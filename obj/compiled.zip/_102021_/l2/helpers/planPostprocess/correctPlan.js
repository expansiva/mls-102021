/// <mls fileReference="_102021_/l2/helpers/planPostprocess/correctPlan.ts" enhancement="_blank"/>
/** Put a `toRemove` usecase that a route still calls back into `usecases` as `done`. Other kinds stay. */
export function correctPlan(input) {
    const backend = clone(input.backend);
    const effort = clone(input.effort);
    const corrections = [];
    for (const item of [...input.used].sort((left, right) => left.id.localeCompare(right.id))) {
        if (!isRemovedUsecase(backend, item.id) && !isRemovedUsecase(effort, item.id))
            continue;
        const backendChange = restore(backend, input.moduleName, item, true);
        const effortChange = restore(effort, input.moduleName, item, false);
        recount(backend, backendChange);
        recount(effort, effortChange);
        corrections.push({
            usecase: item.id,
            from: 'toRemove',
            to: 'done',
            reason: 'exists in l1',
            routes: [...item.routes],
        });
    }
    return { backend, effort, corrections };
}
function restore(doc, moduleName, item, full) {
    const removed = rows(doc.removed);
    const kept = removed.filter(row => !(row.kind === 'usecase' && row.id === item.id && row.status === 'toRemove'));
    const touched = kept.length !== removed.length;
    doc.removed = kept;
    const usecases = rows(doc.usecases);
    doc.usecases = usecases;
    if (usecases.some(row => row.usecaseId === item.id))
        return { added: 0, touched };
    usecases.push(doneRow(usecases, moduleName, item, full));
    return { added: 1, touched: true };
}
function doneRow(usecases, moduleName, item, full) {
    const existing = `l1/${moduleName}/layer_2_application/usecases/${item.id}.defs.ts`;
    if (!full) {
        return { usecaseId: item.id, entity: item.entity, operation: item.operation, status: 'done', existing };
    }
    return {
        usecaseId: item.id,
        entity: item.entity,
        operation: item.operation,
        ports: arrayValue(usecases, item, 'ports'),
        status: 'done',
        existing,
        reason: `exists in l1; used by ${item.routes.length} contract routes`,
        tableRefs: arrayValue(usecases, item, 'tableRefs'),
        noTable: stringValue(usecases, item, 'noTable'),
    };
}
/** First other row of the same entity whose field is non-empty. */
function arrayValue(usecases, item, key) {
    for (const row of usecases) {
        if (row.entity !== item.entity || row.usecaseId === item.id)
            continue;
        if (Array.isArray(row[key]) && row[key].length > 0)
            return row[key];
    }
    return [];
}
function stringValue(usecases, item, key) {
    for (const row of usecases) {
        if (row.entity !== item.entity || row.usecaseId === item.id)
            continue;
        if (typeof row[key] === 'string' && row[key])
            return row[key];
    }
    return '';
}
function recount(doc, change) {
    if (!change.touched || !isRecord(doc.totals))
        return;
    const totals = doc.totals;
    const bucket = totals.usecases;
    if (isRecord(bucket)) {
        if (typeof bucket.done === 'number')
            bucket.done += change.added;
        return;
    }
    if (typeof totals.done === 'number')
        totals.done += change.added;
}
function isRemovedUsecase(doc, id) {
    return rows(doc.removed).some(row => row.kind === 'usecase' && row.id === id && row.status === 'toRemove');
}
function rows(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((row) => isRecord(row));
}
function clone(value) {
    return JSON.parse(JSON.stringify(value));
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
