/// <mls fileReference="_102021_/l2/helpers/l1Defs/operations.ts" enhancement="_blank"/>
export const L1_OPERATIONS = ['list', 'get', 'create', 'update', 'transition', 'delete', 'custom'];
export const L1_OPERATION_TRAITS = {
    list: { read: true, write: false, addressesRecord: false },
    get: { read: true, write: false, addressesRecord: true },
    create: { read: false, write: true, addressesRecord: false },
    update: { read: false, write: true, addressesRecord: true },
    transition: { read: false, write: true, addressesRecord: true },
    delete: { read: false, write: true, addressesRecord: true },
    custom: { read: false, write: false, addressesRecord: false },
};
/** Port reads the M1 body of each operation calls besides its own method: update and transition load the row by list. */
const OPERATION_PORT_READS = {
    list: [],
    get: [],
    create: [],
    update: ['list'],
    transition: ['list'],
    delete: [],
    custom: [],
};
/**
 * The one source for the reads a port declares for an operation (t1_09 r3, r3p6), read by the D1 port plan
 * and by the M1 usecase body: the operation's own reads, and list for a create that checks unique keys.
 */
export function portReadsFor(operation, entity) {
    const reads = [...OPERATION_PORT_READS[operation]];
    if (operation === 'create' && entity.uniqueKeys.length > 0 && !reads.includes('list'))
        reads.push('list');
    return reads;
}
export function isL1Operation(value) {
    return L1_OPERATIONS.includes(value);
}
function lowerFirst(value) {
    return value ? `${value.charAt(0).toLowerCase()}${value.slice(1)}` : value;
}
/** Base transition usecase ids that more than one entity writes (d1_53). */
export function collidingTransitionIds(writes) {
    const entitiesById = new Map();
    for (const write of writes) {
        const id = lowerFirst(write.transitionRef);
        const entities = entitiesById.get(id) ?? new Set();
        entities.add(write.entity);
        entitiesById.set(id, entities);
    }
    return new Set([...entitiesById].filter(([, entities]) => entities.size > 1).map(([id]) => id));
}
/**
 * The one rule for a transition usecase id, for the P1 plan and for a usecase input20 creates from the contract:
 * lowerFirst(transitionRef); when another entity writes the same transition, the entity is appended.
 */
export function transitionUsecaseId(entity, transitionRef, colliding) {
    const id = lowerFirst(transitionRef);
    return colliding.has(id) ? `${id}${entity}` : id;
}
