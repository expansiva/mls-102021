/// <mls fileReference="_102021_/l2/helpers/l1Defs/disclosure.ts" enhancement="_blank"/>
/** Grants that speak for one entity's output: `entityRefs` names it, or the grant has no `entityRefs`. */
export function coveringGrants(grants, entity) {
    return grants.filter(grant => grant.entityRefs.length === 0 || grant.entityRefs.includes(entity));
}
/**
 * Covering grants are grouped by `actorRef` (absent is one actor). Inside an actor a path leaves
 * only when every grant of that actor discloses it. Across actors the path is `disclosed` when
 * some actor discloses it, `carrier` when none does and some actor holds it as a container, else
 * `blocked`. An actor with no grant on the entity is not in the group and does not block.
 * `fullRecord` discloses all; `fieldsOnly`/`summaryOnly` the `<entity>.` allowed fields and what
 * is under them; any other mode nothing.
 * The entity's system paths (primary key and declared concurrency field) leave with any covering
 * grant. They are not business data, so `allowedFields` does not have to name them. A grant that
 * does not cover the entity still discloses nothing.
 */
export function pathDisclosure(grants, entity, path, entityDefinition) {
    const covering = coveringGrants(grants, entity);
    if (covering.length === 0)
        return 'blocked';
    if (systemFieldPaths(entityDefinition).includes(path))
        return 'disclosed';
    let carrier = false;
    for (const group of grantsByActor(covering).values()) {
        const verdict = actorPathDisclosure(group, entity, path);
        if (verdict === 'disclosed')
            return 'disclosed';
        if (verdict === 'carrier')
            carrier = true;
    }
    return carrier ? 'carrier' : 'blocked';
}
/**
 * The nodes of one output. A view of the request tree (`requestTree.ts` `outputViews`, d1_61) carries them; a def
 * written before the tree (`outputs`) has none, and each path is read as a path of its entity.
 */
export function outputNodes(output) {
    return output.disclosure
        ? [...output.disclosure]
        : output.fields.map(field => ({ kind: 'entity', field, entity: output.entity, path: field }));
}
/**
 * The one rule for a classified path. An entity path goes through `pathDisclosure` on its ontology path. A paging key
 * leaves. A calculated value leaves when some actor's grants on its entity are all `fullRecord`, and there is one:
 * an aggregate of records may reveal what the fields do not, so it is closed by default. An actor with no grant
 * on the entity does not block the others.
 */
export function nodeDisclosure(grants, node, entityDefinition) {
    if (node.kind === 'paging')
        return 'disclosed';
    if (node.kind === 'entity')
        return pathDisclosure(grants, node.entity, node.path, entityDefinition(node.entity));
    // d1_65: an aggregate no entity owns has no entity field to check. It leaves to whoever holds the route authority
    // (`grants` are the grants of the route), and is closed without one, or when a grant has no declared mode (an
    // undeclared grant read as `{}`). Alpha risk: a count or a sum may reveal records whose fields the actor does not
    // see; the L4 reviewer chooses the page grants.
    if (!node.entity)
        return grants.length > 0 && grants.every(grant => DECLARED_MODES.includes(grant.disclosure)) ? 'disclosed' : 'computed';
    const covering = coveringGrants(grants, node.entity);
    for (const group of grantsByActor(covering).values()) {
        if (group.every(grant => grant.disclosure === 'fullRecord'))
            return 'disclosed';
    }
    return 'computed';
}
/** Absent `actorRef` is one actor. Callers that pass the whole grant keep its actor. */
function grantsByActor(grants) {
    const groups = new Map();
    for (const grant of grants) {
        const key = grant.actorRef ?? '';
        const group = groups.get(key);
        if (group)
            group.push(grant);
        else
            groups.set(key, [grant]);
    }
    return groups;
}
/** Today's rule, for the grants of one actor. */
function actorPathDisclosure(grants, entity, path) {
    const refusing = grants.filter(grant => !grantDiscloses(grant, entity, path));
    if (refusing.length === 0)
        return 'disclosed';
    return refusing.every(grant => allowedOf(grant, entity).some(item => item.startsWith(`${path}.`))) ? 'carrier' : 'blocked';
}
/**
 * Primary key and concurrency field of one entity, for a domain def or an ontology entity.
 * The identity is the derived `uuid`, else the first derived field; the concurrency field is the
 * single other derived integer or number. A field that is not marked is not included. Not a name list.
 * `domainOptional` reads these two; it does not keep a second copy of the marks.
 */
export function systemIdentity(entityDefinition) {
    const fields = markedFields(entityDefinition);
    const uuid = fields.find(field => field.derived && field.type === 'uuid');
    const identity = uuid ?? fields.find(field => field.derived);
    return identity && isIdent(identity.name) ? identity.name : '';
}
/** The single other derived integer or number, or '' when the entity does not declare exactly one. */
export function systemVersion(entityDefinition, identity) {
    const versions = markedFields(entityDefinition).filter(field => field.derived && field.name !== identity && (field.type === 'integer' || field.type === 'number'));
    return versions.length === 1 && isIdent(versions[0].name) ? versions[0].name : '';
}
export function systemFieldPaths(entityDefinition) {
    const identity = systemIdentity(entityDefinition);
    return [identity, systemVersion(entityDefinition, identity)].filter(name => name.length > 0);
}
function markedFields(entityDefinition) {
    const data = recordData(entityDefinition);
    if (!data)
        return [];
    if (Array.isArray(data.fields)) {
        return data.fields.filter(isRecord).map(field => ({
            name: typeof field.name === 'string' ? field.name : '',
            type: typeof field.type === 'string' ? field.type : '',
            derived: field.derived === true,
        })).filter(field => field.name.length > 0 && !field.name.includes('.'));
    }
    const record = isRecord(data.record) ? data.record : data;
    const map = isRecord(record.fields) ? record.fields : null;
    if (!map)
        return [];
    return Object.entries(map).filter((entry) => isRecord(entry[1])).map(([name, field]) => ({
        name,
        type: typeof field.type === 'string' ? field.type : '',
        derived: field.derived === true,
    })).filter(field => field.name.length > 0 && !field.name.includes('.'));
}
function recordData(value) {
    if (!isRecord(value))
        return null;
    return isRecord(value.data) ? value.data : value;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function isIdent(name) {
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
}
/** The disclosure modes a grant may declare. */
const DECLARED_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly'];
function grantDiscloses(grant, entity, path) {
    if (grant.disclosure === 'fullRecord')
        return true;
    if (grant.disclosure !== 'fieldsOnly' && grant.disclosure !== 'summaryOnly')
        return false;
    return allowedOf(grant, entity).some(item => item === '' || item === path || path.startsWith(`${item}.`));
}
/** Allowed fields relative to the entity; `''` is the whole record. */
function allowedOf(grant, entity) {
    const prefix = `${entity}.`;
    const out = [];
    for (const item of grant.allowedFields) {
        if (item === entity)
            out.push('');
        else if (entity && item.startsWith(prefix))
            out.push(item.slice(prefix.length));
    }
    return out;
}
/**
 * `fieldsOnly` read as an explicit allow-list. No `deniedFields`: `allowedFields` as declared.
 * With denials, each `entityRefs` entry is walked on `record.fields` (tree order, no repeats).
 * A ref under a denial drops; an ancestor is replaced by its children; the bare entity never
 * stays (it becomes its first-level fields). A denial of the entity drops it. No `record.fields` throws.
 */
export function resolveAllowedFields(grant, entities) {
    const denied = grant.deniedFields ?? [];
    if (denied.length === 0)
        return [...(grant.allowedFields ?? [])];
    const out = [];
    const seen = new Set();
    for (const entity of grant.entityRefs) {
        const fields = recordFieldMap(entities[entity]);
        if (!fields)
            throw new Error(`D1_GRANT_DENIED_UNRESOLVED: ${grant.grantId} ${entity} has no record.fields`);
        if (denied.some(item => item === entity))
            continue;
        const seeds = grant.allowedFields == null
            ? [entity]
            : grant.allowedFields.filter(item => item === entity || item.startsWith(`${entity}.`));
        for (const seed of seeds)
            walkAllowed(entity, seed, fields, denied, out, seen);
    }
    return out;
}
function walkAllowed(entity, ref, fields, denied, out, seen) {
    if (denied.some(item => ref === item || ref.startsWith(`${item}.`)))
        return;
    if (ref === entity || denied.some(item => item.startsWith(`${ref}.`))) {
        for (const child of childRefs(entity, ref, fields))
            walkAllowed(entity, child, fields, denied, out, seen);
        return;
    }
    if (seen.has(ref))
        return;
    seen.add(ref);
    out.push(ref);
}
function childRefs(entity, ref, fields) {
    const relative = ref === entity ? '' : ref.slice(entity.length + 1);
    let node = fields;
    if (relative.length > 0) {
        for (const part of relative.split('.')) {
            const child = node[part];
            if (!isRecord(child) || !isRecord(child.fields))
                return [];
            node = child.fields;
        }
    }
    const prefix = relative.length === 0 ? entity : `${entity}.${relative}`;
    return Object.keys(node).map(name => `${prefix}.${name}`);
}
function recordFieldMap(entityDefinition) {
    if (!isRecord(entityDefinition))
        return null;
    const data = isRecord(entityDefinition.data) ? entityDefinition.data : entityDefinition;
    const record = isRecord(data.record) ? data.record : null;
    return record && isRecord(record.fields) ? record.fields : null;
}
