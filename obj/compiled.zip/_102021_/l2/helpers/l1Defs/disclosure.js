/// <mls fileReference="_102021_/l2/helpers/l1Defs/disclosure.ts" enhancement="_blank"/>
/** Grants that speak for one entity's output: `entityRefs` names it, or the grant has no `entityRefs`. */
export function coveringGrants(grants, entity) {
    return grants.filter(grant => grant.entityRefs.length === 0 || grant.entityRefs.includes(entity));
}
/**
 * A path leaves only when every covering grant discloses it. No covering grant is `blocked`
 * (fail closed). `fullRecord` discloses all; `fieldsOnly`/`summaryOnly` the `<entity>.` allowed
 * fields and what is under them; any other mode nothing.
 * The entity's system paths (primary key and declared concurrency field) leave with any covering
 * grant. They are not business data, so `allowedFields` does not have to name them. A grant that
 * does not cover the entity still discloses nothing.
 */
export function pathDisclosure(grants, entity, path, entityDefinition) {
    const covering = coveringGrants(grants, entity);
    if (covering.length === 0)
        return 'blocked';
    if (systemFieldPaths(entityDefinition).includes(path))
        return 'disclosed';
    const refusing = covering.filter(grant => !grantDiscloses(grant, entity, path));
    if (refusing.length === 0)
        return 'disclosed';
    return refusing.every(grant => allowedOf(grant, entity).some(item => item.startsWith(`${path}.`))) ? 'carrier' : 'blocked';
}
/**
 * The nodes of one output. A view of the request tree (`requestTree.ts` `outputViews`, d1_61) carries them; a def
 * written before the tree (`outputs`) has none, and each path is read as a path of its entity.
 */
export function outputNodes(output) {
    return output.disclosure
        ? [...output.disclosure]
        : output.fields.map(field => ({ kind: 'entity', field, entity: output.entity, path: field }));
}
/**
 * The one rule for a classified path. An entity path goes through `pathDisclosure` on its ontology path. A paging key
 * leaves. A calculated value leaves only when every grant that covers its entity is `fullRecord`, and there is one:
 * an aggregate of records may reveal what the fields do not, so it is closed by default.
 */
export function nodeDisclosure(grants, node, entityDefinition) {
    if (node.kind === 'paging')
        return 'disclosed';
    if (node.kind === 'entity')
        return pathDisclosure(grants, node.entity, node.path, entityDefinition(node.entity));
    // d1_65: an aggregate no entity owns has no entity field to check. It leaves to whoever holds the route authority
    // (`grants` are the grants of the route), and is closed without one, or when a grant has no declared mode (an
    // undeclared grant read as `{}`). Alpha risk: a count or a sum may reveal records whose fields the actor does not
    // see; the L4 reviewer chooses the page grants.
    if (!node.entity)
        return grants.length > 0 && grants.every(grant => DECLARED_MODES.includes(grant.disclosure)) ? 'disclosed' : 'computed';
    const covering = coveringGrants(grants, node.entity);
    return covering.length > 0 && covering.every(grant => grant.disclosure === 'fullRecord') ? 'disclosed' : 'computed';
}
/**
 * Primary key and concurrency field of one entity, for a domain def or an ontology entity.
 * The identity is the derived `uuid`, else the first derived field; the concurrency field is the
 * single other derived integer or number. A field that is not marked is not included. Not a name list.
 * `domainOptional` reads these two; it does not keep a second copy of the marks.
 */
export function systemIdentity(entityDefinition) {
    const fields = markedFields(entityDefinition);
    const uuid = fields.find(field => field.derived && field.type === 'uuid');
    const identity = uuid ?? fields.find(field => field.derived);
    return identity && isIdent(identity.name) ? identity.name : '';
}
/** The single other derived integer or number, or '' when the entity does not declare exactly one. */
export function systemVersion(entityDefinition, identity) {
    const versions = markedFields(entityDefinition).filter(field => field.derived && field.name !== identity && (field.type === 'integer' || field.type === 'number'));
    return versions.length === 1 && isIdent(versions[0].name) ? versions[0].name : '';
}
export function systemFieldPaths(entityDefinition) {
    const identity = systemIdentity(entityDefinition);
    return [identity, systemVersion(entityDefinition, identity)].filter(name => name.length > 0);
}
function markedFields(entityDefinition) {
    const data = recordData(entityDefinition);
    if (!data)
        return [];
    if (Array.isArray(data.fields)) {
        return data.fields.filter(isRecord).map(field => ({
            name: typeof field.name === 'string' ? field.name : '',
            type: typeof field.type === 'string' ? field.type : '',
            derived: field.derived === true,
        })).filter(field => field.name.length > 0 && !field.name.includes('.'));
    }
    const record = isRecord(data.record) ? data.record : data;
    const map = isRecord(record.fields) ? record.fields : null;
    if (!map)
        return [];
    return Object.entries(map).filter((entry) => isRecord(entry[1])).map(([name, field]) => ({
        name,
        type: typeof field.type === 'string' ? field.type : '',
        derived: field.derived === true,
    })).filter(field => field.name.length > 0 && !field.name.includes('.'));
}
function recordData(value) {
    if (!isRecord(value))
        return null;
    return isRecord(value.data) ? value.data : value;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function isIdent(name) {
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
}
/** The disclosure modes a grant may declare. */
const DECLARED_MODES = ['fullRecord', 'fieldsOnly', 'summaryOnly'];
function grantDiscloses(grant, entity, path) {
    if (grant.disclosure === 'fullRecord')
        return true;
    if (grant.disclosure !== 'fieldsOnly' && grant.disclosure !== 'summaryOnly')
        return false;
    return allowedOf(grant, entity).some(item => item === '' || item === path || path.startsWith(`${item}.`));
}
/** Allowed fields relative to the entity; `''` is the whole record. */
function allowedOf(grant, entity) {
    const prefix = `${entity}.`;
    const out = [];
    for (const item of grant.allowedFields) {
        if (item === entity)
            out.push('');
        else if (entity && item.startsWith(prefix))
            out.push(item.slice(prefix.length));
    }
    return out;
}
