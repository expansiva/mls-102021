/// <mls fileReference="_102021_/l2/helpers/l1Defs/requestTree.ts" enhancement="_blank"/>
export const REQUEST_NODE_KINDS = ['entity', 'list', 'related', 'computed', 'unresolved'];
export const REQUEST_PAGING_KEYS = ['page', 'pageSize', 'hasMore', 'total'];
export const REQUEST_DOC_SECTIONS = ['purpose', 'input', 'processing', 'output'];
/** The contract path of the records of a node: the item array of a page wrapper, else the node path. */
export function elementPath(node) {
    return node.kind === 'list' && node.items ? `${node.path}.${node.items}` : node.path;
}
/** The tree of a def read back. Null when any node is not a node (fail closed). */
export function readOutputTree(value) {
    if (!Array.isArray(value))
        return null;
    const nodes = [];
    for (const item of value) {
        const node = readNode(item);
        if (!node)
            return null;
        nodes.push(node);
    }
    return nodes;
}
/** The doc of a def read back: undefined when absent, null when it is not a doc. */
export function readRequestDoc(value) {
    if (value === undefined)
        return undefined;
    if (!isRecord(value) || typeof value.raw !== 'string')
        return null;
    const doc = { raw: value.raw };
    for (const key of Object.keys(value)) {
        if (key === 'raw')
            continue;
        if (!REQUEST_DOC_SECTIONS.includes(key) || typeof value[key] !== 'string')
            return null;
        doc[key] = value[key];
    }
    return doc;
}
export function outputViews(tree) {
    const keys = [];
    for (const node of tree) {
        const key = node.path.split('.')[0];
        if (!keys.includes(key))
            keys.push(key);
    }
    return keys.map(key => {
        const under = tree.filter(node => node.path === key || node.path.startsWith(`${key}.`));
        const head = under.find((node) => node.path === key && (node.kind === 'entity' || node.kind === 'list'));
        const fields = [];
        const disclosure = [];
        for (const node of under) {
            if (node.kind === 'unresolved')
                continue;
            if (node.kind === 'computed') {
                // A value that is the whole member (an aggregate with no field of an entity) is named by the member.
                const field = relative(node.path, key) || key;
                fields.push(field);
                disclosure.push({ kind: 'computed', field, entity: node.entity ?? '' });
                continue;
            }
            if (node.kind === 'list') {
                for (const name of REQUEST_PAGING_KEYS) {
                    const value = node[name];
                    if (value)
                        disclosure.push({ kind: 'paging', field: relative(value, key) });
                }
            }
            const prefix = relative(elementPath(node), key);
            for (const item of node.fields) {
                const field = prefix ? `${prefix}.${item.field}` : item.field;
                fields.push(field);
                disclosure.push({ kind: 'entity', field, entity: node.entity, path: item.path });
            }
        }
        return { key, entity: head?.entity ?? '', fields, disclosure };
    });
}
/** `path` relative to `key`; '' for `key` itself; a path outside `key` (a flat paging key at the root) as it is. */
function relative(path, key) {
    if (path === key)
        return '';
    return path.startsWith(`${key}.`) ? path.slice(key.length + 1) : path;
}
function readNode(item) {
    if (!isRecord(item) || !text(item.path))
        return null;
    const path = item.path;
    switch (item.kind) {
        case 'entity': {
            const fields = readFields(item.fields);
            if (!fields || !text(item.entity) || !onlyKeys(item, ['kind', 'path', 'entity', 'fields']))
                return null;
            return { kind: 'entity', path, entity: item.entity, fields };
        }
        case 'list': {
            const fields = readFields(item.fields);
            if (!fields || !text(item.entity) || typeof item.items !== 'string')
                return null;
            if (!onlyKeys(item, ['kind', 'path', 'entity', 'items', 'fields', ...REQUEST_PAGING_KEYS]))
                return null;
            const node = { kind: 'list', path, entity: item.entity, items: item.items, fields };
            for (const name of REQUEST_PAGING_KEYS) {
                if (item[name] === undefined)
                    continue;
                if (!text(item[name]))
                    return null;
                node[name] = item[name];
            }
            return node;
        }
        case 'related': {
            const fields = readFields(item.fields);
            if (!fields || !text(item.entity) || !onlyKeys(item, ['kind', 'path', 'entity', 'relationship', 'fields']))
                return null;
            if (item.relationship !== undefined && !text(item.relationship))
                return null;
            return { kind: 'related', path, entity: item.entity, ...(item.relationship ? { relationship: item.relationship } : {}), fields };
        }
        case 'computed': {
            if (!Array.isArray(item.rules) || !item.rules.every(text) || !onlyKeys(item, ['kind', 'path', 'entity', 'rules']))
                return null;
            if (item.entity !== undefined && !text(item.entity))
                return null;
            return { kind: 'computed', path, ...(item.entity ? { entity: item.entity } : {}), rules: [...item.rules] };
        }
        case 'unresolved':
            if (!text(item.reason) || !onlyKeys(item, ['kind', 'path', 'reason']))
                return null;
            return { kind: 'unresolved', path, reason: item.reason };
        default:
            return null;
    }
}
function readFields(value) {
    if (!Array.isArray(value))
        return null;
    const fields = [];
    for (const item of value) {
        if (!isRecord(item) || !text(item.field) || !text(item.path) || !onlyKeys(item, ['field', 'path']))
            return null;
        fields.push({ field: item.field, path: item.path });
    }
    return fields;
}
function onlyKeys(value, keys) {
    return Object.keys(value).every(key => keys.includes(key));
}
function text(value) {
    return typeof value === 'string' && value.length > 0;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
