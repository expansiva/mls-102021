/// <mls fileReference="_102021_/l2/helpers/effort/describeEffort.ts" enhancement="_blank"/>
import { parseD2ContractV2 } from '/_102020_/l2/helpers/contractV2/render.js';
import { parseDefinitionSource } from '/_102021_/l2/helpers/l1Defs/definition.js';
const MASTER = { project: '102021', kind: 'l1', device: 'web' };
const NO_DEFS = 'módulo sem defs gerados';
const NONE_APPLY = 'nenhum def aplica o id';
function abend(item, reason) {
    return {
        master: { ...MASTER },
        item,
        status: 'abend',
        create: [],
        regenerateDefs: [],
        materialize: [],
        remove: [],
        runAgents: [],
        contract: 'keep',
        abend: { reason },
    };
}
function computed(item, materialize, regenerateDefs = [], remove = [], create = []) {
    return {
        master: { ...MASTER },
        item,
        status: 'computed',
        create,
        regenerateDefs,
        materialize,
        remove,
        runAgents: [],
        contract: 'keep',
    };
}
function ruleIdOf(item) {
    const prefix = 'rule:';
    return item.changeId.startsWith(prefix) ? item.changeId.slice(prefix.length) : '';
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function listsRule(value, ruleId) {
    if (value === ruleId)
        return true;
    if (!Array.isArray(value))
        return false;
    return value.some(entry => {
        if (entry === ruleId)
            return true;
        return isRecord(entry) && entry.ruleId === ruleId;
    });
}
function unitId(artifactType, data) {
    if (artifactType === 'usecase')
        return typeof data.usecaseId === 'string' ? data.usecaseId : '';
    if (artifactType === 'requestService')
        return typeof data.pageId === 'string' ? data.pageId : '';
    if (artifactType === 'domainEntity') {
        const entityId = typeof data.entityId === 'string' ? data.entityId : '';
        return entityId ? entityId.charAt(0).toLowerCase() + entityId.slice(1) : '';
    }
    return '';
}
function applies(artifactType, data, ruleId) {
    if (artifactType === 'usecase')
        return listsRule(data.rulesApplied, ruleId);
    if (artifactType === 'domainEntity') {
        if (listsRule(data.invariants, ruleId))
            return true;
        const lifecycle = isRecord(data.lifecycle) ? data.lifecycle : {};
        const transitions = Array.isArray(lifecycle.transitions) ? lifecycle.transitions : [];
        return transitions.some(transition => isRecord(transition) && listsRule(transition.ruleRefs, ruleId));
    }
    if (artifactType === 'requestService') {
        const requests = Array.isArray(data.requests) ? data.requests : [];
        return requests.some(request => isRecord(request) && listsRule(request.rules, ruleId));
    }
    return false;
}
function kindOf(artifactType) {
    if (artifactType === 'usecase')
        return 'usecase';
    if (artifactType === 'domainEntity')
        return 'entity';
    if (artifactType === 'requestService')
        return 'request';
    return null;
}
function sortUnits(units) {
    return units.sort((a, b) => a.kind.localeCompare(b.kind) || a.id.localeCompare(b.id));
}
function idAfter(changeId, prefix) {
    return changeId.startsWith(prefix) ? changeId.slice(prefix.length) : '';
}
/** `task:<processId>.<taskId>` — the process id is the segment before the first dot. */
function taskProcessId(changeId) {
    const rest = idAfter(changeId, 'task:');
    const dot = rest.indexOf('.');
    return dot > 0 ? rest.slice(0, dot) : '';
}
function eachDefinition(defs, visit) {
    for (const defPath of Object.keys(defs)) {
        const parsed = parseDefinitionSource(defs[defPath] ?? '');
        if (!('definition' in parsed) || !isRecord(parsed.definition))
            continue;
        const definition = parsed.definition;
        const artifactType = typeof definition.artifactType === 'string' ? definition.artifactType : '';
        const data = isRecord(definition.data) ? definition.data : null;
        if (!artifactType || !data)
            continue;
        visit(defPath, artifactType, data);
    }
}
function citingUnits(defs, ruleId) {
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        const kind = kindOf(artifactType);
        if (!kind)
            return;
        const id = unitId(artifactType, data);
        if (!id || !applies(artifactType, data, ruleId))
            return;
        units.push({ kind, id, path: defPath });
    });
    return sortUnits(units);
}
function workflowUnits(defs, processId) {
    if (!processId)
        return [];
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (artifactType !== 'workflowProcess')
            return;
        if (data.processId !== processId)
            return;
        units.push({ kind: 'workflow', id: processId, path: defPath });
    });
    return sortUnits(units);
}
const FORM_ATTRIBUTES = new Set(['type', 'values', 'required', 'collection', 'to']);
const TEXT_ATTRIBUTES = new Set(['title', 'description']);
const CITE_VALUE_KEYS = new Set(['name', 'field', 'path', 'column']);
const NO_FIELD_UNIT = 'no backend unit cites this field';
const NO_GRANT_UNIT = 'no backend unit cites this grant';
const NO_WORKFLOW_UNIT = 'no backend workflow def for this process';
const NO_TRANSITION_UNIT = 'no backend unit cites this transition';
const NO_PUBLISHED_OPERATION = 'no usecase matches the published operation';
const INBOUND_UNHANDLED = 'inbound integration change is not handled yet';
function sameName(left, right) {
    return left.localeCompare(right, 'en', { sensitivity: 'accent' }) === 0;
}
function lowerFirst(value) {
    return value ? value.charAt(0).toLowerCase() + value.slice(1) : '';
}
function fieldPathOf(changeId) {
    return idAfter(changeId, 'field:');
}
function sameJson(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
/** Keys whose value differs. Null when `before` or `after` is not an object. */
function changedAttributeKeys(item) {
    if (!isRecord(item.before) || !isRecord(item.after))
        return null;
    const keys = new Set([...Object.keys(item.before), ...Object.keys(item.after)]);
    const changed = [];
    for (const key of keys) {
        if (!sameJson(item.before[key], item.after[key]))
            changed.push(key);
    }
    return changed;
}
function fieldClass(item) {
    if (item.op === 'added')
        return 'added';
    if (item.op === 'removed')
        return 'removed';
    if (item.op !== 'changed')
        return null;
    const changed = changedAttributeKeys(item);
    if (!changed || changed.length === 0)
        return null;
    if (changed.some(key => FORM_ATTRIBUTES.has(key)))
        return 'form';
    if (changed.some(key => !TEXT_ATTRIBUTES.has(key)))
        return 'validation';
    return null;
}
function textHits(text, full, last) {
    return text === full || text === last;
}
/** Whole-string cite: a key, a `name`/`field`/`path`/`column` value, or a `columns` entry. Not prose. */
function citesPath(value, full, last) {
    const walk = (node, parentKey) => {
        if (typeof node === 'string') {
            if (parentKey === 'columns' || (parentKey !== null && CITE_VALUE_KEYS.has(parentKey))) {
                return textHits(node, full, last);
            }
            return false;
        }
        if (Array.isArray(node))
            return node.some(entry => walk(entry, parentKey));
        if (!isRecord(node))
            return false;
        for (const [key, child] of Object.entries(node)) {
            if (textHits(key, full, last))
                return true;
            if (walk(child, key))
                return true;
        }
        return false;
    };
    return walk(value, null);
}
/** The object that names the field also stores `attribute` as its own key. */
function storesAttribute(value, full, last, attribute) {
    const walk = (node) => {
        if (Array.isArray(node))
            return node.some(entry => walk(entry));
        if (!isRecord(node))
            return false;
        const namesField = Object.entries(node).some(([key, child]) => {
            if (textHits(key, full, last))
                return true;
            if (typeof child === 'string' && CITE_VALUE_KEYS.has(key) && textHits(child, full, last))
                return true;
            if (key === 'columns' && Array.isArray(child) && child.some(entry => typeof entry === 'string' && textHits(entry, full, last))) {
                return true;
            }
            return false;
        });
        if (namesField && Object.prototype.hasOwnProperty.call(node, attribute))
            return true;
        return Object.values(node).some(child => walk(child));
    };
    return walk(value);
}
function entityData(defs, entity) {
    let found = null;
    eachDefinition(defs, (_defPath, artifactType, data) => {
        if (found || artifactType !== 'domainEntity')
            return;
        if (typeof data.entityId === 'string' && sameName(data.entityId, entity))
            found = data;
    });
    return found;
}
function fieldPrefix(path) {
    const dot = path.lastIndexOf('.');
    return dot < 0 ? '' : path.slice(0, dot + 1);
}
function isSiblingField(name, path) {
    if (name === path)
        return false;
    const prefix = fieldPrefix(path);
    if (!name.startsWith(prefix))
        return false;
    const rest = name.slice(prefix.length);
    return rest.length > 0 && !rest.includes('.');
}
function nonDerivedSiblings(data, path) {
    const names = new Set();
    if (!data)
        return names;
    const fields = Array.isArray(data.fields) ? data.fields : [];
    for (const field of fields) {
        if (!isRecord(field) || typeof field.name !== 'string')
            continue;
        if (field.derived === true)
            continue;
        if (isSiblingField(field.name, path))
            names.add(field.name);
    }
    return names;
}
function outputCitesSibling(data, entity, siblings) {
    if (siblings.size === 0)
        return false;
    const requests = Array.isArray(data.requests) ? data.requests : [];
    const cites = (node) => {
        if (Array.isArray(node))
            return node.some(entry => cites(entry));
        if (!isRecord(node))
            return false;
        for (const [key, child] of Object.entries(node)) {
            if ((key === 'field' || key === 'path') && typeof child === 'string' && siblings.has(child))
                return true;
            if (cites(child))
                return true;
        }
        return false;
    };
    return requests.some(request => {
        if (!isRecord(request) || !Array.isArray(request.output))
            return false;
        return request.output.some(node => isRecord(node) && typeof node.entity === 'string' && sameName(node.entity, entity) && cites(node));
    });
}
function remember(units, seen, unit) {
    const key = `${unit.kind}:${unit.id}`;
    if (seen.has(key))
        return;
    seen.add(key);
    units.push(unit);
}
function fieldUnits(defs, entity, path) {
    const full = path;
    const last = path.includes('.') ? path.slice(path.lastIndexOf('.') + 1) : path;
    const siblings = nonDerivedSiblings(entityData(defs, entity), path);
    let entityUnit = null;
    let tableUnit = null;
    let adapterUnit = null;
    const writers = [];
    const citing = [];
    const outputSiblings = [];
    const writerIds = new Set();
    eachDefinition(defs, (defPath, artifactType, data) => {
        const entityId = typeof data.entityId === 'string' ? data.entityId : '';
        const ofEntity = entityId !== '' && sameName(entityId, entity);
        if (artifactType === 'domainEntity' && ofEntity) {
            const id = lowerFirst(entityId);
            if (!id)
                return;
            entityUnit = { kind: 'entity', id, path: defPath };
            if (citesPath(data, full, last))
                citing.push(entityUnit);
            return;
        }
        if (artifactType === 'table' && ofEntity) {
            const id = typeof data.tableId === 'string' ? data.tableId : '';
            if (!id)
                return;
            tableUnit = { kind: 'table', id, path: defPath };
            if (citesPath(data, full, last))
                citing.push(tableUnit);
            return;
        }
        if (artifactType === 'repositoryAdapter' && ofEntity) {
            const portId = typeof data.portId === 'string' ? data.portId : '';
            const id = lowerFirst(portId);
            if (!id)
                return;
            adapterUnit = { kind: 'repository', id, path: defPath };
            if (citesPath(data, full, last))
                citing.push(adapterUnit);
            return;
        }
        if (artifactType === 'usecase' && ofEntity) {
            const operation = typeof data.operation === 'string' ? data.operation : '';
            if (operation !== 'create' && operation !== 'update')
                return;
            const id = unitId(artifactType, data);
            if (!id)
                return;
            const unit = { kind: 'usecase', id, path: defPath };
            writers.push(unit);
            writerIds.add(id);
            if (citesPath(data, full, last))
                citing.push(unit);
            return;
        }
        if (artifactType === 'requestService') {
            const id = unitId(artifactType, data);
            if (!id)
                return;
            const unit = { kind: 'request', id, path: defPath };
            if (citesPath(data, full, last))
                citing.push(unit);
            if (outputCitesSibling(data, entity, siblings))
                outputSiblings.push(unit);
        }
    });
    const writeRequests = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (artifactType !== 'requestService')
            return;
        const id = unitId(artifactType, data);
        if (!id)
            return;
        const requests = Array.isArray(data.requests) ? data.requests : [];
        const writes = requests.some(request => isRecord(request) && Array.isArray(request.uses) && request.uses.some(use => typeof use === 'string' && writerIds.has(use)));
        if (writes)
            writeRequests.push({ kind: 'request', id, path: defPath });
    });
    const storing = (attribute) => {
        const stored = [];
        eachDefinition(defs, (defPath, artifactType, data) => {
            if (!storesAttribute(data, full, last, attribute))
                return;
            if (artifactType === 'domainEntity' && entityUnit && entityUnit.path === defPath)
                stored.push(entityUnit);
            if (artifactType === 'table' && tableUnit && tableUnit.path === defPath)
                stored.push(tableUnit);
            if (artifactType === 'repositoryAdapter' && adapterUnit && adapterUnit.path === defPath)
                stored.push(adapterUnit);
        });
        return stored;
    };
    return { entity: entityUnit, table: tableUnit, adapter: adapterUnit, writers, writeRequests, citing, outputSiblings, storing };
}
function columnPath(path) {
    return path.length > 0 && !path.includes('.');
}
function grantIdOf(changeId) {
    return idAfter(changeId, 'grant:');
}
const NO_JOURNEY_CITE = 'no backend unit cites this journey';
const NO_STEP_CITE = 'no backend unit cites this step';
function indexWithoutTitle(value) {
    if (!isRecord(value))
        return value;
    const copy = { ...value };
    delete copy.title;
    return copy;
}
function journeyIds(changeId) {
    if (changeId.startsWith('journey:'))
        return { journeyId: changeId.slice('journey:'.length), stepId: '' };
    if (!changeId.startsWith('step:'))
        return null;
    const rest = changeId.slice('step:'.length);
    const slash = rest.indexOf('/');
    if (slash <= 0 || slash === rest.length - 1)
        return { journeyId: '', stepId: '' };
    return { journeyId: rest.slice(0, slash), stepId: rest.slice(slash + 1) };
}
function stringValueMatches(value, match) {
    const walk = (node) => {
        if (typeof node === 'string')
            return match(node);
        if (Array.isArray(node))
            return node.some(entry => walk(entry));
        if (!isRecord(node))
            return false;
        return Object.values(node).some(child => walk(child));
    };
    return walk(value);
}
/** Whole string `journey:<id>` or `journey:<id>/…`. Not a fragment of another value. */
function citesJourney(value, journeyId) {
    if (!journeyId)
        return false;
    const exact = `journey:${journeyId}`;
    const prefix = `${exact}/`;
    return stringValueMatches(value, text => text === exact || text.startsWith(prefix));
}
/** Whole string `journey:<journey>/<step>`. */
function citesStep(value, journeyId, stepId) {
    if (!journeyId || !stepId)
        return false;
    const exact = `journey:${journeyId}/${stepId}`;
    return stringValueMatches(value, text => text === exact);
}
function seedUnit(def) {
    if (def.artifactType !== 'persistenceSeeds' || !def.artifactId)
        return null;
    return { kind: 'seeds', id: def.artifactId, path: def.path };
}
function workflowUnit(def) {
    if (def.artifactType !== 'workflowProcess')
        return null;
    const processId = typeof def.data.processId === 'string' ? def.data.processId : '';
    if (!processId)
        return null;
    return { kind: 'workflow', id: processId, path: def.path };
}
function journeyEffort(input, defs) {
    const item = input.item;
    if (item.kind !== 'journey' && item.kind !== 'step')
        return null;
    if (item.op !== 'added' && item.op !== 'removed' && item.op !== 'changed')
        return null;
    const ids = journeyIds(item.changeId) ?? { journeyId: '', stepId: '' };
    const parsed = grantDefs(defs);
    if (item.kind === 'journey' && item.op === 'added') {
        const units = sortUnits(parsed.flatMap(def => {
            const unit = seedUnit(def);
            return unit ? [unit] : [];
        }));
        if (units.length === 0)
            console.info(item.changeId, NO_JOURNEY_CITE);
        return computed(item.changeId, units, units);
    }
    const citeJourney = item.kind === 'journey' || item.op === 'added';
    const units = sortUnits(parsed.flatMap(def => {
        const cited = citeJourney
            ? citesJourney(def.data, ids.journeyId)
            : citesStep(def.data, ids.journeyId, ids.stepId);
        if (!cited)
            return [];
        const unit = seedUnit(def) ?? workflowUnit(def);
        return unit ? [unit] : [];
    }));
    if (units.length === 0)
        console.info(item.changeId, citeJourney ? NO_JOURNEY_CITE : NO_STEP_CITE);
    return computed(item.changeId, units, units);
}
/** A whole string equal to the grant id or to `grant:<id>`. Not a fragment of prose. */
function citesGrant(value, grantId) {
    const prefixed = `grant:${grantId}`;
    const walk = (node) => {
        if (typeof node === 'string')
            return node === grantId || node === prefixed;
        if (Array.isArray(node))
            return node.some(entry => walk(entry));
        if (!isRecord(node))
            return false;
        return Object.values(node).some(child => walk(child));
    };
    return walk(value);
}
function grantDefs(defs) {
    const found = [];
    for (const defPath of Object.keys(defs)) {
        const parsed = parseDefinitionSource(defs[defPath] ?? '');
        if (!('definition' in parsed) || !isRecord(parsed.definition))
            continue;
        const definition = parsed.definition;
        const artifactType = typeof definition.artifactType === 'string' ? definition.artifactType : '';
        const data = isRecord(definition.data) ? definition.data : null;
        if (!artifactType || !data)
            continue;
        const artifactId = typeof definition.artifactId === 'string' ? definition.artifactId : '';
        found.push({ path: defPath, artifactType, artifactId, data });
    }
    return found;
}
const GRANT_LIST_KIND = {
    authorityMap: 'authority',
    accessScope: 'scope',
    persistenceSeeds: 'seeds',
};
function sharedUnit(def) {
    const kind = GRANT_LIST_KIND[def.artifactType];
    if (!kind || !def.artifactId)
        return null;
    return { kind, id: def.artifactId, path: def.path };
}
function controllerUnit(def) {
    if (def.artifactType !== 'httpController')
        return null;
    const pageId = typeof def.data.pageId === 'string' ? def.data.pageId : '';
    if (!pageId)
        return null;
    return { kind: 'controller', id: pageId, path: def.path };
}
function requestForPage(defs, pageId) {
    for (const def of defs) {
        if (def.artifactType !== 'requestService')
            continue;
        if (def.data.pageId !== pageId)
            continue;
        return { kind: 'request', id: pageId, path: def.path };
    }
    return null;
}
function grantEffort(input, defs) {
    const item = input.item;
    if (item.kind !== 'grant')
        return null;
    if (item.op !== 'added' && item.op !== 'removed' && item.op !== 'changed')
        return null;
    const grantId = grantIdOf(item.changeId);
    const parsed = grantDefs(defs);
    const regenerate = [];
    const materialize = [];
    const seenRegen = new Set();
    const seenMat = new Set();
    const takeRegen = (unit) => {
        if (unit)
            remember(regenerate, seenRegen, unit);
    };
    const takeMat = (unit) => {
        if (unit)
            remember(materialize, seenMat, unit);
    };
    if (item.op === 'added') {
        for (const def of parsed) {
            const unit = sharedUnit(def);
            takeRegen(unit);
            takeMat(unit);
        }
        if (materialize.length === 0)
            console.info(item.changeId, NO_GRANT_UNIT);
        return computed(item.changeId, sortUnits(materialize), sortUnits(regenerate));
    }
    for (const def of parsed) {
        if (!citesGrant(def.data, grantId))
            continue;
        const shared = sharedUnit(def);
        const controller = controllerUnit(def);
        const unit = shared ?? controller;
        if (!unit)
            continue;
        takeRegen(unit);
        takeMat(unit);
        if (item.op === 'changed' && controller)
            takeMat(requestForPage(parsed, controller.id));
    }
    if (materialize.length === 0)
        console.info(item.changeId, NO_GRANT_UNIT);
    return computed(item.changeId, sortUnits(materialize), sortUnits(regenerate));
}
/** `on` is `<entity>.<operation>`. The operation is the text after the first dot. */
function publishedOn(value) {
    if (typeof value !== 'string')
        return null;
    const dot = value.indexOf('.');
    if (dot <= 0 || dot >= value.length - 1)
        return null;
    return { entity: value.slice(0, dot), operation: value.slice(dot + 1) };
}
function eventDefUnits(defs) {
    const units = [];
    for (const def of grantDefs(defs)) {
        if (def.artifactType !== 'integrationOutbound' || !def.artifactId)
            continue;
        units.push({ kind: 'events', id: def.artifactId, path: def.path });
    }
    return units;
}
function citesPublishedEvent(data, eventId) {
    if (!eventId || !Array.isArray(data.effects))
        return false;
    return data.effects.some(entry => isRecord(entry) && entry.eventId === eventId);
}
function usecasesCitingEvent(defs, eventId) {
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (artifactType !== 'usecase' || !citesPublishedEvent(data, eventId))
            return;
        const id = typeof data.usecaseId === 'string' ? data.usecaseId : '';
        if (id)
            units.push({ kind: 'usecase', id, path: defPath });
    });
    return units;
}
function usecaseForPublishedOn(defs, on) {
    const published = publishedOn(on);
    if (!published)
        return null;
    let found = null;
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (found || artifactType !== 'usecase')
            return;
        const entityId = typeof data.entityId === 'string' ? data.entityId : '';
        if (!sameName(entityId, published.entity))
            return;
        const transitionRef = typeof data.transitionRef === 'string' ? data.transitionRef : '';
        const operation = typeof data.operation === 'string' ? data.operation : '';
        if (transitionRef !== published.operation && operation !== published.operation)
            return;
        const id = typeof data.usecaseId === 'string' ? data.usecaseId : '';
        if (!id)
            return;
        found = { kind: 'usecase', id, path: defPath };
    });
    return found;
}
function integrationEffort(input, defs) {
    const item = input.item;
    if (item.kind === 'inbound')
        return abend(item.changeId, INBOUND_UNHANDLED);
    if (item.kind !== 'outbound')
        return null;
    if (item.op !== 'added' && item.op !== 'removed' && item.op !== 'changed')
        return null;
    const eventId = idAfter(item.changeId, 'outbound:');
    const beforeOn = isRecord(item.before) ? item.before.on : undefined;
    const afterOn = isRecord(item.after) ? item.after.on : undefined;
    const onChanged = item.op === 'changed' && !sameJson(beforeOn, afterOn);
    const needsOperation = item.op === 'added' || onChanged;
    const operation = needsOperation ? usecaseForPublishedOn(defs, afterOn) : null;
    if (needsOperation && !operation)
        console.info(item.changeId, NO_PUBLISHED_OPERATION);
    const includeCiting = item.op !== 'added';
    const regenerateSource = item.op === 'changed' && !onChanged;
    const picked = [];
    const seen = new Set();
    const take = (unit) => {
        remember(picked, seen, unit);
    };
    for (const unit of eventDefUnits(defs))
        take(unit);
    if (includeCiting) {
        for (const unit of usecasesCitingEvent(defs, eventId))
            take(unit);
    }
    if (operation)
        take(operation);
    const units = sortUnits(picked);
    return computed(item.changeId, units, regenerateSource ? [] : units);
}
function lastSegment(path) {
    const dot = path.lastIndexOf('.');
    return dot < 0 ? path : path.slice(dot + 1);
}
/** Whole word: the segment is not part of a longer identifier. */
function citesWholeWord(text, segment) {
    if (!segment)
        return false;
    const escaped = segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^A-Za-z0-9_$])${escaped}([^A-Za-z0-9_$]|$)`).test(text);
}
/** Usecase, entity and request use `kindOf`/`unitId`. A workflow uses `processId`, as `workflowUnits` does. */
function listedUnit(defPath, artifactType, data) {
    if (artifactType === 'workflowProcess') {
        const id = typeof data.processId === 'string' ? data.processId : '';
        return id ? { kind: 'workflow', id, path: defPath } : null;
    }
    const kind = kindOf(artifactType);
    if (!kind)
        return null;
    const id = unitId(artifactType, data);
    return id ? { kind, id, path: defPath } : null;
}
function fieldEffort(input, defs, sources) {
    const item = input.item;
    if (item.kind !== 'field')
        return null;
    const changeClass = fieldClass(item);
    if (!changeClass)
        return null;
    const path = fieldPathOf(item.changeId);
    const entity = item.entity;
    if (!path || !entity)
        return null;
    const found = fieldUnits(defs, entity, path);
    const picked = [];
    const seen = new Set();
    const take = (unit) => {
        if (unit)
            remember(picked, seen, unit);
    };
    const takeAll = (units) => {
        for (const unit of units)
            remember(picked, seen, unit);
    };
    const regen = [];
    const regenSeen = new Set();
    const takeRegen = (unit) => {
        if (unit)
            remember(regen, regenSeen, unit);
    };
    if (changeClass === 'validation') {
        takeAll(found.writers);
        takeAll(found.writeRequests);
    }
    else if (changeClass === 'form') {
        take(found.entity);
        if (found.table && found.citing.some(unit => unit.path === found.table?.path))
            take(found.table);
        take(found.adapter);
        takeAll(found.writers);
        takeAll(found.citing.filter(unit => unit.kind === 'request'));
        takeAll(found.writeRequests);
        const changed = changedAttributeKeys(item) ?? [];
        if (changed.includes('values')) {
            if (found.entity && found.citing.some(unit => unit.path === found.entity?.path))
                takeRegen(found.entity);
            if (found.table && found.citing.some(unit => unit.path === found.table?.path))
                takeRegen(found.table);
        }
        for (const attribute of changed) {
            if (!FORM_ATTRIBUTES.has(attribute) || attribute === 'values')
                continue;
            for (const unit of found.storing(attribute))
                takeRegen(unit);
        }
    }
    else {
        take(found.entity);
        take(found.adapter);
        const tableCites = found.table !== null && found.citing.some(unit => unit.path === found.table?.path);
        if (changeClass === 'added' ? columnPath(path) || tableCites : tableCites)
            take(found.table);
        takeAll(found.writers);
        takeAll(changeClass === 'added' ? found.outputSiblings : found.citing.filter(unit => unit.kind === 'request'));
        for (const unit of picked)
            takeRegen(unit);
        if (changeClass === 'removed' && sources) {
            const segment = lastSegment(path);
            eachDefinition(defs, (defPath, artifactType, data) => {
                const unit = listedUnit(defPath, artifactType, data);
                if (!unit || !citesWholeWord(sources[defPath] ?? '', segment))
                    return;
                remember(picked, seen, unit);
            });
        }
    }
    if (picked.length === 0) {
        console.info(item.changeId, NO_FIELD_UNIT);
        return computed(item.changeId, []);
    }
    return computed(item.changeId, sortUnits(picked), sortUnits(regen));
}
function entityUnitOf(defs, entityId) {
    if (!entityId)
        return null;
    let found = null;
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (found || artifactType !== 'domainEntity')
            return;
        const id = typeof data.entityId === 'string' ? data.entityId : '';
        if (!id || !sameName(id, entityId))
            return;
        found = { kind: 'entity', id: lowerFirst(id), path: defPath };
    });
    return found;
}
/** Citation is the key, not any string that repeats the id (`uses`, `usecaseId`). */
function citesTransitionKey(data, artifactType, transitionId, operationValue, entityId) {
    const walk = (node) => {
        if (Array.isArray(node))
            return node.some(entry => walk(entry));
        if (!isRecord(node))
            return false;
        for (const [key, value] of Object.entries(node)) {
            if (typeof value === 'string') {
                if (key === 'transitionId' && value === transitionId)
                    return true;
                if (key === 'transitionRef' && value === transitionId && artifactType === 'usecase') {
                    const owner = typeof data.entityId === 'string' ? data.entityId : '';
                    if (sameName(owner, entityId))
                        return true;
                }
                if (key === 'operation' && operationValue && value === operationValue)
                    return true;
                continue;
            }
            if (walk(value))
                return true;
        }
        return false;
    };
    return walk(data);
}
function routeUsesUsecase(data, usecaseIds) {
    const requests = Array.isArray(data.requests) ? data.requests : [];
    return requests.some(request => {
        if (!isRecord(request) || !Array.isArray(request.uses))
            return false;
        return request.uses.some(use => typeof use === 'string' && usecaseIds.has(use));
    });
}
function transitionEffort(input, defs) {
    const item = input.item;
    if (item.kind !== 'transition')
        return null;
    if (item.op !== 'added' && item.op !== 'removed' && item.op !== 'changed')
        return null;
    const transitionId = idAfter(item.changeId, 'transition:');
    const entityId = item.entity;
    if (item.op === 'added') {
        const unit = entityUnitOf(defs, entityId);
        const units = unit ? [unit] : [];
        return computed(item.changeId, units, units);
    }
    const operationValue = entityId && transitionId ? `${entityId}.${transitionId}` : '';
    const units = [];
    const seen = new Set();
    const usecaseIds = new Set();
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (!transitionId || !citesTransitionKey(data, artifactType, transitionId, operationValue, entityId))
            return;
        if (artifactType === 'domainEntity') {
            const id = unitId(artifactType, data);
            if (id)
                remember(units, seen, { kind: 'entity', id, path: defPath });
            return;
        }
        if (artifactType === 'usecase') {
            const id = typeof data.usecaseId === 'string' ? data.usecaseId : '';
            if (!id)
                return;
            usecaseIds.add(id);
            remember(units, seen, { kind: 'usecase', id, path: defPath });
            return;
        }
        if (artifactType === 'workflowProcess') {
            const processId = typeof data.processId === 'string' ? data.processId : '';
            if (processId)
                remember(units, seen, { kind: 'workflow', id: processId, path: defPath });
        }
    });
    if (usecaseIds.size > 0) {
        eachDefinition(defs, (defPath, artifactType, data) => {
            if (artifactType !== 'requestService' || !routeUsesUsecase(data, usecaseIds))
                return;
            const pageId = typeof data.pageId === 'string' ? data.pageId : '';
            if (pageId)
                remember(units, seen, { kind: 'request', id: pageId, path: defPath });
        });
    }
    const sorted = sortUnits(units);
    if (sorted.length === 0)
        console.info(item.changeId, NO_TRANSITION_UNIT);
    return computed(item.changeId, sorted, sorted);
}
const PROSE_KEYS = new Set(['title', 'description']);
const JOURNEY_PROSE = new Set(['goal', 'outcome']);
function enumValueEntry(value) {
    if (typeof value === 'string')
        return { code: value, attrs: { value } };
    if (!isRecord(value) || typeof value.value !== 'string')
        return null;
    return { code: value.value, attrs: value };
}
/** Same codes; every differing key on a value is `title` or `description`. */
function enumValuesTextOnly(before, after) {
    if (!Array.isArray(before) || !Array.isArray(after) || before.length !== after.length)
        return false;
    const beforeByCode = new Map();
    const afterByCode = new Map();
    for (const raw of before) {
        const entry = enumValueEntry(raw);
        if (!entry || beforeByCode.has(entry.code))
            return false;
        beforeByCode.set(entry.code, entry.attrs);
    }
    for (const raw of after) {
        const entry = enumValueEntry(raw);
        if (!entry || afterByCode.has(entry.code))
            return false;
        afterByCode.set(entry.code, entry.attrs);
    }
    if (beforeByCode.size !== afterByCode.size)
        return false;
    for (const [code, beforeAttrs] of beforeByCode) {
        const afterAttrs = afterByCode.get(code);
        if (!afterAttrs)
            return false;
        const keys = new Set([...Object.keys(beforeAttrs), ...Object.keys(afterAttrs)]);
        for (const key of keys) {
            if (sameJson(beforeAttrs[key], afterAttrs[key]))
                continue;
            if (!PROSE_KEYS.has(key))
                return false;
        }
    }
    return true;
}
/**
 * `changed` of any kind except `rule` whose every difference is prose.
 * Prose is `title` and `description`. A journey or step also treats `goal` and `outcome` as prose.
 * On a journey, `title` inside `index` is prose. On a field, enum labels with the same codes are prose.
 * No difference counts as prose.
 */
function proseOnlyChange(item) {
    if (item.op !== 'changed' || item.kind === 'rule')
        return false;
    if (!isRecord(item.before) || !isRecord(item.after))
        return false;
    const keys = new Set([...Object.keys(item.before), ...Object.keys(item.after)]);
    for (const key of keys) {
        if (sameJson(item.before[key], item.after[key]))
            continue;
        if (item.kind === 'journey' && key === 'index') {
            if (!sameJson(indexWithoutTitle(item.before[key]), indexWithoutTitle(item.after[key])))
                return false;
            continue;
        }
        if (item.kind === 'field' && key === 'values') {
            if (!enumValuesTextOnly(item.before[key], item.after[key]))
                return false;
            continue;
        }
        if (PROSE_KEYS.has(key))
            continue;
        if ((item.kind === 'journey' || item.kind === 'step') && JOURNEY_PROSE.has(key))
            continue;
        return false;
    }
    return true;
}
function stringIds(value) {
    if (!Array.isArray(value))
        return null;
    const ids = [];
    for (const entry of value) {
        if (typeof entry !== 'string')
            return null;
        ids.push(entry);
    }
    return ids;
}
function wholeTextEquals(value, id) {
    if (typeof value === 'string')
        return value === id;
    if (Array.isArray(value))
        return value.some(entry => wholeTextEquals(entry, id));
    if (!isRecord(value))
        return false;
    return Object.values(value).some(child => wholeTextEquals(child, id));
}
function unitsCitingText(defs, id) {
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (!id || !wholeTextEquals(data, id))
            return;
        if (artifactType === 'domainEntity') {
            const entityId = typeof data.entityId === 'string' ? data.entityId : '';
            if (entityId)
                units.push({ kind: 'entity', id: lowerFirst(entityId), path: defPath });
            return;
        }
        if (artifactType === 'usecase') {
            const usecaseId = typeof data.usecaseId === 'string' ? data.usecaseId : '';
            if (usecaseId)
                units.push({ kind: 'usecase', id: usecaseId, path: defPath });
            return;
        }
        if (artifactType === 'requestService') {
            const pageId = typeof data.pageId === 'string' ? data.pageId : '';
            if (pageId)
                units.push({ kind: 'request', id: pageId, path: defPath });
            return;
        }
        if (artifactType === 'workflowProcess') {
            const processId = typeof data.processId === 'string' ? data.processId : '';
            if (processId)
                units.push({ kind: 'workflow', id: processId, path: defPath });
        }
    });
    return units;
}
function entityUnhandled(changeId, key) {
    return abend(changeId, `entity ${idAfter(changeId, 'entity:')} changed in ${key}; not handled yet`);
}
/** `entity` `changed`, one answer per attribute. `added` and `removed` stay on the kind path. */
function entityEffort(input, defs) {
    const item = input.item;
    if (item.kind !== 'entity' || item.op !== 'changed')
        return null;
    if (!isRecord(item.before) || !isRecord(item.after))
        return entityUnhandled(item.changeId, 'shape');
    const keys = changedAttributeKeys(item) ?? [];
    const picked = [];
    const seen = new Set();
    for (const key of keys) {
        if (key === 'title' || key === 'description')
            continue;
        if (key === 'rules') {
            const beforeIds = stringIds(item.before.rules ?? []);
            const afterIds = stringIds(item.after.rules ?? []);
            if (!beforeIds || !afterIds)
                return entityUnhandled(item.changeId, key);
            const staying = new Set(afterIds);
            for (const ruleId of beforeIds) {
                if (staying.has(ruleId))
                    continue;
                for (const unit of citingUnits(defs, ruleId))
                    remember(picked, seen, unit);
            }
            continue;
        }
        if (key === 'capabilities') {
            const beforeCaps = item.before.capabilities === undefined ? {} : item.before.capabilities;
            const afterCaps = item.after.capabilities === undefined ? {} : item.after.capabilities;
            if (!isRecord(beforeCaps) || !isRecord(afterCaps))
                return entityUnhandled(item.changeId, key);
            const capKeys = new Set([...Object.keys(beforeCaps), ...Object.keys(afterCaps)]);
            for (const capId of capKeys) {
                const beforeHas = Object.prototype.hasOwnProperty.call(beforeCaps, capId);
                const afterHas = Object.prototype.hasOwnProperty.call(afterCaps, capId);
                if (beforeHas && afterHas) {
                    const was = beforeCaps[capId];
                    const now = afterCaps[capId];
                    if (sameJson(was, now))
                        continue;
                    // A capability value is its sentence. A new sentence for an id that stays is prose.
                    if (typeof was === 'string' && typeof now === 'string')
                        continue;
                    return entityUnhandled(item.changeId, key);
                }
                for (const unit of unitsCitingText(defs, capId))
                    remember(picked, seen, unit);
            }
            continue;
        }
        return entityUnhandled(item.changeId, key);
    }
    const units = sortUnits(picked);
    if (units.length === 0) {
        console.info(item.changeId);
        return computed(item.changeId, []);
    }
    return computed(item.changeId, units, units);
}
function pagesCitingRule(contracts, ruleId) {
    if (!contracts || !ruleId)
        return [];
    const pages = [];
    for (const [pageId, source] of Object.entries(contracts)) {
        try {
            const parsed = parseD2ContractV2(source);
            if (parsed.routes.some(route => route.rules.includes(ruleId))) {
                pages.push(parsed.pageId || pageId);
            }
        }
        catch (error) {
            console.error(`describeEffort: unreadable L2 contract ${pageId}`, error);
        }
    }
    return [...new Set(pages)].sort();
}
function pageUnitsForRule(moduleName, defs, pages) {
    const listed = grantDefs(defs);
    const units = [];
    for (const pageId of pages) {
        units.push(requestForPage(listed, pageId) ?? {
            kind: 'request',
            id: pageId,
            path: `l1/${moduleName}/layer_2_application/requests/${pageId}.defs.ts`,
        });
        const controller = listed.map(controllerUnit).find(unit => unit?.id === pageId) ?? null;
        units.push(controller ?? {
            kind: 'controller',
            id: pageId,
            path: `l1/${moduleName}/layer_1_external/adapters/http/controllers/${pageId}.defs.ts`,
        });
    }
    return sortUnits(units);
}
function ruleAddedFromContracts(input, defs, contracts) {
    if (input.item.kind !== 'rule' || input.item.op !== 'added')
        return null;
    const pages = pagesCitingRule(contracts, ruleIdOf(input.item));
    if (pages.length === 0)
        return null;
    const units = pageUnitsForRule(input.module, defs, pages);
    return computed(input.item.changeId, units, units, [], []);
}
/** Pure. `defs` maps each product def path to its `.defs.ts` source. `sources` maps the same path to the sibling `.ts` text; omitted keeps the previous answer. `contracts` maps pageId to L2 contract source. */
export function describeEffortFrom(input, defs, sources, contracts) {
    const item = input.item.changeId;
    if (input.item.kind === 'inbound')
        return abend(item, INBOUND_UNHANDLED);
    if (proseOnlyChange(input.item)) {
        console.info(item);
        return computed(item, []);
    }
    if (Object.keys(defs).length === 0)
        return abend(item, NO_DEFS);
    const entity = entityEffort(input, defs);
    if (entity)
        return entity;
    const { kind, op } = input.item;
    const fromContracts = ruleAddedFromContracts(input, defs, contracts);
    if (fromContracts)
        return fromContracts;
    if (kind === 'rule' && op === 'changed') {
        const units = citingUnits(defs, ruleIdOf(input.item));
        if (units.length === 0)
            return abend(item, NONE_APPLY);
        return computed(item, units);
    }
    if (kind === 'rule' && op === 'removed') {
        const units = citingUnits(defs, ruleIdOf(input.item));
        return computed(item, units, units);
    }
    if (kind === 'process' && op === 'removed') {
        const units = workflowUnits(defs, idAfter(item, 'process:'));
        return computed(item, [], [], units);
    }
    if (kind === 'process' && op === 'changed') {
        const units = workflowUnits(defs, idAfter(item, 'process:'));
        if (units.length === 0)
            console.info(item, NO_WORKFLOW_UNIT);
        return computed(item, units, units);
    }
    if (kind === 'task' && (op === 'added' || op === 'changed' || op === 'removed')) {
        const units = workflowUnits(defs, taskProcessId(item));
        if (units.length === 0)
            console.info(item, NO_WORKFLOW_UNIT);
        return computed(item, units, units);
    }
    const transition = transitionEffort(input, defs);
    if (transition)
        return transition;
    const field = fieldEffort(input, defs, sources);
    if (field)
        return field;
    const grant = grantEffort(input, defs);
    if (grant)
        return grant;
    const journey = journeyEffort(input, defs);
    if (journey)
        return journey;
    const integration = integrationEffort(input, defs);
    if (integration)
        return integration;
    return abend(item, `kind/op fora da v1: ${kind} ${op}`);
}
function contractPageId(file, moduleName) {
    const appProject = typeof mls.actualProject === 'number' ? mls.actualProject : Number.NaN;
    if (Number(file.project) !== appProject || Number(file.level) !== 2)
        return null;
    if (file.status === 'deleted' || file.extension !== '.defs.ts' || !file.shortName)
        return null;
    if (String(file.folder || '') !== `${moduleName}/web/contracts`)
        return null;
    return file.shortName;
}
function productPath(file, moduleName, extension = '.defs.ts') {
    const appProject = typeof mls.actualProject === 'number' ? mls.actualProject : Number.NaN;
    if (Number(file.project) !== appProject || Number(file.level) !== 1)
        return null;
    if (file.status === 'deleted' || file.extension !== extension || !file.shortName)
        return null;
    const folder = String(file.folder || '');
    const prefix = `${moduleName}/`;
    if (folder !== moduleName && !folder.startsWith(prefix))
        return null;
    const parts = folder.split('/');
    if (parts.includes('pipeline') || parts.includes('materialization'))
        return null;
    return `l1/${folder}/${file.shortName}${extension}`;
}
function siblingSourcePath(defPath) {
    return defPath.endsWith('.defs.ts') ? `${defPath.slice(0, -'.defs.ts'.length)}.ts` : '';
}
async function readStorText(file, defPath) {
    if (file.getValueInfo) {
        try {
            const local = await file.getValueInfo();
            if (typeof local?.content === 'string')
                return local.content;
        }
        catch (error) {
            console.warn(`describeEffort: ${defPath}`, error);
        }
    }
    if (!file.getContent)
        return '';
    const content = await file.getContent();
    return typeof content === 'string' ? content : '';
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((entry) => typeof entry === 'string');
}
function catalogOf(defs) {
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (artifactType === 'usecase') {
            const id = unitId(artifactType, data);
            if (!id)
                return;
            units.push({
                kind: 'usecase',
                id,
                path: defPath,
                lines: [
                    `usecase ${id} entity=${typeof data.entityId === 'string' ? data.entityId : ''} operation=${typeof data.operation === 'string' ? data.operation : ''} rules=${JSON.stringify(stringList(data.rulesApplied))}`,
                ],
            });
            return;
        }
        if (artifactType === 'domainEntity') {
            const id = unitId(artifactType, data);
            if (!id)
                return;
            units.push({
                kind: 'entity',
                id,
                path: defPath,
                lines: [`entity ${id} invariants=${JSON.stringify(data.invariants ?? [])}`],
            });
            return;
        }
        if (artifactType === 'requestService') {
            const id = unitId(artifactType, data);
            if (!id)
                return;
            const requests = Array.isArray(data.requests) ? data.requests : [];
            const routes = requests.filter(isRecord).map(request => {
                const route = typeof request.route === 'string' ? request.route : '';
                return `route ${route} rules=${JSON.stringify(request.rules ?? [])}`;
            });
            units.push({ kind: 'request', id, path: defPath, lines: [`request ${id}`, ...routes] });
            return;
        }
        if (artifactType === 'workflowProcess' && typeof data.processId === 'string' && data.processId) {
            units.push({ kind: 'workflow', id: data.processId, path: defPath, lines: [`workflow ${data.processId}`] });
        }
    });
    return units.sort((a, b) => a.kind.localeCompare(b.kind) || a.id.localeCompare(b.id));
}
function rulePhrase(item) {
    const after = isRecord(item.after) ? item.after : {};
    const description = typeof after.description === 'string' ? after.description : '';
    return { id: ruleIdOf(item), description };
}
function effortSchema(units) {
    const usecases = units.filter(unit => unit.kind === 'usecase').map(unit => unit.id);
    return {
        type: 'object',
        additionalProperties: false,
        required: ['existing', 'reason'],
        properties: {
            existing: {
                type: 'array',
                items: {
                    type: 'object',
                    additionalProperties: false,
                    required: ['usecase'],
                    properties: {
                        usecase: { type: 'string', enum: usecases },
                    },
                },
            },
            reason: { type: 'string' },
        },
    };
}
const LADDER = [
    "A rule about data that an operation writes is guaranteed in that operation's usecase: pick it (existing). The requests that call it follow.",
    'New routes or usecases are not chosen here: they come from the page contract.',
    'Nothing on the backend only for a rule about display alone; then say why in reason.',
].join('\n');
/** Pure. A prompt only for `rule added`; every other item is null and `describeEffort` answers it. Null when an L2 contract route already cites the rule. */
export function effortPromptFrom(input, defs, contracts) {
    if (input.item.kind !== 'rule' || input.item.op !== 'added')
        return null;
    if (pagesCitingRule(contracts, ruleIdOf(input.item)).length > 0)
        return null;
    const units = catalogOf(defs);
    const rule = rulePhrase(input.item);
    const body = units.flatMap(unit => unit.lines);
    const prompt = [
        `Rule ${rule.id}: ${rule.description}`,
        'Units:',
        ...body,
        LADDER,
    ].join('\n');
    return { prompt, schema: effortSchema(units) };
}
const OUTSIDE_SCHEMA = 'answer outside the schema';
const EMPTY_NEEDS_REASON = 'empty answer for a new rule needs a reason';
function schemaFailure(value, units) {
    if (!isRecord(value))
        return OUTSIDE_SCHEMA;
    const keys = Object.keys(value).sort();
    if (keys.join(',') !== 'existing,reason')
        return OUTSIDE_SCHEMA;
    if (typeof value.reason !== 'string')
        return OUTSIDE_SCHEMA;
    if (!Array.isArray(value.existing))
        return OUTSIDE_SCHEMA;
    const usecases = new Set(units.filter(unit => unit.kind === 'usecase').map(unit => unit.id));
    for (const entry of value.existing) {
        if (!isRecord(entry) || Object.keys(entry).sort().join(',') !== 'usecase')
            return OUTSIDE_SCHEMA;
        if (typeof entry.usecase !== 'string' || !usecases.has(entry.usecase)) {
            return `unknown usecase: ${typeof entry.usecase === 'string' ? entry.usecase : ''}`;
        }
    }
    if (value.existing.length === 0 && value.reason.trim() === '')
        return EMPTY_NEEDS_REASON;
    return null;
}
/** Requests whose some route `uses` cites `usecaseId`. */
function requestsUsing(defs, usecaseId) {
    const units = [];
    eachDefinition(defs, (defPath, artifactType, data) => {
        if (artifactType !== 'requestService')
            return;
        const id = unitId(artifactType, data);
        if (!id)
            return;
        const requests = Array.isArray(data.requests) ? data.requests : [];
        const cites = requests.some(request => isRecord(request) && Array.isArray(request.uses) && request.uses.includes(usecaseId));
        if (cites)
            units.push({ kind: 'request', id, path: defPath });
    });
    return units;
}
/** Pure. Checks the model output and builds the effort answer. A bad shape abends; it is never "nothing to do". */
export function finishEffortFrom(input, defs, modelOutput, contracts) {
    const item = input.item.changeId;
    if (input.item.kind !== 'rule' || input.item.op !== 'added') {
        return abend(item, `kind/op fora da v1: ${input.item.kind} ${input.item.op}`);
    }
    const fromContracts = ruleAddedFromContracts(input, defs, contracts);
    if (fromContracts)
        return fromContracts;
    const units = catalogOf(defs);
    const invalid = schemaFailure(modelOutput, units);
    if (invalid)
        return abend(item, invalid);
    const output = modelOutput;
    const byKey = new Map(units.map(unit => [`${unit.kind}:${unit.id}`, unit]));
    const regenerate = [];
    const seen = new Set();
    const remember = (unit) => {
        const key = `${unit.kind}:${unit.id}`;
        if (seen.has(key))
            return;
        seen.add(key);
        regenerate.push(unit);
    };
    for (const choice of output.existing) {
        const unit = byKey.get(`usecase:${choice.usecase}`);
        if (!unit)
            return abend(item, `unknown usecase: ${choice.usecase}`);
        remember({ kind: 'usecase', id: choice.usecase, path: unit.path });
        for (const request of requestsUsing(defs, choice.usecase))
            remember(request);
    }
    if (output.existing.length === 0)
        console.info(item, output.reason);
    const existingUnits = sortUnits(regenerate);
    return computed(item, existingUnits, existingUnits, [], []);
}
async function loadModuleFiles(moduleName, extension) {
    const files = (mls.stor?.files ?? {});
    const texts = {};
    for (const file of Object.values(files)) {
        if (!file)
            continue;
        const path = productPath(file, moduleName, extension);
        if (!path)
            continue;
        const source = await readStorText(file, path);
        if (source)
            texts[path] = source;
    }
    return texts;
}
async function loadModuleDefs(moduleName) {
    return loadModuleFiles(moduleName, '.defs.ts');
}
/** L2 page contracts under `l2/<module>/web/contracts/`, keyed by pageId. */
async function loadModuleContracts(moduleName) {
    const files = (mls.stor?.files ?? {});
    const texts = {};
    for (const file of Object.values(files)) {
        if (!file)
            continue;
        const pageId = contractPageId(file, moduleName);
        if (!pageId)
            continue;
        const source = await readStorText(file, `l2/${moduleName}/web/contracts/${pageId}.defs.ts`);
        if (source)
            texts[pageId] = source;
    }
    return texts;
}
/** Sibling `.ts` of each def, keyed by the `.defs.ts` path. A missing sibling is an empty string. */
async function loadModuleSources(moduleName, defs) {
    const texts = await loadModuleFiles(moduleName, '.ts');
    const sources = {};
    for (const defPath of Object.keys(defs)) {
        sources[defPath] = texts[siblingSourcePath(defPath)] ?? '';
    }
    return sources;
}
/** Reads product `.defs.ts` under `l1/<module>/` from `mls.stor.files` and classifies the item. */
export async function describeEffort(input) {
    const defs = await loadModuleDefs(input.module);
    return describeEffortFrom(input, defs, await loadModuleSources(input.module, defs), await loadModuleContracts(input.module));
}
/** Same read as `describeEffort`. Null unless the item is `rule added`. */
export async function effortPrompt(input) {
    const defs = await loadModuleDefs(input.module);
    return effortPromptFrom(input, defs, await loadModuleContracts(input.module));
}
/** Same read as `describeEffort`, then `finishEffortFrom`. */
export async function finishEffort(input, modelOutput) {
    const defs = await loadModuleDefs(input.module);
    return finishEffortFrom(input, defs, modelOutput, await loadModuleContracts(input.module));
}
