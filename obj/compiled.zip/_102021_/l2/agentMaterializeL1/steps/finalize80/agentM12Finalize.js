/// <mls fileReference="_102021_/l2/agentMaterializeL1/steps/finalize80/agentM12Finalize.ts" enhancement="_blank"/>
import { SERVE_ROUTE_NO_PAGE_TEST } from '/_102021_/l2/agentMaterializeL1/steps/tests60/context.js';
import { M12_FINALIZE_AGENT_NAME, M12_LAYERS, clip, errorText, parseM12StepInvocation } from '/_102021_/l2/agentMaterializeL1/helpers/m12Core.js';
import { addM12Step, m12Result, updateM12Status } from '/_102021_/l2/agentMaterializeL1/helpers/m12Intents.js';
import { readJsonOptional, readUnitStatus, writeJson } from '/_102021_/l2/agentMaterializeL1/helpers/m12Io.js';
import { registrationFile, reportFile } from '/_102021_/l2/agentMaterializeL1/helpers/m12Names.js';
import { loadRun } from '/_102021_/l2/agentMaterializeL1/helpers/m12Phase.js';
import { registersModule } from '/_102021_/l2/agentMaterializeL1/helpers/m12Units.js';
export function createAgent() {
    return { agentName: M12_FINALIZE_AGENT_NAME, agentProject: 102021, agentFolder: 'agentMaterializeL1/steps/finalize80', agentDescription: 'Report every unit of the run from its status file', visibility: 'private', beforePromptStep };
}
export const M12_REPORT_VERSION = '2026-10-05-m12-report-v1';
function isServeSkip(item) {
    return item.status === 'skipped' && item.code === SERVE_ROUTE_NO_PAGE_TEST;
}
export function buildM12Report(project, moduleName, units, missing, defProblems, registration) {
    const counts = { done: 0, reused: 0, blocked: 0, gap: 0, failed: 0, skipped: 0 };
    const byLayer = {};
    for (const unit of units) {
        counts[unit.status] += 1;
        const layer = byLayer[unit.layer] ?? {};
        layer[unit.status] = (layer[unit.status] ?? 0) + 1;
        byLayer[unit.layer] = layer;
    }
    const open = units
        .filter(unit => unit.status !== 'done' && unit.status !== 'reused')
        .map(unit => ({ layer: unit.layer, unitId: unit.unitId, status: unit.status, code: unit.code, diagnostic: clip(unit.diagnostic, 600) }));
    // A connection serve route has no page test: that declared skip is not an open item, same as a platform gap.
    const clean = open.every(item => item.status === 'gap' || isServeSkip(item)) && missing.length === 0 && defProblems.length === 0;
    const notCompiled = units.filter(unit => (unit.status === 'done' || unit.status === 'reused') && unit.code === 'COMPILE_UNAVAILABLE_L1').map(unit => `${unit.layer}/${unit.unitId}`);
    const serveNotTested = open.filter(isServeSkip).map(item => `${item.layer}/${item.unitId}`);
    return { schemaVersion: M12_REPORT_VERSION, project, moduleName, status: clean ? 'complete' : 'partial', counts, byLayer, open, notCompiled, serveNotTested, missing: [...missing], defProblems, registration, createdAt: new Date().toISOString() };
}
export function summarizeM12Report(report) {
    const lines = [
        `agentMaterializeL1 ${report.moduleName} (project ${report.project}): ${report.status}${report.serveNotTested.length ? `, ${report.serveNotTested.length} serve unit(s) with no test` : ''}.`,
        `done ${report.counts.done}, reused ${report.counts.reused}, blocked ${report.counts.blocked}, gap ${report.counts.gap}, failed ${report.counts.failed}, skipped ${report.counts.skipped}.`,
    ];
    for (const layer of M12_LAYERS) {
        const row = report.byLayer[layer];
        if (row)
            lines.push(`- ${layer}: ${Object.entries(row).map(([state, count]) => `${state} ${count}`).join(', ')}`);
    }
    const notGenerated = report.open.filter(item => !isServeSkip(item));
    if (notGenerated.length) {
        lines.push('', 'Not generated:');
        for (const item of notGenerated)
            lines.push(`- ${item.layer}/${item.unitId}: ${item.status} ${item.code} — ${clip(item.diagnostic, 240)}`);
    }
    if (report.serveNotTested.length)
        lines.push('', `Serve units with no test (SERVE_ROUTE_NO_PAGE_TEST): ${report.serveNotTested.join(', ')}. The monitor tests pages; nothing runs these routes.`);
    if (report.notCompiled.length)
        lines.push('', `Generated, not proven by a compiler (COMPILE_UNAVAILABLE_L1): ${report.notCompiled.length} unit(s).`);
    if (report.missing.length)
        lines.push('', `No status for: ${report.missing.join(', ')}`);
    if (report.defProblems.length)
        lines.push('', 'Defs not planned:', ...report.defProblems.map(item => `- ${item.defRef}: ${item.code} ${clip(item.detail, 200)}`));
    if (report.registration)
        lines.push('', `l5 registration: ${clip(report.registration.detail, 600)}`);
    return lines.join('\n');
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const run = parseM12StepInvocation(args || step.prompt || '', Number(mls.actualProject || 0));
    if (run.kind === 'refusal')
        return [updateM12Status(context, parentStep, step, hookSequential, 'failed', run.diagnostic)];
    try {
        const { project, module: moduleName } = run;
        const { selected, problems } = await loadRun(run);
        const units = [];
        const missing = [];
        const read = async (layer, unitId) => {
            const status = await readUnitStatus(project, moduleName, layer, unitId);
            if (status)
                units.push(status);
            else
                missing.push(`${layer}/${unitId}`);
        };
        // Only the units this run selected: a dependency from an earlier run is not reported again.
        for (const unit of selected)
            await read(unit.layer, unit.unitId);
        for (const unit of selected.filter(item => item.layer === 'controllers'))
            await read('tests', String(unit.definition.data.pageId ?? unit.unitId));
        // The module workflow engine is proved by the workflows phase (prepareWorkflows, d1_196): its outcome is a unit of the report.
        if (selected.some(item => item.layer === 'workflows')) {
            const engine = await readUnitStatus(project, moduleName, 'workflows', 'engine');
            if (engine)
                units.push(engine);
        }
        const registration = registersModule(run, moduleName)
            ? await readJsonOptional(registrationFile(project, moduleName))
            : null;
        const report = buildM12Report(project, moduleName, units, missing, problems, registration ? { action: registration.action, detail: registration.detail } : null);
        await writeJson(reportFile(project, moduleName), { ...report, scope: run.scope, target: run.target, force: run.force });
        const summary = clip(summarizeM12Report(report), 6000);
        return [
            addM12Step(context, parentStep.stepId, m12Result('Materialization report', summary, 'finalize80-report')),
            updateM12Status(context, parentStep, step, hookSequential, 'completed', `Report: ${report.status}`),
        ];
    }
    catch (error) {
        return [updateM12Status(context, parentStep, step, hookSequential, 'failed', clip(errorText(error)))];
    }
}
