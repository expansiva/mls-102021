/// <mls fileReference="_102021_/l2/agentMaterializeL1/steps/requests50/context.ts" enhancement="_blank"/>
// What the model sees to write the request service (BFF) of one page: the contract (routes, JSDoc, types,
// rules, access), the request-service def, the recipe attempt, the generated usecases it may call, the rule
// texts and the platform signatures.
import { isRecord } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { systemIdentity } from '/_102021_/l2/helpers/l1Defs/disclosure.js';
import { requestsObjectBodies } from '/_102021_/l2/agentMaterializeL1/helpers/codeScan.js';
import { catalogOperations } from '/_102021_/l2/agentMaterializeL1/emitters/connectionCatalog.js';
import { resolveInputType } from '/_102021_/l2/agentMaterializeL1/emitters/typeResolve.js';
import { PLATFORM_FILES } from '/_102021_/l2/agentMaterializeL1/emitters/context.js';
import { recordFieldFromGrant, recordFieldsFromGrant, scopeJoins } from '/_102021_/l2/agentMaterializeL1/emitters/emit.js';
import { gatewayBypassProblems, importSpecifiers, moduleGatewayNames, repositoryPortNames, repositoryProblems, usesNodeBuiltin } from '/_102021_/l2/agentMaterializeL1/helpers/m12Gates.js';
import { moduleMdmLinksSection } from '/_102021_/l2/agentMaterializeL1/helpers/m12MdmLinks.js';
import { readOptional } from '/_102021_/l2/agentMaterializeL1/helpers/m12Io.js';
import { contractFile, fileRef, infoOfRef, rulesFile } from '/_102021_/l2/agentMaterializeL1/helpers/m12Names.js';
import { moduleSpecifier, workflowFile } from '/_102021_/l2/agentMaterializeL1/emitters/workflowEmit.js';
import { routeChildWrites } from '/_102021_/l2/agentMaterializeL1/emitters/processPorts.js';
import { recipeDraft } from '/_102021_/l2/agentMaterializeL1/helpers/m12Materialize.js';
import { readNotApplicable } from '/_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits.js';
import { MDM_FACADE_REF, MDM_MODULE_REF, MDM_ONTOLOGY_REF, exportSignatures, mdmContextSection, mdmPlatformApiSection, ruleTexts, sessionCompanyAnchor } from '/_102021_/l2/agentMaterializeL1/steps/usecases40/context.js';
import { contractRoutes } from '/_102021_/l2/agentMaterializeL1/steps/tests60/context.js';
import { REGISTRATION_REF, onboardingModuleId, registrationAccessSection } from '/_102021_/l2/agentMaterializeL1/steps/workflows45/context.js';
import { catalogFilePath, catalogImportPath } from '/_102020_/l2/helpers/connections/catalogPath.js';
import { enumMapProblems, enumMapSection, externalEnumPairs, unpairedProblems } from '/_102021_/l2/agentMaterializeL1/helpers/externalEnums.js';
export const M12_REQUEST_TOOL = 'writeRequestService';
export const M12_REQUEST_TOOL_DESCRIPTION = 'Return the whole request service TypeScript file of the page, and the listed rules that do not apply to it';
function section(title, body) {
    return `## ${title}\n\n${body.trim()}\n`;
}
/** Prompt copy of the request def: no route `doc` (the contract already has it), and `{ field, path }` as one text when the two are the same. */
function requestPromptData(data) {
    const copy = JSON.parse(JSON.stringify(data));
    if (!Array.isArray(copy.requests))
        return copy;
    copy.requests = copy.requests.map(row => {
        if (!isRecord(row))
            return row;
        const next = { ...row };
        delete next.doc;
        if (next.output !== undefined)
            next.output = compactOutputFields(next.output);
        return next;
    });
    return copy;
}
/** An output field entry whose `field` equals `path` (and is not `unresolved`) is that text. Anything else is walked as it is. */
function compactOutputFields(value) {
    if (Array.isArray(value))
        return value.map(compactOutputFields);
    if (!isRecord(value))
        return value;
    const keys = Object.keys(value);
    if (keys.length === 2 && keys.includes('field') && keys.includes('path') && typeof value.field === 'string' && typeof value.path === 'string') {
        if (value.field !== 'unresolved' && value.field === value.path)
            return value.field;
        return { field: value.field, path: value.path };
    }
    const next = {};
    for (const [key, child] of Object.entries(value))
        next[key] = compactOutputFields(child);
    return next;
}
/** Entities the routes touch: `entity` on each output block, plus `entityId` of each cited usecase. Compared without case. */
function routeEntities(data, usecases) {
    const names = new Set();
    const rows = Array.isArray(data.requests) ? data.requests.filter(isRecord) : [];
    for (const row of rows)
        collectEntities(row.output, names);
    for (const item of usecases) {
        const entityId = String(item.definition.data.entityId ?? '');
        if (entityId)
            names.add(entityId.toLowerCase());
    }
    return names;
}
function collectEntities(value, names) {
    if (Array.isArray(value)) {
        for (const item of value)
            collectEntities(item, names);
        return;
    }
    if (!isRecord(value))
        return;
    if (typeof value.entity === 'string' && value.entity)
        names.add(value.entity.toLowerCase());
    for (const child of Object.values(value))
        collectEntities(child, names);
}
function fence(lang, text) {
    return `\`\`\`${lang}\n${text.trim()}\n\`\`\``;
}
/** Keys a route file never reads: the usecase owns capabilities, transitions and lifecycle. */
const ONTOLOGY_KEYS_DROPPED = ['capabilities', 'transitions', 'lifecycleStates'];
/** Problems shown in one repair prompt. The receipt keeps the full list. */
const REPAIR_PROBLEM_LIMIT = 4000;
/** Compact ontology for the prompt: the record minus the three keys a route does not read. Null when the file is not a JSON record. */
function ontologyForPrompt(source) {
    const match = /=\s*(\{[\s\S]*\})\s*as const/.exec(source);
    if (!match) {
        console.warn('ontology record is not JSON: no object before `as const`');
        return null;
    }
    let value;
    try {
        value = JSON.parse(match[1]);
    }
    catch (error) {
        console.warn(`ontology record is not JSON: ${error instanceof Error ? error.message : String(error)}`);
        return null;
    }
    if (!isRecord(value))
        return null;
    const copy = { ...value };
    for (const key of ONTOLOGY_KEYS_DROPPED)
        delete copy[key];
    return ['This is the ontology of the entity.', fence('json', JSON.stringify(copy))].join('\n\n');
}
/** The problem list of one repair prompt, at most REPAIR_PROBLEM_LIMIT characters, plus a count of what was left out. */
function repairProblemText(problems) {
    const kept = [];
    let used = 0;
    let index = 0;
    for (; index < problems.length; index += 1) {
        const line = `- ${problems[index]}`;
        const next = used + (kept.length > 0 ? 1 : 0) + line.length;
        if (next > REPAIR_PROBLEM_LIMIT)
            break;
        kept.push(line);
        used = next;
    }
    // One problem longer than the limit still shows, cut, instead of an empty list.
    if (kept.length === 0 && problems.length > 0) {
        kept.push(`- ${problems[0]}`.slice(0, REPAIR_PROBLEM_LIMIT));
        index = 1;
    }
    const omitted = problems.length - index;
    if (omitted > 0)
        kept.push(`${omitted} more problems omitted`);
    return kept.join('\n');
}
/** MDM entities of the module (`storageTarget: "mdm"`), owned or not. The source `unownedMdmEntities` filters. */
export function moduleMdmEntities(units) {
    return units
        .filter(unit => unit.definition.artifactType === 'domainEntity' && unit.definition.data.storageTarget === 'mdm')
        .map(unit => String(unit.definition.data.entityId ?? unit.definition.artifactId))
        .filter(entityId => entityId.length > 0)
        .map(entityId => ({ entityId, key: entityId[0].toLowerCase() + entityId.slice(1) }));
}
function contractNamesEntity(contractText, entity) {
    return new RegExp(`\\b(?:${entity.key}|${entity.entityId})\\b`, 'u').test(contractText);
}
/** Usecase ids the request def calls: `uses` / `usecaseRef` on each route, and the basename of each dependency. */
function requestCalledUsecaseIds(request) {
    const ids = new Set();
    const rows = Array.isArray(request.data?.requests) ? request.data.requests.filter(isRecord) : [];
    for (const row of rows) {
        if (Array.isArray(row.uses))
            for (const id of row.uses)
                ids.add(String(id));
        if (row.usecaseRef)
            ids.add(String(row.usecaseRef));
    }
    for (const dep of request.dependencies ?? []) {
        const name = dep.split('/').pop()?.replace(/\.defs\.ts$/u, '') ?? '';
        if (name)
            ids.add(name);
    }
    return ids;
}
function usecaseUnitMatches(unit, ids) {
    if (unit.definition.artifactType !== 'usecase')
        return false;
    return [unit.unitId, String(unit.definition.data.usecaseId ?? ''), String(unit.definition.artifactId ?? '')].some(id => id.length > 0 && ids.has(id));
}
/** MDM entities of the module whose usecase the request def calls. */
function mdmEntitiesCalledByRequest(request, units) {
    const ids = requestCalledUsecaseIds(request);
    const entityIds = new Set(units.filter(unit => usecaseUnitMatches(unit, ids)).map(unit => String(unit.definition.data.entityId ?? '')).filter(Boolean));
    return moduleMdmEntities(units).filter(entity => entityIds.has(entity.entityId));
}
/**
 * Platform MDM APIs for a request whose def calls a usecase of an MDM entity. Empty when it calls none, and empty
 * when an unowned MDM entity is named in the contract: that path already includes `mdmContextSection`, which
 * carries the same lines. `request` is the request-service definition (`data` + `dependencies`); without it the
 * callers that still pass only the contract keep the previous filter.
 */
export function mdmPlatformSectionForRequest(contractText, units, ontologySource, facadeSource = null, moduleSource = null, request) {
    const cited = request
        ? mdmEntitiesCalledByRequest(request, units)
        : moduleMdmEntities(units).filter(entity => contractNamesEntity(contractText, entity));
    if (!cited.length)
        return '';
    if (unownedMdmEntities(units).some(entity => contractNamesEntity(contractText, entity)))
        return '';
    return section('The platform APIs for MDM data (source: the platform MDM facade)', mdmPlatformApiSection(ontologySource, facadeSource, moduleSource));
}
/**
 * The MDM entities of the module no usecase owns. inscricaoEvento (15/10): the D1 gave Participante no usecase, the
 * request prompt carried no MDM API, and `inscreverEmEvento` had nothing to write the participant with. Read from
 * the defs only: an entity with `storageTarget: "mdm"` and no usecase whose `entityId` is it.
 */
export function unownedMdmEntities(units) {
    const owned = new Set(units.filter(unit => unit.definition.artifactType === 'usecase').map(unit => String(unit.definition.data.entityId ?? '')));
    const grants = units.filter(unit => unit.definition.artifactType === 'accessScope')
        .flatMap(unit => Array.isArray(unit.definition.data.grants) ? unit.definition.data.grants.filter(isRecord) : []);
    return moduleMdmEntities(units)
        .filter(entity => !owned.has(entity.entityId))
        .map(entity => {
        const entityId = entity.entityId;
        const anchored = grants.filter(grant => grant.scopeMode === 'own' && grant.anchorEntity === entityId);
        const recordField = anchored.map(grant => recordFieldFromGrant(grant)).find(Boolean) ?? '';
        return {
            entityId,
            key: entity.key,
            anchor: anchored.length ? { grantIds: anchored.map(grant => String(grant.grantId ?? '')), recordField } : null,
        };
    });
}
/** The prompt section for the unowned MDM entities a contract names; '' when it names none. */
export function unownedMdmSection(moduleName, entities) {
    if (!entities.length)
        return '';
    const lines = [
        `No usecase of this module reads or writes ${entities.map(entity => entity.entityId).join(', ')}: they are kept in the platform`,
        'MDM, and this request service reads and writes them itself, through `ctx.mdm` (inside a command, through the',
        '`bound` ctx). A usecase that takes their id (a `<entity>Id` of another record) receives it from here.',
    ];
    for (const entity of entities) {
        lines.push('', `${entity.entityId} (\`${entity.key}\` in the contract), MDM type \`'${moduleName}.${entity.entityId}'\`:`);
        if (entity.anchor) {
            const field = entity.anchor.recordField;
            lines.push(`- It is the anchor of the own scope (${entity.anchor.grantIds.join(', ')}): the ${entity.entityId} of a session is the logged`, '  person. Its mdmId is `ctx.sessionContext.actorId`: when the login is found in the MDM the platform replaces the', `  actor id with the person's mdmId (\`ctx.sessionContext.person.mdmId\`)${field ? `, and the controller writes that same value into \`${field}\`` : ''}.`, `  Use it as the id of this ${entity.entityId}${field ? ` and as the \`${field}\` of a record you create` : ''}; never take it from the input and never create`, `  another ${entity.entityId} for the actor. No actorId: \`new AppError('FORBIDDEN_ACTOR', 'You have no identity for this scope.', 403)\`.`);
        }
        lines.push(`- A route whose input carries \`${entity.key}\`: \`ctx.mdm.entity.get({ mdmId })\` (null: \`NOT_FOUND\` 404), then`, '  `ctx.mdm.entity.update({ mdmId, expectedVersion: <the version read>, patch })` with the fields the input carries,', `  flat (below), then \`ctx.mdm.entity.attachRole(mdmId, '${moduleName}.${entity.entityId}')\` so the module finds it.`, `- A route whose output has \`${entity.key}\`: \`get\` it by the id the record carries and build the contract shape from the`, '  flat document the engine returns.');
    }
    return lines.join('\n');
}
/** The grant ids a contract route lists in its `access`. */
export function routeGrantIds(contractText, route) {
    const at = contractText.indexOf(`'${route}':`);
    if (at < 0)
        return [];
    const access = /\baccess\s*:\s*\{([^}]*)\}/u.exec(contractText.slice(at, at + 4000))?.[1] ?? '';
    const grants = /\bgrants\s*:\s*\[([^\]]*)\]/u.exec(access)?.[1] ?? '';
    return [...grants.matchAll(/['"]([A-Za-z0-9_]+)['"]/gu)].map(match => match[1]);
}
/**
 * Who may call each route and what they may see (materializadorL1.md §9 and the own scope per entity). The controller
 * lets in a caller who holds ONE grant of the route; this service decides, by the grants the caller holds, which
 * records belong to them and which fields go back. '' when no route has a grant.
 */
export function accessSection(routes, contractText, grants) {
    const byId = new Map(grants.map(grant => [String(grant.grantId ?? ''), grant]));
    const lines = [];
    let shared = false;
    for (const route of routes) {
        const ids = routeGrantIds(contractText, route.route).filter(id => byId.has(id));
        if (!ids.length)
            continue;
        const actors = new Set(ids.map(id => String(byId.get(id).actorRef ?? '')));
        if (actors.size > 1)
            shared = true;
        lines.push(`- ${route.route}:`);
        for (const id of ids) {
            const grant = byId.get(id);
            const mode = String(grant.scopeMode ?? '');
            const parts = [`${id}: actor \`${String(grant.actorRef ?? '')}\`, scope ${mode}`];
            if (mode === 'own') {
                const direct = Object.entries(recordFieldsFromGrant(grant)).map(([entityId, field]) => `${entityId}.${field} = the caller`);
                const joins = scopeJoins(grant).map(join => `${join.entityId} through ${join.steps.join(', then ')}`);
                if (direct.length)
                    parts.push(`own records: ${direct.join('; ')}`);
                if (joins.length)
                    parts.push(`own by join: ${joins.join('; ')}`);
            }
            const allowed = Array.isArray(grant.allowedFields) ? grant.allowedFields.map(String) : [];
            if (String(grant.disclosure ?? '') === 'fieldsOnly' && allowed.length)
                parts.push(`sees only: ${allowed.join(', ')}`);
            lines.push(`  - ${parts.join('; ')}`);
        }
    }
    if (!lines.length)
        return '';
    return [
        'The controller lets a caller in when they hold ONE grant of the route (the role of the grant is among',
        '`ctx.sessionContext.actorScope`: an item equal to the actor, or ending with `:<actor>`). The caller is',
        '`ctx.sessionContext.actorId`.',
        '- Own scope: when the caller holds only own grants for the route, the records of an entity listed under "own records"',
        '  are theirs when that column equals `ctx.sessionContext.actorId`; an entity "own by join" is theirs when the chain',
        '  reaches the caller (list the records of the first entity that are theirs, keep the ones the chain points to).',
        '  Apply it where the JSDoc says the route works on the caller\'s records; a route whose JSDoc lists public records',
        '  (published events, a catalog) lists them as the JSDoc says. An entity a broader grant the caller also holds',
        '  covers (organization, related) is not narrowed by an own grant.',
        ...(shared ? ['- A route of several roles returns to each caller only what their grants disclose ("sees only"): leave',
            '  out of the output a field none of the caller\'s grants allows, as the contract type permits.'] : []),
        '',
        ...lines,
    ].join('\n');
}
/**
 * The routes of a page whose usecase is an operation of a workflow process (materializadorL1.md §11): the handler of
 * such a route calls the function of the process, which reuses the usecase. The operation of a usecase is
 * `Entidade.<operation>`, or `Entidade.<transitionRef>` for a transition, as the process def lists it.
 */
export function workflowRoutes(units, requestDef, project, moduleName) {
    const processes = units.filter(unit => unit.definition.artifactType === 'workflowProcess');
    if (!processes.length)
        return [];
    const usecaseOperation = new Map();
    for (const unit of units.filter(item => item.definition.artifactType === 'usecase')) {
        const entityId = String(unit.definition.data.entityId ?? '');
        const ops = [String(unit.definition.data.operation ?? ''), String(unit.definition.data.transitionRef ?? '')].filter(Boolean).map(op => `${entityId}.${op}`);
        usecaseOperation.set(unit.unitId, ops);
    }
    const out = [];
    const requests = Array.isArray(requestDef.requests) ? requestDef.requests.filter(isRecord) : [];
    for (const request of requests) {
        const route = String(request.route ?? '');
        for (const usecaseId of Array.isArray(request.uses) ? request.uses.map(String) : []) {
            for (const process of processes) {
                const operations = Array.isArray(process.definition.data.operations) ? process.definition.data.operations.filter(isRecord).map(row => String(row.operation ?? '')) : [];
                const operation = (usecaseOperation.get(usecaseId) ?? []).find(op => operations.includes(op));
                if (!operation)
                    continue;
                const processId = String(process.definition.data.processId ?? process.unitId);
                if (out.some(item => item.route === route && item.processId === processId))
                    continue;
                out.push({ route, processId, operation, specifier: moduleSpecifier(workflowFile(project, moduleName, processId)) });
            }
        }
    }
    return out;
}
/**
 * The serve routes whose message starts a process (d1_206): the L4 trigger `{ kind: 'event', event }` of a process equals the
 * `serves` mark of the route (`<connectionId>.<operationId>`). The route hands the message to the process instead of a
 * usecase, so it reaches the workflow service the same way a route of a page does.
 */
export function eventWorkflowRoutes(units, serves, project, moduleName) {
    const out = [];
    for (const process of units.filter(unit => unit.definition.artifactType === 'workflowProcess')) {
        const trigger = process.definition.data.trigger;
        if (!isRecord(trigger) || trigger.kind !== 'event' || typeof trigger.event !== 'string' || !trigger.event)
            continue;
        const processId = String(process.definition.data.processId ?? process.unitId);
        for (const item of serves.filter(row => row.serves === trigger.event)) {
            out.push({ route: item.route, processId, operation: `event ${trigger.event}`, specifier: moduleSpecifier(workflowFile(project, moduleName, processId)) });
        }
    }
    return out;
}
/** A page whose routes reach a process and a file that never imports its workflow service. */
export function workflowRouteProblems(code, routes) {
    const missing = new Map();
    for (const route of routes)
        if (!code.includes(route.specifier))
            missing.set(route.specifier, [...(missing.get(route.specifier) ?? []), route]);
    return [...missing.entries()].map(([specifier, items]) => `${items.map(item => `${item.route} (${item.operation})`).join(', ')} reach the process ${items[0].processId}: call its function from \`${specifier}\` (it reuses the usecase and keeps the occurrence), not the usecase alone.`);
}
/** The routes of a contract whose input carries one of the unowned MDM entities. */
export function mdmInputRoutes(routes, entities) {
    return routes.flatMap(route => entities
        .filter(entity => route.inputFields.includes(entity.key))
        .map(entity => ({ route: route.route, entityId: entity.entityId, key: entity.key })));
}
/** A route that receives an unowned MDM entity and a file that never writes the MDM. */
export function mdmInputProblems(code, inputs) {
    if (!inputs.length || /\bmdm\.entity\.(?:update|create)\s*\(/u.test(code))
        return [];
    return inputs.map(input => `Route ${input.route} receives \`${input.key}\` (${input.entityId}, kept in the platform MDM, with no usecase): write it with \`ctx.mdm.entity.update\` (see the MDM section), do not drop it.`);
}
const SERVES_MARK = /^([a-z][A-Za-z0-9]*)\.([a-z][A-Za-z0-9]*)$/u;
function connectionCatalogRef(connectionId) {
    return catalogFilePath(connectionId);
}
function serveMarks(data) {
    const requests = Array.isArray(data.requests) ? data.requests.filter(isRecord) : [];
    const out = [];
    for (const row of requests) {
        const mark = SERVES_MARK.exec(String(row.serves ?? ''));
        if (mark)
            out.push({ connectionId: mark[1], operationId: mark[2], row });
    }
    return out;
}
function typeBlocks(source) {
    const starts = [...source.matchAll(/^export\s+(?:interface|type)\s+([A-Za-z_$][\w$]*)\b/gmu)];
    const blocks = new Map();
    for (let index = 0; index < starts.length; index += 1) {
        const from = starts[index].index ?? 0;
        const to = index + 1 < starts.length ? (starts[index + 1].index ?? source.length) : source.length;
        let text = source.slice(from, to);
        const constant = text.search(/\nexport\s+const\b/u);
        if (constant >= 0)
            text = text.slice(0, constant);
        blocks.set(starts[index][1], text.trim());
    }
    return blocks;
}
function citedTypes(source, roots) {
    const blocks = typeBlocks(source);
    const seen = new Set();
    const pending = [...roots];
    const parts = [];
    while (pending.length) {
        const name = pending.pop();
        if (!name || seen.has(name))
            continue;
        seen.add(name);
        const block = blocks.get(name);
        if (!block)
            continue;
        parts.push(block);
        for (const match of block.matchAll(/\b[A-Z][A-Za-z0-9_]*\b/gu)) {
            if (blocks.has(match[0]) && !seen.has(match[0]))
                pending.push(match[0]);
        }
    }
    return parts.join('\n\n');
}
function entityOfServe(row) {
    const refs = Array.isArray(row.entityRefs) ? row.entityRefs.map(String).filter(Boolean) : [];
    const writes = String(row.writes ?? '');
    const wrote = /^([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)$/u.exec(writes);
    return {
        entityId: refs[0] || wrote?.[1] || '',
        effect: typeof row.effect === 'string' && row.effect ? row.effect : (wrote?.[2] ?? ''),
    };
}
function identityField(entity) {
    if (!entity)
        return '';
    const system = systemIdentity(entity.definition);
    if (system)
        return system;
    const storage = isRecord(entity.definition.data.storage) ? entity.definition.data.storage : null;
    if (typeof storage?.idField === 'string')
        return storage.idField;
    return typeof entity.definition.data.idField === 'string' ? entity.definition.data.idField : '';
}
/** A repository port reads one record by id when it has `get(id)`, as the persistence recipe emits. No method list means that recipe. */
function portReadsById(port) {
    const methods = port.definition.data.methods;
    if (!Array.isArray(methods) || methods.length === 0)
        return true;
    return methods.some(method => {
        if (typeof method === 'string')
            return method === 'get';
        if (!isRecord(method) || method.name !== 'get')
            return false;
        const params = Array.isArray(method.params) ? method.params.map(String) : [];
        return params.length === 0 || params.includes('id') || params.length === 1;
    });
}
function requestsTypeOfServe(routes) {
    const fields = routes.map(route => `'${route.route}': (input: ${route.inputType}, ctx: RequestContext) => Promise<${route.outputType}>`);
    return `{ ${fields.join('; ')} }`;
}
async function loadServeRequestContext(ctx, unit, repair) {
    const { project, module: moduleName } = ctx.run;
    const pageId = String(unit.definition.data.pageId ?? unit.unitId);
    const marks = serveMarks(unit.definition.data);
    const header = `/// <mls fileReference="${unit.outputRef}" enhancement="_blank"/>`;
    const byConnection = new Map();
    for (const mark of marks) {
        if (byConnection.has(mark.connectionId))
            continue;
        const text = await ctx.read(connectionCatalogRef(mark.connectionId));
        if (!text)
            throw new Error(`CONNECTION_CATALOG_MISSING: ${connectionCatalogRef(mark.connectionId)}`);
        byConnection.set(mark.connectionId, text);
    }
    const typed = [];
    const catalogSections = [];
    const routes = [];
    for (const mark of marks) {
        const source = byConnection.get(mark.connectionId) ?? '';
        const operations = catalogOperations(source);
        const operation = operations?.find(item => item.operationId === mark.operationId);
        if (!operation || operation.direction !== 'serve') {
            throw new Error(`OPERATION_NOT_IN_CATALOG: ${mark.connectionId}.${mark.operationId} is not a serve operation of the connection catalog.`);
        }
        const route = String(mark.row.route ?? `${moduleName}.${mark.connectionId}.${mark.operationId}`);
        const specifier = catalogImportPath(mark.connectionId);
        typed.push({ route, inputType: operation.inputType, outputType: operation.outputType, specifier });
        routes.push({ route, kind: operation.kind === 'command' ? 'cmd' : 'qry', inputFields: [], actors: [], rules: [] });
        const flags = [
            `kind: ${operation.kind || 'unknown'}`,
            `reply: ${operation.reply || 'unknown'}`,
            `noRowLimit: ${operation.noRowLimit ? 'true' : 'false'}`,
            `hiddenFromAgents: ${operation.hiddenFromAgents ? 'true' : 'false'}`,
        ];
        const description = operation.description;
        catalogSections.push([
            `Operation ${mark.connectionId}.${mark.operationId} of route ${route}.`,
            description,
            flags.join('; '),
            'The input and output types, and the types of this catalog file they cite:',
            fence('ts', citedTypes(source, [operation.inputType, operation.outputType])),
        ].filter(Boolean).join('\n'));
    }
    const contractsInterface = requestsTypeOfServe(typed);
    const catalogSpecifiers = [...new Set(typed.map(item => item.specifier))];
    const parts = [];
    parts.push(section('Task', [
        `Write the request service of the connection routes of module ${moduleName}, file \`${unit.outputRef}\`. There is no page contract.`,
        `It exports \`requests\`, typed exactly \`${contractsInterface}\` with \`import type { ${[...new Set(typed.flatMap(item => [item.inputType, item.outputType]))].sort().join(', ')} } from '${catalogSpecifiers[0] ?? ''}'\`: one async function per route, keyed by the route string.`,
        'Each function takes the whole catalog input and returns the catalog output. Do not drop a field of the input. Do not call fetch, callConnection or any HTTP client.',
        '`ctx.requestMeta.connection` describes the call that reached this route: `connectionId`, `operationId`, `context` (the person is `context.actorMdmId`) and an optional `idempotencyKey`. The type is `requestMeta.connection` on `RequestContext` (`/_102034_/l1/server/layer_2_controllers/contracts.js`). The engine already sets `context.actorMdmId`.',
    ].join('\n')));
    parts.push(section('Connection catalog', catalogSections.join('\n\n')));
    const serveUses = marks.map(mark => ({
        route: String(mark.row.route ?? `${moduleName}.${mark.connectionId}.${mark.operationId}`),
        uses: Array.isArray(mark.row.uses) ? mark.row.uses.map(String).filter(Boolean) : [],
    })).filter(item => item.uses.length > 0);
    if (serveUses.length) {
        const named = new Set(serveUses.flatMap(item => item.uses));
        parts.push(section('Usecases of the routes (the def names them in `uses`: each route calls one of its usecases)', [
            ...serveUses.map(item => `- ${item.route} → ${item.uses.join(', ')}`),
            'The route is the entrance for the connection: it checks the catalog input, calls the usecase with it and returns the catalog output. A route that does not call its usecase does nothing. Throwing `missingUsecase` or returning without the call is wrong.',
        ].join('\n')));
        for (const item of ctx.units.filter(candidate => candidate.definition.artifactType === 'usecase' && named.has(candidate.unitId))) {
            const shown = await usecaseSection(ctx, item, true);
            if (shown)
                parts.push(shown);
        }
    }
    const flows = eventWorkflowRoutes(ctx.units, marks.map(mark => ({
        route: String(mark.row.route ?? `${moduleName}.${mark.connectionId}.${mark.operationId}`),
        serves: `${mark.connectionId}.${mark.operationId}`,
    })), project, moduleName);
    for (const specifier of [...new Set(flows.map(item => item.specifier))]) {
        const items = flows.filter(item => item.specifier === specifier);
        const info = infoOfRef(specifier, project);
        const generated = info ? await readOptional(info) : null;
        parts.push(section(`Workflow service of process ${items[0].processId} (the message of these routes starts it)`, [
            ...items.map(item => `- ${item.route}: ${item.operation}`),
            '',
            `Import from \`${specifier}\`. The route does not call a usecase for this message: it checks the catalog input as above, builds the input of the entry function of the process (the one that opens the occurrence, chosen by its signature and by the l4 prose) from the message, calls it with \`ctx\`, and returns the catalog output. The function owns the occurrence and the writes; the route does not repeat them.`,
            generated ? fence('ts', exportSignatures(generated)) : '(the workflow service was not generated: the phase before this one failed for it)',
        ].join('\n')));
    }
    for (const mark of marks) {
        const target = entityOfServe(mark.row);
        if (target.effect !== 'create' || !target.entityId)
            continue;
        // The process the message starts owns the write and its repeat: no repeat path of the route.
        if (flows.some(flow => flow.route === String(mark.row.route ?? `${moduleName}.${mark.connectionId}.${mark.operationId}`)))
            continue;
        const port = ctx.units.find(item => item.definition.artifactType === 'repositoryPort' && String(item.definition.data.entityId ?? '') === target.entityId);
        if (!port || !portReadsById(port)) {
            throw new Error(`SERVE_READ_BY_ID_MISSING: the port of ${target.entityId} has no get by id, so a creating serve route has no repeat path.`);
        }
        const idField = identityField(ctx.units.find(item => item.definition.artifactType === 'domainEntity' && String(item.definition.data.entityId ?? item.definition.artifactId) === target.entityId));
        const portName = String(port.definition.data.interfaceName ?? port.definition.artifactId);
        const generated = await readOptional(port.output);
        const identity = idField ? `input.${idField}` : 'the input field whose name is the entity storage.idField';
        parts.push(section(`Repeat of ${String(mark.row.route ?? mark.operationId)} (creates ${target.entityId})`, [
            `Read the existing record by id through the entity port before writing: \`resolveRepository<${portName}>(bound, '${portName}')\`, importing the port from \`/${port.outputRef.replace(/\.ts$/u, '.js')}\`.`,
            `The identity comes from the input: \`${identity}\`. Call \`get\` with that id.`,
            'When the record exists, return what is stored and do not overwrite it. When it does not, write through the port with the id set from that same input field and return the output shape this catalog output type uses for a record written now.',
            'The response shape is only what the output type of this operation declares. Repeating the same identity is never an error.',
            generated ? fence('ts', exportSignatures(generated)) : '',
        ].filter(Boolean).join('\n')));
    }
    if (repair) {
        parts.push(section('Repair', [
            'The previous answer was refused. Fix exactly these problems and return the whole file again:',
            repairProblemText(repair.problems),
            repair.previous ? `\nPrevious answer:\n${fence('ts', repair.previous)}` : '',
        ].join('\n')));
    }
    return {
        pageId,
        contractsInterface,
        contractSpecifier: catalogSpecifiers[0] ?? '',
        header,
        routes,
        contractRef: connectionCatalogRef(marks[0]?.connectionId ?? pageId),
        mdmInputs: [],
        workflowRoutes: flows,
        externalEnums: [],
        serveUses,
        human: parts.join('\n'),
    };
}
export async function loadRequestContext(ctx, unit, repair) {
    if (serveMarks(unit.definition.data).length)
        return loadServeRequestContext(ctx, unit, repair);
    const { project, module: moduleName } = ctx.run;
    const pageId = String(unit.definition.data.pageId ?? unit.unitId);
    const contract = contractFile(project, moduleName, pageId);
    const contractRef = fileRef(contract);
    const contractText = await readOptional(contract);
    if (!contractText)
        throw new Error(`CONTRACT_UNREAD: ${contractRef}`);
    const routes = contractRoutes(contractText, moduleName, pageId);
    if (!routes.length)
        throw new Error(`CONTRACT_NO_ROUTES: ${contractRef} has no route of ${moduleName}.${pageId}.`);
    const header = `/// <mls fileReference="${unit.outputRef}" enhancement="_blank"/>`;
    const contractsInterface = /export\s+interface\s+([A-Za-z_][A-Za-z0-9_]*Contracts)\b/u.exec(contractText)?.[1] ?? '';
    if (!contractsInterface)
        throw new Error(`CONTRACT_INTERFACE_MISSING: ${contractRef} has no exported …Contracts interface.`);
    const contractSpecifier = `/${contractRef.replace(/\.defs\.ts$/u, '.defs.js')}`;
    const rulesSource = await readOptional(rulesFile(project, moduleName));
    const rules = ruleTexts(rulesSource, [...new Set(routes.flatMap(route => route.rules))].sort());
    const parts = [];
    parts.push(section('Task', [
        `Write the request service (BFF) of page ${pageId} of module ${moduleName}, file \`${unit.outputRef}\`.`,
        `It exports \`requests\`, typed exactly \`${requestsTypeOf(contractsInterface)}\` with \`import type { ${contractsInterface} } from '${contractSpecifier}'\`: one async function per route of the contract below, keyed by the route string, each returning exactly that route's output type, so the compiler proves the shape. The page controller calls \`requests["<route>"](params, ctx)\` after it checked the grant and the input shape.`,
        'Each function does what its JSDoc says: purpose, input, processing (filters, rules, compositions, calculations) and output, returning exactly the output type of the contract.',
    ].join('\n')));
    parts.push(section(`Contract ${contractRef} (the source of truth)`, fence('ts', contractText)));
    // Compact JSON: the def is a hint and its output tree is the largest section; indented, consultas (agendaClinica)
    // went past M12_PROMPT_LIMIT and was never sent (07/10). The projection is the prompt text only: recipeDraft and
    // the gate keep reading unit.definition. A repair already followed these hints, so it does not repeat the def.
    if (repair) {
        parts.push('The route hints were in the first request; your previous answer already follows them.');
    }
    else {
        parts.push(section(`Request service def ${unit.defRef} (hints: uses, params and the output tree; where they diverge from the contract or the l4, the contract and the l4 win; an empty or unresolved field means "decide by the contract and the l4"). An output entry written as plain text has field equal to path, and the doc of each route is in the contract.`, fence('json', JSON.stringify(requestPromptData(unit.definition.data)))));
    }
    const draft = await recipeDraft(ctx, unit);
    parts.push(section('Recipe attempt', 'source' in draft
        ? ['The deterministic recipe produced this file. Keep what is right; it is a draft, not the answer.', fence('ts', draft.source.slice(0, 16000))].join('\n\n')
        : `The deterministic recipe could not produce this request service: ${draft.refusal.slice(0, 4000)}`));
    if (rules.length)
        parts.push(section('Rules (l4 text)', rules.map(rule => `- ${rule.ruleId}: ${rule.text}`).join('\n')));
    // Signatures of every usecase of the module: a route may call one the def does not name.
    const uses = new Set(Array.isArray(unit.definition.data.requests)
        ? unit.definition.data.requests.filter(isRecord).flatMap(row => Array.isArray(row.uses) ? row.uses.map(String) : [])
        : []);
    const dependencies = new Set(unit.definition.dependencies);
    const cited = ctx.units.filter(item => item.definition.artifactType === 'usecase' && (uses.has(item.unitId) || dependencies.has(item.defRef)));
    const usecases = ctx.units.filter(item => item.definition.artifactType === 'usecase')
        .sort((left, right) => Number(uses.has(right.unitId)) - Number(uses.has(left.unitId)));
    for (const item of usecases) {
        const shown = await usecaseSection(ctx, item, uses.has(item.unitId));
        if (shown)
            parts.push(shown);
    }
    const enumPairs = await externalEnumPairs(ctx, cited);
    const unpaired = unpairedProblems(enumPairs);
    if (unpaired.length)
        throw new Error(unpaired.join(' | '));
    const externalEnums = enumPairs;
    if (externalEnums.length)
        parts.push(section('Enum values of an external entity (source: the L4 of the entity and the catalog)', enumMapSection(externalEnums)));
    const touched = routeEntities(unit.definition.data, cited);
    for (const entity of ctx.units.filter(item => item.definition.artifactType === 'domainEntity' && touched.has(String(item.definition.data.entityId ?? item.definition.artifactId).toLowerCase()))) {
        const ref = `_${project}_/l4/${moduleName}/ontology/${String(entity.definition.data.entityId ?? entity.definition.artifactId)}.defs.ts`;
        const text = await ctx.read(ref);
        // A file that is not the JSON record keeps going as the source text, as before the trimming.
        const ontology = text ? (ontologyForPrompt(text) ?? fence('ts', text.slice(0, 20000))) : null;
        if (ontology)
            parts.push(section(`l4 ontology ${ref} (source)`, ontology));
    }
    parts.push(section('Entities of the module', ctx.units.filter(item => item.definition.artifactType === 'domainEntity').map(item => {
        const fields = Array.isArray(item.definition.data.fields) ? item.definition.data.fields.filter(isRecord).map(field => `${String(field.name ?? '')}${field.derived ? ' (derived)' : ''}`) : [];
        return `- ${String(item.definition.data.entityId ?? item.definition.artifactId)}: ${fields.join(', ')}`;
    }).join('\n')));
    const links = await moduleMdmLinksSection(ctx);
    if (links)
        parts.push(section('Links of the platform MDM (source: the compact keys each link is stored under)', links));
    const scopeGrants = ctx.units.filter(item => item.definition.artifactType === 'accessScope')
        .flatMap(item => Array.isArray(item.definition.data.grants) ? item.definition.data.grants.filter(isRecord) : []);
    // The workflow service of the processes the page reaches (§11): the function of the process, not the usecase.
    const flows = workflowRoutes(ctx.units, unit.definition.data, project, moduleName);
    for (const specifier of [...new Set(flows.map(item => item.specifier))]) {
        const items = flows.filter(item => item.specifier === specifier);
        const info = infoOfRef(specifier, project);
        const generated = info ? await readOptional(info) : null;
        parts.push(section(`Workflow service of process ${items[0].processId} (these routes go through it)`, [
            ...items.map(item => `- ${item.route}: operation ${item.operation}`),
            '',
            `Import from \`${specifier}\`. The handler of each route above calls the function of the process that the l4 prose names for that step (open the occurrence, advance it, reassign who acts): the function reuses the usecase, keeps the Task of the occurrence and decides; this service does not open a Task or call the usecase of that operation on its own. Pass \`ctx\` (or \`bound\` inside a command).`,
            generated ? fence('ts', exportSignatures(generated)) : '(the workflow service was not generated: the phase before this one failed for it)',
        ].join('\n')));
    }
    // The children a route writes with its parent and no usecase writes (the checklist items of a task): through the
    // port of the child, which the run gave the methods they need.
    const childWrites = (await routeChildWrites(ctx.units.map(item => item.declared), ctx.read, project, moduleName))
        .filter(write => routes.some(route => route.route === write.route));
    for (const child of [...new Set(childWrites.map(write => write.child))]) {
        const port = ctx.units.find(item => item.definition.artifactType === 'repositoryPort' && String(item.definition.data.entityId ?? '') === child);
        const entity = ctx.units.find(item => item.definition.artifactType === 'domainEntity' && String(item.definition.data.entityId ?? '') === child);
        if (!port)
            continue;
        const portName = String(port.definition.data.interfaceName ?? '');
        const generated = await readOptional(port.output);
        const entitySource = entity ? await readOptional(entity.output) : null;
        parts.push(section(`${child} written with its parent (no usecase writes it: through its port)`, [
            ...childWrites.filter(write => write.child === child).map(write => `- ${write.route} (${write.parent}.${write.operation}): \`input.${write.inputKey}\` carries the ${child} records; each points to the ${write.parent} by \`${write.foreignKey}\`.`),
            '',
            `Write them inside the command transaction through \`resolveRepository<${portName}>(bound, '${portName}')\`, importing the port from \`/${port.outputRef.replace(/\.ts$/u, '.js')}\` and typing the records with the entity. A new record is a whole entity: \`id: ctx.idGenerator.newId()\`, \`version: 1\`, the \`${childWrites.find(write => write.child === child)?.foreignKey}\` of the parent, the fields the input carries and the initial values of the others. On an edit, the input list is the whole list: list the stored records of the parent, update the ones that come with their id, create the ones without id, delete the ones that are no longer in the list. Never declare a repository type of your own.`,
            generated ? fence('ts', exportSignatures(generated)) : '',
            entitySource ? fence('ts', exportSignatures(entitySource)) : '',
        ].join('\n')));
    }
    const access = accessSection(routes, contractText, scopeGrants);
    if (access)
        parts.push(section('Access of the routes (source: the contract access and the module access scope)', access));
    const unowned = unownedMdmEntities(ctx.units)
        .filter(entity => contractNamesEntity(contractText, entity));
    if (unowned.length) {
        parts.push(section('MDM entities with no usecase (source: the defs and the access scope of the module)', unownedMdmSection(moduleName, unowned)));
        parts.push(section('The platform MDM (source: how the engine stores and returns these entities today)', mdmContextSection(moduleName, await ctx.read(MDM_ONTOLOGY_REF), await ctx.read(MDM_FACADE_REF), [], await ctx.read(MDM_MODULE_REF))));
    }
    else {
        const platformApis = mdmPlatformSectionForRequest(contractText, ctx.units, await ctx.read(MDM_ONTOLOGY_REF), await ctx.read(MDM_FACADE_REF), await ctx.read(MDM_MODULE_REF), unit.definition);
        if (platformApis)
            parts.push(platformApis);
    }
    for (const ref of [PLATFORM_FILES.requestContext, PLATFORM_FILES.repositoryRegistry]) {
        const text = await ctx.read(ref);
        if (text)
            parts.push(section(`Platform ${ref}`, [`Import from \`/${ref.replace(/\.ts$/u, '.js')}\`.`, fence('ts', exportSignatures(text))].join('\n\n')));
    }
    const l5Config = await ctx.read(`_${project}_/l5/config.json`);
    const companyAnchor = sessionCompanyAnchor(moduleName, l5Config, ctx.units.map(item => String(item.definition.data.entityId ?? '')));
    if (companyAnchor)
        parts.push(companyAnchor);
    if (onboardingModuleId(l5Config) === moduleName) {
        parts.push(registrationAccessSection(moduleName, l5Config, await ctx.read(REGISTRATION_REF)));
    }
    if (repair) {
        parts.push(section('Repair', [
            'The previous answer was refused. Fix exactly these problems and return the whole file again:',
            repairProblemText(repair.problems),
            repair.previous ? `\nPrevious answer:\n${fence('ts', repair.previous)}` : '',
        ].join('\n')));
    }
    const mdmInputs = mdmInputRoutes(routes, unowned);
    return { pageId, contractsInterface, contractSpecifier, header, routes, contractRef, mdmInputs, workflowRoutes: flows, externalEnums, serveUses: [], human: parts.join('\n') };
}
/**
 * A request that throws away the contract input type: a parameter `input: Record<string, unknown>` (a helper or a
 * route), or the input — or a name taken from it — cast to `Record<…>`. registrarAtendimento did
 * `const rawDetails = input.details; (rawDetails as Record<string, unknown>).attendanceNote` and read a path the
 * contract does not have (`details.details.attendanceNote`); with the contract type the compiler refuses it.
 */
export function untypedInputProblems(code) {
    const problems = [];
    if (/\binput\s*\??\s*:\s*Record\s*</u.test(code)) {
        problems.push('Do not type a parameter `input: Record<string, unknown>`: a route function takes its contract input as `requests` declares it, and a helper takes `<Page>Contracts["<route>"]["input"]` (or the member it needs), so the compiler checks every path you read.');
    }
    const aliases = new Set(['input']);
    for (const match of code.matchAll(/\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=;]+)?=\s*input\b[^;\n]*/gu))
        aliases.add(match[1]);
    const roots = [...aliases].join('|');
    if (new RegExp(`\\b(?:${roots})\\b[\\w$.?\\[\\]'"]*\\s*\\)?\\s+as\\s+Record\\s*<`, 'u').test(code)) {
        problems.push('Do not cast the input (or a value taken from it) to `Record<…>`: read it through its contract type, which says where each field is (the attendance note is `input.details.details.attendanceNote`).');
    }
    return problems;
}
/** The section of one usecase of the module: where to import it, its signatures and its input type resolved. '' when it is not generated. */
async function usecaseSection(ctx, item, named) {
    const generated = await readOptional(item.output);
    if (!generated)
        return '';
    return section(`Usecase ${item.unitId}${named ? ' (named in the def)' : ''}`, [
        `Import from \`/${item.outputRef.replace(/\.ts$/u, '.js')}\`.`,
        fence('ts', exportSignatures(generated)),
        await resolvedInputSection(ctx, generated),
    ].filter(Boolean).join('\n\n'));
}
/** The connection id of a catalog import specifier, only when it is exactly the one `catalogImportPath` gives. */
function catalogIdOf(specifier) {
    const id = /([A-Za-z][A-Za-z0-9]*)\.js$/u.exec(specifier)?.[1] ?? '';
    return id && catalogImportPath(id) === specifier ? id : '';
}
/**
 * d1_199/d1_200/d1_203: the input and the output of a usecase as the compiler sees them. The types of a usecase on a connection
 * only extend the catalog types and name aliases for their unions, so the signature hides the fields and the unions. Each resolved
 * type (aliases, unions, `extends` and the types of other files expanded, depth limited) goes in the same section, by the same
 * resolver. One is shown when something was expanded or not found; a type that already has everything in place adds nothing.
 */
async function resolvedInputSection(ctx, generated) {
    const inputName = /export\s+(?:async\s+)?function\s+\w+\s*\(\s*\w+\s*:\s*([A-Za-z_$][\w$]*)/u.exec(generated)?.[1];
    const outputName = /export\s+(?:async\s+)?function\s+\w+\s*\([^)]*\)\s*:\s*Promise<\s*([A-Za-z_$][\w$]*)\s*>/u.exec(generated)?.[1];
    const readImport = async (specifier) => {
        const id = catalogIdOf(specifier);
        if (id)
            return ctx.read(catalogFilePath(id));
        return specifier.startsWith('/_') ? ctx.read(specifier.replace(/\.js$/u, '.ts')) : null;
    };
    const blocks = [];
    for (const [label, typeName] of [['Input', inputName], ['Output', outputName]]) {
        if (!typeName)
            continue;
        const resolved = await resolveInputType({ entry: generated, typeName, readImport });
        if (!resolved.text || (resolved.expanded === 0 && !resolved.unresolved.length))
            continue;
        blocks.push([
            `${label} type, resolved as the compiler sees it (aliases, unions and extended types expanded; \`(truncated)\` and \`(not resolved)\` mark what was not):`,
            fence('ts', `${typeName} = ${resolved.text}`),
        ].join('\n'));
    }
    return blocks.join('\n\n');
}
/**
 * d1_201/d1_202: a serve route that names usecases in `uses` calls one of them. The body of a route is the property of that key in
 * the object `requests` (found by structure: the type annotation repeats the keys). Only a call counts: a `missingUsecase` throw, a comment or an import does not.
 */
export function serveUsecaseProblems(code, routes) {
    const bodies = requestsObjectBodies(code);
    const problems = [];
    for (const item of routes) {
        const body = bodies.get(item.route) ?? '';
        const calls = item.uses.some(name => new RegExp(`(?<![\\w$.])${name}\\s*\\(`, 'u').test(body));
        if (!calls)
            problems.push(`SERVE_ROUTE_WITHOUT_USECASE_CALL: route ${item.route} must call one of its usecases (${item.uses.join(', ')}) with the catalog input. Throwing \`missingUsecase\`, returning without the call or only importing the usecase does not count.`);
    }
    return problems;
}
/** Problems of a model-written request service. Empty = the gate passes. */
export function requestGate(code, input) {
    const problems = [];
    if ((code.split('\n')[0]?.trim() ?? '') !== input.header)
        problems.push(`The first line must be exactly: ${input.header}`);
    // The declared type may contain `=>` (the type the prompt asks for): match up to the `= {` of the value.
    if (!/export\s+const\s+requests\b[\s\S]{0,400}?=\s*\{/u.test(code))
        problems.push('The file must export `const requests = { … }`, one function per contract route.');
    if (input.contractsInterface?.startsWith('{')) {
        const annotation = /export\s+const\s+requests\s*:\s*([\s\S]*?)\s*=\s*\{/u.exec(code);
        if (annotation?.[1].replace(/\s+/gu, '') !== input.contractsInterface.replace(/\s+/gu, '')) {
            problems.push(`\`requests\` must be typed \`${input.contractsInterface}\`: each serve route takes its catalog input and returns its catalog output.`);
        }
    }
    else if (input.contractsInterface) {
        const contracts = input.contractsInterface;
        const mapped = new RegExp(`export\\s+const\\s+requests\\s*:\\s*\\{\\s*\\[\\s*K\\s+in\\s+keyof\\s+${contracts}\\s*\\]\\s*:\\s*\\(\\s*input\\s*:\\s*${contracts}\\s*\\[\\s*K\\s*\\]\\s*\\[\\s*['"]input['"]\\s*\\][\\s\\S]{0,200}?Promise<\\s*${contracts}\\s*\\[\\s*K\\s*\\]\\s*\\[\\s*['"]output['"]\\s*\\]\\s*>`, 'u');
        if (!mapped.test(code))
            problems.push(`\`requests\` must be typed \`${requestsTypeOf(contracts)}\`: the compiler then proves every route exists, reads its contract input and returns exactly its contract output.`);
    }
    if (/\bas\s+unknown\s+as\b/u.test(code) || /\bas\s+any\b/u.test(code)) {
        problems.push('No `as unknown as` and no `as any`: they hide a wrong shape from the compiler (a list returned as `{}` reached a page that way). Build the value with its type, or convert a field with String()/Number().');
    }
    problems.push(...untypedInputProblems(code));
    if (/\bas\s+Parameters\s*</u.test(code)) {
        problems.push('No `as Parameters<typeof <usecase>>[0]`: it forces the contract input onto the usecase input and hides a field the usecase reads that the contract does not send (createProfissional read `input.details.person` and threw). Build the usecase input field by field from the contract input.');
    }
    for (const route of input.routes) {
        if (!code.includes(`"${route.route}"`) && !code.includes(`'${route.route}'`))
            problems.push(`Route ${route.route} of the contract has no function in requests.`);
        if (route.kind === 'cmd' && !code.includes('runInTransaction'))
            problems.push(`Command ${route.route} must run inside ctx.data.moduleData.runInTransaction (the contract command is atomic).`);
        for (const ruleId of route.rules) {
            if (!input.waived.has(ruleId) && !code.includes(ruleId))
                problems.push(`Rule ${ruleId} of ${route.route} is not applied: name it where it is applied (a ruleId of an AppError, or a comment on the calculation).`);
        }
    }
    const known = new Set(input.routes.map(route => route.route));
    for (const match of code.matchAll(new RegExp(`["'](${input.moduleName}\\.${input.pageId}\\.[A-Za-z0-9_]+)["']\\s*:`, 'gu'))) {
        if (!known.has(match[1]))
            problems.push(`requests has ${match[1]}, which is not a route of the contract.`);
    }
    const ownL1 = `/_${input.project}_/l1/${input.moduleName}/`;
    const ownContracts = `/_${input.project}_/l2/${input.moduleName}/web/contracts/`;
    for (const specifier of importSpecifiers(code)) {
        if (!specifier.startsWith('/') || !specifier.endsWith('.js')) {
            problems.push(`Import "${specifier}" must start with / and end with .js.`);
            continue;
        }
        if (!specifier.startsWith('/_102034_/l1/') && !specifier.startsWith(ownL1) && !specifier.startsWith(ownContracts)) {
            problems.push(`Import "${specifier}" is outside the platform (/_102034_/l1/), this module (${ownL1}) and its contracts (${ownContracts}).`);
        }
    }
    if (usesNodeBuiltin(code))
        problems.push('No node: import.');
    if (/\bfetch\s*\(/u.test(code))
        problems.push('No fetch().');
    problems.push(...gatewayBypassProblems(code));
    if (input.externalEnums?.length)
        problems.push(...enumMapProblems(code, input.externalEnums));
    if (input.serveUses?.length)
        problems.push(...serveUsecaseProblems(code, input.serveUses));
    if (/\blocalStorage\b|\bsessionStorage\b/u.test(code))
        problems.push('No browser storage.');
    if (/catch\s*(\([^)]*\))?\s*\{\s*\}/u.test(code))
        problems.push('No empty catch: an error names its cause.');
    return problems;
}
/**
 * A route rule the request names only in a comment that hands it to a usecase ("createItemComanda enforces
 * itensSomenteEmComandaAberta"). The handoff holds only when that usecase carries the ruleId in its code; the usecase
 * gate then makes it read the record the rule is about. On 06/10 neither side checked the comanda of a launched item.
 */
export async function delegatedRuleProblems(code, ruleIds, readUsecase) {
    const usecases = [...new Set(importSpecifiers(code)
            .filter(specifier => specifier.includes('/layer_2_application/usecases/'))
            .map(specifier => (specifier.split('/').pop() ?? '').replace(/\.js$/u, '')))];
    const problems = [];
    for (const ruleId of ruleIds) {
        if (code.includes(`'${ruleId}'`) || code.includes(`"${ruleId}"`))
            continue;
        const lines = code.split('\n').filter(line => line.includes(ruleId));
        for (const name of usecases.filter(item => lines.some(line => new RegExp(`\\b${item}\\b`, 'u').test(line)))) {
            const source = await readUsecase(name);
            if (source && (source.includes(`'${ruleId}'`) || source.includes(`"${ruleId}"`)))
                continue;
            problems.push(`Rule ${ruleId} is handed to ${name} in a comment, but ${name} does not apply it (no AppError with ruleId '${ruleId}'). Check it here: read the record the rule is about through its usecase and throw an AppError with ruleId '${ruleId}' when it is broken.`);
        }
    }
    return problems;
}
export async function requestAnswerProblems(ctx, unit, code, notApplicable) {
    const data = await loadRequestContext(ctx, unit);
    const ruleIds = [...new Set(data.routes.flatMap(route => route.rules))];
    const waived = readNotApplicable(notApplicable, ruleIds);
    const waivedIds = new Set(waived.items.map(item => item.ruleId));
    const readUsecase = (name) => ctx.read(`_${ctx.run.project}_/l1/${ctx.run.module}/layer_2_application/usecases/${name}.ts`);
    return [
        ...waived.problems,
        ...requestGate(code, { header: data.header, contractsInterface: data.contractsInterface, routes: data.routes, project: ctx.run.project, moduleName: ctx.run.module, pageId: data.pageId, waived: waivedIds, externalEnums: data.externalEnums, serveUses: data.serveUses }),
        ...mdmInputProblems(code, data.mdmInputs),
        ...workflowRouteProblems(code, data.workflowRoutes),
        // A repository the file types for itself compiles and has no such method at run time (minhas_tarefas declared
        // `create`/`delete` for ItemChecklist, whose port has neither: "repo.create is not a function", tarefas 16/10).
        ...repositoryProblems(code, [...repositoryPortNames(ctx.units, item => String(item.definition.data.interfaceName ?? item.definition.artifactId)), ...moduleGatewayNames(ctx.units)], moduleGatewayNames(ctx.units)),
        ...await delegatedRuleProblems(code, ruleIds.filter(ruleId => !waivedIds.has(ruleId)), readUsecase),
    ];
}
/**
 * The type `requests` has: one function per contract route, taking exactly that route's input and returning exactly
 * its output. The input was `Record<string, unknown>` until 07/10: registrarAtendimento read
 * `details.attendanceNote` where the contract sends `details.details.attendanceNote`, and nothing caught it.
 */
export function requestsTypeOf(contractsInterface) {
    return `{ [K in keyof ${contractsInterface}]: (input: ${contractsInterface}[K]['input'], ctx: RequestContext) => Promise<${contractsInterface}[K]['output']> }`;
}
/**
 * The annotation of `requests` is set mechanically to the contract-mapped type (a model kept typing it with the
 * bare `…Contracts` interface, or with `Record<…unknown>`, which hid the output shape from the compiler), and the
 * two type imports it needs are added when missing. Nothing else in the file changes; the compiler proves the
 * result, and a function whose output differs from the contract is a compile error the repair receives.
 */
function namedCatalogTypes(typeLiteral) {
    const skip = new Set(['Promise', 'RequestContext']);
    return [...new Set([...typeLiteral.matchAll(/\b[A-Z][A-Za-z0-9_]*\b/gu)].map(match => match[0]).filter(name => !skip.has(name)))].sort();
}
export function normalizeRequestsTyping(code, contractsInterface, contractSpecifier) {
    const serve = contractsInterface.startsWith('{');
    const mapped = serve ? contractsInterface : requestsTypeOf(contractsInterface);
    let next = code.replace(/(export\s+const\s+requests)\s*:[\s\S]{0,800}?=\s*\{/u, `$1: ${mapped} = {`);
    if (next === code)
        next = code.replace(/(export\s+const\s+requests)\s*=\s*\{/u, `$1: ${mapped} = {`);
    next = next.replace(/\}\s*satisfies\s+[A-Za-z_][A-Za-z0-9_]*\s*;/u, '};');
    const imports = [];
    if (serve) {
        const names = namedCatalogTypes(contractsInterface);
        const present = names.every(name => new RegExp(`import\\s+(?:type\\s+)?\\{[^}]*\\b${name}\\b[^}]*\\}\\s+from`, 'u').test(next));
        if (names.length && !present)
            imports.push(`import type { ${names.join(', ')} } from '${contractSpecifier}';`);
    }
    else if (!new RegExp(`import\\s+(?:type\\s+)?\\{[^}]*\\b${contractsInterface}\\b[^}]*\\}\\s+from`, 'u').test(next))
        imports.push(`import type { ${contractsInterface} } from '${contractSpecifier}';`);
    if (!/import\s+(?:type\s+)?\{[^}]*\bRequestContext\b[^}]*\}\s+from/u.test(next))
        imports.push("import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';");
    if (imports.length) {
        const lines = next.split('\n');
        lines.splice(1, 0, ...imports);
        next = lines.join('\n');
    }
    return next;
}
