/// <mls fileReference="_102021_/l2/agentMaterializeL1/steps/workflows45/context.ts" enhancement="_blank"/>
// What the model sees to write the workflow service of one process (materializadorL1.md §11): the def (trigger,
// occurrence, functions, operations), the l4 prose of each function (the source), the usecases the operations reach,
// the occurrence entity and its port, the module engine, the runtime engine signatures and the record-id rule.
// And the gate of its answer.
import { isRecord } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { PLATFORM_FILES } from '/_102021_/l2/agentMaterializeL1/emitters/context.js';
import { ontologyRef } from '/_102021_/l2/agentMaterializeL1/emitters/emit.js';
import { bindHumanPages, moduleSpecifier, transitionDestinations, workflowEngineFile, workflowEngineSource, workflowTablesFromL4 } from '/_102021_/l2/agentMaterializeL1/emitters/workflowEmit.js';
import { clip } from '/_102021_/l2/agentMaterializeL1/helpers/m12Core.js';
import { compileDiagnostics, compileM12Files, isUnavailable } from '/_102021_/l2/agentMaterializeL1/helpers/m12Compile.js';
import { importSpecifiers, repositoryProblems, usesNodeBuiltin } from '/_102021_/l2/agentMaterializeL1/helpers/m12Gates.js';
import { readOptional, storExists, writeSource } from '/_102021_/l2/agentMaterializeL1/helpers/m12Io.js';
import { fileRef, rulesFile, workflowRecoverForm, workflowRecoverName, workflowWakeHandlerForm, workflowWakeHandlerName } from '/_102021_/l2/agentMaterializeL1/helpers/m12Names.js';
import { dependencyUnits } from '/_102021_/l2/agentMaterializeL1/helpers/m12Materialize.js';
import { M12_CODE_SCHEMA, missingImports } from '/_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits.js';
import { calledFunctions, findFunction, functionSignature, mergeImports, notImplementedFunctions, notImplementedStub, replaceFunction, workflowPhaseOrder, WORKFLOW_NOT_IMPLEMENTED, addHelpers } from '/_102021_/l2/agentMaterializeL1/steps/workflows45/sequence.js';
import { MDM_FACADE_REF, MDM_MODULE_REF, MDM_ONTOLOGY_REF, allRuleIds, citedEntities, entityNames, exportSignatures, mdmContextSection, ruleTexts, usesMdm } from '/_102021_/l2/agentMaterializeL1/steps/usecases40/context.js';
export const M12_WORKFLOW_TOOL = 'writeWorkflowService';
export const M12_WORKFLOW_TOOL_DESCRIPTION = 'Return the whole workflow service TypeScript file of the process';
export const EVALUATE_SCHEDULE_REF = '_102034_/l1/server/layer_2_application/schedule/evaluateSchedule.ts';
/** Public surface of the runtime engine (`/_102034_/l1/workflow/index.js`). */
export const WORKFLOW_INDEX_REF = '_102034_/l1/workflow/index.ts';
/** Call shapes `index.ts` re-exports: open, advance, find, the table and the key. */
export const WORKFLOW_ENGINE_REF = '_102034_/l1/workflow/engine.ts';
export const WORKFLOW_CONTRACTS_REF = '_102034_/l1/workflow/contracts.ts';
/** `occurrenceRecordId` and `createOccurrenceContext` (the first `newId` is the record). */
export const WORKFLOW_RECORD_ID_REF = '_102034_/l1/workflow/occurrenceRecordId.ts';
/** Platform access-request read API. The screen resolves; this module only reads. */
export const REGISTRATION_REF = '_102034_/l1/mdm/registration.ts';
function section(title, body) {
    return `## ${title}\n\n${body.trim()}\n`;
}
function fence(lang, text) {
    return `\`\`\`${lang}\n${text.trim()}\n\`\`\``;
}
/** Worker view of the module engine: export signatures, with the whole `transitionTo` (its keys) in place of the collapsed line. */
export function workflowEngineShown(source) {
    const shown = exportSignatures(source).split('\n').filter(line => !/^export const transitionTo\b/u.test(line));
    const literal = transitionToLiteral(source);
    return [...shown, literal].filter(part => part.length > 0).join('\n');
}
function transitionToLiteral(source) {
    const start = source.search(/^export const transitionTo\b/mu);
    if (start < 0)
        return '';
    const marker = 'satisfies Readonly<Record<string, string>>;';
    const satisfies = source.indexOf(marker, start);
    if (satisfies >= 0)
        return source.slice(start, satisfies + marker.length);
    const end = source.indexOf('};', start);
    return end < 0 ? '' : source.slice(start, end + 2);
}
function text(value) {
    return typeof value === 'string' ? value : '';
}
/** `onboarding.moduleId` of a project's `l5/config.json`, or empty when the file has none. */
export function onboardingModuleId(configText) {
    if (!configText)
        return '';
    const config = JSON.parse(configText);
    return typeof config.onboarding?.moduleId === 'string' ? config.onboarding.moduleId : '';
}
/**
 * Export surface of `registration.ts`, read from the source. A union type and a function head span lines;
 * `exportSignatures` stops at the first line, which drops `person.mdmId` and `(ctx, { requestId })`.
 */
export function registrationSignatures(source) {
    const lines = source.split('\n');
    const out = [];
    for (let index = 0; index < lines.length; index += 1) {
        const line = lines[index];
        if (!/^export\s+(?:type|interface|async\s+function|function)\s/u.test(line))
            continue;
        const block = [line];
        const isType = /^export\s+(?:type|interface)\s/u.test(line);
        let depth = (line.match(/\{/gu)?.length ?? 0) - (line.match(/\}/gu)?.length ?? 0);
        while (index + 1 < lines.length && (depth > 0 || (isType ? !lineEnds(block) : !block[block.length - 1].includes('{')))) {
            index += 1;
            block.push(lines[index]);
            depth += (lines[index].match(/\{/gu)?.length ?? 0) - (lines[index].match(/\}/gu)?.length ?? 0);
        }
        const text = block.join('\n');
        out.push(isType ? text : text.replace(/\{\s*$/u, '{ … }'));
    }
    return out.join('\n');
}
function lineEnds(block) {
    return /;\s*$/u.test(block[block.length - 1]);
}
/**
 * The registration read API, only for the onboarding module. The signature is read from `registration.ts`
 * (never a hand copy). Other modules get an empty string.
 */
export function registrationAccessSection(moduleName, configText, registrationSource) {
    const moduleId = onboardingModuleId(configText);
    if (!moduleId || moduleId !== moduleName)
        return '';
    const rules = [
        'Import `readAccessRequestState` from `/_102034_/l1/mdm/registration.js`. `listPendingAccessRequests` needs a person in the session; a process routine does not use it.',
        'Reread the access request with `readAccessRequestState(ctx, { requestId })`. `requestId` is the key of the occurrence. Continue only with `person.mdmId` when the result is `resolved`.',
        'No flag from the frontend and no copy of the request in this module.',
        'The screen resolves the request (`POST /session/registration/resolve`). This code only reads.',
    ];
    if (!registrationSource)
        throw new Error(`${REGISTRATION_REF} not found: the onboarding module ${moduleName} needs the access request read API`);
    return section('Platform access request (source: _102034_/l1/mdm/registration.ts)', [...rules, fence('ts', registrationSignatures(registrationSource))].join('\n\n'));
}
/**
 * Rules every process function follows when it calls the module engine. The engine does the owner action;
 * the function supplies the command and applies the L4 system transition from the returned notice state only.
 */
export function engineUseRules(moduleName, processId) {
    return [
        'Open with `engine.open(ctx, { key, plan, title, firstStep, actorNow, owner, origin, executor, room, message? })`. Advance with `engine.advance(ctx, key, { commandId, expectedRevision, from, to, actorNow, executor, note?, wake?, message? })`. No step table on `advance`. `find` is `engine.find(ctx, key)`.',
        'The function whose L4 prose returns the person of a human step calls `resolveStepPerson(ctx, { actorRef, step, history })` from this module engine and returns that result. `actorRef` and `step` are that step in the engine table; `history` is the `history` of the `find` of the same call. Never return `null` or `\'\'`, never query the MDM on your own and never invent who holds the actor. The helper\'s error is thrown as it is.',
        '`commandId`: from a person, `requestMeta.requestId`; from a routine, `<recordId>:<to>` (the same value on a retry, a different value only for a new command); from a wake, `<taskId>:<step>:<wake.seq>`.',
        '`expectedRevision` is the `revision` of the `find` of the same call. `executor` is `{ kind: \'person\', mdmId }` or `{ kind: \'routine\', name: \'<module>.<processId>.<function>\' }` (here `' + moduleName + '.' + processId + '.<function>`). `title` is the business record by its display field. `origin` is the screen, the channel, or the schedule.',
        'The notice result decides the L4 system transition, only from the state returned (`moduleMessage`, or `noticeState` when the module engine exports it). `sent` → the success transition (in `tarefas`, `concluirAviso`) and `to: \'end\'`. A definitive port error (below) → the failure transition (`falharAviso`, `motivoFalha` with no personal data) and `to: \'end\'`. `pending` or absent → the record stays `pending` and the Task stays on the step. Never a second message and never another `commandId` to repeat the same command.',
        'A notice still `pending` from an earlier run is settled by the next run of the start function, **for that recipient only**: if its message is `sent`, apply the success transition; otherwise apply the failure transition with `motivoFalha` = `NOTICE_DELIVERY_NOT_CONFIRMED`; then that recipient\'s new notice starts. A `sent` that arrives after the failure is only logged. A pending notice of one recipient never blocks another.',
        'A `wait` step requests a wake only when the L4 gives it a time (a deadline, a reminder or a period in the step description or in a rule) and names the function that handles it; `everyMinutes`/`until` come from that text and `routine` is that function. Otherwise the step has no wake: the wait ends by the action of the next step\'s owner. Never invent an interval.',
        '`onTick(ctx, now)` stays the public entry of the schedule. `ctx.clock` agrees with `now`.',
        'Port errors do not open another occurrence. Temporary (`WORKFLOW_CM_BUSY`, `WORKFLOW_CM_TASK_INCOMPLETE`, `WORKFLOW_CM_ROOM_UNAVAILABLE`, `WORKFLOW_IDENTITY_INCOMPLETE`, HTTP 503): the screen receives the error so the person can try again; the routine leaves the notice `pending` for the next execution and does not change the business record. Definitive for the command (`WORKFLOW_CM_REJECTED`, `WORKFLOW_IDENTITY_UNLINKED`, `WORKFLOW_IDENTITY_REMOVED`): the screen receives the error; the routine applies the failure transition with the code as `motivoFalha`.',
    ].join('\n');
}
/** Steps of one l4 process object (the JSON `l4Process` returns). */
export function workflowProcessSteps(processJson) {
    if (!processJson)
        return [];
    let row;
    try {
        row = JSON.parse(processJson);
    }
    catch {
        return [];
    }
    if (!row || typeof row !== 'object')
        return [];
    const wrapped = `export const workflows = ${JSON.stringify({ processes: [row] })} as const;`;
    return workflowTablesFromL4(wrapped)[0]?.steps ?? [];
}
/**
 * Names the process file exports when it has an `llm` step: one wake handler per `llm` step and per periodic
 * `wait`, plus the tick recovery of the process. Empty when the process has no `llm` step.
 */
export function workflowLlmExportNames(processId, steps) {
    if (!steps.some(step => step.kind === 'llm'))
        return [];
    const names = steps
        .filter(step => step.kind === 'llm' || (step.kind === 'wait' && step.wakeMode === 'periodic'))
        .map(step => workflowWakeHandlerName(step.stepId));
    names.push(workflowRecoverName(processId));
    return names;
}
const LLM_SIGNATURES = ['requestLlmStep', 'TaskWorkflowLlmStep', 'TaskOccurrenceLlmResult', 'ModuleWakeEvent', 'WorkflowWakeHandler', 'workflowWakeCommandId', 'registerWorkflowWakeHandler'];
/** Export blocks of a platform file whose text names one of the LLM-step symbols. */
function llmSignatureBlocks(source) {
    if (!source)
        return '';
    const blocks = exportSignatures(source).split(/\n(?=export\s)/u);
    return blocks.filter(block => LLM_SIGNATURES.some(name => block.includes(name))).join('\n');
}
/** `export type Name = …;` through the semicolon that closes it. '' when the file does not declare the alias. */
export function typeAlias(source, name) {
    const match = new RegExp(`export type ${name}\\s*=`, 'u').exec(source);
    if (!match)
        return '';
    let depth = 0;
    let quote = '';
    for (let index = match.index; index < source.length; index += 1) {
        const char = source[index];
        if (quote) {
            if (char === '\\') {
                index += 1;
                continue;
            }
            if (char === quote)
                quote = '';
            continue;
        }
        if (char === '\'' || char === '"' || char === '`') {
            quote = char;
            continue;
        }
        if (char === '(' || char === '{' || char === '[')
            depth += 1;
        if (char === ')' || char === '}' || char === ']')
            depth -= 1;
        if (char === ';' && depth === 0)
            return source.slice(match.index, index + 1);
    }
    return '';
}
/** Stor ref of the file the workflow index re-exports `name` from. '' when the index declares it itself. */
export function reexportRef(indexSource, name) {
    for (const match of indexSource.matchAll(/export type \{([^}]+)\} from '([^']+)'/gu)) {
        const names = match[1].split(',').map(item => item.trim()).filter(Boolean);
        if (!names.includes(name))
            continue;
        const specifier = match[2];
        if (!specifier.startsWith('/') || !specifier.endsWith('.js'))
            return '';
        return specifier.slice(1).replace(/\.js$/u, '.ts');
    }
    return '';
}
/**
 * What the model needs to write an `llm` step. Empty when the process has none.
 * Signatures come from the platform files the index re-exports; the import the file writes is the index.
 * `wakeSignature` is the `WorkflowWakeHandler` alias read from the index (or from the file it re-exports).
 */
export function llmStepSection(processId, steps, sources, wakeSignature = '') {
    const names = workflowLlmExportNames(processId, steps);
    if (!names.length)
        return '';
    const handlers = names.filter(name => name !== workflowRecoverName(processId));
    const handlerSteps = steps.filter(step => step.kind === 'llm' || (step.kind === 'wait' && step.wakeMode === 'periodic'));
    const lines = [
        'This process has an `llm` step. Follow the `llm` bullet of the prompt. Ignore it for a process that has none.',
        `Export ${handlers.map(name => `\`${name}\``).join(', ')} (wake handlers) and \`${workflowRecoverName(processId)}\` (tick recovery). The module tick and the registration import these names.`,
        `Each wake handler is ${handlerSteps.map(step => `\`${workflowWakeHandlerForm(step.stepId)}\``).join(', ')}: the context first, then the event, and assignable to \`WorkflowWakeHandler\` (type below, from \`/_102034_/l1/workflow/index.js\`), which the registration passes it to.`,
        `The recovery is \`${workflowRecoverForm(processId)}\`. The clock is \`ctx.clock\`.`,
        'Import `TaskOccurrenceLlmResult`, `ModuleWakeEvent`, `workflowWakeCommandId` and `registerWorkflowWakeHandler` from `/_102034_/l1/workflow/index.js`. Do not import `/_102036_/`. `requestLlmStep` is `workflowEngine.requestLlmStep(ctx, input: TaskWorkflowLlmStep)`.',
        '`ModuleWakeEvent` fields used here: `eventId`, `taskId`, `stepKey`, `pass`, `kind` (`wake` | `llm-step-finished`), `commandId`, `state`.',
    ];
    const fromSources = sources.map(llmSignatureBlocks).filter(Boolean).join('\n');
    const signature = wakeSignature && !fromSources.includes(wakeSignature) ? wakeSignature : '';
    const signatures = [fromSources, signature].filter(Boolean).join('\n');
    return signatures ? `${lines.join('\n')}\n\n${fence('ts', signatures)}` : lines.join('\n');
}
/**
 * An entity the process only names (not its occurrence, not an operation target) needs its states and transitions
 * (the model guessed them without), not its fields: the generated entity file above already carries those.
 * Anything that does not parse as the ontology object stays whole.
 */
export function citedOntology(source) {
    const start = source.indexOf('= {');
    const end = source.lastIndexOf('} as const');
    if (start < 0 || end < start)
        return source.slice(0, 20000);
    try {
        const root = JSON.parse(source.slice(start + 2, end + 1));
        const kept = {};
        for (const key of ['entityId', 'title', 'lifecycleStates', 'transitions'])
            if (key in root)
                kept[key] = root[key];
        return JSON.stringify(kept, null, 2).slice(0, 20000);
    }
    catch {
        return source.slice(0, 20000);
    }
}
export function workflowFacts(unit) {
    const data = unit.definition.data;
    const trigger = isRecord(data.trigger) ? data.trigger : {};
    return {
        processId: text(data.processId) || unit.unitId,
        trigger: { kind: text(trigger.kind), actorRef: text(trigger.actorRef), event: text(trigger.event), schedule: text(trigger.schedule) },
        occurrence: isRecord(data.occurrence) ? text(data.occurrence.entityId) : '',
        functions: Array.isArray(data.functions) ? data.functions.map(String).filter(Boolean) : [],
        operations: Array.isArray(data.operations)
            ? data.operations.filter(isRecord).map(row => ({ operation: text(row.operation), steps: Array.isArray(row.steps) ? row.steps.map(String) : [] }))
            : [],
    };
}
/** The process `processId` of an l4 workflows source, as JSON text; '' when it is not there. */
export function l4Process(source, processId) {
    if (!source)
        return '';
    const match = /=\s*(\{[\s\S]*\})\s*as const/u.exec(source);
    if (!match)
        return '';
    try {
        const value = JSON.parse(match[1]);
        const found = [];
        const walk = (node) => {
            if (Array.isArray(node)) {
                node.forEach(walk);
                return;
            }
            if (!isRecord(node))
                return;
            if (node.processId === processId)
                found.push(node);
            Object.values(node).forEach(walk);
        };
        walk(value);
        return found.length ? JSON.stringify(found[0], null, 2) : '';
    }
    catch {
        return '';
    }
}
/** The usecase that runs one operation (`Entidade.<op>` or `Entidade.<transição>`), among the units of the module. */
export function operationUsecase(units, operation) {
    const [entityId, op] = operation.split('.');
    return units.find(unit => unit.definition.artifactType === 'usecase'
        && String(unit.definition.data.entityId ?? '') === entityId
        && (String(unit.definition.data.operation ?? '') === op || String(unit.definition.data.transitionRef ?? '') === op));
}
function operationTransitionIds(units) {
    const ids = new Set();
    for (const unit of units) {
        if (unit.definition.artifactType !== 'workflowProcess' || !Array.isArray(unit.definition.data.operations))
            continue;
        for (const row of unit.definition.data.operations.filter(isRecord)) {
            const operation = text(row.operation);
            const id = operation.includes('.') ? operation.slice(operation.lastIndexOf('.') + 1) : operation;
            if (id)
                ids.add(id);
        }
    }
    return ids;
}
/**
 * The module engine (the engine on the cm Task port, the plan of each process, the destination status of each operation),
 * written and compiled before any workflow worker runs. An engine.ts that is already there stays; delete it to regenerate.
 * The lines go to the phase trace.
 */
export async function prepareWorkflows(ctx) {
    const { project, module: moduleName, force } = ctx.run;
    const info = workflowEngineFile(project, moduleName);
    if (!force && storExists(info))
        return ['workflowEngine: kept: exists'];
    const workflows = await ctx.read(`_${project}_/l4/${moduleName}/workflows.defs.ts`);
    const ontologySources = [];
    for (const item of ctx.units) {
        if (item.definition.artifactType !== 'domainEntity')
            continue;
        const source = await ctx.read(ontologyRef(item.definition, item.outputRef));
        if (source)
            ontologySources.push(source);
    }
    const operations = operationTransitionIds(ctx.units);
    let tables = workflowTablesFromL4(workflows);
    const unresolved = [];
    // Shared page defs and the route in l5/config.json are written by the L2 finalize before this step.
    if (tables.some(table => table.steps.some(step => step.kind === 'llm'))) {
        const pages = [];
        for (const ref of sharedPageRefs(project, moduleName)) {
            const source = await ctx.read(ref);
            const pageId = ref.split('/').pop()?.replace(/\.defs\.ts$/u, '') ?? '';
            if (source && pageId)
                pages.push({ pageId, source });
        }
        const bound = bindHumanPages(tables, pages, await ctx.read(`_${project}_/l5/config.json`), moduleName);
        tables = bound.tables;
        unresolved.push(...bound.unresolved);
    }
    const source = workflowEngineSource(project, moduleName, tables, transitionDestinations(ontologySources, operations.size ? operations : undefined));
    const stored = await writeSource(info, source);
    const results = await compileM12Files([{ info, expected: stored.text }], ctx.compiler);
    const unavailable = results.every(result => result.errors.length === 1 && isUnavailable(result.errors[0]));
    const errors = unavailable ? [] : compileDiagnostics(results);
    const written = errors.length ? `workflowEngine: COMPILE_FAILED ${clip(errors.join(' | '), 400)}` : 'workflowEngine: written';
    return [written, ...unresolved.map(item => `PAGE_UNRESOLVED: ${item}`)];
}
/** `l2/<module>/web/shared/<pageId>.defs.ts` present in the stor. */
function sharedPageRefs(project, moduleName) {
    const files = globalThis.mls?.stor?.files;
    if (!files)
        return [];
    const folder = `${moduleName}/web/shared`;
    const refs = [];
    for (const info of Object.values(files)) {
        if (!info || info.status === 'deleted')
            continue;
        if (info.project !== project || info.level !== 2 || info.folder !== folder || info.extension !== '.defs.ts' || !info.shortName)
            continue;
        refs.push(`_${project}_/l2/${folder}/${info.shortName}.defs.ts`);
    }
    return refs.sort();
}
/** One step of the l4 process, with `functionRef` when the task names the function it runs. `WorkflowStepEmit` does not keep that field. */
export function workflowStepFunctionRefs(processJson) {
    const emitted = workflowProcessSteps(processJson);
    if (!processJson)
        return emitted.map(step => ({ stepId: step.stepId }));
    let row;
    try {
        row = JSON.parse(processJson);
    }
    catch {
        return emitted.map(step => ({ stepId: step.stepId }));
    }
    const tasks = isRecord(row) && Array.isArray(row.tasks) ? row.tasks : [];
    const byId = new Map();
    for (const task of tasks) {
        if (!isRecord(task) || typeof task.taskId !== 'string' || typeof task.functionRef !== 'string' || !task.functionRef)
            continue;
        byId.set(task.taskId, task.functionRef);
    }
    return emitted.map(step => {
        const functionRef = byId.get(step.stepId);
        return functionRef ? { stepId: step.stepId, functionRef } : { stepId: step.stepId };
    });
}
/** `word` as a whole identifier in `text` (letters, digits and `_` stay attached). */
function citesWord(text, word) {
    if (!word)
        return false;
    const escaped = word.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&');
    return new RegExp(`(?:^|[^\\p{L}\\p{N}_])${escaped}(?=[^\\p{L}\\p{N}_]|$)`, 'u').test(text);
}
function functionIdsOf(processJson) {
    let row;
    try {
        row = JSON.parse(processJson);
    }
    catch {
        return [];
    }
    if (!isRecord(row) || !Array.isArray(row.functions))
        return [];
    return row.functions.flatMap(item => isRecord(item) && typeof item.functionId === 'string' && item.functionId ? [item.functionId] : []);
}
/**
 * Functions tied to an `llm` step without guessing from the name: a step `functionRef`, or prose that cites the
 * step id as a whole word. Empty when nothing ties — the caller then keeps the section for every function.
 */
function llmLinkedFunctions(processJson, steps) {
    const llmIds = new Set(steps.filter(step => step.kind === 'llm').map(step => step.stepId));
    const linked = new Set();
    for (const ref of workflowStepFunctionRefs(processJson)) {
        if (ref.functionRef && llmIds.has(ref.stepId))
            linked.add(ref.functionRef);
    }
    for (const name of functionIdsOf(processJson)) {
        const prose = functionProse(processJson, name);
        for (const stepId of llmIds) {
            if (citesWord(prose, stepId))
                linked.add(name);
        }
    }
    return linked;
}
/** The llm section stays for this call. With no `llm` step it is already empty. A repair, or no focus, keeps it. */
function includeLlmSection(focus, repair, processId, processJson, steps) {
    if (!steps.some(step => step.kind === 'llm'))
        return false;
    if (!focus || repair)
        return true;
    if (workflowLlmExportNames(processId, steps).includes(focus))
        return true;
    const linked = llmLinkedFunctions(processJson, steps);
    return linked.size === 0 || linked.has(focus);
}
/**
 * Entities this function touches: the occurrence, entities named in its own prose, and entities of operations whose
 * steps the l4 ties to it by `functionRef`. Without `functionRef`, only the occurrence and the prose count.
 */
function touchedEntities(focus, processJson, facts, titles) {
    const touched = new Set();
    if (facts.occurrence)
        touched.add(facts.occurrence);
    for (const entityId of citedEntities(functionProse(processJson, focus), titles))
        touched.add(entityId);
    const ownSteps = new Set(workflowStepFunctionRefs(processJson).filter(row => row.functionRef === focus).map(row => row.stepId));
    for (const operation of facts.operations) {
        if (!operation.steps.some(step => ownSteps.has(step)))
            continue;
        const entityId = operation.operation.split('.')[0];
        if (entityId)
            touched.add(entityId);
    }
    return touched;
}
/** The l4 process with only `focus` left whole in `functions`; every other function keeps `functionId`. */
function focusFunctions(process, focus) {
    let row;
    try {
        row = JSON.parse(process);
    }
    catch {
        return process;
    }
    if (!isRecord(row) || !Array.isArray(row.functions))
        return process;
    row.functions = row.functions.map(item => {
        if (!isRecord(item) || item.functionId === focus)
            return item;
        return { functionId: item.functionId };
    });
    return JSON.stringify(row, null, 2);
}
export async function loadWorkflowContext(ctx, unit, repair, focus) {
    const { project, module: moduleName } = ctx.run;
    const facts = workflowFacts(unit);
    const header = `/// <mls fileReference="${unit.outputRef}" enhancement="_blank"/>`;
    const l4Ref = unit.definition.dependencies.find(ref => ref.endsWith(`/l4/${moduleName}/workflows.defs.ts`)) ?? `_${project}_/l4/${moduleName}/workflows.defs.ts`;
    const readProcess = l4Process(await ctx.read(l4Ref), facts.processId);
    const process = focus ? focusFunctions(readProcess, focus) : readProcess;
    if (!process)
        throw new Error(`PROCESS_UNREAD: ${l4Ref} has no process ${facts.processId}.`);
    const parts = [];
    parts.push(section('Task', [
        `Write the workflow service of process \`${facts.processId}\` of module ${moduleName}, file \`${unit.outputRef}\`.`,
        `It exports one async function per function of the process: ${facts.functions.map(name => `\`${name}\``).join(', ')}, each \`(input, ctx: RequestContext)\`, with its input and output interfaces exported as \`<Function>Input\` / \`<Function>Output\` (PascalCase). What each one receives, checks, writes, tells and returns, and what happens when it runs twice, is the prose of that function in the l4 process below: the source.`,
        facts.trigger.kind === 'scheduled'
            ? `The process is scheduled ("${facts.trigger.schedule}"): also export \`onTick(ctx: RequestContext, now: Date): Promise<void>\`, which asks \`evaluateSchedule\` whether an occurrence is due and, when it is, runs the function that does the scheduled work. The module tick calls it every minute.`
            : `The process is started by ${facts.trigger.kind === 'event' ? `the event ${facts.trigger.event}` : `the actor ${facts.trigger.actorRef || 'of its journeys'}`}: the request service of the page calls these functions.`,
    ].join('\n')));
    parts.push(section(`Definition ${unit.defRef} (the intent: trigger, occurrence, functions, the entity operations the process reaches)`, fence('json', JSON.stringify(unit.declared.data, null, 2))));
    parts.push(section(`l4 process ${facts.processId} (${l4Ref}, the source)`, fence('json', process.slice(0, 30000))));
    // The operations: the usecase each one runs, or none (a system transition the function applies through the port).
    const lines = [];
    for (const row of facts.operations) {
        const usecase = operationUsecase(ctx.units, row.operation);
        lines.push(`- ${row.operation} (${row.steps.join(', ')}): ${usecase ? `usecase \`${usecase.unitId}\`` : 'no usecase: the function applies it through the entity port (POOL_ABSENT)'}`);
    }
    if (lines.length)
        parts.push(section('Operations of the process', lines.join('\n')));
    const mdmUsecase = facts.operations.map(row => operationUsecase(ctx.units, row.operation)).find(usecase => usecase && usesMdm(usecase));
    if (mdmUsecase) {
        parts.push(section('The platform MDM (source: how the engine stores and returns this entity today)', mdmContextSection(moduleName, await ctx.read(MDM_ONTOLOGY_REF), await ctx.read(MDM_FACADE_REF), [], await ctx.read(MDM_MODULE_REF))));
    }
    const sent = new Set();
    for (const dep of dependencyUnits(ctx, unit)) {
        const generated = await readOptional(dep.output);
        if (!generated)
            continue;
        sent.add(dep.defRef);
        parts.push(section(`Usecase ${dep.unitId}`, [`Import from \`/${dep.outputRef.replace(/\.ts$/u, '.js')}\`.`, fence('ts', exportSignatures(generated))].join('\n\n')));
    }
    // The entity of the occurrence and of every operation, with its port: a system transition and the occurrence
    // record are read and written through them. And every entity the prose of the process names: the daily notice
    // reads the open tasks, and without the Tarefa entity the model guessed its states (todo, inProgress).
    // Citations are read on the whole process, so a focused call still sends the signature of an entity another
    // function names. The ontology of an entity this function does not touch is omitted, except on a repair.
    const titles = (await entityNames(ctx)).flatMap(names => [{ entityId: names.entityId, title: names.title }, { entityId: names.entityId, title: names.entityId }]);
    const core = new Set([facts.occurrence, ...facts.operations.map(row => row.operation.split('.')[0])].filter(Boolean));
    const entities = new Set([...core, ...citedEntities(readProcess, titles)]);
    const narrow = Boolean(focus) && !repair;
    const touched = narrow && focus ? touchedEntities(focus, readProcess, facts, titles) : null;
    for (const item of ctx.units) {
        const kind = item.definition.artifactType;
        if ((kind !== 'domainEntity' && kind !== 'repositoryPort') || !entities.has(String(item.definition.data.entityId ?? '')))
            continue;
        const generated = await readOptional(item.output);
        parts.push(section(`${kind} ${item.definition.artifactId}`, [
            `Import from \`/${item.outputRef.replace(/\.ts$/u, '.js')}\`.${kind === 'repositoryPort' ? ` Resolve it with \`resolveRepository<${String(item.definition.data.interfaceName ?? '')}>(ctx, '${String(item.definition.data.interfaceName ?? '')}')\`.` : ''}`,
            generated ? fence('ts', exportSignatures(generated)) : fence('json', JSON.stringify(item.definition.data)),
        ].join('\n\n')));
        if (kind === 'domainEntity') {
            const entityId = String(item.definition.data.entityId ?? '');
            if (touched && !touched.has(entityId))
                continue;
            const ontology = await ctx.read(ontologyRef(item.definition, item.outputRef));
            if (ontology) {
                const cited = !core.has(entityId);
                parts.push(section(`l4 ontology of ${item.definition.artifactId} (source: states, transitions, derived fields)`, fence('ts', cited ? citedOntology(ontology) : ontology.slice(0, 20000))));
            }
        }
    }
    const rulesSource = await readOptional(rulesFile(project, moduleName));
    const rules = ruleTexts(rulesSource, allRuleIds(rulesSource));
    if (rules.length)
        parts.push(section('Rules of the module (l4 text)', rules.map(rule => `- ${rule.ruleId}: ${rule.text}`).join('\n')));
    const adapter = workflowEngineFile(project, moduleName);
    const adapterSource = await readOptional(adapter);
    if (adapterSource)
        parts.push(section('The module engine (one engine per process, the step tables, the destination status of each operation)', [`Import from \`${moduleSpecifier(adapter)}\`. Open and advance through it. \`transitionTo\` is the destination status of each operation. The function that returns the person of a human step calls \`resolveStepPerson\` from this file.`, fence('ts', workflowEngineShown(adapterSource))].join('\n\n')));
    parts.push(section('Occurrence record id', [
        `On creation, \`recordId = occurrenceRecordId(ctx, '${facts.processId}')\` and the create usecase is called with \`createOccurrenceContext(ctx, recordId)\`.`,
        'That context returns the occurrence record id on the first `newId` and delegates every later id to the parent generator. Check, on that usecase, that the record is the first `newId`.',
        'Import `occurrenceRecordId` and `createOccurrenceContext` from `/_102034_/l1/workflow/index.js`. The version of an occurrence is the one the engine stored (the release, or `null`).',
    ].join('\n')));
    parts.push(section('How every process function uses the engine', engineUseRules(moduleName, facts.processId)));
    const processSteps = workflowProcessSteps(readProcess);
    const platform = [WORKFLOW_INDEX_REF, WORKFLOW_ENGINE_REF, WORKFLOW_CONTRACTS_REF, WORKFLOW_RECORD_ID_REF, PLATFORM_FILES.requestContext, PLATFORM_FILES.repositoryRegistry, ...(facts.trigger.kind === 'scheduled' ? [EVALUATE_SCHEDULE_REF] : [])];
    const platformSources = await Promise.all(platform.slice(0, 3).map(ref => ctx.read(ref)));
    const indexSource = platformSources[0] ?? '';
    let wakeSignature = typeAlias(indexSource, 'WorkflowWakeHandler');
    if (!wakeSignature) {
        const ref = reexportRef(indexSource, 'WorkflowWakeHandler');
        wakeSignature = ref ? typeAlias(await ctx.read(ref) ?? '', 'WorkflowWakeHandler') : '';
    }
    const llm = includeLlmSection(focus, repair, facts.processId, readProcess, processSteps)
        ? llmStepSection(facts.processId, processSteps, platformSources, wakeSignature)
        : '';
    if (llm)
        parts.push(section('An llm step', llm));
    for (const ref of platform) {
        const source = await ctx.read(ref);
        if (source)
            parts.push(section(`Platform ${ref}`, [`Import from \`/${ref.replace(/\.ts$/u, '.js')}\`.`, fence('ts', exportSignatures(source))].join('\n\n')));
    }
    const l5Config = await ctx.read(`_${project}_/l5/config.json`);
    if (onboardingModuleId(l5Config) === moduleName) {
        parts.push(registrationAccessSection(moduleName, l5Config, await ctx.read(REGISTRATION_REF)));
    }
    if (repair) {
        parts.push(section('Repair', [
            'The previous answer was refused. Fix exactly these problems and return the whole file again:',
            ...repair.problems.map(problem => `- ${problem}`),
            repair.previous ? `\nPrevious answer:\n${fence('ts', repair.previous)}` : '',
        ].join('\n')));
    }
    return { header, facts, human: parts.join('\n') };
}
/** Transition id → the state it leads to, from the lifecycle of every entity of the module. */
export function transitionTargets(units) {
    const out = new Map();
    for (const unit of units.filter(item => item.definition.artifactType === 'domainEntity')) {
        const lifecycle = unit.definition.data.lifecycle;
        const transitions = isRecord(lifecycle) && Array.isArray(lifecycle.transitions) ? lifecycle.transitions.filter(isRecord) : [];
        for (const transition of transitions) {
            const id = text(transition.transitionId);
            const to = text(transition.to);
            if (id && to)
                out.set(id, to);
        }
    }
    return out;
}
/** The top-level arguments of every `.transition(…)` call: read by brackets and quotes, never by a fixed shape. */
export function transitionCalls(code) {
    const out = [];
    for (const match of code.matchAll(/\.transition\s*\(/gu)) {
        const args = [];
        let depth = 0;
        let quote = '';
        let current = '';
        let at = (match.index ?? 0) + match[0].length;
        for (; at < code.length; at += 1) {
            const char = code[at];
            if (quote) {
                current += char;
                if (char === '\\') {
                    current += code[at + 1] ?? '';
                    at += 1;
                }
                else if (char === quote)
                    quote = '';
                continue;
            }
            if (char === '\'' || char === '"' || char === '`') {
                quote = char;
                current += char;
                continue;
            }
            if (char === '(' || char === '{' || char === '[')
                depth += 1;
            if (char === ')' || char === '}' || char === ']') {
                if (depth === 0)
                    break;
                depth -= 1;
            }
            if (char === ',' && depth === 0) {
                args.push(current.trim());
                current = '';
                continue;
            }
            current += char;
        }
        if (current.trim())
            args.push(current.trim());
        const id = /^['"`]([A-Za-z_$][\w$]*)['"`]$/u.exec(args[args.length - 1] ?? '')?.[1];
        if (id && args.length >= 2)
            out.push({ record: args[0], transitionId: id });
    }
    return out;
}
/**
 * A port `transition(record, '<id>')` whose record never takes the state the transition leads to. The adapter stores
 * the record as given (the id is a label): the daily notice called concluirAviso and stayed `pending` (tarefas, 16/10),
 * first with a variable, then with the object built inside the call. The state must be written on a field
 * (`status: '<to>'`): inside the object when the call builds it, anywhere in the file when it passes a variable. A bare
 * `return '<to>'` is not a write. The states come from the module lifecycles: nothing here names one.
 */
export function workflowTransitionProblems(code, targets) {
    const problems = [];
    const reported = new Set();
    for (const call of transitionCalls(code)) {
        const to = targets.get(call.transitionId);
        if (!to)
            continue;
        const written = new RegExp(`[A-Za-z_$][\\w$]*\\s*:\\s*['"\`]${to}['"\`]`, 'u');
        const scope = call.record.startsWith('{') ? call.record : code;
        if (written.test(scope))
            continue;
        if (reported.has(call.transitionId))
            continue;
        reported.add(call.transitionId);
        problems.push(`Transition ${call.transitionId} leads to '${to}', and the record passed to \`transition(record, '${call.transitionId}')\` never takes that state: set it on the record (\`status: '${to}'\`, with the payload fields). The port stores the record as given.`);
    }
    return problems;
}
/** Problems of a model-written workflow service. Empty = the gate passes. */
export function workflowGate(code, input) {
    const problems = [];
    if (input.targets)
        problems.push(...workflowTransitionProblems(code, input.targets));
    if ((code.split('\n')[0]?.trim() ?? '') !== input.header)
        problems.push(`The first line must be exactly: ${input.header}`);
    for (const name of input.llmExports ?? []) {
        if (!new RegExp(`export\\s+async\\s+function\\s+${name}\\s*\\(`, 'u').test(code))
            problems.push(`The process file must export \`${name}\` (\`export async function ${name}\`).`);
    }
    for (const name of input.facts.functions) {
        if (!new RegExp(`export\\s+async\\s+function\\s+${name}\\s*\\(`, 'u').test(code))
            problems.push(`The process function \`${name}\` must be exported as \`export async function ${name}(input, ctx: RequestContext)\`.`);
    }
    if (input.facts.trigger.kind === 'scheduled') {
        if (!/export\s+async\s+function\s+onTick\s*\(/u.test(code))
            problems.push('A scheduled process exports `onTick(ctx: RequestContext, now: Date): Promise<void>`: the module tick calls it every minute.');
        if (!/\bevaluateSchedule\s*\(/u.test(code))
            problems.push('`onTick` asks `evaluateSchedule(schedule, now, lastRun)` whether an occurrence is due: never a hard-coded hour.');
    }
    if (input.facts.occurrence && !code.includes(moduleSpecifier(workflowEngineFile(input.project, input.moduleName)))) {
        problems.push(`The process keeps an occurrence of ${input.facts.occurrence}: open and advance it through the module engine (${moduleSpecifier(workflowEngineFile(input.project, input.moduleName))}), never in a table of your own.`);
    }
    if (/\bas\s+unknown\s+as\b/u.test(code) || /\bas\s+any\b/u.test(code))
        problems.push('No `as unknown as` and no `as any`.');
    problems.push(...repositoryProblems(code, input.ports));
    const ownL1 = `/_${input.project}_/l1/${input.moduleName}/`;
    for (const specifier of importSpecifiers(code)) {
        if (!specifier.startsWith('/') || !specifier.endsWith('.js')) {
            problems.push(`Import "${specifier}" must start with / and end with .js.`);
            continue;
        }
        if (!specifier.startsWith('/_102034_/l1/') && !specifier.startsWith(ownL1))
            problems.push(`Import "${specifier}" is outside the platform (/_102034_/l1/) and this module (${ownL1}).`);
    }
    if (usesNodeBuiltin(code))
        problems.push('No node: import.');
    if (/\bfetch\s*\(/u.test(code))
        problems.push('No fetch().');
    if (/\blocalStorage\b|\bsessionStorage\b/u.test(code))
        problems.push('No browser storage.');
    if (/catch\s*(\([^)]*\))?\s*\{\s*\}/u.test(code))
        problems.push('No empty catch: an error names its cause.');
    return problems;
}
export async function workflowAnswerProblems(ctx, unit, code, _notApplicable) {
    const facts = workflowFacts(unit);
    const header = `/// <mls fileReference="${unit.outputRef}" enhancement="_blank"/>`;
    const ports = ctx.units.filter(item => item.definition.artifactType === 'repositoryPort').map(item => String(item.definition.data.interfaceName ?? item.definition.artifactId));
    const { project, module: moduleName } = ctx.run;
    const l4Ref = unit.definition.dependencies.find(ref => ref.endsWith(`/l4/${moduleName}/workflows.defs.ts`)) ?? `_${project}_/l4/${moduleName}/workflows.defs.ts`;
    const llmExports = workflowLlmExportNames(facts.processId, workflowProcessSteps(l4Process(await ctx.read(l4Ref), facts.processId)));
    return [
        ...workflowGate(code, { header, facts, project, moduleName, ports, targets: transitionTargets(ctx.units), llmExports }),
        ...await missingImports(ctx, code),
    ];
}
const WORKFLOW_FUNCTION_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    required: ['code', 'notApplicable'],
    properties: {
        code: { type: 'string', description: 'One function, from its comment through the closing brace of `export async function`.' },
        imports: { type: 'array', items: { type: 'string' }, description: 'New import lines this function needs. Omit a line the file already has.' },
        helpers: { type: 'string', description: 'New helper declarations inserted before the first exported function. Empty when none.' },
        notApplicable: {
            type: 'array',
            description: 'Rules listed for this unit that do not apply to it (empty when every rule applies), each with why.',
            items: {
                type: 'object',
                additionalProperties: false,
                required: ['ruleId', 'reason'],
                properties: { ruleId: { type: 'string' }, reason: { type: 'string' } },
            },
        },
    },
};
const ON_TICK_FORM = 'export async function onTick(ctx: RequestContext, now: Date): Promise<void>';
async function readProcess(ctx, unit) {
    const { project, module: moduleName } = ctx.run;
    const l4Ref = unit.definition.dependencies.find(ref => ref.endsWith(`/l4/${moduleName}/workflows.defs.ts`)) ?? `_${project}_/l4/${moduleName}/workflows.defs.ts`;
    return l4Process(await ctx.read(l4Ref), workflowFacts(unit).processId);
}
function functionProse(processJson, name) {
    let row;
    try {
        row = JSON.parse(processJson);
    }
    catch {
        return '';
    }
    if (!isRecord(row) || !Array.isArray(row.functions))
        return '';
    const found = row.functions.find(item => isRecord(item) && item.functionId === name);
    return isRecord(found) && typeof found.description === 'string' ? found.description : '';
}
function fixedForms(processId, steps, scheduled) {
    const forms = [];
    for (const name of workflowLlmExportNames(processId, steps)) {
        const form = name === workflowRecoverName(processId)
            ? workflowRecoverForm(processId)
            : steps.map(step => workflowWakeHandlerForm(step.stepId)).find(item => item.includes(`function ${name}(`)) ?? '';
        if (form)
            forms.push({ name, form });
    }
    if (scheduled)
        forms.push({ name: 'onTick', form: ON_TICK_FORM });
    return forms;
}
function phaseNames(facts, processJson) {
    const steps = workflowProcessSteps(processJson);
    const fixed = fixedForms(facts.processId, steps, facts.trigger.kind === 'scheduled').map(item => item.name);
    return workflowPhaseOrder(facts, workflowStepFunctionRefs(processJson), fixed);
}
function exportHeader(source, name) {
    try {
        const signature = functionSignature(source, name);
        const at = signature.lastIndexOf('export async function');
        if (at < 0)
            return null;
        return signature.slice(at).replace(/\s+/gu, ' ').trim();
    }
    catch {
        return null;
    }
}
function functionTextProblems(code, project, moduleName, targets) {
    const problems = [];
    problems.push(...workflowTransitionProblems(code, targets));
    if (/\bas\s+unknown\s+as\b/u.test(code) || /\bas\s+any\b/u.test(code))
        problems.push('No `as unknown as` and no `as any`.');
    const ownL1 = `/_${project}_/l1/${moduleName}/`;
    for (const specifier of importSpecifiers(code)) {
        if (!specifier.startsWith('/') || !specifier.endsWith('.js')) {
            problems.push(`Import "${specifier}" must start with / and end with .js.`);
            continue;
        }
        if (!specifier.startsWith('/_102034_/l1/') && !specifier.startsWith(ownL1))
            problems.push(`Import "${specifier}" is outside the platform (/_102034_/l1/) and this module (${ownL1}).`);
    }
    if (usesNodeBuiltin(code))
        problems.push('No node: import.');
    if (/\bfetch\s*\(/u.test(code))
        problems.push('No fetch().');
    if (/\blocalStorage\b|\bsessionStorage\b/u.test(code))
        problems.push('No browser storage.');
    if (/catch\s*(\([^)]*\))?\s*\{\s*\}/u.test(code))
        problems.push('No empty catch: an error names its cause.');
    return problems;
}
/** The file so far: every function as a signature, and the full text of `full`. */
function shownAssembled(source, names, full) {
    const present = names.filter(name => findFunction(source, name));
    const first = present.length ? findFunction(source, present[0]) : null;
    const prefix = first ? source.slice(0, first.start).trimEnd() : source.trimEnd();
    const blocks = present.map(name => {
        const span = findFunction(source, name);
        if (!span)
            return '';
        return full.has(name) ? source.slice(span.start, span.end) : functionSignature(source, name);
    }).filter(Boolean);
    return blocks.length ? `${prefix}\n\n${blocks.join('\n\n')}\n` : `${prefix}\n`;
}
export const workflowSequence = {
    async phases(ctx, unit) {
        const facts = workflowFacts(unit);
        return ['skeleton', ...phaseNames(facts, await readProcess(ctx, unit)).map(name => `fn:${name}`)];
    },
    async promptAddendum(ctx, phase) {
        const shortName = phase === 'skeleton' ? 'promptSkeleton' : phase.startsWith('fn:') ? 'promptFunction' : '';
        if (!shortName)
            return '';
        const info = { project: 102021, level: 2, folder: 'agentMaterializeL1/steps/workflows45', shortName, extension: '.md' };
        return (await ctx.read(fileRef(info))) ?? '';
    },
    parameters(phase) {
        return phase === 'skeleton' || phase === 'final' ? M12_CODE_SCHEMA : WORKFLOW_FUNCTION_SCHEMA;
    },
    async context(ctx, unit, phase, assembled, repair) {
        if (phase === 'final')
            return (await loadWorkflowContext(ctx, unit, repair)).human;
        if (phase === 'skeleton') {
            const loaded = await loadWorkflowContext(ctx, unit, repair);
            const processJson = await readProcess(ctx, unit);
            const forms = fixedForms(loaded.facts.processId, workflowProcessSteps(processJson), loaded.facts.trigger.kind === 'scheduled');
            const lines = [
                'This call writes the skeleton only. Declare every function below with that exact header and a body that is only the not-implemented stub. Do not write a real body yet.',
                ...phaseNames(loaded.facts, processJson).map(name => {
                    const form = forms.find(item => item.name === name);
                    return form ? `- \`${name}\`: \`${form.form}\`` : `- \`${name}(input, ctx: RequestContext)\`, stub \`${notImplementedStub(name)}\``;
                }),
            ];
            return `${loaded.human}\n${section('Functions of this skeleton', lines.join('\n'))}`;
        }
        const name = phase.startsWith('fn:') ? phase.slice(3) : '';
        const loaded = await loadWorkflowContext(ctx, unit, repair, name);
        const processJson = await readProcess(ctx, unit);
        const names = phaseNames(loaded.facts, processJson);
        const written = new Set(names.filter(item => findFunction(assembled, item) && !notImplementedFunctions(assembled).includes(item)));
        const called = new Set(calledFunctions(functionProse(processJson, name), names, written));
        return [
            loaded.human,
            section('The file so far', [
                `Write only \`${name}\`. The functions below are signatures, except the ones \`${name}\` calls, which are the whole function. Keep the signature of \`${name}\` exactly as it is here.`,
                fence('ts', shownAssembled(assembled, names, called)),
            ].join('\n\n')),
        ].join('\n');
    },
    async apply(ctx, unit, phase, assembled, payload) {
        const code = typeof payload.code === 'string' ? payload.code : '';
        if (phase === 'final') {
            if (!code.trim())
                return { source: assembled, problems: ['The answer has no code.'] };
            return { source: code.endsWith('\n') ? code : `${code}\n`, problems: [] };
        }
        const facts = workflowFacts(unit);
        const header = `/// <mls fileReference="${unit.outputRef}" enhancement="_blank"/>`;
        const { project, module: moduleName } = ctx.run;
        const processJson = await readProcess(ctx, unit);
        const steps = workflowProcessSteps(processJson);
        if (phase === 'skeleton') {
            const problems = workflowGate(code, {
                header, facts, project, moduleName,
                ports: [],
                llmExports: workflowLlmExportNames(facts.processId, steps),
            });
            for (const item of fixedForms(facts.processId, steps, facts.trigger.kind === 'scheduled')) {
                const got = exportHeader(code, item.name);
                const expected = `${item.form} { … }`.replace(/\s+/gu, ' ');
                if (got !== expected)
                    problems.push(`\`${item.name}\` must be exactly \`${item.form}\`.`);
            }
            problems.push(...await missingImports(ctx, code));
            return { source: code.endsWith('\n') ? code : `${code}\n`, problems };
        }
        const name = phase.startsWith('fn:') ? phase.slice(3) : '';
        const problems = [];
        if (!name || !code.trim())
            problems.push('The answer has no function.');
        const expected = exportHeader(assembled, name);
        const got = code.trim() ? exportHeader(code, name) : null;
        if (expected && got !== expected)
            problems.push(`\`${name}\` must keep the skeleton signature \`${expected}\`.`);
        if (!expected)
            problems.push(`\`${name}\` is not in the skeleton.`);
        if (code.includes(`'${WORKFLOW_NOT_IMPLEMENTED}'`) || code.includes(`"${WORKFLOW_NOT_IMPLEMENTED}"`))
            problems.push(`\`${name}\` still throws ${WORKFLOW_NOT_IMPLEMENTED}.`);
        const importLines = Array.isArray(payload.imports) ? payload.imports.filter((item) => typeof item === 'string') : [];
        const helpers = typeof payload.helpers === 'string' ? payload.helpers : '';
        const snippet = [header, ...importLines, code].join('\n');
        if (name === 'onTick') {
            if (!/export\s+async\s+function\s+onTick\s*\(/u.test(code))
                problems.push('A scheduled process exports `onTick(ctx: RequestContext, now: Date): Promise<void>`.');
            if (!/\bevaluateSchedule\s*\(/u.test(code))
                problems.push('`onTick` asks `evaluateSchedule(schedule, now, lastRun)` whether an occurrence is due: never a hard-coded hour.');
        }
        problems.push(...functionTextProblems(snippet, project, moduleName, transitionTargets(ctx.units)));
        if (problems.length)
            return { source: assembled, problems };
        try {
            const merged = replaceFunction(addHelpers(mergeImports(assembled, importLines), helpers), name, code.endsWith('\n') ? code : `${code}\n`);
            const imports = await missingImports(ctx, merged);
            if (imports.length)
                return { source: assembled, problems: imports };
            return { source: merged, problems: [] };
        }
        catch (error) {
            return { source: assembled, problems: [error instanceof Error ? error.message : String(error)] };
        }
    },
    async finalProblems(ctx, unit, source) {
        const empty = notImplementedFunctions(source).map(name => `Function \`${name}\` is still ${WORKFLOW_NOT_IMPLEMENTED}.`);
        return [...await workflowAnswerProblems(ctx, unit, source, []), ...empty];
    },
};
