/// <mls fileReference="_102021_/l2/agentMaterializeL1/state/maintain.ts" enhancement="_blank"/>
/**
 * Maintenance decisions. The store port in core/state.ts stays frozen.
 * `running` is a receipt stage, never a fifth definition status.
 *
 * Who writes status:
 * - pending: D1, when it creates or changes semantics. M1, when the output is
 *   missing or stale and the old status is not evidence. A stub stays pending.
 * - generated: M1, only after the output file, the receipt and the passing
 *   verifications are already durable.
 * - blocked: M1, when a concrete source or external decision is missing.
 *   The reason is on the receipt. Only dependents of that unit are held.
 * - failed: M1, when the repair budget ends without a passing result.
 *   Resume does not zero that budget and does not repeat the exhausted cycle
 *   until the semantic input changes.
 *
 * Local rename of one file is atomic on one filesystem. The output, the receipt
 * and the definition status are three files, so a crash between them is visible.
 * Studio stor has no compare-and-swap and no multi-file transaction. This module
 * does not claim a remote CAS.
 */
import { generatedAllowsSkip, isRecord, parseDefinitionSource, readDefinition, receiptFolder, semanticHash, } from '/_102021_/l2/agentMaterializeL1/contracts/definition.js';
import { contentHash } from '/_102021_/l2/agentMaterializeL1/core/io.js';
export const M1_RECIPE_VERSION = '2026-09-25-m1-recipe-v1';
export const M1_OWNED_SCHEMA = '2026-09-25-m1-owned-v1';
export const M1_WRITER_SCHEMA = '2026-09-25-m1-writer-v1';
export const WRITE_BOUNDARIES = ['before-promote', 'staging', 'output', 'receipt', 'status'];
const FILE_GAP = new Set(['MISSING_REF', 'CONTEXT_UNREAD', 'MECHANISM_UNBOUND', 'NO_NAMED_HANDLER', 'BLOCKED_BY']);
export function stagingRef(moduleName, outputRef) {
    const marker = `/l1/${moduleName}/`;
    const at = outputRef.indexOf(marker);
    const rest = at >= 0 ? outputRef.slice(at + marker.length) : outputRef.split('/').pop() || 'output.ts';
    return `${receiptFolder(moduleName)}/staging/${rest}`;
}
export function ownedManifestRef(moduleName) {
    return `${receiptFolder(moduleName)}/owned.json`;
}
export function writerRef(moduleName) {
    return `${receiptFolder(moduleName)}/writer.json`;
}
/** Hash a dependency or source. A v2 def hashes the canonical body, so status alone does not cascade. */
export async function hashEvidence(text) {
    const parsed = parseDefinitionSource(text);
    if ('definition' in parsed) {
        const read = readDefinition(parsed.definition);
        if (!('issues' in read))
            return semanticHash(read);
    }
    return contentHash(text);
}
/**
 * Replace the single envelope status and leave every other byte alone.
 * Returns null when the source is not a def or the status field is not unique.
 */
export function replaceStatus(source, status) {
    const parsed = parseDefinitionSource(source);
    if (!('definition' in parsed))
        return null;
    const read = readDefinition(parsed.definition);
    if ('issues' in read)
        return null;
    if (read.status === status)
        return source;
    const pattern = /("status"\s*:\s*")(pending|generated|blocked|failed)(")/g;
    const hits = source.match(pattern);
    if (!hits || hits.length !== 1)
        return null;
    return source.replace(pattern, `$1${status}$3`);
}
export function statusForPromotion(accepted, scaffold) {
    if (!accepted || scaffold)
        return null;
    return 'generated';
}
/**
 * Generated without an intact output is not a skip. Pending forces work.
 * A hand-edited output is a local conflict: dependents are not invalidated by it.
 * A test-only change asks verify. A recipe change asks generate, unless the
 * output was hand-edited, which still wins.
 */
export async function decideMaintenance(input) {
    const receipt = input.receipt;
    const status = input.definition.status;
    const recorded = receipt && input.outputPath ? receipt.outputHashes[input.outputPath] : undefined;
    const hasRecord = typeof recorded === 'string' && recorded.length > 0;
    const outputDrift = input.outputPresent && hasRecord && input.outputHash !== recorded;
    if (status === 'failed' && receipt && !releasedFailure(input, receipt)) {
        const detail = receipt.failures.map(item => item.code).join(', ') || 'definition status is failed.';
        return { action: 'blocked', reason: `STATUS_FAILED: ${detail}` };
    }
    if (status === 'blocked' && receipt?.reason && !releasedBlock(input, receipt)) {
        return { action: 'blocked', reason: `STATUS_BLOCKED: ${receipt.reason}` };
    }
    const recipeDrift = input.recipeVersion !== null && !!receipt && receipt.recipeVersion !== input.recipeVersion;
    const implementGap = input.stage === 'implement'
        && input.hasImplementHandler
        && receipt?.stage !== 'verify';
    const skip = input.outputPresent
        && hasRecord
        && !outputDrift
        && !recipeDrift
        && !implementGap
        && await generatedAllowsSkip(input.definition, receipt, input.dependencyHashes);
    if (skip && (input.verifyOnly || testChanged(input))) {
        return { action: 'verify', reason: 'VERIFY: test change only; implementation receipt is intact.' };
    }
    if (skip) {
        return { action: 'reuse', reason: 'REUSE: receipt matches the semantic hash, dependencies and outputs.' };
    }
    if (outputDrift) {
        const code = recipeDrift || semanticChanged(input) ? 'LOCAL_EDIT' : 'OUTPUT_DRIFT';
        return {
            action: 'conflict',
            reason: `${code}: ${input.outputPath} does not match the receipt; the local file is not overwritten.`,
        };
    }
    if (recipeDrift) {
        return { action: 'generate', reason: `RECIPE_CHANGED: recipe ${input.recipeVersion} does not match the receipt.` };
    }
    const handler = input.hasImplementHandler ? 'implement' : 'structure';
    return {
        action: 'generate',
        reason: `GENERATE: output is not an accepted implementation; handler ${handler}.`,
    };
}
function semanticChanged(input) {
    return !!input.receipt && input.receipt.semanticHash !== input.semantic;
}
function testChanged(input) {
    if (!input.testPath || !input.testHash || !input.receipt)
        return false;
    const recorded = input.receipt.sourceHashes[input.testPath];
    return typeof recorded === 'string' && recorded.length > 0 && recorded !== input.testHash;
}
function releasedFailure(input, receipt) {
    if (receipt.semanticHash !== input.semantic)
        return true;
    return dependencyDrift(input, receipt);
}
function releasedBlock(input, receipt) {
    if (receipt.semanticHash !== input.semantic)
        return true;
    if (dependencyDrift(input, receipt))
        return true;
    const code = receipt.reason.split(':')[0] || '';
    return FILE_GAP.has(code) && input.unresolved.length === 0;
}
function dependencyDrift(input, receipt) {
    const recorded = isRecord(receipt.dependencyHashes) ? receipt.dependencyHashes : {};
    return input.definition.dependencies.some(path => recorded[path] !== input.dependencyHashes[path]);
}
export function selectRemoval(owned, requested) {
    const allowed = new Set(owned);
    const remove = [];
    const keep = [];
    for (const path of requested) {
        if (!path || path.endsWith('/') || !allowed.has(path))
            keep.push(path);
        else
            remove.push(path);
    }
    return { remove, keep };
}
export function parseOwnedManifest(text, moduleName) {
    try {
        const parsed = JSON.parse(text);
        if (parsed.schemaVersion !== M1_OWNED_SCHEMA || parsed.moduleName !== moduleName || !Array.isArray(parsed.units))
            return null;
        return parsed;
    }
    catch {
        return null;
    }
}
export function renderOwnedManifest(manifest) {
    return `${JSON.stringify(manifest)}\n`;
}
export function parseWriterRecord(text) {
    try {
        const parsed = JSON.parse(text);
        if (parsed.schemaVersion !== M1_WRITER_SCHEMA || !parsed.holder || !parsed.moduleName)
            return null;
        return parsed;
    }
    catch {
        return null;
    }
}
/** Reverse closure: units that depend on `changed`, directly or further down. */
export function reverseClosure(changed, dependents) {
    const seen = new Set();
    const stack = [...changed];
    while (stack.length > 0) {
        const current = stack.pop();
        for (const next of dependents.get(current) ?? []) {
            if (seen.has(next))
                continue;
            seen.add(next);
            stack.push(next);
        }
    }
    return [...seen].sort();
}
