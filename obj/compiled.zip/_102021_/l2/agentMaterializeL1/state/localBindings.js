/// <mls fileReference="_102021_/l2/agentMaterializeL1/state/localBindings.ts" enhancement="_blank"/>
import { receiptPathFor } from '/_102021_/l2/agentMaterializeL1/contracts/definition.js';
import { projectLockRef } from '/_102021_/l2/agentMaterializeL1/register/reconcileL5.js';
import { lockHolder, M1_WRITER_SCHEMA, parseWriterRecord, selectRemoval, writerRef, } from '/_102021_/l2/agentMaterializeL1/state/maintain.js';
export function createLocalBindings(io, files) {
    const state = {
        async readReceipt(defPath) {
            const path = receiptPathFor(defPath);
            if (!path)
                return null;
            const text = await io.read(path);
            if (!text)
                return null;
            try {
                return JSON.parse(text);
            }
            catch {
                return null;
            }
        },
        async writeReceipt(receipt) {
            const path = receiptPathFor(receipt.defPath);
            if (!path)
                throw new Error('Receipt path is empty.');
            await files.write(path, `${JSON.stringify(receipt)}\n`);
        },
        async readOwned(outputPath) {
            const text = await io.read(outputPath);
            return text === null ? null : new TextEncoder().encode(text);
        },
        async writeOwned(outputPath, body) {
            await files.write(outputPath, new TextDecoder().decode(body));
        },
        async removeOwned(owned, requested) {
            const plan = selectRemoval(owned, requested);
            const removed = [];
            const kept = [...plan.keep];
            for (const path of plan.remove) {
                if (await files.remove(path))
                    removed.push(path);
                else
                    kept.push(path);
            }
            return { removed, kept };
        },
        async readRevision(defPath) {
            const receipt = await this.readReceipt(defPath);
            return receipt?.semanticHash ?? null;
        },
    };
    const writer = {
        async claim(moduleName, holder) {
            const body = `${JSON.stringify({ schemaVersion: M1_WRITER_SCHEMA, moduleName, holder })}\n`;
            return files.createExclusive(writerRef(moduleName), body);
        },
        async release(moduleName, holder) {
            const text = await files.read(writerRef(moduleName));
            const record = text ? parseWriterRecord(text) : null;
            if (!record || record.holder !== holder || record.moduleName !== moduleName)
                return;
            await files.remove(writerRef(moduleName));
        },
    };
    const projectLock = {
        claim: (projectId, holder) => files.createExclusive(projectLockRef(projectId), `${JSON.stringify({ holder })}\n`),
        async release(projectId, holder) {
            if (lockHolder(await files.read(projectLockRef(projectId))) !== holder)
                return;
            await files.remove(projectLockRef(projectId));
        },
    };
    return { state, writer, projectLock };
}
