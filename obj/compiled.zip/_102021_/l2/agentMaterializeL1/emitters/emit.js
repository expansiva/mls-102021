/// <mls fileReference="_102021_/l2/agentMaterializeL1/emitters/emit.ts" enhancement="_blank"/>
/**
 * Renders one structure file from a v2 def. Imports are only platform files,
 * an existing l2 contract, or the output of a dependency. A missing source
 * is a named failure, not an import of a file that does not exist.
 */
import { parseDefinitionExport, usecasePlan } from '/_102021_/l2/agentMaterializeL1/emitters/usecaseIntent.js';
import { isRecord, outputPathFromDefPath, readDefinition, } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { M1_STUB_ERROR, M1_STUB_STATUS } from '/_102021_/l2/agentMaterializeL1/emitters/catalog.js';
import { domainOptionalPaths, optionalSignatureNames } from '/_102021_/l2/agentMaterializeL1/emitters/domainOptional.js';
import { nodeDisclosure, outputNodes } from '/_102021_/l2/helpers/l1Defs/disclosure.js';
import { elementPath, outputViews, readOutputTree } from '/_102021_/l2/helpers/l1Defs/requestTree.js';
import { AUTHORITY_UNMAPPED, AUTHORITY_UNREAD, FORBIDDEN_ACTOR, GRANT_ABSENT, REPOSITORY_NOT_IMPLEMENTED, SCOPE_UNBOUND, SESSION_UNVERIFIED, VALIDATION_ERROR, DEF_V1_UNSUPPORTED, defV1Detail, } from '/_102021_/l2/agentMaterializeL1/emitters/gate.js';
/** Raised when the structure handler body changes. An older receipt is a new input. */
export const STRUCTURE_HANDLER_RECIPE = '2026-10-02-structure-handler-v13';
const PLATFORM_CONTRACTS = '/_102034_/l1/server/layer_2_controllers/contracts.js';
const REPOSITORY_REGISTRY = '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';
const MDM_MODULE = '/_102034_/l1/mdm/module.js';
/**
 * `optional` names the field paths a stored record may lack; without it every field is required.
 * `enums` maps a field path to the values its source declares; an `enum` field without values stays `string`.
 * The lifecycle states type the entity's single top-level `enum` field.
 */
export function emitDomain(definition, output, optional = new Set(), enums = new Map(), collections = new Set()) {
    const name = token(definition.data.entityId, definition.artifactId);
    const fields = fieldRows(definition.data.fields);
    const states = lifecycleStates(definition.data.lifecycle);
    const topEnums = fields.filter(field => field.type === 'enum' && !field.name.includes('.'));
    const declared = new Map(enums);
    if (states.length > 0 && topEnums.length === 1 && !declared.has(topEnums[0].name))
        declared.set(topEnums[0].name, states);
    const body = renderType(nest(fields, declared, optional, new Set(), collections), '');
    const values = platformValueImports(fields);
    const importLine = values.length > 0 ? `import type { ${values.join(', ')} } from '${MDM_MODULE}';\n` : '';
    // A type alias, not an interface: an object type alias fits where a usecase output that extends
    // Record<string, unknown> is expected; an interface does not (TS2345 "Index signature … is missing"), which made the
    // fechamento request of comandaRestaurante fail three repairs on 09/10. Same fields, no runtime difference.
    return {
        runsStub: false,
        imports: values.length > 0 ? [MDM_MODULE] : [],
        source: `${header(output)}\n${importLine}export type ${name} = ${body};\n`,
    };
}
export function emitValueObject(definition, output) {
    const name = token(definition.data.valueObjectId, definition.artifactId);
    const [referencedBy] = emittedValueExports(definition);
    const fields = fieldRows(definition.data.fields);
    const referenced = stringList(definition.data.referencedBy);
    const body = renderType(nest(fields, new Map()), '');
    return {
        runsStub: false,
        imports: [],
        source: [
            header(output),
            `export interface ${name} ${body}`,
            `export const ${referencedBy} = ${JSON.stringify(referenced)} as const;`,
            '',
        ].join('\n'),
    };
}
export function emitPort(definition, output) {
    const interfaceName = token(definition.data.interfaceName, definition.artifactId);
    const entity = token(definition.data.entityId, 'Entity');
    const entityDep = definition.dependencies.find(path => path.includes('/entities/'));
    if (!entityDep)
        return { code: 'ENTITY_UNBOUND', detail: `${interfaceName} has no entity dependency.` };
    const methods = Array.isArray(definition.data.methods) ? definition.data.methods.filter(isRecord) : [];
    if (methods.length === 0)
        return { code: 'PORT_EMPTY', detail: `${interfaceName} has no methods.` };
    const locals = new Set();
    const signatures = methods.map(method => renderMethod(method, entity, locals, false));
    const bodies = methods.map(method => renderMethod(method, entity, locals, true));
    const aliases = [...locals].filter(name => name !== entity).map(name => `export type ${name} = Record<string, unknown>;`);
    const [pending] = emittedValueExports(definition);
    const entityImport = importSpecifier(entityDep, 'output');
    return {
        runsStub: true,
        imports: [PLATFORM_CONTRACTS, entityImport],
        source: [
            header(output),
            `import { AppError } from '${PLATFORM_CONTRACTS}';`,
            `import type { ${entity} } from '${importSpecifier(entityDep, 'output')}';`,
            '',
            ...aliases,
            aliases.length ? '' : '',
            `export interface ${interfaceName} {`,
            ...signatures,
            '}',
            '',
            `export const ${pending}: ${interfaceName} = {`,
            ...bodies,
            '};',
            '',
        ].filter((line, index, all) => line !== '' || all[index - 1] !== '').join('\n'),
    };
}
export function emitAccess(definition, output) {
    const grants = grantsOf(definition.data);
    const [grantsName, resolveName] = emittedValueExports(definition);
    const literal = grants.map(grant => `  ${JSON.stringify(grant)}`).join(',\n');
    return {
        runsStub: false,
        imports: [],
        source: [
            header(output),
            'export interface StructureGrant {',
            '  grantId: string;',
            '  actorRef: string;',
            '  scopeMode: string;',
            '  session: string;',
            '  pending: string;',
            '  disclosure: string;',
            '  recordField: string;',
            '  /** Per entity of an own grant, the column that holds the anchor id (one direct step); a longer chain is a join. */',
            '  recordFields: Readonly<Record<string, string>>;',
            '  entityRefs: readonly string[];',
            '  /** An own grant over the anchor itself (the person\'s own record): resolved with no column. */',
            '  selfAnchored: boolean;',
            '}',
            '',
            `export const ${grantsName}: readonly StructureGrant[] = [`,
            literal,
            '];',
            '',
            `export function ${resolveName}(grantId: string): StructureGrant | { code: string; detail: string } {`,
            `  const grant = ${grantsName}.find(item => item.grantId === grantId);`,
            `  if (!grant) return { code: '${GRANT_ABSENT}', detail: \`Grant \${grantId} is not declared.\` };`,
            '  if (grant.pending) return { code: grant.pending, detail: `Grant ${grantId} is pending ${grant.pending}.` };',
            `  if (grant.session !== 'verified') return { code: '${SESSION_UNVERIFIED}', detail: \`Grant \${grantId} session is not verified.\` };`,
            `  if (!grant.scopeMode) return { code: '${SCOPE_UNBOUND}', detail: \`Grant \${grantId} has no scope mode.\` };`,
            '  if (grant.scopeMode === \'own\' && Object.keys(grant.recordFields).length === 0 && !grant.selfAnchored) return { code: \'ACCESS_ANCHOR\', detail: `Grant ${grantId} has no resolved scope path.` };',
            '  return grant;',
            '}',
            '',
        ].join('\n'),
    };
}
export function emitAuthority(definition, output) {
    const entries = Array.isArray(definition.data.entries) ? definition.data.entries.filter(isRecord) : [];
    const [entriesName, actorRefName] = emittedValueExports(definition);
    const rows = entries
        .map(entry => ({ grantId: String(entry.grantId ?? ''), actorRef: String(entry.actorRef ?? '') }))
        .filter(entry => entry.grantId);
    return {
        runsStub: false,
        imports: [],
        source: [
            header(output),
            `export const ${entriesName} = ${JSON.stringify(rows, null, 2)} as const;`,
            '',
            `export function ${actorRefName}(grantId: string): string | null {`,
            `  const entry = ${entriesName}.find(item => item.grantId === grantId);`,
            '  return entry ? entry.actorRef : null;',
            '}',
            '',
        ].join('\n'),
    };
}
export async function emitUsecase(definition, output, read) {
    const fn = readFunction(definition);
    const [fnName] = emittedValueExports(definition);
    if (!fn || !fnName)
        return { code: 'FUNCTION_MISSING', detail: `${definition.artifactId} has no function.` };
    // The signature is the domain and application fields on the def.
    return emitDomainUsecase(definition, output, read, fn, fnName);
}
/** Application interfaces over the def's fields. The entity type is imported; nothing from l2 is. */
async function emitDomainUsecase(definition, output, read, fn, fnName) {
    if (fn.input.length === 0 || fn.output.length === 0) {
        return { code: 'FUNCTION_MISSING', detail: `${definition.artifactId} has no domain signature.` };
    }
    const declaredPorts = stringList(definition.data.ports);
    const ports = portBindings(definition);
    if (declaredPorts.length > 0 && ports.length === 0) {
        return { code: 'PORT_UNBOUND', detail: `${definition.artifactId} names a port that is not a dependency.` };
    }
    if (ports.length > 1 && new Set(ports.map(item => item.specifier)).size > 1) {
        return { code: 'PORT_UNBOUND', detail: `${definition.artifactId} ports are not in one module.` };
    }
    const entityName = token(definition.data.entityId, '');
    const outputFields = fn.output.map(field => field.name === 'items' && field.type === entityName
        ? { name: field.name, type: `${entityName}[]` }
        : field);
    const aliases = new Set();
    if (entityName && [...fn.input, ...outputFields].some(field => field.type === entityName || field.type === `${entityName}[]`)) {
        aliases.add(entityName);
    }
    const entityDep = definition.dependencies.find(path => path.includes('/entities/'));
    if (aliases.size > 0 && !entityDep)
        return { code: 'ENTITY_UNBOUND', detail: `${definition.artifactId} has no entity dependency.` };
    const entityText = entityDep ? await read(entityDep) : null;
    if (entityDep && entityText === null)
        return { code: 'ENTITY_UNBOUND', detail: `${entityDep} could not be read.` };
    // Optional is what the domain types with `?`: same entity def, same l4 entity, same criterion.
    // Unreadable l4 entity: the domain unit is refused on its own (ONTOLOGY_UNREAD); nothing is optional here.
    const entity = entityText === null ? null : parseDefinitionExport(entityText);
    const ontologySource = entity && entityDep ? await read(ontologyRef(entity, entityDep)) : null;
    const domainOptional = entity && entityDep ? domainOptionalPaths(entity, ontologySource) ?? new Set() : new Set();
    // An l4 collection is a list in the usecase signature too, as in the entity (details.tarefas of a notice).
    const collections = ontologyCollections(ontologySource);
    const rawFn = Array.isArray(definition.data.functions) && isRecord(definition.data.functions[0]) ? definition.data.functions[0] : {};
    const inputOptional = optionalSignatureNames(Array.isArray(rawFn.input) ? rawFn.input : [], entityName, domainOptional);
    // Every filter of a list is optional: a caller passes only the filters it means. Required filters made the request
    // invent values (`id: ''`, `contacts: {}`) that then filtered every record out (agendaClinica listPaciente, 07/10).
    if (String(definition.data.operation ?? '') === 'list') {
        for (const row of fn.input)
            if (row.name !== 'page' && row.name !== 'pageSize')
                inputOptional.add(row.name);
    }
    const outputOptional = optionalSignatureNames(Array.isArray(rawFn.output) ? rawFn.output : [], entityName, domainOptional);
    const portImport = ports.length === 0
        ? ''
        : `import type { ${ports.map(item => item.interfaceName).join(', ')} } from '${ports[0].specifier}';`;
    const portArg = ports.length === 0
        ? ''
        : `, ports: { ${ports.map(item => `${item.binding}: ${item.interfaceName}`).join('; ')} }`;
    const voidPorts = ports.length === 0 ? '' : '  void ports;\n';
    const inputType = `${pascal(fnName)}Input`;
    const outputType = `${pascal(fnName)}Output`;
    const entitySpecifier = entityDep && aliases.size > 0 ? importSpecifier(entityDep, 'output') : '';
    return {
        runsStub: true,
        imports: [PLATFORM_CONTRACTS, entitySpecifier, ...ports.map(item => item.specifier)].filter(Boolean),
        source: [
            header(output),
            `import { AppError } from '${PLATFORM_CONTRACTS}';`,
            `import type { RequestContext } from '${PLATFORM_CONTRACTS}';`,
            ...(entitySpecifier ? [`import type { ${entityName} } from '${entitySpecifier}';`] : []),
            portImport,
            '',
            // The service asserts this to and from a record. The index is what makes that assertion legal.
            `export interface ${inputType} extends Record<string, unknown> ${renderType(nest(fn.input, new Map(), inputOptional, aliases, collections), '')}`,
            `export interface ${outputType} extends Record<string, unknown> ${renderType(nest(outputFields, new Map(), outputOptional, aliases, collections), '')}`,
            '',
            `export async function ${fnName}(input: ${inputType}, ctx: RequestContext${portArg}): Promise<${outputType}> {`,
            '  void input;',
            '  void ctx;',
            voidPorts.trimEnd(),
            `  throw new AppError('${M1_STUB_ERROR}', '${fnName} is not implemented.', ${M1_STUB_STATUS});`,
            '}',
            '',
        ].filter(line => line !== '').join('\n'),
    };
}
export async function emitController(definition, output, read) {
    const scopeDep = definition.dependencies.find(path => path.endsWith('/accessScope.defs.ts'));
    if (!scopeDep)
        return { code: 'GRANT_UNREAD', detail: `${definition.artifactId} has no access scope dependency.` };
    const scopeText = await read(scopeDep);
    if (scopeText === null)
        return { code: 'GRANT_UNREAD', detail: `${scopeDep} could not be read.` };
    const handlers = Array.isArray(definition.data.handlers) ? definition.data.handlers.filter(isRecord) : [];
    if (handlers.length === 0)
        return { code: 'ROUTE_MISSING', detail: `${definition.artifactId} declares no route.` };
    // A handler without a service function is the removed v1 route (usecaseId); it is refused, never emitted.
    if (!handlers.every(handler => typeof handler.serviceFunction === 'string')) {
        return { code: DEF_V1_UNSUPPORTED, detail: defV1Detail(definition.artifactId) };
    }
    return emitAdapter(definition, output, read, handlers, scopeDep);
}
/**
 * The page controller calls one request-service function. Input and output types are
 * indexed on the contract interface. It does not resolve a repository or cast through `unknown`.
 */
async function emitAdapter(definition, output, read, handlers, scopeDep) {
    const pageId = typeof definition.data.pageId === 'string' ? definition.data.pageId : '';
    const serviceDep = definition.dependencies.find(path => pageId && path.endsWith(`/requests/${pageId}.defs.ts`));
    if (!serviceDep)
        return { code: 'USECASE_UNBOUND', detail: `${definition.artifactId} has no request service.` };
    if (await read(serviceDep) === null)
        return { code: 'USECASE_UNBOUND', detail: `${serviceDep} could not be read.` };
    const authorityDep = definition.dependencies.find(path => path.endsWith('/authorityMap.defs.ts'));
    const needsAuthority = handlers.some(handler => stringList(handler.grantIds).length > 0);
    if (needsAuthority && !authorityDep) {
        return { code: AUTHORITY_UNREAD, detail: `${definition.artifactId} has grants and no authority map dependency.` };
    }
    if (authorityDep && await read(authorityDep) === null) {
        return { code: AUTHORITY_UNREAD, detail: `${authorityDep} could not be read.` };
    }
    const routes = [];
    const contracts = new Map();
    for (const handler of [...handlers, ...await unlistedContractRoutes(definition, handlers, read)]) {
        const resolved = await resolveAdapterRoute(definition, handler, read);
        if ('code' in resolved)
            return resolved;
        routes.push(resolved.route);
        contracts.set(resolved.specifier, { specifier: resolved.specifier, iface: resolved.route.contractInterface });
    }
    const authorityImport = authorityDep
        ? [`import { actorRefFor } from '${importSpecifier(authorityDep, 'output')}';`]
        : [];
    const contractImports = [...contracts.values()].map(item => `import type { ${item.iface} } from '${item.specifier}';`);
    const imports = [
        PLATFORM_CONTRACTS,
        importSpecifier(scopeDep, 'output'),
        ...(authorityDep ? [importSpecifier(authorityDep, 'output')] : []),
        importSpecifier(serviceDep, 'output'),
        ...[...contracts.keys()],
    ];
    return {
        runsStub: false,
        imports,
        source: [
            header(output),
            `import { AppError, type BffRequest, type BffResponse, type ControllerRoute, type IRequestEnvelope } from '${PLATFORM_CONTRACTS}';`,
            `import { resolveGrant } from '${importSpecifier(scopeDep, 'output')}';`,
            ...authorityImport,
            `import { requests } from '${importSpecifier(serviceDep, 'output')}';`,
            ...contractImports,
            '',
            `export const ${emittedValueExports(definition)[0]}: ControllerRoute[] = [`,
            ...routes.map(route => `  { key: '${route.route}', handler: ${route.fn} },`),
            '];',
            '',
            ...routes.map(renderAdapter),
            scopeSource(),
            authorizeSource(!!authorityDep),
            validateSource(),
            '',
        ].join('\n'),
    };
}
/**
 * The routes of the page contract the controller def does not list. The D1 leaves a route it cannot bind to a
 * usecase out of the controller (`ROUTE_UNRESOLVED`, materializadorL1.md §12: qryExportarInscritosCsv); the route is
 * still the page's, and its handler follows the contract like any other: the request service has its function, the
 * authority is the route's `access.grants`. A route whose contract names no grant is not exposed: no permissive
 * fallback.
 */
async function unlistedContractRoutes(definition, handlers, read) {
    const first = handlers.find(handler => typeof handler.contractPath === 'string' && typeof handler.contractInterface === 'string');
    const pageId = typeof definition.data.pageId === 'string' ? definition.data.pageId : '';
    if (!first || !pageId)
        return [];
    const text = await read(qualifyFile(String(first.contractPath), definition.dependencies));
    if (text === null)
        return [];
    const listed = new Set(handlers.map(handler => String(handler.route ?? '')));
    const prefix = `${definition.moduleName}.${pageId}.`.replace(/\./gu, '\\.');
    const out = [];
    for (const match of text.matchAll(new RegExp(`'(${prefix}[A-Za-z0-9_]+)'\\s*:`, 'gu'))) {
        const route = match[1];
        if (listed.has(route))
            continue;
        listed.add(route);
        const clause = routeClause(text, route) ?? '';
        const grants = /\bgrants\s*:\s*\[([^\]]*)\]/u.exec(clause)?.[1] ?? '';
        const grantIds = [...grants.matchAll(/['"]([A-Za-z0-9_]+)['"]/gu)].map(item => item[1]);
        if (grantIds.length === 0)
            continue;
        out.push({ route, serviceFunction: route, contractPath: first.contractPath, contractInterface: first.contractInterface, grantIds });
    }
    return out;
}
/** Grant and required fields of one v2 route. The adapter names a service function, not a usecase. */
export async function adapterRouteFacts(definition, handler, read) {
    const resolved = await resolveAdapterRoute(definition, handler, read);
    if ('code' in resolved)
        return resolved;
    return { grantIds: resolved.route.grantIds, requiredFields: resolved.route.requiredFields };
}
async function resolveAdapterRoute(definition, handler, read) {
    const route = typeof handler.route === 'string' ? handler.route : '';
    const serviceFunction = typeof handler.serviceFunction === 'string' ? handler.serviceFunction : '';
    const contractPath = typeof handler.contractPath === 'string' ? handler.contractPath : '';
    const contractInterface = typeof handler.contractInterface === 'string' ? handler.contractInterface : '';
    const grantIds = stringList(handler.grantIds);
    if (!route || !serviceFunction)
        return { code: 'ROUTE_MISSING', detail: `${definition.artifactId} has a route without a service function.` };
    if (!contractPath || !IDENT.test(contractInterface) || /(?:Input|Output)$/.test(contractInterface)) {
        return { code: 'CONTRACT_SYMBOL', detail: `${route} has no contract interface.` };
    }
    const qualified = qualifyFile(contractPath, definition.dependencies);
    const text = await read(qualified);
    if (text === null)
        return { code: 'CONTRACT_UNREAD', detail: `${qualified} could not be read.` };
    if (!text.includes(`export interface ${contractInterface} `) && !text.includes(`export interface ${contractInterface}{`)) {
        return { code: 'CONTRACT_SYMBOL', detail: `${qualified} does not export ${contractInterface}.` };
    }
    const clause = routeClause(text, route);
    if (!clause)
        return { code: 'CONTRACT_SYMBOL', detail: `${qualified} has no route ${route}.` };
    const input = clauseValue(clause, 'input');
    if (!input)
        return { code: 'CONTRACT_SYMBOL', detail: `${route} has no input type.` };
    const members = membersOfType(text, input);
    if (!members)
        return { code: 'CONTRACT_SYMBOL', detail: `${route} input could not be read.` };
    // agentMaterializeL1: a named member left closed would refuse the input the contract itself describes.
    const closed = unopenedNamedMembers(text, input, members.allowedPaths);
    if (closed.length)
        return { code: 'CONTRACT_INPUT_UNOPENED', detail: `${route} input has members typed by a contract interface that were not opened: ${closed.join(', ')}.` };
    return {
        specifier: importSpecifier(qualified, 'defs'),
        route: {
            route,
            fn: functionName(route),
            grantIds,
            serviceFunction,
            contractInterface,
            requiredFields: members.requiredFields,
            allowedInputPaths: members.allowedPaths,
            nullableInputPaths: members.nullablePaths,
            unions: members.unions,
        },
    };
}
function renderAdapter(route) {
    const grants = route.grantIds.map(item => `'${item}'`).join(', ');
    const required = route.requiredFields.map(item => `'${item}'`).join(', ');
    const allowed = route.allowedInputPaths.map(item => `'${item}'`).join(', ');
    const nullable = route.nullableInputPaths.map(item => `'${item}'`).join(', ');
    const unions = route.unions.map(item => `'${item.path}': [${item.values.map(value => `'${value.replaceAll('\\', '\\\\').replaceAll('\'', '\\\'')}'`).join(', ')}]`).join(', ');
    const inputType = `${route.contractInterface}['${route.route}']['input']`;
    const outputType = `${route.contractInterface}['${route.route}']['output']`;
    return [
        `async function ${route.fn}(input: IRequestEnvelope): Promise<BffResponse<${outputType}>> {`,
        `  const held = authorize(input.request, [${grants}]);`,
        '  if (held instanceof AppError) throw held;',
        // The scope field is the server's: it is set before the validation, so the page is never asked for it.
        `  const scoped = scopeParams(input.request.params, input.ctx, held, [${allowed}]);`,
        `  const invalid = validateInput(scoped, [${required}], [${allowed}], [${nullable}], { ${unions} });`,
        '  if (invalid) throw invalid;',
        `  const params = scoped as ${inputType};`,
        // The request takes the contract input type: no cast, so a wrong input path is a compile error there.
        `  const data = await requests[${JSON.stringify(route.serviceFunction)}](params, input.ctx);`,
        `  return { ok: true, data: data as ${outputType}, error: null };`,
        '}',
        '',
    ].join('\n');
}
export function membersOfType(source, typeText) {
    const text = typeText.trim();
    if (text.startsWith('{')) {
        // agentMaterializeL1: the rest of the contract follows, so a member typed with a named interface of the same
        // contract (`details: DetalhesItemCardapio`) is opened (the copied recipe allowed only `details`: 400 on details.details).
        const wrapped = `export interface Wrapped ${text.replaceAll('{', '{\n').replaceAll(';', ';\n').replaceAll('}', '\n}')}\n${source}`;
        const members = readMembers(wrapped, 'Wrapped');
        if (!members)
            return null;
        return { requiredFields: members.requiredFields, allowedPaths: members.allowedPaths, nullablePaths: members.nullablePaths, unions: members.unions };
    }
    if (!IDENT.test(text))
        return null;
    const members = readMembers(source, text);
    if (!members)
        return null;
    return { requiredFields: members.requiredFields, allowedPaths: members.allowedPaths, nullablePaths: members.nullablePaths, unions: members.unions };
}
export function routeClause(source, route) {
    const at = source.indexOf(`'${route}':`);
    if (at < 0)
        return null;
    const open = source.indexOf('{', at);
    if (open < 0)
        return null;
    let depth = 0;
    for (let index = open; index < source.length; index += 1) {
        const char = source[index];
        if (char === '{')
            depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0)
                return source.slice(open + 1, index);
        }
    }
    return null;
}
export function clauseValue(clause, name) {
    const match = new RegExp(`(?:^|\\n)\\s*${name}: ([\\s\\S]*?);\\n`).exec(`\n${clause}\n`);
    return match ? match[1].trim() : null;
}
/** Project-qualified ref of an L1/L2 file a def names relatively; the `_<proj>_/` prefix comes from its dependencies. */
export function qualifyFile(path, dependencies) {
    if (/^_\d+_\/l\d+\//.test(path))
        return path;
    const hit = dependencies.find(dep => dep === path || dep.endsWith(`/${path}`));
    if (hit)
        return hit;
    const project = dependencies.map(dep => /^_(\d+)_/.exec(dep)?.[1]).find(Boolean) ?? '';
    return project && /^l\d+\//.test(path) ? `_${project}_/${path}` : path;
}
/** An access-scope grant as the shared rule reads it. An undeclared grant (`{}`) has no mode and discloses nothing. */
function disclosureGrant(grant) {
    return { disclosure: String(grant.disclosure ?? ''), allowedFields: stringList(grant.allowedFields), entityRefs: stringList(grant.entityRefs) };
}
/**
 * Grants of each route a v2 page controller of the module exposes: the handler's `grantIds` read on
 * the module access scope. An undeclared grant id stays `{}` and discloses nothing.
 * A route no controller names is not exposed and has no entry.
 */
export function exposedRouteGrants(moduleDefinitions) {
    const definitions = moduleDefinitions.map(value => readDefinition(value)).filter((item) => !('issues' in item));
    const scope = definitions.find(item => item.artifactType === 'accessScope');
    const scopeGrants = scope && Array.isArray(scope.data.grants) ? scope.data.grants.filter(isRecord) : [];
    const routes = new Map();
    for (const controller of definitions.filter(item => item.artifactType === 'httpController')) {
        const handlers = Array.isArray(controller.data.handlers) ? controller.data.handlers.filter(isRecord) : [];
        for (const handler of handlers) {
            if (typeof handler.serviceFunction !== 'string' || typeof handler.route !== 'string')
                continue;
            const grantIds = stringList(handler.grantIds);
            if (grantIds.length > 0 && !scope)
                return { code: 'GRANT_UNREAD', detail: `${handler.route} names grants and the module has no access scope.` };
            const grants = grantIds.map(grantId => scopeGrants.find(grant => grant.grantId === grantId) ?? {});
            routes.set(handler.route, [...(routes.get(handler.route) ?? []), ...grants]);
        }
    }
    return routes;
}
function scopeSource() {
    // §9 and the own scope per entity: own applies only to the grants the caller holds, and not to an entity a broader
    // grant the caller holds also covers (organization, related); the field goes in only where the route input declares
    // it (the request reads the session otherwise). It runs before the validation: the page is never asked for it.
    return [
        'function scopeParams(params: unknown, ctx: { sessionContext?: { actorId?: string } }, held: readonly string[], allowed: readonly string[]): Record<string, unknown> {',
        '  const body = params && typeof params === \'object\' && !Array.isArray(params) ? { ...(params as Record<string, unknown>) } : {};',
        '  const grants = held.map(grantId => resolveGrant(grantId)).filter((grant): grant is Exclude<ReturnType<typeof resolveGrant>, { code: string }> => \'grantId\' in grant);',
        '  const broader = new Set(grants.filter(grant => grant.scopeMode !== \'own\').flatMap(grant => grant.entityRefs));',
        '  const fields = new Set(grants.filter(grant => grant.scopeMode === \'own\')',
        '    .flatMap(grant => Object.entries(grant.recordFields).filter(([entityId]) => !broader.has(entityId)).map(([, field]) => field)));',
        '  if (fields.size === 0) return body;',
        '  const actorId = ctx.sessionContext?.actorId ?? \'\';',
        `  if (!actorId) throw new AppError('${FORBIDDEN_ACTOR}', 'You have no identity for this scope.', 403);`,
        '  for (const field of fields) {',
        '    if (!allowed.includes(field)) continue;',
        '    // enforce:scope',
        '    body[field] = actorId;',
        '  }',
        '  return body;',
        '}',
        '',
    ].join('\n');
}
function authorizeSource(mapped) {
    // Without grants there is no map; the loop below never runs, so the actor line is never reached.
    const actorLine = mapped
        ? '    const actorRef = actorRefFor(grantId);'
        : '    const actorRef = null as string | null;';
    // §9: a page of several roles. The caller needs ONE grant of the route, of a role they hold; the result is the
    // grants they hold, which scope the call. A route with no grant is open, as before.
    return [
        'function authorize(request: BffRequest, grantIds: readonly string[]): AppError | string[] {',
        '  const source = request.meta?.source ?? \'http\';',
        '  const authorities = request.meta?.verifiedAuthorities ?? [];',
        `  if (source === 'http' && authorities.length === 0) {`,
        `    return new AppError('${FORBIDDEN_ACTOR}', 'You have no authority to call this routine.', 403);`,
        '  }',
        '  if (grantIds.length === 0) return [];',
        '  const held: string[] = [];',
        '  let refused: AppError | null = null;',
        '  for (const grantId of grantIds) {',
        actorLine,
        `    if (!actorRef) { refused = new AppError('${AUTHORITY_UNMAPPED}', \`Grant \${grantId} has no actor in the authority map.\`, 403); continue; }`,
        '    if (authorities.length > 0 && !authorities.some(item => item === actorRef || item.endsWith(\':\' + actorRef))) continue;',
        '    const resolved = resolveGrant(grantId);',
        '    if (!(\'grantId\' in resolved)) { refused = new AppError(resolved.code, resolved.detail, 403); continue; }',
        '    held.push(grantId);',
        '  }',
        '  if (held.length > 0) return held;',
        `  return refused ?? new AppError('${FORBIDDEN_ACTOR}', 'You have no authority to call this routine.', 403);`,
        '}',
        '',
    ].join('\n');
}
export function validateSource() {
    return [
        '// `null` is accepted only where the contract type declares it; elsewhere it is refused, never read as absent.',
        '// A required member is a present key. `\'\'` is a string, refused only when a closed union omits it.',
        'function validateInput(params: unknown, fields: readonly string[], allowed: readonly string[], nullable: readonly string[] = [], unions: Readonly<Record<string, readonly string[]>> = {}): AppError | null {',
        '  const body = params && typeof params === \'object\' && !Array.isArray(params) ? params as Record<string, unknown> : null;',
        `  if (!body) return new AppError('${VALIDATION_ERROR}', 'Request body must be an object.', 400);`,
        '  const invalidPath = (value: unknown, prefix: string): string => {',
        '    if (Array.isArray(value)) { for (const item of value) { const invalid = invalidPath(item, prefix); if (invalid) return invalid; } return \'\'; }',
        '    if (!value || typeof value !== \'object\') return \'\';',
        '    for (const [key, child] of Object.entries(value as Record<string, unknown>)) {',
        "      const path = prefix ? prefix + '.' + key : key;",
        "      if (!allowed.includes(path)) return path + ' is not permitted.';",
        "      if (child === null && !nullable.includes(path)) return path + ' must not be null.';",
        '      const permitted = unions[path];',
        '      if (permitted && child !== null && (typeof child !== \'string\' || !permitted.includes(child))) return path + \' is not a permitted value.\';',
        '      const invalid = invalidPath(child, path); if (invalid) return invalid;',
        '    }',
        '    return \'\';',
        '  };',
        `  const invalid = invalidPath(body, ''); if (invalid) return new AppError('${VALIDATION_ERROR}', invalid, 400);`,
        '  for (const field of fields) {',
        '    // A required member of an absent optional parent is not required; a required parent has its own entry.',
        '    // A list on the way applies the rest of the path to each of its items: an empty list requires nothing.',
        '    const missing = (value: unknown, parts: readonly string[], path: string, top: boolean): string => {',
        '      if (parts.length === 0) return value === undefined || (value === null && !nullable.includes(field)) ? path : \'\';',
        '      if (!top && (value === undefined || value === null)) return \'\';',
        '      if (Array.isArray(value)) {',
        '        for (const [index, item] of value.entries()) { const found = missing(item, parts, `${path}[${index}]`, false); if (found) return found; }',
        '        return \'\';',
        '      }',
        '      const next = value && typeof value === \'object\' ? (value as Record<string, unknown>)[parts[0]] : undefined;',
        '      return missing(next, parts.slice(1), path ? `${path}.${parts[0]}` : parts[0], false);',
        '    };',
        '    const found = missing(body, field.split(\'.\'), \'\', true);',
        `    if (found) return new AppError('${VALIDATION_ERROR}', \`\${found} is required.\`, 400);`,
        '  }',
        '  return null;',
        '}',
        '',
    ].join('\n');
}
function projectSource() {
    return [
        '// A path in `fields` is copied whole; an ancestor of one is walked; anything else is dropped.',
        'function projectOutput(data: unknown, fields: readonly string[], prefix = \'\'): unknown {',
        '  if (Array.isArray(data)) return data.map(item => projectOutput(item, fields, prefix));',
        '  const source = data && typeof data === \'object\' ? data as Record<string, unknown> : {};',
        '  const projected: Record<string, unknown> = {};',
        '  for (const [key, child] of Object.entries(source)) {',
        "    const path = prefix ? prefix + '.' + key : key;",
        '    if (fields.includes(path)) projected[key] = child;',
        "    else if (child && typeof child === 'object' && fields.some(field => field.startsWith(path + '.'))) projected[key] = projectOutput(child, fields, path);",
        '  }',
        '  return projected;',
        '}',
    ].join('\n');
}
function portBindings(definition) {
    const names = stringList(definition.data.ports);
    if (names.length === 0)
        return [];
    const specifier = definition.dependencies.find(path => path.includes('/ports/'));
    if (!specifier)
        return [];
    return names.map(interfaceName => ({
        interfaceName,
        specifier: importSpecifier(specifier, 'output'),
        binding: camel(interfaceName),
    }));
}
/** Port names named by a repositoryRegistration adapter row in this module's defs. */
function registeredPortNames(definitions) {
    const names = new Set();
    for (const value of definitions) {
        const parsed = readDefinition(value);
        if ('issues' in parsed || parsed.artifactType !== 'repositoryRegistration')
            continue;
        const adapters = Array.isArray(parsed.data.adapters) ? parsed.data.adapters.filter(isRecord) : [];
        for (const adapter of adapters) {
            const portId = typeof adapter.portId === 'string' ? adapter.portId : '';
            if (portId)
                names.add(portId);
        }
    }
    return names;
}
function renderMethod(method, entity, locals, body) {
    const name = token(method.name, 'call');
    const params = Array.isArray(method.params) ? method.params.map(item => String(item)) : [];
    const args = params.map((item, index) => `${argName(item, index)}: ${mapToken(item, entity, locals)}`).join(', ');
    const returns = mapToken(String(method.returns ?? 'void'), entity, locals);
    if (!body)
        return `  ${name}(${args}): Promise<${returns}>;`;
    return `  async ${name}(${args}): Promise<${returns}> { throw new AppError('${REPOSITORY_NOT_IMPLEMENTED}', '${name} is not implemented.', ${M1_STUB_STATUS}); },`;
}
function mapToken(tokenValue, entity, locals) {
    const array = tokenValue.endsWith('[]');
    const base = array ? tokenValue.slice(0, -2) : tokenValue;
    let ts = 'unknown';
    if (base === entity)
        ts = entity;
    else if (base === 'string' || base === 'number' || base === 'boolean' || base === 'void')
        ts = base;
    else if (/^[a-z]/.test(base))
        ts = 'string';
    else if (/^[A-Z][A-Za-z0-9_]*$/.test(base)) {
        locals.add(base);
        ts = base;
    }
    return array ? `${ts}[]` : ts;
}
const FIELD_PATH = /^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$/;
const IDENT = /^[A-Za-z_][A-Za-z0-9_]*$/;
/**
 * One function per request, keyed by the route. A command resolves repositories on the
 * transaction runtime: the adapter binds `ctx.data.moduleData` when the factory runs.
 * `outputs[].page`, `pageSize` and `hasMore` are the contract pagination keys when the def has them.
 */
export async function emitRequestService(definition, output, read, moduleDefinitions, stage) {
    const loaded = await loadService(definition, read, registeredPortNames(moduleDefinitions));
    if ('code' in loaded)
        return loaded;
    // The grant still bounds what leaves: the shared rule (helpers/l1Defs/disclosure.ts, same as the D1 plan).
    // A route no controller names is not exposed and has no grants to check.
    const exposed = exposedRouteGrants(moduleDefinitions);
    if ('code' in exposed)
        return exposed;
    for (const call of loaded) {
        const grants = (exposed.get(call.route) ?? []).map(disclosureGrant);
        if (grants.length === 0)
            continue;
        const entityDefinition = (entity) => moduleDefinitions.find(item => isRecord(item) && item.artifactType === 'domainEntity' && isRecord(item.data) && item.data.entityId === entity);
        for (const output of call.outputs) {
            for (const node of outputNodes(output)) {
                const verdict = nodeDisclosure(grants, node, entityDefinition);
                if (verdict === 'computed')
                    return { code: 'COMPUTED_NOT_DISCLOSED', detail: `COMPUTED_NOT_DISCLOSED: ${call.route} ${node.field}` };
                if (verdict !== 'disclosed')
                    return { code: 'DISCLOSURE_EXCEEDS_GRANT', detail: `DISCLOSURE_EXCEEDS_GRANT: ${call.route} ${node.field}` };
            }
        }
    }
    // d1_61: what the grants release but this emitter does not project as the contract shape is refused by name, never
    // emitted as a wrong projection.
    const unsupported = loaded.flatMap(call => call.unsupported);
    if (unsupported.length)
        return { code: 'REQUEST_SHAPE_UNSUPPORTED', detail: unsupported.join('\n') };
    const behavior = stage === 'implement';
    const uses = loaded.flatMap(call => call.uses);
    const specifiers = unique(uses.map(use => use.specifier));
    const imports = [PLATFORM_CONTRACTS, ...(behavior ? [REPOSITORY_REGISTRY] : []), ...specifiers];
    const source = [
        header(output),
        `import { AppError, type RequestContext } from '${PLATFORM_CONTRACTS}';`,
        ...(behavior ? [`import { resolveRepository } from '${REPOSITORY_REGISTRY}';`] : []),
        ...usecaseImportLines(uses),
        '',
        'export const requests = {',
        ...loaded.map(call => renderRequest(call, behavior)),
        '};',
        '',
        ...(behavior ? [projectSource(), ''] : []),
    ].join('\n');
    return { runsStub: !behavior, imports, source };
}
async function loadService(definition, read, registered) {
    const rows = Array.isArray(definition.data.requests) ? definition.data.requests.filter(isRecord) : [];
    if (rows.length === 0)
        return { code: 'ROUTE_MISSING', detail: `${definition.artifactId} declares no request.` };
    const calls = [];
    const seen = new Set();
    for (const row of rows) {
        const route = typeof row.route === 'string' ? row.route : '';
        const kind = row.kind === 'cmd' || row.kind === 'qry' ? row.kind : '';
        const transaction = row.transaction === 'single' || row.transaction === 'none' ? row.transaction : '';
        if (!route || !kind || !transaction)
            return { code: 'ROUTE_MISSING', detail: `${definition.artifactId} has a request without a route.` };
        if (seen.has(route))
            return { code: 'REQUEST_HANDLER', detail: `Route ${route} is declared more than once.` };
        seen.add(route);
        const expected = kind === 'cmd' ? 'single' : 'none';
        if (transaction !== expected) {
            return { code: 'TRANSACTION_REQUIRED', detail: `${route} transaction is ${transaction}. A ${kind === 'cmd' ? 'command' : 'query'} is ${expected}.` };
        }
        const uses = await loadUses(definition, route, stringList(row.uses), read, registered);
        if ('code' in uses)
            return uses;
        const shape = readServiceOutputs(route, row);
        if ('code' in shape)
            return shape;
        const { outputs, unsupported } = shape;
        const params = loadParams(route, row.params);
        if ('code' in params)
            return params;
        if (unsupported.length) {
            calls.push({ route, transaction, uses, outputs, params, unsupported });
            continue;
        }
        for (const output of outputs) {
            if (!uses.some(use => use.entityId === output.entity)) {
                return { code: 'USECASE_UNBOUND', detail: `${route} projects ${output.entity}, which is not a used usecase.` };
            }
            if (output.page && !params.some(param => param.target === output.key && param.pages && param.name === 'page')) {
                return { code: 'PAGINATION_UNBOUND', detail: `${route} output ${output.key} names ${output.page} and has no page param.` };
            }
            if (output.pageSize && !params.some(param => param.target === output.key && param.pages && param.name === 'pageSize')) {
                return { code: 'PAGINATION_UNBOUND', detail: `${route} output ${output.key} names ${output.pageSize} and has no pageSize param.` };
            }
        }
        calls.push({ route, transaction, uses, outputs, params, unsupported: [] });
    }
    return calls;
}
async function loadUses(definition, route, ids, read, registered) {
    if (ids.length === 0)
        return { code: 'USECASE_UNBOUND', detail: `${route} uses no usecase.` };
    const uses = [];
    const names = new Set();
    const entities = new Set();
    for (const usecaseId of ids) {
        if (!IDENT.test(usecaseId))
            return { code: 'USECASE_UNBOUND', detail: `${route} uses ${usecaseId}, which is not an identifier.` };
        const dep = definition.dependencies.find(path => path.endsWith(`/${usecaseId}.defs.ts`));
        if (!dep)
            return { code: 'USECASE_UNBOUND', detail: `${route} has no dependency on ${usecaseId}.` };
        const text = await read(dep);
        if (text === null)
            return { code: 'USECASE_UNBOUND', detail: `${dep} could not be read.` };
        const declared = parseDefinitionExport(text);
        if (!declared)
            return { code: 'USECASE_UNBOUND', detail: `${dep} is not a definition.` };
        // The usecase def carries only its intent (§10): its function and port follow from the operation and the entity.
        const plan = await usecasePlan(declared, read);
        if (plan.detail)
            return { code: 'FUNCTION_MISSING', detail: plan.detail };
        const parsed = plan.definition;
        const fn = readFunction(parsed);
        const entityId = typeof parsed.data.entityId === 'string' ? parsed.data.entityId : '';
        const operation = typeof parsed.data.operation === 'string' ? parsed.data.operation : '';
        if (!fn || !IDENT.test(fn.name) || !IDENT.test(entityId) || !operation) {
            return { code: 'FUNCTION_MISSING', detail: `${usecaseId} has no function.` };
        }
        if (names.has(fn.name))
            return { code: 'FUNCTION_MISSING', detail: `${fn.name} is exported by more than one usecase.` };
        if (entities.has(entityId))
            return { code: 'USECASE_ENTITY', detail: `${route} uses more than one usecase of ${entityId}.` };
        names.add(fn.name);
        entities.add(entityId);
        const ports = [];
        for (const interfaceName of stringList(parsed.data.ports)) {
            if (!IDENT.test(interfaceName))
                return { code: 'PORT_UNBOUND', detail: `${usecaseId} names a port that is not an identifier.` };
            if (!registered.has(interfaceName))
                return { code: 'PORT_UNBOUND', detail: `${interfaceName} is not a registered repository.` };
            ports.push({ interfaceName, binding: camel(interfaceName) });
        }
        uses.push({ usecaseId, functionName: fn.name, specifier: importSpecifier(dep, 'output'), entityId, operation, ports });
    }
    return uses;
}
/**
 * The outputs of one request row, the one M1 reader (emit and obligations). A def with the classified tree (`output`,
 * d1_61) is projected only when every node is one this emitter projects as it is: an `entity` or a flat `list` (no
 * `total`, no page wrapper) at a root member, whose fields are their own ontology paths. Every other node is a named
 * refusal, one line per path in `unsupported`: `REQUEST_SHAPE_UNSUPPORTED: <route> <path> <type>`. The outputs still
 * carry every classified node, so the disclosure check reads the entity, related and computed paths first. The flat
 * paging keys of a list are not projected, as with the flat `outputs`. A def written before the tree (`outputs`) is
 * read by name, as before.
 */
export function readServiceOutputs(route, row) {
    if (row.output === undefined) {
        const flat = loadFlatOutputs(route, row.outputs);
        return 'code' in flat ? flat : { outputs: flat, unsupported: [] };
    }
    if (row.outputs !== undefined)
        return { code: 'PROJECTION_UNDECLARED', detail: `${route} declares both output and outputs.` };
    const tree = readOutputTree(row.output);
    if (!tree)
        return { code: 'PROJECTION_FIELD_UNKNOWN', detail: `${route} has an output node that is not a classified path.` };
    if (tree.length === 0)
        return { code: 'PROJECTION_UNDECLARED', detail: `${route} has no output projection.` };
    const unsupported = unsupportedShapes(tree).map(item => `REQUEST_SHAPE_UNSUPPORTED: ${route} ${item.path} ${item.type}`);
    const outputs = [];
    for (const view of outputViews(tree)) {
        if (!unsupported.length && (!IDENT.test(view.key) || !IDENT.test(view.entity) || view.fields.length === 0 || view.fields.some(field => !FIELD_PATH.test(field)))) {
            return { code: 'PROJECTION_FIELD_UNKNOWN', detail: `${route} has an output projection that is not a field path.` };
        }
        outputs.push({ key: view.key, entity: view.entity, fields: view.fields, disclosure: view.disclosure, page: '', pageSize: '', hasMore: '' });
    }
    return { outputs, unsupported };
}
/** The nodes of a tree this emitter does not project, with the type the refusal names. */
export function unsupportedShapes(tree) {
    const out = [];
    tree.forEach((node, index) => {
        if (node.kind === 'related') {
            // N:1 fields sit on the records of an owner written before them, and are named one by one; a nested relation is
            // named by its path.
            const owned = tree.slice(0, index).some(other => other.kind !== 'computed' && other.kind !== 'unresolved' && elementPath(other) === node.path);
            if (!owned)
                out.push({ path: node.path, type: node.kind });
            else
                for (const field of node.fields)
                    out.push({ path: `${node.path}.${field.field}`, type: node.kind });
            return;
        }
        if (node.kind !== 'entity' && node.kind !== 'list') {
            out.push({ path: node.path, type: node.kind });
            return;
        }
        // Nested in a group of outputs, or a page wrapper: the projection would not be the contract shape.
        if (!IDENT.test(node.path) || (node.kind === 'list' && node.items))
            out.push({ path: node.path, type: node.kind });
        if (node.kind === 'list' && node.total)
            out.push({ path: node.total, type: 'list' });
        // A field that stands for another ontology path would be projected by its contract name, which the record lacks.
        for (const field of node.fields)
            if (field.field !== field.path)
                out.push({ path: `${elementPath(node)}.${field.field}`, type: 'mapped' });
    });
    return out;
}
function loadFlatOutputs(route, value) {
    const rows = Array.isArray(value) ? value.filter(isRecord) : [];
    if (rows.length === 0)
        return { code: 'PROJECTION_UNDECLARED', detail: `${route} has no output projection.` };
    const outputs = [];
    for (const row of rows) {
        const key = typeof row.key === 'string' ? row.key : '';
        const entity = typeof row.entity === 'string' ? row.entity : '';
        const fields = stringList(row.fields);
        if (!IDENT.test(key) || !IDENT.test(entity) || fields.length === 0 || fields.some(field => !FIELD_PATH.test(field))) {
            return { code: 'PROJECTION_FIELD_UNKNOWN', detail: `${route} has an output projection that is not a field path.` };
        }
        const page = typeof row.page === 'string' ? row.page : '';
        const pageSize = typeof row.pageSize === 'string' ? row.pageSize : '';
        const hasMore = typeof row.hasMore === 'string' ? row.hasMore : '';
        if ([page, pageSize, hasMore].some(name => name && !IDENT.test(name))) {
            return { code: 'PROJECTION_FIELD_UNKNOWN', detail: `${route} has a pagination key that is not an identifier.` };
        }
        outputs.push({ key, entity, fields, page, pageSize, hasMore });
    }
    return outputs;
}
function loadParams(route, value) {
    const rows = Array.isArray(value) ? value.filter(isRecord) : [];
    const params = [];
    for (const row of rows) {
        const name = typeof row.name === 'string' ? row.name : '';
        const target = typeof row.target === 'string' ? row.target : '';
        const pages = typeof row.pages === 'string' ? row.pages : '';
        if (!IDENT.test(name) || !IDENT.test(target)) {
            return { code: 'ROUTE_MISSING', detail: `${route} has a param that is not an identifier.` };
        }
        params.push({ name, target, pages });
    }
    return params;
}
function usecaseImportLines(uses) {
    const bySpec = new Map();
    for (const use of uses) {
        const names = bySpec.get(use.specifier) ?? [];
        if (!names.includes(use.functionName))
            names.push(use.functionName);
        bySpec.set(use.specifier, names);
    }
    return [...bySpec].map(([specifier, names]) => `import { ${names.join(', ')} } from '${specifier}';`);
}
function renderRequest(call, behavior) {
    const signature = `  ${JSON.stringify(call.route)}: async function (input: Record<string, unknown>, ctx: RequestContext): Promise<Record<string, unknown>> {`;
    if (!behavior) {
        return [
            signature,
            '    void input;',
            '    void ctx;',
            ...call.uses.map(use => `    void ${use.functionName};`),
            `    throw new AppError('${M1_STUB_ERROR}', ${JSON.stringify(`${call.route} is not implemented.`)}, ${M1_STUB_STATUS});`,
            '  },',
        ].join('\n');
    }
    const body = renderRequestBody(call, call.transaction === 'single' ? '    ' : '  ');
    if (call.transaction === 'single') {
        return [signature, '  return ctx.data.moduleData.runInTransaction(async (tx) => {', body, '  });', '  },'].join('\n');
    }
    return [signature, body, '  },'].join('\n');
}
function renderRequestBody(call, indent) {
    const inTx = call.transaction === 'single';
    const bound = inTx
        ? `${indent}const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };`
        : `${indent}const bound: RequestContext = ctx;`;
    const steps = call.uses.map((use, index) => {
        const ports = use.ports.length === 0
            ? ''
            : `, { ${use.ports.map(port => `${port.binding}: resolveRepository(bound, ${JSON.stringify(port.interfaceName)})`).join(', ')} } as Parameters<typeof ${use.functionName}>[2]`;
        return `${indent}const step${index} = await ${use.functionName}(input as Parameters<typeof ${use.functionName}>[0], bound${ports});`;
    });
    const lines = [bound, ...steps, `${indent}const out: Record<string, unknown> = {};`];
    call.outputs.forEach(output => {
        const index = call.uses.findIndex(use => use.entityId === output.entity);
        const step = `step${index}`;
        const fields = output.fields.map(field => JSON.stringify(field)).join(', ');
        const source = call.uses[index].operation === 'list'
            ? `(${step} && typeof ${step} === 'object' ? (${step} as Record<string, unknown>).items : undefined)`
            : step;
        lines.push(`${indent}out[${JSON.stringify(output.key)}] = projectOutput(${source}, [${fields}]);`);
        if (output.page)
            lines.push(`${indent}out[${JSON.stringify(output.page)}] = input.page;`);
        if (output.pageSize)
            lines.push(`${indent}out[${JSON.stringify(output.pageSize)}] = input.pageSize;`);
        if (output.hasMore) {
            lines.push(`${indent}out[${JSON.stringify(output.hasMore)}] = ${step} && typeof ${step} === 'object' ? (${step} as Record<string, unknown>).hasMore : undefined;`);
        }
    });
    lines.push(`${indent}return out;`);
    return lines.join('\n');
}
/** Value bindings the structure emitters write. Types are not included. */
export function emittedValueExports(definition) {
    switch (definition.artifactType) {
        case 'valueObject':
            return ['referencedBy'];
        case 'repositoryPort':
            return [`pending${token(definition.data.interfaceName, definition.artifactId)}`];
        case 'accessScope':
            return ['grants', 'resolveGrant'];
        case 'authorityMap':
            return ['entries', 'actorRefFor'];
        case 'usecase': {
            const fn = readFunction(definition);
            return fn ? [fn.name] : [];
        }
        case 'httpController':
            return ['routes'];
        case 'requestService':
            return ['requests'];
        default:
            return [];
    }
}
export function importSpecifier(defPath, kind) {
    const output = kind === 'output' ? outputPathFromDefPath(defPath) : defPath;
    const file = output || defPath;
    return `/${file.replace(/\.ts$/, '.js')}`;
}
export function auditImports(source, allowed) {
    const found = [...source.matchAll(/from '([^']+)'/g)].map(match => match[1]);
    return found.find(specifier => !allowed.includes(specifier)) ?? '';
}
export function grantsOf(data) {
    if (!Array.isArray(data.grants))
        return [];
    return data.grants.filter(isRecord).map(grant => ({
        grantId: String(grant.grantId ?? ''),
        actorRef: String(grant.actorRef ?? ''),
        scopeMode: String(grant.scopeMode ?? ''),
        session: String(grant.session ?? ''),
        pending: String(grant.pending ?? ''),
        disclosure: String(grant.disclosure ?? ''),
        recordField: recordFieldFromGrant(grant),
        recordFields: recordFieldsFromGrant(grant),
        entityRefs: stringList(grant.entityRefs),
        // The person's own record: the anchor is one of the grant's entities (publicoMeuCadastro on Participante).
        selfAnchored: String(grant.scopeMode ?? '') === 'own' && !!String(grant.anchorEntity ?? '') && stringList(grant.entityRefs).includes(String(grant.anchorEntity ?? '')),
    })).filter(grant => grant.grantId);
}
/**
 * Own scope read per entity (the team's notice of 16/10): each entry of the grant `path` is one entity of the grant and
 * its chain to the anchor. One direct step (`Inscricao.participanteId` → Participante) is a column filter: the entity's
 * record field. A longer chain with an inverse step (Evento ← Inscricao.eventoId, Inscricao.participanteId → Participante)
 * is a join the request service applies. The anchor's own entry and a pending entry name no field.
 */
export function recordFieldsFromGrant(grant) {
    const out = {};
    if (String(grant.scopeMode ?? '') !== 'own')
        return out;
    const anchor = String(grant.anchorEntity ?? '');
    for (const entry of scopeEntries(grant)) {
        if (entry.pending || (anchor && entry.entityId === anchor) || entry.steps.length !== 1)
            continue;
        const leaf = directLeaf(entry.steps[0], entry.entityId, anchor);
        if (leaf)
            out[entry.entityId] = leaf;
    }
    return out;
}
/** The record field of `entityId` in an own grant: its direct step to the anchor; '' when it has none. */
export function recordFieldFor(grant, entityId) {
    return recordFieldsFromGrant(grant)[entityId] ?? '';
}
/** The one record field every directly anchored entity of an own grant shares; '' when there is none or they differ. */
export function recordFieldFromGrant(grant) {
    const fields = [...new Set(Object.values(recordFieldsFromGrant(grant)))];
    return fields.length === 1 ? fields[0] : '';
}
/** The entities of an own grant reached through more than one step, with their chain: the join the request applies. */
export function scopeJoins(grant) {
    if (String(grant.scopeMode ?? '') !== 'own')
        return [];
    const anchor = String(grant.anchorEntity ?? '');
    return scopeEntries(grant)
        .filter(entry => !entry.pending && entry.entityId !== anchor && entry.steps.length > 1)
        .map(entry => ({ entityId: entry.entityId, steps: entry.steps.map(step => `${String(step.from ?? '')} → ${String(step.to ?? '')} by ${String(step.field ?? '')}`) }));
}
function directLeaf(step, entityId, anchor) {
    const from = String(step.from ?? '');
    const to = String(step.to ?? '');
    const field = String(step.field ?? '');
    if (!from || !to || !field || from !== entityId || (anchor && to !== anchor))
        return '';
    const prefix = `${from}.`;
    if (!field.startsWith(prefix))
        return '';
    const leaf = field.slice(prefix.length);
    return /^[A-Za-z_][A-Za-z0-9_]*$/.test(leaf) ? leaf : '';
}
/** The grant path as entries; a path of bare hops (one chain, no entries) is read as the entry of its first entity. */
function scopeEntries(grant) {
    const path = Array.isArray(grant.path) ? grant.path.filter(isRecord) : [];
    if (path.length && path.every(item => !Array.isArray(item.steps))) {
        return [{ entityId: String(path[0].from ?? ''), steps: path, pending: '' }];
    }
    return path.filter(item => Array.isArray(item.steps)).map(item => ({
        entityId: String(item.entityId ?? ''),
        steps: item.steps.filter(isRecord),
        pending: String(item.pending ?? ''),
    }));
}
export function contractMembers(source, name) {
    const members = readMembers(source, name);
    if (!members)
        return null;
    const { requiredFields, allowedFields, allowedPaths } = members;
    return { requiredFields, allowedFields, allowedPaths };
}
/** Member paths of `name` whose declared type admits `null`. */
export function contractNullablePaths(source, name) {
    return readMembers(source, name)?.nullablePaths ?? null;
}
/** `T`, `T[]`, `T | null` or `null | T` of a declared member type: T when it names an interface; '' otherwise. */
export function namedMemberType(declared) {
    const text = declared.replace(/;\s*$/u, '').trim();
    const parts = text.split('|').map(part => part.trim()).filter(part => part && part !== 'null' && part !== 'undefined');
    if (parts.length !== 1)
        return '';
    const bare = parts[0].replace(/\[\]$/u, '');
    return /^[A-Z][A-Za-z0-9_]*$/u.test(bare) ? bare : '';
}
/**
 * Members whose declared type names an interface of the contract and that were not opened: a validator built
 * without them refuses what the contract describes. Empty = every named member was opened.
 */
export function unopenedNamedMembers(source, typeText, allowedPaths) {
    const out = [];
    const text = typeText.trim();
    const body = text.startsWith('{') ? text : (() => {
        const at = source.indexOf(`export interface ${text} `);
        const open = at < 0 ? -1 : source.indexOf('{', at);
        return open < 0 ? '' : source.slice(open);
    })();
    for (const match of body.matchAll(/([A-Za-z_][A-Za-z0-9_]*)\??\s*:\s*([A-Z][A-Za-z0-9_]*)(?:\[\])?\s*(?:\|\s*null\s*)?[;}\n]/gu)) {
        const [_, member, typeName] = match;
        if (!source.includes(`export interface ${typeName} `))
            continue;
        if (!allowedPaths.some(path => path === member || path.endsWith(`.${member}`)))
            continue;
        const opened = allowedPaths.some(path => path.startsWith(`${member}.`) || path.includes(`.${member}.`));
        if (!opened)
            out.push(`${member}: ${typeName}`);
    }
    return out;
}
/** String-literal union (`'a' | 'b'`, optional `| null`). Anything else, including `string`, is not closed. */
function closedUnionLiterals(declared) {
    const text = declared.replace(/;\s*$/u, '').trim();
    if (!text || text.includes('{') || text.includes('['))
        return null;
    const parts = text.split('|').map(part => part.trim()).filter(part => part && part !== 'null' && part !== 'undefined');
    if (parts.length === 0)
        return null;
    const values = [];
    for (const part of parts) {
        const match = /^(['"])((?:\\.|(?!\1).)*)\1$/u.exec(part);
        if (!match)
            return null;
        values.push(match[2].replace(/\\(['"\\])/gu, '$1'));
    }
    return values;
}
function readMembers(source, name, seen = new Set()) {
    const tokenText = `export interface ${name} `;
    const at = source.indexOf(tokenText);
    if (at < 0)
        return null;
    const open = source.indexOf('{', at);
    if (open < 0)
        return null;
    let depth = 0;
    let end = -1;
    for (let index = open; index < source.length; index += 1) {
        const char = source[index];
        if (char === '{')
            depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0) {
                end = index;
                break;
            }
        }
    }
    if (end < 0)
        return null;
    const body = source.slice(open + 1, end);
    const requiredFields = [];
    const allowedFields = [];
    const allowedPaths = [];
    const nullablePaths = [];
    const unions = [];
    const parents = [];
    depth = 1;
    const lines = body.split('\n');
    for (const line of lines) {
        const opens = (line.match(/\{/g) ?? []).length;
        const closes = (line.match(/\}/g) ?? []).length;
        const match = /^\s*"?([A-Za-z_][A-Za-z0-9_]*)"?(\??)\s*:/.exec(line);
        if (match && depth >= 1) {
            if (depth === 1)
                allowedFields.push(match[1]);
            allowedPaths.push([...parents, match[1]].join('.'));
            const path = [...parents, match[1]].join('.');
            if (match[2] !== '?')
                requiredFields.push(path);
            // `x: T | null` on one line, or `x: null | {` opening an object.
            const declared = line.slice(line.indexOf(':') + 1);
            if (/\bnull\b/.test(opens > closes ? declared.slice(0, declared.indexOf('{')) : declared))
                nullablePaths.push(path);
            const literals = closedUnionLiterals(opens > closes ? declared.slice(0, declared.indexOf('{')) : declared);
            if (literals)
                unions.push({ path, values: literals });
            if (opens > closes)
                parents.push(match[1]);
            else {
                // agentMaterializeL1: a member typed with a named interface of the same contract (also `T[]`, `T | null`)
                // is opened, recursively; its paths sit under this member. A cycle stops at the interface already open.
                const named = namedMemberType(declared);
                if (named && !seen.has(named) && source.includes(`export interface ${named} `)) {
                    const inner = readMembers(source, named, new Set([...seen, name, named]));
                    if (inner) {
                        for (const child of inner.allowedPaths)
                            allowedPaths.push(`${path}.${child}`);
                        for (const child of inner.requiredFields)
                            requiredFields.push(`${path}.${child}`);
                        for (const child of inner.nullablePaths)
                            nullablePaths.push(`${path}.${child}`);
                        for (const child of inner.unions)
                            unions.push({ path: `${path}.${child.path}`, values: child.values });
                    }
                }
            }
        }
        else if (closes > opens) {
            // `} | null;` closes an object whose type admits null.
            if (/\}\s*\|\s*null\b/.test(line) && parents.length > 0)
                nullablePaths.push(parents.join('.'));
            for (let count = 0; count < closes - opens; count += 1)
                parents.pop();
        }
        depth += opens - closes;
    }
    return { requiredFields, allowedFields: [...new Set(allowedFields)], allowedPaths: [...new Set(allowedPaths)], nullablePaths: [...new Set(nullablePaths)], unions };
}
function readFunction(definition) {
    const functions = definition.data.functions;
    if (!Array.isArray(functions) || !isRecord(functions[0]))
        return null;
    const fn = functions[0];
    const name = typeof fn.functionName === 'string' ? fn.functionName : '';
    if (!name)
        return null;
    return { name, input: fieldRows(fn.input), output: fieldRows(fn.output) };
}
function fieldRows(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter(isRecord).map(field => ({
        name: typeof field.name === 'string' ? field.name : '',
        type: typeof field.type === 'string' ? field.type : 'string',
        ...(typeof field.of === 'string' && field.of ? { of: field.of } : {}),
    })).filter(field => field.name);
}
function lifecycleStates(value) {
    if (!isRecord(value) || !Array.isArray(value.states))
        return [];
    return value.states.flatMap(item => isRecord(item) && typeof item.state === 'string' && item.state ? [item.state] : []);
}
/** The l4 entity a domain def types against: its ontology dependency, else the module's ontology file. */
export function ontologyRef(definition, output) {
    const project = output.split('/')[0] ?? '';
    return definition.dependencies.find(dep => dep.includes('/ontology/') && !dep.endsWith('/mdm.defs.ts'))
        ?? `${project}/l4/${definition.moduleName}/ontology/${token(definition.data.entityId, definition.artifactId)}.defs.ts`;
}
/** Field paths the l4 entity marks `collection: true` (a list), walking nested `fields`; empty when unreadable. */
export function ontologyCollections(source) {
    const out = new Set();
    const match = source ? /=\s*(\{[\s\S]*\})\s*as const/.exec(source) : null;
    if (!match)
        return out;
    let value;
    try {
        value = JSON.parse(match[1]);
    }
    catch (error) {
        console.warn(`ontology record is not JSON: ${String(error)}`);
        return out;
    }
    const record = isRecord(value) && isRecord(value.record) ? value.record : null;
    if (!record || !isRecord(record.fields))
        return out;
    const walk = (fields, prefix) => {
        for (const [name, meta] of Object.entries(fields)) {
            if (!isRecord(meta))
                continue;
            const path = prefix ? `${prefix}.${name}` : name;
            if (meta.collection === true)
                out.add(path);
            if (isRecord(meta.fields))
                walk(meta.fields, path);
        }
    };
    walk(record.fields, '');
    return out;
}
/** Enum values the l4 entity declares per field path, walking nested `fields`; empty when unreadable. */
export function ontologyEnums(source) {
    const enums = new Map();
    const match = source ? /=\s*(\{[\s\S]*\})\s*as const/.exec(source) : null;
    if (!match)
        return enums;
    let value;
    try {
        value = JSON.parse(match[1]);
    }
    catch (error) {
        console.warn(`ontology record is not JSON: ${String(error)}`);
        return enums;
    }
    const record = isRecord(value) && isRecord(value.record) ? value.record : null;
    if (!record || !isRecord(record.fields))
        return enums;
    const walk = (fields, prefix) => {
        for (const [name, meta] of Object.entries(fields)) {
            if (!isRecord(meta))
                continue;
            const path = prefix ? `${prefix}.${name}` : name;
            const values = Array.isArray(meta.values)
                ? meta.values.flatMap(item => typeof item === 'string' ? [item] : isRecord(item) && typeof item.value === 'string' ? [item.value] : [])
                : [];
            if (meta.type === 'enum' && values.length > 0)
                enums.set(path, values);
            if (isRecord(meta.fields))
                walk(meta.fields, path);
        }
    };
    walk(record.fields, '');
    return enums;
}
function nest(fields, enums, optional = new Set(), aliases = new Set(), collections = new Set()) {
    const root = { ts: 'Record<string, never>', children: new Map() };
    for (const field of fields) {
        const parts = field.name.split('.').filter(Boolean);
        let node = root;
        parts.forEach((part, index) => {
            let child = node.children.get(part);
            if (!child) {
                child = { ts: 'Record<string, unknown>', children: new Map() };
                node.children.set(part, child);
            }
            if (index === parts.length - 1) {
                const ts = fieldTs(field.type, enums.get(field.name) ?? [], aliases, field.of);
                // `collection: true` in the l4 is a list (`details.base.contacts` of an MDM person is `[]`, not an object).
                child.ts = collections.has(field.name) && !ts.endsWith('[]') ? (ts.includes('|') ? `Array<${ts}>` : `${ts}[]`) : ts;
            }
            if (optional.has(parts.slice(0, index + 1).join('.')))
                child.optional = true;
            if (collections.has(parts.slice(0, index + 1).join('.')))
                child.collection = true;
            node = child;
        });
    }
    return root;
}
function fieldTs(type, values, aliases = new Set(), of) {
    if (of)
        return platformValueName(of);
    if (aliases.has(type))
        return type;
    const array = /^(.+)\[\]$/.exec(type);
    if (array && aliases.has(array[1]))
        return type;
    if (type.includes('|') || type.includes('"'))
        return type.split('"').join("'");
    if (type === 'enum' && values.length > 0)
        return values.map(value => `'${value}'`).join(' | ');
    if (type === 'integer' || type === 'number')
        return 'number';
    if (type === 'boolean')
        return 'boolean';
    if (type === 'object')
        return 'Record<string, unknown>';
    return 'string';
}
/**
 * `<of>Value`, imported from the MDM module. No list of platform names here: the unit compile proves the export
 * exists, and a missing one fails by name ("has no exported member 'GeoPointValue'"), never as `Record`.
 */
function platformValueName(of) {
    return `${of}Value`;
}
function platformValueImports(fields) {
    const names = new Set();
    for (const field of fields)
        if (field.of)
            names.add(platformValueName(field.of));
    return [...names].sort();
}
function renderType(node, indent) {
    if (node.children.size === 0)
        return node.ts;
    const lines = [...node.children].map(([key, child]) => `${indent}  ${key}${child.optional ? '?' : ''}: ${renderType(child, `${indent}  `)};`);
    // A collection with fields is a list of that object; the leaf marker of `nest` would be lost under its children.
    return `{\n${lines.join('\n')}\n${indent}}${node.collection ? '[]' : ''}`;
}
function header(output) {
    return `/// <mls fileReference="${output}" enhancement="_blank"/>`;
}
function pascal(value) {
    return value.charAt(0).toUpperCase() + value.slice(1);
}
function functionName(route) {
    const tail = route.split('.').pop() ?? 'route';
    const bare = tail.replace(/[^A-Za-z0-9]/g, '');
    return `handle${bare.charAt(0).toUpperCase()}${bare.slice(1)}`;
}
function argName(tokenValue, index) {
    const base = tokenValue.replace(/\[\]$/, '');
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(base) || base === 'string' || base === 'number' || base === 'boolean')
        return `arg${index}`;
    return camel(base);
}
function camel(value) {
    return value.charAt(0).toLowerCase() + value.slice(1);
}
function token(value, fallback) {
    return typeof value === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(value) ? value : fallback;
}
function stringList(value) {
    return Array.isArray(value) ? value.filter((item) => typeof item === 'string' && item.length > 0) : [];
}
function unique(values) {
    return [...new Set(values)];
}
