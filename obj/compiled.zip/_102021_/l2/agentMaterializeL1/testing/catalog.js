/// <mls fileReference="_102021_/l2/agentMaterializeL1/testing/catalog.ts" enhancement="_blank"/>
import { isM1ArtifactType } from '/_102021_/l2/helpers/l1Defs/definition.js';
export const M1_CATALOG_SCHEMA = '2026-09-25-m1-scenario-catalog-v1';
/** Additive: each case names its runner, and a route case names its caller. */
export const M1_CATALOG_SCHEMA_V11 = '2026-09-26-m1-scenario-catalog-v1.1';
/** Additive: a route case may name `<seedRef>` params and the entity field each one addresses. */
export const M1_CATALOG_SCHEMA_V12 = '2026-10-02-m1-scenario-catalog-v1.2';
export const M1_CATALOG_SCHEMAS = [M1_CATALOG_SCHEMA, M1_CATALOG_SCHEMA_V11, M1_CATALOG_SCHEMA_V12];
/** Literal the monitor resolves from a seeded row. Never an invented id. */
export const M1_SEED_REF = '<seedRef>';
/** Positive case of an operation that addresses one stored record. */
export const M1_EXISTING_RECORD = 'existing record';
export const M1_CATALOG_EXPORT = 'scenarioCatalog';
/** Config key x1_02 will read. It is not `frontend.pageTests`. */
export const M1_CATALOG_CONFIG_KEY = 'backend.scenarioCatalog';
/** Provisional stub from the structure handler. Business expectations do not use this code. */
export const M1_STUB_ERROR = 'USECASE_NOT_IMPLEMENTED';
export const M1_STUB_STATUS = 501;
export const M1_GATES = ['compile', 'contract', 'auth', 'business'];
const ROW_KEYS = ['entity', 'id', 'professionalId', 'patientId', 'scheduledAt', 'status', 'version', 'attendanceNote'];
const EXPECT_KEYS = ['ok', 'status', 'errorCode', 'ruleId', 'forbiddenFields', 'isolatedActorField'];
const FAILURE_KEYS = ['caseId', 'stage', 'errorCode', 'status'];
const CASE_KEYS = [
    'caseId', 'gate', 'mandatory', 'source', 'expectation', 'preconditions', 'synthetic',
    'actorId', 'routine', 'mutating', 'expect', 'expectedFailure',
];
const CASE_KEYS_V11 = [...CASE_KEYS, 'runner', 'caller'];
const CASE_KEYS_V12 = [...CASE_KEYS_V11, 'params', 'paramFieldRefs'];
const CALLER_KEYS = ['source', 'authorities'];
const SCENARIO_KEYS = [
    'scenarioId', 'source', 'artifactType', 'artifactId', 'handlerId', 'productionFile', 'testFile', 'cases',
];
const CATALOG_KEYS = ['schemaVersion', 'moduleName', 'store', 'scenarios'];
export function canonicalJson(value) {
    return JSON.stringify(sortValue(value));
}
export function extractCatalogJson(source) {
    const marker = `export const ${M1_CATALOG_EXPORT} = `;
    const marked = source.indexOf(marker);
    const start = source.indexOf('{', marked === -1 ? 0 : marked);
    if (start < 0)
        return null;
    let depth = 0;
    let inString = false;
    let escape = false;
    for (let index = start; index < source.length; index++) {
        const char = source[index];
        if (inString) {
            if (escape)
                escape = false;
            else if (char === '\\')
                escape = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"')
            inString = true;
        else if (char === '{')
            depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0)
                return source.slice(start, index + 1);
        }
    }
    return null;
}
export function parseCatalog(source) {
    const json = extractCatalogJson(source.trim().startsWith('{') ? source : source);
    if (!json)
        return { catalog: null, issues: ['catalog json is missing'] };
    let raw;
    try {
        raw = JSON.parse(json);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return { catalog: null, issues: [`catalog json: ${message}`] };
    }
    const issues = catalogIssues(raw);
    if (issues.length > 0 || !isCatalog(raw))
        return { catalog: null, issues };
    return { catalog: raw, issues: [] };
}
/** Implement removes the provisional mark. This is not a repair. */
export function catalogForStage(catalog, stage) {
    if (stage === 'structure')
        return catalog;
    return {
        ...catalog,
        scenarios: catalog.scenarios.map(scenario => ({
            ...scenario,
            cases: scenario.cases.map(item => ({ ...item, expectedFailure: null })),
        })),
    };
}
/**
 * Drops a rule or a filter from a copy of the case. Used only to prove the
 * original assertion fails when that rule is absent. Repair refuses the same edit.
 */
export function withoutRule(item, ruleId) {
    const forbiddenFields = item.expect.forbiddenFields.filter(field => field !== ruleId);
    const ruleCleared = item.expect.ruleId === ruleId;
    const actorCleared = item.expect.isolatedActorField === ruleId;
    return {
        ...item,
        expect: {
            ...item.expect,
            forbiddenFields,
            ruleId: ruleCleared ? null : item.expect.ruleId,
            isolatedActorField: actorCleared ? null : item.expect.isolatedActorField,
        },
    };
}
export function repairRefusal(item, proposal) {
    const reasons = [];
    if (proposal.ok !== undefined && proposal.ok !== item.expect.ok)
        reasons.push('ok');
    if (proposal.status !== undefined && proposal.status !== item.expect.status)
        reasons.push('status');
    if (proposal.errorCode !== undefined && proposal.errorCode !== item.expect.errorCode)
        reasons.push('errorCode');
    if (proposal.ruleId !== undefined && proposal.ruleId !== item.expect.ruleId)
        reasons.push('ruleId');
    if (proposal.dropForbiddenFields?.some(field => item.expect.forbiddenFields.includes(field))) {
        reasons.push('forbiddenFields');
    }
    if (proposal.clearActorFilter && item.expect.isolatedActorField)
        reasons.push('actorFilter');
    if (proposal.dropExpectedFailure && item.expectedFailure)
        reasons.push('expectedFailure');
    if (proposal.replaceExpectedFailure)
        reasons.push('expectedFailure');
    return reasons;
}
export function applyRepair(catalog, proposal) {
    const item = catalog.scenarios.flatMap(scenario => scenario.cases).find(entry => entry.caseId === proposal.caseId);
    if (!item)
        return { catalog, refused: ['caseId'] };
    const refused = repairRefusal(item, proposal);
    return { catalog, refused };
}
export function renderMonitorCatalog(catalog, fileReference) {
    return [
        `/// <mls fileReference="${fileReference}" enhancement="_blank"/>`,
        '',
        '// Declarative backend scenarios. A server loads this module as data.',
        `export const ${M1_CATALOG_EXPORT} = ${JSON.stringify(catalog, null, 2)} as const;`,
        '',
    ].join('\n');
}
/** Qualified file or import (`_NNNNN_/…` or `/_NNNNN_/…`) as `/_NNNNN_/….js`. Anything else is refused. */
export function moduleSpecifier(file) {
    const js = file.replace(/\.ts$/, '.js');
    if (js.startsWith('/_'))
        return js;
    if (/^_\d+_\//.test(js))
        return `/${js}`;
    return '';
}
/** Export of the per-unit `.test.ts`: that unit's scenario, as data. */
export const M1_TEST_EXPORT = 'scenarioCases';
/**
 * The per-unit `.test.ts` is data: the scenario the monitor runs from the module catalog
 * (`backend.scenarioCatalog`). No import, no runner, nothing executes when it loads, so it
 * compiles in the Studio like any other module (conduta 28/09, rule 4).
 */
export function renderScenarioTest(scenario) {
    const data = { scenarioId: scenario.scenarioId, handlerId: scenario.handlerId, source: scenario.source, cases: scenario.cases };
    return [
        `/// <mls fileReference="${scenario.testFile}" enhancement="_blank"/>`,
        '',
        '// Behaviour cases of this unit, as data. The monitor runs them from the module scenario catalog.',
        `export const ${M1_TEST_EXPORT} = ${JSON.stringify(data, null, 2)} as const;`,
        '',
    ].join('\n');
}
/** A test this agent rendered before m1_35: a node runner bound to the catalog. It is rewritten, never kept. */
export function isLegacyNodeTest(text, testFile) {
    return text.startsWith(`/// <mls fileReference="${testFile}"`)
        && /from\s*['"]node:/.test(text)
        && text.includes(`${M1_CATALOG_EXPORT}.scenarios.find(`);
}
export function testFileFor(productionFile) {
    if (!productionFile.endsWith('.ts') || productionFile.endsWith('.test.ts'))
        return '';
    return productionFile.replace(/\.ts$/, '.test.ts');
}
function catalogIssues(value) {
    if (!isRecord(value))
        return ['catalog must be an object'];
    const issues = [];
    for (const key of Object.keys(value)) {
        if (!CATALOG_KEYS.includes(key))
            issues.push(`unknown catalog.${key}`);
    }
    const schema = value.schemaVersion;
    if (schema !== M1_CATALOG_SCHEMA && schema !== M1_CATALOG_SCHEMA_V11 && schema !== M1_CATALOG_SCHEMA_V12)
        issues.push('schemaVersion');
    if (typeof value.moduleName !== 'string' || !/^[a-z][A-Za-z0-9]*$/.test(value.moduleName))
        issues.push('moduleName');
    if (value.store !== 'memory')
        issues.push('store must be memory');
    if (!Array.isArray(value.scenarios))
        return [...issues, 'scenarios'];
    const seen = new Set();
    const revision = schema === M1_CATALOG_SCHEMA_V12 ? 12 : schema === M1_CATALOG_SCHEMA_V11 ? 11 : 1;
    for (const scenario of value.scenarios)
        issues.push(...scenarioIssues(scenario, seen, revision));
    return issues;
}
function scenarioIssues(value, seen, revision) {
    if (!isRecord(value))
        return ['scenario must be an object'];
    const issues = [];
    for (const key of Object.keys(value)) {
        if (!SCENARIO_KEYS.includes(key))
            issues.push(`unknown scenario.${key}`);
    }
    const scenarioId = typeof value.scenarioId === 'string' ? value.scenarioId : '';
    if (!scenarioId)
        issues.push('scenarioId');
    if (typeof value.source !== 'string' || !value.source)
        issues.push(`${scenarioId || 'scenario'} source`);
    if (typeof value.artifactType !== 'string' || !isM1ArtifactType(value.artifactType))
        issues.push(`${scenarioId} artifactType`);
    if (typeof value.artifactId !== 'string' || !value.artifactId)
        issues.push(`${scenarioId} artifactId`);
    if (typeof value.handlerId !== 'string' || !value.handlerId.includes('.'))
        issues.push(`${scenarioId} handlerId`);
    if (typeof value.productionFile !== 'string' || !value.productionFile.endsWith('.ts') || value.productionFile.endsWith('.test.ts')) {
        issues.push(`${scenarioId} productionFile`);
    }
    if (value.testFile !== testFileFor(String(value.productionFile ?? '')))
        issues.push(`${scenarioId} testFile`);
    if (!Array.isArray(value.cases) || value.cases.length === 0)
        return [...issues, `${scenarioId} cases`];
    for (const item of value.cases)
        issues.push(...caseIssues(item, seen, revision));
    return issues;
}
function caseIssues(value, seen, revision) {
    if (!isRecord(value))
        return ['case must be an object'];
    const issues = [];
    const allowed = revision >= 12 ? CASE_KEYS_V12 : revision >= 11 ? CASE_KEYS_V11 : CASE_KEYS;
    for (const key of Object.keys(value)) {
        if (!allowed.includes(key))
            issues.push(`unknown case.${key}`);
    }
    const caseId = typeof value.caseId === 'string' ? value.caseId : '';
    if (!caseId)
        issues.push('caseId');
    if (seen.has(caseId))
        issues.push(`duplicate ${caseId}`);
    seen.add(caseId);
    if (!M1_GATES.includes(String(value.gate)))
        issues.push(`${caseId} gate`);
    if (value.mandatory !== true)
        issues.push(`${caseId} mandatory`);
    if (typeof value.source !== 'string' || !value.source)
        issues.push(`${caseId} source`);
    if (typeof value.expectation !== 'string' || !value.expectation)
        issues.push(`${caseId} expectation`);
    if (!stringList(value.preconditions))
        issues.push(`${caseId} preconditions`);
    if (!Array.isArray(value.synthetic))
        issues.push(`${caseId} synthetic`);
    else {
        for (const row of value.synthetic)
            issues.push(...rowIssues(row, caseId));
    }
    if (typeof value.actorId !== 'string')
        issues.push(`${caseId} actorId`);
    if (typeof value.routine !== 'string')
        issues.push(`${caseId} routine`);
    if (typeof value.mutating !== 'boolean')
        issues.push(`${caseId} mutating`);
    issues.push(...expectIssues(value.expect, caseId));
    issues.push(...failureIssues(value.expectedFailure, caseId, String(value.gate)));
    issues.push(...runnerIssues(value, caseId, revision));
    issues.push(...seedIssues(value, caseId, revision));
    return issues;
}
function seedIssues(value, caseId, revision) {
    if (revision < 12 || (value.params === undefined && value.paramFieldRefs === undefined))
        return [];
    const issues = [];
    if (!stringRecord(value.params ?? {}))
        issues.push(`${caseId} params`);
    if (!stringRecord(value.paramFieldRefs ?? {}))
        issues.push(`${caseId} paramFieldRefs`);
    if (issues.length > 0)
        return issues;
    const params = (value.params ?? {});
    const refs = (value.paramFieldRefs ?? {});
    for (const [key, ref] of Object.entries(refs)) {
        if (!(key in params))
            issues.push(`${caseId} paramFieldRefs.${key}`);
        if (!/^[A-Za-z][A-Za-z0-9]*\.[A-Za-z][A-Za-z0-9.]*$/u.test(ref))
            issues.push(`${caseId} paramFieldRefs.${key}`);
    }
    for (const [key, param] of Object.entries(params)) {
        if (param === M1_SEED_REF && refs[key] === undefined)
            issues.push(`${caseId} paramFieldRefs.${key}`);
    }
    return issues;
}
function stringRecord(value) {
    return isRecord(value) && Object.values(value).every(item => typeof item === 'string');
}
function runnerIssues(value, caseId, revision) {
    if (revision < 11)
        return [];
    const issues = [];
    if (value.runner !== 'route' && value.runner !== 'module')
        issues.push(`${caseId} runner`);
    if (value.runner === 'module') {
        if ('caller' in value)
            issues.push(`${caseId} caller`);
        return issues;
    }
    if (value.runner !== 'route')
        return issues;
    if (!isRecord(value.caller))
        return [...issues, `${caseId} caller`];
    for (const key of Object.keys(value.caller)) {
        if (!CALLER_KEYS.includes(key))
            issues.push(`${caseId} caller.${key}`);
    }
    if (value.caller.source !== 'http')
        issues.push(`${caseId} caller.source`);
    if (!stringList(value.caller.authorities))
        issues.push(`${caseId} caller.authorities`);
    return issues;
}
function expectIssues(value, caseId) {
    if (!isRecord(value))
        return [`${caseId} expect`];
    const issues = [];
    for (const key of Object.keys(value)) {
        if (!EXPECT_KEYS.includes(key))
            issues.push(`${caseId} expect.${key}`);
    }
    if (typeof value.ok !== 'boolean')
        issues.push(`${caseId} expect.ok`);
    if (typeof value.status !== 'number')
        issues.push(`${caseId} expect.status`);
    if (!(typeof value.errorCode === 'string' || value.errorCode === null))
        issues.push(`${caseId} expect.errorCode`);
    if (!(typeof value.ruleId === 'string' || value.ruleId === null))
        issues.push(`${caseId} expect.ruleId`);
    if (!stringList(value.forbiddenFields))
        issues.push(`${caseId} expect.forbiddenFields`);
    if (!(typeof value.isolatedActorField === 'string' || value.isolatedActorField === null)) {
        issues.push(`${caseId} expect.isolatedActorField`);
    }
    return issues;
}
function failureIssues(value, caseId, gate) {
    if (value === null)
        return [];
    if (!isRecord(value))
        return [`${caseId} expectedFailure`];
    const issues = [];
    if (gate !== 'business')
        issues.push(`${caseId} expectedFailure is only valid on a business case`);
    for (const key of Object.keys(value)) {
        if (!FAILURE_KEYS.includes(key))
            issues.push(`${caseId} expectedFailure.${key}`);
    }
    if (value.caseId !== caseId)
        issues.push(`${caseId} expectedFailure.caseId`);
    if (value.stage !== 'structure')
        issues.push(`${caseId} expectedFailure.stage`);
    if (value.errorCode !== M1_STUB_ERROR)
        issues.push(`${caseId} expectedFailure.errorCode`);
    if (value.status !== M1_STUB_STATUS)
        issues.push(`${caseId} expectedFailure.status`);
    return issues;
}
function rowIssues(value, caseId) {
    if (!isRecord(value))
        return [`${caseId} synthetic row`];
    const issues = [];
    for (const key of Object.keys(value)) {
        if (!ROW_KEYS.includes(key))
            issues.push(`${caseId} synthetic.${key}`);
    }
    for (const key of ROW_KEYS) {
        if (key === 'version') {
            if (typeof value.version !== 'number')
                issues.push(`${caseId} synthetic.version`);
        }
        else if (typeof value[key] !== 'string')
            issues.push(`${caseId} synthetic.${key}`);
    }
    return issues;
}
function stringList(value) {
    return Array.isArray(value) && value.every(item => typeof item === 'string');
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function isCatalog(value) {
    return isRecord(value)
        && (value.schemaVersion === M1_CATALOG_SCHEMA || value.schemaVersion === M1_CATALOG_SCHEMA_V11 || value.schemaVersion === M1_CATALOG_SCHEMA_V12)
        && value.store === 'memory';
}
function sortValue(value) {
    if (Array.isArray(value))
        return value.map(sortValue);
    if (!value || typeof value !== 'object')
        return value;
    const entries = Object.entries(value).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0);
    return Object.fromEntries(entries.map(([key, item]) => [key, sortValue(item)]));
}
