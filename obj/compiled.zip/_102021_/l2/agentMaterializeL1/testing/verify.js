/// <mls fileReference="_102021_/l2/agentMaterializeL1/testing/verify.ts" enhancement="_blank"/>
import { contentHash } from '/_102021_/l2/agentMaterializeL1/core/io.js';
import { handlerFor } from '/_102021_/l2/agentMaterializeL1/core/registry.js';
import { canonicalJson, catalogForStage, parseCatalog, } from '/_102021_/l2/agentMaterializeL1/testing/catalog.js';
export const M1_CHECKPOINT_SCHEMA = '2026-09-25-m1-checkpoint-v1';
export const M1_CHECKPOINT_BUDGET_MS = 20 * 60 * 1000;
export const M1_VERDICTS = ['passed', 'expectedRed', 'failed', 'blocked', 'skipped', 'inconclusive'];
export const M1_BROKEN = ['none', 'compile', 'import', 'transport'];
export function checkpointDue(elapsedMs, batchClosed) {
    return batchClosed || elapsedMs >= M1_CHECKPOINT_BUDGET_MS;
}
export function classifyCase(stage, item, observation) {
    if (!observation) {
        return evidence(item.caseId, 'inconclusive', null, null, 0, 'case did not run');
    }
    const base = { errorCode: observation.errorCode, status: observation.status, durationMs: observation.durationMs };
    if (observation.thrown) {
        return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, 'unstructured exception is not an expected failure');
    }
    if (observation.broken !== 'none') {
        return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, `${observation.broken} broken is not an expected failure`);
    }
    if (observation.blocked) {
        const owner = observation.blockOwner || 'unassigned';
        return evidence(item.caseId, 'blocked', base.errorCode, base.status, base.durationMs, `blocked: ${owner}`);
    }
    if (observation.skipped) {
        return evidence(item.caseId, 'skipped', base.errorCode, base.status, base.durationMs, observation.reason || 'skipped');
    }
    if (observation.inconclusive) {
        return evidence(item.caseId, 'inconclusive', base.errorCode, base.status, base.durationMs, observation.reason || 'inconclusive');
    }
    if (stage === 'implement' && item.expectedFailure) {
        return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, 'expected mark expired');
    }
    if (stage === 'structure' && matchesFailure(item, observation)) {
        return evidence(item.caseId, 'expectedRed', base.errorCode, base.status, base.durationMs, `expected red at structure: ${observation.errorCode} status ${observation.status}`);
    }
    const filter = filterMiss(item, observation);
    if (sameOutcome(item.expect, observation) && !filter) {
        if (item.expectedFailure) {
            return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, 'expected mark expired');
        }
        return evidence(item.caseId, 'passed', base.errorCode, base.status, base.durationMs, 'passed');
    }
    if (filter && sameOutcome(item.expect, observation)) {
        return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, filter);
    }
    return evidence(item.caseId, 'failed', base.errorCode, base.status, base.durationMs, differentDetail(item, observation));
}
export async function verifyBatch(request) {
    const loaded = await loadCases(request);
    if ('report' in loaded)
        return loaded.report;
    const byId = new Map(request.observations.map(item => [item.caseId, item]));
    const evidenceRows = loaded.cases.map(item => classifyCase(loaded.stage, item, byId.get(item.caseId)));
    return checkpoint(request, loaded.inputHash, evidenceRows);
}
/**
 * The agent's own gate (m1_34). The agent runs in the browser and does not run a case, so a case
 * with no observation and a predicted ok/status decide nothing: the case verdict is the monitor's
 * (m1_35). What blocks is only what the agent sees without running: a broken compile or import, an
 * unstructured exception, and a def gap with an owner (held). The catalog checks stay fail-closed.
 */
export async function gateBatch(request) {
    const loaded = await loadCases(request);
    if ('report' in loaded)
        return loaded.report;
    const byId = new Map(request.observations.map(item => [item.caseId, item]));
    const rows = [];
    for (const item of loaded.cases) {
        const seen = byId.get(item.caseId);
        if (!seen)
            continue;
        const base = [seen.errorCode, seen.status, seen.durationMs];
        if (seen.thrown)
            rows.push(row(item.caseId, 'failed', ...base, 'unstructured exception is not an expected failure'));
        else if (seen.broken !== 'none')
            rows.push(row(item.caseId, 'failed', ...base, `${seen.broken} broken${seen.reason ? `: ${seen.reason}` : ''}`));
        else if (seen.blocked)
            rows.push(row(item.caseId, 'blocked', ...base, `blocked: ${seen.blockOwner || 'unassigned'}`));
    }
    if (rows.length === 0) {
        rows.push(row(request.artifactId || request.handler.id, 'passed', null, 0, 0, 'generated; the cases are not run by the agent, the monitor verifies them'));
    }
    return checkpoint(request, loaded.inputHash, rows);
}
async function loadCases(request) {
    const stage = request.handler.stage;
    const registered = handlerFor(request.handler.artifactType, stage);
    if (!registered || registered.id !== request.handler.id) {
        return { report: checkpoint(request, '', [row('handler', 'failed', null, null, 0, 'handler is not the registered one')]) };
    }
    let text;
    try {
        text = await request.io.read(request.catalogRef);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return { report: checkpoint(request, '', [row('catalog', 'failed', null, null, 0, `catalog read failed: ${message}`)]) };
    }
    if (text === null) {
        return { report: checkpoint(request, '', [row('catalog', 'failed', null, null, 0, 'catalog unreadable')]) };
    }
    const parsed = parseCatalog(text);
    if (!parsed.catalog) {
        return { report: checkpoint(request, '', [row('catalog', 'failed', null, null, 0, parsed.issues.join('; '))]) };
    }
    const inputHash = await contentHash(canonicalJson(parsed.catalog));
    const staged = catalogForStage(parsed.catalog, stage);
    const cases = casesFor(staged, request.handler.id, request.artifactId);
    if (cases.length === 0) {
        const runtime = request.handler.artifactType === 'usecase' || request.handler.artifactType === 'httpController';
        if (request.artifactId && runtime) {
            return { report: checkpoint(request, inputHash, [row(request.artifactId, 'failed', null, null, 0, 'no catalog case for this artifact')]) };
        }
        if (request.artifactId) {
            return { report: checkpoint(request, inputHash, [row(request.artifactId, 'passed', null, 0, 0, 'no runtime scenario; structural file only')]) };
        }
        return { report: checkpoint(request, inputHash, [row('batch', 'failed', null, null, 0, `no scenario for handler ${request.handler.id}`)]) };
    }
    return { stage, inputHash, cases };
}
export function noteMonitorFailure(report, error) {
    return {
        ...report,
        counts: { ...report.counts },
        evidence: report.evidence.map(item => ({ ...item })),
        monitor: { delivered: false, error },
        nextAction: `Monitor did not keep this result (${error}). The local checkpoint stands. ${report.nextAction}`,
    };
}
function casesFor(catalog, handlerId, artifactId) {
    const match = (id) => catalog.scenarios
        .filter(scenario => scenario.handlerId === id && (!artifactId || scenario.artifactId === artifactId))
        .flatMap(scenario => scenario.cases);
    const exact = match(handlerId);
    if (exact.length > 0 || !handlerId.startsWith('implement.'))
        return exact;
    return match(handlerId.replace('implement.', 'structure.'));
}
function matchesFailure(item, observation) {
    const mark = item.expectedFailure;
    if (!mark || mark.caseId !== item.caseId || mark.stage !== 'structure')
        return false;
    return observation.errorCode === mark.errorCode && observation.status === mark.status;
}
function sameOutcome(expect, observation) {
    if (observation.ok !== expect.ok)
        return false;
    if (observation.status !== expect.status)
        return false;
    if (observation.errorCode !== expect.errorCode)
        return false;
    if (expect.ruleId !== null && observation.ruleId !== expect.ruleId)
        return false;
    return true;
}
function filterMiss(item, observation) {
    const leaked = item.expect.forbiddenFields.find(field => observation.fields.includes(field));
    if (leaked)
        return `forbidden field present: ${leaked}`;
    const actorField = item.expect.isolatedActorField;
    if (!actorField)
        return '';
    if (observation.rowActorIds.length === 0)
        return 'actor filter had no rows';
    if (observation.rowActorIds.some(actorId => actorId !== item.actorId))
        return 'actor filter missed';
    return '';
}
function differentDetail(item, observation) {
    const wanted = describeExpect(item.expect);
    return `different failure: expected ${wanted}, got ${observation.errorCode ?? 'none'} status ${observation.status}`;
}
function describeExpect(expect) {
    if (expect.ok)
        return `ok status ${expect.status}`;
    return `${expect.errorCode ?? 'error'} status ${expect.status}`;
}
function evidence(caseId, verdict, errorCode, status, durationMs, detail) {
    return { caseId, verdict, errorCode, status, durationMs, detail };
}
function row(caseId, verdict, errorCode, status, durationMs, detail) {
    return evidence(caseId, verdict, errorCode, status, durationMs, detail);
}
function checkpoint(request, inputHash, evidenceRows) {
    const counts = count(evidenceRows);
    const accepted = evidenceRows.length > 0 && evidenceRows.every(item => item.verdict === 'passed' || (item.verdict === 'expectedRed' && request.handler.stage === 'structure'));
    const ready = request.handler.stage === 'implement' && accepted && counts.expectedRed === 0;
    return {
        schemaVersion: M1_CHECKPOINT_SCHEMA,
        runId: request.runId,
        inputHash,
        commit: request.commit,
        stage: request.handler.stage,
        handlerId: request.handler.id,
        startedAt: request.startedAt,
        finishedAt: request.finishedAt,
        budgetMs: M1_CHECKPOINT_BUDGET_MS,
        counts,
        durationsMs: { total: evidenceRows.reduce((sum, item) => sum + item.durationMs, 0) },
        ready,
        accepted,
        evidence: evidenceRows,
        nextAction: nextAction(request.handler.stage, accepted, evidenceRows),
        monitor: { delivered: request.monitorError === null, error: request.monitorError },
    };
}
function count(rows) {
    const counts = {
        passed: 0, expectedRed: 0, failed: 0, blocked: 0, skipped: 0, inconclusive: 0,
    };
    for (const item of rows)
        counts[item.verdict] += 1;
    return counts;
}
function nextAction(stage, accepted, rows) {
    if (!accepted) {
        const bad = rows.find(item => item.verdict !== 'passed' && !(item.verdict === 'expectedRed' && stage === 'structure'));
        const name = bad ? `${bad.caseId}: ${bad.detail}` : 'empty batch';
        return `Fix ${name}. Do not weaken the assertion.`;
    }
    if (stage === 'structure') {
        return 'Structural checkpoint only. Implement the usecases and remove the expected-red marks. The backend is not ready.';
    }
    return 'Implement checkpoint accepted.';
}
