/// <mls fileReference="_102021_/l2/agentMaterializeL1/run/execute.ts" enhancement="_blank"/>
/**
 * Run of the Studio entry (the agent runs in the browser; collab-msg simulates it).
 * simulate only reads. structure calls structure handlers. implement calls
 * only handlers registered for implement. A missing body is a named block,
 * not a generic file. A failed checkpoint is not promoted and does not start
 * the next stage. A source that changes during the call is not overwritten.
 */
import { isRecord, outputPathFromDefPath, parseDefinitionSource, readDefinition, receiptPathFor, semanticHash, } from '/_102021_/l2/agentMaterializeL1/contracts/definition.js';
import { contentHash } from '/_102021_/l2/agentMaterializeL1/core/io.js';
import { handlerFor } from '/_102021_/l2/agentMaterializeL1/core/registry.js';
import { simulate } from '/_102021_/l2/agentMaterializeL1/simulate/simulate.js';
import { canonicalJson, M1_STUB_ERROR, parseCatalog, renderMonitorCatalog, isLegacyNodeTest, renderScenarioTest, testFileFor, } from '/_102021_/l2/agentMaterializeL1/testing/catalog.js';
import { catalogBytes, catalogWithheld, deriveCatalog } from '/_102021_/l2/agentMaterializeL1/testing/derive.js';
import { obligationSourceHashes } from '/_102021_/l2/agentMaterializeL1/testing/obligations.js';
import { gateBatch } from '/_102021_/l2/agentMaterializeL1/testing/verify.js';
import { decideProfile, emptyLedger, encodeLedger, ledgerPath, noteModelCall, noteRepair, parseLedger, tightenBudget, MaterializeCallError, } from '/_102021_/l2/agentMaterializeL1/run/budget.js';
import { commitL5Registration, loadRegistrationFiles, reconcileL5Backend } from '/_102021_/l2/agentMaterializeL1/register/reconcileL5.js';
import { unitsForFlow } from '/_102021_/l2/agentMaterializeL1/run/command.js';
import { fixtureCheckpoint, fixturePass, fixtureReportRef, fixtureVerification, M1_FIXTURE_CHECK, M1_FIXTURE_REPORT_SCHEMA, parseFixtureReport, renderFixtureReport, } from '/_102021_/l2/agentMaterializeL1/run/fixtureRun.js';
import { invokeModel, shouldCallModel } from '/_102021_/l2/agentMaterializeL1/run/model.js';
import { failureNeedsReverify, hashEvidence, M1_OWNED_SCHEMA, M1_RECIPE_VERSION, recipeForStage, ownedManifestRef, parseOwnedManifest, renderOwnedManifest, replaceStatus, stagingRef, statusForPromotion, busyDetail, writerRef, } from '/_102021_/l2/agentMaterializeL1/state/maintain.js';
export const M1_RUN_SCHEMA = '2026-09-25-m1-run-v1';
export { M1_RECIPE_VERSION };
export async function runMaterialize(request, host) {
    const profile = decideProfile(request.profileMode, request.profileDeclared);
    const selected = unitsForFlow(request.units, request.flow);
    const book = ledgerPath(request.moduleName);
    const stored = await readLedger(host, book, request.project, request.moduleName);
    if (request.resume && stored === 'missing') {
        const budget = tightenBudget(request.budget ?? null, null);
        return finish(request, profile, budget, null, emptyLedger(request.project, request.moduleName, budget), [], [], 0, false, 'NOTHING_TO_RESUME', request.stage ?? 'simulate');
    }
    if (stored === 'corrupt') {
        const budget = tightenBudget(request.budget ?? null, null);
        return finish(request, profile, budget, null, emptyLedger(request.project, request.moduleName, budget), [], [], 0, false, 'LEDGER_UNREADABLE', request.stage ?? 'simulate');
    }
    const budget = tightenBudget(request.budget ?? null, stored && stored !== 'missing' ? stored.budget : null);
    const ledger = stored && stored !== 'missing'
        ? stored
        : emptyLedger(request.project, request.moduleName, budget, request.stage ?? 'simulate');
    ledger.budget = budget;
    const stage = request.stage ?? (request.resume ? ledger.stage : 'simulate');
    if (request.eventId) {
        const previous = ledger.events.find(event => event.id === request.eventId);
        if (previous) {
            return finish(request, profile, budget, null, ledger, previous.units.map(unit => ({
                defPath: unit.defPath,
                code: 'DUPLICATE_EVENT',
                detail: previous.ended,
                promoted: false,
                modelCalls: 0,
            })), [], ledger.calls, false, 'DUPLICATE_EVENT', stage);
        }
    }
    if (request.flow && selected.length === 0) {
        return finish(request, profile, budget, null, ledger, [], [], ledger.calls, false, 'FLOW_NOT_FOUND', stage);
    }
    if (selected.length === 0) {
        return finish(request, profile, budget, null, ledger, [], [], ledger.calls, false, 'NO_UNITS', stage);
    }
    const planStage = stage === 'implement' ? 'implement' : 'structure';
    const merged = await preferDiskDefinitions(host, selected);
    const removals = request.flow ? [] : await ownedRemovals(host, request.moduleName, request.units);
    const snapshot = await simulate({
        moduleName: request.moduleName,
        units: merged,
        stage: planStage,
        io: host.io,
        state: host.state,
        verifyOnly: stage === 'verify' ? merged.map(unit => unit.defPath) : [],
        recipeVersion: recipeForStage(planStage),
        removals,
    });
    const recordedCatalog = ledger.catalogInputHash ?? null;
    const derivedObligations = { obligations: [] };
    // Nothing of the module is written before the writer claim: the catalog and its tests included (m1_32).
    const holder = `${request.project}:${request.moduleName}:${Math.random().toString(16).slice(2)}`;
    const claims = stage !== 'simulate' && !!host.writer;
    if (claims && !await host.writer.claim(request.moduleName, holder)) {
        const ref = writerRef(request.moduleName);
        return { ...finish(request, profile, budget, snapshot, ledger, [], [], 0, false, 'WRITER_BUSY', stage), detail: busyDetail(ref, await host.io.read(ref)) };
    }
    const releaseEarly = async () => {
        if (claims)
            await host.writer.release(request.moduleName, holder);
    };
    let catalogPrep;
    try {
        catalogPrep = host.catalogRef
            ? await prepareCatalog(request, host, snapshot, merged, stage !== 'simulate', recordedCatalog, derivedObligations)
            : null;
    }
    catch (error) {
        await releaseEarly();
        throw error;
    }
    const currentCatalog = catalogPrep?.inputHash ?? null;
    if (catalogPrep?.action === 'invalid') {
        await releaseEarly();
        return finish(request, profile, budget, snapshot, ledger, [], [], 0, false, 'CATALOG_INVALID', stage, catalogPrep);
    }
    if (catalogPrep && ledger.catalogInputHash && ledger.catalogInputHash !== catalogPrep.inputHash) {
        for (const unit of Object.values(ledger.units)) {
            if (unit.signature === 'CATALOG_UNREAD' || unit.signature === 'CATALOG_INVALID' || unit.signature === 'CHECKPOINT_FAILED') {
                unit.signature = '';
            }
        }
    }
    if (catalogPrep)
        ledger.catalogInputHash = catalogPrep.inputHash;
    if (stage === 'simulate') {
        const registration = await reconcileRegistration(request, host, snapshot, profile.allowsStubRun);
        return finish(request, profile, budget, snapshot, ledger, snapshot.units.map(unit => ({
            defPath: unit.defPath,
            code: unit.action.toUpperCase(),
            detail: unit.reason,
            promoted: false,
            modelCalls: 0,
        })), [], 0, false, 'SIMULATED', stage, catalogPrep, registration);
    }
    try {
        const openedAs = ledger.stage;
        ledger.stage = stage;
        let wrote = catalogPrep?.action === 'written';
        const outcomes = [];
        const checkpoints = [];
        const modelCalls = { count: ledger.calls };
        const pending = snapshot.units.map(unit => unit.defPath);
        const done = new Set();
        const definitions = new Map(merged.map(unit => [unit.defPath, unit.definition]));
        const depsOf = dependencyMap(merged);
        while (pending.length > 0) {
            if (request.signal?.aborted) {
                ledger.stage = stage;
                await persist(host, book, ledger);
                return finish(request, profile, budget, snapshot, ledger, outcomes, checkpoints, modelCalls.count - (stored && stored !== 'missing' ? stored.calls : 0), wrote, 'INTERRUPTED', stage, catalogPrep);
            }
            const ready = pending.filter(path => (depsOf.get(path) ?? []).every(dep => done.has(dep) || !depsOf.has(dep)));
            if (ready.length === 0)
                break;
            const wave = ready.slice(0, budget.maxWorkers);
            for (const path of wave)
                pending.splice(pending.indexOf(path), 1);
            await Promise.all(wave.map(async (path) => {
                const unit = snapshot.units.find(item => item.defPath === path);
                if (!unit)
                    return;
                const outcome = await runUnit(request, host, stage, profile, budget, ledger, unit, definitions.get(path), depsOf.get(path) ?? [], checkpoints, modelCalls, openedAs, recordedCatalog, currentCatalog);
                outcomes.push(outcome);
                if (outcome.promoted)
                    wrote = true;
                done.add(path);
            }));
            ledger.stage = stage;
            await persist(host, book, ledger);
        }
        const fixtures = stage === 'implement' && catalogPrep && derivedObligations.obligations.length > 0
            ? await runFixtureStage(request, host, ledger, request.flow ? await preferDiskDefinitions(host, request.units) : merged, derivedObligations.obligations, catalogPrep, checkpoints)
            : undefined;
        const endedName = ledger.callsExhausted && outcomes.some(item => item.code === 'BUDGET_CALLS')
            ? 'BUDGET_CALLS'
            : 'COMPLETED';
        if (request.eventId) {
            ledger.events.push({
                id: request.eventId,
                ended: endedName,
                units: outcomes.map(unit => ({ defPath: unit.defPath, code: unit.code, promoted: unit.promoted })),
            });
            ledger.stage = stage;
            await persist(host, book, ledger);
        }
        const catalogRecord = catalogPrep && catalogPrep.action !== 'conflict'
            ? { ref: catalogPrep.ref, hash: catalogPrep.inputHash }
            : null;
        await persistOwned(host, request.moduleName, request.units.map(unit => unit.defPath), catalogRecord);
        const registration = host.l5
            ? await commitL5Registration(await registrationInput(request, host, snapshot, profile.allowsStubRun), host.l5, holder)
            : await reconcileRegistration(request, host, snapshot, profile.allowsStubRun);
        if (!host.l5 && registration.action === 'patch' && registration.nextText !== null) {
            const target = registration.effectiveSource === 'l5/runtime.project.json'
                ? runtimeProjectJsonRef(request.project)
                : projectJsonRef(request.project);
            await host.state.writeOwned(target, new TextEncoder().encode(registration.nextText));
            wrote = true;
        }
        if (host.l5 && registration.action === 'patch')
            wrote = true;
        return finish(request, profile, budget, snapshot, ledger, orderOutcomes(snapshot, outcomes), checkpoints, modelCalls.count - (stored && stored !== 'missing' ? stored.calls : 0), wrote, endedName, stage, catalogPrep, registration, fixtures);
    }
    finally {
        if (host.writer)
            await host.writer.release(request.moduleName, holder);
    }
}
async function runUnit(request, host, stage, profile, budget, ledger, unit, definition, deps, checkpoints, modelCalls, openedAs, recordedCatalog, currentCatalog) {
    const prior = ledger.units[unit.defPath];
    const finishedAs = prior?.stage ?? openedAs;
    const reopen = await failedEvidenceMoved(host, unit, recordedCatalog, currentCatalog);
    if (prior?.ended && prior.ended !== 'INTERRUPTED' && finishedAs === stage) {
        const success = prior.ended === 'PROMOTED' || prior.ended === 'REUSE' || prior.ended === 'VERIFIED';
        if (success && (unit.action === 'reuse' || unit.action === 'verify')) {
            const code = unit.action === 'verify' ? 'VERIFIED' : 'REUSE';
            return outcome(unit.defPath, code, unit.reason, false, 0);
        }
        if (!success && await sameSemantic(host, unit.defPath, definition) && !releasedBlock(definition, unit.action) && !await failureRecipeChanged(host, unit.defPath, stage) && !reopen) {
            return outcome(unit.defPath, prior.ended, 'Resume kept the failed attempt. The budget was not reset.', false, 0);
        }
    }
    if (reopen) {
        await writeDefStatus(host, unit.defPath, 'pending');
        if (unit.action === 'blocked' && unit.reason.startsWith('STATUS_FAILED')) {
            unit.action = 'verify';
            unit.reason = 'VERIFY: catalog or test changed; the failed attempt is checked again.';
        }
    }
    if (unit.action === 'blocked'
        && unit.heldAction
        && unit.blockedBy.length > 0
        && unit.blockedBy.every(path => dependencyOk(ledger.units[path]?.ended || ''))) {
        const restored = unit.heldAction;
        unit.action = restored;
        const label = restored === 'reuse' ? 'REUSE' : restored === 'verify' ? 'VERIFY' : 'GENERATE';
        unit.reason = `${label}: a dependency that blocked this unit passed in this run.`;
    }
    // Importing the structure stub before emit leaves that module loaded for the new catalog.
    if (stage === 'implement' && unit.action === 'verify' && await structureScaffoldOnDisk(host, unit.defPath)) {
        unit.action = 'generate';
        unit.reason = 'GENERATE: catalog or test changed; the output is still a structure scaffold.';
    }
    if (unit.action === 'conflict') {
        await writeConflictReceipt(request, host, unit, definition, codeOf(unit.reason, 'LOCAL_EDIT'), unit.reason);
        return remember(ledger, unit.defPath, outcome(unit.defPath, codeOf(unit.reason, 'LOCAL_EDIT'), unit.reason, false, 0));
    }
    if (unit.action === 'blocked') {
        if (!unit.reason.startsWith('BLOCKED_BY:') && !unit.reason.startsWith('STATUS_')) {
            await writeBlockedReceipt(request, host, unit, definition, codeOf(unit.reason, 'BLOCKED'), unit.reason);
            await writeDefStatus(host, unit.defPath, 'blocked');
        }
        return remember(ledger, unit.defPath, outcome(unit.defPath, codeOf(unit.reason, 'BLOCKED'), unit.reason, false, 0));
    }
    if (unit.action === 'reuse') {
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'REUSE', unit.reason, false, 0));
    }
    if (unit.action === 'remove') {
        const output = outputPathFromDefPath(unit.defPath);
        const previous = await host.state.readReceipt(unit.defPath);
        const owned = [...new Set([
                ...(output ? [output] : []),
                ...Object.keys(previous?.outputHashes ?? {}),
            ])];
        await host.state.removeOwned(owned, owned);
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'REMOVE', unit.reason, false, 0));
    }
    if (unit.action === 'verify' || stage === 'verify') {
        if (unit.action === 'generate') {
            return remember(ledger, unit.defPath, outcome(unit.defPath, 'NOT_READY', 'Verify does not generate. The output is not an accepted implementation.', false, 0));
        }
        // The agent runs in the browser and does not run a case (m1_33, m1_34): verify checks that the
        // accepted output is intact. The case verdict is the monitor's and does not decide here.
        const unready = await outputUnintact(host, unit.defPath);
        return remember(ledger, unit.defPath, outcome(unit.defPath, unready ? 'CHECKPOINT_FAILED' : 'VERIFIED', unready ? `${unit.defPath} ${unready}.` : 'Output intact against its receipt. Cases are verified by the monitor.', false, 0));
    }
    if (stage === 'implement' && unit.action !== 'generate') {
        return remember(ledger, unit.defPath, outcome(unit.defPath, codeOf(unit.reason, 'BLOCKED'), unit.reason, false, 0));
    }
    if (deps.some(path => !dependencyOk(ledger.units[path]?.ended || ''))) {
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'BLOCKED_BY', `A dependency failed. ${unit.defPath} was not started.`, false, 0));
    }
    const handler = handlerFor(unit.artifactType, stage === 'implement' ? 'implement' : 'structure');
    if (!handler || handler.id !== unit.handlerId || handler.stage !== (stage === 'implement' ? 'implement' : 'structure')) {
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'NO_NAMED_HANDLER', unit.reason || `No ${stage} handler is registered for ${unit.artifactType || 'this type'}. No file was written.`, false, 0));
    }
    const runner = host.runners[handler.id];
    if (!runner) {
        await writeBlockedReceipt(request, host, unit, definition, 'HANDLER_UNBOUND', `${handler.id} has no executor. No generic file was written.`);
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'HANDLER_UNBOUND', `${handler.id} has no executor. No generic file was written.`, false, 0));
    }
    const before = await fingerprint(host.io, unit);
    const revisionBefore = await host.state.readRevision(unit.defPath);
    const first = await attempt(request, host, stage, profile, budget, ledger, unit, definition, handler, runner, false, modelCalls);
    if (first.kind === 'promoted' || first.kind === 'held') {
        const promoted = await promote(request, host, unit, definition, before, revisionBefore, first.files, first.checkpoint, first.runsStub, first.kind === 'held' ? 'BLOCKED' : 'PROMOTED', first.evidences);
        if (promoted.checkpoint)
            checkpoints.push(promoted.checkpoint);
        return remember(ledger, unit.defPath, promoted.outcome);
    }
    if (first.checkpoint)
        checkpoints.push(first.checkpoint);
    if (!repairable(first.code) || sameSignature(ledger, unit.defPath, first.code)) {
        const code = sameSignature(ledger, unit.defPath, first.code) ? 'REPEATED_FAILURE' : first.code;
        await writeBlockedReceipt(request, host, unit, definition, code, first.detail);
        return remember(ledger, unit.defPath, outcome(unit.defPath, code, first.detail, false, first.modelCalls), first.code);
    }
    if (!noteRepair(ledger, budget, unit.defPath)) {
        await writeBlockedReceipt(request, host, unit, definition, 'REPAIR_BUDGET', first.detail);
        return remember(ledger, unit.defPath, outcome(unit.defPath, 'REPAIR_BUDGET', first.detail, false, first.modelCalls), first.code);
    }
    const second = await attempt(request, host, stage, profile, budget, ledger, unit, definition, handler, runner, true, modelCalls);
    if (second.kind === 'promoted') {
        const promoted = await promote(request, host, unit, definition, before, revisionBefore, second.files, second.checkpoint, second.runsStub, 'PROMOTED', second.evidences);
        if (promoted.checkpoint)
            checkpoints.push(promoted.checkpoint);
        return remember(ledger, unit.defPath, {
            ...promoted.outcome,
            modelCalls: first.modelCalls + promoted.outcome.modelCalls,
        });
    }
    if (second.checkpoint)
        checkpoints.push(second.checkpoint);
    const repeated = second.code === first.code;
    const code = repeated ? 'REPEATED_FAILURE' : second.code;
    await writeBlockedReceipt(request, host, unit, definition, code, second.detail);
    return remember(ledger, unit.defPath, outcome(unit.defPath, code, second.detail, false, first.modelCalls + second.modelCalls), second.code);
}
async function attempt(request, host, stage, profile, budget, ledger, unit, definition, handler, runner, repair, modelCalls) {
    let modelText = null;
    let usedModel = 0;
    if (unit.needsLlm || shouldCallModel(stage, handler)) {
        if (!host.llm) {
            return { kind: 'failed', code: 'LLM_UNAVAILABLE', detail: `${unit.defPath} needs a model and none is configured.`, files: {}, checkpoint: null, modelCalls: 0, runsStub: false };
        }
        if (!noteModelCall(ledger, budget)) {
            return { kind: 'failed', code: 'BUDGET_CALLS', detail: `Model call ceiling ${budget.callsPerRun} is already used.`, files: {}, checkpoint: null, modelCalls: 0, runsStub: false };
        }
        modelCalls.count = ledger.calls;
        usedModel = 1;
        try {
            modelText = await invokeModel(host.llm, {
                prompt: unit.prompt,
                signal: request.signal ?? new AbortController().signal,
                eventId: `${request.eventId || request.moduleName}:${unit.defPath}:${repair ? 'repair' : 'call'}`,
            }, budget.timeoutMs);
        }
        catch (error) {
            const mapped = asCallError(error);
            return { kind: 'failed', code: mapped.code, detail: mapped.message, files: {}, checkpoint: null, modelCalls: usedModel, runsStub: false };
        }
    }
    const unitState = touch(ledger, unit.defPath);
    unitState.calls += 1;
    let produced;
    try {
        produced = await withTimeout(signal => runner({
            handler,
            unit,
            definition,
            read: ref => host.io.read(ref),
            catalogRef: host.catalogRef || '',
            repair,
            signal,
            eventId: `${unit.defPath}:${unitState.calls}`,
            profile,
            modelText,
            moduleDefinitions: request.units.map(item => item.definition),
        }), budget.timeoutMs);
    }
    catch (error) {
        const mapped = asCallError(error);
        return { kind: 'failed', code: mapped.code, detail: mapped.message, files: {}, checkpoint: null, modelCalls: usedModel, runsStub: false };
    }
    if (produced.failure) {
        return { kind: 'failed', code: produced.failure.code, detail: produced.failure.detail, files: {}, checkpoint: null, modelCalls: usedModel, runsStub: produced.runsStub };
    }
    if ((produced.seeds && !profile.allowsSeeds) || (produced.resets && !profile.allowsReset) || (produced.runsStub && !profile.allowsStubRun)) {
        return {
            kind: 'failed',
            code: 'PROFILE_REFUSED',
            detail: `appEnv='${profile.mode}' refuses seeds, reset or running a stub.`,
            files: {},
            checkpoint: null,
            modelCalls: usedModel,
            runsStub: produced.runsStub,
        };
    }
    const output = outputPathFromDefPath(unit.defPath);
    const foreign = Object.keys(produced.files).filter(path => path !== output);
    if (foreign.length > 0 || !output) {
        return {
            kind: 'failed',
            code: 'WRITE_OUTSIDE_TARGET',
            detail: `Refused ${foreign.join(', ') || 'an empty output path'}. Nothing was written.`,
            files: {},
            checkpoint: null,
            modelCalls: usedModel,
            runsStub: produced.runsStub,
        };
    }
    // The agent does not execute generated code (m1_33). The gate reads only a broken compile/import,
    // a throw or a def gap; a case not observed does not block (m1_34).
    const checkpoint = await checkUnit(request, host, unit, produced.observations);
    if (!checkpoint.accepted && heldBlock(checkpoint)) {
        const blocked = checkpoint.evidence.filter(item => item.verdict === 'blocked').map(item => item.caseId);
        return {
            kind: 'held',
            code: 'BLOCKED',
            detail: `External gap on ${blocked.join(', ')}. The file is written and the unit is not generated.`,
            files: produced.files,
            checkpoint,
            modelCalls: usedModel,
            runsStub: produced.runsStub,
            evidences: produced.evidences,
        };
    }
    if (!checkpoint.accepted) {
        return { kind: 'failed', code: 'CHECKPOINT_FAILED', detail: checkpoint.nextAction, files: {}, checkpoint, modelCalls: usedModel, runsStub: produced.runsStub };
    }
    return {
        kind: 'promoted', code: 'PROMOTED', detail: checkpoint.nextAction, files: produced.files, checkpoint,
        modelCalls: usedModel, runsStub: produced.runsStub, evidences: produced.evidences,
    };
}
/** '' when the unit's output is the accepted one: intact against a receipt with no failure, implemented when the type has an implement handler. */
async function unitUnready(host, defPath) {
    const intact = await outputUnintact(host, defPath);
    if (intact)
        return intact;
    const receipt = await host.state.readReceipt(defPath);
    if (!receipt)
        return 'has no receipt';
    const implemented = handlerFor(receipt.artifactType, 'implement') ? receipt.stage === 'verify' : receipt.stage !== 'plan';
    return implemented ? '' : `is not implemented (receipt stage ${receipt.stage})`;
}
/** '' when the output is intact against a receipt with no failure, at any stage. */
async function outputUnintact(host, defPath) {
    const receipt = await host.state.readReceipt(defPath);
    if (!receipt)
        return 'has no receipt';
    if (receipt.failures.length > 0)
        return `failed (${receipt.failures.map(item => item.code).join(', ')})`;
    const output = outputPathFromDefPath(defPath);
    const body = output ? await host.io.read(output) : null;
    if (body === null)
        return 'has no output';
    if (receipt.outputHashes[output] !== await contentHash(body))
        return 'output does not match its receipt';
    return '';
}
/**
 * Runs the certification fixture after the units (run/fixtureRun.ts), persists the report,
 * adds one checkpoint per controller that ran and keeps the controller receipt's fixture row
 * equal to the latest verdict. Unit outcomes, ledger and def status are not changed here.
 */
async function runFixtureStage(request, host, ledger, units, obligations, catalogPrep, checkpoints) {
    const ref = fixtureReportRef(request.moduleName);
    const stored = await host.state.readOwned(ref);
    const previous = parseFixtureReport(stored && stored.byteLength > 0 ? new TextDecoder().decode(stored) : null, request.moduleName);
    const entries = await fixturePass({
        moduleName: request.moduleName,
        units,
        obligations,
        oracleSources: catalogPrep.oracleSources,
        unready: path => unitUnready(host, path),
        read: path => host.io.read(path),
        previous,
        execute: null,
        hostGap: 'FIXTURE_HOST_UNAVAILABLE: the agent runs in the browser and does not execute code; the memory proof did not run.',
        mode: request.profileMode,
        runStamp: `${request.project}.${Date.now().toString(36)}${Math.random().toString(16).slice(2, 8)}`,
    });
    const now = host.now ? host.now() : new Date().toISOString();
    for (const entry of entries) {
        const checkpoint = fixtureCheckpoint(entry, `${request.project}:${request.moduleName}`, host.commit || '', now);
        if (checkpoint)
            checkpoints.push(checkpoint);
        const receipt = await host.state.readReceipt(entry.controller);
        if (!receipt)
            continue;
        const row = fixtureVerification(entry);
        const kept = receipt.verifications.filter(item => item.id !== M1_FIXTURE_CHECK);
        const verifications = row ? [...kept, row] : kept;
        if (canonicalJson(verifications) === canonicalJson(receipt.verifications))
            continue;
        await host.state.writeReceipt({ ...receipt, verifications });
    }
    const next = renderFixtureReport({
        schemaVersion: M1_FIXTURE_REPORT_SCHEMA,
        moduleName: request.moduleName,
        entries: { ...(previous?.entries ?? {}), ...Object.fromEntries(entries.map(entry => [entry.controller, entry])) },
    });
    if (!stored || new TextDecoder().decode(stored) !== next)
        await host.state.writeOwned(ref, new TextEncoder().encode(next));
    return entries;
}
/** A def gap with an owner and nothing broken. The output is kept. A case that did not run is not a block (m1_34). */
function heldBlock(checkpoint) {
    const counts = checkpoint.counts;
    if (counts.failed > 0 || counts.skipped > 0 || counts.blocked === 0)
        return false;
    return checkpoint.evidence.every(item => item.verdict === 'passed' || item.verdict === 'blocked');
}
async function promote(request, host, unit, definition, before, revisionBefore, files, checkpoint, scaffold, receiptCode = 'PROMOTED', evidences) {
    const output = outputPathFromDefPath(unit.defPath);
    const body = files[output];
    if (typeof body !== 'string') {
        return { outcome: outcome(unit.defPath, 'INVALID_RESPONSE', 'The handler returned no output file.', false, 0), checkpoint };
    }
    await boundary(host, 'before-promote');
    const after = await fingerprint(host.io, unit);
    const revisionNow = await host.state.readRevision(unit.defPath);
    if (before !== after || revisionBefore !== revisionNow) {
        await writeBlockedReceipt(request, host, unit, definition, 'SNAPSHOT_CHANGED', 'The source changed during the call. The previous output was kept.');
        return {
            outcome: outcome(unit.defPath, 'SNAPSHOT_CHANGED', 'The source changed during the call. The previous output was kept.', false, 0),
            checkpoint,
        };
    }
    const current = await host.io.read(output);
    const previous = await host.state.readReceipt(unit.defPath);
    const recorded = previous?.outputHashes[output];
    if (current !== null && typeof recorded === 'string' && recorded.length > 0 && await contentHash(current) !== recorded) {
        await writeConflictReceipt(request, host, unit, definition, 'LOCAL_EDIT', 'The output was edited. It was not overwritten.');
        return {
            outcome: outcome(unit.defPath, 'LOCAL_EDIT', 'The output was edited. It was not overwritten.', false, 0),
            checkpoint,
        };
    }
    const staged = stagingRef(request.moduleName, output);
    await host.state.writeOwned(staged, new TextEncoder().encode(body));
    await boundary(host, 'staging');
    const revisionAfterStage = await host.state.readRevision(unit.defPath);
    const afterStage = await fingerprint(host.io, unit);
    if (revisionAfterStage !== revisionNow || afterStage !== after) {
        await host.state.removeOwned([staged], [staged]);
        await writeBlockedReceipt(request, host, unit, definition, 'SNAPSHOT_CHANGED', 'The source changed during the call. The previous output was kept.');
        return {
            outcome: outcome(unit.defPath, 'SNAPSHOT_CHANGED', 'The source changed during the call. The previous output was kept.', false, 0),
            checkpoint,
        };
    }
    await host.state.writeOwned(output, new TextEncoder().encode(body));
    await writePromotedTest(host, unit.defPath);
    await boundary(host, 'output');
    const accepted = receiptCode === 'PROMOTED';
    await writeReceipt(request, host, unit, definition, output, body, checkpoint, receiptCode, accepted ? '' : (checkpoint?.nextAction || receiptCode), scaffold, evidences);
    await boundary(host, 'receipt');
    const nextStatus = accepted ? statusForPromotion(true, scaffold) : 'blocked';
    if (nextStatus)
        await writeDefStatus(host, unit.defPath, nextStatus);
    await boundary(host, 'status');
    await host.state.removeOwned([staged], [staged]);
    return {
        outcome: outcome(unit.defPath, receiptCode, checkpoint?.nextAction || (accepted ? 'Promoted.' : receiptCode), accepted, 0),
        checkpoint,
    };
}
async function checkUnit(request, host, unit, observations) {
    const stage = request.stage === 'implement' ? 'implement' : 'structure';
    const handler = handlerFor(unit.artifactType, stage) ?? {
        id: unit.handlerId || 'missing',
        artifactType: 'usecase',
        stage,
        needsLlm: false,
        capabilities: [],
    };
    const now = host.now ? host.now() : new Date().toISOString();
    return gateBatch({
        handler,
        io: host.io,
        catalogRef: host.catalogRef || '',
        artifactId: unit.artifactId,
        observations,
        runId: `${request.project}:${request.moduleName}`,
        commit: host.commit || '',
        startedAt: now,
        finishedAt: now,
        monitorError: host.monitorError ?? null,
    });
}
async function writeBlockedReceipt(request, host, unit, definition, code, detail) {
    await writeReceipt(request, host, unit, definition, '', '', null, code, detail, false);
}
async function writeReceipt(request, host, unit, definition, output, body, checkpoint, code, detail, scaffold, evidences) {
    const parsed = readDefinition(definition);
    if ('issues' in parsed)
        return;
    const path = receiptPathFor(unit.defPath);
    if (!path)
        return;
    const hash = await semanticHash(parsed);
    const outputHashes = output && body ? { [output]: await contentHash(body) } : {};
    const failed = code !== 'PROMOTED';
    const dependencyHashes = {};
    for (const dep of parsed.dependencies) {
        const text = await host.io.read(dep);
        if (text !== null)
            dependencyHashes[dep] = await hashEvidence(text);
    }
    const sourceHashes = { [unit.defPath]: hash };
    const testPath = output ? testFileFor(output) : '';
    if (testPath) {
        const testText = await host.io.read(testPath);
        if (testText !== null)
            sourceHashes[testPath] = await contentHash(testText);
    }
    const checkpointRow = checkpoint ? [{
            id: checkpoint.handlerId,
            kind: 'test',
            passed: checkpoint.accepted,
            detail: checkpoint.nextAction,
        }] : [];
    const receipt = {
        schemaVersion: '2026-09-24-m1-receipt-v1',
        runId: `${request.project}:${request.moduleName}`,
        candidateId: '',
        defPath: unit.defPath,
        artifactType: parsed.artifactType,
        artifactId: parsed.artifactId,
        recipeVersion: recipeForStage(request.stage === 'implement' ? 'implement' : 'structure'),
        semanticHash: hash,
        dependencyHashes,
        sourceHashes,
        outputHashes,
        stage: failed ? 'plan' : scaffold ? 'compile' : request.stage === 'implement' ? 'verify' : 'generate',
        verifications: [...checkpointRow, ...(evidences ?? [])],
        failures: failed ? [{ code, detail: detail || code }] : [],
        attempts: 1,
        reason: failed ? `${code}: ${detail}` : scaffold ? 'scaffold' : '',
    };
    await host.state.writeReceipt(receipt);
    if (FAILED_STATUS.has(code))
        await writeDefStatus(host, unit.defPath, 'failed');
}
const FAILED_STATUS = new Set([
    'REPEATED_FAILURE', 'REPAIR_BUDGET', 'BUDGET_CALLS', 'NETWORK_UNAVAILABLE',
    'TIMEOUT', 'INVALID_RESPONSE', 'CALL_FAILED', 'CHECKPOINT_FAILED',
]);
async function writeConflictReceipt(request, host, unit, definition, code, detail) {
    const parsed = readDefinition(definition);
    if ('issues' in parsed)
        return;
    const path = receiptPathFor(unit.defPath);
    if (!path)
        return;
    const previous = await host.state.readReceipt(unit.defPath);
    const hash = await semanticHash(parsed);
    const receipt = {
        schemaVersion: '2026-09-24-m1-receipt-v1',
        runId: `${request.project}:${request.moduleName}`,
        candidateId: previous?.candidateId ?? '',
        defPath: unit.defPath,
        artifactType: parsed.artifactType,
        artifactId: parsed.artifactId,
        recipeVersion: previous?.recipeVersion || M1_RECIPE_VERSION,
        semanticHash: hash,
        dependencyHashes: previous?.dependencyHashes ?? {},
        sourceHashes: previous?.sourceHashes ?? { [unit.defPath]: hash },
        outputHashes: previous?.outputHashes ?? {},
        stage: 'plan',
        verifications: previous?.verifications ?? [],
        failures: [{ code, detail: detail || code }],
        attempts: previous?.attempts ?? 1,
        reason: `${code}: ${detail}`,
    };
    await host.state.writeReceipt(receipt);
}
async function writeDefStatus(host, defPath, status) {
    const text = await host.io.read(defPath);
    if (!text)
        return;
    const next = replaceStatus(text, status);
    if (!next || next === text)
        return;
    await host.state.writeOwned(defPath, new TextEncoder().encode(next));
}
async function boundary(host, name) {
    if (host.onBoundary)
        await host.onBoundary(name);
}
async function preferDiskDefinitions(host, units) {
    const merged = [];
    for (const unit of units) {
        const text = await host.io.read(unit.defPath);
        if (!text) {
            merged.push(unit);
            continue;
        }
        const parsed = parseDefinitionSource(text);
        merged.push('definition' in parsed ? { defPath: unit.defPath, definition: parsed.definition } : unit);
    }
    return merged;
}
function releasedBlock(definition, action) {
    if (action !== 'generate')
        return false;
    const parsed = readDefinition(definition);
    return !('issues' in parsed) && parsed.status === 'blocked';
}
/** The bytes on disk are still the structure stub, even when a later failed receipt replaced the compile receipt. */
async function structureScaffoldOnDisk(host, defPath) {
    const receipt = await host.state.readReceipt(defPath);
    if (receipt?.stage === 'compile' && receipt.reason === 'scaffold')
        return true;
    const output = outputPathFromDefPath(defPath);
    if (!output)
        return false;
    const body = await host.io.read(output);
    return !!body && body.includes(`'${M1_STUB_ERROR}'`);
}
/** Catalog or test drift releases this failed receipt only. Other ledger rows and the budget stay. */
async function failedEvidenceMoved(host, unit, recordedCatalog, currentCatalog) {
    const receipt = await host.state.readReceipt(unit.defPath);
    if (!receipt)
        return false;
    const output = outputPathFromDefPath(unit.defPath);
    const testPath = output ? testFileFor(output) : '';
    const testText = testPath ? await host.io.read(testPath) : null;
    const testHash = testText === null ? null : await contentHash(testText);
    return failureNeedsReverify(receipt, testPath, testHash, recordedCatalog, currentCatalog);
}
/** An older handler recipe releases this unit only. Other ledger rows and the budget stay. */
async function failureRecipeChanged(host, defPath, stage) {
    const receipt = await host.state.readReceipt(defPath);
    if (!receipt || receipt.failures.length === 0)
        return false;
    const current = recipeForStage(stage === 'implement' ? 'implement' : 'structure');
    if (receipt.recipeVersion === current)
        return false;
    return receipt.failures.some(item => item.code === 'LLM_UNAVAILABLE' || item.code.length > 0);
}
async function sameSemantic(host, defPath, definition) {
    const parsed = readDefinition(definition);
    if ('issues' in parsed)
        return false;
    const receipt = await host.state.readReceipt(defPath);
    if (!receipt)
        return false;
    return receipt.semanticHash === await semanticHash(parsed);
}
async function ownedRemovals(host, moduleName, units) {
    const bytes = await host.state.readOwned(ownedManifestRef(moduleName));
    if (!bytes || bytes.byteLength === 0)
        return [];
    const manifest = parseOwnedManifest(new TextDecoder().decode(bytes), moduleName);
    if (!manifest)
        return [];
    const present = new Set(units.map(unit => unit.defPath));
    return manifest.units.map(unit => unit.defPath).filter(path => !present.has(path));
}
async function ownedCatalogHash(host, moduleName, ref) {
    const bytes = await host.state.readOwned(ownedManifestRef(moduleName));
    if (!bytes || bytes.byteLength === 0)
        return null;
    const manifest = parseOwnedManifest(new TextDecoder().decode(bytes), moduleName);
    if (!manifest?.catalogHash || manifest.catalogRef !== ref)
        return null;
    return manifest.catalogHash;
}
async function persistOwned(host, moduleName, defPaths, catalog) {
    const previousBytes = await host.state.readOwned(ownedManifestRef(moduleName));
    const previous = previousBytes && previousBytes.byteLength > 0
        ? parseOwnedManifest(new TextDecoder().decode(previousBytes), moduleName)
        : null;
    const units = defPaths.map(defPath => {
        const output = outputPathFromDefPath(defPath);
        return { defPath, outputs: output ? [output] : [] };
    });
    const kept = !catalog && previous?.catalogHash
        ? { catalogRef: previous.catalogRef, catalogHash: previous.catalogHash }
        : {};
    const recorded = catalog ? { catalogRef: catalog.ref, catalogHash: catalog.hash } : kept;
    await host.state.writeOwned(ownedManifestRef(moduleName), new TextEncoder().encode(renderOwnedManifest({
        schemaVersion: M1_OWNED_SCHEMA,
        moduleName,
        units,
        ...recorded,
    })));
}
function dependencyOk(ended) {
    return ended === 'PROMOTED' || ended === 'REUSE' || ended === 'VERIFIED';
}
function repairable(code) {
    return code === 'TIMEOUT' || code === 'TRANSIENT' || code === 'INVALID_RESPONSE' || code === 'CHECKPOINT_FAILED' || code === 'CALL_FAILED';
}
function sameSignature(ledger, defPath, code) {
    return ledger.units[defPath]?.signature === code && code !== '';
}
function remember(ledger, defPath, value, signature = '') {
    const unit = touch(ledger, defPath);
    unit.ended = value.code;
    unit.stage = ledger.stage;
    if (signature)
        unit.signature = signature;
    else if (!unit.signature && value.code !== 'PROMOTED')
        unit.signature = value.code;
    return value;
}
function touch(ledger, defPath) {
    const current = ledger.units[defPath];
    if (current)
        return current;
    const created = { repairs: 0, calls: 0, signature: '', ended: '' };
    ledger.units[defPath] = created;
    return created;
}
function outcome(defPath, code, detail, promoted, modelCalls) {
    return { defPath, code, detail, promoted, modelCalls };
}
function codeOf(reason, fallback) {
    const name = reason.split(':')[0];
    return name || fallback;
}
async function fingerprint(io, unit) {
    const output = outputPathFromDefPath(unit.defPath);
    const refs = [unit.defPath, ...unit.contextRefs];
    if (output)
        refs.push(output);
    const parts = [];
    for (const ref of refs) {
        const text = await io.read(ref);
        parts.push(text === null ? `${ref}=missing` : `${ref}=${await contentHash(text)}`);
    }
    return parts.join('\n');
}
async function readLedger(host, path, project, moduleName) {
    const bytes = await host.state.readOwned(path);
    if (!bytes || bytes.byteLength === 0)
        return 'missing';
    const text = new TextDecoder().decode(bytes);
    const parsed = parseLedger(text, project, moduleName);
    return parsed ?? 'corrupt';
}
async function persist(host, path, ledger) {
    await host.state.writeOwned(path, new TextEncoder().encode(encodeLedger(ledger)));
}
async function withTimeout(work, timeoutMs) {
    const controller = new AbortController();
    let timer;
    const timeout = new Promise((_resolve, reject) => {
        timer = setTimeout(() => {
            controller.abort();
            reject(new MaterializeCallError('TIMEOUT', `Call exceeded ${timeoutMs}ms.`));
        }, timeoutMs);
    });
    try {
        return await Promise.race([work(controller.signal), timeout]);
    }
    catch (error) {
        if (error instanceof MaterializeCallError)
            throw error;
        const wrapped = new Error(error instanceof Error ? error.message : String(error));
        wrapped.code = 'CALL_FAILED';
        throw wrapped;
    }
    finally {
        if (timer)
            clearTimeout(timer);
    }
}
function asCallError(error) {
    if (error instanceof MaterializeCallError)
        return { code: error.code, message: error.message };
    if (error && typeof error === 'object') {
        const code = error.code;
        if (typeof code === 'string' && code) {
            return { code, message: error instanceof Error ? error.message : String(error) };
        }
    }
    return { code: 'CALL_FAILED', message: error instanceof Error ? error.message : String(error) };
}
function dependencyMap(units) {
    const known = new Set(units.map(unit => unit.defPath));
    const map = new Map();
    for (const unit of units) {
        const raw = isRecord(unit.definition) ? unit.definition : {};
        const dependencies = Array.isArray(raw.dependencies)
            ? raw.dependencies.filter((item) => typeof item === 'string' && known.has(item))
            : [];
        map.set(unit.defPath, dependencies);
    }
    return map;
}
function orderOutcomes(snapshot, outcomes) {
    const byPath = new Map(outcomes.map(item => [item.defPath, item]));
    return snapshot.order.map(path => byPath.get(path)).filter((item) => !!item);
}
function finish(request, profile, budget, snapshot, ledger, units, checkpoints, llmCalls, wrote, ended, stage, catalog, registration, fixtures) {
    return {
        schemaVersion: M1_RUN_SCHEMA,
        project: request.project,
        moduleName: request.moduleName,
        stage,
        flow: request.flow,
        profile,
        budget,
        snapshot,
        ledger,
        units,
        checkpoints,
        llmCalls,
        wrote,
        ended,
        catalog: catalog ?? undefined,
        registration: registration ?? undefined,
        ...(fixtures ? { fixtures } : {}),
    };
}
function projectJsonRef(project) {
    return `_${project}_/l5/project.json`;
}
function runtimeProjectJsonRef(project) {
    return `_${project}_/l5/runtime.project.json`;
}
async function registrationInput(request, host, snapshot, allowStructureStub) {
    const files = await loadRegistrationFiles(request.project, request.moduleName, snapshot.units, ref => host.io.read(ref));
    const catalogRef = host.catalogRef || null;
    if (catalogRef && !files.some(file => file.ref === catalogRef)) {
        files.push({ ref: catalogRef, source: await host.io.read(catalogRef), role: 'output' });
    }
    return {
        project: request.project,
        moduleName: request.moduleName,
        allowStructureStub,
        phase: allowStructureStub ? 'structure' : 'verified',
        files,
        catalogRef,
    };
}
async function reconcileRegistration(request, host, snapshot, allowStructureStub) {
    const input = await registrationInput(request, host, snapshot, allowStructureStub);
    return reconcileL5Backend({
        ...input,
        projectJson: await host.io.read(projectJsonRef(request.project)),
        runtimeProjectJson: await host.io.read(runtimeProjectJsonRef(request.project)),
    });
}
async function prepareCatalog(request, host, snapshot, units, write, recordedHash, derivedOut) {
    const ref = host.catalogRef || '';
    const texts = {};
    for (const unit of units) {
        const own = await host.io.read(unit.defPath);
        if (own)
            texts[unit.defPath] = own;
        const raw = isRecord(unit.definition) ? unit.definition : {};
        const dependencies = Array.isArray(raw.dependencies) ? raw.dependencies.filter((item) => typeof item === 'string') : [];
        for (const dependency of dependencies) {
            if (texts[dependency])
                continue;
            const text = await host.io.read(dependency);
            if (text)
                texts[dependency] = text;
        }
    }
    const withheld = catalogWithheld(snapshot.units, new Set(Object.keys(host.runners)), await promotedUnits(host, snapshot.units));
    const derived = deriveCatalog(request.moduleName, units, texts, withheld);
    const inputHash = await contentHash(catalogBytes(derived.catalog));
    const oracleSources = await obligationSourceHashes(derived.obligations, texts);
    derivedOut.obligations = derived.obligations;
    const existing = await host.io.read(ref);
    if (existing === null) {
        if (write)
            await writeDerived(host, ref, derived.catalog, null);
        return {
            ref,
            action: write ? 'written' : 'simulated',
            inputHash,
            recipeVersion: derived.recipeVersion,
            gaps: derived.gaps,
            oracleSources,
            detail: write ? 'catalog written from defs' : 'catalog planned; nothing written',
        };
    }
    const parsed = parseCatalog(existing);
    if (!parsed.catalog) {
        return {
            ref,
            action: 'invalid',
            inputHash,
            recipeVersion: derived.recipeVersion,
            gaps: derived.gaps,
            oracleSources,
            detail: parsed.issues.join('; ') || 'catalog unreadable',
        };
    }
    if (canonicalJson(parsed.catalog) !== catalogBytes(derived.catalog)) {
        const existingHash = await contentHash(catalogBytes(parsed.catalog));
        const ownedHash = await ownedCatalogHash(host, request.moduleName, ref);
        const known = new Set();
        if (recordedHash)
            known.add(recordedHash);
        if (ownedHash)
            known.add(ownedHash);
        const emitted = existing.startsWith(`/// <mls fileReference="${ref}"`);
        // A ledger hash that already equals the derived catalog was stored without rewriting the file.
        // Only an emitted catalog is M1 output. A fixture or a hand file with the same ledger hash stays a conflict.
        const ledgerAhead = !!recordedHash && recordedHash === inputHash && !ownedHash && emitted;
        const unrecordedEmission = emitted && !ownedHash;
        if (known.has(existingHash) || ledgerAhead || unrecordedEmission) {
            if (write)
                await writeDerived(host, ref, derived.catalog, parsed.catalog);
            return {
                ref,
                action: write ? 'written' : 'simulated',
                inputHash,
                recipeVersion: derived.recipeVersion,
                gaps: derived.gaps,
                oracleSources,
                detail: write
                    ? 'catalog matched the M1 receipt and was rewritten'
                    : 'catalog matches the M1 receipt; rewrite planned, nothing written',
            };
        }
        return {
            ref,
            action: 'conflict',
            inputHash,
            recipeVersion: derived.recipeVersion,
            gaps: derived.gaps,
            oracleSources,
            detail: 'existing catalog differs from the derived catalog; it was not overwritten',
        };
    }
    if (write)
        await rewriteLegacyTests(host, parsed.catalog);
    return {
        ref,
        action: 'unchanged',
        inputHash,
        recipeVersion: derived.recipeVersion,
        gaps: derived.gaps,
        oracleSources,
        detail: 'catalog already matches the defs',
    };
}
/**
 * Units whose output was promoted once: the receipt lists the output hash. The output and the
 * test of the structure stay on disk, so the catalog keeps their scenarios (m1_32). The receipt,
 * not the owned manifest, because the receipt is written with the promotion of that unit.
 */
async function promotedUnits(host, units) {
    const promoted = new Set();
    for (const unit of units) {
        const output = outputPathFromDefPath(unit.defPath);
        if (!output)
            continue;
        const receipt = await host.state.readReceipt(unit.defPath);
        if (receipt?.outputHashes && typeof receipt.outputHashes[output] === 'string')
            promoted.add(unit.defPath);
    }
    return promoted;
}
async function writeDerived(host, ref, catalog, previous) {
    await host.state.writeOwned(ref, new TextEncoder().encode(renderMonitorCatalog(catalog, ref)));
    const priorCases = new Map((previous?.scenarios ?? []).map(scenario => [scenario.scenarioId, canonicalJson(scenario.cases)]));
    for (const scenario of catalog.scenarios) {
        if (!scenario.testFile || scenario.cases.length === 0)
            continue;
        const current = await host.io.read(scenario.testFile);
        const next = renderScenarioTest(scenario);
        if (current === next)
            continue;
        // A node runner this agent rendered before m1_35 is replaced whatever the rules below say.
        if (current !== null && isLegacyNodeTest(current, scenario.testFile)) {
            await host.state.writeOwned(scenario.testFile, new TextEncoder().encode(next));
            continue;
        }
        // A first catalog does not clobber a test that is already on disk.
        if (current !== null && previous === null)
            continue;
        // Same cases and the unit was not promoted: leave the bytes alone.
        if (current !== null && previous !== null && priorCases.get(scenario.scenarioId) === canonicalJson(scenario.cases))
            continue;
        await host.state.writeOwned(scenario.testFile, new TextEncoder().encode(next));
    }
}
/** The catalog did not move, but a test on disk may still be a pre-m1_35 node runner: only those are rewritten. */
async function rewriteLegacyTests(host, catalog) {
    for (const scenario of catalog.scenarios) {
        if (!scenario.testFile || scenario.cases.length === 0)
            continue;
        const current = await host.io.read(scenario.testFile);
        if (current === null || !isLegacyNodeTest(current, scenario.testFile))
            continue;
        await host.state.writeOwned(scenario.testFile, new TextEncoder().encode(renderScenarioTest(scenario)));
    }
}
/** Promotion rewrites this unit's test from the catalog just written. Other tests stay put. */
async function writePromotedTest(host, defPath) {
    const ref = host.catalogRef || '';
    if (!ref)
        return;
    const raw = await host.io.read(ref);
    if (raw === null)
        return;
    const parsed = parseCatalog(raw);
    const scenario = parsed.catalog?.scenarios.find(item => item.source === defPath);
    if (!scenario?.testFile || scenario.cases.length === 0)
        return;
    const next = renderScenarioTest(scenario);
    const current = await host.io.read(scenario.testFile);
    if (current === next)
        return;
    await host.state.writeOwned(scenario.testFile, new TextEncoder().encode(next));
}
