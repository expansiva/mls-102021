/// <mls fileReference="_102021_/l2/agentMaterializeL1/run/fixtureRun.ts" enhancement="_blank"/>
/**
 * Certification fixture in the implement run (m1_30). After the units of the run are done, the
 * authenticated obligations of each controller (testing/obligations.ts) run in memory against
 * the emitted bytes through testing/fixture.ts `runFixture`, once per controller whose inputs
 * changed. Browser-safe: execution is a port; the agent runs in the browser and passes none
 * (m1_33), so the proof is inconclusive with an owner.
 * - An obligation runs only when every unit its route imports has an accepted, intact output
 *   (the caller reads the receipts); otherwise it stays pending with owner L1. A sibling route's
 *   usecase does not hold it back.
 * - The key hashes the harness recipe, the fixture plan, the oracle sources, the emitted bytes the
 *   obligations import, the obligations and their readiness. Same key: the stored proof is reused.
 * - Memory is the only proof here. Runtime (identity, MDM) stays pending with its owner.
 */
import { isRecord, outputPathFromDefPath, readDefinition, receiptFolder } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { contentHash } from '/_102021_/l2/agentMaterializeL1/core/io.js';
import { emittedValueExports } from '/_102021_/l2/agentMaterializeL1/handlers/structure/emit.js';
import { canonicalJson } from '/_102021_/l2/agentMaterializeL1/testing/catalog.js';
import { fixtureModelOf } from '/_102021_/l2/agentMaterializeL1/testing/derive.js';
import { M1_RUNTIME_OWNER, routeUsecases, runtimeGap } from '/_102021_/l2/agentMaterializeL1/testing/fixture.js';
import { M1_CHECKPOINT_BUDGET_MS, M1_CHECKPOINT_SCHEMA } from '/_102021_/l2/agentMaterializeL1/testing/verify.js';
export const M1_FIXTURE_REPORT_SCHEMA = '2026-09-28-m1-fixture-report-v1';
/** Harness recipe; a new one invalidates every stored proof. */
export const M1_FIXTURE_RECIPE = '2026-09-28-m1-fixture-run-v1';
/** Id of the verification row the controller receipt carries. */
export const M1_FIXTURE_CHECK = 'fixture.memory';
export const M1_FIXTURE_HOST_OWNER = 'L1 host';
export function fixtureReportRef(moduleName) {
    return `${receiptFolder(moduleName)}/fixtureReport.json`;
}
export function parseFixtureReport(text, moduleName) {
    if (!text)
        return null;
    try {
        const value = JSON.parse(text);
        if (!isRecord(value) || value.schemaVersion !== M1_FIXTURE_REPORT_SCHEMA || value.moduleName !== moduleName || !isRecord(value.entries))
            return null;
        return value;
    }
    catch {
        return null;
    }
}
export function renderFixtureReport(report) {
    return `${JSON.stringify(report, null, 2)}\n`;
}
/** One entry per controller with obligations. Writes nothing; the caller persists the report. */
export async function fixturePass(input) {
    const defs = new Map();
    for (const unit of input.units) {
        const parsed = readDefinition(unit.definition);
        if (!('issues' in parsed))
            defs.set(unit.defPath, parsed);
    }
    const model = fixtureModelOf(defs);
    // No plan: every obligation already carries FIXTURE_PLAN_ABSENT as a catalog gap.
    if (!model)
        return [];
    const seeds = [...defs.values()].find(item => item.artifactType === 'persistenceSeeds' && item.data.fixture !== undefined);
    const fixtureHash = await contentHash(canonicalJson(seeds?.data.fixture ?? null));
    const ports = [...defs.entries()].filter(([, definition]) => definition.artifactType === 'repositoryPort');
    const dataEntities = new Set(model.plan.datasets.map(item => item.entityId));
    const closure = (roots) => {
        const seen = new Set();
        const stack = [...roots];
        while (stack.length > 0) {
            const path = stack.pop() ?? '';
            if (!defs.has(path) || seen.has(path))
                continue;
            seen.add(path);
            stack.push(...(defs.get(path)?.dependencies ?? []));
        }
        return [...seen].sort();
    };
    const entries = [];
    for (const [controllerPath, controller] of defs) {
        if (controller.artifactType !== 'httpController')
            continue;
        const obligations = input.obligations.filter(item => item.sources.some(source => source.startsWith(`${controllerPath}#`)));
        if (obligations.length === 0)
            continue;
        // The controller and what it imports besides its route usecases (scope, authority map, contracts).
        const own = [controllerPath, ...closure(controller.dependencies.filter(path => defs.get(path)?.artifactType !== 'usecase'))];
        const ready = [];
        const unready = [];
        const imported = new Set([controllerPath]);
        for (const obligation of obligations) {
            const reached = routeUsecases(defs, controller, obligation.routine);
            const usecases = reached.length > 0 && reached.every(item => item) ? reached.flatMap(item => item ? [item[0]] : []) : [];
            const entities = new Set([...dataEntities, model.routeEntity.get(obligation.routine) ?? '']);
            const needed = [...new Set([...own, ...closure([...usecases, ...ports.filter(([, port]) => entities.has(String(port.data.entityId))).map(([path]) => path)])])].sort();
            const missing = usecases.length > 0 ? [] : [`usecase of ${obligation.routine} is not a unit`];
            for (const path of needed) {
                const why = await input.unready(path);
                if (why)
                    missing.push(`${path} ${why}`);
            }
            if (missing.length > 0) {
                unready.push({
                    caseId: obligation.caseId, memory: 'pending', owner: 'L1',
                    detail: `FIXTURE_DEPENDENCY_UNMATERIALIZED: ${missing.join(', ')}`,
                    runtime: 'pending', runtimeGap: runtimeGap(model.plan, obligation), runtimeOwner: M1_RUNTIME_OWNER,
                });
                continue;
            }
            ready.push(obligation);
            for (const path of needed)
                imported.add(path);
        }
        const outputs = {};
        for (const path of [...imported].sort()) {
            const output = outputPathFromDefPath(path);
            if (!output)
                continue;
            const text = await input.read(output);
            outputs[output] = text === null ? 'absent' : await contentHash(text);
        }
        const oracle = {};
        for (const ref of [...new Set(obligations.flatMap(item => item.sources.map(source => source.split('#')[0] ?? source)))].sort()) {
            oracle[ref] = input.oracleSources[ref] ?? 'absent';
        }
        const hashes = { recipe: M1_FIXTURE_RECIPE, fixture: fixtureHash, oracle, outputs };
        const key = await contentHash(canonicalJson({ hashes, obligations, ready: ready.map(item => item.caseId), mode: String(input.mode ?? '') }));
        const base = {
            controller: controllerPath, key, reused: false, executionId: '', proof: 'memory', runtime: 'pending',
            runtimeOwner: M1_RUNTIME_OWNER, hashes, unready,
        };
        const previous = input.previous?.entries[controllerPath];
        if (previous && previous.key === key && previous.status !== 'inconclusive') {
            entries.push({ ...previous, reused: true });
            continue;
        }
        if (ready.length === 0) {
            entries.push({ ...base, status: 'pending', owner: 'L1', detail: 'No obligation is ready: a unit it imports is not materialized.', counts: counts(unready, null), receipt: null });
            continue;
        }
        if (!input.execute) {
            entries.push({ ...base, status: 'inconclusive', owner: M1_FIXTURE_HOST_OWNER, detail: input.hostGap, counts: counts(unready, null), receipt: null });
            continue;
        }
        const executionId = `${input.runStamp}.${controller.artifactId}`;
        const files = {};
        for (const unit of input.units) {
            const output = outputPathFromDefPath(unit.defPath);
            const text = output ? await input.read(output) : null;
            if (output && text !== null)
                files[output] = text;
        }
        const loadPorts = ports
            .filter(([path, port]) => imported.has(path) || dataEntities.has(String(port.data.entityId)))
            .map(([path, port]) => ({ ref: outputPathFromDefPath(path), entityId: String(port.data.entityId), exportName: emittedValueExports(port)[0] ?? '' }));
        const project = /^(_\d+_)\//.exec(controllerPath)?.[1] ?? '';
        let ran;
        try {
            ran = await input.execute({
                module: { project, files, controllers: [outputPathFromDefPath(controllerPath)], ports: loadPorts },
                model, obligations: ready, runId: executionId, mode: input.mode,
            });
        }
        catch (error) {
            ran = { receipt: null, error: `FIXTURE_EXECUTOR_FAILED: ${error instanceof Error ? error.message : String(error)}` };
        }
        if (!ran.receipt) {
            entries.push({ ...base, executionId, status: 'inconclusive', owner: 'L1', detail: ran.error || 'the executor returned no receipt', counts: counts(unready, null), receipt: null });
            continue;
        }
        const receipt = { ...ran.receipt, cases: [...ran.receipt.cases, ...unready] };
        const failed = receipt.cases.filter(item => item.memory === 'failed');
        const passed = receipt.cases.filter(item => item.memory === 'passed');
        let status = 'pending';
        let owner = 'L1';
        let detail = '';
        if (receipt.phase === 'refused') {
            status = 'inconclusive';
            detail = receipt.refused;
        }
        else if (failed.length > 0 || receipt.ledger.residue.length > 0) {
            status = 'failed';
            detail = [...failed.map(item => `${item.caseId}: ${item.detail}`), ...receipt.ledger.residue.map(item => `residue ${item}`)].join('; ');
        }
        else if (passed.length > 0) {
            status = 'passed';
            owner = '';
            detail = `${passed.length} case(s) passed in memory; runtime proof pending (${M1_RUNTIME_OWNER}).`;
        }
        else {
            detail = 'No case ran in memory; every one keeps its gap.';
        }
        entries.push({ ...base, executionId, status, owner, detail, counts: counts(receipt.cases, receipt), receipt });
    }
    return entries;
}
function counts(cases, receipt) {
    return {
        cases: cases.length,
        passed: cases.filter(item => item.memory === 'passed').length,
        failed: cases.filter(item => item.memory === 'failed').length,
        pending: cases.filter(item => item.memory === 'pending').length,
        residue: receipt?.ledger.residue.length ?? 0,
    };
}
/** The run checkpoint of one entry: executed cases and residue; pending cases keep their gap in the report. */
export function fixtureCheckpoint(entry, runId, commit, at) {
    const rows = [];
    const row = (caseId, verdict, detail) => ({ caseId, verdict, errorCode: null, status: null, durationMs: 0, detail });
    if (entry.status === 'inconclusive')
        rows.push(row(`${entry.controller}#${M1_FIXTURE_CHECK}`, 'inconclusive', `${entry.owner}: ${entry.detail}`));
    for (const item of entry.receipt?.cases ?? []) {
        if (item.memory === 'passed')
            rows.push(row(item.caseId, 'passed', 'passed in memory'));
        if (item.memory === 'failed')
            rows.push(row(item.caseId, 'failed', item.detail));
    }
    for (const item of entry.receipt?.ledger.residue ?? [])
        rows.push(row(`${entry.controller}#cleanup`, 'failed', `residue ${item}`));
    if (rows.length === 0)
        return null;
    const tally = { passed: 0, expectedRed: 0, failed: 0, blocked: 0, skipped: 0, inconclusive: 0 };
    for (const item of rows)
        tally[item.verdict] += 1;
    const accepted = rows.every(item => item.verdict === 'passed');
    const bad = rows.find(item => item.verdict !== 'passed');
    return {
        schemaVersion: M1_CHECKPOINT_SCHEMA,
        runId,
        inputHash: entry.key,
        commit,
        stage: 'implement',
        handlerId: M1_FIXTURE_CHECK,
        startedAt: at,
        finishedAt: at,
        budgetMs: M1_CHECKPOINT_BUDGET_MS,
        counts: tally,
        durationsMs: { total: 0 },
        ready: false,
        accepted,
        evidence: rows,
        nextAction: accepted
            ? `Memory fixture accepted for ${entry.controller}; runtime proof pending (${M1_RUNTIME_OWNER}).`
            : `Fix ${bad?.caseId}: ${bad?.detail}. Do not weaken the assertion.`,
        monitor: { delivered: false, error: 'memory fixture is not a monitor result' },
    };
}
/** Verification row for the controller receipt, only when the cases ran. */
export function fixtureVerification(entry) {
    if (entry.status !== 'passed' && entry.status !== 'failed')
        return null;
    const tally = `${entry.counts.passed} passed, ${entry.counts.failed} failed, ${entry.counts.pending} pending, residue ${entry.counts.residue}`;
    return {
        id: M1_FIXTURE_CHECK,
        kind: 'test',
        passed: entry.status === 'passed',
        detail: `memory ${entry.status} (${tally}; execution ${entry.executionId}); runtime pending (${M1_RUNTIME_OWNER}). ${entry.status === 'failed' ? entry.detail : ''}`.trim(),
    };
}
/** Report lines for a run log; CLI and Studio print the same text. */
export function fixtureLines(entries) {
    return entries.flatMap(entry => {
        const tally = `passed=${entry.counts.passed} failed=${entry.counts.failed} pending=${entry.counts.pending} residue=${entry.counts.residue}`;
        const head = `fixture: ${entry.status} ${entry.controller} ${tally} proof=${entry.proof} runtime=${entry.runtime} (${entry.runtimeOwner})${entry.reused ? ' reused' : ''}${entry.executionId ? ` execution=${entry.executionId}` : ''} key=${entry.key}`;
        return entry.detail && entry.status !== 'passed' ? [head, `fixtureDetail: ${entry.owner ? `(${entry.owner}) ` : ''}${entry.detail}`] : [head];
    });
}
