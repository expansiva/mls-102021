/// <mls fileReference="_102021_/l2/agentMaterializeL1/run/model.ts" enhancement="_blank"/>
/**
 * Model port. Simulate, structure and verify do not call it.
 * The adapter applies the call timeout and does not retry; the run decides repairs.
 */
import { MaterializeCallError } from '/_102021_/l2/agentMaterializeL1/run/budget.js';
export function shouldCallModel(stage, handler) {
    return stage === 'implement' && !!handler && handler.needsLlm && handler.stage === 'implement';
}
export async function invokeModel(port, request, timeoutMs) {
    const controller = new AbortController();
    const onParent = () => controller.abort();
    if (request.signal.aborted)
        controller.abort();
    else
        request.signal.addEventListener('abort', onParent, { once: true });
    let timer;
    const timeout = new Promise((_resolve, reject) => {
        timer = setTimeout(() => {
            controller.abort();
            reject(new MaterializeCallError('TIMEOUT', `Call exceeded ${timeoutMs}ms.`));
        }, timeoutMs);
    });
    try {
        const text = await Promise.race([
            port({ ...request, signal: controller.signal }),
            timeout,
        ]);
        if (typeof text !== 'string' || !text.trim()) {
            throw new MaterializeCallError('INVALID_RESPONSE', 'The model returned an empty response.');
        }
        return text;
    }
    catch (error) {
        if (error instanceof MaterializeCallError)
            throw error;
        const code = readCode(error);
        if (code)
            throw new MaterializeCallError(code, error instanceof Error ? error.message : String(error));
        throw new MaterializeCallError('TRANSIENT', error instanceof Error ? error.message : String(error));
    }
    finally {
        if (timer)
            clearTimeout(timer);
        request.signal.removeEventListener('abort', onParent);
    }
}
function readCode(error) {
    if (!error || typeof error !== 'object')
        return null;
    const code = error.code;
    if (code === 'TIMEOUT' || code === 'NETWORK_UNAVAILABLE' || code === 'TRANSIENT' || code === 'INVALID_RESPONSE')
        return code;
    return null;
}
