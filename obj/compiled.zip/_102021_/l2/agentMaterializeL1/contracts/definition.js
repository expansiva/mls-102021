/// <mls fileReference="_102021_/l2/agentMaterializeL1/contracts/definition.ts" enhancement="_blank"/>
/**
 * C0 contract for defs v2. Exclusive owner of this file: d1_30.
 *
 * d1_31 (writer/finalize), m1_01 (planner) and m1_04 (tests) import from here:
 *   /_102021_/l2/agentMaterializeL1/contracts/definition.js
 *
 * Does not import d1Artifact: d1_31 will import this module, and a reverse
 * runtime import would cycle. Business `data` keeps the D1 field names.
 */
export const M1_DEFINITION_SCHEMA = '2026-09-24-d1-definition-v2';
export const M1_RECEIPT_SCHEMA = '2026-09-24-m1-receipt-v1';
export const D1_DEFINITION_SCHEMA_V1 = '2026-09-21-d1-definition-v1';
export const M1_STATUSES = ['pending', 'generated', 'blocked', 'failed'];
export const M1_ARTIFACT_TYPES = [
    'domainEntity',
    'valueObject',
    'repositoryPort',
    'table',
    'repositoryAdapter',
    'usecase',
    'httpController',
    'accessScope',
    'authorityMap',
    'repositoryRegistration',
    'persistenceSeeds',
    'integrationOutbound',
];
export const M1_STAGES = ['plan', 'generate', 'compile', 'verify', 'promote'];
export const M1_VERIFICATION_KINDS = ['compile', 'test', 'schema', 'hash'];
/** Public names d1_31 must import. Do not duplicate these enums in agentDefsL1. */
export const D1_31_IMPORT = '/_102021_/l2/agentMaterializeL1/contracts/definition.js';
export const D1_31_EXPORTS = [
    'M1_DEFINITION_SCHEMA',
    'M1_STATUSES',
    'M1_ARTIFACT_TYPES',
    'parseDefinitionSource',
    'renderDefinition',
    'definitionIssues',
    'canonicalProjection',
    'semanticHash',
    'referenceIssues',
    'traverseDefinitions',
    'statusEvidenceIssues',
    'generatedAllowsSkip',
    'receiptIssues',
    'receiptPathFor',
    'diagnoseUnit',
];
const ENVELOPE_KEYS = ['schemaVersion', 'artifactType', 'artifactId', 'moduleName', 'status', 'dependencies', 'data'];
const HASH_KEYS = ['schemaVersion', 'artifactType', 'artifactId', 'moduleName', 'dependencies', 'data'];
const TOKEN = /^[A-Za-z][A-Za-z0-9_]*$/;
const MODULE_TOKEN = /^[a-z][A-Za-z0-9]*$/;
const QUALIFIED_FILE = /^_\d+_\/l[1-7]\/[A-Za-z0-9][A-Za-z0-9_./-]*$/;
const DEFINITION_MARKER = 'export const definition = ';
const PIPELINE_MARKER = 'export const pipeline = ';
const AGENT_EXPORT = 'export const agent';
const DATA_KEYS = {
    domainEntity: { required: ['entityId', 'storageTarget', 'fields', 'lifecycle', 'invariants', 'imports'], optional: [], nonempty: [] },
    valueObject: { required: ['valueObjectId', 'fields', 'referencedBy'], optional: [], nonempty: ['referencedBy'] },
    repositoryPort: { required: ['entityId', 'interfaceName', 'methods'], optional: [], nonempty: ['methods'] },
    table: { required: ['tableId', 'entityId', 'physicalName', 'primaryKey', 'uniqueKeys', 'indexes'], optional: [], nonempty: ['primaryKey'] },
    repositoryAdapter: { required: ['entityId', 'portId', 'tableId', 'columns'], optional: [], nonempty: ['columns'] },
    usecase: {
        required: ['usecaseId', 'entityId', 'operation', 'ports', 'rulesApplied', 'functions', 'routeProjections', 'portCalls', 'transactional', 'effects', 'sequence', 'uses', 'rules', 'transaction'],
        optional: ['lifecycle', 'mdm', 'rulePlan'],
        nonempty: ['functions'],
    },
    httpController: { required: ['pageId', 'handlers'], optional: [], nonempty: ['handlers'] },
    accessScope: { required: ['scopeId', 'grants'], optional: [], nonempty: ['grants'] },
    authorityMap: { required: ['mapId', 'entries'], optional: [], nonempty: ['entries'] },
    repositoryRegistration: { required: ['registrationId', 'adapters'], optional: [], nonempty: ['adapters'] },
    persistenceSeeds: { required: ['seedId', 'scenarios'], optional: ['phase', 'dependencies', 'datasets'], nonempty: ['scenarios'] },
    integrationOutbound: { required: ['integrationId', 'events'], optional: ['processes', 'inbound', 'plugins', 'gaps'], nonempty: [] },
};
export function isM1Status(value) {
    return M1_STATUSES.includes(value);
}
export function isM1ArtifactType(value) {
    return M1_ARTIFACT_TYPES.includes(value);
}
export function isM1Stage(value) {
    return M1_STAGES.includes(value);
}
export function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
export function receiptFolder(moduleName) {
    return `l1/${moduleName}/materialization/agentMaterializeL1`;
}
/**
 * Receipt file for one def. The def path is unique on disk; artifactId is not,
 * and a case-only difference is the same file. The base name has no extra dot.
 */
export function receiptPathFor(defPath) {
    const match = /^(?:_\d+_\/)?l1\/([a-z][A-Za-z0-9]*)\/(.+)\/([^/]+)\.defs\.ts$/.exec(defPath);
    if (!match)
        return '';
    const moduleName = match[1];
    const relativeDir = match[2];
    const base = match[3];
    if (!MODULE_TOKEN.test(moduleName) || !TOKEN.test(base))
        return '';
    if (relativeDir.split('/').some(part => !part || part === '.' || part === '..' || part.includes('.')))
        return '';
    return `${receiptFolder(moduleName)}/${relativeDir}/${base}.json`;
}
export function outputPathFromDefPath(defPath) {
    return defPath.endsWith('.defs.ts') ? defPath.replace(/\.defs\.ts$/, '.ts') : '';
}
export function qualifiedFileIssues(path, field) {
    if (!path)
        return [`${field} is empty.`];
    if (path.includes('..'))
        return [`${field} must not contain '..'.`];
    if (path.startsWith('/_'))
        return [`${field} must be a qualified file _NNNNN_/lN/..., not a TypeScript import.`];
    if (!QUALIFIED_FILE.test(path) || path.endsWith('/'))
        return [`${field} must be a qualified file _NNNNN_/lN/....`];
    return [];
}
export function definitionIssues(value) {
    if (!isRecord(value))
        return ['Definition must be an object.'];
    const issues = [];
    for (const key of Object.keys(value)) {
        if (!ENVELOPE_KEYS.includes(key))
            issues.push(`Unknown field definition.${key}.`);
    }
    issues.push(...schemaVersionIssues(value.schemaVersion));
    const artifactType = typeof value.artifactType === 'string' ? value.artifactType : '';
    if (!isM1ArtifactType(artifactType))
        issues.push('definition.artifactType is unknown.');
    const artifactId = typeof value.artifactId === 'string' ? value.artifactId : '';
    if (!TOKEN.test(artifactId))
        issues.push('definition.artifactId must be a token.');
    if (typeof value.moduleName !== 'string' || !MODULE_TOKEN.test(value.moduleName)) {
        issues.push('definition.moduleName must be lowerCamel.');
    }
    const status = typeof value.status === 'string' ? value.status : '';
    if (!isM1Status(status))
        issues.push('definition.status is invalid.');
    issues.push(...dependencyListIssues(value.dependencies));
    if (!isRecord(value.data)) {
        issues.push('Missing field definition.data.');
        return issues;
    }
    if (isM1ArtifactType(artifactType))
        issues.push(...dataIssues(artifactType, value.data));
    return issues;
}
export function parseDefinitionSource(source) {
    const issues = [];
    if (source.includes(PIPELINE_MARKER))
        issues.push('v2 definition must not export pipeline.');
    if (source.includes(AGENT_EXPORT) || /\b"agent"\s*:/.test(source))
        issues.push('v2 definition must not export agent.');
    const raw = sliceJson(source, DEFINITION_MARKER);
    if (raw === undefined)
        issues.push('definition export is missing or is not JSON.');
    if (issues.length > 0)
        return { issues };
    return { definition: raw };
}
export function renderDefinition(definition, defPath) {
    const issues = [
        ...definitionIssues(definition),
        ...qualifiedFileIssues(defPath, 'defPath'),
    ];
    if (issues.length > 0)
        return { issues };
    const body = [
        `/// <mls fileReference="${defPath}" enhancement="_blank"/>`,
        '',
        `export const definition = ${JSON.stringify(definition, null, 2)} as const;`,
        '',
        'export default definition;',
        '',
    ].join('\n');
    return { source: body };
}
export function readDefinition(value) {
    const issues = definitionIssues(value);
    if (issues.length > 0)
        return { issues };
    const record = value;
    return {
        schemaVersion: M1_DEFINITION_SCHEMA,
        artifactType: record.artifactType,
        artifactId: record.artifactId,
        moduleName: record.moduleName,
        status: record.status,
        dependencies: [...record.dependencies],
        data: record.data,
    };
}
export function canonicalProjection(definition) {
    const projection = {};
    for (const key of HASH_KEYS) {
        projection[key] = key === 'dependencies'
            ? [...definition.dependencies].sort()
            : key === 'data'
                ? cloneCanonical(definition.data)
                : definition[key];
    }
    return projection;
}
export async function semanticHash(definition) {
    return sha256Text(stableStringify(canonicalProjection(definition)));
}
export function referenceIssues(definition, index) {
    const issues = [];
    const files = new Set(index.files);
    const byKey = new Map();
    for (const artifact of index.artifacts) {
        const key = `${artifact.artifactType}:${artifact.artifactId}`;
        const list = byKey.get(key) || [];
        list.push(artifact.defPath);
        byKey.set(key, list);
    }
    for (const path of definition.dependencies) {
        if (!files.has(path))
            issues.push(`Missing dependency ${path}.`);
    }
    for (const ref of collectIdentityRefs(definition)) {
        const matches = byKey.get(`${ref.type}:${ref.id}`) || [];
        if (matches.length === 0)
            issues.push(`Missing reference ${ref.type}:${ref.id} at ${ref.path}.`);
        else if (matches.length > 1)
            issues.push(`Ambiguous reference ${ref.type}:${ref.id} at ${ref.path}.`);
    }
    for (const fileRef of collectFileRefs(definition)) {
        if (definition.dependencies.includes(fileRef.path))
            continue;
        if (files.has(fileRef.path))
            issues.push(`File reference ${fileRef.path} at ${fileRef.field} is not listed in dependencies.`);
        else
            issues.push(`Missing file reference ${fileRef.path} at ${fileRef.field}.`);
    }
    return issues;
}
export function traverseDefinitions(units, knownFiles = []) {
    const issues = [];
    const byPath = new Map();
    for (const unit of units) {
        if (byPath.has(unit.defPath))
            issues.push(`Duplicate defPath ${unit.defPath}.`);
        byPath.set(unit.defPath, unit);
        issues.push(...definitionIssues(unit.definition).map(item => `${unit.defPath}: ${item}`));
    }
    const known = new Set(knownFiles);
    for (const unit of units) {
        for (const dep of unit.definition.dependencies) {
            if (!byPath.has(dep) && !known.has(dep))
                issues.push(`Missing dependency ${dep} on ${unit.defPath}.`);
        }
    }
    const color = new Map();
    const stack = [];
    const seen = new Set();
    const visit = (id) => {
        const state = color.get(id) ?? 0;
        if (state === 1) {
            const at = stack.indexOf(id);
            const cycle = [...stack.slice(at), id];
            const key = cycle.slice().sort().join('|');
            if (!seen.has(key)) {
                seen.add(key);
                issues.push(`Cycle: ${cycle.join(' -> ')}.`);
            }
            return;
        }
        if (state === 2)
            return;
        color.set(id, 1);
        stack.push(id);
        const unit = byPath.get(id);
        if (unit) {
            for (const next of unit.definition.dependencies) {
                if (byPath.has(next))
                    visit(next);
            }
        }
        stack.pop();
        color.set(id, 2);
    };
    for (const unit of units)
        visit(unit.defPath);
    const order = [];
    const placed = new Set();
    const walking = new Set();
    const walk = (id) => {
        if (placed.has(id) || walking.has(id) || !byPath.has(id))
            return;
        const unit = byPath.get(id);
        if (!unit)
            return;
        walking.add(id);
        for (const dep of unit.definition.dependencies)
            walk(dep);
        walking.delete(id);
        placed.add(id);
        order.push(id);
    };
    for (const unit of units)
        walk(unit.defPath);
    return { order, issues };
}
export function receiptIssues(value) {
    if (!isRecord(value))
        return ['Receipt must be an object.'];
    const issues = [];
    const keys = [
        'schemaVersion', 'runId', 'candidateId', 'defPath', 'artifactType', 'artifactId', 'recipeVersion',
        'semanticHash', 'dependencyHashes', 'sourceHashes', 'outputHashes', 'stage', 'verifications',
        'failures', 'attempts', 'reason',
    ];
    for (const key of Object.keys(value)) {
        if (!keys.includes(key))
            issues.push(`Unknown field receipt.${key}.`);
    }
    if (value.schemaVersion !== M1_RECEIPT_SCHEMA)
        issues.push('receipt.schemaVersion is unknown.');
    for (const key of ['runId', 'defPath', 'artifactId', 'recipeVersion', 'semanticHash']) {
        if (typeof value[key] !== 'string' || !value[key])
            issues.push(`receipt.${key} is required.`);
    }
    if (typeof value.candidateId !== 'string')
        issues.push('receipt.candidateId must be a string.');
    if (typeof value.defPath === 'string')
        issues.push(...qualifiedFileIssues(value.defPath, 'receipt.defPath'));
    const type = typeof value.artifactType === 'string' ? value.artifactType : '';
    if (!isM1ArtifactType(type))
        issues.push('receipt.artifactType is unknown.');
    const stage = typeof value.stage === 'string' ? value.stage : '';
    if (!isM1Stage(stage))
        issues.push('receipt.stage is invalid.');
    if (!isRecord(value.dependencyHashes))
        issues.push('receipt.dependencyHashes must be an object.');
    if (!isRecord(value.sourceHashes))
        issues.push('receipt.sourceHashes must be an object.');
    if (!isRecord(value.outputHashes))
        issues.push('receipt.outputHashes must be an object.');
    if (!Array.isArray(value.verifications))
        issues.push('receipt.verifications must be a list.');
    if (!Array.isArray(value.failures))
        issues.push('receipt.failures must be a list.');
    if (typeof value.attempts !== 'number' || !Number.isInteger(value.attempts) || value.attempts < 0) {
        issues.push('receipt.attempts must be a non-negative integer.');
    }
    if (typeof value.reason !== 'string')
        issues.push('receipt.reason must be a string.');
    return issues;
}
export async function statusEvidenceIssues(definition, receipt, currentDependencyHashes = {}) {
    if (definition.status === 'generated') {
        if (!receipt)
            return ['generated requires a receipt.'];
        return [
            ...receiptMatchIssues(definition, receipt),
            ...await hashDriftIssues(definition, receipt, currentDependencyHashes),
        ];
    }
    if (definition.status === 'blocked') {
        if (!receipt)
            return ['blocked requires a receipt.'];
        if (!receipt.reason)
            return ['blocked requires a reason on the receipt.'];
        return [];
    }
    if (definition.status === 'failed') {
        if (!receipt)
            return ['failed requires a receipt.'];
        if (receipt.failures.length === 0)
            return ['failed requires failures on the receipt.'];
        return [];
    }
    return [];
}
export async function generatedAllowsSkip(definition, receipt, currentDependencyHashes = {}) {
    if (definition.status !== 'generated')
        return false;
    const issues = await statusEvidenceIssues(definition, receipt, currentDependencyHashes);
    return issues.length === 0;
}
export async function diagnoseUnit(input) {
    const receipt = input.receipt ?? null;
    const issues = [
        ...qualifiedFileIssues(input.defPath, 'defPath'),
        ...definitionIssues(input.definition),
        ...(input.index ? referenceIssues(input.definition, input.index) : []),
        ...await statusEvidenceIssues(input.definition, receipt, input.currentDependencyHashes),
    ];
    const inputHash = await semanticHash(input.definition);
    const outputs = receipt?.outputHashes || {};
    const outputHash = Object.keys(outputs).length === 0 ? '' : await sha256Text(stableStringify(outputs));
    return {
        unitId: `${input.definition.artifactType}/${input.definition.artifactId}`,
        defPath: input.defPath,
        artifactType: input.definition.artifactType,
        artifactId: input.definition.artifactId,
        status: input.definition.status,
        stage: input.stage || receipt?.stage || 'plan',
        issues,
        inputHash,
        outputHash,
    };
}
async function sha256Text(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
function schemaVersionIssues(value) {
    if (value === M1_DEFINITION_SCHEMA)
        return [];
    if (value === D1_DEFINITION_SCHEMA_V1) {
        return [`definition.schemaVersion is ${D1_DEFINITION_SCHEMA_V1}; v2 is ${M1_DEFINITION_SCHEMA}.`];
    }
    return ['definition.schemaVersion is unknown.'];
}
function dependencyListIssues(value) {
    if (!Array.isArray(value))
        return ['definition.dependencies must be a list of qualified files.'];
    const issues = [];
    const seen = new Set();
    const paths = [];
    value.forEach((item, index) => {
        if (typeof item !== 'string') {
            issues.push(`definition.dependencies.${index} must be a string.`);
            return;
        }
        issues.push(...qualifiedFileIssues(item, `definition.dependencies.${index}`).map(text => text.replace(`definition.dependencies.${index}`, `dependencies ${item}`)));
        if (seen.has(item))
            issues.push(`Duplicate dependency ${item}.`);
        seen.add(item);
        paths.push(item);
    });
    const ordered = [...paths].sort();
    if (ordered.some((path, index) => path !== paths[index]))
        issues.push('definition.dependencies must be sorted.');
    return issues;
}
/** Top-level `data` keys. d1_31 uses this list; agentDefsL1 does not keep a second copy. */
export function dataAllowList(type) {
    const spec = DATA_KEYS[type];
    return [...spec.required, ...spec.optional];
}
function dataIssues(type, data) {
    const spec = DATA_KEYS[type];
    const issues = [];
    const allowed = [...spec.required, ...spec.optional];
    for (const key of Object.keys(data)) {
        if (!allowed.includes(key))
            issues.push(`Unknown field data.${key}.`);
    }
    for (const key of spec.required) {
        if (data[key] === undefined)
            issues.push(`Missing field data.${key}.`);
    }
    for (const key of spec.nonempty) {
        if (!Array.isArray(data[key]) || data[key].length === 0)
            issues.push(`Missing field data.${key}.`);
    }
    return issues;
}
function sliceJson(source, marker) {
    const at = source.indexOf(marker);
    if (at < 0)
        return undefined;
    const start = at + marker.length;
    // A string in the JSON may contain ` as const`; the export terminator is the last one.
    const end = source.lastIndexOf(' as const;');
    if (end < start)
        return undefined;
    try {
        return JSON.parse(source.slice(start, end));
    }
    catch {
        return undefined;
    }
}
function cloneCanonical(value) {
    if (Array.isArray(value))
        return value.map(item => cloneCanonical(item));
    if (isRecord(value)) {
        const out = {};
        for (const key of Object.keys(value).sort())
            out[key] = cloneCanonical(value[key]);
        return out;
    }
    return value;
}
function stableStringify(value) {
    if (Array.isArray(value))
        return `[${value.map(item => stableStringify(item)).join(',')}]`;
    if (isRecord(value)) {
        return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
    }
    return JSON.stringify(value) ?? 'null';
}
function collectIdentityRefs(definition) {
    const data = definition.data;
    const refs = [];
    const push = (type, id, path) => {
        if (typeof id === 'string' && id)
            refs.push({ type, id, path });
    };
    if (Array.isArray(data.fields)) {
        data.fields.forEach((field, index) => {
            if (isRecord(field) && field.type === 'record')
                push('domainEntity', field.ref, `data.fields.${index}.ref`);
        });
    }
    if (typeof data.entityId === 'string' && definition.artifactType !== 'domainEntity') {
        push('domainEntity', data.entityId, 'data.entityId');
    }
    if (Array.isArray(data.ports)) {
        data.ports.forEach((port, index) => push('repositoryPort', port, `data.ports.${index}`));
    }
    if (typeof data.portId === 'string')
        push('repositoryPort', data.portId, 'data.portId');
    if (typeof data.tableId === 'string' && definition.artifactType !== 'table') {
        push('table', data.tableId, 'data.tableId');
    }
    if (Array.isArray(data.handlers)) {
        data.handlers.forEach((handler, index) => {
            if (isRecord(handler))
                push('usecase', handler.usecaseId, `data.handlers.${index}.usecaseId`);
        });
    }
    if (Array.isArray(data.adapters)) {
        data.adapters.forEach((adapter, index) => {
            if (!isRecord(adapter))
                return;
            push('repositoryPort', adapter.portId, `data.adapters.${index}.portId`);
            push('repositoryAdapter', adapter.adapterArtifactId, `data.adapters.${index}.adapterArtifactId`);
        });
    }
    if (Array.isArray(data.referencedBy)) {
        data.referencedBy.forEach((id, index) => push('domainEntity', id, `data.referencedBy.${index}`));
    }
    return refs;
}
function collectFileRefs(definition) {
    const data = definition.data;
    const refs = [];
    const push = (path, field) => {
        if (typeof path !== 'string' || !path)
            return;
        refs.push({ path: normalizeFileRef(path, definition.dependencies), field });
    };
    if (Array.isArray(data.rules)) {
        data.rules.forEach((rule, index) => {
            if (isRecord(rule))
                push(rule.path, `data.rules.${index}.path`);
        });
    }
    if (Array.isArray(data.routeProjections)) {
        data.routeProjections.forEach((item, index) => {
            if (isRecord(item))
                push(item.contractPath, `data.routeProjections.${index}.contractPath`);
        });
    }
    if (Array.isArray(data.effects)) {
        data.effects.forEach((effect, index) => {
            if (isRecord(effect))
                push(effect.path, `data.effects.${index}.path`);
        });
    }
    if (isRecord(data.lifecycle) && typeof data.lifecycle.sourcePath === 'string') {
        push(data.lifecycle.sourcePath, 'data.lifecycle.sourcePath');
    }
    return refs;
}
function projectOf(dependencies) {
    for (const path of dependencies) {
        const match = /^_(\d+)_/.exec(path);
        if (match)
            return match[1];
    }
    return '0';
}
function normalizeFileRef(path, dependencies) {
    if (QUALIFIED_FILE.test(path))
        return path;
    if (!path.startsWith('l'))
        return path;
    const matches = dependencies.filter(dep => dep === path || dep.endsWith(`/${path}`));
    if (matches.length === 1)
        return matches[0];
    const project = projectOf(dependencies);
    return project === '0' ? path : `_${project}_/${path}`;
}
async function hashDriftIssues(definition, receipt, currentDependencyHashes) {
    const issues = [];
    if (receipt.semanticHash !== await semanticHash(definition))
        issues.push('semantic hash changed');
    const recorded = isRecord(receipt.dependencyHashes) ? receipt.dependencyHashes : {};
    for (const path of definition.dependencies) {
        if (recorded[path] !== currentDependencyHashes[path])
            issues.push(`dependency ${path} changed`);
    }
    return issues;
}
function receiptMatchIssues(definition, receipt) {
    const issues = receiptIssues(receipt);
    if (receipt.artifactType !== definition.artifactType)
        issues.push('receipt.artifactType does not match the definition.');
    if (receipt.artifactId !== definition.artifactId)
        issues.push('receipt.artifactId does not match the definition.');
    if (!receipt.recipeVersion)
        issues.push('receipt.recipeVersion is required.');
    if (!receipt.semanticHash.startsWith('sha256:'))
        issues.push('receipt.semanticHash is not a sha256 digest.');
    const outputs = Object.keys(receipt.outputHashes);
    if (outputs.length === 0)
        issues.push('generated receipt must hash at least one output.');
    if (!Array.isArray(receipt.verifications) || receipt.verifications.length === 0) {
        issues.push('generated receipt must record verifications.');
    }
    else if (receipt.verifications.some(item => !item.passed)) {
        issues.push('generated receipt has a failed verification.');
    }
    for (const path of definition.dependencies) {
        if (!receipt.dependencyHashes[path])
            issues.push(`generated receipt is missing dependency hash ${path}.`);
    }
    return issues;
}
