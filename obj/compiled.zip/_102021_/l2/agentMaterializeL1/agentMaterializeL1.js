/// <mls fileReference="_102021_/l2/agentMaterializeL1/agentMaterializeL1.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { helpText, parseStudioPrompt, M1_AGENT_NAME } from '/_102021_/l2/agentMaterializeL1/run/command.js';
import { runMaterialize } from '/_102021_/l2/agentMaterializeL1/run/execute.js';
import { createStudioHost, loadStudioUnits, readStudioProfile } from '/_102021_/l2/agentMaterializeL1/studioHost.js';
export function createAgent() {
    return {
        agentName: M1_AGENT_NAME,
        agentProject: 102021,
        agentFolder: 'agentMaterializeL1',
        agentDescription: 'Materialize L1 defs. simulate plans and does not call a model. structure and implement call only their registered handlers.',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const project = typeof mls.actualProject === 'number' ? mls.actualProject : 0;
    const command = parseStudioPrompt(userPrompt || context.message.content || '', project);
    if (command.help)
        return statusTask(agent, context, helpText(project), { command: 'help' });
    if (command.refusal)
        return statusTask(agent, context, command.refusal, { command: 'refused' });
    try {
        const [units, profile] = await Promise.all([
            loadStudioUnits(command.project, command.moduleName),
            readStudioProfile(command.project),
        ]);
        const result = await runMaterialize({
            project: command.project,
            moduleName: command.moduleName,
            stage: command.stage,
            flow: command.flow,
            resume: command.resume,
            units,
            profileMode: profile.mode,
            profileDeclared: profile.declared,
        }, createStudioHost(command.project));
        return statusTask(agent, context, summarize(result), {
            command: result.stage,
            ended: result.ended,
            moduleName: command.moduleName,
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return statusTask(agent, context, `agentMaterializeL1 stopped: ${message}`, { command: 'stopped' });
    }
}
async function beforePromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'agentMaterializeL1 does not call a model for this step.')];
}
async function afterPromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'agentMaterializeL1 finished this step without a model call.')];
}
function summarize(result) {
    return [
        `agentMaterializeL1 ${result.moduleName} in project ${result.project}.`,
        `Stage ${result.stage}. ${result.ended}.`,
        `Model calls: ${result.llmCalls}. Writes: ${result.wrote ? 'yes' : 'no'}.`,
        ...result.units.map(unit => `${unit.code} ${unit.defPath}`),
    ].join('\n');
}
function statusTask(agent, context, message, memory) {
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: `agentMaterializeL1 deterministic bootstrap. The root LLM is skipped.\n${message}` },
                { type: 'human', content: message },
            ],
            taskTitle: 'agentMaterializeL1',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentMaterializeL1', flowName: M1_AGENT_NAME, statusOnly: 'true', ...memory },
        },
    };
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Status',
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, {
            type: 'add-step',
            messageId: '',
            threadId: context.message.threadId,
            taskId: '',
            parentStepId: 1,
            step: result,
        }];
}
function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
