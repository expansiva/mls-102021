/// <mls fileReference="_102021_/l2/agentMaterializeL1/studioHost.ts" enhancement="_blank"/>
/**
 * Studio IO. Reads and writes go through the host stor. No node, fs or typescript import.
 * The project mode is the appEnv field of l5/project.json, the same field the server reads.
 */
import { createStorFile } from '/_102027_/l2/libStor.js';
import { parseDefinitionSource, receiptPathFor } from '/_102021_/l2/agentMaterializeL1/contracts/definition.js';
import { behaviorRunners } from '/_102021_/l2/agentMaterializeL1/handlers/behavior/runners.js';
import { persistenceRunners } from '/_102021_/l2/agentMaterializeL1/handlers/persistence/runners.js';
import { structureRunners } from '/_102021_/l2/agentMaterializeL1/handlers/structure/runners.js';
import { M1_WRITER_SCHEMA, selectRemoval, writerRef, } from '/_102021_/l2/agentMaterializeL1/state/maintain.js';
export async function loadStudioUnits(project, moduleName) {
    const units = [];
    for (const stored of Object.values(files())) {
        if (stored.project !== project || stored.extension !== '.defs.ts' || !stored.shortName)
            continue;
        const folder = stored.folder || '';
        if (!folder.split('/').includes(moduleName))
            continue;
        const text = await readStored(stored);
        if (!text)
            continue;
        const parsed = parseDefinitionSource(text);
        if (!('definition' in parsed))
            continue;
        const level = stored.level ?? 1;
        units.push({
            defPath: `_${project}_/l${level}/${folder}/${stored.shortName}.defs.ts`,
            definition: parsed.definition,
        });
    }
    units.sort((left, right) => left.defPath < right.defPath ? -1 : left.defPath > right.defPath ? 1 : 0);
    return units;
}
export async function readStudioProfile(project) {
    for (const stored of Object.values(files())) {
        if (stored.project !== project || stored.folder !== 'l5' || stored.shortName !== 'project' || stored.extension !== '.json')
            continue;
        const text = await readStored(stored);
        if (!text)
            return { mode: undefined, declared: false };
        try {
            const parsed = JSON.parse(text);
            if (typeof parsed.appEnv === 'string' && parsed.appEnv)
                return { mode: parsed.appEnv, declared: true };
        }
        catch {
            return { mode: undefined, declared: false };
        }
    }
    return { mode: undefined, declared: false };
}
export function createStudioHost(project) {
    const io = {
        async read(ref) {
            const file = fileFromRef(project, ref);
            if (!file)
                return null;
            return readStored(lookup(file));
        },
    };
    const state = {
        async readReceipt(defPath) {
            const path = receiptPathFor(defPath);
            if (!path)
                return null;
            const text = await io.read(path);
            if (!text)
                return null;
            try {
                return JSON.parse(text);
            }
            catch {
                return null;
            }
        },
        async writeReceipt(receipt) {
            const path = receiptPathFor(receipt.defPath);
            if (!path)
                throw new Error('Receipt path is empty.');
            await writeRef(project, path, `${JSON.stringify(receipt)}\n`);
        },
        async readOwned(outputPath) {
            const text = await io.read(outputPath);
            return text === null ? null : new TextEncoder().encode(text);
        },
        async writeOwned(outputPath, body) {
            await writeRef(project, outputPath, new TextDecoder().decode(body));
        },
        async removeOwned(owned, requested) {
            const plan = selectRemoval(owned, requested);
            const removed = [];
            const kept = [...plan.keep];
            for (const path of plan.remove) {
                const file = fileFromRef(project, path);
                const stored = file ? lookup(file) : null;
                if (!file || !stored || stored.status === 'deleted') {
                    kept.push(path);
                    continue;
                }
                stored.status = 'deleted';
                removed.push(path);
            }
            return { removed, kept };
        },
        async readRevision(defPath) {
            const receipt = await this.readReceipt(defPath);
            return receipt?.semanticHash ?? null;
        },
    };
    return {
        io,
        state,
        runners: { ...structureRunners, ...behaviorRunners, ...persistenceRunners },
        writer: studioWriter(project),
    };
}
/**
 * One writer per module inside this page. Stor has no compare-and-swap, so two
 * browser processes are not serialized. The limit is the same one documented
 * on the local adapter.
 */
const studioHolders = new Map();
function studioWriter(project) {
    return {
        async claim(moduleName, holder) {
            const key = `${project}:${moduleName}`;
            const current = studioHolders.get(key);
            if (current && current !== holder)
                return false;
            await writeRef(project, writerRef(moduleName), `${JSON.stringify({ schemaVersion: M1_WRITER_SCHEMA, moduleName, holder })}\n`);
            studioHolders.set(key, holder);
            return true;
        },
        async release(moduleName, holder) {
            const key = `${project}:${moduleName}`;
            if (studioHolders.get(key) !== holder)
                return;
            studioHolders.delete(key);
        },
    };
}
function files() {
    const stor = mls.stor;
    return stor.files || {};
}
function lookup(file) {
    const key = mls.stor.getKeyToFile(file);
    return mls.stor.files[key] || null;
}
async function readStored(stored) {
    if (!stored || stored.status === 'deleted')
        return null;
    if (stored.getValueInfo) {
        try {
            const local = await stored.getValueInfo();
            if (typeof local?.content === 'string')
                return local.content;
        }
        catch { /* fall through to getContent */ }
    }
    if (!stored.getContent)
        return null;
    const content = await stored.getContent();
    if (typeof content === 'string')
        return content;
    if (content && typeof content === 'object')
        return `${JSON.stringify(content)}\n`;
    return null;
}
async function writeRef(project, ref, body) {
    const file = fileFromRef(project, ref);
    if (!file)
        throw new Error(`Refused a write outside the module tree: ${ref}`);
    if (file.shortName.includes('.'))
        throw new Error(`Refused a file name with an extra dot: ${file.shortName}`);
    const stored = lookup(file);
    if (!stored || stored.status === 'deleted') {
        await createStorFile({ ...file, source: body, status: 'new' }, false, false, false);
        return;
    }
    await mls.stor.localStor.setContent(stored, { contentType: 'string', content: body });
}
function fileFromRef(project, ref) {
    if (!ref || ref.includes('..') || ref.includes('\\') || ref.startsWith('/'))
        return null;
    const qualified = /^_(\d+)_\/l([1-7])\/(.+)$/.exec(ref);
    const local = /^l([1-7])\/(.+)$/.exec(ref);
    const projectId = qualified ? Number(qualified[1]) : project;
    const level = qualified ? Number(qualified[2]) : local ? Number(local[1]) : 0;
    const rest = qualified ? qualified[3] : local ? local[2] : '';
    if (!rest || projectId !== project || !level)
        return null;
    const slash = rest.lastIndexOf('/');
    const folder = slash >= 0 ? rest.slice(0, slash) : '';
    const filename = slash >= 0 ? rest.slice(slash + 1) : rest;
    const doubled = ['.defs.ts', '.test.ts', '.d.ts'].find(item => filename.endsWith(item));
    const dot = doubled ? filename.length - doubled.length : filename.lastIndexOf('.');
    if (dot <= 0)
        return null;
    const shortName = filename.slice(0, dot);
    const extension = doubled || filename.slice(dot);
    if (!shortName || shortName.includes('.') || folder.split('/').some(part => !part || part === '.' || part === '..'))
        return null;
    return { project, level, folder, shortName, extension };
}
