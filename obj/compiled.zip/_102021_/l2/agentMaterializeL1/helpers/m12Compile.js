/// <mls fileReference="_102021_/l2/agentMaterializeL1/helpers/m12Compile.ts" enhancement="_blank"/>
// Proof = the Studio compiler (briefing section 6). An unavailable compiler is a failure, never "clean".
//
// The model lookup and the import preload are this agent's own: the 102035 helper files every `.defs.ts`
// under the `ts` slot and preloads a `/x.defs.js` import as `x.defs.ts` (a file that does not exist).
// A controller imports its contract `.defs.js` type, so with that helper it would never compile.
import { enterStudioCompile, formatCompilerDiagnostic, getStudioModel, leaveStudioCompile, releaseBorrowedModelScope, studioCompileAvailable } from '/_102035_/l2/solution/studioCompile.js';
import { readOptional } from '/_102021_/l2/agentMaterializeL1/helpers/m12Io.js';
import { fileRef } from '/_102021_/l2/agentMaterializeL1/helpers/m12Names.js';
/** Editor slot of a stor file: one per extension family, under one key per (project, folder, shortName). */
export function modelSlotOf(extension) {
    if (extension === '.defs.ts')
        return 'defs';
    if (extension === '.test.ts')
        return 'test';
    if (extension === '.less')
        return 'style';
    if (extension === '.html')
        return 'html';
    return 'ts';
}
const MLS_IMPORT = /\bfrom\s+['"]\/_(\d+)_\/l(\d+)\/([^'"]+)\.js['"]/gu;
/** Absolute `/…/x.js` and `/…/x.defs.js` specifiers of `source` as stor files. */
export function importedFiles(source) {
    const out = [];
    for (const match of source.matchAll(MLS_IMPORT)) {
        const rest = match[3];
        const at = rest.lastIndexOf('/');
        const name = at < 0 ? rest : rest.slice(at + 1);
        const defs = name.endsWith('.defs');
        out.push({
            project: Number(match[1]),
            level: Number(match[2]),
            folder: at < 0 ? '' : rest.slice(0, at),
            shortName: defs ? name.slice(0, -'.defs'.length) : name,
            extension: defs ? '.defs.ts' : '.ts',
        });
    }
    return out;
}
function belongsTo(model, info) {
    const owner = model?.storFile;
    return !!model?.model && !!owner && owner.project === info.project && owner.level === info.level
        && (owner.folder ?? '') === info.folder && owner.shortName === info.shortName && owner.extension === info.extension;
}
/**
 * The editor model of exactly this stor file. One editor key covers `<x>.ts` and `<x>.defs.ts` of the same
 * folder, so a model is matched by its `storFile`, never by slot alone.
 */
async function studioModel(info) {
    const file = mls.stor.files[mls.stor.getKeyToFile(info)];
    if (!file || file.status === 'deleted')
        return null;
    const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, info.level);
    const find = () => {
        const slots = mls.editor.models[key];
        if (!slots)
            return undefined;
        const preferred = slots[modelSlotOf(info.extension)];
        if (belongsTo(preferred, info))
            return preferred;
        return Object.values(slots).find(model => belongsTo(model, info));
    };
    let model = find();
    if (!model) {
        // Canonical Studio creation, the same primitive the L2 materializer uses. `getStudioModel` creates through
        // `file.getOrCreateModel()` and borrows the model when this editor key was empty. A key that already holds
        // another extension (`.ts` beside `.defs.ts`) is not borrowed and is not passed through `getStudioModel`:
        // that helper files every non-test extension in the `ts` slot and would sync the wrong bytes into it.
        // Identity stays `storFile`, never the slot.
        const slots = mls.editor.models?.[key];
        if (!slots)
            await getStudioModel(info.project, info.level, info.folder, info.shortName, info.extension);
        else
            await file.getOrCreateModel?.();
        model = find();
    }
    if (!model?.model)
        return null;
    // Monaco compiles memory, not stor: bring the model to the stor bytes.
    try {
        const content = await file.getContent?.();
        if (typeof content === 'string' && model.model.getValue() !== content)
            model.model.setValue?.(content);
    }
    catch { /* the byte check of compileM12Files catches a mismatch */ }
    return model;
}
/** How long one call to the Studio TypeScript worker may take before the unit fails instead of hanging. */
export const M12_COMPILE_TIMEOUT_MS = 60000;
/**
 * A worker failure (e.g. `DataCloneError` inside `ts.worker.js`, measured 05/10/2026 on an l1 file) never settles
 * the main-thread promise: without a deadline the phase hangs forever. With it, the unit fails by name.
 */
export async function withCompileTimeout(what, work, timeoutMs = M12_COMPILE_TIMEOUT_MS) {
    let timer;
    const deadline = new Promise((_resolve, reject) => {
        timer = setTimeout(() => reject(new Error(`M12_COMPILER_TIMEOUT: the Studio TypeScript worker did not answer for ${what} in ${timeoutMs / 1000}s (see the browser console for the worker error).`)), timeoutMs);
    });
    try {
        return await Promise.race([work, deadline]);
    }
    finally {
        if (timer)
            clearTimeout(timer);
    }
}
function studioTypescript() {
    return mls.l2.typescript;
}
/**
 * An l1 file is proven by its diagnostics only. On the Studio, `compile` also asks the TypeScript worker for
 * imports, the emit output, decorators and the JSON doc; on an l1 model one of those answers could not be
 * cloned back (DataCloneError in ts.worker.js, 05/10/2026), and the server JavaScript of l1 is built at publish
 * anyway. So when `getTypeScriptWorker` and `getDiagnostics` exist, an l1 file asks the worker for exactly the
 * proof. A host that has `compile` and not that pair (collabmsg: a real `ts.LanguageService`, no worker) is
 * proven by `compile(model)` and `compilerResults.errors`, the same shape the other levels already return.
 * Neither capability is `M12_COMPILE_UNAVAILABLE_L1`. Chosen by what the object offers, never by host name.
 */
async function l1Diagnostics(info, model) {
    const typescript = studioTypescript();
    const getTypeScriptWorker = typescript.getTypeScriptWorker;
    const getDiagnostics = typescript.getDiagnostics;
    if (typeof getTypeScriptWorker !== 'function' || typeof getDiagnostics !== 'function') {
        if (typeof typescript.compile !== 'function') {
            throw new Error('M12_COMPILER_TIMEOUT: mls.l2.typescript has no getTypeScriptWorker/getDiagnostics here');
        }
        const ref = fileRef(info);
        if (model.compilerResults)
            model.compilerResults.modelNeedCompile = true;
        await withCompileTimeout(ref, typescript.compile(model));
        const text = typeof model.model.getValue === 'function' ? String(model.model.getValue()) : '';
        return { errors: (model.compilerResults?.errors ?? []).map(diagnostic => `${formatCompilerDiagnostic(diagnostic)}${diagnosticLocation(diagnostic, text)}`) };
    }
    const ref = fileRef(info);
    const textModel = model.model;
    const fileName = textModel.uri?.toString() ?? '';
    if (!fileName)
        throw new Error(`model of ${ref} has no uri`);
    const worker = await withCompileTimeout(`${ref} (getTypeScriptWorker)`, getTypeScriptWorker(model.model));
    const diagnostics = await withCompileTimeout(`${ref} (getDiagnostics)`, getDiagnostics(fileName, worker));
    const text = typeof model.model.getValue === 'function' ? String(model.model.getValue()) : '';
    return { errors: (Array.isArray(diagnostics) ? diagnostics : []).map(diagnostic => `${formatCompilerDiagnostic(diagnostic)}${diagnosticLocation(diagnostic, text)}`) };
}
/**
 * Where a worker diagnostic points, as " (line L, column C: `…the code there…`)". The worker sends `start` as an
 * offset and no source file, so the shared formatter prints no position; the repair prompt then only said
 * "TS1005 ',' expected" for a 77-line request and the model never found the missing brace (agendaClinica, 07/10).
 */
export function diagnosticLocation(diagnostic, text) {
    const start = diagnostic && typeof diagnostic === 'object' ? diagnostic.start : undefined;
    if (typeof start !== 'number' || !text || start < 0 || start > text.length)
        return '';
    const before = text.slice(0, start);
    const line = before.split('\n').length;
    const lineStart = before.lastIndexOf('\n') + 1;
    const column = start - lineStart + 1;
    const lineEnd = text.indexOf('\n', start);
    const whole = text.slice(lineStart, lineEnd < 0 ? text.length : lineEnd);
    const from = Math.max(0, column - 1 - 160);
    const snippet = `${from > 0 ? '…' : ''}${whole.slice(from, column - 1)}⟨here⟩${whole.slice(column - 1, column - 1 + 80)}${column - 1 + 80 < whole.length ? '…' : ''}`;
    return ` (line ${line}, column ${column}: \`${snippet}\`)`;
}
/**
 * An l1 file: diagnostics only (see l1Diagnostics). Any other level: compile + enhancement post-process +
 * service-worker cache, as the l2 materializers do.
 */
async function studioCompile(info) {
    const model = await studioModel(info);
    if (!model?.model)
        return null;
    if (info.level === 1)
        return l1Diagnostics(info, model);
    if (model.compilerResults)
        model.compilerResults.modelNeedCompile = true;
    const typescript = studioTypescript();
    const ref = fileRef(info);
    if (typeof typescript.compileAndPostProcess !== 'function') {
        await withCompileTimeout(ref, typescript.compile(model));
    }
    else {
        const runtime = info.extension === '.ts';
        await withCompileTimeout(ref, typescript.compileAndPostProcess(model, runtime, runtime));
        if (!model.compilerResults?.prodDTS && model.compilerResults) {
            model.compilerResults.modelNeedCompile = true;
            await withCompileTimeout(ref, typescript.compile(model));
        }
    }
    return { errors: (model.compilerResults?.errors ?? []).map(formatCompilerDiagnostic) };
}
/**
 * How long the first check after the imports are loaded may take. With the platform server and MDM files of a
 * workflow module in the editor, the worker answered its first request after 222s and every later one at once
 * (tarefas, 19/10/2026); with the 60s deadline each request queued behind that first one timed out in turn.
 */
export const M12_WARMUP_TIMEOUT_MS = 360000;
/**
 * One diagnostics request on `root` with the long deadline, after its imports are in the editor and before any
 * other request: whatever the worker builds the first time is paid here once. A host without the worker pair has
 * nothing to warm. A timeout throws M12_COMPILER_TIMEOUT, which turns the breaker on for the run.
 */
async function warmWorker(root) {
    const typescript = studioTypescript();
    const getTypeScriptWorker = typescript.getTypeScriptWorker;
    const getDiagnostics = typescript.getDiagnostics;
    if (typeof getTypeScriptWorker !== 'function' || typeof getDiagnostics !== 'function')
        return;
    const model = await studioModel(root);
    const fileName = model?.model?.uri?.toString() ?? '';
    if (!model?.model || !fileName)
        return;
    const ref = fileRef(root);
    const worker = await withCompileTimeout(`${ref} (warm-up)`, getTypeScriptWorker(model.model), M12_WARMUP_TIMEOUT_MS);
    await withCompileTimeout(`${ref} (warm-up: first check with its imports loaded)`, getDiagnostics(fileName, worker), M12_WARMUP_TIMEOUT_MS);
}
/**
 * Loads every transitive import of `root` into the editor, warms the worker once with them, then compiles each l2
 * import that has no declaration yet. Loading first and warming before any compile keeps the slow first request
 * on the long deadline instead of on the compile of whichever import came first (_102029_/l2/webCrypto.ts).
 */
async function studioPreload(root) {
    const missing = [];
    const seen = new Set([fileRef(root)]);
    const queue = [root];
    const toCompile = [];
    const typescript = studioTypescript();
    while (queue.length) {
        const current = queue.shift();
        const model = await studioModel(current);
        const source = model?.model?.getValue() ?? await readOptional(current);
        if (source === null) {
            missing.push(`${fileRef(current)} (source unreadable)`);
            continue;
        }
        for (const dep of importedFiles(source)) {
            const id = fileRef(dep);
            if (seen.has(id))
                continue;
            seen.add(id);
            try {
                const depModel = await studioModel(dep);
                if (!depModel?.model) {
                    missing.push(id);
                    continue;
                }
                // An l1 dependency only needs its model in the editor: the worker type-checks against the models it has.
                // Compiling it here would send it through the full compile that broke the worker on l1.
                if (dep.level !== 1 && !depModel.compilerResults?.prodDTS)
                    toCompile.push({ id, model: depModel });
            }
            catch (error) {
                missing.push(`${id} (${error instanceof Error ? error.message : String(error)})`);
                continue;
            }
            queue.push(dep);
        }
    }
    if (missing.length)
        return missing;
    // A file with no imports has nothing loaded to warm: its own check is the first and only request.
    if (seen.size > 1)
        await warmWorker(root);
    for (const { id, model } of toCompile) {
        try {
            if (model.compilerResults)
                model.compilerResults.modelNeedCompile = true;
            await withCompileTimeout(id, typescript.compile(model));
        }
        catch (error) {
            missing.push(`${id} (${error instanceof Error ? error.message : String(error)})`);
        }
    }
    return missing;
}
const STUDIO = {
    available: studioCompileAvailable,
    enter: enterStudioCompile,
    leave: leaveStudioCompile,
    read: readOptional,
    model: studioModel,
    preload: studioPreload,
    compile: studioCompile,
};
/**
 * Prefix of a compile that did not happen: no Studio compiler, or a TypeScript worker that stopped answering.
 * The unit keeps its file and ends `done COMPILE_UNAVAILABLE_L1` with the cause; it is never a clean compile.
 */
export const L1_UNAVAILABLE = 'M12_COMPILE_UNAVAILABLE_L1';
/**
 * Switch of the Studio compile. With false every generated file is written and marked unproven
 * (COMPILE_UNAVAILABLE_L1, listed in the report's notCompiled). It was off on 19/10 while the controllers phase
 * looked stuck: the worker was not stuck, it took 222s on its first request once the platform files were loaded
 * (see M12_WARMUP_TIMEOUT_MS), and each 60s request behind it timed out in turn.
 */
export const M12_STUDIO_COMPILE_ENABLED = true;
export function isUnavailable(error) {
    return error.startsWith(L1_UNAVAILABLE);
}
/**
 * Breaker for the page: once the Studio TypeScript worker stops answering (DataCloneError inside ts.worker.js,
 * measured 05/10/2026), every later compile of the run is reported unavailable at once instead of waiting the
 * deadline again for each file. A page reload resets it.
 */
const breaker = globalThis;
export function workerDown() {
    return breaker.__agentMaterializeL1WorkerDown || '';
}
export function markWorkerDown(cause) {
    breaker.__agentMaterializeL1WorkerDown = cause;
}
/**
 * Compiles `files` in order (dependencies first) against the bytes this run wrote: a file whose stor or model
 * text differs from `expected` is a failure, not a compile of someone else's text.
 */
export async function compileM12Files(files, compiler = STUDIO) {
    const fail = (message) => files.map(file => ({ path: fileRef(file.info), errors: [message] }));
    if (compiler === STUDIO && !M12_STUDIO_COMPILE_ENABLED)
        return fail(`${L1_UNAVAILABLE}: the Studio compile is switched off for the tests (M12_STUDIO_COMPILE_ENABLED = false)`);
    if (compiler === STUDIO && workerDown())
        return fail(`${L1_UNAVAILABLE}: ${workerDown()}`);
    if (typeof mls === 'undefined' && compiler === STUDIO)
        return fail(`${L1_UNAVAILABLE}: no Studio`);
    let entered = false;
    try {
        if (!compiler.available())
            return fail(`${L1_UNAVAILABLE}: the Studio TypeScript compiler is not available here`);
        compiler.enter();
        entered = true;
        const results = [];
        for (const file of files) {
            const path = fileRef(file.info);
            try {
                if (await compiler.read(file.info) !== file.expected)
                    throw new Error('stor bytes differ from the generated source');
                const before = await compiler.model(file.info);
                if (!before?.model || before.model.getValue() !== file.expected)
                    throw new Error('Studio model is unavailable or differs from the generated source');
                const missing = await compiler.preload(file.info);
                if (!Array.isArray(missing))
                    throw new Error('import preload returned no result');
                // An import the compiler did not load in time (a dependency of another project, compiled on the way: the
                // platform workflow engine pulls _102029_/l2 files through the MDM) is the compiler, not the code: the unit is
                // not proven, and the model is not asked to repair what it cannot fix (cicloTarefa, tarefas 19/10). An import
                // that does not exist is still an error of the code.
                if (missing.length && missing.every(item => item.includes('(M12_COMPILER_TIMEOUT'))) {
                    if (compiler === STUDIO)
                        markWorkerDown(`imports the compiler did not load in time: ${missing.join(', ')}`);
                    results.push({ path, errors: [`${L1_UNAVAILABLE}: imports the compiler did not load in time: ${missing.join(', ')}`] });
                    continue;
                }
                // An import the Studio failed to fetch is the environment too: the platform workflow engine imports
                // _102036_/l2/shared/interfaces.ts since d1_89, and a Studio that has not loaded 102036 answers "fecthQl:
                // Please connect to github!" (cicloTarefa and avisoDiario refused, tarefas 21/10). The preload lists such an
                // import with the error it threw, in brackets; an import that does not exist is listed bare and stays the code.
                if (missing.length && missing.every(item => / \(.+\)$/u.test(item) && !item.endsWith('(source unreadable)'))) {
                    results.push({ path, errors: [`${L1_UNAVAILABLE}: imports the Studio could not load: ${missing.join(', ')}`] });
                    continue;
                }
                if (missing.length)
                    throw new Error(`imports unavailable: ${missing.join(', ')}`);
                const compiled = await compiler.compile(file.info);
                if (!compiled || !Array.isArray(compiled.errors))
                    throw new Error('compiler returned no diagnostics');
                if (await compiler.read(file.info) !== file.expected)
                    throw new Error('stor bytes changed during compilation');
                results.push({ path, errors: compiled.errors });
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                if (message.startsWith('M12_COMPILER_TIMEOUT')) {
                    if (compiler === STUDIO)
                        markWorkerDown(message);
                    results.push({ path, errors: [`${L1_UNAVAILABLE}: ${message}`] });
                    continue;
                }
                results.push({ path, errors: [message] });
            }
        }
        return results;
    }
    catch (error) {
        return fail(`${L1_UNAVAILABLE}: ${error instanceof Error ? error.message : String(error)}`);
    }
    finally {
        if (entered)
            compiler.leave();
    }
}
/** Releases the editor models the compile path borrowed (call at the end of a phase). */
export function releaseCompileModels() {
    try {
        releaseBorrowedModelScope();
    }
    catch { /* best effort: no Studio */ }
}
export function compileDiagnostics(results) {
    return results.flatMap(result => result.errors.map(error => `${result.path}: ${error}`));
}
