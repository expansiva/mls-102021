/// <mls fileReference="_102021_/l2/agentMaterializeL1/helpers/m12Io.ts" enhancement="_blank"/>
import { fileRef, infoOfRef, unitDraftFile, unitStatusFile } from '/_102021_/l2/agentMaterializeL1/helpers/m12Names.js';
export const M12_UNIT_STATUS_VERSION = '2026-10-05-m12-unit-v1';
/** Units whose state lets a dependent unit go on. */
export function stateReady(status) {
    return !!status && (status.status === 'done' || status.status === 'reused');
}
/**
 * An l1 file generated and checked by every gate except the Studio compiler, which cannot compile l1 from an
 * agent: the unit is `done` with this code, and the report lists it apart as not proven by a compiler.
 */
export const COMPILE_UNAVAILABLE_L1 = 'COMPILE_UNAVAILABLE_L1';
/** A generated unit no compiler proved (COMPILE_UNAVAILABLE_L1). */
export function unproven(status) {
    return stateReady(status) && status.code === COMPILE_UNAVAILABLE_L1;
}
/** A unit whose file can be registered and used by the next step. */
export function usable(status) {
    return stateReady(status);
}
/** Units that left a file a dependent unit can import (a held unit keeps its file). */
export function fileReady(status) {
    return stateReady(status) || (!!status && status.status === 'blocked' && Object.keys(status.outputs).length > 0 && status.code !== 'COMPILE_FAILED');
}
function storFiles() {
    return (mls.stor.files) || {};
}
function lookup(info) {
    const file = storFiles()[mls.stor.getKeyToFile(info)];
    return file && file.status !== 'deleted' ? file : null;
}
export function storExists(info) {
    try {
        return lookup(info) !== null;
    }
    catch {
        return false;
    }
}
/**
 * The file text, or null when the file is absent or unreadable. Never throws.
 * `getContent()` first: after `localStor.setContent` on an existing file, `getValueInfo()` keeps returning the
 * previous bytes while `getContent()` returns the new ones (measured by agenteMaterializeL22, 01/10/2026).
 */
export async function readOptional(info) {
    try {
        // This session's bytes first, while the file is still in the stor index (writeText registers it there);
        // a file the Studio dropped since (discarded, deleted) is no longer ours to serve.
        const key = keyOf(info);
        const written = memory.get(key);
        if (written !== undefined) {
            if (lookup(info))
                return written;
            memory.delete(key);
        }
    }
    catch { /* no stor key: fall through */ }
    let file;
    try {
        file = lookup(info);
    }
    catch {
        return null;
    }
    if (!file)
        return null;
    try {
        const content = await file.getContent?.();
        if (typeof content === 'string')
            return content;
        if (content && typeof content === 'object')
            return `${JSON.stringify(content)}\n`;
    }
    catch { /* fall through */ }
    try {
        const value = await file.getValueInfo?.();
        if (typeof value?.content === 'string')
            return value.content;
    }
    catch { /* unreadable */ }
    return null;
}
export async function readJsonOptional(info) {
    const text = await readOptional(info);
    if (!text || !text.trim())
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
/** Projects whose stor index this run already asked for (a platform project, e.g. 102034). */
const loadedProjects = new Map();
async function loadProject(project) {
    const server = mls.stor.server;
    if (typeof server?.loadProjectInfoIfNeeded !== 'function')
        return `the stor cannot load project ${project}.`;
    try {
        await server.loadProjectInfoIfNeeded(project);
        return '';
    }
    catch (error) {
        return `loading project ${project} failed: ${error instanceof Error ? error.message : String(error)}`;
    }
}
/**
 * The reader the emitters get: any ref form `infoOfRef` accepts. Another project's file loads that project's
 * stor index once; a failure is warned with its cause and read as absent (the emitter then names what is missing).
 */
export function createReader(project) {
    return async (ref) => {
        const info = infoOfRef(ref, project);
        if (!info)
            return null;
        if (info.project !== project) {
            let loading = loadedProjects.get(info.project);
            if (!loading) {
                loading = loadProject(info.project);
                loadedProjects.set(info.project, loading);
            }
            const failure = await loading;
            if (failure) {
                console.warn(`agentMaterializeL1: cannot read ${ref}; ${failure}`);
                return null;
            }
        }
        return readOptional(info);
    };
}
export async function sha256Text(text) {
    const bytes = new TextEncoder().encode(text);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
export async function hashParts(parts) {
    return sha256Text(parts.map(part => `${part.length}:${part}`).join('\n'));
}
/**
 * The bytes this agent wrote in this browser session, by stor key. Nothing is saved: a written file lives in
 * `mls.stor.files` (registered with `addOrUpdateFile`) with its content here, until the Studio saves it.
 */
// One map for the whole page: every phase agent, whatever module instance the Studio loaded it from, reads the
// bytes the earlier phases wrote. A module-level map was not shared, so a later phase read every status as absent
// and blocked every unit (BLOCKED_BY ... not materialized), 05/10/2026.
const memory = (() => {
    const holder = globalThis;
    if (!holder.__agentMaterializeL1Memory)
        holder.__agentMaterializeL1Memory = new Map();
    return holder.__agentMaterializeL1Memory;
})();
function keyOf(info) {
    return mls.stor.getKeyToFile(info);
}
/**
 * In memory only: no libStor, no `localStor.setContent`, no editor model (an l1 model sent to the Studio
 * TypeScript worker never settles, 05/10/2026). The file is registered in `mls.stor.files` with
 * `mls.stor.addOrUpdateFile`, marked `new` or `changed`, and serves these bytes through `getContent` and
 * `getValueInfo`. Returns the hash of the bytes, which is the hash a later read of this session returns.
 */
export async function writeText(info, text) {
    if (info.shortName.includes('.') && info.shortName !== 'runtime.project')
        throw new Error(`M12_SHORTNAME_DOT: ${fileRef(info)}`);
    const key = keyOf(info);
    const now = new Date().toISOString();
    const index = mls.stor.files;
    let file = index[key];
    memory.set(key, text);
    if (!file || file.status === 'deleted') {
        const returned = await mls.stor.addOrUpdateFile({ project: info.project, level: info.level, shortName: info.shortName, extension: info.extension, versionRef: '0', folder: info.folder, updatedAt: now });
        // The object the index holds is the one the Studio reads: keep that one, register the returned one if missing.
        file = index[key] ?? returned;
        if (!file)
            throw new Error(`M12_STOR_REFUSED: ${fileRef(info)} could not be registered in mls.stor.files.`);
        if (!index[key])
            index[key] = file;
        file.status = 'new';
    }
    else if (file.status !== 'new' && file.status !== 'renamed') {
        file.status = 'changed';
    }
    file.updatedAt = now;
    file.getContent = async () => memory.get(key) ?? text;
    file.getValueInfo = async () => ({ content: memory.get(key) ?? text, contentType: 'string' });
    return sha256Text(text);
}
/** Writes a generated source and returns the exact bytes it holds (what a compiler would see). */
export async function writeSource(info, text) {
    const hash = await writeText(info, text);
    return { hash, text };
}
/**
 * Drops a file this agent created in this session (a broken output, the l5 lock). A file that existed before is
 * never removed here: its previous bytes are written back instead.
 */
export async function removeStorFile(info) {
    const key = keyOf(info);
    const file = mls.stor.files[key];
    memory.delete(key);
    if (file && file.status === 'new')
        delete mls.stor.files[key];
}
export async function writeJson(info, value) {
    await writeText(info, `${JSON.stringify(value, null, 2)}\n`);
}
export async function readUnitStatus(project, moduleName, layer, unitId) {
    const status = await readJsonOptional(unitStatusFile(project, moduleName, layer, unitId));
    return status && status.schemaVersion === M12_UNIT_STATUS_VERSION ? status : null;
}
export async function writeUnitStatus(project, moduleName, status) {
    const full = { schemaVersion: M12_UNIT_STATUS_VERSION, ...status, updatedAt: new Date().toISOString() };
    await writeJson(unitStatusFile(project, moduleName, status.layer, status.unitId), full);
    return full;
}
/** Whether the bytes on disk are still the ones this agent generated last time. */
export async function outputCheck(status, info) {
    const text = await readOptional(info);
    if (text === null)
        return 'absent';
    const recorded = status?.outputs?.[fileRef(info)];
    if (!recorded)
        return 'editedLocally';
    return await sha256Text(text) === recorded ? 'generated' : 'editedLocally';
}
/**
 * Reuse decision of one unit: reusable when the inputs did not change and every output is the one this agent
 * wrote. An output edited locally, or written by someone else, is never overwritten without "force".
 */
export async function reuseDecision(status, inputHash, outputs, force) {
    if (force)
        return { kind: 'generate' };
    const checks = await Promise.all(outputs.map(async (info) => ({ info, check: await outputCheck(status, info) })));
    if (status === null || Object.keys(status.outputs).length === 0) {
        const foreign = checks.find(item => item.check !== 'absent');
        if (foreign)
            return { kind: 'protect', path: fileRef(foreign.info) };
        return { kind: 'generate' };
    }
    const edited = checks.find(item => item.check === 'editedLocally');
    if (edited)
        return { kind: 'protect', path: fileRef(edited.info) };
    const ok = stateReady(status) && status.inputHash === inputHash && checks.every(item => item.check === 'generated');
    return ok ? { kind: 'reuse' } : { kind: 'generate' };
}
export async function writeDraft(project, moduleName, layer, unitId, part, text) {
    await writeText(unitDraftFile(project, moduleName, layer, unitId, part), text);
}
export async function readDraft(project, moduleName, layer, unitId, part) {
    return readOptional(unitDraftFile(project, moduleName, layer, unitId, part));
}
/** appEnv of l5/project.json, the field the server reads. Absent = presentation (not production). */
export async function readAppEnv(project) {
    const config = await readJsonOptional({ project, level: 5, folder: '', shortName: 'project', extension: '.json' });
    return typeof config?.appEnv === 'string' && config.appEnv ? config.appEnv : 'presentation';
}
