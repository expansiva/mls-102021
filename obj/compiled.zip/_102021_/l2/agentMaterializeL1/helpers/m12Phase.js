/// <mls fileReference="_102021_/l2/agentMaterializeL1/helpers/m12Phase.ts" enhancement="_blank"/>
import { M12_BUILD, clip, errorText, parseM12StepInvocation } from '/_102021_/l2/agentMaterializeL1/helpers/m12Core.js';
import { updateM12Status } from '/_102021_/l2/agentMaterializeL1/helpers/m12Intents.js';
import { readAppEnv } from '/_102021_/l2/agentMaterializeL1/helpers/m12Io.js';
import { releaseCompileModels } from '/_102021_/l2/agentMaterializeL1/helpers/m12Compile.js';
import { createContext, layerUnits, materializeUnit } from '/_102021_/l2/agentMaterializeL1/helpers/m12Materialize.js';
import { loadModuleUnits, orderWithinLayer, selectUnits, storEntries } from '/_102021_/l2/agentMaterializeL1/helpers/m12Units.js';
/** The module as this run sees it: every unit (dependencies) and the selected ones. */
export async function loadRun(run) {
    const loaded = await loadModuleUnits(run.project, run.module, storEntries());
    const appEnv = await readAppEnv(run.project);
    const ctx = createContext(run, loaded.units, appEnv);
    return { ctx, selected: selectUnits(run.project, run.module, loaded.units, run), problems: loaded.problems };
}
/** Every selected unit of `layer`, sequentially (one Studio compile at a time). Lines for the trace. */
export async function runDeterministicLayer(run, layer) {
    const { ctx, selected } = await loadRun(run);
    const units = orderWithinLayer(layerUnits(selected, layer));
    const lines = [];
    try {
        for (const unit of units)
            lines.push((await materializeUnit(ctx, unit)).line);
    }
    finally {
        releaseCompileModels();
    }
    return lines.length ? lines : [`No ${layer} unit selected.`];
}
/** A phase agent whose whole job is `runDeterministicLayer`: no LLM, completes when the layer is done. */
export function deterministicPhaseAgent(agentName, folder, description, layer) {
    async function beforePromptStep(_agent, context, parentStep, step, hookSequential, args) {
        const parsed = parseM12StepInvocation(args || step.prompt || '', Number(mls.actualProject || 0));
        if (parsed.kind === 'refusal')
            return [updateM12Status(context, parentStep, step, hookSequential, 'failed', parsed.diagnostic)];
        try {
            const lines = await runDeterministicLayer(parsed, layer);
            return [updateM12Status(context, parentStep, step, hookSequential, 'completed', clip([`build ${M12_BUILD}`, ...lines].join('\n'), 3000))];
        }
        catch (error) {
            return [updateM12Status(context, parentStep, step, hookSequential, 'failed', clip(errorText(error)))];
        }
    }
    return { agentName, agentProject: 102021, agentFolder: `agentMaterializeL1/${folder}`, agentDescription: description, visibility: 'private', beforePromptStep };
}
