/// <mls fileReference="_102021_/l2/agentMaterializeL1/core/registry.ts" enhancement="_blank"/>
/**
 * Closed handler registry. This file is the only integrator: m1_03, m1_06 and m1_07
 * deliver a MaterializeHandler; wiring it stays here. A type with no named entry is
 * blocked by the planner. Nothing in this module writes a file.
 */
import { isM1ArtifactType } from '/_102021_/l2/helpers/l1Defs/definition.js';
export const M1_HANDLER_STAGES = ['structure', 'implement'];
/** Platform capabilities a handler may ask the context resolver to load. MDM catalog is not one of them. */
export const M1_CONTEXT_CAPABILITIES = [
    'requestContext',
    'dataRuntime',
    'tableDefinition',
    'repositoryRegistry',
    'mdmFacade',
];
const STRUCTURE = {
    domainEntity: handler('structure.domainEntity', 'domainEntity', 'structure', []),
    valueObject: handler('structure.valueObject', 'valueObject', 'structure', []),
    repositoryPort: handler('structure.repositoryPort', 'repositoryPort', 'structure', []),
    table: handler('persistence.table', 'table', 'structure', ['tableDefinition']),
    repositoryAdapter: handler('persistence.repositoryAdapter', 'repositoryAdapter', 'structure', [
        'requestContext', 'dataRuntime', 'tableDefinition', 'repositoryRegistry',
    ]),
    usecase: handler('structure.usecase', 'usecase', 'structure', ['requestContext', 'repositoryRegistry']),
    httpController: handler('structure.httpController', 'httpController', 'structure', ['requestContext']),
    requestService: handler('structure.requestService', 'requestService', 'structure', ['requestContext', 'repositoryRegistry']),
    accessScope: handler('structure.accessScope', 'accessScope', 'structure', ['requestContext']),
    authorityMap: handler('structure.authorityMap', 'authorityMap', 'structure', ['requestContext']),
    repositoryRegistration: handler('persistence.repositoryRegistration', 'repositoryRegistration', 'structure', [
        'requestContext', 'repositoryRegistry',
    ]),
    persistenceSeeds: handler('persistence.persistenceSeeds', 'persistenceSeeds', 'structure', ['tableDefinition']),
    integrationOutbound: handler('persistence.integrationOutbound', 'integrationOutbound', 'structure', []),
    workflowProcess: handler('structure.workflowProcess', 'workflowProcess', 'structure', []),
};
/** Implement recipes. Null is a written absence: no fallback onto the structure scaffolder. */
export const M1_IMPLEMENT_HANDLERS = {
    domainEntity: handler('implement.domainEntity', 'domainEntity', 'implement', []),
    valueObject: null,
    repositoryPort: handler('implement.repositoryPort', 'repositoryPort', 'implement', []),
    table: null,
    repositoryAdapter: null,
    usecase: handler('implement.usecase', 'usecase', 'implement', ['requestContext', 'repositoryRegistry']),
    httpController: null,
    requestService: handler('implement.requestService', 'requestService', 'implement', ['requestContext', 'repositoryRegistry']),
    accessScope: handler('implement.accessScope', 'accessScope', 'implement', ['requestContext']),
    authorityMap: handler('implement.authorityMap', 'authorityMap', 'implement', ['requestContext']),
    repositoryRegistration: null,
    persistenceSeeds: null,
    integrationOutbound: null,
    workflowProcess: null,
};
export const M1_STRUCTURE_HANDLERS = STRUCTURE;
export function handlerFor(type, stage = 'structure') {
    if (!isM1ArtifactType(type))
        return null;
    if (stage === 'implement')
        return M1_IMPLEMENT_HANDLERS[type];
    return STRUCTURE[type];
}
export function registeredHandlerIds(stage = 'structure') {
    if (stage === 'implement') {
        return Object.values(M1_IMPLEMENT_HANDLERS).flatMap(item => item ? [item.id] : []).sort();
    }
    return Object.values(STRUCTURE).map(item => item.id).sort();
}
function handler(id, artifactType, stage, capabilities) {
    return { id, artifactType, stage, needsLlm: false, capabilities };
}
