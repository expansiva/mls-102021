/// <mls fileReference="_102021_/l2/agentMaterializeL1/core/io.ts" enhancement="_blank"/>
export async function contentHash(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
