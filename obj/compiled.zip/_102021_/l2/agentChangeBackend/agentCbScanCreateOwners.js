/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbScanCreateOwners.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNext, createUpdateStatusIntent, logPrefix } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbScanCreateOwners', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic l4 statusBackend=toCreate scan', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        // toCreate is the trigger; inProgress is treated as resumable (a previous run locked but did not
        // finish) so the reconciler is idempotent and never gets stuck after a partial run.
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        if (scan.owners.length === 0) {
            return [
                enqueueNext(context, parentStep, step, 'cb-final-summary', 'agentCbFinalSummary', 'Resumo (sem trabalho)', { noWork: true }),
                createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'No owner with statusBackend = toCreate.'),
            ];
        }
        return [
            enqueueNext(context, parentStep, step, 'cb-validate-readiness', 'agentCbValidateL4Readiness', 'Preflight l4', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Selected ${scan.owners.length} owner(s).`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} failed: ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
