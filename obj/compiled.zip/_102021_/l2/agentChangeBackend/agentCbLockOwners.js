/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbLockOwners.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setOwnerStatusBackend, enqueueNext, createUpdateStatusIntent } from '/_102021_/l2/agentChangeBackend/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbLockOwners', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic statusBackend toCreate -> inProgress lock', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate']);
        let locked = 0;
        for (const owner of scan.owners) {
            if (await setOwnerStatusBackend(owner, 'inProgress'))
                locked++;
        }
        return [
            enqueueNext(context, parentStep, step, 'cb-aggregate-index', 'agentCbAggregateIndex', 'Planejar agregados', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Locked ${locked} owner(s).`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
