/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
// Strict JSON schemas for every agentChangeBackend tool call (the `result` shape inside the planner
// envelope status/result/questions/trace). collab-llm forces the model to satisfy these and the
// agents re-validate locally. Each schema is the contract that makes the produced .defs.ts
// self-sufficient for the .ts materialization. See spec.md (auto-suficiência) and flow.json.
const str = { type: 'string' };
const bool = { type: 'boolean' };
const num = { type: 'number' };
const strArray = { type: 'array', items: str };
function objArray(required, properties) {
    return { type: 'array', items: { type: 'object', additionalProperties: false, required, properties } };
}
// ── generation / defs ───────────────────────────────────────────────────────────
// NOTE (2026-07-11): the planning/index schemas (aggregate/persistence/usecase/bff Index) were
// removed together with their LLM steps — the output was discarded and the generators re-derive
// aggregates/columns/usecases deterministically.
const fieldSchema = { type: 'object', additionalProperties: false, required: ['fieldId', 'type', 'required'], properties: { fieldId: str, type: str, required: bool, description: str, enum: strArray } };
// Only `entityId` (to map the item back to its domain) is required from the model: the LLM's job here
// is the INVARIANTS (business rules that are not derivable from the ontology). `fields`, `valueObjects`
// and `statusEnum` are DETERMINISTIC (ontology fields, embedded members, the status enum) and are
// attached by agentCbDomainEntity from the scan — so they are optional here and any model-emitted copy
// is ignored. This removes the whole class of "items/0 must have required property 'fields'" failures
// (the model used to omit the root fields or nest them under valueObjects) and shrinks the output.
export const domainEntityResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['entityId'],
    properties: {
        entityId: str,
        title: str,
        fields: { type: 'array', items: fieldSchema },
        valueObjects: objArray(['name'], { name: str, fields: { type: 'array', items: fieldSchema }, collection: bool }),
        invariants: strArray,
        statusEnum: strArray,
    },
};
export const repositoryPortResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['entityId', 'interfaceName', 'methods'],
    properties: {
        entityId: str,
        interfaceName: str, // I{Entity}Repository
        methods: objArray(['name', 'returns'], { name: str, params: strArray, returns: str, description: str }),
    },
};
export const persistenceTableResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['tableId', 'tableName', 'columns', 'primaryKey'],
    properties: {
        tableId: str,
        tableName: str, // snake_case
        columns: objArray(['name', 'type', 'nullable'], { name: str, type: str, nullable: bool, description: str }),
        primaryKey: strArray,
        indexes: objArray(['indexName', 'columns'], { indexName: str, columns: strArray, unique: bool }),
        detailsColumn: { type: 'object', additionalProperties: false, required: ['enabled'], properties: { enabled: bool, columnName: str, childCollections: strArray } },
        // Append-only event tables: appendOnly=true, purpose 'controle' (telemetry/audit), retentionDays
        // carried to the TableDefinition (omitted = permanent). Absent for normal aggregate tables.
        appendOnly: bool,
        purpose: str,
        retentionDays: num,
    },
};
export const repositoryAdapterResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['entityId', 'className', 'portRef', 'tableRef'],
    properties: {
        entityId: str,
        className: str,
        portRef: str, // .d.ts of the port it implements
        tableRef: str, // .d.ts of the table it maps to
        mdmReads: strArray,
        notes: strArray,
    },
};
// A usecase file may export SEVERAL functions, each with its OWN explicit Input/Output FIELDS (not
// just type names) so the .ts and the BFF that imports it are deterministic.
// `fieldRef`/`item` mirror the l4 outputShape entry vocabulary: the prompt shows the canonical
// outputShape and models copy its entries verbatim into output[] — rejecting those keys made the
// x-tool-strict ajv gate 502 the whole call (primary AND fallback) on run 102049. They are tolerated,
// not consumed: the pin (cbOutputShapeToDefsFields) flattens the defs output regardless.
// The item shape of an array field = { fields: [...columns] }. Flat one level (columns are scalars),
// so its own field schema omits a further `item` — keeps the tree bounded AND provider-clean.
const itemFieldSchema = { type: 'object', additionalProperties: false, required: ['name', 'type'], properties: { name: str, type: str, required: bool, description: str, ofEntity: str, fieldRef: str } };
const arrayItemSchema = { type: 'object', additionalProperties: false, properties: { fields: { type: 'array', items: itemFieldSchema } } };
const ioFieldSchema = { type: 'object', additionalProperties: false, required: ['name', 'type'], properties: { name: str, type: str, required: bool, description: str, ofEntity: str, fieldRef: str, item: arrayItemSchema } };
const usecaseFunctionSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['functionName', 'inputTypeName', 'outputTypeName', 'input', 'output'],
    properties: {
        functionName: str,
        inputTypeName: str,
        outputTypeName: str,
        input: { type: 'array', items: ioFieldSchema }, // explicit input fields (camelCase)
        output: { type: 'array', items: ioFieldSchema }, // explicit output fields (camelCase)
        ports: strArray, // ports this function uses
        rulesApplied: strArray,
        transactional: bool,
        steps: strArray,
    },
};
export const usecaseResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['usecaseId', 'ports', 'functions'],
    properties: {
        usecaseId: str,
        ports: strArray, // all repository ports the usecase file imports (union of functions)
        rulesApplied: strArray,
        functions: { type: 'array', items: usecaseFunctionSchema }, // 1..N exported functions
    },
};
export const httpControllerResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['pageId', 'controllerName', 'handlers', 'routes'],
    properties: {
        pageId: str,
        controllerName: str,
        handlers: objArray(['handlerName', 'command', 'usecaseRef'], { handlerName: str, command: str, usecaseRef: str, kind: str }),
        routes: objArray(['key', 'handlerName'], { key: str, handlerName: str }), // key = {module}.{page}.{command}
    },
};
// ── seed scenario planning (agentCbSeeds) ─────────────────────────────────────
// The planner returns semantic data only. It cannot emit TypeScript or raw IDs: the deterministic
// cbSeedsCore compiler resolves the symbolic refs and validates the result before saving seeds.ts.
const seedReferenceSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['ref'],
    properties: { ref: str },
};
const seedAssetReferenceSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['asset', 'kind'],
    properties: {
        asset: str,
        kind: { type: 'string', const: 'image' },
    },
};
const seedValueSchema = {
    anyOf: [str, num, bool, { type: 'null' }, seedReferenceSchema, seedAssetReferenceSchema],
};
const seedFieldSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['name', 'value'],
    properties: { name: str, value: seedValueSchema },
};
const seedChildRowSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['key', 'fields'],
    properties: { key: str, fields: { type: 'array', items: seedFieldSchema } },
};
const seedChildCollectionSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['name', 'rows'],
    properties: { name: str, rows: { type: 'array', items: seedChildRowSchema } },
};
const seedLocalRowSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['key', 'columns', 'details', 'children'],
    properties: {
        key: str,
        columns: { type: 'array', items: seedFieldSchema },
        details: { type: 'array', items: seedFieldSchema },
        children: { type: 'array', items: seedChildCollectionSchema },
    },
};
const seedRelationshipSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['targetRef', 'type', 'metadata', 'isBidirectional'],
    properties: {
        targetRef: str,
        type: str,
        metadata: { type: 'array', items: seedFieldSchema },
        isBidirectional: bool,
    },
};
const seedMdmRowSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['key', 'fields', 'relationships'],
    properties: {
        key: str,
        fields: { type: 'array', items: seedFieldSchema },
        relationships: { type: 'array', items: seedRelationshipSchema },
    },
};
export const seedPlanResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['summary', 'localTables', 'mdmEntities'],
    properties: {
        summary: str,
        localTables: objArray(['tableId', 'rows'], {
            tableId: str,
            rows: { type: 'array', items: seedLocalRowSchema },
        }),
        mdmEntities: objArray(['entityId', 'rows'], {
            entityId: str,
            rows: { type: 'array', items: seedMdmRowSchema },
        }),
    },
};
// ── judge (adversarial critic, cb-judge) ────────────────────────────────────────
// Findings typed by the repair-routing taxonomy (improveAddNewSolution2_1.md §2):
// estrutural (artifact/link missing) | decisao (business default missing) | fora_de_escopo (other layer).
export const judgeResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['findings'],
    properties: {
        findings: objArray(['ownerId', 'type', 'severity', 'message'], {
            ownerId: str, // operationId of the usecase judged
            type: { type: 'string', enum: ['estrutural', 'decisao', 'fora_de_escopo'] },
            severity: { type: 'string', enum: ['error', 'warning'] },
            message: str,
            suggestion: str,
        }),
    },
};
export const finalSummaryResultSchema = {
    type: 'object',
    additionalProperties: false,
    required: ['summary'],
    properties: { summary: str, ownersDone: strArray, warnings: strArray },
};
