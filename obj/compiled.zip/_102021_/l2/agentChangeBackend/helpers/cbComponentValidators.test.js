/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.test.ts" enhancement="_blank"/>
import test from 'node:test';
import assert from 'node:assert/strict';
import { collectL1Imports, escapeRegExp, fieldNameFromRef, requiredBoundaryFields, collectRequiredChecksByHandler, collectExportedHandlers, collectRouteHandlers, collectUsecaseRules, normalizeRuleId, collectV2ControllerCoherenceIssues, extractInterfaceMethods, collectRepositoryMethodMisuse, collectInventedRelationshipKeyIssues, stableCompilerErrors, selectCompilerRepairRoots, } from '/_102021_/l2/agentChangeBackend/helpers/cbComponentValidators.js';
test('stableCompilerErrors (T2): keeps only findings that reproduce on the double-check (flaky dropped)', () => {
    const first = ['compiler: TS2792 cannot find module', 'compiler: TS2322 real type error'];
    const second = ['compiler: TS2322 real type error']; // TS2792 was a transient (models not settled)
    assert.deepEqual(stableCompilerErrors(first, second), ['compiler: TS2322 real type error']);
    // A finding present in BOTH passes is a real error and stays.
    assert.deepEqual(stableCompilerErrors(['x'], ['x']), ['x']);
    // Nothing reproduces -> everything suppressed as flaky.
    assert.deepEqual(stableCompilerErrors(['a', 'b'], ['c']), []);
});
test('selectCompilerRepairRoots (T2): an importer of a flagged file is a cascade; only the root is repaired', () => {
    // B is broken; A imports B; C is independently broken and imports nobody flagged.
    const flagged = ['mod/adapters::orderrepositoryadapter', 'mod/entities::order', 'mod/entities::daily'];
    const importsOf = (key) => key === 'mod/adapters::orderrepositoryadapter' ? ['mod/entities::order'] // A imports flagged B
        : []; // order (B) and daily (C) import nothing flagged
    const { roots, cascades } = selectCompilerRepairRoots(flagged, importsOf);
    assert.deepEqual(cascades, ['mod/adapters::orderrepositoryadapter'], 'importer of a flagged file is deferred');
    assert.deepEqual(roots.sort(), ['mod/entities::daily', 'mod/entities::order'], 'only roots are repaired this round');
});
test('selectCompilerRepairRoots (T2): a file importing a NON-flagged file is a root (not a cascade)', () => {
    const { roots, cascades } = selectCompilerRepairRoots(['a'], () => ['some/other::cleanfile']);
    assert.deepEqual(roots, ['a']);
    assert.deepEqual(cascades, []);
});
// An append-only ledger port (StockAdjustment): NO save/create — only append + queries.
const STOCK_ADJ_PORT = `
import type { StockAdjustment } from '/_102051_/l1/cafeFlow/layer_3_domain/entities/stockAdjustment.js';
export interface IStockAdjustmentRepository {
  append(record: StockAdjustment): Promise<void>;
  listByPeriod(period: DateRange): Promise<StockAdjustment[]>;
  listByProductId(productId: ProductId): Promise<StockAdjustment[]>;
}
`;
test('collectInventedRelationshipKeyIssues flags a literal-cast related() key (erro4) but not a typed key', () => {
    // The exact erro4 shape: entity.related(key as 'o') — an invented CompactRelationshipRefKey forced past the type.
    const bad = `for (const key of ['o','op'] as const) { const ids = entity.related(key as 'o'); pushAll(ids); }
    const more = entity.relatedIds(rel as "OffersProduct");`;
    const issues = collectInventedRelationshipKeyIssues(bad);
    assert.equal(issues.length, 2, issues.join(' | '));
    assert.ok(issues.some(i => i.includes("as 'o'")));
    assert.ok(issues.some(i => i.includes("as 'OffersProduct'")));
    // A properly typed key (no literal cast) must NOT be flagged.
    const good = `const rel: CompactRelationshipRefKey = resolveKey(); const ids = entity.related(rel);`;
    assert.deepEqual(collectInventedRelationshipKeyIssues(good), []);
});
test('extractInterfaceMethods reads only the named interface method signatures', () => {
    const methods = extractInterfaceMethods(STOCK_ADJ_PORT, 'IStockAdjustmentRepository');
    assert.deepEqual([...methods].sort(), ['append', 'listByPeriod', 'listByProductId']);
    // Unknown interface -> empty (never a false source of methods).
    assert.equal(extractInterfaceMethods(STOCK_ADJ_PORT, 'IOrderRepository').size, 0);
});
test('collectRepositoryMethodMisuse flags a call to a method the port does not declare (run14: save on append-only)', () => {
    const methods = new Map([['IStockAdjustmentRepository', extractInterfaceMethods(STOCK_ADJ_PORT, 'IStockAdjustmentRepository')]]);
    const code = `
    const stockAdjustments = resolveRepository<IStockAdjustmentRepository>(ctx, 'StockAdjustment');
    await stockAdjustments.save(record);
    const past = await stockAdjustments.listByPeriod(period);
  `;
    const issues = collectRepositoryMethodMisuse(code, methods);
    assert.equal(issues.length, 1, issues.join('\n'));
    assert.match(issues[0], /stockAdjustments\.save\(\) is not declared on IStockAdjustmentRepository/);
    assert.match(issues[0], /use one of: append, listByPeriod, listByProductId/);
});
test('collectRepositoryMethodMisuse accepts only-declared calls and skips unresolved interfaces', () => {
    const methods = new Map([['IStockAdjustmentRepository', extractInterfaceMethods(STOCK_ADJ_PORT, 'IStockAdjustmentRepository')]]);
    // All calls valid.
    assert.deepEqual(collectRepositoryMethodMisuse(`
    const a = resolveRepository<IStockAdjustmentRepository>(ctx, 'StockAdjustment');
    await a.append(r); await a.listByProductId(id);
  `, methods), []);
    // Port not in the map (source unresolved) -> skipped, no false positive even for a bogus method.
    assert.deepEqual(collectRepositoryMethodMisuse(`
    const o = resolveRepository<IOrderRepository>(ctx, 'Order');
    await o.whatever(x);
  `, methods), []);
});
// A well-formed v2 controller for the "catalog" workspace (one handler per bffCall, routes by const).
const CATALOG_CONTROLLER = `
export const catalogCatalogListHandler: BffHandler = async ({ request, ctx }) => { return ok({}); };
export const catalogProductDetailHandler: BffHandler = async ({ request, ctx }) => { return ok({}); };
export const routes: ControllerRoute[] = [
  { key: catalogListRoute, handler: catalogCatalogListHandler },
  { key: productDetailRoute, handler: catalogProductDetailHandler },
];
`;
const catalogWs = { workspaceId: 'catalog', bffCalls: [{ bffId: 'catalogList' }, { bffId: 'productDetail' }] };
test('collectV2ControllerCoherenceIssues passes a well-formed workspace controller', () => {
    const issues = collectV2ControllerCoherenceIssues([catalogWs], new Map([['catalog', CATALOG_CONTROLLER]]));
    assert.deepEqual(issues, []);
});
test('collectV2ControllerCoherenceIssues flags a bffCall with no handler', () => {
    const src = CATALOG_CONTROLLER.replace(/export const catalogProductDetailHandler[\s\S]*?};\n/, '');
    const issues = collectV2ControllerCoherenceIssues([catalogWs], new Map([['catalog', src]]));
    assert.ok(issues.some(i => /bffCall productDetail has no handler catalogProductDetailHandler/.test(i)), issues.join('\n'));
});
test('collectV2ControllerCoherenceIssues flags an orphan route (missing route const)', () => {
    // handler exists and is registered, but the route const is never referenced.
    const src = CATALOG_CONTROLLER.replace(/productDetailRoute/g, 'wrongRoute');
    const issues = collectV2ControllerCoherenceIssues([catalogWs], new Map([['catalog', src]]));
    assert.ok(issues.some(i => /route const productDetailRoute missing \(rota órfã\)/.test(i)), issues.join('\n'));
});
test('collectV2ControllerCoherenceIssues flags a workspace whose controller was not generated', () => {
    const issues = collectV2ControllerCoherenceIssues([catalogWs], new Map());
    assert.ok(issues.some(i => /\.ts not generated for the workspace/.test(i)), issues.join('\n'));
});
test('collectL1Imports keeps same-project l1 imports and drops others', () => {
    const code = `
    import { a } from '/_102048_/l1/cafeFlow/layer_3_domain/entities/order.js';
    import { b } from '/_102034_/l1/platform/thing.js';
    import { c } from '/_102048_/l2/somewhere/else.js';
  `;
    assert.deepEqual(collectL1Imports(code, 102048), [
        { key: 'cafeFlow/layer_3_domain/entities::order', target: '_102048_/l1/cafeFlow/layer_3_domain/entities/order' },
    ]);
});
test('escapeRegExp escapes regex metacharacters', () => {
    assert.equal(escapeRegExp('a.b*c'), 'a\\.b\\*c');
});
test('fieldNameFromRef returns the last dotted segment', () => {
    assert.equal(fieldNameFromRef('movement.movementType'), 'movementType');
    assert.equal(fieldNameFromRef('plain'), 'plain');
    assert.equal(fieldNameFromRef(undefined), '');
});
test('requiredBoundaryFields ignores context-resolved sources', () => {
    const contract = [
        { inputId: 'name', required: true, source: 'userInput' },
        { inputId: 'companyId', required: true, source: 'businessContext' },
        { fieldRef: 'order.total', required: true, source: 'routeParam' },
        { inputId: 'optional', required: false, source: 'userInput' },
    ];
    assert.deepEqual([...requiredBoundaryFields(contract)].sort(), ['name', 'total']);
});
test('collectRequiredChecksByHandler extracts required-field guards by handler', () => {
    const code = `
export const createOrder: BffHandler = async (req) => {
  if (!req.name) throw new AppError({ code: 'x', message: 'required', field: 'name' });
  if (!req.m) throw new AppError({ code: 'y', message: 'required', field: 'movement.movementType' });
};
`;
    const checks = collectRequiredChecksByHandler(code);
    assert.deepEqual([...(checks.get('createOrder') ?? [])].sort(), ['movementType', 'name']);
});
test('collectExportedHandlers and collectRouteHandlers pair up', () => {
    const code = `
export const createOrder: BffHandler = async () => {};
export const listOrders: BffHandler = async () => {};
const routes = [
  { key: 'order.create', handler: createOrder },
  { key: 'order.list', handler: listOrders },
];
`;
    assert.deepEqual([...collectExportedHandlers(code)].sort(), ['createOrder', 'listOrders']);
    const routes = collectRouteHandlers(code);
    assert.equal(routes.get('order.create'), 'createOrder');
    assert.equal(routes.get('order.list'), 'listOrders');
});
test('normalizeRuleId strips the description after the colon', () => {
    assert.equal(normalizeRuleId('R1: no negative stock'), 'R1');
    assert.equal(normalizeRuleId('  R2  '), 'R2');
});
test('collectUsecaseRules unions top-level and per-function rules, normalized', () => {
    const data = {
        rulesApplied: ['R1: top', 'R2'],
        functions: [
            { rulesApplied: ['R2: dup', 'R3'] },
            { rulesApplied: ['R4'] },
            'not-a-record',
        ],
    };
    assert.deepEqual(collectUsecaseRules(data).sort(), ['R1', 'R2', 'R3', 'R4']);
    assert.deepEqual(collectUsecaseRules(undefined), []);
    assert.deepEqual(collectUsecaseRules('nope'), []);
});
