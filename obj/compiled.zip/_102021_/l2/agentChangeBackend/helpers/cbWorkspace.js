/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
// l4 v2 workspace/bffCall model + PURE parsers (no file I/O, no side-effecting imports). Kept in its own
// module so it stays unit-testable: cbShared pulls in libStor -> libModel whose top-level
// `mls.events.addEventListener` crashes the l2 test stub. Everything here depends only on isRecord.
// The controller (gen-http v2, B4) is derived deterministically from these — see newSolution_10 §A2/A5.
import { isRecord } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function readStringArray(value) {
    return Array.isArray(value) ? value.map(readString).filter(Boolean) : [];
}
// Actors: l4 v2 declares `actors: string[]`; v1 `actor: string` (folded to a single-element array).
export function readActorsField(obj) {
    const plural = readStringArray(obj.actors);
    if (plural.length)
        return plural;
    const singular = readString(obj.actor);
    return singular ? [singular] : [];
}
// Module actors file (l4 v2): `actors` is an array of objects, not strings — read separately.
export function readModuleActors(obj, moduleName) {
    const arr = Array.isArray(obj.actors) ? obj.actors.filter(isRecord) : [];
    return arr
        .map(a => {
        const actorId = readString(a.actorId);
        if (!actorId)
            return null;
        return { actorId, title: readString(a.title) || actorId, roleScope: readString(a.roleScope), moduleName };
    })
        .filter((a) => a !== null);
}
// Parse a l4 v2 workspace defs into a CbWorkspace (bffCalls + projection). Pure/testable: no file I/O.
export function parseWorkspaceDefs(obj, moduleName) {
    if (!isRecord(obj))
        return null;
    const workspaceId = readString(obj.workspaceId);
    if (!workspaceId)
        return null;
    const bffCalls = (Array.isArray(obj.bffCalls) ? obj.bffCalls.filter(isRecord) : [])
        .map(c => parseBffCall(c, moduleName, workspaceId))
        .filter((c) => c !== null);
    const usedOps = [...new Set(bffCalls.flatMap(c => c.uses.map(u => u.operationId)).filter(Boolean))];
    return {
        workspaceId,
        moduleName,
        title: readString(obj.title) || workspaceId,
        actors: readActorsField(obj),
        kind: readString(obj.kind),
        purpose: readString(obj.purpose),
        bffCalls,
        operationIds: usedOps.length ? usedOps : readStringArray(obj.operationIds),
    };
}
function parseBffCall(obj, moduleName, workspaceId) {
    const bffId = readString(obj.bffId);
    if (!bffId)
        return null;
    const kind = readString(obj.kind) === 'command' ? 'command' : 'query';
    const uses = (Array.isArray(obj.uses) ? obj.uses.filter(isRecord) : [])
        .map(u => {
        const operationId = readString(u.operationId);
        return operationId ? { operationId, ...(u.optional === true ? { optional: true } : {}) } : null;
    })
        .filter((u) => u !== null);
    const input = (Array.isArray(obj.input) ? obj.input.filter(isRecord) : [])
        .map(i => {
        const name = readString(i.name);
        if (!name)
            return null;
        const field = { name, from: readString(i.from) };
        if (readString(i.type))
            field.type = readString(i.type);
        return field;
    })
        .filter((i) => i !== null);
    const output = parseBffCallOutput(obj.output);
    const route = readString(obj.route) || `${moduleName}.${workspaceId}.${bffId}`;
    return { bffId, kind, uses, input, ...(output ? { output } : {}), route };
}
function parseBffCallOutput(value) {
    if (!isRecord(value))
        return undefined;
    const kind = readString(value.kind);
    const fields = (Array.isArray(value.fields) ? value.fields : [])
        .map(parseBffCallOutputField)
        .filter((f) => f !== null);
    if (!kind || fields.length === 0)
        return undefined;
    return { kind, fields };
}
function parseBffCallOutputField(value) {
    if (!isRecord(value))
        return null;
    const name = readString(value.name);
    if (!name)
        return null;
    const field = { name };
    if (readString(value.from))
        field.from = readString(value.from);
    if (readString(value.type))
        field.type = readString(value.type);
    if (value.required === true)
        field.required = true;
    if (isRecord(value.item) && Array.isArray(value.item.fields)) {
        const fields = value.item.fields.map(parseBffCallOutputField).filter((f) => f !== null);
        if (fields.length)
            field.item = { fields };
    }
    return field;
}
