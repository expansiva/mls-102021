/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, todoOwnerType, todoStatusField, todoStatusDivergences, pickTodoBackendReadBack, selectTodoBackendFileForStatusWrite, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, } from '/_102021_/l2/agentChangeBackend/helpers/cbDefsSource.js';
import { parseWorkspaceDefs, readAccessMatrixActors, readModuleActors, readActorsField, } from '/_102021_/l2/agentChangeBackend/helpers/cbWorkspace.js';
import { agentTraceFileInfo } from '/_102021_/l2/agentChangeBackend/helpers/cbTraceScope.js';
import { parseEntityLifecycle } from '/_102021_/l2/agentChangeBackend/helpers/cbLifecycle.js';
import { formatDiscardedOrphans, liveBackendModulesFromL5, reconcileClientBackendRegistration, } from '/_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig.js';
export { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, };
export { parseEntityLifecycle, compactLifecycleForPrompt, lifecycleForEntity, collectLifecycleContradictionFindings } from '/_102021_/l2/agentChangeBackend/helpers/cbLifecycle.js';
export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, };
/** Loose planner config: validates the envelope and returns the `result` object as a record. Each
 * agent reads the array property it expects (items/aggregates/tables/...). */
export function plannerConfig(toolName) {
    return { toolName, normalizeResult: (value) => assertRecord(value, 'result') };
}
/** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
 * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
export function batchSchema(itemSchema) {
    return { type: 'object', additionalProperties: false, required: ['items'], properties: { items: { type: 'array', items: itemSchema } } };
}
export function asArray(value) {
    return Array.isArray(value) ? value.filter(isRecord) : [];
}
// The SINGLE source of truth for "every owner status" (T10/A1). Use it whenever the question is about
// OWNERSHIP or STRUCTURE — "does this artifact belong to a current owner?", "which module is this?" —
// because the gen-http `done` flip empties a ['toCreate','inProgress'] scan and such a check would then
// conclude that everything the run just generated is an orphan (erro5). Keep the pending-filtered scan
// only where the question really is "what is still PENDING?".
// Do NOT re-declare this list locally: three copies used to exist (root, gen-http, here) and a drift
// between them would make the ownership checks diverge silently.
// `readonly`: now that a SINGLE array instance is shared by every caller, an in-place mutation
// (push/sort/splice) would silently change what every ownership check sees.
export const ALL_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'inProgress', 'done'];
export const DEFAULT_EVENT_RETENTION_DAYS = 90; // telemetry default when the ontology omits it
import { CB_PHASES, reconcileBackendTodo, resolveModuleName, scopeBackendScan, upsertEntity, backfillEntityFieldsFromOwners, lookupTodoOwner, indexTodoOwner, flattenTodoOwners } from '/_102021_/l2/agentChangeBackend/helpers/cbScope.js';
export { CB_PHASES } from '/_102021_/l2/agentChangeBackend/helpers/cbScope.js';
import { promptSizeError } from '/_102021_/l2/agentChangeBackend/helpers/cbPromptBudget.js';
import { parseStepCost } from '/_102021_/l2/agentChangeBackend/helpers/cbCostReport.js';
import { setCbTraceModule } from '/_102021_/l2/agentChangeBackend/helpers/cbTraceScope.js';
// ── deterministic l4 scan ──────────────────────────────────────────────────────
export async function readBackendScan(statuses = ['toCreate'], context, targetModuleOverride) {
    const wanted = new Set(statuses);
    const project = mls.actualProject || 0;
    const moduleNames = new Set();
    const entityToModule = new Map();
    const entities = [];
    const relationships = [];
    const rawOwners = [];
    const workspaces = [];
    const actorsList = [];
    const siteMaps = {};
    const siteMapSource = {};
    const warnings = [];
    const lifecycles = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts')
            continue;
        const folder = String(file.folder || '');
        const shortName = String(file.shortName || '');
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!isRecord(parsed))
            continue;
        // l4 layout: v1 keeps operations/workflows flat at the l4 root; v2 nests everything under `<module>/`.
        const nestedModule = folder.includes('/') ? folder.split('/')[0] : '';
        if (folder === 'operations' || folder.endsWith('/operations')) {
            rawOwners.push({ kind: 'operation', obj: parsed, moduleName: nestedModule || undefined });
        }
        else if (folder === 'workflows' || folder.endsWith('/workflows')) {
            // ns4 workflows are entity lifecycles (states/transitions), not units of generation: nothing
            // in the todo owns them, so treating them as owners would fail the scan on missing owners.
            // They still have to travel to gen-domain/gen-usecase — otherwise the model invents a
            // stricter machine than the fromStates→toState matrix (pending→completed denied while declared).
            if (isEntityLifecycle(parsed)) {
                const lifecycle = parseEntityLifecycle(parsed, nestedModule);
                if (lifecycle)
                    lifecycles.push(lifecycle);
            }
            else {
                rawOwners.push({ kind: 'workflow', obj: parsed, moduleName: nestedModule || undefined });
            }
        }
        else if (folder.endsWith('/workspaces')) {
            // l4 v2 only: the workspace declares the page's bffCalls (controller source — see B4).
            const ws = parseWorkspaceDefs(parsed, nestedModule);
            if (ws) {
                workspaces.push(ws);
                if (ws.moduleName)
                    moduleNames.add(ws.moduleName);
            }
        }
        else if (shortName === 'access-matrix' || folder.endsWith('/access')) {
            // ns4: the module audience lives in the access matrix instead of a dedicated actors file.
            const moduleName = readString(parsed.moduleName) || folder.split('/')[0];
            for (const a of readAccessMatrixActors(parsed, moduleName))
                actorsList.push(a);
        }
        else if (shortName === 'actors' && folder && !folder.includes('/')) {
            // l4 v2 module actors file: `l4/<module>/actors.defs.ts` (folder === moduleName; actors are objects).
            const moduleName = readString(parsed.moduleName) || folder;
            for (const a of readModuleActors(parsed, moduleName))
                actorsList.push(a);
        }
        else if ((shortName === 'siteMap' || shortName === 'navigation') && folder && !folder.includes('/')) {
            // Prefer siteMap (post-P7); navigation is the pre-P7 fallback. Kept as a raw view for menu/register.
            const moduleName = readString(parsed.moduleName) || folder;
            if (siteMapSource[moduleName] !== 'siteMap') {
                siteMaps[moduleName] = parsed;
                siteMapSource[moduleName] = shortName === 'siteMap' ? 'siteMap' : 'navigation';
            }
        }
        else if (shortName === 'module' && folder && !folder.includes('/')) {
            const moduleName = readString((isRecord(parsed.module) ? parsed.module : parsed).moduleName) || folder;
            moduleNames.add(moduleName);
            collectModuleOntology(parsed, moduleName, entities, entityToModule, relationships);
        }
        else if (folder.endsWith('/ontology')) {
            const moduleName = folder.split('/')[0];
            // ns4 keeps the relationship graph in the ontology index; it is an index, never an entity.
            if (shortName === 'index') {
                if (moduleName) {
                    moduleNames.add(moduleName);
                    collectOntologyRelationships(parsed, relationships);
                }
                continue;
            }
            // Older generators name the entity only by the file; ns4 always declares `entityId`.
            const entityId = readString(parsed.entityId) || shortName;
            if (moduleName && entityId) {
                moduleNames.add(moduleName);
                entityToModule.set(entityId, moduleName);
                const declaredKind = readString(parsed.kind);
                const ownership = readString(parsed.ownership) || 'moduleOwned';
                const storage = readEntityStorage(parsed);
                const kind = classifyEntityKind({ kind: declaredKind, ownership, storage });
                const contradiction = MDM_WRITE_PATH_ENABLED ? contradictoryStorageDeclaration({ kind: declaredKind, ownership, storage }) : '';
                if (contradiction)
                    warnings.push(`entity ${entityId}: ${contradiction}`);
                // The mapping is a DECISION about a foreign vocabulary, so it is visible in the scan trace
                // instead of only in the code (same treatment as the projection mapping).
                if (declaredKind && declaredKind !== kind) {
                    const declared = storage.target ? `${declaredKind}/${storage.target}` : declaredKind;
                    warnings.push(`entity ${entityId}: l4 kind '${declared}' (${ownership}) read as '${kind}'`);
                }
                const storageNotes = isRecord(parsed.storage) ? readString(parsed.storage.notes) : '';
                const derivation = readDerivation(parsed.derivation);
                upsertEntity(entities, {
                    entityId,
                    title: readString(parsed.title) || entityId,
                    kind,
                    ownership,
                    moduleName,
                    fields: Array.isArray(parsed.fields) ? parsed.fields.filter(isRecord) : undefined,
                    eventPolicy: readEventPolicy(parsed.eventPolicy),
                    ...(storage.target ? { storageTarget: storage.target } : {}),
                    ...(storage.mdmType ? { mdmType: storage.mdmType } : {}),
                    ...(storage.idField ? { idField: storage.idField } : {}),
                    ...(readString(parsed.description) ? { description: readString(parsed.description) } : {}),
                    ...(storageNotes ? { storageNotes } : {}),
                    ...(readStringArray(parsed.useRules).length ? { useRules: readStringArray(parsed.useRules) } : {}),
                    ...(derivation ? { derivation } : {}),
                });
            }
        }
    }
    const moduleFallback = moduleNames.size === 1 ? Array.from(moduleNames)[0] : 'unknown';
    const allOwners = rawOwners
        // v2 knows the module from the folder (`<module>/operations`); v1 (flat) derives it from the entity.
        .map(({ kind, obj, moduleName }) => ownerFrom(kind, obj, entityToModule, moduleFallback, moduleName))
        .filter((o) => !!o);
    const todoState = await readBackendTodoState(project);
    for (const moduleName of todoState.moduleNames)
        moduleNames.add(moduleName);
    // The target module is resolved BEFORE reconciliation. A project keeps the modules the generator
    // left behind (ns4 writes buildFlowFsm39…47 side by side and only the last has a todo), and
    // reconciling project-wide killed a run whose own module was intact.
    const requestedModule = (targetModuleOverride && targetModuleOverride.trim())
        || (context ? readTargetModule(context) : '');
    const targetModule = resolveModuleName(requestedModule, Array.from(moduleNames).sort());
    const ownersOfTarget = (moduleName) => targetModule
        ? moduleName === targetModule
        : todoState.filesByModule.has(moduleName) || todoState.moduleNames.includes(moduleName);
    if (rawOwners.length > 0 && !todoState.files && (!targetModule || allOwners.some(owner => owner.moduleName === targetModule))) {
        throw new Error('l5/{module}/todoBackend.defs.ts not found; backend generation status must come from todoBackend, not inline l4 statusBackend.');
    }
    for (const owner of allOwners) {
        const todoOwner = lookupTodoOwner(todoState.ownersByModule, owner, todoState.ownersByKey);
        if (!todoOwner)
            continue;
        owner.todoStatus = todoOwner.status;
        owner.statusBackend = todoOwner.status;
        // The todo only NAMES the module for the flat v1 layout, where the owner has none of its own.
        // Overwriting a folder-derived module made a previous generation's operation (ids repeat across
        // ns4 generations) claim the target module and join the run as if it belonged to it.
        if (!owner.moduleName || owner.moduleName === 'unknown')
            owner.moduleName = todoOwner.moduleName || owner.moduleName;
        if (owner.inlineStatusBackend && owner.inlineStatusBackend !== todoOwner.status) {
            warnings.push(`${owner.kind}:${owner.id} inline statusBackend=${owner.inlineStatusBackend} ignored; todoBackend=${todoOwner.status}`);
        }
    }
    const reconciliation = reconcileBackendTodo({
        l4Owners: allOwners.map(owner => ({ key: ownerKey(owner), moduleName: owner.moduleName })),
        todoOwners: flattenTodoOwners(todoState.ownersByModule).map(({ key, moduleName }) => ({ key, moduleName })),
        todoErrors: todoState.errors,
        targetModule,
    });
    if (reconciliation.errors.length)
        throw new Error(reconciliation.errors.join('; '));
    warnings.push(...reconciliation.warnings, ...todoState.warnings);
    // An owner of a module with no todo never carries a status, so it can never be pending work.
    const owners = allOwners.filter(o => wanted.has(o.todoStatus) && ownersOfTarget(o.moduleName));
    // Roots that operations own (entity + writes) across ALL operations regardless of status — the
    // aggregate boundaries must be stable even when only some owners are pending (toCreate).
    const operatedRootIds = new Set();
    for (const { obj, moduleName } of rawOwners) {
        // Owners of another module never shape THIS module's aggregates: an entity only some previous
        // generation operates would otherwise get an entity, a port, a table and seeds it has no use for.
        if (moduleName && !ownersOfTarget(moduleName))
            continue;
        const e = readString(obj.entity);
        if (e)
            operatedRootIds.add(e);
        for (const w of readStringArray(obj.writes))
            operatedRootIds.add(w);
    }
    // ── single-module scope ────────────────────────────────────────────────────────
    // A run targets exactly ONE module so each task stays small (a project may hold several modules).
    // The target is the explicit CLI module (an override arg, or the value the root persisted in the
    // task longMemory), else the first (sorted) module that has owners in the requested statuses.
    // Every downstream step reads the SAME target — moduleNames[0] and only that module's owners,
    // entities, relationships, workspaces and actors — so the pipeline never spans modules. Pure
    // filtering lives in cbScope (unit-tested there).
    const allModuleNames = Array.from(moduleNames).sort();
    const scoped = scopeBackendScan({ owners, entities, relationships, workspaces, actors: actorsList, allModuleNames, requestedModule: targetModule });
    // From here on every trace/state artifact of the run is written under `l4/<module>/trace`.
    setCbTraceModule(scoped.moduleName);
    if (scoped.warning)
        warnings.push(scoped.warning);
    // An ontology entity with NO fields (every `kind: "metric"` one in cafeFlow) still becomes a real
    // aggregate with a domain entity, table and seeds — all built from an empty field list, which is what
    // left getShiftClosingReport answering with two ids and getAiSalesSummary crashing on .toFixed(). The
    // L4 owner shapes already declare those fields via `fieldRef`, so recover them deterministically
    // BEFORE aggregates/events/seed planning read `entities`. Ontology-declared fields always win.
    const backfilled = backfillEntityFieldsFromOwners(scoped.entities, scoped.owners);
    for (const entity of backfilled) {
        const original = scoped.entities.find(e => e.entityId === entity.entityId);
        if (original && original !== entity) {
            warnings.push(`entity '${entity.entityId}' declares no fields in the ontology; ${entity.fields?.length ?? 0} field(s) recovered from l4 owner shapes`);
        }
    }
    const aggregates = deriveAggregates(backfilled, scoped.relationships, operatedRootIds);
    const events = deriveEventTargets(backfilled, scoped.relationships);
    // NB: the l4 contracts (`.ts`) are NEVER read here — l4 holds only `.defs.ts` (a `.ts` in l4 is not
    // compilable and getContent on it 422s). The l1 contracts are GENERATED from `workspaces` (gen-http).
    const inScopeIds = new Set(backfilled.map(e => e.entityId));
    const scopedLifecycles = lifecycles.filter(lc => (!lc.moduleName || lc.moduleName === scoped.moduleName) && (!inScopeIds.size || inScopeIds.has(lc.entityRef)));
    return {
        project, moduleNames: scoped.moduleName ? [scoped.moduleName] : allModuleNames,
        owners: scoped.owners, entities: backfilled, relationships: scoped.relationships,
        aggregates, events, workspaces: scoped.workspaces, actors: scoped.actors, siteMaps,
        lifecycles: scopedLifecycles, warnings,
    };
}
function ownerKey(owner) {
    return `${owner.kind}:${owner.id}`;
}
function todoOwnerKey(ownerType, ownerId) {
    return `${ownerType}:${ownerId}`;
}
async function readBackendTodoState(project) {
    const ownersByModule = new Map();
    const ownersByKey = new Map();
    const moduleNames = new Set();
    const warnings = [];
    const errors = [];
    const filesByModule = new Set();
    let files = 0;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 5 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || String(file.shortName || '') !== 'todoBackend')
            continue;
        files++;
        filesByModule.add(String(file.folder || ''));
        const parsed = parseDefsSource(String(await file.getContent()));
        if (!isRecord(parsed)) {
            errors.push({ moduleName: String(file.folder || ''), message: `invalid todoBackend defs at l5/${String(file.folder || '')}/todoBackend.defs.ts` });
            continue;
        }
        const layer = readString(parsed.layer);
        if (layer && layer !== 'backend')
            warnings.push(`todoBackend ${String(file.folder || '')} has layer=${layer}; treating as backend by filename`);
        const moduleName = readString(parsed.moduleName) || String(file.folder || '');
        if (moduleName)
            moduleNames.add(moduleName);
        const owners = Array.isArray(parsed.owners) ? parsed.owners.filter(isRecord) : [];
        for (const raw of owners) {
            const ownerType = todoOwnerType(readString(raw.ownerType));
            const ownerId = readString(raw.ownerId);
            const status = readString(raw[todoStatusField(raw) || 'status']);
            if (!ownerType || !ownerId) {
                errors.push({ moduleName, message: `todoBackend ${moduleName || String(file.folder || '')} has invalid owner entry` });
                continue;
            }
            if (!isOwnerStatus(status)) {
                errors.push({ moduleName, message: `todoBackend ${moduleName || String(file.folder || '')}/${ownerType}:${ownerId} has invalid status "${status}"` });
                continue;
            }
            const key = todoOwnerKey(ownerType, ownerId);
            const value = { ownerType, ownerId, status, moduleName };
            if (indexTodoOwner(ownersByModule, moduleName, key, value) === 'duplicate') {
                warnings.push(`duplicate todoBackend owner ${key}; first entry kept`);
                continue;
            }
            if (!ownersByKey.has(key))
                ownersByKey.set(key, value);
        }
    }
    return { files, filesByModule, moduleNames: Array.from(moduleNames).sort(), ownersByModule, ownersByKey, warnings, errors };
}
// Derived from ALL_STATUSES so the list lives in exactly ONE place (it used to be spelled out here too).
function isOwnerStatus(status) {
    return ALL_STATUSES.includes(status);
}
// Read the optional event classification from an ontology def (shape-safe; ignores malformed input).
function readEventPolicy(value) {
    if (!isRecord(value))
        return undefined;
    const purpose = readString(value.purpose);
    if (purpose !== 'telemetry' && purpose !== 'audit' && purpose !== 'reaction')
        return undefined;
    const retentionDays = typeof value.retentionDays === 'number' ? value.retentionDays : undefined;
    return retentionDays === undefined ? { purpose } : { purpose, retentionDays };
}
function readDerivation(value) {
    if (!isRecord(value))
        return undefined;
    const from = readString(value.from);
    if (!from)
        return undefined;
    const aggregate = Array.isArray(value.aggregate)
        ? value.aggregate.filter(isRecord).map(raw => {
            const fieldId = readString(raw.fieldId);
            const op = readString(raw.op);
            if (!fieldId || !op)
                return null;
            const sourceField = readString(raw.sourceField);
            return { fieldId, op, ...(sourceField ? { sourceField } : {}) };
        }).filter((item) => item !== null)
        : [];
    return { from, filter: readString(value.filter), aggregate };
}
// Turn every kind:"event" entity into a first-class generation target. The owner is the related core
// entity (relationship in either direction). Missing eventPolicy defaults to telemetry/90d so legacy
// ontologies still get persisted instead of producing a dead in-memory object. reaction events are
// NOT persisted locally (persisted:false) — the usecase routes them to the platform outbox.
export function deriveEventTargets(entities, relationships) {
    const byId = new Map(entities.map(e => [e.entityId, e]));
    const out = [];
    for (const e of entities) {
        if (e.kind !== 'event')
            continue;
        const policy = e.eventPolicy ?? { purpose: 'telemetry', retentionDays: DEFAULT_EVENT_RETENTION_DAYS };
        let ownerEntity = '';
        for (const rel of relationships) {
            const other = rel.fromEntity === e.entityId ? rel.toEntity : rel.toEntity === e.entityId ? rel.fromEntity : '';
            if (other && byId.get(other)?.kind === 'core') {
                ownerEntity = other;
                break;
            }
        }
        const persisted = policy.purpose !== 'reaction';
        const retentionDays = policy.purpose === 'telemetry' ? (policy.retentionDays ?? DEFAULT_EVENT_RETENTION_DAYS) : policy.retentionDays;
        out.push({ entityId: e.entityId, ownerEntity, purpose: policy.purpose, retentionDays, persisted, fields: e.fields });
    }
    return out;
}
/** ns4 relationships live in `<module>/ontology/index.defs.ts` instead of in module.defs.ts. */
function collectOntologyRelationships(index, relationships) {
    const rels = Array.isArray(index.relationships) ? index.relationships : [];
    for (const rel of rels) {
        if (!isRecord(rel))
            continue;
        const fromEntity = readString(rel.fromEntity);
        const toEntity = readString(rel.toEntity);
        const persistenceMode = isRecord(rel.persistence) ? readString(rel.persistence.mode) : '';
        if (fromEntity && toEntity) {
            relationships.push({
                fromEntity, toEntity, type: readString(rel.type) || 'manyToOne',
                ...(persistenceMode ? { persistenceMode } : {}),
            });
        }
    }
}
function collectModuleOntology(moduleDefs, moduleName, entities, entityToModule, relationships) {
    const ontology = isRecord(moduleDefs.ontology) ? moduleDefs.ontology : undefined;
    const ents = ontology && isRecord(ontology.entities) ? ontology.entities : undefined;
    if (ents) {
        for (const [entityId, raw] of Object.entries(ents)) {
            if (!isRecord(raw))
                continue;
            entityToModule.set(entityId, moduleName);
        }
    }
    const rels = Array.isArray(moduleDefs.relationships) ? moduleDefs.relationships : [];
    for (const rel of rels) {
        if (!isRecord(rel))
            continue;
        const fromEntity = readString(rel.fromEntity);
        const toEntity = readString(rel.toEntity);
        if (fromEntity && toEntity)
            relationships.push({ fromEntity, toEntity, type: readString(rel.type) || 'manyToOne' });
    }
}
function ownerFrom(kind, obj, entityToModule, fallbackModule, explicitModule) {
    const id = readString(obj.operationId) || readString(obj.workflowId);
    if (!id)
        return null;
    const entity = readString(obj.entity);
    // Workflows declare the entities they touch in `entities` (no reads/writes). Fold those in so the
    // deterministic port derivation works for workflows too (otherwise the model invents port names).
    // Strip field-level refs ("CashMovement.amount") — keep only bare entity ids.
    const bare = (arr) => arr.filter(s => s && !s.includes('.'));
    const entitiesArr = bare(readStringArray(obj.entities));
    const reads = [...new Set([...bare(readStringArray(obj.reads)), ...entitiesArr])];
    const writes = [...new Set([...bare(readStringArray(obj.writes)), ...entitiesArr])];
    const moduleName = explicitModule || entityToModule.get(entity) || entityToModule.get(reads[0]) || entityToModule.get(writes[0]) || fallbackModule;
    const mdm = readOwnerMdm(obj);
    return {
        kind,
        id,
        pageId: readString(obj.pageId),
        commandName: readString(obj.commandName),
        bffName: readString(obj.bffName),
        title: readString(obj.title) || id,
        entity,
        opKind: readString(obj.kind),
        actors: readActorsField(obj),
        reads,
        writes,
        rulesApplied: readStringArray(obj.rulesApplied),
        accessPattern: readAccessPattern(obj.accessPattern),
        outputShape: readOutputShape(obj.outputShape),
        inputs: synthesizeMdmInputs(readOperationInputs(obj.inputs), mdm),
        ...(mdm ? { mdm } : {}),
        contextResolution: readContextResolution(obj.contextResolution),
        acceptanceAssertions: readStringArray(obj.acceptanceAssertions),
        todoStatus: '',
        statusBackend: '',
        inlineStatusBackend: readString(obj.statusBackend),
        moduleName,
    };
}
function readAccessPattern(value) {
    if (!isRecord(value))
        return undefined;
    const kind = readString(value.kind);
    const description = readString(value.description);
    if (!kind && !description)
        return undefined;
    return {
        kind,
        description,
        ...(readString(value.entity) ? { entity: readString(value.entity) } : {}),
        ...(readString(value.keyField) ? { keyField: readString(value.keyField) } : {}),
        ...(readStringArray(value.filters).length ? { filters: readStringArray(value.filters) } : {}),
        ...(readStringArray(value.sort).length ? { sort: readStringArray(value.sort) } : {}),
        ...(readString(value.pagination) ? { pagination: readString(value.pagination) } : {}),
        ...(readString(value.selection) ? { selection: readString(value.selection) } : {}),
        ...(readStringArray(value.output).length ? { output: readStringArray(value.output) } : {}),
    };
}
function readCbOutputField(value) {
    if (!isRecord(value))
        return null;
    const name = readString(value.name);
    const type = readString(value.type);
    if (!name || !type)
        return null;
    const field = { name, type, required: value.required === true };
    const fieldRef = readString(value.fieldRef);
    if (fieldRef)
        field.fieldRef = fieldRef;
    if (isRecord(value.item) && Array.isArray(value.item.fields)) {
        const fields = value.item.fields.map(readCbOutputField).filter((f) => f !== null);
        if (fields.length)
            field.item = { fields };
    }
    return field;
}
function readOutputShape(value) {
    if (!isRecord(value))
        return undefined;
    const kind = readString(value.kind);
    const fields = Array.isArray(value.fields)
        ? value.fields.map(readCbOutputField).filter((f) => f !== null)
        : [];
    if (!kind || fields.length === 0)
        return undefined;
    return { kind, fields };
}
function readOperationInputs(value) {
    return Array.isArray(value) ? value.filter(isRecord).map(raw => ({
        inputId: readString(raw.inputId),
        fieldRef: readString(raw.fieldRef),
        ...(readString(raw.type) ? { type: readString(raw.type) } : {}),
        required: raw.required === true,
        source: readString(raw.source),
        description: readString(raw.description),
        ...(Array.isArray(raw.enumValues) ? { enumValues: raw.enumValues.filter((item) => typeof item === 'string') } : {}),
    })).filter(input => !!input.inputId || !!input.fieldRef) : [];
}
function readContextResolution(value) {
    return Array.isArray(value) ? value.filter(isRecord).map(raw => ({
        ...(readString(raw.inputId) ? { inputId: readString(raw.inputId) } : {}),
        targetRef: readString(raw.targetRef),
        source: readString(raw.source),
        originRef: readString(raw.originRef),
        description: readString(raw.description),
    })).filter(item => !!item.targetRef || !!item.originRef) : [];
}
// ── aggregate derivation (baseline; the LLM index agent may refine) ────────────
export function deriveAggregates(entities, relationships, operatedRootIds = new Set()) {
    const byId = new Map(entities.map(e => [e.entityId, e]));
    const buildAggregate = (root) => {
        const embeddedMembers = [];
        const events = [];
        const mdmRefs = [];
        for (const rel of relationships) {
            // a supporting child related to this root (root -> child) folds into the root details JSONB
            const childId = rel.fromEntity === root.entityId ? rel.toEntity : rel.toEntity === root.entityId ? rel.fromEntity : '';
            if (!childId)
                continue;
            const child = byId.get(childId);
            if (!child)
                continue;
            if (child.kind === 'supporting' && (rel.type === 'oneToMany' || rel.type === 'oneToOne'))
                push(embeddedMembers, childId);
            else if (child.kind === 'event')
                push(events, childId);
            else if (child.kind === 'mdm')
                push(mdmRefs, childId);
            // `external` children are neither members nor mdm refs: the FK carries an id resolved outside.
        }
        return { aggregateId: root.entityId, rootEntity: root.entityId, embeddedMembers, events, mdmRefs };
    };
    const aggregates = entities.filter(e => e.kind === 'core').map(buildAggregate);
    // Invariant: any entity an operation acts on as a root (operatedRootIds = operation.entity + writes)
    // must own an entity+port+table — UNLESS it is embedded in another aggregate (a child folded into
    // details JSONB) or is an mdm/event entity. This keeps generation robust when the ontology
    // under-classifies kinds (e.g. a standalone "table"/"category" marked supporting): without it the
    // usecases that reference its port would import a module that was never generated.
    const embedded = new Set(aggregates.flatMap(a => a.embeddedMembers));
    const roots = new Set(aggregates.map(a => a.rootEntity));
    for (const id of operatedRootIds) {
        const e = byId.get(id);
        if (!e || roots.has(id) || embedded.has(id) || e.kind === 'mdm' || e.kind === 'event' || e.kind === 'external' || e.kind === 'derived' || e.storageTarget === 'derived')
            continue;
        aggregates.push(buildAggregate(e));
        roots.add(id);
    }
    return aggregates;
}
/** Heuristic: a field needs a real column when it is the id (PK), a reference/FK (type is an entity
 * id or ends with "Id"), a status/lifecycle field, or an ordering timestamp (createdAt). Everything
 * else goes into details JSONB. Deterministic column plan consumed by the table/adapter generators. */
export function planTableColumns(fields, knownEntityIds) {
    const indexed = [];
    const details = [];
    for (const f of fields) {
        const fieldId = readString(f.fieldId);
        if (!fieldId)
            continue;
        const type = readString(f.type);
        const isId = fieldId === 'id' || /Id$/.test(fieldId);
        const isRef = knownEntityIds.has(type);
        const isStatus = fieldId === 'status' || Array.isArray(f.enum);
        const isSearch = fieldId === 'title' || fieldId === 'name';
        const isOrderTs = fieldId === 'createdAt' || /At$/.test(fieldId) || type === 'date' || type === 'datetime';
        if (isId || isRef || isStatus || isSearch || isOrderTs) {
            const enumValues = Array.isArray(f.enum)
                ? f.enum.filter((v) => typeof v === 'string' && !!v.trim())
                : [];
            indexed.push({
                fieldId,
                reason: isId ? 'pk/fk' : isRef ? 'fk' : isStatus ? 'status' : isSearch ? 'search' : 'ordering',
                type,
                ...(enumValues.length ? { enum: enumValues } : {}),
            });
        }
        else {
            details.push(fieldId);
        }
    }
    return { indexed, details };
}
// ── l1 hexagonal file-info builders ────────────────────────────────────────────
const L1 = 1;
function defs(folder, shortName) {
    return { project: mls.actualProject || 0, level: L1, folder, shortName: toSafeShortName(shortName), extension: '.defs.ts' };
}
export function domainEntityFileInfo(m, entityId) { return defs(`${m}/layer_3_domain/entities`, lowerFirst(entityId)); }
export function valueObjectFileInfo(m, memberId) { return defs(`${m}/layer_3_domain/value-objects`, lowerFirst(memberId)); }
export function repositoryPortFileInfo(m, entityId) { return defs(`${m}/layer_2_application/ports`, `${lowerFirst(entityId)}Repository`); }
export function usecaseFileInfo(m, usecaseId) { return defs(`${m}/layer_2_application/usecases`, lowerFirst(usecaseId)); }
export function persistenceTableFileInfo(m, tableId) { return defs(`${m}/layer_1_external/adapters/persistence`, lowerFirst(tableId)); }
export function persistenceSeedsFileInfo(m) { return defs(`${m}/layer_1_external/adapters/persistence`, 'seeds'); }
export function repositoryAdapterFileInfo(m, entityId) { return defs(`${m}/layer_1_external/adapters/persistence`, `${lowerFirst(entityId)}RepositoryAdapter`); }
export function httpControllerFileInfo(m, pageId) { return defs(`${m}/layer_1_external/adapters/http/controllers`, lowerFirst(pageId)); }
// ── defs reuse (staleness) ──────────────────────────────────────────────────────
// Regenerating .defs.ts via the LLM is the dominant cost of a re-run (~1h for a module). Mirror the
// materializer's staleness model at the DEFS level: a generated l1 .defs.ts is reusable when it
// already exists AND was written at/after the newest L4 input (nothing upstream changed). A step then
// skips the LLM for current components and regenerates only what is missing/stale. Callers gate this:
// /rebuild forces regeneration (isRebuildCommand), and a pending repair finding also forces it.
function fileModifiedMs(info) {
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(info)];
        if (!file || file.status === 'deleted')
            return null;
        if (file.updatedAt)
            return Date.parse(String(file.updatedAt));
        return (file.status === 'new' || file.status === 'changed') ? Number.MAX_SAFE_INTEGER : null;
    }
    catch {
        return null;
    }
}
/** Newest mtime (ms) among all L4 `.defs.ts` of the project — the "input changed" watermark. Any l1
 * defs written at/after this is current; anything older (or a changed L4) forces regeneration. */
export function newestL4DefsMs(project) {
    let newest = 0;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (String(file.extension) !== '.defs.ts')
            continue;
        const ms = file.updatedAt ? Date.parse(String(file.updatedAt)) : ((file.status === 'new' || file.status === 'changed') ? Number.MAX_SAFE_INTEGER : 0);
        if (ms > newest)
            newest = ms;
    }
    return newest;
}
/** Pure staleness decision (extracted for unit testing): a generated defs is current when it exists
 * (non-null mtime) and was written at/after the L4 watermark. */
export function defsIsCurrent(defsMs, l4WatermarkMs) {
    return defsMs != null && defsMs >= l4WatermarkMs;
}
/** Whether the generated `.defs.ts` for `fileInfo` can be reused (exists + at/after the L4 watermark). */
export function defsCurrent(fileInfo, l4WatermarkMs) {
    return defsIsCurrent(fileModifiedMs(fileInfo), l4WatermarkMs);
}
/** A /rebuild forces fresh output — reuse is bypassed. (run/bare reuses current defs.) */
export function isRebuildCommand(context) {
    const cmd = readCliCommand(context);
    return cmd === 'rebuild-all' || cmd === 'rebuild-defs';
}
// ── co-located agent prompt assets ─────────────────────────────────────────────
export const CB_AGENT_PROJECT = 102021;
export const CB_AGENT_FOLDER = 'agentChangeBackend';
/** Read a co-located LLM prompt at runtime. Prompts live next to their step agent as
 * `agentChangeBackend/steps/<slug>/prompt.md` (moved into the step folders on 2026-07-11,
 * step 4; inline template strings were extracted in step 2). Each file
 * keeps its `<!-- modelType: ... -->` marker; the caller still replaces the {{toolName}} placeholder.
 * `folderRel` is relative to this agent folder (e.g. 'steps/gen-domain'); fixed to project 102021 (the
 * agent's own files), NOT the client mls.actualProject. */
export async function readCbPrompt(folderRel, shortName = 'prompt') {
    const fileInfo = { project: CB_AGENT_PROJECT, level: 2, folder: `${CB_AGENT_FOLDER}/${folderRel}`, shortName, extension: '.md' };
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted')
        throw new Error(`[readCbPrompt] prompt not found: ${folderRel}/${shortName}.md`);
    const raw = await file.getContent();
    if (typeof raw !== 'string')
        throw new Error(`[readCbPrompt] prompt is not text: ${folderRel}/${shortName}.md`);
    return raw;
}
// ── defs writer (main export + pipeline export, self-sufficient) ───────────────
export function defsRef(fileInfo) {
    return `_${fileInfo.project}_/l${fileInfo.level}/${fileInfo.folder}/${fileInfo.shortName}.defs.ts`;
}
/** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
export function dtsRef(fileInfo) {
    return defsRef(fileInfo).replace(/\.defs\.ts$/, '.d.ts');
}
/** Standard planning envelope shared by every .defs.ts data block. */
export function buildArtifact(artifactType, artifactId, moduleName, agentName, data) {
    return { schemaVersion: '2026-06-26', artifactType, artifactId, moduleName, status: 'draft', source: { agentName, stepId: 0, planId: '' }, data };
}
/** Materialization context for a layer: the hexagonal base architecture skill + the per-type skill
 * (both co-located with this agent) + the platform defs. */
export function layerSkills(skillFile) {
    return [
        '_102021_/l2/agentChangeBackend/skills/architecture.md',
        `_102021_/l2/agentChangeBackend/skills/${skillFile}`,
        '_102034_.d.ts',
    ];
}
/** Build the pipeline item that makes a .defs.ts self-sufficient for materialization (agentCbMaterialize
 * in-flow, or the cbMaterializeCli Node runner): it carries the outputPath (.ts), the dependsFiles
 * (.d.ts of the inner callee layer) and skills (the LLM context = layer skill + platform defs).
 * See spec.md (auto-suficiência). */
export function buildPipelineItem(shortName, type, fileInfo, dependsFiles, skills, opts = {}) {
    const defPath = defsRef(fileInfo);
    return {
        id: `${shortName}__${type}`,
        type,
        outputPath: defPath.replace(/\.defs\.ts$/, '.ts'),
        defPath,
        dependsFiles,
        dependsOn: [],
        skills,
        ...(opts.rulesPath ? { rulesPath: opts.rulesPath } : {}),
        ...(opts.rulesApplied && opts.rulesApplied.length ? { rulesApplied: opts.rulesApplied } : {}),
        agent: 'agentCbMaterialize',
    };
}
/** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
 * (optionally) the `export const pipeline`. Force-overwrites. */
export async function saveDefs(fileInfo, exportName, data, pipeline) {
    const ref = defsRef(fileInfo);
    let src = `/// <mls fileReference="${ref}" enhancement="_blank"/>\n\n`;
    src += `export const ${exportName} = ${JSON.stringify(data, null, 2)} as const;\n\nexport default ${exportName};\n`;
    if (pipeline && pipeline.length)
        src += `\nexport const pipeline = ${JSON.stringify(pipeline, null, 2)} as const;\n`;
    return writeDefsSource(fileInfo, src);
}
/** Write a .defs.ts verbatim. Used to update a file this agent does not own the shape of. */
export async function writeDefsSource(fileInfo, src) {
    const ref = defsRef(fileInfo);
    const info = mls.stor.convertFileReferenceToFile(ref);
    const key = mls.stor.getKeyToFile(info);
    let file = mls.stor.files[key];
    // A .defs.ts is data for this agent, not a compile input. Creating a Monaco model just to WRITE
    // it is the leak measured on be4 (createStorFile -> createModel, listeners 200 -> 336). An
    // existing file is updated in place — re-add with versionRef '0' is also the SW `add` with
    // content length undefined (F4). New files: createStorFile without a model (same as saveJsonStor).
    if (!file) {
        const param = { ...info, source: src };
        file = await createStorFile(param, false, false, false);
    }
    if (file.status !== 'renamed' && file.status !== 'new')
        file.status = 'changed';
    // Bump updatedAt so staleness (isStale: defs newer than .ts) re-materializes after a regen — the
    // shared libStor.createStorFile does not set it (unlike core agentDefs.createStorFile).
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: src });
    refreshExistingModel(file, src);
    return ref;
}
/**
 * Keep an ALREADY EXISTING Monaco model in sync with the content just persisted. Not cosmetic: the
 * Studio<->disk sync reads a file from its model first and only falls back to the stor content when
 * there is no model, and libModel.createModel hands back an existing model untouched (no setValue).
 * So without this, the SECOND write onwards updates the stor while the model stays frozen at the
 * first one, and the next export writes that first snapshot over the good content — the petShop lost
 * update of 2026-08-21 (65 todoBackend writes, disk got the state after write #1).
 *
 * Never CREATES a model: an unowned model is a leak (see releaseBorrowedModels/sweepModuleModels), and
 * with no model the export already reads the stor, which is correct.
 */
function refreshExistingModel(file, src) {
    try {
        const model = mls.editor.getModel(file);
        if (model?.model && model.model.getValue() !== src)
            model.model.setValue(src);
    }
    catch (error) {
        console.warn('[cb writeDefsSource] model refresh failed', error);
    }
}
export async function saveBackendWorkspaceConfig() {
    const project = mls.actualProject || 0;
    if (!project)
        return 'l5/config.json backend skipped: project unavailable';
    const l5 = await readJsonStor({ project, level: 5, folder: '', shortName: 'project', extension: '.json' });
    if (!isRecord(l5))
        return 'l5/config.json backend skipped: l5/project.json not found';
    const masters = isRecord(l5.masters) ? l5.masters : {};
    const backendSignature = isRecord(masters.backend) ? masters.backend : {};
    const runtimeId = readId(backendSignature.runtimeProject) || '102034';
    const config = await readJsonStor({ project, level: 5, folder: '', shortName: 'config', extension: '.json' });
    const workspace = isRecord(config) ? config : {};
    workspace.defaultProjectId = readId(workspace.defaultProjectId) || String(project);
    const projects = ensureRecordProperty(workspace, 'projects');
    const client = ensureProjectConfig(projects, String(project), { root: '.', type: 'client', runtime: projectRuntimeMetadata(l5, String(project)) });
    const backendRuntime = isRecord(projects[runtimeId]) ? projects[runtimeId] : {};
    projects[runtimeId] = { ...backendRuntime, root: `../mls-${runtimeId}`, type: 'master backend' };
    projects['102029'] = isRecord(projects['102029']) ? projects['102029'] : { root: '../mls-102029', type: 'lib' };
    const live = liveBackendModulesFromL5(l5.modules);
    if (live.length === 0)
        return 'l5/config.json backend merged (0 module(s))';
    const reconciled = reconcileClientBackendRegistration(Array.isArray(client.modules) ? client.modules.filter(isRecord) : [], Array.isArray(client.persistenceModules) ? client.persistenceModules.filter(isRecord) : [], live);
    client.modules = reconciled.modules;
    client.persistenceModules = reconciled.persistenceModules;
    await saveJsonStor({ project, level: 5, folder: '', shortName: 'config', extension: '.json' }, workspace);
    return `l5/config.json backend merged (${live.length} module(s))${formatDiscardedOrphans(reconciled.discarded)}`;
}
async function readJsonStor(fileInfo) {
    try {
        const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        return file && file.status !== 'deleted' ? JSON.parse(String(await file.getContent())) : null;
    }
    catch {
        return null;
    }
}
async function saveJsonStor(fileInfo, data) {
    const source = `${JSON.stringify(data, null, 2)}\n`;
    const key = mls.stor.getKeyToFile(fileInfo);
    let file = mls.stor.files[key];
    if (!file)
        file = await createStorFile({ ...fileInfo, source }, false, false, false);
    if (file.status !== 'renamed' && file.status !== 'new')
        file.status = 'changed';
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: source });
    // Same reason as writeDefsSource, and it bites even on a SINGLE write: createStorFile registers no
    // model for `.json`, but a config.json open in a Studio tab has one, and the export prefers it — the
    // backend merge would be silently lost, and this is the one write here that a re-run does not redo.
    refreshExistingModel(file, source);
}
function ensureRecordProperty(target, key) {
    if (!isRecord(target[key]))
        target[key] = {};
    return target[key];
}
function ensureProjectConfig(projects, id, patch) {
    const existing = isRecord(projects[id]) ? projects[id] : {};
    projects[id] = { ...existing, ...patch };
    return projects[id];
}
function projectRuntimeMetadata(l5, clientId) {
    return {
        projectId: readId(l5.projectId) || clientId,
        domain: l5.domain,
        port: l5.port,
        databaseName: l5.databaseName,
        environment: l5.environment,
        studioEnabled: l5.studioEnabled,
    };
}
function readId(value) {
    if (typeof value === 'number' && Number.isFinite(value))
        return String(value);
    return readString(value);
}
export async function saveAgentTrace(context, agentName, step, counters) {
    if (!shouldSaveTrace(context))
        return;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            return;
        const scan = await readBackendScan(ALL_STATUSES, context).catch(() => null);
        const moduleName = scan?.moduleNames?.[0] || 'backend';
        // The trace is what a post-mortem reads. Besides the payload it carries WHAT THE STEP COST and what
        // it did: the model/tokens/cost of the interaction and the counters the caller chose to publish —
        // otherwise every analysis has to be reconstructed by hand from the msgtask plus the console.
        // Write the declared .json via fileInfo directly (same path as saveRunReport). Do NOT go through
        // defsRef: that helper is for table/entity defs and crushes the extension to `.defs.ts`.
        await saveJsonStor(agentTraceFileInfo(moduleName, agentName, step.stepId, mls.actualProject || 0), {
            savedAt: new Date().toISOString(),
            agentName,
            stepId: step.stepId,
            planning: step.planning || null,
            status: step.status,
            interaction: interactionSummary(step.interaction),
            counters: counters || null,
            payload,
        });
    }
    catch (error) {
        console.warn(`[cb saveAgentTrace] failed for ${agentName}`, error);
    }
}
/** Cost, tokens and model of one interaction — the numbers a run report sums up. */
function interactionSummary(interaction) {
    if (!interaction)
        return null;
    const trace = (interaction.trace ?? []).map(String);
    const parsed = parseStepCost(trace);
    const model = trace.map(line => /model[:=]\s*([\w.\-/]+)/i.exec(line)?.[1]).find(Boolean) || '';
    return {
        cost: typeof interaction.cost === 'number' && interaction.cost > 0 ? interaction.cost : parsed.cost,
        inputTokens: parsed.inputTokens,
        outputTokens: parsed.outputTokens,
        ...(model ? { model } : {}),
    };
}
function shouldSaveTrace(context) {
    try {
        const longMemory = context.task?.iaCompressed?.longMemory;
        const flag = longMemory?._saveTrace;
        if (flag === 'true')
            return true;
        if (flag === 'false')
            return false;
    }
    catch {
        // use default
    }
    return true;
}
// ── todoBackend mutation (deterministic) ───────────────────────────────────────
/** Update only l5/{module}/todoBackend.defs.ts. l4 owner defs are read-only for this agent. */
export async function setTodoBackendStatus(owner, status) {
    const project = mls.actualProject || 0;
    const candidates = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 5 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || String(file.shortName || '') !== 'todoBackend')
            continue;
        candidates.push({ folder: String(file.folder || ''), content: String(await file.getContent()), file });
    }
    const hit = selectTodoBackendFileForStatusWrite(candidates, owner);
    if (!hit)
        return false;
    const { file, content } = hit;
    const parsed = parseDefsSource(content);
    if (!isRecord(parsed))
        return false;
    const owners = Array.isArray(parsed.owners) ? parsed.owners.filter(isRecord) : [];
    const todoOwner = owners.find(raw => todoOwnerType(readString(raw.ownerType)) === owner.kind && readString(raw.ownerId) === owner.id);
    if (!todoOwner)
        return false;
    const fileInfo = { project, level: 5, folder: String(file.folder || owner.moduleName), shortName: 'todoBackend', extension: '.defs.ts' };
    // Write the status back into the field it was read from, and keep the rest of the file as the
    // generator wrote it: re-serializing would drop its `import type` and its `satisfies`.
    todoOwner[todoStatusField(todoOwner) || 'status'] = status;
    const preserved = replaceDefsValue(content, parsed);
    // `updatedAt` is this agent's own bookkeeping: an artifact typed with `satisfies` rejects the
    // extra property, so it is only added on the path that rewrites the file wholesale.
    if (preserved) {
        await writeDefsSource(fileInfo, preserved);
        return true;
    }
    const exportName = readExportName(content);
    if (!exportName)
        return false;
    parsed.updatedAt = new Date().toISOString();
    await saveDefs(fileInfo, exportName, parsed);
    return true;
}
/** Every surface of the read-back that disagrees with what the run believes it wrote. */
export function todoReadBackDivergences(readBack) {
    if (!readBack)
        return [];
    return [...readBack.stor.divergent, ...readBack.model.divergent];
}
export function todoReadBackIsClean(readBack) {
    return Boolean(readBack) && !readBack.missingModule && !readBack.stor.unreadable && !readBack.model.unreadable && todoReadBackDivergences(readBack).length === 0;
}
/**
 * Is this a read-back the run must DIE on? Divergence on either surface, yes — that is the lost update.
 * An unparseable STOR, yes — the durable state stopped being readable. An unparseable MODEL, no, only a
 * loud warning: that is somebody editing todoBackend.defs.ts in a Studio tab with the syntax momentarily
 * broken, which is their editor and not this agent's write.
 */
export function todoReadBackIsFatal(readBack) {
    if (!readBack)
        return false;
    if (readBack.missingModule)
        return true;
    return readBack.stor.unreadable || todoReadBackDivergences(readBack).length > 0;
}
/**
 * Re-read todoBackend and compare it with the statuses this run believes it wrote — on BOTH surfaces
 * that can become the file on disk. Reading only the stor is not enough: in the petShop incident the
 * stor was RIGHT (65 done) and the stale Monaco model was what got exported, so a stor-only read-back
 * would have passed the run that produced the corrupt file.
 */
export async function readBackTodoBackend(expected, moduleName = '') {
    const project = mls.actualProject || 0;
    const matches = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 5 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || String(file.shortName || '') !== 'todoBackend')
            continue;
        matches.push({ folder: String(file.folder || ''), file });
    }
    const pick = pickTodoBackendReadBack(matches.map(m => m.folder), moduleName);
    if (pick.kind === 'none')
        return null;
    if (pick.kind === 'module-missing') {
        return {
            ref: pick.ref,
            checked: expected.size,
            missingModule: pick.moduleName,
            stor: { unreadable: false, divergent: [] },
            model: { present: false, unreadable: false, divergent: [] },
        };
    }
    const file = matches.find(m => m.folder === pick.folder).file;
    const storContent = String(await file.getContent());
    const storDivergent = todoStatusDivergences(storContent, expected);
    let modelPresent = false;
    let modelDivergent = [];
    try {
        const model = mls.editor.getModel(file);
        if (model?.model) {
            modelPresent = true;
            modelDivergent = todoStatusDivergences(model.model.getValue(), expected);
        }
    }
    catch (error) {
        console.warn('[cb readBackTodoBackend] model read failed', error);
        modelDivergent = null;
    }
    return {
        ref: pick.ref,
        checked: expected.size,
        stor: { unreadable: storDivergent === null, divergent: storDivergent || [] },
        model: { present: modelPresent, unreadable: modelPresent && modelDivergent === null, divergent: modelDivergent || [] },
    };
}
// ── intent / step helpers (mirrored, self-contained) ───────────────────────────
export function createUpdateStatusIntent(context, parentStep, step, hookSequential, status, traceMsg, cleaner, newTaskTitle) {
    const intent = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep?.stepId ?? step.stepId,
        stepId: step.stepId,
        status,
        traceMsg,
    };
    if (cleaner)
        intent.cleaner = cleaner;
    // Rename the running task once the module name is known (the scan step resolves it). Mirrors the
    // e1-draft "plan <module>" rename on agentNewSolution.
    if (newTaskTitle)
        intent.newTaskTitle = newTaskTitle;
    return intent;
}
export function createAgentStepPayload(planId, agentName, stepTitle, args, dependsOn, executionMode, status = 'waiting_dependency', dynamicSource) {
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle,
        status,
        nextSteps: [],
        agentName,
        prompt: typeof args === 'string' ? args : JSON.stringify(args ?? {}),
        rags: [],
        planning: { planId, dependsOn, executionMode, executionHost: 'client', ...(dynamicSource ? { dynamicSource } : {}) },
    };
}
/**
 * Start the next step INSIDE its phase. Steps that stay in the same phase keep using `enqueueNext`:
 * their parent already IS the phase, so a sibling lands in it for free. Only a phase TRANSITION goes
 * through here.
 *
 * A phase can only receive children while it is open, so it is created lazily with its first child
 * inside it (agentCbPhase adds that child from within the phase's own hook) — never pre-created empty
 * and then completed, which would make every later child throw.
 *
 * `dependsOnPlanId` overrides the default barrier (the CURRENT step). A DISPATCHER that just spawned a
 * parallel fan-out must pass the FAN-OUT's planId: the dispatcher completes the instant it returns its
 * intents, so depending on it lets the next phase start while the workers are still writing. That is
 * exactly what happened on 2026-08-28 (102047/todo): cb-judge depended on cb-gen-usecase instead of
 * cb-usecase-fanout, so the judge saw 0/9 usecase defs and cb-gen-http saw 4/9 — 5 bffCalls and a whole
 * workspace silently lost their controller. cb-gen-port already does it right (dependsOn the fan-out).
 */
export function enqueueNextInPhase(context, currentStep, phase, planId, agentName, stepTitle, args = {}, onFailure, dependsOnPlanId) {
    const dep = dependsOnPlanId || planIdOf(currentStep);
    const { planId: phasePlanId, title } = CB_PHASES[phase];
    const child = { planId, agentName, stepTitle, args: { planId, ...(args && typeof args === 'object' ? args : {}) }, onFailure };
    const open = findOpenStepByPlanId(context, phasePlanId);
    if (open) {
        const next = createAgentStepPayload(planId, agentName, stepTitle, child.args, dep ? [dep] : [], 'sequential', 'waiting_dependency');
        if (onFailure)
            next.onFailure = onFailure;
        return createAddStepIntent(context, open, next);
    }
    const phaseStep = createAgentStepPayload(phasePlanId, 'agentCbPhase', title, { planId: phasePlanId, first: child }, dep ? [dep] : [], 'sequential', 'waiting_dependency');
    // The phase belongs to the run, not to the step that opened it: it hangs from the task root.
    return { type: 'add-step', messageId: context.message.orderAt, threadId: context.message.threadId, taskId: context.task?.PK || '', parentStepId: 1, step: phaseStep };
}
/** An agent step with this planId that can still receive children. */
export function findOpenStepByPlanId(context, planId) {
    const steps = flattenSteps(context.task?.iaCompressed?.nextSteps);
    return steps.find(step => step.type === 'agent'
        && step.planning?.planId === planId
        && step.status !== 'completed' && step.status !== 'failed') || null;
}
function flattenSteps(steps) {
    const out = [];
    for (const item of steps || []) {
        if (!item || typeof item !== 'object')
            continue;
        const step = item;
        out.push(step);
        out.push(...flattenSteps(step.nextSteps));
    }
    return out;
}
export function createAddStepIntent(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
export function createPromptReadyIntent(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, toolSchema, toolName) {
    if (!context.task)
        throw new Error('[createPromptReadyIntent] task invalid');
    // A prompt bigger than the transport accepts used to surface as an uncaught 413 in the client and
    // left the step hanging in waiting_human_input with nothing on the task. Fail it here instead, with
    // a message that names the step and the size.
    const oversize = promptSizeError(`[createPromptReadyIntent] ${parentStep.agentName || 'step'}`, humanPrompt, systemPrompt);
    if (oversize)
        throw new Error(oversize);
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task.PK,
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [toolSchema],
        toolChoice: { type: 'function', function: { name: toolName } },
    };
}
/**
 * How many children of a fan-out run at once. Run 9 finished with 0 provider errors and 0 fallbacks
 * while the effective parallelism was only ~2× (LLM time 2:06 against 1:02 of wall clock) — the
 * provider had room, so the default moved from 5/10 to 20. A single place decides it.
 */
export const CB_MAX_PARALLEL = 20;
/** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
export function createParallelStepIntent(context, parentStep, planId, agentName, stepTitle, args, dependsOn = [], maxParallel = CB_MAX_PARALLEL) {
    const step = createAgentStepPayload(planId, agentName, stepTitle, {}, dependsOn, 'parallel_dynamic', 'in_progress');
    // Children inherit onFailure from the fan-out parent. Without 'continue', an LLM-CALL failure
    // (e.g. proxy 502 after a TOOL_ARGS_SCHEMA reject on primary+fallback) marks the child failed AND
    // the whole task failed (runLLMStepParallel default branch) — bypassing the repair loop entirely.
    // With 'continue' the child proceeds to afterPromptStep, which finds no payload, records the repair
    // finding and COMPLETES the step, exactly like every other worker failure class.
    step.onFailure = 'continue';
    step.interaction = {
        input: [{ type: 'system', content: '<!-- modelType: code -->' }],
        cost: 0,
        trace: [`queued ${args.length} parallel args for ${agentName}`],
        payload: null,
    };
    return { ...createAddStepIntent(context, parentStep, step), executionMode: { type: 'parallel', args, maxParallel } };
}
export function logPrefix(agent) {
    return `[${agent.agentName} v1]`;
}
export function planIdOf(step) {
    return step?.planning?.planId || '';
}
/** The CLI command the root stored in the task longMemory (rebuild-all | rebuild-defs | run | help). */
export function readCliCommand(context) {
    const lm = context.task?.iaCompressed?.longMemory;
    return typeof lm?.cliCommand === 'string' ? lm.cliCommand : '';
}
/** T11: true when the run was started with `--no-assets` — the optional seed-image step is skipped
 *  entirely (it completes with a warning and the seeds stay intact). Mirrors readCliCommand. */
export function readNoAssets(context) {
    const lm = context.task?.iaCompressed?.longMemory;
    return lm?.noAssets === 'true' || lm?.noAssets === true;
}
/** The target module the root stored in the task longMemory. Empty means "auto": readBackendScan
 * scopes to the first (sorted) module with owners in the requested statuses. Mirrors readCliCommand. */
export function readTargetModule(context) {
    const lm = context.task?.iaCompressed?.longMemory;
    return typeof lm?.targetModule === 'string' ? lm.targetModule.trim() : '';
}
/** Count of l1 files `/rebuild all` archived at bootstrap — empty when this run did not archive. */
export function readRebuildArchived(context) {
    const lm = context.task?.iaCompressed?.longMemory;
    return typeof lm?.rebuildArchived === 'string' ? lm.rebuildArchived.trim() : '';
}
/** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
 * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
 * compile; parallelization is a later optimization. */
export function enqueueNext(context, parentStep, currentStep, planId, agentName, stepTitle, args = {}, onFailure) {
    const dep = planIdOf(currentStep);
    // Steps are SIBLINGS under the same parent (NEVER nested under the current step — that would
    // deadlock: parent waits for child, child depends on parent). Uniqueness for the runtime's hook
    // dispatch key comes from UNIQUE ARGS (the planId embedded in the prompt), not from the parent.
    const mergedArgs = { planId, ...(args && typeof args === 'object' ? args : {}) };
    const next = createAgentStepPayload(planId, agentName, stepTitle, mergedArgs, dep ? [dep] : [], 'sequential', 'waiting_dependency');
    // 'continue' lets afterPromptStep run even when the LLM call itself fails (proxy error / no payload),
    // so a step that soft-handles failures is not force-failed by the runtime before it can react.
    if (onFailure)
        next.onFailure = onFailure;
    return createAddStepIntent(context, parentStep, next);
}
// ── small parsers ──────────────────────────────────────────────────────────────
function readExportName(content) {
    const m = content.match(/export const\s+([A-Za-z0-9_$]+)\s*=/);
    return m ? m[1] : '';
}
export function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
export function readStringArray(value) {
    return Array.isArray(value) ? value.map(readString).filter(Boolean) : [];
}
export function lowerFirst(value) {
    return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
}
export function capitalize(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}
export function toSafeShortName(value) {
    return (value || '').trim().replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '') || 'artifact';
}
function push(list, value) {
    if (value && !list.includes(value))
        list.push(value);
}
