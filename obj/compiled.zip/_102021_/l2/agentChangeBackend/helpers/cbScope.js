/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbScope.ts" enhancement="_102027_/l2/enhancementAgent"/>
/** Resolve the target module and filter every collection to it. The target is the explicit requested
 * module, else the first (sorted) module that has owners in the caller's requested statuses, else the
 * first module overall. A requested-but-absent module yields empty owners plus a warning (so the run
 * finishes cleanly with "no work" instead of silently spanning modules). Relationships are kept only
 * when BOTH endpoints are in-scope entities, so no seeded/generated artifact dangles across modules. */
export function scopeBackendScan(input) {
    const pendingModules = [...new Set(input.owners.map(o => o.moduleName).filter(Boolean))].sort();
    const requested = input.requestedModule.trim();
    const moduleName = requested || pendingModules[0] || input.allModuleNames[0] || '';
    if (!moduleName) {
        return {
            moduleName: '',
            owners: input.owners, entities: input.entities, relationships: input.relationships,
            workspaces: input.workspaces, actors: input.actors, warning: null,
        };
    }
    const entities = input.entities.filter(e => e.moduleName === moduleName);
    const inScope = new Set(entities.map(e => e.entityId));
    const warning = (requested && !input.allModuleNames.includes(requested))
        ? `requested module '${requested}' not found in project modules [${input.allModuleNames.join(', ') || 'none'}]`
        : null;
    return {
        moduleName,
        owners: input.owners.filter(o => o.moduleName === moduleName),
        entities,
        relationships: input.relationships.filter(r => inScope.has(r.fromEntity) && inScope.has(r.toEntity)),
        workspaces: input.workspaces.filter(w => w.moduleName === moduleName),
        actors: input.actors.filter(a => a.moduleName === moduleName),
        warning,
    };
}
