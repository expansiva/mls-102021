/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbArchive.ts" enhancement="_blank"/>
/** Backend generated l1 lives under `<module>/layer_*`. Scope so one module never touches another. */
export function isGeneratedBackendFolder(folder, modules) {
    return modules.some(module => !!module && (folder === module || folder.startsWith(`${module}/`)));
}
function isModuleL1File(file, project, moduleName) {
    if (!file)
        return false;
    if (Number(file.project) !== project || Number(file.level) !== 1)
        return false;
    return isGeneratedBackendFolder(String(file.folder || ''), [moduleName]);
}
/** Keys of l1 files that `/rebuild all` must archive before regenerating.
 *  Everything under `l1/<mod>/`: `.ts` and `.defs.ts`, every layer, `seeds.ts`,
 *  `registerRepositories.ts`, including leftovers whose stor status is already `deleted`. */
export function listBackendL1ArchiveKeys(files, project, moduleName) {
    if (!moduleName)
        return [];
    const keys = [];
    for (const [key, file] of Object.entries(files)) {
        if (!isModuleL1File(file, project, moduleName))
            continue;
        keys.push(key);
    }
    return keys;
}
/** Live (not `deleted`) l1 files still in the index after a wipe. */
export function countBackendL1LiveFiles(files, project, moduleName) {
    if (!moduleName)
        return 0;
    let n = 0;
    for (const file of Object.values(files)) {
        if (!isModuleL1File(file, project, moduleName))
            continue;
        if (file?.status === 'deleted')
            continue;
        n++;
    }
    return n;
}
/** Count of l1 files of the module still in the index, including `status=deleted`. */
export function countBackendL1IndexedFiles(files, project, moduleName) {
    if (!moduleName)
        return 0;
    let n = 0;
    for (const file of Object.values(files)) {
        if (isModuleL1File(file, project, moduleName))
            n++;
    }
    return n;
}
export function rebuildAllWipedMessage(moduleName, wiped) {
    return `rebuild-all wiped ${wiped} file(s) of l1/${moduleName}`;
}
/** A wipe that counted files and still left live ones is not a rebuild-all — abort the run. */
export function rebuildWipeShouldAbort(wiped, leftover) {
    return wiped > 0 && leftover > 0;
}
/** Trace line plus optional finding when a populated module wipes 0, or live files remain. */
export function describeRebuildWipe(moduleName, wiped, indexed, leftover) {
    const message = rebuildAllWipedMessage(moduleName, wiped);
    const abort = rebuildWipeShouldAbort(wiped, leftover);
    if (wiped === 0 && indexed > 0) {
        return { message, finding: `${message} but the index still has ${indexed} file(s)`, abort };
    }
    if (leftover > 0) {
        return { message, finding: `${message}; ${leftover} live file(s) remain`, abort };
    }
    return { message, finding: null, abort };
}
