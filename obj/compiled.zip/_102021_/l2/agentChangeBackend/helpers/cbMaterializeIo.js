/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_blank"/>
// Platform I/O glue for the in-studio materializer (agentCbMaterialize), vendored into agentChangeBackend
// so it does not depend on agentMaterializeSolution (being removed). Pure mls.stor / libStor access; the
// pure prompt/parse/order logic lives in cbMaterializeCore.ts (shared with the Node CLI).
import { isModelAlreadyExistsError, mlsImportPathParts, phantomModulePathOf } from '/_102021_/l2/agentChangeBackend/helpers/cbDefsSource.js';
import { createStorFile } from '/_102027_/l2/libStor.js';
import { syntaxDiagnostics } from '/_102021_/l2/agentChangeBackend/helpers/cbSyntaxValidation.js';
import { countGroupedDiagnostics, mlsBaseFromDiskPath, traceProjectTscResult, } from '/_102021_/l2/agentChangeBackend/helpers/cbProjectTsc.js';
// L1 layer folders that may hold a .defs.ts with a pipeline (hexagonal: only layer_1_external in v1,
// but keep the full set so the scan is robust if defs land in other layers).
const L1_LAYERS = ['layer_1_external', 'layer_2_application', 'layer_3_domain', 'layer_4_entities', 'layer_3_usecases', 'layer_2_controllers'];
/** Extract the `pipeline` array from a .defs.ts content string. */
export function parsePipelineFromContent(content) {
    try {
        const match = content.match(/export\s+const\s+pipeline\s*=\s*([\s\S]*?)\s+as\s+const\s*;/u);
        if (!match)
            return null;
        return JSON.parse(match[1]);
    }
    catch {
        return null;
    }
}
/** Scan every l1 .defs.ts (with a pipeline) of a module. */
export async function scanL1DefsWithPipeline(project, moduleName) {
    const result = [];
    try {
        const prefix = `${moduleName}/`;
        for (const f of Object.values(mls.stor.files)) {
            if (f.project !== project)
                continue;
            if (f.level !== 1)
                continue;
            const folder = String(f.folder || '');
            if (!folder.startsWith(prefix))
                continue;
            if (!L1_LAYERS.some((layer) => folder === `${moduleName}/${layer}` || folder.startsWith(`${moduleName}/${layer}/`)))
                continue;
            if (f.extension !== '.defs.ts')
                continue;
            if (f.status === 'deleted')
                continue;
            if (f.shortName === 'module' || f.shortName === 'index')
                continue;
            const content = String(await f.getContent());
            const pipeline = parsePipelineFromContent(content);
            if (!pipeline || pipeline.length === 0)
                continue;
            result.push({ folder, shortName: f.shortName, pipeline });
        }
    }
    catch (err) {
        console.warn('[cbMaterializeIo] scanL1DefsWithPipeline failed', err);
    }
    return result;
}
/**
 * Whether the file is in this session's index at all — which `getFileModified` cannot say, because it
 * answers `null` both for "absent" and for "present, no usable timestamp". Conflating the two made a
 * resumed session read every generated .ts as never-generated and re-materialize files that were
 * already current (run of 2026-08-17: 14 of 34 controllers rewritten for nothing).
 */
export function fileIsPresent(project, level, folder, shortName, extension) {
    try {
        const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension });
        const file = mls.stor.files[key];
        return !!file && file.status !== 'deleted';
    }
    catch {
        return false;
    }
}
/** updatedAt (ms) of a file, MAX_SAFE_INTEGER when new/changed without a timestamp, else null. */
export function getFileModified(project, level, folder, shortName, extension) {
    try {
        const key = mls.stor.getKeyToFile({ project, level, folder, shortName, extension });
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        if (file.updatedAt)
            return Date.parse(file.updatedAt);
        const status = file.status;
        return (status === 'new' || status === 'changed') ? Number.MAX_SAFE_INTEGER : null;
    }
    catch {
        return null;
    }
}
/** Read any file by its full MLS path string. */
export async function getContentByMlsPath(mlsPath) {
    try {
        const info = mls.stor.convertFileReferenceToFile(mlsPath);
        const key = mls.stor.getKeyToFile(info);
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        return String(await file.getContent());
    }
    catch {
        return null;
    }
}
/** Parse a MLS path like `_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts`. */
export function parseMlsPath(mlsPath) {
    const match = mlsPath.match(/^_(\d+)_\/l(\d+)\/(.+)$/u);
    if (!match)
        return null;
    const project = parseInt(match[1], 10);
    const level = parseInt(match[2], 10);
    const rest = match[3];
    const lastSlash = rest.lastIndexOf('/');
    const folder = lastSlash >= 0 ? rest.slice(0, lastSlash) : '';
    const filename = lastSlash >= 0 ? rest.slice(lastSlash + 1) : rest;
    let shortName, extension;
    if (filename.endsWith('.defs.ts')) {
        shortName = filename.slice(0, -'.defs.ts'.length);
        extension = '.defs.ts';
    }
    else if (filename.endsWith('.d.ts')) {
        shortName = filename.slice(0, -'.d.ts'.length);
        extension = '.d.ts';
    }
    else {
        const dot = filename.lastIndexOf('.');
        shortName = dot >= 0 ? filename.slice(0, dot) : filename;
        extension = dot >= 0 ? filename.slice(dot) : '';
    }
    return { project, level, folder, shortName, extension };
}
/** Flatten a monaco diagnostic (messageText may be a chain) into a single line. */
function flattenDiagnostic(d) {
    const flat = (m) => {
        if (typeof m === 'string')
            return m;
        if (m && typeof m.messageText === 'string') {
            const next = Array.isArray(m.next) && m.next.length ? ` -> ${flat(m.next[0])}` : '';
            return `${m.messageText}${next}`;
        }
        return '';
    };
    const msg = flat(d?.messageText ?? d);
    const code = typeof d?.code === 'number' ? `TS${d.code}: ` : '';
    return msg ? `${code}${sanitizeModuleHint(msg)}` : '';
}
// The stock TS2792/TS2307 hint ("Did you mean to set the 'moduleResolution' option ... 'paths'?")
// teaches the repair model to abandon the '/_<project>_/...' alias for a relative path (observed in
// run task2/102049: six controllers rewritten to '../../../../...'). Replace it with the actual fix.
function sanitizeModuleHint(message) {
    return message.replace(/Did you mean to set the 'moduleResolution' option to '[^']+', or to add aliases to the 'paths' option\?/g, "Keep the '/_<project>_/l1/...' alias import exactly as in the context files — NEVER rewrite it as a relative path; the alias resolves once the target module is materialized.");
}
async function ensureImportModels(content) {
    // Models loaded HERE are BORROWED for one compile and released afterwards (see releaseImportModels).
    // A model already in the registry belongs to the Studio (it may be open in a tab) and is never ours
    // to release — the `continue` below is what makes the ownership unambiguous.
    const borrowed = [];
    for (const match of content.matchAll(/from\s+['"]\/_(\d+)_\/l1\/([^'"]+?)\.js['"]/gu)) {
        const importProject = Number(match[1]);
        if (!Number.isInteger(importProject) || importProject <= 0)
            continue;
        const path = match[2];
        const idx = path.lastIndexOf('/');
        if (idx <= 0)
            continue;
        const folder = path.slice(0, idx);
        const shortName = path.slice(idx + 1);
        if (mls.editor.models[mls.editor.getKeyModel(importProject, shortName, folder, 1)])
            continue;
        const fileInfo = { project: importProject, level: 1, folder, shortName, extension: '.ts' };
        let fileKey = mls.stor.getKeyToFile(fileInfo);
        if (!mls.stor.files[fileKey]) {
            // The session may simply not have indexed the other project yet — the same thing libModel does
            // before creating a model for a cross-project file. It is a READ of the project index; nothing
            // is written anywhere. Without it the import is skipped in silence and the compile blames the
            // generated file for a module that was there all along.
            await loadProjectIndexOnce(importProject);
            fileKey = mls.stor.getKeyToFile(fileInfo);
            if (!mls.stor.files[fileKey]) {
                console.warn(`[cbMaterializeIo] import /_${importProject}_/l1/${folder}/${shortName}.ts is not in this session's storage; its types cannot be loaded`);
                continue;
            }
        }
        const model = await loadImportModel(importProject, folder, shortName, false);
        if (model) {
            borrowed.push({ project: importProject, shortName, folder, level: 1 });
            // addModels loads sibling .defs.ts onto a separate registry key (shortName + '.defs').
            // Releasing only the .ts left those models resident (be5: 10× listener leak).
            const defsShort = `${shortName}.defs`;
            if (mls.editor.models[mls.editor.getKeyModel(importProject, defsShort, folder, 1)]) {
                borrowed.push({ project: importProject, shortName: defsShort, folder, level: 1 });
            }
        }
    }
    return borrowed;
}
/** Project indexes already asked for in this session: the load is idempotent but not free. */
const loadedProjectIndexes = new Set();
/** Ask the server for another project's file index (read-only), once per session. */
async function loadProjectIndexOnce(project) {
    if (loadedProjectIndexes.has(project))
        return;
    loadedProjectIndexes.add(project);
    try {
        await mls.stor.server.loadProjectInfoIfNeeded(project);
    }
    catch (error) {
        console.warn(`[cbMaterializeIo] could not load the file index of project ${project}`, error);
    }
}
/**
 * Load one import model, loudly. `addModels` used to be a bare best-effort call: a transient failure
 * left the compile without the model and produced a TS2792 that reads exactly like a broken import.
 * `force` drops whatever the registry holds first — a retry that respects the registry guard would be
 * a no-op precisely in the case worth retrying (an entry that exists but is unusable).
 */
async function loadImportModel(project, folder, shortName, force) {
    if (force) {
        try {
            mls.editor.deleteModels(project, shortName, folder, true, 1);
        }
        catch { /* nothing to drop */ }
    }
    try {
        await mls.editor.addModels(project, shortName, folder, 1);
        return true;
    }
    catch (error) {
        // "model already exists" is the platform's OLD behaviour: the model IS in Monaco under a key this
        // registry lost, so the create threw and the import stayed unborrowed. The editor now ADOPTS the
        // existing model instead of throwing (cfe-collab-front-end F1), so this branch should be dead — it
        // stays because the agent also runs on Studio builds that predate that fix, and there the goal (a
        // loaded model) is still met. The release is no longer a no-op either: a delete now reaches the
        // model by URI even when the two indexes diverge (F2).
        if (isModelAlreadyExistsError(error instanceof Error ? error.message : String(error))) {
            reportModelKeyMismatch(project, folder, shortName);
            return true;
        }
        console.warn(`[cbMaterializeIo] could not load import model /_${project}_/l1/${folder}/${shortName}.ts`, error);
        return false;
    }
}
/** Registry keys already reported: the mismatch is one fact per file, not one per compile. */
const reportedKeyMismatches = new Set();
/**
 * Log the key this agent computes next to the keys Monaco actually holds for the same file, ONCE.
 * The mismatch is what makes the registry guard blind (the model exists, the guard says it does not);
 * fixing `getKeyModel`/`createModelTS` is a platform decision, so this only produces the evidence.
 */
function reportModelKeyMismatch(project, folder, shortName) {
    const computed = mls.editor.getKeyModel(project, shortName, folder, 1);
    if (reportedKeyMismatches.has(computed))
        return;
    reportedKeyMismatches.add(computed);
    const present = Object.keys(mls.editor.models || {}).filter(key => key.includes(shortName)).slice(0, 4);
    console.info(`[cbMaterializeIo] model registry key mismatch for /_${project}_/l1/${folder}/${shortName}.ts — computed "${computed}", present ${JSON.stringify(present)}`);
}
/**
 * Diagnostics that blame an import whose SOURCE IS ON DISK. The file exists, so the module is not
 * missing: the model behind it did not load. Treating these as plan errors is what burned the seed
 * repair budget and then failed a run whose plan was correct.
 */
function phantomModuleErrors(errors) {
    return errors.flatMap(error => {
        const path = phantomModulePathOf(error);
        if (!path)
            return [];
        const parts = mlsImportPathParts(path);
        if (!parts)
            return [];
        const key = mls.stor.getKeyToFile({ ...parts, extension: '.ts' });
        return mls.stor.files[key] ? [{ error, path }] : [];
    });
}
// Materialize workers run in a POOL (parallel_dynamic, CB_MAX_PARALLEL slots), so two compiles can overlap. Worker B
// skips borrowing a model that worker A already loaded (the registry guard above), so releasing A's
// borrows while B is mid-compile could pull a model out from under B and produce a FALSE TS2792 that
// burns repair budget. Releases are therefore deferred until no compile is in flight — the registry
// still gets emptied at every quiescent point, which is what keeps the listener count bounded.
let activeCompiles = 0;
const pendingRelease = [];
/** Queue models WE loaded/created for release, and release everything queued once the last in-flight
 * compile finishes. Without any release the registry only grows (the guards never re-add one) and Monaco
 * hits its "potential listener LEAK detected, having 200 listeners already" threshold — observed on a
 * 62-file module.
 *
 * Two sources are queued: the imports borrowed for a compile, and the model of the generated file itself
 * (created by saveGeneratedTs). Releasing the latter is safe because NOTHING in this agent depends on a
 * model outliving its compile: `mls.editor.models` is read in exactly two places, both of them the
 * "load it if absent" guards below (`:166` for imports, `:210` for the file being compiled). The
 * materialization step is an independent process — it can run in a later session or from the CLI — so it
 * can never assume a preloaded registry, and every compile reloads what it needs on demand.
 *
 * Only models WE put there are ever released: each site checks the registry first, so a file the user has
 * open in a Studio tab is never ours and is never disposed. */
function releaseBorrowedModels(borrowed) {
    pendingRelease.push(...borrowed);
    if (activeCompiles > 0)
        return;
    const toRelease = pendingRelease.splice(0, pendingRelease.length);
    for (const model of toRelease) {
        // Signature is (project, shortName, folder, releaseMonacoModel, level) — the boolean comes BEFORE
        // the level. `true` disposes the underlying monaco model, which is what holds the listeners.
        try {
            mls.editor.deleteModels(model.project, model.shortName, model.folder, true, model.level);
        }
        catch { /* best effort */ }
    }
}
/**
 * Release everything the compiles queued, once no compile is in flight. `releaseBorrowedModels` only
 * drains at a quiescent point, and a long sweep (the whole-module compile borrows the imports of ~200
 * files) never reaches one on its own: the queue grows, the Monaco models pile up and the tab runs
 * out of memory. A caller that works in blocks calls this between them.
 */
export async function flushBorrowedModels() {
    const queued = pendingRelease.length;
    // Nothing forces a wait here: the queue drains as soon as the count of in-flight compiles is zero,
    // and this agent's compiles are awaited one at a time.
    releaseBorrowedModels([]);
    return { released: queued - pendingRelease.length, pending: pendingRelease.length };
}
/**
 * Release every model of the module this agent is responsible for.
 *
 * `addModels` loads ALL siblings of a shortName — the `.defs.ts` rides along with the `.ts` — and not
 * every path releases symmetrically, so after run 9 the tab held 464 Monaco models against 256 registry
 * entries (208 orphans) plus ~all the module's defs. The delete now reaches an orphan by URI (platform
 * F2), so a final sweep can actually clean up.
 *
 * A file whose model was ALREADY in the registry when the run started belongs to the Studio (an open
 * tab) and is never touched — the same ownership rule the per-compile borrow uses.
 */
export function sweepModuleModels(project, moduleName, keep) {
    let swept = 0;
    let kept = 0;
    for (const key of Object.keys(mls.editor.models || {})) {
        const entry = mls.editor.models[key];
        const storFile = entry?.ts?.storFile || entry?.defs?.storFile || entry?.test?.storFile;
        if (!storFile || storFile.project !== project || storFile.level !== 1)
            continue;
        if (moduleName && !String(storFile.folder || '').startsWith(`${moduleName}/`))
            continue;
        if (keep.has(key)) {
            kept++;
            continue;
        }
        try {
            mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true, storFile.level);
            swept++;
        }
        catch { /* best effort: a model that resists disposal is not worth failing a run over */ }
    }
    return { swept, kept };
}
/** The registry keys present right now — the caller snapshots them at the start of a run to know
 *  which models were NOT loaded by this agent (an open Studio tab). */
export function modelRegistryKeys() {
    try {
        return new Set(Object.keys(mls.editor.models || {}));
    }
    catch {
        return new Set();
    }
}
/**
 * How many models the registry holds and how many releases are still queued — the cheap way to see a
 * leak coming, and to prove it is gone. (Monaco's own store is not reachable from here; the registry
 * is the index this agent can account for, and since the platform fix a delete reaches the model even
 * when the two diverge.)
 */
let peakRegistry = 0;
export function modelCounts() {
    let registry = 0;
    try {
        registry = Object.keys(mls.editor.models || {}).length;
    }
    catch { /* registry unavailable */ }
    if (registry > peakRegistry)
        peakRegistry = registry;
    return { registry, pendingRelease: pendingRelease.length, peak: peakRegistry };
}
/**
 * ONE compile pass over a whole set of files.
 *
 * `compileSavedTsAndGetErrors` per file costs `N × the platform`: each call re-borrows the models of
 * its imports, re-typechecks everything the program reaches, and releases — ~6s per file, so the
 * validate gate of a 193-file module took ~20 minutes and the flagged ones paid it twice (the
 * anti-flaky double check). The TS worker, on the other hand, keeps an incremental program: load the
 * models ONCE and asking it for the diagnostics of each file is cheap from the second question on.
 *
 * The stable model set also removes the source of the flakiness the double compile existed for (a
 * model appearing halfway through the sweep), so callers ask once and re-ask only the flagged ones.
 *
 * Returns `{ errors, trace }`. `errors` is null when no compile capability exists — the caller then
 * keeps the per-file path, because a missing optimization must never cost the gate. `trace` always
 * names the path (`monaco` | `project-tsc` | `unavailable`), the raw diagnostic count, and how many
 * remained after the in-module filter. Monaco first (browser unchanged); project `tsc` only when the
 * worker is absent (`diskPath` + `node:child_process`).
 */
function monacoCompileAvailable() {
    const ts = mls.l2?.typescript;
    return typeof ts?.getTypeScriptWorker === 'function' && typeof mls.editor?.addModels === 'function';
}
function editorGetModel() {
    if (typeof mls.editor?.getModel !== 'function')
        return undefined;
    return mls.editor.getModel.bind(mls.editor);
}
// Call it as a METHOD, never detached. `diskPath` is host-only (it does not exist
// in mls.d.ts nor in the cfe) and on the CLI host it is a CLASS method that reads a
// private field. `const fn = mls.stor.diskPath; fn(info)` throws
// `Cannot read properties of undefined (reading '#mlsBase')`, the catch swallows it,
// and the project-tsc gate reports `no-diskPath` — i.e. the CB ran with NO compiler
// on the only host that could give it one. Measured on the lima host 02/09.
export function storDiskPath(info) {
    const stor = mls.stor;
    if (typeof stor.diskPath !== 'function')
        return null;
    try {
        return stor.diskPath(info);
    }
    catch {
        return null;
    }
}
async function runProjectBackendTsc(cwd) {
    try {
        const childProcessSpec = 'node:child_process';
        const loaded = await import(childProcessSpec);
        if (typeof loaded.spawn !== 'function')
            return null;
        const spawn = loaded.spawn;
        return await new Promise(resolve => {
            const child = spawn('npx', ['tsc', '-p', 'tsconfig.backend.json', '--noEmit', '--pretty', 'false'], { cwd });
            let out = '';
            child.stdout?.on('data', chunk => { out += String(chunk); });
            child.stderr?.on('data', chunk => { out += String(chunk); });
            child.on('error', () => resolve(null));
            child.on('close', () => resolve(out));
        });
    }
    catch {
        return null;
    }
}
async function compileModuleViaProjectTsc(project, files) {
    const sample = files[0];
    if (!sample) {
        return {
            grouped: new Map(),
            trace: { path: 'project-tsc', rawDiagnostics: 0, afterFilter: 0, files: 0 },
        };
    }
    const abs = storDiskPath({ project, level: 1, folder: sample.folder, shortName: sample.shortName, extension: '.ts' });
    if (!abs)
        return { grouped: null, trace: { path: 'unavailable', reason: 'no-diskPath', rawDiagnostics: 0, afterFilter: 0, files: files.length } };
    const cwd = mlsBaseFromDiskPath(abs);
    if (!cwd)
        return { grouped: null, trace: { path: 'unavailable', reason: 'no-mlsBase', rawDiagnostics: 0, afterFilter: 0, files: files.length } };
    const output = await runProjectBackendTsc(cwd);
    return traceProjectTscResult(output, files, project, 'spawn-null');
}
export async function compileModuleAndGetErrors(project, files) {
    if (!files.length) {
        const trace = {
            path: monacoCompileAvailable() ? 'monaco' : 'unavailable',
            reason: 'no-files',
            rawDiagnostics: 0,
            afterFilter: 0,
            files: 0,
        };
        return { errors: new Map(), trace };
    }
    if (monacoCompileAvailable()) {
        const monaco = await compileModuleViaMonaco(project, files);
        if (monaco) {
            const n = countGroupedDiagnostics(monaco);
            const trace = { path: 'monaco', rawDiagnostics: n, afterFilter: n, files: files.length };
            return { errors: monaco, trace };
        }
    }
    const tsc = await compileModuleViaProjectTsc(project, files);
    return { errors: tsc.grouped, trace: tsc.trace };
}
async function compileModuleViaMonaco(project, files) {
    const borrowed = [];
    activeCompiles++;
    try {
        // 1. Load the module's own .ts files and the closure of their l1 imports — one borrow set.
        // `.defs.ts` is not in the type closure (Wagner): we never ask the worker for its diagnostics.
        // `addModels` still loads siblings of a shortName; those ride along as platform behaviour.
        const models = [];
        for (const file of files) {
            const content = await readSavedTs(project, file.folder, file.shortName);
            if (content === null)
                continue;
            borrowed.push(...await ensureImportModels(content));
            const model = await loadTsModel(project, 1, file.folder, file.shortName, content);
            if (model) {
                models.push({ key: `${file.folder}::${file.shortName}`, model });
                const defsShort = `${file.shortName}.defs`;
                if (mls.editor.models[mls.editor.getKeyModel(project, defsShort, file.folder, 1)]) {
                    borrowed.push({ project, shortName: defsShort, folder: file.folder, level: 1 });
                }
            }
            modelCounts();
        }
        if (!models.length)
            return null;
        // 2. One worker for the whole set; it owns the incremental program.
        const worker = await mls.l2.typescript.getTypeScriptWorker(models[0].model.model);
        if (!worker)
            return null;
        const errors = new Map();
        for (const entry of models) {
            const diagnostics = await mls.l2.typescript.getDiagnostics(entry.model.model.uri.toString(), worker);
            const list = (diagnostics || [])
                .filter((d) => d?.category === undefined || d.category === 1)
                .map(flattenDiagnostic)
                .filter(Boolean)
                .slice(0, 12);
            errors.set(entry.key, list);
        }
        return errors;
    }
    catch (error) {
        console.warn('[cbMaterializeIo] compileModuleAndGetErrors unavailable; falling back to per-file compile', error);
        return null;
    }
    finally {
        activeCompiles--;
        releaseBorrowedModels(borrowed);
    }
}
/** The saved content of a generated .ts, or null when the file is not in this session. */
async function readSavedTs(project, folder, shortName) {
    try {
        const key = mls.stor.getKeyToFile({ project, level: 1, folder, shortName, extension: '.ts' });
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return null;
        return String(await file.getContent() ?? '');
    }
    catch {
        return null;
    }
}
/** The loaded TS model of a file, creating it when this session does not have it yet. */
async function loadTsModel(project, level, folder, shortName, content) {
    try {
        const editorKey = mls.editor.getKeyModel(project, shortName, folder, level);
        let base = mls.editor.models[editorKey];
        if (!base)
            base = await mls.editor.addModels(project, shortName, folder, level);
        const model = base?.ts;
        if (!model)
            return null;
        // The saved content is the truth for the gate: a model left over from an earlier phase of the run
        // may still hold the pre-repair text.
        if (model.model.getValue() !== content)
            model.model.setValue(content);
        return model;
    }
    catch {
        return null;
    }
}
/** Compile the saved .ts and distinguish a clean compile from unavailable Monaco infrastructure. */
async function compileGeneratedTs(project, level, folder, shortName, content) {
    if (!monacoCompileAvailable())
        return { errors: [], infraErrors: [], available: false };
    // Borrowed OUTSIDE the try so the finally can always release them, even on a compile exception.
    let borrowed = [];
    activeCompiles++;
    try {
        borrowed = await ensureImportModels(content);
        const editorKey = mls.editor.getKeyModel(project, shortName, folder, level);
        let modelBase = mls.editor.models[editorKey];
        if (!modelBase)
            modelBase = await mls.editor.addModels(project, shortName, folder, level);
        const modelTs = modelBase?.ts;
        if (!modelTs)
            return { errors: [], infraErrors: [], available: false };
        // Resident model (open tab / leftover): Monaco compiles against MEMORY. Hooks write stor only,
        // so sync from the saved content here — same idea as addModels for imports.
        if (modelTs.model && modelTs.model.getValue() !== content)
            modelTs.model.setValue(content);
        if (modelTs.compilerResults)
            modelTs.compilerResults.modelNeedCompile = true;
        await mls.l2.typescript.compileAndPostProcess(modelTs, true, true);
        mls.editor.forceModelUpdate(modelTs.model);
        // category 1 = Error in monaco/ts DiagnosticCategory; keep only real errors, capped.
        const readErrors = () => (modelTs.compilerResults?.errors ?? [])
            .filter(d => d?.category === undefined || d.category === 1)
            .map(flattenDiagnostic)
            .filter(Boolean)
            .slice(0, 12);
        let errors = readErrors();
        // An import that exists on disk cannot be "not found": the model behind it failed to load. Force
        // it back and compile once more before believing the diagnostic.
        let phantom = phantomModuleErrors(errors);
        if (phantom.length) {
            for (const item of phantom) {
                const parts = mlsImportPathParts(item.path);
                if (parts)
                    await loadImportModel(parts.project, parts.folder, parts.shortName, true);
            }
            if (modelTs.compilerResults)
                modelTs.compilerResults.modelNeedCompile = true;
            await mls.l2.typescript.compileAndPostProcess(modelTs, true, true);
            mls.editor.forceModelUpdate(modelTs.model);
            errors = readErrors();
            phantom = phantomModuleErrors(errors);
        }
        return { errors, infraErrors: phantom.map(item => item.error), available: true };
    }
    catch (err) {
        console.warn('[cbMaterializeIo] compileGeneratedTs failed', err);
        return { errors: [], infraErrors: [], available: false };
    }
    finally {
        // NB: the model of the file BEING compiled (added above) is deliberately kept — it is a real project
        // artifact the editor/publish path and the repair loop reuse. Only the borrowed imports are released.
        activeCompiles--;
        releaseBorrowedModels(borrowed);
    }
}
/**
 * Keep an ALREADY EXISTING Monaco model in sync with the content just persisted. Not cosmetic: the
 * Studio<->disk sync reads a file from its model first and only falls back to the stor content when
 * there is no model, and libModel.createModel hands back an existing model untouched (no setValue).
 * So without this, the SECOND write onwards updates the stor while the model stays frozen at the
 * first one, and the next export writes that first snapshot over the good content — the petShop lost
 * update of 2026-08-21 (65 todoBackend writes, disk got the state after write #1).
 *
 * Never CREATES a model: an unowned model is a leak (see releaseBorrowedModels/sweepModuleModels), and
 * with no model the export already reads the stor, which is correct. Hook writers call this; they must
 * not mention `mls.editor` themselves.
 */
export function refreshExistingModel(file, src) {
    const getModel = editorGetModel();
    if (!getModel)
        return;
    try {
        const model = getModel(file);
        if (model?.model && model.model.getValue() !== src)
            model.model.setValue(src);
    }
    catch (error) {
        console.warn('[cbMaterializeIo] model refresh failed', error);
    }
}
/** Read an already-existing Monaco model. Never creates one. `failed` is a throw from getModel/getValue. */
export function readExistingModelValue(file) {
    const getModel = editorGetModel();
    if (!getModel)
        return { present: false, value: null, failed: false };
    let present = false;
    try {
        const model = getModel(file);
        if (!model?.model)
            return { present: false, value: null, failed: false };
        present = true;
        return { present: true, value: model.model.getValue(), failed: false };
    }
    catch (error) {
        console.warn('[cbMaterializeIo] model read failed', error);
        return { present, value: null, failed: true };
    }
}
/** Save (create or overwrite) a generated file with an ARBITRARY extension, WITHOUT compiling. Used for
 * byte-mirror artifacts (l1 contract copies `.ts`/`.d.ts` — B5) where the whole-project compile in
 * validate-all owns correctness; a per-file compile of a `.d.ts` twin would be meaningless. Later
 * compile loads the model on demand via addModels; an open tab is synced, never created. */
export async function saveGeneratedFile(project, level, folder, shortName, extension, content) {
    try {
        const fileInfo = { project, level, folder, shortName, extension };
        const key = mls.stor.getKeyToFile(fileInfo);
        let file = mls.stor.files[key];
        if (!file) {
            file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
        }
        file.updatedAt = new Date().toISOString();
        await mls.stor.localStor.setContent(file, { contentType: 'string', content });
        refreshExistingModel(file, content);
        return true;
    }
    catch (err) {
        console.warn('[cbMaterializeIo] saveGeneratedFile failed', err);
        return false;
    }
}
/** Save (create or overwrite) a generated .ts file, force a recompile and report its errors. */
export async function saveGeneratedTs(project, level, folder, shortName, content) {
    try {
        const fileInfo = { project, level, folder, shortName, extension: '.ts' };
        const key = mls.stor.getKeyToFile(fileInfo);
        // OWNERSHIP, decided BEFORE compile can create a model: if the registry has no model for this
        // file yet, the model compileGeneratedTs addModels creates is OURS and is released after the
        // compile. If a model already exists the file is open in the Studio — not ours, never disposed.
        const ownsModel = !mls.editor.models[mls.editor.getKeyModel(project, shortName, folder, level)];
        let file = mls.stor.files[key];
        if (!file) {
            // needCreateModel=false: compileGeneratedTs loads this file (and its imports) on demand via
            // addModels from stor. Creating a model here was redundant; later importers already reload
            // from stor (ensureImportModels), which is what makes releasing the working copy safe.
            file = await createStorFile({ ...fileInfo, source: content }, false, false, false);
        }
        // Bump updatedAt for the [cb-stale] diagnostic log; libStor.createStorFile / setContent do not
        // set it. Generation is decided by existence of this file, not by comparing stamps.
        file.updatedAt = new Date().toISOString();
        await mls.stor.localStor.setContent(file, { contentType: 'string', content });
        refreshExistingModel(file, content);
        const compiled = shortName.endsWith('.defs') ? { errors: [], infraErrors: [], available: true } : await compileGeneratedTs(project, level, folder, shortName, content);
        // The content is already durable in stor; the monaco model was a working copy for the compile. Queue
        // it (released at the next quiescent point, so a peer compile in the pool can still import it).
        if (ownsModel) {
            const borrowed = [{ project, shortName, folder, level }];
            const defsShort = `${shortName}.defs`;
            if (mls.editor.models[mls.editor.getKeyModel(project, defsShort, folder, level)]) {
                borrowed.push({ project, shortName: defsShort, folder, level });
            }
            releaseBorrowedModels(borrowed);
        }
        modelCounts(); // record peak after each save/compile
        const syntaxErrors = syntaxDiagnostics(content).slice(0, 12);
        const compileErrors = [...syntaxErrors, ...compiled.errors].slice(0, 12);
        return { ok: true, compileErrors, syntaxErrors, infraErrors: compiled.infraErrors, compilerAvailable: compiled.available };
    }
    catch (err) {
        console.warn('[cbMaterializeIo] saveGeneratedTs failed', err);
        return { ok: false, compileErrors: [], syntaxErrors: [], infraErrors: [], compilerAvailable: false };
    }
}
/** Whole-project compile check (used by cb-validate-all): compile an already-saved generated .ts and
 * return its errors. At that point every generated file exists, so findings are REAL — unlike the
 * per-file compile during the layer sweep, which is deferred (see agentCbMaterialize). Returns []
 * when Monaco is unavailable — the deterministic checks remain the floor. */
export async function compileSavedTsAndGetErrors(project, folder, shortName) {
    try {
        const key = mls.stor.getKeyToFile({ project, level: 1, folder, shortName, extension: '.ts' });
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted')
            return [];
        const content = String(await file.getContent() ?? '');
        const compiled = await compileGeneratedTs(project, 1, folder, shortName, content);
        return compiled.available ? compiled.errors : [];
    }
    catch {
        return [];
    }
}
function parseMaybeJson(raw) {
    if (typeof raw !== 'string')
        return raw;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
function isRecord(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
}
/** Pull the arguments of a named tool call out of the model payload (several shapes supported). */
export function extractToolCallArgs(raw, toolName) {
    const v = parseMaybeJson(raw);
    if (!isRecord(v))
        return null;
    if (v.toolName === toolName) {
        const args = parseMaybeJson(v.arguments);
        return isRecord(args) ? args : null;
    }
    if (v.type === 'flexible' && v.result !== undefined) {
        const result = parseMaybeJson(v.result);
        if (isRecord(result) && result.toolName === toolName) {
            const args = parseMaybeJson(result.arguments);
            return isRecord(args) ? args : null;
        }
    }
    if (Array.isArray(v.tool_calls)) {
        const call = v.tool_calls.find((item) => isRecord(item) && isRecord(item.function) && item.function.name === toolName);
        if (isRecord(call)) {
            const args = parseMaybeJson(call.function.arguments);
            return isRecord(args) ? args : null;
        }
    }
    return null;
}
