/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig.ts" enhancement="_blank"/>
export function formatDiscardedOrphans(discarded) {
    return discarded.length === 0 ? '' : `; discarded orphan module(s): ${discarded.join(', ')}`;
}
export function liveBackendModulesFromL5(l5Modules) {
    const live = [];
    if (!Array.isArray(l5Modules))
        return live;
    for (const l5mod of l5Modules) {
        if (!isRecord(l5mod))
            continue;
        const moduleId = readString(l5mod.moduleName);
        const backend = isRecord(l5mod.backend) ? l5mod.backend : null;
        if (!moduleId || !backend)
            continue;
        const persistence = isRecord(backend.persistence) ? backend.persistence : {};
        const backendControllers = readString(backend.backendControllers);
        const tableDefsDir = readString(persistence.tableDefsDir);
        if (!backendControllers || !tableDefsDir)
            continue;
        live.push({ moduleId, backendControllers, tableDefsDir });
    }
    return live;
}
/** Drop l5/project.json backend blocks whose persistence dir is gone, except the module this run owns. */
export function pruneOrphanL5BackendModules(modules, currentModuleName, tableDefsExists) {
    const discarded = [];
    const kept = [];
    for (const mod of Array.isArray(modules) ? modules : []) {
        if (!isRecord(mod))
            continue;
        const name = readString(mod.moduleName);
        const backend = isRecord(mod.backend) ? mod.backend : null;
        if (!name || !backend || name === currentModuleName || tableDefsExists(name)) {
            kept.push({ ...mod });
            continue;
        }
        discarded.push(name);
        const rest = { ...mod };
        delete rest.backend;
        const extraKeys = Object.keys(rest).filter(key => key !== 'moduleName');
        if (extraKeys.length > 0)
            kept.push(rest);
    }
    discarded.sort();
    return { modules: kept, discarded };
}
export function reconcileClientBackendRegistration(existingModules, existingPersistence, live) {
    const liveIds = new Set(live.map(item => item.moduleId));
    const modules = (existingModules ?? []).filter(isRecord).map(mod => ({ ...mod }));
    const persistenceById = new Map();
    for (const pm of existingPersistence ?? []) {
        if (!isRecord(pm))
            continue;
        const id = readString(pm.moduleId);
        if (id)
            persistenceById.set(id, { ...pm });
    }
    const discarded = new Set();
    for (const id of persistenceById.keys()) {
        if (!liveIds.has(id))
            discarded.add(id);
    }
    for (const mod of modules) {
        const id = readString(mod.moduleId);
        if (id && !liveIds.has(id) && (mod.backendControllers || mod.backendRouter))
            discarded.add(id);
    }
    for (const item of live) {
        let mod = modules.find(candidate => readString(candidate.moduleId) === item.moduleId);
        if (!mod) {
            mod = { moduleId: item.moduleId, basePath: `/${item.moduleId}`, shellMode: 'spa' };
            modules.push(mod);
        }
        const rec = mod;
        rec.basePath = readString(rec.basePath) || `/${item.moduleId}`;
        rec.shellMode = readString(rec.shellMode) || 'spa';
        rec.backendControllers = item.backendControllers;
        delete rec.backendRouter;
        const pm = { ...(persistenceById.get(item.moduleId) || { moduleId: item.moduleId }) };
        const pmRec = pm;
        pmRec.moduleId = item.moduleId;
        pmRec.tableDefsDir = item.tableDefsDir;
        delete pmRec.persistenceEntrypoint;
        persistenceById.set(item.moduleId, pm);
    }
    for (const mod of modules) {
        const id = readString(mod.moduleId);
        if (!id || liveIds.has(id))
            continue;
        delete mod.backendControllers;
        delete mod.backendRouter;
    }
    const persistenceModules = live.map(item => persistenceById.get(item.moduleId));
    const keptModules = modules.filter(mod => {
        const id = readString(mod.moduleId);
        if (liveIds.has(id))
            return true;
        const frontend = isRecord(mod.frontend) ? mod.frontend : null;
        const pages = frontend && Array.isArray(frontend.pages) ? frontend.pages : [];
        if (pages.length > 0)
            return true;
        if (id)
            discarded.add(id);
        return false;
    });
    return {
        modules: keptModules,
        persistenceModules,
        discarded: [...discarded].sort(),
    };
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
