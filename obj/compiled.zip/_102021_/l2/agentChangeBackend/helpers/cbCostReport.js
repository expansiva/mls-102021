/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbCostReport.ts" enhancement="_102027_/l2/enhancementAgent"/>
/** Parse the charged cost + token counts from an LLM step's interaction trace. The provider lines carry
 *  `... cost:$0.0199 ...` and `... inputTokens:7954 outputTokens:85 ...`; a step may have several provider
 *  attempts (primary + fallback) — SUM them, since the run is charged for each attempt. */
export function parseStepCost(traceLines) {
    let cost = 0, inputTokens = 0, outputTokens = 0;
    for (const line of traceLines) {
        for (const m of String(line).matchAll(/cost:\$(\d+(?:\.\d+)?)/gu))
            cost += Number(m[1]);
        for (const m of String(line).matchAll(/inputTokens:(\d+)/gu))
            inputTokens += Number(m[1]);
        for (const m of String(line).matchAll(/outputTokens:(\d+)/gu))
            outputTokens += Number(m[1]);
    }
    return { cost, inputTokens, outputTokens };
}
/** Add one LLM call's cost to a phase bucket (returns a NEW report; pure). */
export function accumulatePhaseCost(report, phase, delta) {
    const prev = report[phase] ?? { cost: 0, calls: 0, inputTokens: 0, outputTokens: 0 };
    return {
        ...report,
        [phase]: {
            cost: prev.cost + (delta.cost || 0),
            calls: prev.calls + 1,
            inputTokens: prev.inputTokens + (delta.inputTokens || 0),
            outputTokens: prev.outputTokens + (delta.outputTokens || 0),
        },
    };
}
/** Roll up the report: total cost/calls and the single most expensive phase. */
export function summarizeCost(report) {
    let totalCost = 0, totalCalls = 0, topPhase = null, topPhaseCost = 0;
    for (const [phase, c] of Object.entries(report)) {
        totalCost += c.cost;
        totalCalls += c.calls;
        if (c.cost > topPhaseCost) {
            topPhaseCost = c.cost;
            topPhase = phase;
        }
    }
    return { totalCost, totalCalls, topPhase, topPhaseCost };
}
/** One-line human summary for the final task trace (T7 visibility). */
export function formatCostSummary(report) {
    const { totalCost, totalCalls, topPhase, topPhaseCost } = summarizeCost(report);
    if (!totalCalls)
        return '';
    const per = Object.entries(report)
        .sort(([, a], [, b]) => b.cost - a.cost)
        .map(([phase, c]) => `${phase} $${c.cost.toFixed(2)}/${c.calls}`)
        .join(', ');
    return ` cost $${totalCost.toFixed(2)} in ${totalCalls} call(s) [${per}]${topPhase ? `; priciest: ${topPhase} $${topPhaseCost.toFixed(2)}` : ''}`;
}
