/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbLocalStepTitle.ts" enhancement="_blank"/>
import { changeLocalStepTitle, startLocalStepTitleTick } from '/_102025_/l2/collabMessagesEvents.js';
export function localStepTitle(context, step, title) {
    const taskPK = context.task?.PK;
    if (!taskPK)
        return;
    changeLocalStepTitle(taskPK, step.stepId, title);
}
export function startLocalStepTick(context, step, makeTitle) {
    const taskPK = context.task?.PK;
    if (!taskPK)
        return () => { };
    return startLocalStepTitleTick(taskPK, step.stepId, makeTitle);
}
