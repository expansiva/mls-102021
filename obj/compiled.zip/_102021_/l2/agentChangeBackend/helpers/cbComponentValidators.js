/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { isClientBoundarySource } from '/_102029_/l2/clientBoundarySources.js';
// Shared component-inspection helpers for the generated l1 .ts / .defs.ts artifacts. These pure
// functions were duplicated (near-identically) in agentCbMaterialize.ts and agentCbValidateAll.ts;
// a fix on one side kept drifting from the other. Extracted here on 2026-07-11 as the SINGLE source
// (todo/modernizeChangeBackend.md step 3). Behavior is preserved exactly — they parse generated code
// and defs to check BFF boundary/route coherence and rule coverage. No step-specific knowledge.
// Self-contained (like cbMdmGuards/cbSeedsCore): inlines the three trivial primitives instead of
// importing cbShared, so this module + its unit test stay free of the heavy runtime graph. The
// implementations mirror cbShared.isRecord/readString/readStringArray exactly.
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function readString(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function readStringArray(value) {
    return Array.isArray(value) ? value.map(readString).filter(Boolean) : [];
}
/** Module-local l1 imports of a generated .ts: `from '/_<project>_/l1/<folder>/<name>.js'`. Returns
 * the tsSet key (`${folder}::${shortName}`) so the caller can check the target was actually generated.
 * Cross-project imports (e.g. /_102034_/ platform) and non-l1 imports are ignored on purpose. */
export function collectL1Imports(content, project) {
    const out = [];
    const re = /from\s+['"]\/_(\d+)_\/l1\/([^'"]+)['"]/g;
    let match;
    while ((match = re.exec(content)) !== null) {
        if (Number(match[1]) !== project)
            continue;
        const path = match[2].replace(/\.(?:d\.ts|ts|js)$/u, '');
        const lastSlash = path.lastIndexOf('/');
        const folder = lastSlash >= 0 ? path.slice(0, lastSlash) : '';
        const shortName = lastSlash >= 0 ? path.slice(lastSlash + 1) : path;
        out.push({ key: `${folder}::${shortName.toLowerCase()}`, target: `_${project}_/l1/${path}` });
    }
    return out;
}
/** Generated l1 code must import ONLY via the '/_<project>_/...' alias. A relative import sometimes
 * even resolves under tsc, but it breaks the studio path convention — and it is the typical way the
 * model tries to silence a not-yet-materialized alias import (TS2792 hint, run task2/102049: six
 * controllers rewritten to '../../../../...' during repair). Rejected deterministically here. */
export function collectRelativeImportIssues(code) {
    const issues = [];
    const re = /\b(?:from|import)\s*\(?\s*['"](\.{1,2}\/[^'"]*)['"]/g;
    let match;
    while ((match = re.exec(code)) !== null) {
        issues.push(`relative import forbidden -> '${match[1]}'; import via the '/_<project>_/l1/...' alias exactly as in the context files (keep the alias even if the target module is not materialized yet)`);
    }
    return issues;
}
export function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
export function fieldNameFromRef(value) {
    const raw = String(value ?? '').trim();
    if (!raw)
        return '';
    const parts = raw.split('.');
    return parts[parts.length - 1] || raw;
}
export function requiredBoundaryFields(inputContract) {
    const fields = new Set();
    if (!Array.isArray(inputContract))
        return fields;
    for (const input of inputContract) {
        if (!isRecord(input) || input.required !== true)
            continue;
        const source = String(input.source ?? '');
        if (!isClientBoundarySource(source))
            continue;
        const inputId = fieldNameFromRef(input.inputId);
        const fieldRef = fieldNameFromRef(input.fieldRef);
        if (inputId)
            fields.add(inputId);
        if (fieldRef)
            fields.add(fieldRef);
    }
    return fields;
}
export function collectRequiredChecksByHandler(content) {
    const checks = new Map();
    const handlerRe = /export\s+const\s+([A-Za-z0-9_$]+)\s*:\s*BffHandler\s*=\s*async[\s\S]*?=>\s*\{([\s\S]*?)\n\};/g;
    let handlerMatch;
    while ((handlerMatch = handlerRe.exec(content)) !== null) {
        const fields = new Set();
        const body = handlerMatch[2];
        const errorRe = /new\s+AppError\(([\s\S]*?)\);/g;
        let errorMatch;
        while ((errorMatch = errorRe.exec(body)) !== null) {
            const call = errorMatch[1];
            if (!/\b(required|obrigat[oó]ri[oa]|required field|campo obrigat[oó]ri[oa])\b/i.test(call))
                continue;
            // Accept dotted paths ('movement.movementType') and compare by the LAST segment — a dotted
            // field must not evade the boundary check (lesson task2/102049: adjustStockLevel).
            const fieldMatch = call.match(/field\s*:\s*['"]([A-Za-z0-9_$.]+)['"]/);
            if (fieldMatch)
                fields.add(fieldMatch[1].split('.').pop());
        }
        checks.set(handlerMatch[1], fields);
    }
    return checks;
}
export function collectExportedHandlers(content) {
    const handlers = new Set();
    const re = /export\s+const\s+([A-Za-z0-9_$]+)\s*:\s*BffHandler\b/g;
    let match;
    while ((match = re.exec(content)) !== null)
        handlers.add(match[1]);
    return handlers;
}
export function collectRouteHandlers(content) {
    const routes = new Map();
    const re = /\{\s*key\s*:\s*['"]([^'"]+)['"]\s*,\s*handler\s*:\s*([A-Za-z0-9_$]+)/g;
    let match;
    while ((match = re.exec(content)) !== null)
        routes.set(match[1], match[2]);
    return routes;
}
export function normalizeRuleId(rule) {
    return rule.split(':')[0].trim();
}
export function collectUsecaseRules(data) {
    if (!isRecord(data))
        return [];
    const rules = new Set(readStringArray(data.rulesApplied).map(normalizeRuleId).filter(Boolean));
    const functions = Array.isArray(data.functions) ? data.functions : [];
    for (const fn of functions) {
        if (!isRecord(fn))
            continue;
        for (const rule of readStringArray(fn.rulesApplied).map(normalizeRuleId).filter(Boolean))
            rules.add(rule);
    }
    return [...rules].filter(Boolean);
}
// ── l4 v2: workspace-controller coherence (B7) ──────────────────────────────────
// The v2 controller is emitted DETERMINISTICALLY (no .defs.ts). "Rotas esperadas = bffCalls do
// workspace": every bffCall must have an exported handler `<ws><Bff>Handler`, registered in `routes`
// by its `<bffId>Route` const. Pure so validate-all's check is unit-tested (bffCall sem handler / rota
// órfã fixtures) without importing the heavy runtime graph.
function capitalizeFirst(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}
export function collectV2ControllerCoherenceIssues(workspaces, controllerSources) {
    const issues = [];
    for (const ws of workspaces) {
        if (!ws.bffCalls.length)
            continue;
        const src = controllerSources.get(ws.workspaceId.toLowerCase());
        if (!src) {
            issues.push(`v2 controller ${ws.workspaceId} -> .ts not generated for the workspace`);
            continue;
        }
        const exported = collectExportedHandlers(src);
        for (const bff of ws.bffCalls) {
            const handlerName = `${ws.workspaceId}${capitalizeFirst(bff.bffId)}Handler`;
            if (!exported.has(handlerName))
                issues.push(`v2 controller ${ws.workspaceId} -> bffCall ${bff.bffId} has no handler ${handlerName}`);
            else if (!new RegExp(`handler:\\s*${escapeRegExp(handlerName)}\\b`).test(src))
                issues.push(`v2 controller ${ws.workspaceId} -> bffCall ${bff.bffId} handler not registered in routes`);
            if (!new RegExp(`\\b${escapeRegExp(bff.bffId)}Route\\b`).test(src))
                issues.push(`v2 controller ${ws.workspaceId} -> bffCall ${bff.bffId} route const ${bff.bffId}Route missing (rota órfã)`);
        }
    }
    return issues;
}
