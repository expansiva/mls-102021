/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbPipelineRun.ts" enhancement="_blank"/>
import { cbCurrentTraceModule, cbTraceFolder } from '/_102021_/l2/agentChangeBackend/helpers/cbTraceScope.js';
import { CB_FAST_HANDOFF_MARK_SHORT } from '/_102021_/l2/agentChangeBackend/helpers/cbFastHandoff.js';
export const CB_PIPELINE_AGENT_SLUG = 'changebackend';
export function nextPipelineRunNn(existingShortNames, agentSlug) {
    const re = new RegExp(`^run(\\d+)_${agentSlug}$`);
    let max = 0;
    for (const name of existingShortNames) {
        const match = re.exec(name);
        if (match)
            max = Math.max(max, Number(match[1]));
    }
    return String(max + 1).padStart(2, '0');
}
function asLongMemory(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}
export function resolveCbPipelineModule(explicit, longMemory) {
    const memory = asLongMemory(longMemory);
    for (const raw of [explicit, cbCurrentTraceModule(), typeof memory?.targetModule === 'string' ? memory.targetModule : '']) {
        const name = String(raw || '').trim();
        if (name && name !== 'unknown')
            return name;
    }
    return '';
}
export function describeCbCommand(longMemory) {
    if (!longMemory)
        return '';
    const parts = [];
    if (longMemory.fastMode === 'true')
        parts.push('/fast');
    const cli = typeof longMemory.cliCommand === 'string' ? longMemory.cliCommand : '';
    if (cli === 'rebuild-all' || cli === 'rebuild')
        parts.push('/rebuild all');
    else if (cli)
        parts.push(cli);
    return parts.join(' ');
}
export function listCbPipelineShortNames(moduleName) {
    const project = mls.actualProject || 0;
    const folder = `${moduleName}/pipeline`;
    const names = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        if (file.extension !== '.json' || String(file.folder || '') !== folder)
            continue;
        if (file.shortName)
            names.push(String(file.shortName));
    }
    return names;
}
export function buildCbRunSummary(input) {
    const health = input.health;
    const degraded = Array.isArray(health?.degraded) ? health.degraded.map(String) : [];
    const findingList = Array.isArray(health?.findings) ? health.findings.map(String) : [];
    const findings = findingList.length;
    const degradations = degraded.map(reason => ({
        at: new Date().toISOString(),
        kind: 'health-degraded',
        reason,
    }));
    if (health?.seeds === 'degraded') {
        degradations.push({ at: new Date().toISOString(), kind: 'seeds-degraded', reason: String(health.seedSkipped ?? 'seeds degraded') });
    }
    if (input.extraDegradations?.length)
        degradations.push(...input.extraDegradations);
    const healthFailed = health?.outcome === 'failed';
    const verdict = (input.compilerLeft || healthFailed)
        ? 'failed'
        : input.noWork
            ? 'completed'
            : (degradations.length ? 'degraded' : 'completed');
    return {
        moduleName: input.moduleName,
        agent: 'agentChangeBackend',
        command: input.command,
        startedAt: null,
        finishedAt: new Date().toISOString(),
        verdict,
        reason: input.summary,
        counts: {
            ownersDone: input.ownersDone,
            ownersFlipped: input.ownersFlipped,
            findings,
            findingList,
            degraded: degraded.length,
            repairs: Array.isArray(health?.repairHistory) ? health.repairHistory.length : 0,
            globalAttempts: typeof health?.globalAttempts === 'number' ? health.globalAttempts : 0,
            noWork: input.noWork,
        },
        degradations,
        scanWarnings: Array.isArray(health?.scanWarnings) ? health.scanWarnings.map(String) : [],
        todoReadBack: health?.todoReadBack && typeof health.todoReadBack === 'object' ? health.todoReadBack : null,
    };
}
/** Recording must never change the run outcome. A throw from the writer is swallowed. */
export async function bestEffortRecord(write) {
    try {
        await write();
    }
    catch {
        /* recording is never on the critical path */
    }
}
/** Index the run on a terminal failure so `l4/<module>/pipeline/` is not missing `runNN_changebackend.json`. */
export async function recordFailedCbRun(input) {
    await bestEffortRecord(async () => {
        const moduleName = resolveCbPipelineModule(input.moduleName, input.longMemory);
        if (!moduleName)
            return;
        const health = input.health && typeof input.health === 'object' && !Array.isArray(input.health)
            ? { ...input.health, outcome: 'failed' }
            : { outcome: 'failed', findings: [], degraded: [], repairHistory: [] };
        await saveCbRunSummary(buildCbRunSummary({
            moduleName,
            command: describeCbCommand(asLongMemory(input.longMemory)),
            noWork: false,
            ownersDone: 0,
            ownersFlipped: 0,
            compilerLeft: false,
            health,
            summary: input.reason,
        }));
    });
}
export async function saveCbRunSummary(summary) {
    try {
        const project = mls.actualProject || 0;
        if (!project || !summary.moduleName)
            return null;
        const nn = nextPipelineRunNn(listCbPipelineShortNames(summary.moduleName), CB_PIPELINE_AGENT_SLUG);
        const info = {
            project,
            level: 4,
            folder: `${summary.moduleName}/pipeline`,
            shortName: `run${nn}_${CB_PIPELINE_AGENT_SLUG}`,
            extension: '.json',
        };
        const source = `${JSON.stringify({ savedAt: new Date().toISOString(), ...summary }, null, 2)}\n`;
        const { createStorFile } = await import('/_102027_/l2/libStor.js');
        const key = mls.stor.getKeyToFile(info);
        let file = mls.stor.files[key];
        if (!file)
            file = await createStorFile({ ...info, source }, false, false, false);
        await mls.stor.localStor.setContent(file, { contentType: 'string', content: source });
        return `l4/${info.folder}/${info.shortName}.json`;
    }
    catch {
        return null;
    }
}
export function cbFastHandoffMarkInfo(moduleName, project = mls.actualProject || 0) {
    return { project, level: 4, folder: `${moduleName}/pipeline`, shortName: CB_FAST_HANDOFF_MARK_SHORT, extension: '.json' };
}
export async function readCbFastHandoffMark(moduleName) {
    try {
        const project = mls.actualProject || 0;
        if (!project || !moduleName)
            return null;
        const key = mls.stor.getKeyToFile(cbFastHandoffMarkInfo(moduleName, project));
        const file = mls.stor.files[key];
        if (!file || file.status === 'deleted' || !file.getContent)
            return null;
        const parsed = JSON.parse(String(await file.getContent() ?? ''));
        if (!parsed || typeof parsed !== 'object' || typeof parsed.message !== 'string')
            return null;
        return { to: String(parsed.to || 'agentChangeFrontend'), message: parsed.message, at: String(parsed.at || '') };
    }
    catch {
        return null;
    }
}
export async function writeCbFastHandoffMark(moduleName, message) {
    const project = mls.actualProject || 0;
    if (!project || !moduleName)
        return;
    const info = cbFastHandoffMarkInfo(moduleName, project);
    const source = `${JSON.stringify({ to: 'agentChangeFrontend', message, at: new Date().toISOString() }, null, 2)}\n`;
    const { createStorFile } = await import('/_102027_/l2/libStor.js');
    const key = mls.stor.getKeyToFile(info);
    let file = mls.stor.files[key];
    if (!file)
        file = await createStorFile({ ...info, source }, false, false, false);
    await mls.stor.localStor.setContent(file, { contentType: 'string', content: source });
}
/** Keep a reference so the write-folder chokepoint stays in this module's tests. */
export function cbRunTraceFolder() {
    return cbTraceFolder();
}
