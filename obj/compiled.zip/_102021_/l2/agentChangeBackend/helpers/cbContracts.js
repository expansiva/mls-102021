/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
// PURE l4-v2 projection helpers (no file I/O, no side-effecting imports — stays unit-testable; cbShared's
// libStor->libModel import crashes the l2 test stub). Resolves a bffCall projection deterministically so
// the controller-def builder (gen-http) can carry the pick/rename/$items spec into the .defs.ts, which
// cb-materialize (LLM + httpController.md) then turns into the controller .ts.
import { isRecord } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
/** The array-carrying field of a paginated operation outputShape (the `$items` target). The first field
 * of type 'array' (or one with a nested `item`) — real outputShapes have exactly one. `list` shapes are
 * flat (no array field) and return null. */
export function resolveItemsArrayField(shape) {
    if (!shape || !Array.isArray(shape.fields))
        return null;
    const arr = shape.fields.find(f => f && (f.type === 'array' || isRecord(f.item)));
    return arr ? arr.name : null;
}
/** Parse a bffCall `from` path (`<op>.<field>` | `<op>.$items.<col>`) into its parts. Returns null for a
 * malformed/empty `from`, or for a bare `<op>.$items` (the whole array — handled by the array field). */
export function parseFromPath(from) {
    const raw = String(from || '').trim();
    if (!raw)
        return null;
    const segs = raw.split('.');
    if (segs.length < 2)
        return null;
    const operationId = segs[0];
    if (segs[1] === '$items') {
        const path = segs.slice(2);
        return path.length ? { operationId, fromItems: true, path } : null;
    }
    return { operationId, fromItems: false, path: segs.slice(1) };
}
export function resolveBffProjection(bff) {
    const kind = envelopeKindOf(bff);
    const fields = bff.output?.fields ?? [];
    if (kind === 'paginated') {
        const arrayField = fields.find(f => (f.item?.fields?.length) || isBareItems(f.from));
        const itemFields = (arrayField?.item?.fields ?? []).map(resolveField).filter((f) => f !== null);
        const arrOp = arrayField ? (parseFromPath(arrayField.from)?.operationId ?? itemFields[0]?.operationId ?? null) : null;
        const topFields = fields.filter(f => f !== arrayField).map(resolveField).filter((f) => f !== null);
        return { kind, itemFields, topFields, arrayFieldName: arrayField?.name ?? null, arrayOperationId: arrOp };
    }
    if (kind === 'list') {
        const itemFields = fields.map(resolveField).filter((f) => f !== null);
        return { kind, itemFields, topFields: [], arrayFieldName: null, arrayOperationId: itemFields[0]?.operationId ?? null };
    }
    const topFields = fields.map(resolveField).filter((f) => f !== null);
    return { kind, itemFields: [], topFields, arrayFieldName: null, arrayOperationId: null };
}
function isBareItems(from) {
    return /\.\$items$/.test(String(from || '').trim()); // `<op>.$items` with no column
}
function resolveField(field) {
    const parsed = parseFromPath(field.from);
    if (!parsed)
        return null;
    return { name: field.name, operationId: parsed.operationId, path: parsed.path, fromItems: parsed.fromItems };
}
export function envelopeKindOf(bff) {
    const kind = bff.output?.kind;
    return kind === 'paginated' || kind === 'list' ? kind : 'object';
}
