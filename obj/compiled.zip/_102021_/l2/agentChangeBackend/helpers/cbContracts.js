/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
// PURE l4-v2 contract/controller helpers (no file I/O, no side-effecting imports — stays unit-testable;
// cbShared's libStor->libModel import crashes the l2 test stub). Two concerns:
//  1. B4 — resolve a bffCall projection deterministically: `$items` -> the operation's array field name,
//     input mapping (wire name -> usecase field), and the per-kind wire envelope.
//  2. B5 — GENERATE the l1 contract (Input/Output/route) from the bffCall (the agent must NEVER read a
//     `.ts` from l4 — l4 holds only `.defs.ts`). The controller emitter and the contract generator both
//     render from resolveBffProjection, so they share ONE source of truth for the shapes.
import { isRecord } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
/** The array-carrying field of a paginated/list operation outputShape (the `$items` target). The first
 * field of type 'array' (or one with a nested `item`) — real outputShapes have exactly one. */
export function resolveItemsArrayField(shape) {
    if (!shape || !Array.isArray(shape.fields))
        return null;
    const arr = shape.fields.find(f => f && (f.type === 'array' || isRecord(f.item)));
    return arr ? arr.name : null;
}
/** Parse a bffCall `from` path (`<op>.<field>` | `<op>.$items.<col>`) into its parts. Returns null for
 * a malformed/empty `from`. */
export function parseFromPath(from) {
    const raw = String(from || '').trim();
    if (!raw)
        return null;
    const segs = raw.split('.');
    if (segs.length < 2)
        return null;
    const operationId = segs[0];
    if (segs[1] === '$items') {
        const path = segs.slice(2);
        return path.length ? { operationId, fromItems: true, path } : null;
    }
    return { operationId, fromItems: false, path: segs.slice(1) };
}
export function resolveBffProjection(bff) {
    const kind = envelopeKindOf(bff);
    const fields = bff.output?.fields ?? [];
    if (kind === 'paginated') {
        // The array field carries nested item.fields (canonical) OR a bare `<op>.$items` from.
        const arrayField = fields.find(f => (f.item?.fields?.length) || isBareItems(f.from));
        const itemFields = (arrayField?.item?.fields ?? []).map(resolveField).filter((f) => f !== null);
        const arrOp = arrayField ? (parseFromPath(arrayField.from)?.operationId ?? itemFields[0]?.operationId ?? null) : null;
        const topFields = fields.filter(f => f !== arrayField).map(resolveField).filter((f) => f !== null);
        return { kind, itemFields, topFields, arrayFieldName: arrayField?.name ?? null, arrayOperationId: arrOp };
    }
    if (kind === 'list') {
        // Flat item columns at top level (each `<op>.$items.<col>`). Bare array wire.
        const itemFields = fields.map(resolveField).filter((f) => f !== null);
        return { kind, itemFields, topFields: [], arrayFieldName: null, arrayOperationId: itemFields[0]?.operationId ?? null };
    }
    const topFields = fields.map(resolveField).filter((f) => f !== null);
    return { kind, itemFields: [], topFields, arrayFieldName: null, arrayOperationId: null };
}
function isBareItems(from) {
    return /\.\$items$/.test(String(from || '').trim()); // `<op>.$items` with no column
}
function resolveField(field) {
    const parsed = parseFromPath(field.from);
    if (!parsed)
        return null;
    return { name: field.name, operationId: parsed.operationId, path: parsed.path, fromItems: parsed.fromItems };
}
export function envelopeKindOf(bff) {
    const kind = bff.output?.kind;
    return kind === 'paginated' || kind === 'list' ? kind : 'object';
}
// ── l1 contract GENERATION (replaces the l4 `.ts` byte-mirror — l4 holds only `.defs.ts`) ───────────
// The changeBackend agent must NEVER read a `.ts`/`.d.ts` from l4 (l4 is not compilable; getContent on
// it 422s). So the l1 contract is DERIVED from the workspace bffCall defs here, deterministically.
const capC = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
// l4 type token -> TS type. string/text/uuid -> string; number/money -> number; boolean; array/object structural.
export function tsTypeToken(t) {
    const x = String(t || '').toLowerCase();
    if (x === 'number' || x === 'money' || x === 'integer' || x === 'float' || x === 'decimal')
        return 'number';
    if (x === 'boolean' || x === 'bool')
        return 'boolean';
    if (x === 'array')
        return 'unknown[]';
    if (x === 'object')
        return 'Record<string, unknown>';
    return 'string';
}
/** Generate the l1 contract `.ts` for a bffCall from the workspace defs. Emits Input/Output + route const,
 * matching the canonical shapes: object -> interface; list -> `type Output = Item[]` (bare array);
 * paginated -> `{ <arrayName>: Item[], ...meta }` (declared array name). */
export function renderBffContract(project, moduleName, workspaceId, bff, types) {
    const Cap = capC(bff.bffId);
    const inputName = `${Cap}Input`, outputName = `${Cap}Output`, routeConst = `${bff.bffId}Route`;
    const route = bff.route || `${moduleName}.${workspaceId}.${bff.bffId}`;
    const last = (f) => f.path[f.path.length - 1] || f.name;
    const L = [
        `/// <mls fileReference="_${project}_/l1/${moduleName}/contracts/${workspaceId}.${bff.bffId}.ts" enhancement="_blank"/>`,
        ``,
        `// GENERATED MECHANICALLY from _${project}_/l4/${moduleName}/workspaces/${workspaceId}.defs.ts`,
        `// (bffCall ${bff.bffId}, ${bff.kind}, Output kind=${bff.output?.kind ?? 'object'}) — DO NOT EDIT.`,
        ``,
        `export interface ${inputName} {`,
    ];
    for (const i of bff.input) {
        const p = parseFromPath(i.from);
        const t = i.type || (p ? types.inputType(p.operationId, p.path[0] || i.name) : 'string');
        L.push(`  ${i.name}?: ${tsTypeToken(t)};`);
    }
    L.push(`}`, ``);
    const proj = resolveBffProjection(bff);
    if (!bff.output) {
        // command passthrough with no declared output: no Output interface (the controller returns the usecase result).
    }
    else if (proj.kind === 'object') {
        L.push(`export interface ${outputName} {`);
        for (const f of proj.topFields)
            L.push(`  ${f.name}: ${tsTypeToken(types.outputType(f.operationId, last(f), false))};`);
        L.push(`}`, ``);
    }
    else if (proj.kind === 'list') {
        const itemName = `${Cap}Item`;
        L.push(`export interface ${itemName} {`);
        for (const f of proj.itemFields)
            L.push(`  ${f.name}: ${tsTypeToken(types.outputType(f.operationId, last(f), true))};`);
        L.push(`}`, ``, `export type ${outputName} = ${itemName}[];`, ``);
    }
    else { // paginated
        const arrName = proj.arrayFieldName || 'items';
        const itemName = `${Cap}${capC(arrName)}Item`;
        L.push(`export interface ${itemName} {`);
        for (const f of proj.itemFields)
            L.push(`  ${f.name}: ${tsTypeToken(types.outputType(f.operationId, last(f), true))};`);
        L.push(`}`, ``, `export interface ${outputName} {`, `  ${arrName}: ${itemName}[];`);
        for (const f of proj.topFields)
            L.push(`  ${f.name}: ${tsTypeToken(types.outputType(f.operationId, last(f), false))};`);
        L.push(`}`, ``);
    }
    L.push(`export const ${routeConst} = '${route}' as const;`, ``);
    return L.join('\n');
}
