/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/.ts" enhancement="_102027_/l2/enhancementAgent"/>
// PURE l4-v2 contract/controller helpers (no file I/O, no side-effecting imports — stays unit-testable;
// cbShared's libStor->libModel import crashes the l2 test stub). Two concerns:
//  1. B5 — rewrite an l4 contract header so its byte-copy can live at l1 (the platform can't resolve the
//     l4 import, so controllers import the l1 mirror).
//  2. B4 — resolve a bffCall projection deterministically: `$items` -> the operation's array field name,
//     input mapping (wire name -> usecase field), and the per-kind wire envelope. Everything the
//     controller emitter needs is derived here so the generator and its test share ONE source of truth.
import { isRecord } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
// ── B5: l1 mirror header rewrite ────────────────────────────────────────────────
/** Rewrite an l4 contract's `.ts`/`.d.ts` content so the byte-copy is valid at l1: point the
 * `fileReference` at the l1 path and stamp a "copied from l4" note. The TYPE body is untouched.
 * Idempotent because callers always re-derive from the clean l4 source. */
export function rewriteContractHeaderToL1(content, project, moduleName, shortName, extension) {
    const l1Ref = `_${project}_/l1/${moduleName}/contracts/${shortName}${extension}`;
    const l4Ref = `_${project}_/l4/${moduleName}/contracts/${shortName}${extension}`;
    const note = `// COPIED FROM l4 — do not edit. Source of truth: ${l4Ref}.`;
    const out = content.replace(/(<mls\s+fileReference=")[^"]*(")/u, `$1${l1Ref}$2`);
    const nl = out.indexOf('\n');
    return nl >= 0 ? `${out.slice(0, nl + 1)}${note}\n${out.slice(nl + 1)}` : `${out}\n${note}\n`;
}
/** The array-carrying field of a paginated/list operation outputShape (the `$items` target). The first
 * field of type 'array' (or one with a nested `item`) — real outputShapes have exactly one. */
export function resolveItemsArrayField(shape) {
    if (!shape || !Array.isArray(shape.fields))
        return null;
    const arr = shape.fields.find(f => f && (f.type === 'array' || isRecord(f.item)));
    return arr ? arr.name : null;
}
/** Parse a bffCall `from` path (`<op>.<field>` | `<op>.$items.<col>`) into its parts. Returns null for
 * a malformed/empty `from`. */
export function parseFromPath(from) {
    const raw = String(from || '').trim();
    if (!raw)
        return null;
    const segs = raw.split('.');
    if (segs.length < 2)
        return null;
    const operationId = segs[0];
    if (segs[1] === '$items') {
        const path = segs.slice(2);
        return path.length ? { operationId, fromItems: true, path } : null;
    }
    return { operationId, fromItems: false, path: segs.slice(1) };
}
export function resolveBffProjection(bff) {
    const itemFields = [];
    const topFields = [];
    for (const field of bff.output?.fields ?? []) {
        const resolved = resolveField(field);
        if (!resolved)
            continue;
        (resolved.fromItems ? itemFields : topFields).push(resolved);
    }
    return { itemFields, topFields };
}
function resolveField(field) {
    const parsed = parseFromPath(field.from);
    if (!parsed)
        return null;
    return { name: field.name, operationId: parsed.operationId, path: parsed.path, fromItems: parsed.fromItems };
}
// The wire envelope key for each output kind. `object` returns the projected object as-is; `paginated`/
// `list` wrap the projected items under `items` (+ pagination meta passed through for paginated). This
// matches the v1 usecase envelope ({ items, total, page, pageSize }) and the generated contract (Output
// is the ITEM shape for paginated/list, the whole object for object). See B4 Notas.
export function envelopeKindOf(bff) {
    const kind = bff.output?.kind;
    return kind === 'paginated' || kind === 'list' ? kind : 'object';
}
