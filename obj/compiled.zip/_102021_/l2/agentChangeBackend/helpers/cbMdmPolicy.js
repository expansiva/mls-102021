/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbMdmPolicy.ts" enhancement="_blank"/>
const REASON = {
    mdm: 'master data is owned by 102034 and written through ctx.mdm (no local entity/port/adapter/table)',
    external: 'the identity lives outside this module; the FK keeps the external id (no local artifact, no seeds)',
};
const PERSISTENCE_SUFFIXES = new Set(['repository', 'repositoryadapter', 'adapter', 'table']);
function lowerSet(values) {
    return new Set([...(values ?? [])].map(value => String(value).toLowerCase()));
}
/**
 * One finding per (entity, forbidden artifact). `storage.target` is quoted verbatim so the reader can
 * go straight to the l4 line that was ignored.
 */
export function collectPersistencePolicyIssues(entities, artifacts) {
    const domain = lowerSet(artifacts.domainEntities);
    const ports = lowerSet(artifacts.ports);
    const persistence = lowerSet(artifacts.persistence);
    const seeded = lowerSet(artifacts.seededLocalEntities);
    const issues = [];
    for (const entity of entities) {
        const target = entity.storageTarget === 'mdm' || entity.storageTarget === 'external'
            ? entity.storageTarget
            : entity.kind === 'mdm' || entity.kind === 'external' ? entity.kind : '';
        if (!target)
            continue;
        const id = entity.entityId;
        const lc = id.toLowerCase();
        const reason = REASON[target];
        const found = [];
        if (domain.has(lc))
            found.push(`local domain entity ${id}.defs.ts`);
        if (ports.has(`${lc}repository`))
            found.push(`local port ${id}Repository.defs.ts`);
        // The generated names are the entity in lowerCamel plus a role suffix (`client.defs.ts` is the table
        // def, `clientRepositoryAdapter.defs.ts` the adapter). Matching by prefix ALONE would make `Client`
        // claim `clientBillingSummary`, so the suffix comes from a closed list.
        for (const name of persistence) {
            if (name === lc || (name.startsWith(lc) && PERSISTENCE_SUFFIXES.has(name.slice(lc.length)))) {
                found.push(`local persistence artifact ${name}.defs.ts`);
            }
        }
        if (seeded.has(lc)) {
            found.push(target === 'mdm' ? 'local seed rows (master data belongs to mdmEntities)' : 'local seed rows');
        }
        for (const artifact of found) {
            issues.push(`persistence policy: entity '${id}' declares storage.target '${target}' -> ${artifact} forbidden; ${reason}`);
        }
    }
    return [...new Set(issues)];
}
