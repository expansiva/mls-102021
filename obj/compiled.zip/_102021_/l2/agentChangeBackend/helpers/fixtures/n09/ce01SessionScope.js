/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce01SessionScope.ts" enhancement="_blank"/>
function detailField(details, fieldId) {
    if (!details || typeof details !== 'object' || Array.isArray(details))
        return '';
    const value = details[fieldId];
    return typeof value === 'string' ? value : '';
}
export async function scopeFilterForListAppointment(ctx) {
    const userId = String(ctx.sessionContext?.actorId ?? '').trim();
    if (!userId)
        return { fieldId: 'professionalId', allowed: [] };
    const listed = await ctx.mdm.collection.listByType({ type: 'agendaClinicaLike.Professional', status: 'Active' });
    const allowed = listed.items
        .filter(item => detailField(item.details, 'platformUserId') === userId)
        .map(item => item.mdmId);
    return { fieldId: 'professionalId', allowed };
}
export function rowInScope(row, filter) {
    const value = row[filter.fieldId];
    return filter.allowed.indexOf(typeof value === 'string' ? value : '') >= 0;
}
