/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce09SessionScope.ts" enhancement="_blank"/>
function detailField(details, fieldId) {
    if (!details || typeof details !== 'object' || Array.isArray(details))
        return '';
    const value = details[fieldId];
    return typeof value === 'string' ? value : '';
}
function fieldOf(row, fieldId) {
    const value = row[fieldId];
    return typeof value === 'string' ? value : '';
}
export async function scopeFilterForListVehicle(ctx, listAssignments) {
    const userId = String(ctx.sessionContext?.actorId ?? '').trim();
    if (!userId)
        return { fieldId: 'vehicleId', allowed: [] };
    const listed = await ctx.mdm.collection.listByType({ type: 'fleetLike.Driver', status: 'Active' });
    const personIds = listed.items
        .filter(item => detailField(item.details, 'platformUserId') === userId)
        .map(item => item.mdmId);
    const assignments = await listAssignments();
    const allowed = [...new Set(assignments
            .filter(row => personIds.indexOf(fieldOf(row, 'driverId')) >= 0)
            .map(row => fieldOf(row, 'vehicleId'))
            .filter(Boolean))];
    return { fieldId: 'vehicleId', allowed };
}
