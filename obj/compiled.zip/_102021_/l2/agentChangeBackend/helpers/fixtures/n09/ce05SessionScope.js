/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce05SessionScope.ts" enhancement="_blank"/>
function detailField(details, fieldId) {
    if (!details || typeof details !== 'object' || Array.isArray(details))
        return '';
    const value = details[fieldId];
    return typeof value === 'string' ? value : '';
}
export async function scopeFilterForInspectOrden(ctx) {
    const userId = String(ctx.sessionContext?.actorId ?? '').trim();
    if (!userId)
        return { fieldId: 'clienteId', allowed: [] };
    const listed = await ctx.mdm.collection.listByType({ type: 'ordenServicioLike.Cliente', status: 'Active' });
    const allowed = listed.items
        .filter(item => detailField(item.details, 'platformUserId') === userId)
        .map(item => item.mdmId);
    return { fieldId: 'clienteId', allowed };
}
