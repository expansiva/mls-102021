/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/fixtures/n13/listOverdue.ts" enhancement="_blank"/>
class AppError extends Error {
    constructor(code, message, status) {
        super(message);
        this.code = code;
        this.status = status;
    }
}
function resolveRepository(_ctx, _name) {
    throw new Error('fixture stub');
}
export async function listTuition(ctx, _input) {
    const tuitions = resolveRepository(ctx, 'Tuition');
    const rows = await tuitions.list();
    const today = ctx.clock.nowIso().slice(0, 10);
    return {
        tuitions: rows.map(row => {
            // time status computed on read (2026-09-09): overdue via overdueWhenPastDue
            const status = row.dueDate < today && row.balance > 0 ? 'overdue' : row.status;
            return { ...row, status };
        }),
    };
}
void AppError;
