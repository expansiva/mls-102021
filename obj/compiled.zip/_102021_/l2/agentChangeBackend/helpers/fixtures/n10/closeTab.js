/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/fixtures/n10/closeTab.ts" enhancement="_blank"/>
class AppError extends Error {
    constructor(code, message, status) {
        super(message);
        this.code = code;
        this.status = status;
    }
}
function resolveRepository(_ctx, _name) {
    throw new Error('fixture stub');
}
export async function closeTab(ctx, input) {
    const tabs = resolveRepository(ctx, 'Tab');
    const tabCloses = resolveRepository(ctx, 'TabClose');
    const tables = resolveRepository(ctx, 'Table');
    const tab = await tabs.findById(input.tabId);
    if (!tab)
        throw new AppError('NOT_FOUND', 'Tab not found.', 404);
    const now = ctx.clock.nowIso();
    const saved = await ctx.data.runInTransaction(async () => {
        const closed = { ...tab, status: 'closed', updatedAt: now };
        await tabs.save(closed);
        await tabCloses.save({ tabCloseId: ctx.idGenerator.newId(), tabId: tab.tabId, createdAt: now });
        const table = await tables.findById(tab.tableId);
        if (table)
            await tables.save({ ...table, status: 'free', updatedAt: now });
        return closed;
    });
    return { tabId: saved.tabId, tableId: saved.tableId, status: saved.status };
}
