/// <mls fileReference="_102021_/l2/agentChangeBackend/helpers/cbFindingSeverity.ts" enhancement="_blank"/>
export function partitionFindings(findings) {
    const blocking = [];
    const degradable = [];
    for (const finding of findings) {
        if (findingSeverity(finding) === 'degradable')
            degradable.push(finding);
        else
            blocking.push(finding);
    }
    return { blocking, degradable };
}
export function findingSeverity(finding) {
    if (isDegradableFinding(finding))
        return 'degradable';
    return 'blocking';
}
/** Opt-in list. Anything not matched stays blocking (compile, missing export, empty PK, composition root). */
function isDegradableFinding(finding) {
    return isSeedFinding(finding) || isOmittablePolicyFinding(finding) || isMissingContractRouteFinding(finding);
}
/**
 * A contract routine with no controller: the app BOOTS, the screens that call that routine answer 404.
 * Degradable by the same doctrine as seeds — the gate blocks what stops the app from coming up, and
 * reports the rest. The finding is still recorded and shown; only the run's fate changes.
 */
export function isMissingContractRouteFinding(finding) {
    return finding.startsWith('contract route without controller ->');
}
/** Seeds are test data: empty tables are a valid, visible app. Includes compiler errors ON seeds.ts. */
export function isSeedFinding(finding) {
    if (/\bseeds\.ts\b/i.test(finding))
        return true;
    if (/\blocal seed rows\b/i.test(finding))
        return true;
    if (/SEEDS-ENVIRONMENT-FAILURE/i.test(finding))
        return true;
    if (/^SEED\s/i.test(finding))
        return true;
    if (/seed wave \d+\s+skipped/i.test(finding))
        return true;
    if (/seeded EMPTY by design/i.test(finding))
        return true;
    if (/\bseedCoverage\b/i.test(finding))
        return true;
    return false;
}
/**
 * Persistence-policy findings about artifacts that can be omitted from publication (adapter/port/domain
 * /seed rows). A leaked TABLE is structural (migrate would create it) and stays blocking.
 */
export function isOmittablePolicyFinding(finding) {
    if (!finding.startsWith('persistence policy:'))
        return false;
    if (/\blocal seed rows\b/i.test(finding))
        return true;
    if (/\blocal domain entity\b/i.test(finding))
        return true;
    if (/\blocal port\b/i.test(finding))
        return true;
    if (/repositoryadapter\.defs\.ts/i.test(finding))
        return true;
    return false;
}
