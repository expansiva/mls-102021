/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/gen-seed-assets/seedAssetsCore.ts" enhancement="_blank"/>
// Pure planning/manifest helpers for optional seed images. Browser storage and image conversion stay
// in agentCbSeedAssets.ts because this step is the sole owner of the L3 asset boundary.
import { isSeedAssetRef } from '../../helpers/cbSeedsCore.js';
export const SEED_ASSET_SCHEMA_VERSION = 1;
const ASSET_ID = /^[A-Za-z][A-Za-z0-9_-]*\/[A-Za-z][A-Za-z0-9_-]*$/u;
export function emptySeedAssetManifest(moduleId) {
    return { schemaVersion: SEED_ASSET_SCHEMA_VERSION, moduleId, assets: [] };
}
export function parseSeedAssetManifest(value, moduleId) {
    if (!isRecord(value) || value.schemaVersion !== SEED_ASSET_SCHEMA_VERSION || value.moduleId !== moduleId || !Array.isArray(value.assets)) {
        return emptySeedAssetManifest(moduleId);
    }
    const assets = value.assets.flatMap((entry) => {
        if (!isRecord(entry) || !ASSET_ID.test(string(entry.id)) || typeof entry.path !== 'string' || typeof entry.publicUrl !== 'string'
            || entry.source !== 'imagem' || typeof entry.promptHash !== 'string' || (entry.status !== 'ready' && entry.status !== 'failed'))
            return [];
        return [{
                id: string(entry.id), path: string(entry.path), publicUrl: string(entry.publicUrl), source: 'imagem',
                promptHash: string(entry.promptHash), status: entry.status, ...(typeof entry.warning === 'string' ? { warning: entry.warning } : {}),
            }];
    }).sort((left, right) => left.id.localeCompare(right.id));
    return { schemaVersion: SEED_ASSET_SCHEMA_VERSION, moduleId, assets };
}
export function putSeedAssetManifestEntry(manifest, entry) {
    const assets = new Map(manifest.assets.map(item => [item.id, item]));
    assets.set(entry.id, entry);
    return { ...manifest, assets: [...assets.values()].sort((left, right) => left.id.localeCompare(right.id)) };
}
export function readySeedAssetUrls(manifest) {
    return Object.fromEntries(manifest.assets
        .filter(asset => asset.status === 'ready')
        .map(asset => [asset.id, asset.publicUrl])
        .sort(([left], [right]) => left.localeCompare(right)));
}
export function seedAssetWarnings(manifest) {
    return manifest.assets.filter(asset => asset.status === 'failed')
        .map(asset => `${asset.id}: ${asset.warning || 'image unavailable; seed value set to null'}`).sort();
}
export function collectSeedAssetRequests(moduleId, plan, entities) {
    const entityById = new Map(entities.map(entity => [entity.entityId, entity]));
    const candidates = [];
    for (const table of plan.localTables) {
        for (const row of table.rows)
            candidates.push(...assetFields(table.tableId, row.key, [...row.columns, ...row.details]));
    }
    for (const entity of plan.mdmEntities) {
        for (const row of entity.rows)
            candidates.push(...assetFields(entity.entityId, row.key, row.fields));
    }
    const unique = new Map();
    for (const candidate of candidates.sort((left, right) => left.assetId.localeCompare(right.assetId))) {
        if (!unique.has(candidate.assetId))
            unique.set(candidate.assetId, candidate);
    }
    return [...unique.values()].map(candidate => {
        const entity = entityById.get(candidate.entityId);
        const title = entity?.title || candidate.entityId;
        const description = describeSeedRow(title, candidate.rowKey, candidate.fields);
        const prompt = [
            'Create a realistic, original editorial image for a fictional example application.',
            `Subject: ${description}.`,
            'Square composition, natural light, no text, watermark, logo, brand, celebrity, or identifiable real person.',
        ].join(' ');
        const path = `seed/${candidate.assetId}.webp`;
        return {
            assetId: candidate.assetId,
            targetPath: `l3/${moduleId}/assets/${path}`,
            path,
            publicUrl: `/${moduleId}/assets/${path}`,
            alt: `${title} — ${candidate.rowKey}`.slice(0, 180),
            prompt,
            promptHash: `fnv1a32:${hash(prompt)}`,
            format: 'webp',
            maxWidth: 1200,
        };
    });
}
// T11: images are the most expensive thing this flow buys, and the seed plan can nominate an unbounded
// number of them. Cap the candidates per run and report what was dropped — a silent truncation would
// read as "all assets generated" when it wasn't ("no silent caps"). The list is already sorted by
// assetId in collectSeedAssetRequests, so the kept subset is deterministic across runs.
export const SEED_ASSET_CAP = 8;
export function capSeedAssetRequests(requests, cap = SEED_ASSET_CAP) {
    if (cap <= 0)
        return { kept: [], dropped: requests.map(request => request.assetId) };
    return {
        kept: requests.slice(0, cap),
        dropped: requests.slice(cap).map(request => request.assetId),
    };
}
/** Trace line for the dropped candidates (empty when nothing was capped). */
export function seedAssetCapWarning(dropped, cap = SEED_ASSET_CAP) {
    return dropped.length
        ? `${dropped.length} seed image(s) over the per-run cap of ${cap} were skipped: ${dropped.join(', ')}`
        : '';
}
function assetFields(entityId, rowKey, fields) {
    return fields.flatMap(field => {
        const value = field.value;
        return isSeedAssetRef(value) ? [{ assetId: value.asset, entityId, rowKey, fields }] : [];
    });
}
function describeSeedRow(title, rowKey, fields) {
    const details = fields.filter(field => /^(name|title|species|breed|type|color|description)$/iu.test(field.name))
        .map(field => typeof field.value === 'string' ? `${field.name} ${field.value.replace(/[\r\n<>]/g, ' ').slice(0, 80)}` : '')
        .filter(Boolean).join(', ');
    return details ? `${title}: ${details}` : `${title} identified by ${rowKey}`;
}
function hash(input) {
    let value = 0x811c9dc5;
    for (let index = 0; index < input.length; index++) {
        value ^= input.charCodeAt(index);
        value = Math.imul(value, 0x01000193);
    }
    return (value >>> 0).toString(16).padStart(8, '0');
}
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function string(value) {
    return typeof value === 'string' ? value : '';
}
