/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/gen-port/agentCbRepositoryPort.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { recordLlmCost } from '/_102021_/l2/agentChangeBackend/helpers/cbRepair.js';
import { readBackendScan, createPromptReadyIntent, createUpdateStatusIntent, enqueueNext, readCbPrompt, extractPlannerOutput, plannerConfig, createPlannerToolSchema, batchSchema, asArray, saveAgentTrace, saveDefs, buildArtifact, buildPipelineItem, repositoryPortFileInfo, domainEntityFileInfo, dtsRef, layerSkills, readString, lowerFirst, logPrefix, newestL4DefsMs, defsCurrent, isRebuildCommand, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { recordFailedCbRun } from '/_102021_/l2/agentChangeBackend/helpers/cbPipelineRun.js';
import { repositoryPortResultSchema } from '/_102021_/l2/agentChangeBackend/helpers/cbSchemas.js';
import { buildPortPlanItems, ensureRequiredPortMethods, requiredMethodsForEntity, stripEventPortDelete, } from '/_102021_/l2/agentChangeBackend/helpers/cbPortMethods.js';
const AGENT_NAME = 'agentCbRepositoryPort';
const TOOL_NAME = 'submitRepositoryPorts';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the repository port interfaces.', batchSchema(repositoryPortResultSchema));
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/gen-port', agentDescription: 'Generate repository port interfaces', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const scan = await readBackendScan(['toCreate', 'inProgress'], context);
    if (!isRebuildCommand(context)) {
        const module = scan.moduleNames[0] || 'unknown';
        const targetIds = [...scan.aggregates.map(a => a.rootEntity), ...scan.events.filter(ev => ev.persisted).map(ev => ev.entityId)];
        const watermark = newestL4DefsMs(scan.project);
        if (targetIds.length && targetIds.every(id => defsCurrent(repositoryPortFileInfo(module, id), watermark))) {
            return [
                enqueueNext(context, parentStep, step, 'cb-gen-table', 'agentCbPersistenceTable', 'Gerar tabelas (persistência)', {}),
                createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `reused ${targetIds.length} repository port .defs.ts (L4 unchanged; skipped generation)`, 'input_output'),
            ];
        }
    }
    const deleteTargets = new Set(scan.deleteTargetEntityIds);
    const items = buildPortPlanItems(scan.aggregates, deleteTargets);
    // Append-only event ports: append(record) + read finders (listByOwnerId, listByPeriod). NO update/delete.
    const eventItems = scan.events.filter(ev => ev.persisted).map(ev => ({ entityId: ev.entityId, appendOnlyEvent: true, owner: ev.ownerEntity }));
    const human = `## Aggregates\n${JSON.stringify(items, null, 2)}\n\n## Append-only event ports\n${JSON.stringify(eventItems, null, 2)}\n\nReturn one repository port (I{Entity}Repository) per aggregate AND per event. Aggregate ports use getById/list/save/domain finders. {Entity}ListFilter includes equality fields (PK/FKs/status) plus optional search/sortBy/sortOrder/page/pageSize when those list controls exist. A paginated list port also declares count(filter) — matching rows, not the page length. requiredMethods on an aggregate item is the l4 contract — declare every one of them. When the module deletes an aggregate, that port MUST declare delete — otherwise the generated delete usecase 409s with "repository does not support deletion". Event ports are append-only: an append(record) method plus read finders (e.g. listByOwnerId, listByPeriod) — never update or delete. Typed in domain terms.`;
    const systemPrompt = await readCbPrompt('steps/gen-port');
    return [createPromptReadyIntent(context, parentStep, hookSequential, (step.prompt || ""), systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    await recordLlmCost('gen-port', step.interaction); // T7: per-phase cost telemetry (best-effort)
    let status = 'completed';
    let trace;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const out = extractPlannerOutput(payload, plannerConfig(TOOL_NAME));
        const scan = await readBackendScan(['toCreate', 'inProgress'], context);
        const module = scan.moduleNames[0] || 'unknown';
        const deleteTargets = new Set(scan.deleteTargetEntityIds);
        const eventIds = new Set(scan.events.filter(ev => ev.persisted).map(ev => ev.entityId));
        let saved = 0;
        for (const raw of asArray(out.result.items)) {
            const item = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : null;
            if (!item)
                continue;
            const entityId = readString(item.entityId);
            if (!entityId)
                continue;
            if (eventIds.has(entityId)) {
                stripEventPortDelete(item);
            }
            else {
                const required = requiredMethodsForEntity(entityId, deleteTargets);
                item.requiredMethods = required;
                ensureRequiredPortMethods(item, required);
            }
            const fi = repositoryPortFileInfo(module, entityId);
            const dependsFiles = [dtsRef(domainEntityFileInfo(module, entityId))];
            const pipeline = [buildPipelineItem(`${lowerFirst(entityId)}Repository`, 'repositoryPort', fi, dependsFiles, layerSkills('repositoryPort.md'))];
            await saveDefs(fi, `${lowerFirst(entityId)}RepositoryPort`, buildArtifact('repositoryPort', `${entityId}Repository`, module, AGENT_NAME, item), pipeline);
            saved++;
        }
        if (out.status === 'failed') {
            status = 'failed';
            trace = 'model returned failed';
        }
    }
    catch (error) {
        status = 'failed';
        trace = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${trace}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    if (status === 'failed') {
        await recordFailedCbRun({ longMemory: context.task?.iaCompressed?.longMemory, reason: trace || 'failed' });
    }
    const intents = [];
    if (status === 'completed')
        intents.push(enqueueNext(context, parentStep, step, 'cb-gen-table', 'agentCbPersistenceTable', 'Gerar tabelas (persistência)', {}));
    intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, status, trace, status === 'completed' ? 'input_output' : undefined));
    return intents;
}
