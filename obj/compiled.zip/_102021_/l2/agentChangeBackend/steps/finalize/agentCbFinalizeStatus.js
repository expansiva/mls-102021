/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalizeStatus.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setTodoBackendStatus, enqueueNext, createUpdateStatusIntent, ALL_STATUSES } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbFinalizeStatus', agentProject: 102021, agentFolder: 'agentChangeBackend/steps/finalize', agentDescription: 'Deterministic todoBackend inProgress -> done', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        // ONE scan over every status: the owners to flip are the inProgress ones, and the rest of the
        // module's owners are the context that makes the count honest (see A2 above).
        const scan = await readBackendScan(ALL_STATUSES, context);
        const moduleName = scan.moduleNames[0] || '';
        let flipped = 0;
        for (const owner of scan.owners.filter(o => o.todoStatus === 'inProgress')) {
            if (await setTodoBackendStatus(owner, 'done'))
                flipped++;
        }
        // Already `done` BEFORE this step — in a normal run these are the owners gen-http flipped, i.e. the
        // ones whose .ts this run materialized and cb-validate-all just approved.
        const alreadyDone = scan.owners.filter(o => o.todoStatus === 'done').length;
        const ownersDone = flipped + alreadyDone;
        const trace = flipped
            ? `Marked ${flipped} owner(s) done${alreadyDone ? ` (+${alreadyDone} already done at gen-http)` : ''}.`
            : `${alreadyDone} owner(s) already done at gen-http (defs generated); materialization validated by cb-validate-all.`;
        return [
            enqueueNext(context, parentStep, step, 'cb-final-summary', 'agentCbFinalSummary', 'Resumo do run', { ownersDone, ownersFlipped: flipped, ownersAlreadyDone: alreadyDone, moduleName }),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
