/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalSummary.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createUpdateStatusIntent, isRecord, parseMaybeJson, saveBackendWorkspaceConfig } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbFinalSummary', agentProject: 102021, agentFolder: 'agentChangeBackend/steps/finalize', agentDescription: 'Terminal run summary + task completion', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const args = isRecord(parseMaybeJson(step.prompt)) ? parseMaybeJson(step.prompt) : {};
    let configMsg = '';
    try {
        configMsg = await saveBackendWorkspaceConfig();
    }
    catch (error) {
        configMsg = `l5/config.json backend update failed: ${error instanceof Error ? error.message : String(error)}`;
    }
    const summary = args.noWork
        ? `agentChangeBackend: nothing to create (no todoBackend status = toCreate). ${configMsg}`
        : `agentChangeBackend: run complete. owners done = ${args.ownersDone ?? 0}. ${configMsg}`;
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', summary)];
}
