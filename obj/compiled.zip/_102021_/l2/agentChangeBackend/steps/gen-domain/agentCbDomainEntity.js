/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/gen-domain/agentCbDomainEntity.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, createPromptReadyIntent, createUpdateStatusIntent, enqueueNext, readCbPrompt, extractPlannerOutput, plannerConfig, createPlannerToolSchema, batchSchema, asArray, saveAgentTrace, saveDefs, buildArtifact, buildPipelineItem, domainEntityFileInfo, layerSkills, readString, lowerFirst, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { domainEntityResultSchema } from '/_102021_/l2/agentChangeBackend/helpers/cbSchemas.js';
const AGENT_NAME = 'agentCbDomainEntity';
const TOOL_NAME = 'submitDomainEntities';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the pure domain entities (one per aggregate root).', batchSchema(domainEntityResultSchema));
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/gen-domain', agentDescription: 'Generate pure domain entities + value-objects', visibility: 'private', beforePromptStep, afterPromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    const scan = await readBackendScan(['toCreate', 'inProgress']);
    const byId = new Map(scan.entities.map(e => [e.entityId, e]));
    const items = scan.aggregates.map(agg => ({
        aggregateId: agg.aggregateId,
        root: { entityId: agg.rootEntity, fields: byId.get(agg.rootEntity)?.fields || [] },
        embeddedMembers: agg.embeddedMembers.map(id => ({ entityId: id, fields: byId.get(id)?.fields || [] })),
    }));
    // Persisted events (telemetry/audit) are immutable append-only records — generate a pure domain
    // entity for each (no embedded members, no behavior beyond shape) so its port/adapter/table can type it.
    const eventItems = scan.events.filter(ev => ev.persisted).map(ev => ({
        aggregateId: ev.entityId,
        root: { entityId: ev.entityId, fields: ev.fields || [] },
        embeddedMembers: [],
        appendOnlyEvent: true,
        eventOwner: ev.ownerEntity,
    }));
    const human = `## Aggregates (root + embedded members, with ontology fields)\n${JSON.stringify(items, null, 2)}\n\n## Append-only event records (one pure domain entity each, immutable, no valueObjects)\n${JSON.stringify(eventItems, null, 2)}\n\nReturn one pure domain entity per aggregate root AND per event record; embedded members become valueObjects (collection=true for oneToMany). Event records carry no invariants beyond their fields.`;
    const systemPrompt = await readCbPrompt('steps/gen-domain');
    return [createPromptReadyIntent(context, parentStep, hookSequential, (step.prompt || ""), systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    let status = 'completed';
    let trace;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const out = extractPlannerOutput(payload, plannerConfig(TOOL_NAME));
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const module = scan.moduleNames[0] || 'unknown';
        let saved = 0;
        for (const item of asArray(out.result.items)) {
            const entityId = readString(item.entityId);
            if (!entityId)
                continue;
            const fi = domainEntityFileInfo(module, entityId);
            const pipeline = [buildPipelineItem(lowerFirst(entityId), 'domainEntity', fi, [], layerSkills('domainEntity.md'))];
            await saveDefs(fi, `${lowerFirst(entityId)}DomainEntity`, buildArtifact('domainEntity', entityId, module, AGENT_NAME, item), pipeline);
            saved++;
        }
        if (out.status === 'failed') {
            status = 'failed';
            trace = 'model returned failed';
        }
    }
    catch (error) {
        status = 'failed';
        trace = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${trace}`);
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    const intents = [];
    if (status === 'completed')
        intents.push(enqueueNext(context, parentStep, step, 'cb-gen-port', 'agentCbRepositoryPort', 'Gerar ports de repositório', {}));
    intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, status, trace, status === 'completed' ? 'input_output' : undefined));
    return intents;
}
