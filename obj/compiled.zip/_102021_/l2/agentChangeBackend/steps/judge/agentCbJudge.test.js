/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge.test.ts" enhancement="_blank"/>
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { lintToolSchema } from '/_102025_/l2/toolSchemaLint.js';
import { callToolProvider, liveTestsEnabled, parseEnvFile } from '/_102025_/l2/testLlmClient.js';
import { createPlannerToolSchema } from '/_102021_/l2/agentChangeBackend/helpers/cbPlanner.js';
import { judgeResultSchema } from '/_102021_/l2/agentChangeBackend/helpers/cbSchemas.js';
import { JUDGE_BATCH_MAX_BYTES, JUDGE_BATCH_MAX_PAIRS, MAX_PROMPT_BYTES, planJudgeBatch, promptSizeError, } from '/_102021_/l2/agentChangeBackend/helpers/cbPromptBudget.js';
import { judgeBatchContextLines } from '/_102021_/l2/agentChangeBackend/steps/judge/judgeBatchContext.js';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const MLS_BASE = path.resolve(HERE, '../../../../..');
const TOOL_NAME = 'submitJudgeFindings';
const MODEL_TYPES = ['code', 'design'];
void test('the judge is a dispatcher, N batch workers and one collector', () => {
    const dispatcher = readFileSync(path.join(HERE, 'agentCbJudge.ts'), 'utf8');
    const worker = readFileSync(path.join(HERE, 'agentCbJudgeBatch.ts'), 'utf8');
    const collector = readFileSync(path.join(HERE, 'agentCbJudgeCollect.ts'), 'utf8');
    const flow = readFileSync(path.join(HERE, '..', '..', 'flow.json'), 'utf8');
    // The dispatcher plans and fans out; it must not call the model itself (that was the 413).
    assert.match(dispatcher, /createParallelStepIntent\(context, parentStep, fanoutPlanId, 'agentCbJudgeBatch'/);
    assert.match(dispatcher, /\{\{completed\}\}\/\{\{total\}\}/);
    assert.doesNotMatch(dispatcher, /createPromptReadyIntent/);
    assert.doesNotMatch(dispatcher, /afterPromptStep/);
    // The worker judges its slice and persists it — the runtime discards a child's return value —
    // and it never fails (a failed child fails the whole task) and never adds steps.
    assert.match(worker, /createPromptReadyIntent/);
    assert.match(worker, /saveBatchFindings/);
    assert.doesNotMatch(worker, /'failed'/);
    assert.doesNotMatch(worker, /createAddStepIntent|createParallelStepIntent/);
    // The collector owns the single routing decision, over the union of the batches.
    assert.match(collector, /readBatchFindings\(runId, judgeRun\)/);
    assert.match(collector, /createParallelStepIntent\(context, parentStep, repairPlanId, 'agentCbUsecase'/);
    assert.match(collector, /'cb-gen-http'/);
    assert.match(flow, /"agentName": "agentCbJudge"/);
});
void test('agentCbJudge tool schema is provider-clean', () => {
    const errs = lintToolSchema(JSON.stringify(tool().function.parameters));
    assert.equal(errs, null, errs?.join(' | '));
});
for (const modelType of MODEL_TYPES) {
    void test(`agentCbJudge live @ ${modelType}: schema accepted + result has findings`, { skip: !liveTestsEnabled() }, async () => {
        const r = await callToolProvider(config(), { modelType, system: system(modelType), human: human({ findings: [] }), tool: tool() });
        assertLiveResponse(r);
        assert.ok(isRecord(r.args) && Array.isArray(r.args.findings), `${modelType}: result.findings missing`);
    });
}
function tool() {
    return createPlannerToolSchema(TOOL_NAME, 'Submit the judge findings.', judgeResultSchema);
}
function system(modelType) {
    return ['<!-- modelType: code -->', '<!-- x-tool-strict: true -->', `Return only one valid ${TOOL_NAME} tool call for model ${modelType}.`].join('\n');
}
function human(result) {
    return `Call ${TOOL_NAME} with exactly this arguments JSON:\n${JSON.stringify({ status: 'ok', result, questions: [], trace: ['schema-test'] }, null, 2)}`;
}
function config() {
    return parseEnvFile(readFileSync(path.join(MLS_BASE, '.env'), 'utf8'));
}
function assertLiveResponse(r) {
    const sample = r.text.replace(/\s+/g, ' ').slice(0, 200);
    assert.ok(!r.schemaReject, `${r.modelType}: schema rejected (${r.status}): ${sample}`);
    assert.equal(r.status, 200, `${r.modelType}: expected 200, got ${r.status}: ${sample}`);
    assert.ok(r.args, `${r.modelType}: no tool_call result`);
}
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
// ── batching (413 Payload Too Large) ────────────────────────────────────────
// 119 pairs of (L4 contract + generated usecase defs) pretty-printed is megabytes: the intents POST
// answered 413, the client swallowed it, and the step hung forever in waiting_human_input.
void test('the batch packer respects the byte budget, the pair cap and the queue order', () => {
    const queue = Array.from({ length: 119 }, (_value, index) => ({
        ownerId: `op${index}`,
        // Sizes vary a lot between usecases; a few are huge on their own.
        bytes: index % 17 === 0 ? 90000 : 4000 + (index % 5) * 3000,
    }));
    const batches = [];
    let pending = queue.map(entry => entry.ownerId);
    while (pending.length) {
        const slice = queue.filter(entry => pending.includes(entry.ownerId));
        const plan = planJudgeBatch(slice);
        assert.ok(plan.batch.length >= 1, 'a batch always drains at least one owner');
        assert.ok(plan.batch.length <= JUDGE_BATCH_MAX_PAIRS);
        const bytes = plan.batch.reduce((sum, id) => sum + (queue.find(entry => entry.ownerId === id)?.bytes || 0), 0);
        // Over budget is only allowed when a SINGLE pair is already over it.
        assert.ok(bytes <= JUDGE_BATCH_MAX_BYTES || plan.batch.length === 1, `batch of ${bytes} bytes`);
        batches.push(plan.batch);
        pending = plan.pending;
    }
    // Order preserved and nothing lost or judged twice.
    const flat = batches.flat();
    assert.deepEqual(flat, queue.map(entry => entry.ownerId));
    assert.equal(new Set(flat).size, queue.length);
    assert.ok(batches.length >= 8 && batches.length <= 20, `expected a handful of batches, got ${batches.length}`);
});
void test('a pair bigger than the whole budget still drains, alone', () => {
    const plan = planJudgeBatch([{ ownerId: 'huge', bytes: JUDGE_BATCH_MAX_BYTES * 3 }, { ownerId: 'next', bytes: 10 }]);
    assert.deepEqual(plan.batch, ['huge']);
    assert.deepEqual(plan.pending, ['next']);
});
void test('the batches are planned once and their findings meet only in the collector', () => {
    const dispatcher = readFileSync(path.join(HERE, 'agentCbJudge.ts'), 'utf8');
    const worker = readFileSync(path.join(HERE, 'agentCbJudgeBatch.ts'), 'utf8');
    const collector = readFileSync(path.join(HERE, 'agentCbJudgeCollect.ts'), 'utf8');
    // Planned ONCE by the dispatcher; the worker receives its owners as the arg and re-plans nothing.
    assert.match(dispatcher, /planBatches\(await pairSizes\(scan, operations\)\)/);
    assert.doesNotMatch(worker, /planJudgeBatch/);
    assert.match(worker, /const wanted = new Set\(parsed\.queue \|\| parsed\.owners\)/);
    // Parallel workers must not read-modify-write one shared accumulator: each writes its own file and
    // the collector unions them (concurrent writers to cb-repair-state would drop findings).
    assert.match(worker, /judgeFindingsFileInfo/);
    // The findings of a PREVIOUS execution stay in l4/trace as its audit; this run's files carry the
    // task in the name so a fresh judge run 1 never reads them as its own.
    assert.match(dispatcher, /const runId = judgeArgsOf\(step\)\.runId \|\| String\(context\.task\?\.PK/);
    assert.match(worker, /runId: batch\.runId/);
    assert.match(collector, /const prefix = judgeFindingsPrefix\(runId, judgeRun\)/);
    assert.match(collector, /for \(const file of Object\.values\(mls\.stor\.files\)/);
    assert.doesNotMatch(worker, /saveRepairState/);
    // The routing decision — and only it — writes the repair state.
    assert.match(collector, /saveRepairState\(state\)/);
    assert.match(collector, /judgeRun < JUDGE_MAX_RUNS/);
});
void test('a prompt over the transport limit fails the step instead of hanging it', () => {
    assert.equal(promptSizeError('cb-judge', 'x'.repeat(1000)), null);
    const message = promptSizeError('cb-judge', 'x'.repeat(MAX_PROMPT_BYTES + 1));
    assert.match(String(message), /cb-judge: prompt of \d+KB exceeds the \d+KB transport limit/);
    assert.match(String(message), /must batch or fan out/);
    // System and human count together — the transport sees one body.
    assert.ok(promptSizeError('cb-judge', 'x'.repeat(MAX_PROMPT_BYTES - 10), 'y'.repeat(100)));
    // And the shared intent factory is the one place that enforces it.
    const shared = readFileSync(path.join(HERE, '..', '..', 'helpers', 'cbShared.ts'), 'utf8');
    assert.match(shared, /const oversize = promptSizeError\([\s\S]{0,120}\n\s*if \(oversize\) throw new Error\(oversize\);/);
});
// ── V1: os 85/85 do run 5 não eram o juiz exagerando ─────────────────────────
// Os 121 achados eram todos "usecase .defs.ts missing for operation X": este cliente não tinha
// observado o que o fan-out escreveu (no re-judge, com os arquivos visíveis, sobraram 10 achados
// reais). Custou uma rodada de repair de 85 usecases em chamadas de LLM.
void test('the judge refreshes the file index before judging, and never repairs a whole module for invisibility', () => {
    const dispatcher = readFileSync(path.join(HERE, 'agentCbJudge.ts'), 'utf8');
    const collector = readFileSync(path.join(HERE, 'agentCbJudgeCollect.ts'), 'utf8');
    // Barreira de visibilidade antes de planejar (leitura, uma requisição).
    assert.match(dispatcher, /await refreshProjectIndex\(\);/);
    assert.match(dispatcher, /loadProjectInfoIfNeeded\(mls\.actualProject \|\| 0, true\)/);
    // E o collector trata "todos ausentes" como ambiente, sem rotear repair.
    assert.match(collector, /JUDGE-ENVIRONMENT-FAILURE/);
    assert.match(collector, /new Set\(missingDefs\.map\(finding => finding\.ownerId\)\)\.size === operationIds\.size/);
    assert.match(collector, /operationIds\.size > 2/); // um módulo minúsculo não vira diagnóstico de ambiente
});
// ── derived projections (carve-out simétrico ao MDM) ──────────────────────────
// A operação lê a projeção e, de propósito, não declara port. Sem esta lista + a
// exceção na regra 1 o judge acusa o código certo e o repair queima o orçamento.
const LEGACY_JUDGE_HEADER = (validPorts, mdmIds) => [
    `## Valid repository ports (aggregate roots + persisted event stores): ${JSON.stringify([...validPorts])}`,
    `## MDM entities (read by id via 102034; NEVER a port, NEVER a local entity): ${JSON.stringify([...mdmIds])}`,
].join('\n');
void test('scan with a derived entity lists it in the judge header and teaches no-port compose', () => {
    const entities = [
        { entityId: 'Petition', kind: 'core' },
        { entityId: 'SignatureExport', kind: 'derived' },
    ];
    const derivedIds = entities.filter(e => e.kind === 'derived').map(e => e.entityId);
    const text = judgeBatchContextLines(['Petition'], [], derivedIds).join('\n');
    assert.match(text, /SignatureExport/);
    assert.match(text, /no table, no port/);
    assert.match(text, /COMPOSES the projection in the output/);
    assert.match(text, /ofEntity pointing at them is legitimate/);
    const worker = readFileSync(path.join(HERE, 'agentCbJudgeBatch.ts'), 'utf8');
    assert.match(worker, /kind === 'derived'/);
    assert.match(worker, /judgeBatchContextLines\(validPorts, mdmIds, derivedIds\)/);
});
void test('scan without derived entities leaves the judge header byte-identical to the pre-derived form', () => {
    const entities = [
        { entityId: 'Petition', kind: 'core' },
        { entityId: 'Person', kind: 'mdm' },
    ];
    const derivedIds = entities.filter(e => e.kind === 'derived').map(e => e.entityId);
    const validPorts = ['Petition'];
    const mdmIds = ['Person'];
    const text = judgeBatchContextLines(validPorts, mdmIds, derivedIds).join('\n');
    assert.equal(text, LEGACY_JUDGE_HEADER(validPorts, mdmIds));
    assert.equal(text.includes('Derived'), false);
    assert.equal(text.includes('derived'), false);
    assert.equal(judgeBatchContextLines(validPorts, mdmIds).join('\n'), LEGACY_JUDGE_HEADER(validPorts, mdmIds));
});
void test('prompt.md item 1 carves out derived projections and keeps MDM plus invented-port bans', () => {
    const prompt = readFileSync(path.join(HERE, 'prompt.md'), 'utf8');
    const item1Start = prompt.indexOf('1. Ports:');
    const item2Start = prompt.indexOf('2. rulesApplied:');
    assert.ok(item1Start >= 0 && item2Start > item1Start, 'item 1 must precede item 2');
    const item1 = prompt.slice(item1Start, item2Start);
    assert.match(item1, /An invented\s+port/);
    assert.match(item1, /a port for an MDM entity/);
    assert.match(item1, /a port for a derived projection/);
    assert.match(item1, /does NOT require a port/);
    assert.match(item1, /missing\s+port for a persisted/);
    assert.match(item1, /declaring a port for it is the error/);
});
