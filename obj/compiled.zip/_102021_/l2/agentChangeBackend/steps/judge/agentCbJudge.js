/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, createUpdateStatusIntent, createAgentStepPayload, createAddStepIntent, createParallelStepIntent, enqueueNextInPhase, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { byteLength, planJudgeBatch } from '/_102021_/l2/agentChangeBackend/helpers/cbPromptBudget.js';
import { judgeArgsOf, ownerContract, readUsecaseDefsByOwner, scopedOperations, } from '/_102021_/l2/agentChangeBackend/steps/judge/judgeShared.js';
const AGENT_NAME = 'agentCbJudge';
export function createAgent() {
    return {
        agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/judge',
        agentDescription: 'Plans the judge batches and fans them out; the collector routes their findings',
        visibility: 'private', beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress'], context);
        const { judgeRun, operations } = scopedOperations(scan, step);
        if (!operations.length) {
            return [
                enqueueNextInPhase(context, step, 'materialization', 'cb-gen-http', 'agentCbHttpController', 'Gerar controllers HTTP (BFF)', {}),
                createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'no operation owners to judge'),
            ];
        }
        // The batches are planned ONCE, here, from the real byte size of each pair — a worker never
        // re-plans and never re-scans the module (skills §4: the per-item arg is the queue, not a payload).
        const batches = planBatches(await pairSizes(scan, operations));
        const fanoutPlanId = `cb-judge-b${judgeRun}`;
        const collectPlanId = `cb-judge-collect-r${judgeRun}`;
        // The findings files of a previous execution stay in l4/trace as its audit; naming this run's
        // files after the task keeps a fresh judge run 1 from reading them as its own.
        const runId = judgeArgsOf(step).runId || String(context.task?.PK || context.message.orderAt || '');
        const batchArgs = batches.map((owners, index) => JSON.stringify({
            planId: `${fanoutPlanId}-${index + 1}`, judgeRun, batchIndex: index + 1, queue: owners, runId,
        }));
        const collect = createAgentStepPayload(collectPlanId, 'agentCbJudgeCollect', 'Consolidar achados do juiz', { planId: collectPlanId, judgeRun, runId, owners: judgeRun > 1 ? operations.map(owner => owner.id) : [] }, [fanoutPlanId], 'sequential', 'waiting_dependency');
        collect.onFailure = 'continue';
        return [
            createParallelStepIntent(context, parentStep, fanoutPlanId, 'agentCbJudgeBatch', 'Juiz LLM {{completed}}/{{total}} lotes, falhas {{failed}}', batchArgs, [], 5),
            createAddStepIntent(context, parentStep, collect),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `judge run ${judgeRun}: ${operations.length} usecase(s) in ${batches.length} batch(es)`, 'input_output'),
        ];
    }
    catch (error) {
        // The judge must never kill a run by itself: fail soft to the chain, keep the trace objective.
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${message}`);
        return [
            enqueueNextInPhase(context, step, 'materialization', 'cb-gen-http', 'agentCbHttpController', 'Gerar controllers HTTP (BFF)', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `judge skipped (error): ${message}`),
        ];
    }
}
/** The size of the pair each owner contributes — what the packer bounds a batch by. */
async function pairSizes(scan, operations) {
    const defsByOwner = await readUsecaseDefsByOwner(scan, operations);
    return operations.map(owner => ({
        ownerId: owner.id,
        bytes: byteLength(JSON.stringify({ l4Contract: ownerContract(owner), generatedUsecaseDefs: defsByOwner.get(owner.id) ?? null }, null, 2)),
    }));
}
function planBatches(queue) {
    const batches = [];
    let pending = queue;
    while (pending.length) {
        const plan = planJudgeBatch(pending);
        batches.push(plan.batch);
        pending = pending.filter(entry => plan.pending.includes(entry.ownerId));
    }
    return batches;
}
export { judgeArgsOf };
