/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/judge/agentCbJudgeCollect.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, createUpdateStatusIntent, createAgentStepPayload, createAddStepIntent, createParallelStepIntent, CB_MAX_PARALLEL, enqueueNextInPhase, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { readRepairState, saveRepairState, usecaseDefsTarget, COMPONENT_REPAIR_BUDGET, JUDGE_MAX_RUNS, } from '/_102021_/l2/agentChangeBackend/helpers/cbRepair.js';
import { judgeArgsOf, judgeFindingsPrefix, scopedOperations, } from '/_102021_/l2/agentChangeBackend/steps/judge/judgeShared.js';
import { cbTraceReadFolders } from '/_102021_/l2/agentChangeBackend/helpers/cbTraceScope.js';
const AGENT_NAME = 'agentCbJudgeCollect';
export function createAgent() {
    return {
        agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/judge',
        agentDescription: 'Unions the judge batch findings and routes them to the repair loop or to the controllers',
        visibility: 'private', beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const { judgeRun, runId } = judgeArgsOf(step);
        const scan = await readBackendScan(['toCreate', 'inProgress'], context);
        const { operations } = scopedOperations(scan, step);
        const operationIds = new Set(operations.map(owner => owner.id));
        const findings = (await readBatchFindings(runId, judgeRun)).filter(finding => operationIds.has(finding.ownerId));
        const warnings = findings.filter(finding => finding.severity !== 'error');
        // EVERY usecase missing is not N worker failures: it is this client not seeing what the fan-out
        // wrote (run 5: 85/85 routed to repair, 85 LLM calls spent regenerating files that were on disk).
        // Say so once and route nothing — the same doctrine the materialization gates already use.
        const missingDefs = findings.filter(finding => /usecase \.defs\.ts missing for operation/u.test(finding.message));
        if (operationIds.size > 2 && new Set(missingDefs.map(finding => finding.ownerId)).size === operationIds.size) {
            return [
                enqueueNextInPhase(context, step, 'materialization', 'cb-gen-http', 'agentCbHttpController', 'Gerar controllers HTTP (BFF)', {}),
                createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `JUDGE-ENVIRONMENT-FAILURE: all ${operationIds.size} usecase defs read as missing, so this client did not observe what the fan-out wrote — not a defect of ${operationIds.size} usecases. No repair was routed; the deterministic gates of materialization and validate-all still check the artifacts.`, 'input_output'),
            ];
        }
        // Route only errors that name a real owner with repair budget left.
        const state = await readRepairState();
        const errorsByOwner = new Map();
        for (const finding of findings) {
            if (finding.severity !== 'error')
                continue;
            const target = usecaseDefsTarget(finding.ownerId);
            if ((state.componentRepairs[target]?.attempts ?? 0) > COMPONENT_REPAIR_BUDGET)
                continue;
            errorsByOwner.set(finding.ownerId, [...(errorsByOwner.get(finding.ownerId) || []), finding]);
        }
        if (errorsByOwner.size > 0 && judgeRun < JUDGE_MAX_RUNS) {
            for (const [ownerId, list] of errorsByOwner) {
                const target = usecaseDefsTarget(ownerId);
                state.componentRepairs[target] = {
                    target,
                    attempts: state.componentRepairs[target]?.attempts ?? 0,
                    findings: list.map(finding => `[${finding.type}] ${finding.message}${finding.suggestion ? ` — suggestion: ${finding.suggestion}` : ''}`).slice(0, 20),
                    source: 'judge',
                    updatedAt: new Date().toISOString(),
                };
            }
            state.judgeRuns = judgeRun;
            await saveRepairState(state);
            const repairPlanId = `cb-usecase-repair-r${judgeRun}`;
            const repaired = [...errorsByOwner.keys()];
            const nextRun = judgeRun + 1;
            const nextJudgePlanId = `cb-judge-r${nextRun}`;
            // Re-verification is SCOPED to the repaired owners (mechanical): run 1 already cleared the rest.
            const nextJudge = createAgentStepPayload(nextJudgePlanId, 'agentCbJudge', `Juiz LLM (re-verificação de ${repaired.length})`, { planId: nextJudgePlanId, judgeRun: nextRun, owners: repaired }, [repairPlanId], 'sequential', 'waiting_dependency');
            nextJudge.onFailure = 'continue'; // an LLM 502 must never kill the task
            return [
                createParallelStepIntent(context, parentStep, repairPlanId, 'agentCbUsecase', 'Reparar usecases {{completed}}/{{total}}, falhas {{failed}}', repaired, [], CB_MAX_PARALLEL),
                createAddStepIntent(context, parentStep, nextJudge),
                createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `judge run ${judgeRun}/${JUDGE_MAX_RUNS}: ${errorsByOwner.size} usecase(s) routed to repair; ${warnings.length} warning(s)`, 'input_output'),
            ];
        }
        // PASS or final run: remaining errors are DOWNGRADED to warnings here — the judge signals, the
        // deterministic validators stay the blocking gate.
        const leftover = findings.filter(finding => finding.severity === 'error');
        const trace = leftover.length
            ? `judge run ${judgeRun}/${JUDGE_MAX_RUNS}: budget exhausted; ${leftover.length} finding(s) downgraded to warning: ${leftover.slice(0, 8).map(finding => `${finding.ownerId}: ${finding.message}`).join('; ')}`
            : `judge run ${judgeRun}/${JUDGE_MAX_RUNS}: clean (${warnings.length} warning(s))`;
        return [
            enqueueNextInPhase(context, step, 'materialization', 'cb-gen-http', 'agentCbHttpController', 'Gerar controllers HTTP (BFF)', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace, 'input_output'),
        ];
    }
    catch (error) {
        // The judge must never kill a run by itself: fail soft to the chain, keep the trace objective.
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${message}`);
        return [
            enqueueNextInPhase(context, step, 'materialization', 'cb-gen-http', 'agentCbHttpController', 'Gerar controllers HTTP (BFF)', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `judge skipped (error): ${message}`),
        ];
    }
}
/** Every batch file of THIS run. A batch that wrote nothing simply said nothing. */
async function readBatchFindings(runId, judgeRun) {
    const project = mls.actualProject || 0;
    const prefix = judgeFindingsPrefix(runId, judgeRun);
    const findings = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 4 || file.status === 'deleted')
            continue;
        // The findings live in this module's `pipeline/trace/l1` folder.
        const folder = String(file.folder || '');
        if (file.extension !== '.json' || !cbTraceReadFolders().includes(folder))
            continue;
        if (!String(file.shortName || '').startsWith(prefix))
            continue;
        try {
            const parsed = JSON.parse(String(await file.getContent()));
            if (Array.isArray(parsed?.findings))
                findings.push(...parsed.findings);
        }
        catch { /* an unreadable batch file says nothing */ }
    }
    return findings;
}
