/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/scan/agentCbLockOwners.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setTodoBackendStatus, enqueueNextInPhase, createUpdateStatusIntent } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
export function createAgent() {
    return { agentName: 'agentCbLockOwners', agentProject: 102021, agentFolder: 'agentChangeBackend/steps/scan', agentDescription: 'Deterministic todoBackend toCreate -> inProgress lock', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate'], context);
        let locked = 0;
        for (const owner of scan.owners) {
            if (await setTodoBackendStatus(owner, 'inProgress'))
                locked++;
        }
        return [
            enqueueNextInPhase(context, step, 'generation', 'cb-gen-domain', 'agentCbDomainEntity', 'Gerar entidades de domínio', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Locked ${locked} owner(s).`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
