/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/gen-http/agentCbHttpController.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNext, createUpdateStatusIntent, isRecord, saveDefs, buildArtifact, buildPipelineItem, httpControllerFileInfo, usecaseFileInfo, dtsRef, layerSkills, capitalize, lowerFirst, logPrefix, readCliCommand, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { saveGeneratedTs } from '/_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo.js';
// Item 5 — boundary DTO (adapter HTTP owns the wire shape). The DTO .ts is a thin alias of the
// usecase output type + identity toDto: it is the projection SEAM (the ownership boundary), so the day
// a usecase goes domain-shaped only toDto changes and the public contract + frontend stay put. Kept as
// an alias (not a hand-mirrored interface) so it is deterministic and always compiles. The top-level
// `responseShape` copied into the controller defs is the single source the frontend contract derives
// from (killing the l4 re-inference drift). Nested item schemas are NOT carried yet (they live only in
// usecase-defs prose) — deferred; top-level fixes every reported bug and every task2 acceptance case.
const HTTP_DTO_FOLDER_SUFFIX = 'layer_1_external/adapters/http/dto';
function dtoFileInfo(module, ownerId) {
    return { project: mls.actualProject || 0, level: 1, folder: `${module}/${HTTP_DTO_FOLDER_SUFFIX}`, shortName: lowerFirst(ownerId), extension: '.defs.ts' };
}
/** Top-level wire shape from the usecase output field list (object with named fields; each field kept
 *  as array | object | scalar). The frontend copies this instead of re-inferring the shape from l4. */
function buildResponseShape(output) {
    if (!Array.isArray(output) || output.length === 0)
        return undefined;
    return { kind: 'object', fields: output.map(f => ({ name: f.name, type: f.type, required: f.required })) };
}
function renderDtoTs(module, ownerId, outputTypeName) {
    const project = mls.actualProject || 0;
    const dtoName = `${capitalize(ownerId)}ResponseDto`;
    const usecaseImport = `/_${project}_/l1/${module}/layer_2_application/usecases/${lowerFirst(ownerId)}.js`;
    return [
        `/// <mls fileReference="_${project}_/l1/${module}/${HTTP_DTO_FOLDER_SUFFIX}/${lowerFirst(ownerId)}.ts" enhancement="_blank"/>`,
        ``,
        `// Boundary DTO for the ${ownerId} routine — the wire shape owned by the HTTP adapter. Alias of the`,
        `// usecase output today (toDto is identity); the seam lets the public contract diverge from the`,
        `// usecase later without touching the frontend. Frontend copies the shape from the controller defs.`,
        `import type { ${outputTypeName} } from '${usecaseImport}';`,
        ``,
        `export type ${dtoName} = ${outputTypeName};`,
        ``,
        `export function toDto(result: ${outputTypeName}): ${dtoName} {`,
        `  return result;`,
        `}`,
        ``,
    ].join('\n');
}
const AGENT_NAME = 'agentCbHttpController';
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/gen-http', agentDescription: 'Generate BFF http controllers from l4 (usecase-driven; contract optional)', visibility: 'private', beforePromptStep };
}
/** Page ids that already have a frontend contract (optional Output refinement). */
async function contractPageIds() {
    const project = mls.actualProject || 0;
    const ids = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 2 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || !String(file.folder || '').endsWith('/web/contracts'))
            continue;
        const sn = String(file.shortName || '');
        if (sn)
            ids.add(sn);
    }
    return ids;
}
/** First `export const … = {…} as const;` — the artifact block (parseDefsSource spans both exports). */
function parseArtifactData(content) {
    const s = content.indexOf('= ');
    const e = content.indexOf(' as const;');
    if (s === -1 || e <= s)
        return undefined;
    try {
        const o = JSON.parse(content.slice(s + 2, e));
        if (!isRecord(o))
            return undefined;
        return isRecord(o.data) ? o.data : o;
    }
    catch {
        return undefined;
    }
}
/** Read each generated usecase's EXPORTED functions from its saved defs, keyed by usecaseId. The
 * controller binds to these real names so it never imports a function the usecase did not produce. */
async function readUsecaseFunctions() {
    const project = mls.actualProject || 0;
    const map = new Map();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || !String(file.folder || '').endsWith('/layer_2_application/usecases'))
            continue;
        const data = parseArtifactData(String(await file.getContent()));
        if (!data)
            continue;
        const usecaseId = String(data.usecaseId || file.shortName || '');
        const fns = Array.isArray(data.functions) ? data.functions : [];
        const parsed = fns
            .map((f) => ({
            functionName: String(f?.functionName || ''),
            inputTypeName: f?.inputTypeName ? String(f.inputTypeName) : undefined,
            outputTypeName: f?.outputTypeName ? String(f.outputTypeName) : undefined,
            kind: f?.kind ? String(f.kind) : undefined,
            output: Array.isArray(f?.output)
                ? f.output.filter(isRecord).map((o) => ({ name: String(o?.name || ''), type: String(o?.type || 'unknown'), required: o?.required === true })).filter((o) => !!o.name)
                : undefined,
        }))
            .filter((f) => !!f.functionName);
        if (usecaseId && parsed.length)
            map.set(usecaseId, parsed);
    }
    return map;
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const module = scan.moduleNames[0] || 'unknown';
        const contracts = await contractPageIds();
        const usecaseFns = await readUsecaseFunctions();
        let saved = 0;
        for (const owner of scan.owners) {
            const ownerId = owner.id;
            if (!ownerId)
                continue;
            // Only OPERATIONS are BFF command owners. Workflows are pure orchestration — no controller/command.
            if (owner.kind !== 'operation')
                continue;
            const routePageId = owner.pageId || ownerId;
            let outputSource = contracts.has(routePageId) ? 'contract' : 'usecase';
            // COHERENCE (item 3): bind handlers to the usecase's REAL exported functions read from the
            // generated defs — never an assumed name. This prevents the controller from importing a function
            // the usecase never produced (the orderFlow-class break). Fallback to the ownerId only if the defs
            // are missing/unparsed.
            const fns = usecaseFns.get(ownerId) || [];
            const handlers = [];
            const routes = [];
            if (fns.length > 1) {
                // A usecase exposing several functions -> one command/route per function (1:1 function<->command).
                for (const fn of fns) {
                    const handlerName = `${module}${capitalize(fn.functionName)}Handler`;
                    handlers.push({
                        handlerName,
                        command: fn.functionName,
                        usecaseRef: fn.functionName,
                        inputTypeName: fn.inputTypeName,
                        kind: fn.kind || owner.opKind || 'command',
                        inputContract: owner.inputs,
                        contextResolution: owner.contextResolution,
                        accessPattern: owner.accessPattern,
                    });
                    routes.push({ key: `${module}.${routePageId}.${fn.functionName}`, handlerName });
                }
                // L4 is the source of truth for the BFF contract: the canonical bffName route MUST
                // also exist (the l2 contract calls it). Emit a dispatcher handler that selects the
                // usecase function from the provided params (see httpController.md, kind 'dispatcher').
                const canonicalKey = owner.bffName || `${module}.${routePageId}.${owner.commandName || ownerId}`;
                if (!routes.some(r => r.key === canonicalKey)) {
                    const dispatcherName = `${module}${capitalize(owner.commandName || ownerId)}Handler`;
                    handlers.push({
                        handlerName: dispatcherName,
                        command: owner.commandName || ownerId,
                        usecaseRef: fns.map(f => f.functionName).join(' | '),
                        kind: 'dispatcher',
                        inputContract: owner.inputs,
                        contextResolution: owner.contextResolution,
                        accessPattern: owner.accessPattern,
                    });
                    routes.push({ key: canonicalKey, handlerName: dispatcherName });
                }
            }
            else {
                const fn = fns[0];
                const handlerName = `${module}${capitalize(ownerId)}Handler`;
                const routeKey = owner.bffName || `${module}.${routePageId}.${owner.commandName || ownerId}`;
                handlers.push({
                    handlerName,
                    command: owner.commandName || ownerId,
                    usecaseRef: fn?.functionName || ownerId,
                    inputTypeName: fn?.inputTypeName,
                    kind: fn?.kind || owner.opKind || 'command',
                    inputContract: owner.inputs,
                    contextResolution: owner.contextResolution,
                    accessPattern: owner.accessPattern,
                });
                routes.push({ key: routeKey, handlerName });
            }
            // Item 5: for a single-function operation, emit the boundary DTO and anchor the wire shape on it.
            // The controller then returns ok(toDto(result)); the frontend copies responseShape by routine key.
            // Multi-function/dispatcher owners keep the legacy path (no DTO) — best-effort, flagged.
            const soleFn = fns.length <= 1 ? fns[0] : undefined;
            const responseShape = soleFn ? buildResponseShape(soleFn.output) : undefined;
            const dtoRefs = [];
            let dtoMeta = {};
            if (soleFn?.outputTypeName) {
                await saveGeneratedTs(mls.actualProject || 0, 1, `${module}/${HTTP_DTO_FOLDER_SUFFIX}`, lowerFirst(ownerId), renderDtoTs(module, ownerId, soleFn.outputTypeName));
                outputSource = 'dto';
                dtoRefs.push(dtsRef(dtoFileInfo(module, ownerId)));
                dtoMeta = { dtoTypeName: `${capitalize(ownerId)}ResponseDto`, dtoModulePath: `_${mls.actualProject || 0}_/l1/${module}/${HTTP_DTO_FOLDER_SUFFIX}/${lowerFirst(ownerId)}.js`, usecaseOutputTypeName: soleFn.outputTypeName };
            }
            const data = {
                pageId: routePageId,
                controllerName: `${capitalize(ownerId)}Controller`,
                ownerKind: owner.kind, // operation (workflows are skipped)
                outputSource,
                ...dtoMeta,
                ...(responseShape ? { responseShape } : {}),
                handlers,
                routes,
            };
            const fi = httpControllerFileInfo(module, ownerId);
            const dependsFiles = [dtsRef(usecaseFileInfo(module, ownerId)), ...dtoRefs];
            // Legacy contract-mapping path only when no DTO was emitted (DTO now owns the wire shape).
            if (outputSource === 'contract' && contracts.has(routePageId))
                dependsFiles.push(`_${mls.actualProject || 0}_/l2/${module}/web/contracts/${routePageId}.ts`);
            const pipeline = [buildPipelineItem(lowerFirst(ownerId), 'httpController', fi, dependsFiles, layerSkills('httpController.md'))];
            await saveDefs(fi, `${lowerFirst(ownerId)}Controller`, buildArtifact('httpController', ownerId, module, AGENT_NAME, data), pipeline);
            saved++;
        }
        // /rebuild defs stops at the .defs.ts (no .ts materialization): skip cb-materialize, go to cb-gen-seeds.
        const defsOnly = readCliCommand(context) === 'rebuild-defs';
        const next = defsOnly
            ? enqueueNext(context, parentStep, step, 'cb-gen-seeds', 'agentCbSeeds', 'Gerar seeds', {})
            : enqueueNext(context, parentStep, step, 'cb-materialize', 'agentCbMaterialize', 'Materializar .defs.ts -> .ts', {});
        return [
            next,
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Generated ${saved} controller(s) from l4${defsOnly ? ' (defs-only: .ts skipped)' : ''}.`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
