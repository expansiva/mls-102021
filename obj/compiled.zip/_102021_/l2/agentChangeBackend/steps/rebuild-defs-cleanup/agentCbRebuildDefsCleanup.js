/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/rebuild-defs-cleanup/agentCbRebuildDefsCleanup.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { deleteFile } from '/_102027_/l2/libStor.js';
import { enqueueNext, createUpdateStatusIntent, logPrefix } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
const AGENT_NAME = 'agentCbRebuildDefsCleanup';
const MAX_TRACE_PATHS = 60;
// Everything under l1/<module>/ that is NOT the .defs.ts source of truth is a derived materialization.
const DERIVED_EXTENSIONS = new Set(['.ts', '.test.ts', '.d.ts']);
export function createAgent() {
    return {
        agentName: AGENT_NAME,
        agentProject: 102021,
        agentFolder: 'agentChangeBackend/steps/rebuild-defs-cleanup',
        agentDescription: 'Soft-delete derived l1 .ts after a /rebuild defs, keeping only .defs.ts',
        visibility: 'private',
        beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const { modules } = parseArgs(step.prompt);
        const project = mls.actualProject || 0;
        const deleted = [];
        for (const file of Object.values(mls.stor.files)) {
            if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
                continue;
            const extension = String(file.extension || '');
            if (!DERIVED_EXTENSIONS.has(extension))
                continue; // keep .defs.ts (the source of truth)
            const folder = String(file.folder || '');
            if (!isGeneratedBackendFolder(folder, modules))
                continue;
            await deleteFile(file);
            deleted.push(`_${project}_/l1/${folder}/${file.shortName}${extension}`);
        }
        const trace = `rebuild-defs: 0 materializados, ${deleted.length} .ts soft-deletados` +
            (deleted.length === 0 ? ' (nada derivado a remover)' : `:\n${summarize(deleted)}`);
        return [
            enqueueNext(context, parentStep, step, 'cb-finalize', 'agentCbFinalizeStatus', 'Finalizar status (defs-only)', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', trace),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${message}`);
        // Best-effort: a cleanup failure must not fail the whole rebuild-defs tree — the defs are already
        // regenerated and the stale .ts are recoverable and re-materializable. Still advance to finalize.
        return [
            enqueueNext(context, parentStep, step, 'cb-finalize', 'agentCbFinalizeStatus', 'Finalizar status (defs-only)', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `REBUILD-DEFS-CLEANUP-SKIPPED: ${message}`),
        ];
    }
}
// Backend generated l1 code lives under `<module>/layer_1_external|layer_2_application|layer_3_domain/…`.
// Scope the sweep to the run's modules so a rebuild-defs of one module never touches another.
export function isGeneratedBackendFolder(folder, modules) {
    return modules.some(module => !!module && (folder === module || folder.startsWith(`${module}/`)));
}
function summarize(paths) {
    if (paths.length <= MAX_TRACE_PATHS)
        return paths.join('\n');
    return `${paths.slice(0, MAX_TRACE_PATHS).join('\n')}\n…(+${paths.length - MAX_TRACE_PATHS} more)`;
}
function parseArgs(prompt) {
    const parsed = prompt ? JSON.parse(prompt) : {};
    const modules = Array.isArray(parsed.modules)
        ? parsed.modules.filter((value) => typeof value === 'string' && value.length > 0)
        : [];
    return { modules };
}
