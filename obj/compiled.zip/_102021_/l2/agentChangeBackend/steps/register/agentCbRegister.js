/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/register/agentCbRegister.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNextInPhase, createUpdateStatusIntent, isRecord, capitalize, logPrefix } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { recordFailedCbRun } from '/_102021_/l2/agentChangeBackend/helpers/cbPipelineRun.js';
import { saveGeneratedTs } from '/_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo.js';
import { extractSeedSkippedFromSource } from '/_102021_/l2/agentChangeBackend/helpers/cbSeedsCore.js';
import { formatDiscardedOrphans, pruneOrphanL5BackendModules } from '/_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig.js';
export function createAgent() {
    return { agentName: 'agentCbRegister', agentProject: 102021, agentFolder: 'agentChangeBackend/steps/register', agentDescription: 'Deterministic backend registration (l5 config + composition root; routes/tables discovered at runtime)', visibility: 'private', beforePromptStep };
}
/** First `export const … = {…} as const;` block — the artifact data of an l1 defs file. */
function parseArtifactData(content) {
    const s = content.indexOf('= ');
    const e = content.indexOf(' as const;');
    if (s === -1 || e <= s)
        return undefined;
    try {
        const o = JSON.parse(content.slice(s + 2, e));
        if (!isRecord(o))
            return undefined;
        return isRecord(o.data) ? o.data : o;
    }
    catch {
        return undefined;
    }
}
/** Composition root: bind every repositoryAdapter defs of the module to its port name (entityId). */
async function writeRegisterRepositories(project, moduleName) {
    const persistenceFolder = `${moduleName}/layer_1_external/adapters/persistence`;
    const adapters = [];
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || String(file.folder || '') !== persistenceFolder)
            continue;
        const data = parseArtifactData(String(await file.getContent()));
        const entityId = data && typeof data.entityId === 'string' ? String(data.entityId) : '';
        const shortName = String(file.shortName || '');
        // Identify adapter defs by the DETERMINISTIC file name (`<entity>RepositoryAdapter`), NOT the
        // LLM-authored `className` (which drifts, e.g. `PaymentRepository` vs `PaymentRepositoryAdapter`, and
        // silently produced an EMPTY composition root -> resolveRepository 500 at runtime).
        if (!shortName.endsWith('RepositoryAdapter') || !entityId)
            continue;
        adapters.push({
            portName: entityId,
            // repositoryAdapter.md ALWAYS exports `create<Entity>RepositoryAdapter` (independent of the def's
            // className) — derive the factory from the entityId so the import matches the real export.
            factoryName: `create${capitalize(entityId)}RepositoryAdapter`,
            importPath: `/_${project}_/l1/${persistenceFolder}/${shortName}.js`,
        });
    }
    if (adapters.length === 0)
        return 'composition root skipped (no repository adapters)';
    adapters.sort((a, b) => a.portName.localeCompare(b.portName));
    const content = [
        `/// <mls fileReference="_${project}_/l1/${persistenceFolder}/registerRepositories.ts" enhancement="_blank"/>`,
        '',
        '// Composition root — generated deterministically by agentCbRegister; do not edit by hand.',
        '// The 102034 moduleRegistry imports this file through the persistenceModules[].tableDefsDir',
        '// config link before loading the module controllers, so usecases can resolveRepository().',
        "import { registerRepository } from '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';",
        ...adapters.map((a) => `import { ${a.factoryName} } from '${a.importPath}';`),
        '',
        ...adapters.map((a) => `registerRepository('${a.portName}', ${a.factoryName});`),
        '',
    ].join('\n');
    const saved = await saveGeneratedTs(project, 1, persistenceFolder, 'registerRepositories', content);
    if (!saved.ok)
        return 'composition root write failed';
    if (saved.compileErrors.length > 0)
        return `composition root written with compile errors: ${saved.compileErrors[0]}`;
    return `composition root written (${adapters.length} repository port(s))`;
}
/** Collect the route keys the generated controllers expose (their exported `routes[].key`). */
async function collectRouteKeys(project) {
    const keys = new Set();
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
            continue;
        if (file.extension !== '.defs.ts' || !String(file.folder || '').endsWith('/adapters/http/controllers'))
            continue;
        const data = parseArtifactData(String(await file.getContent()));
        const routes = data && Array.isArray(data.routes) ? data.routes : [];
        for (const r of routes) {
            const k = String(r?.key || '');
            if (k)
                keys.add(k);
        }
    }
    return [...keys].sort();
}
/** Seed coverage published by gen-seeds, read back from the generated seeds.ts. Absent/complete -> null. */
async function readSeedSkipped(project, moduleName) {
    try {
        const fileInfo = { project, level: 1, folder: `${moduleName}/layer_1_external/adapters/persistence`, shortName: 'seeds', extension: '.ts' };
        const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
        if (!file || file.status === 'deleted')
            return null;
        return extractSeedSkippedFromSource(String(await file.getContent()));
    }
    catch {
        return null;
    }
}
/** Write the module's backend block into the client-owned l5/project.json (guarded; never blocks). */
async function updateL5BackendConfig(project, moduleName, routeKeys, seedSkipped) {
    const fileInfo = { project, level: 5, folder: '', shortName: 'project', extension: '.json' };
    const key = mls.stor.getKeyToFile(fileInfo);
    const file = mls.stor.files[key];
    if (!file || file.status === 'deleted')
        return 'l5/project.json not found; backend config skipped';
    const cfg = JSON.parse(String(await file.getContent()));
    // Master signature: records who generated the backend and which production master runtime uses.
    if (!isRecord(cfg.masters))
        cfg.masters = {};
    cfg.masters.backend = { masterProject: 102021, agentFolder: 'agentChangeBackend', runtimeProject: 102034 };
    const controllersDir = `./_${project}_/l1/${moduleName}/layer_1_external/adapters/http/controllers`;
    const tableDefsDir = `./_${project}_/l1/${moduleName}/layer_1_external/adapters/persistence`;
    const existingModules = Array.isArray(cfg.modules) ? cfg.modules.filter(isRecord) : [];
    const pruned = pruneOrphanL5BackendModules(existingModules, moduleName, (name) => l1PersistenceExists(project, name));
    cfg.modules = pruned.modules;
    let mod = pruned.modules.find((m) => m.moduleName === moduleName);
    if (!mod) {
        mod = { moduleName };
        pruned.modules.push(mod);
    }
    const backend = { backendControllers: controllersDir, persistence: { tableDefsDir }, routeKeys };
    // seedCoverage: targets that are EMPTY BY DESIGN (a seed wave that never converged). Consumers —
    // notably a test generator — must not assert "at least one row" against these. Omitted entirely when
    // coverage is complete, so its mere presence means "there is a known gap".
    if (seedSkipped)
        backend.seedCoverage = { skippedTables: seedSkipped.tables, skippedMdmEntities: seedSkipped.mdmEntities, reason: seedSkipped.reason };
    mod.backend = backend;
    const content = JSON.stringify(cfg, null, 2);
    file.updatedAt = new Date().toISOString();
    await mls.stor.localStor.setContent(file, { contentType: 'string', content });
    const coverageNote = seedSkipped ? `; seedCoverage gap: tables [${seedSkipped.tables.join(', ') || 'none'}], MDM [${seedSkipped.mdmEntities.join(', ') || 'none'}]` : '';
    return `l5/project.json backend block updated for '${moduleName}' (${routeKeys.length} route(s))${coverageNote}${formatDiscardedOrphans(pruned.discarded)}`;
}
function l1PersistenceExists(project, moduleName) {
    const persistenceFolder = `${moduleName}/layer_1_external/adapters/persistence`;
    for (const file of Object.values(mls.stor.files)) {
        if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
            continue;
        const folder = String(file.folder || '');
        if (folder === persistenceFolder || folder.startsWith(`${persistenceFolder}/`))
            return true;
    }
    return false;
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const project = mls.actualProject || 0;
        const scan = await readBackendScan(['toCreate', 'inProgress'], context);
        const moduleName = scan.moduleNames[0] || 'unknown';
        const moduleTables = scan.aggregates.map(a => a.rootEntity);
        let compositionMsg = 'composition root skipped';
        try {
            compositionMsg = await writeRegisterRepositories(project, moduleName);
        }
        catch (rootError) {
            // Non-blocking: validateAll still runs and surfaces the missing registrations.
            compositionMsg = `composition root failed: ${rootError instanceof Error ? rootError.message : String(rootError)}`;
            console.warn(`${logPrefix(agent)} ${compositionMsg}`);
        }
        let configMsg = 'l5 config skipped';
        try {
            // Route keys: v1 controllers expose them in their .defs.ts (collectRouteKeys); v2 controllers are
            // deterministic .ts with no defs, so their routes come straight from the workspace bffCalls
            // (route = <module>.<workspaceId>.<bffId>). backendControllers stays the CONTROLLERS DIR — the
            // 102034 host discovers every workspace controller by directory, so 1-file-per-workspace needs no
            // change there; only the informational routeKeys list must include the v2 routes.
            const v1RouteKeys = await collectRouteKeys(project);
            const v2RouteKeys = scan.workspaces
                .filter(w => w.moduleName === moduleName)
                .flatMap(w => w.bffCalls.map(b => b.route))
                .filter(Boolean);
            const routeKeys = [...new Set([...v1RouteKeys, ...v2RouteKeys])].sort();
            configMsg = await updateL5BackendConfig(project, moduleName, routeKeys, await readSeedSkipped(project, moduleName));
        }
        catch (cfgError) {
            // Non-blocking: a config write failure must not abort the run.
            configMsg = `l5 config update failed: ${cfgError instanceof Error ? cfgError.message : String(cfgError)}`;
            console.warn(`${logPrefix(agent)} ${configMsg}`);
        }
        return [
            enqueueNextInPhase(context, step, 'finalization', 'cb-validate-all', 'agentCbValidateAll', 'Validar artefatos l1', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `Registered ${moduleTables.length} module table(s). ${compositionMsg}. ${configMsg}`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        await recordFailedCbRun({ longMemory: context.task?.iaCompressed?.longMemory, reason: message });
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
