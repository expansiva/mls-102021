/// <mls fileReference="_102021_/l2/agentChangeBackend/steps/phase/agentCbPhase.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { createAddStepIntent, createAgentStepPayload, createUpdateStatusIntent, isRecord, readString, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
const AGENT_NAME = 'agentCbPhase';
export function createAgent() {
    return {
        agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend/steps/phase',
        agentDescription: 'Groups the steps of one phase of the run; opens the phase with its first step inside',
        visibility: 'private', beforePromptStep,
    };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const first = firstStepOf(step);
        if (!first)
            throw new Error('phase step without a first step to open');
        const child = createAgentStepPayload(first.planId, first.agentName, first.stepTitle, first.args, [], 'sequential', 'waiting_human_input');
        if (first.onFailure)
            child.onFailure = first.onFailure;
        return [
            // The child hangs from THIS step: that is what makes the phase a branch, and what keeps the
            // phase open (deferred completion) until the whole branch finishes.
            createAddStepIntent(context, step, child),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `fase iniciada em ${first.planId}`),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${message}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
function firstStepOf(step) {
    try {
        const parsed = JSON.parse(String(step.prompt || '{}'));
        const first = isRecord(parsed) && isRecord(parsed.first) ? parsed.first : null;
        if (!first)
            return null;
        const planId = readString(first.planId);
        const agentName = readString(first.agentName);
        if (!planId || !agentName)
            return null;
        return {
            planId,
            agentName,
            stepTitle: readString(first.stepTitle) || planId,
            args: isRecord(first.args) ? first.args : { planId },
            ...(readString(first.onFailure) ? { onFailure: readString(first.onFailure) } : {}),
        };
    }
    catch {
        return null;
    }
}
