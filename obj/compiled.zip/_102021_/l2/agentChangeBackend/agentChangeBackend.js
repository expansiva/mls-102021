/// <mls fileReference="_102021_/l2/agentChangeBackend/agentChangeBackend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setTodoBackendStatus, createAgentStepPayload, createUpdateStatusIntent, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
const ALL_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'inProgress', 'done'];
export function createAgent() {
    return {
        agentName: 'agentChangeBackend',
        agentProject: 102021,
        agentFolder: 'agentChangeBackend',
        agentDescription: 'Stage 3 backend reconciler (v1, hexagonal). CLI: /rebuild all | /run | /help.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
/** Parse the user prompt into a CLI command. Lenient: mention stripped, keyword matched anywhere.
 * Empty (bare @@changeBackend) is the autonomous default -> 'run' (scan toCreate + materialize stale). */
function parseCommand(raw) {
    const t = normalizePrompt(raw);
    if (!t)
        return 'run';
    if (/\brebuild\b/.test(t))
        return /\bdefs\b/.test(t) ? 'rebuild-defs' : 'rebuild-all';
    if (/\brun\b/.test(t))
        return 'run';
    return 'help';
}
function normalizePrompt(raw) {
    return String(raw || '')
        .trim()
        .replace(/@@?[a-z0-9_]*changebackend\s*/i, '')
        .replace(/\s+/g, ' ')
        .toLowerCase();
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const raw = userPrompt || context.message.content || '';
    const cmd = parseCommand(raw);
    // The root agent step is created WITHOUT calling the model (skipRootLLM); the chain is added below.
    const addMessageAI = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentChangeBackend deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: normalizePrompt(raw) || 'agentChangeBackend' },
            ],
            taskTitle: 'agentChangeBackend',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeBackend', flowName: 'agentChangeBackend', version: '1', cliCommand: cmd },
        },
    };
    if (cmd === 'help') {
        return [addMessageAI, createBootstrapAddStepIntent(context, createHelpStep())];
    }
    if (cmd === 'rebuild-all' || cmd === 'rebuild-defs') {
        let reset = 0;
        try {
            const scan = await readBackendScan(ALL_STATUSES);
            for (const owner of scan.owners) {
                if (await setTodoBackendStatus(owner, 'toCreate'))
                    reset++;
            }
        }
        catch (e) {
            console.error(`${logPrefix(agent)} ${cmd} reset failed: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    const scanStep = createAgentStepPayload('cb-scan', 'agentCbScanCreateOwners', 'Scan todoBackend (status = toCreate)', { planId: 'cb-scan' }, [], 'sequential', 'waiting_human_input');
    return [addMessageAI, createBootstrapAddStepIntent(context, scanStep)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
/** Add a step under the root (stepId 1), created by the skipRootLLM bootstrap above. */
function createBootstrapAddStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function createHelpStep() {
    return {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Help',
        result: HELP,
        planning: { planId: 'help', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
const HELP = `agentChangeBackend — CLI

Uso: @@changeBackend <comando>

Comandos:
- /rebuild all  : reseta todoBackend de TODOS os owners para toCreate e regenera o backend — defs E materialização dos .ts (arquivos sobrescritos in place; sem deletar).
- /rebuild defs : reseta TODOS os owners para toCreate e regenera SOMENTE os .defs.ts (NÃO materializa os .ts).
- /run          : gera os owners pendentes (todoBackend = toCreate | inProgress) sem resetar; materializa os .ts faltando/desatualizados.
- (sem comando) : igual ao /run — varre o todoBackend por owners toCreate e materializa os .ts antigos/ausentes.
- /help         : mostra esta ajuda.

Qualquer outro comando (texto não reconhecido) mostra esta ajuda.`;
