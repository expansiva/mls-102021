/// <mls fileReference="_102021_/l2/agentChangeBackend/agentChangeBackend.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, setTodoBackendStatus, createAgentStepPayload, createUpdateStatusIntent, logPrefix, } from '/_102021_/l2/agentChangeBackend/helpers/cbShared.js';
import { parseCli, normalizePrompt } from '/_102021_/l2/agentChangeBackend/helpers/cbCli.js';
const ALL_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'inProgress', 'done'];
export function createAgent() {
    return {
        agentName: 'agentChangeBackend',
        agentProject: 102021,
        agentFolder: 'agentChangeBackend',
        agentDescription: 'Stage 3 backend reconciler (v1, hexagonal). CLI: /rebuild all | /run | /help.',
        visibility: 'public',
        beforePromptImplicit,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const raw = userPrompt || context.message.content || '';
    const { kind: cmd, module: requestedModule } = parseCli(raw);
    // Resolve the ONE module this run targets, and (for rebuild) reset only that module's owners so the
    // task stays small. No explicit module -> the first (sorted) module with owners; readBackendScan
    // (given the override) already scopes owners to it. The resolved module is persisted in longMemory
    // so every downstream step (which reads it via readTargetModule) scopes to the SAME module.
    let targetModule = requestedModule;
    if (cmd === 'rebuild-all' || cmd === 'rebuild-defs') {
        let reset = 0;
        try {
            const scan = await readBackendScan(ALL_STATUSES, undefined, requestedModule);
            targetModule = scan.moduleNames[0] || requestedModule;
            for (const owner of scan.owners) {
                if (await setTodoBackendStatus(owner, 'toCreate'))
                    reset++;
            }
        }
        catch (e) {
            console.error(`${logPrefix(agent)} ${cmd} reset failed: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    else if (cmd === 'run' || cmd === 'rebuild-seeds') {
        // rebuild-seeds regenerates ONLY seeds.ts of an already-built module — it never resets owners.
        // Resolve the target module up front (explicit, else the first module with pending owners) so the
        // task title is correct AT CREATION. Renaming later via the update-status intent's newTaskTitle is
        // best-effort and depends on collab-messages forwarding it; the bootstrap taskTitle path is the
        // reliable one. Never blocks the run.
        try {
            const scan = await readBackendScan(['toCreate', 'inProgress'], undefined, requestedModule);
            targetModule = scan.moduleNames[0] || requestedModule;
        }
        catch (e) {
            console.error(`${logPrefix(agent)} run module resolve failed: ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    // Task title reflects the ONE module this run targets (backend). Set here, at creation, via the
    // deployed taskTitle path — not the mid-run newTaskTitle intent.
    const taskTitle = targetModule ? `${targetModule} - backend` : 'agentChangeBackend';
    // The root agent step is created WITHOUT calling the model (skipRootLLM); the chain is added below.
    const addMessageAI = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentChangeBackend deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: normalizePrompt(raw) || 'agentChangeBackend' },
            ],
            taskTitle,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'agentChangeBackend', flowName: 'agentChangeBackend', version: '1', cliCommand: cmd, targetModule },
        },
    };
    if (cmd === 'help') {
        return [addMessageAI, createBootstrapAddStepIntent(context, createHelpStep())];
    }
    const scanStep = createAgentStepPayload('cb-scan', 'agentCbScanCreateOwners', 'Scan todoBackend (status = toCreate)', { planId: 'cb-scan' }, [], 'sequential', 'waiting_human_input');
    return [addMessageAI, createBootstrapAddStepIntent(context, scanStep)];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!context.task)
        throw new Error(`[${agent.agentName}] task invalid`);
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
/** Add a step under the root (stepId 1), created by the skipRootLLM bootstrap above. */
function createBootstrapAddStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function createHelpStep() {
    return {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Help',
        result: HELP,
        planning: { planId: 'help', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
const HELP = `agentChangeBackend — CLI

Uso: @@changeBackend <comando> [módulo]

Uma execução processa SEMPRE um único módulo (para a task não ficar grande). Sem [módulo], assume
o primeiro módulo (ordem alfabética) com pendências; com [módulo], processa só aquele. "all" é
palavra do comando, nunca nome de módulo.

Comandos:
- /rebuild all [módulo]  : reseta os owners do módulo-alvo para toCreate e regenera o backend — defs E materialização dos .ts (arquivos sobrescritos in place; sem deletar).
- /rebuild defs [módulo] : reseta os owners do módulo-alvo para toCreate e regenera SOMENTE os .defs.ts (NÃO materializa os .ts).
- /rebuild seeds [módulo]: regenera SOMENTE o seeds.ts (+ assets) do módulo já construído e termina — não reseta owners, não toca domínio/ports/tabelas/usecases/controllers. Use após ajustar dados/regra de seed sem refazer todo o backend.
- /run [módulo]          : gera os owners pendentes (todoBackend = toCreate | inProgress) sem resetar; materializa os .ts faltando/desatualizados.
- <módulo>               : igual ao /run daquele módulo (ex: @@changeBackend cafeFlow).
- (sem comando)          : igual ao /run — varre o todoBackend e continua o primeiro módulo pendente.
- /help                  : mostra esta ajuda.

Qualquer outro texto sem comando e sem módulo reconhecível mostra esta ajuda.`;
