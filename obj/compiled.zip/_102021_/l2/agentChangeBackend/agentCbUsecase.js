/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbUsecase.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, createPromptReadyIntent, createUpdateStatusIntent, createAgentStepPayload, createAddStepIntent, createParallelStepIntent, extractPlannerOutput, plannerConfig, createPlannerToolSchema, saveAgentTrace, saveDefs, buildArtifact, buildPipelineItem, usecaseFileInfo, repositoryPortFileInfo, domainEntityFileInfo, dtsRef, layerSkills, readString, readStringArray, lowerFirst, logPrefix, } from '/_102021_/l2/agentChangeBackend/cbShared.js';
import { usecaseResultSchema } from '/_102021_/l2/agentChangeBackend/cbSchemas.js';
import { getComponentRepair, clearComponentRepair, recordComponentFailure, buildRepairPromptSection } from '/_102021_/l2/agentChangeBackend/cbRepair.js';
const AGENT_NAME = 'agentCbUsecase';
const TOOL_NAME = 'submitUsecase';
const FANOUT_PLAN_ID = 'cb-usecase-fanout';
const toolSchema = createPlannerToolSchema(TOOL_NAME, 'Submit the usecase.', usecaseResultSchema);
export function createAgent() {
    return { agentName: AGENT_NAME, agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Generate application usecases (parallel_dynamic worker per owner; controller joins)', visibility: 'private', beforePromptStep, afterPromptStep };
}
// The owner id of a WORKER invocation arrives in hook.args (a bare id); the DISPATCHER step carries a
// JSON prompt ({planId:...}) and no bare id. Resolve from args first, then step.prompt as a fallback.
function workerOwnerId(args, step) {
    const a = (args ?? '').trim();
    if (a && !a.startsWith('{'))
        return a;
    const p = String(step?.prompt ?? '').trim();
    return p && !p.startsWith('{') ? p : '';
}
// Shared maps derived from the scan (aggregate roots, mdm ids, embedded child -> parent root, events).
function deriveMaps(scan) {
    const roots = new Set(scan.aggregates.map(a => a.rootEntity));
    const mdmIds = new Set(scan.entities.filter(e => e.kind === 'mdm').map(e => e.entityId)); // master data: read by id, no port
    const childToRoot = new Map();
    for (const a of scan.aggregates)
        for (const m of a.embeddedMembers)
            childToRoot.set(m, a.rootEntity);
    const byId = new Map(scan.entities.map(e => [e.entityId, e]));
    // ownerEntity -> events the owner's usecases must emit when they mutate that aggregate.
    const eventsByOwner = new Map();
    for (const ev of scan.events) {
        const list = eventsByOwner.get(ev.ownerEntity) || [];
        list.push(ev);
        eventsByOwner.set(ev.ownerEntity, list);
    }
    return { roots, mdmIds, childToRoot, byId, eventsByOwner };
}
// The single-owner item sent to the LLM (explicit ports/mdmRefs + entity fields to shape input/output).
function buildOwnerItem(o, maps) {
    const { roots, mdmIds, childToRoot, byId, eventsByOwner } = maps;
    const fieldsOf = (id) => (byId.get(id)?.fields || []).map((f) => ({ fieldId: f.fieldId, type: f.type, required: f.required, ...(f.enum ? { enum: f.enum } : {}) }));
    const rawRefs = [...new Set([o.entity, ...o.reads, ...o.writes].filter(Boolean))]; // keep children + mdm for fields
    const portRefs = [...new Set(rawRefs.map(id => childToRoot.get(id) ?? id))]; // children -> parent root
    // Events the owner must emit: those owned by an aggregate this usecase writes (entity + writes).
    const mutated = new Set([o.entity, ...o.writes].filter(Boolean).map(id => childToRoot.get(id) ?? id));
    const eventWrites = [...new Set([o.entity, ...o.writes].filter(Boolean))]
        .flatMap(id => eventsByOwner.get(id) || [])
        .concat([...mutated].flatMap(id => eventsByOwner.get(id) || []))
        .filter((ev, i, arr) => arr.findIndex(x => x.entityId === ev.entityId) === i)
        .map(ev => ({ entityId: ev.entityId, owner: ev.ownerEntity, purpose: ev.purpose, persisted: ev.persisted, port: ev.persisted ? ev.entityId : null }));
    return {
        usecaseId: o.id,
        ownerKind: o.kind,
        opKind: o.opKind,
        entity: o.entity,
        parentAggregate: childToRoot.get(o.entity) ?? o.entity,
        reads: o.reads,
        writes: o.writes,
        rulesApplied: o.rulesApplied,
        accessPattern: o.accessPattern ?? null,
        inputs: o.inputs,
        contextResolution: o.contextResolution,
        acceptanceAssertions: o.acceptanceAssertions,
        ports: portRefs.filter(id => roots.has(id) && !mdmIds.has(id)),
        mdmRefs: rawRefs.filter(id => mdmIds.has(id)),
        eventWrites, // append-only events to emit (persisted -> via its port; reaction -> outbox)
        entityFields: Object.fromEntries(rawRefs.map(id => [id, fieldsOf(id)])),
    };
}
// ── beforePromptStep: dispatch (fan-out) or worker (one usecase) ───────────────
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const ownerId = workerOwnerId(args, step);
    return ownerId
        ? worker(agent, context, parentStep, step, hookSequential, ownerId)
        : dispatch(agent, context, parentStep, step, hookSequential);
}
// DISPATCHER (deterministic, no LLM): ONE parallel_dynamic step whose args queue is the owner ids
// (runtime pool of 5, payloads discarded as each finishes) + the controller JOIN on that parent.
async function dispatch(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        // Only OPERATIONS are BFF command owners with their own usecase. Workflows are pure L4
        // orchestration/composition realized by their member operations — they generate no usecase,
        // controller or command (their status is still finalized to done downstream).
        const ownerIds = scan.owners.filter(o => o.kind === 'operation').map(o => o.id).filter(Boolean);
        if (!ownerIds.length) {
            return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', 'no operation owners to generate')];
        }
        // stepTitle is used by the runtime as the progress templateTitle ({{completed}}/{{total}}/{{failed}}
        // are substituted live as workers finish), e.g. "Gerar usecases 27/27, falhas 0".
        const intents = [
            createParallelStepIntent(context, parentStep, FANOUT_PLAN_ID, AGENT_NAME, 'Gerar usecases {{completed}}/{{total}}, falhas {{failed}}', ownerIds, [], 10),
        ];
        // JUDGE joins on the single parallel parent (runs after every worker finished): adversarial
        // critique of the saved usecase defs vs the L4 contract, routing error findings back to these
        // workers (repair loop) before controllers/materialization. The judge enqueues cb-gen-http.
        const jstep = createAgentStepPayload('cb-judge', 'agentCbJudge', 'Juiz LLM (usecases vs L4)', { planId: 'cb-judge', judgeRun: 1 }, [FANOUT_PLAN_ID], 'sequential', 'waiting_dependency');
        intents.push(createAddStepIntent(context, parentStep, jstep));
        intents.push(createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `fan-out ${ownerIds.length} usecase(s) (parallel_dynamic)`));
        return intents;
    }
    catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        console.error(`${logPrefix(agent)} ${msg}`);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', msg)];
    }
}
// WORKER: build the prompt for ONE owner and ask the model for that single usecase.
async function worker(agent, context, parentStep, step, hookSequential, ownerId) {
    const scan = await readBackendScan(['toCreate', 'inProgress']);
    const owner = scan.owners.find(o => o.id === ownerId);
    // NB: worker children never return 'failed' (a failed step does not satisfy dependsOn and would
    // stall the fan-out join); the judge/validate-all report what is missing.
    if (!owner)
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `[worker-error] owner not found: ${ownerId}`)];
    if (owner.kind !== 'operation')
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', `skip ${ownerId}: workflows generate no usecase`)];
    const item = buildOwnerItem(owner, deriveMaps(scan));
    let human = `## Owner -> usecase (entity fields included so you can declare explicit input/output)\n${JSON.stringify(item, null, 2)}\n\nReturn ONE usecase with functions[] — each function has explicit input[] and output[] FIELDS. accessPattern decides list/get/lookup/commandInput. inputs declares the public/request inputs. contextResolution declares values resolved from runtime context/defaults/previous navigation; do not turn systemDefault/currentWorkspace/actorSession/businessContext resolutions into required user input. A usecase MAY expose several functions with different IO.`;
    // REPAIR: when the judge (or a previous failure) left findings for this owner, feed them back so the
    // model FIXES the exact defects instead of regenerating blindly (repair loop, cbRepair.ts).
    const repair = await getComponentRepair(`usecase-defs:${ownerId}`);
    if (repair && repair.findings.length)
        human += `\n\n${buildRepairPromptSection(repair)}`;
    // prompt_ready args MUST equal the parallel child's queued hook args (the ownerId) so the runtime
    // (continueBeforePrompt → findBeforePromptStep by parentStepId+args) matches it. step.prompt is not
    // yet set to the arg on the first beforePromptStep of a parallel child.
    return [createPromptReadyIntent(context, parentStep, hookSequential, ownerId, systemPrompt.split('{{toolName}}').join(TOOL_NAME), human, toolSchema, TOOL_NAME)];
}
// ── afterPromptStep (worker only): save the one usecase .defs.ts ───────────────
async function afterPromptStep(agent, context, parentStep, step, hookSequential, args) {
    let status = 'completed';
    let trace;
    try {
        const payload = step.interaction?.payload?.[0];
        if (!payload)
            throw new Error('missing payload');
        const out = extractPlannerOutput(payload, plannerConfig(TOOL_NAME));
        const result = out.result;
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const module = scan.moduleNames[0] || 'unknown';
        const { roots, mdmIds, childToRoot } = deriveMaps(scan);
        const usecaseId = readString(result?.usecaseId) || workerOwnerId(args, step);
        if (!usecaseId)
            throw new Error('missing usecaseId');
        // Final ports = model's ports ∪ deterministic ports (owner entity+writes, children -> parent root),
        // with mdm removed (master data is read by id via 102034, not through a port).
        const owner = scan.owners.find(o => o.id === usecaseId);
        const ownerRefs = owner ? [owner.entity, ...owner.reads, ...owner.writes].filter(Boolean) : [];
        const detPorts = [...new Set(ownerRefs.map(id => childToRoot.get(id) ?? id))].filter(id => roots.has(id) && !mdmIds.has(id));
        // Trust only REAL aggregate roots: the model sometimes invents port names ("dailyShiftPort",
        // "recipePort", "productionTicket"). Keep model ports only if they are real roots, union with the
        // deterministic ones (derived from the owner's entities, children resolved to their parent).
        const aggPorts = [...new Set([...readStringArray(result?.ports), ...detPorts])].filter(id => roots.has(id) && !mdmIds.has(id));
        // Persisted event ports the owner emits (own real ports too) — append-only writes within the txn.
        const mutated = new Set(ownerRefs.map(id => childToRoot.get(id) ?? id));
        const eventPortIds = scan.events
            .filter(ev => ev.persisted && (ownerRefs.includes(ev.ownerEntity) || mutated.has(ev.ownerEntity)))
            .map(ev => ev.entityId);
        const ports = [...new Set([...aggPorts, ...eventPortIds])];
        result.ports = ports;
        result.mdmRefs = [...new Set(ownerRefs.filter(id => mdmIds.has(id)))];
        for (const fn of Array.isArray(result?.functions) ? result.functions : []) {
            fn.ports = readStringArray(fn?.ports).filter((id) => ports.includes(id)); // drop invented ports
        }
        const fi = usecaseFileInfo(module, usecaseId);
        const dependsFiles = [
            ...ports.map(p => dtsRef(repositoryPortFileInfo(module, p))),
            ...ports.map(p => dtsRef(domainEntityFileInfo(module, p))),
        ];
        const pipeline = [buildPipelineItem(lowerFirst(usecaseId), 'applicationUsecase', fi, dependsFiles, layerSkills('applicationUsecase.md'), { rulesApplied: readStringArray(result?.rulesApplied) })];
        await saveDefs(fi, `${lowerFirst(usecaseId)}Usecase`, buildArtifact('usecase', usecaseId, module, AGENT_NAME, result), pipeline);
        if (out.status === 'failed') {
            status = 'failed';
            trace = 'model returned failed';
        }
        else
            await clearComponentRepair(`usecase-defs:${usecaseId}`); // converged: drop the repair record
    }
    catch (error) {
        status = 'failed';
        trace = error instanceof Error ? error.message : String(error);
        // No console output: the trace lands on the step and the finding on cb-repair-state (below).
    }
    if (status === 'failed') {
        // Burn a repair attempt and keep the error as a finding: the judge (cb-judge) detects the missing
        // defs deterministically and re-spawns this worker while the budget lasts (repair loop).
        const failedOwnerId = workerOwnerId(args, step);
        if (failedOwnerId)
            await recordComponentFailure(`usecase-defs:${failedOwnerId}`, [trace || 'usecase generation failed']);
        // ENGINE SEMANTICS (2026-07-04): a FAILED child does NOT satisfy dependsOn — the fan-out join
        // (cb-judge) would wait forever. Complete with a "[repair]" trace instead; the judge routes the
        // repair and the deterministic gates downstream keep blocking what does not converge.
        status = 'completed';
        trace = `[repair] ${trace || 'usecase generation failed'}`;
    }
    await saveAgentTrace(context, AGENT_NAME, step);
    // No enqueueNext here: the controller step was already queued by the dispatcher with a join dependsOn.
    return [createUpdateStatusIntent(context, parentStep, step, hookSequential, status, trace)];
}
const systemPrompt = `
<!-- modelType: codehigh -->
<!-- x-tool-strict: true -->

You are ${AGENT_NAME} (hexagonal layer_2_application/usecases). Generate ONE usecase for the given owner:
it decides WHAT happens — validations, state transitions, orchestration — using the domain + repository
PORTS only (import the port interface, NEVER the concrete adapter; use ctx.data only for a single
transaction wrapper). MDM is accessed only through ctx.mdm. Apply rulesApplied inline.

ports must NOT be empty: use exactly the provided "ports" (already the parent aggregate roots). When the
owner's "entity" is a child embedded in a parent aggregate (its parent is "parentAggregate", different
from "entity"), the operation works through the PARENT port — load the parent, mutate the embedded child
in its collection, save the parent. NEVER invent a child repository. "steps" are guidance, not a
contract: the contract is input/output/ports.

Use the L4 v2 contract directly:
- accessPattern.kind decides the function shape: list returns a collection/projection, getById requires
  the declared keyField, lookup is a short selector, commandInput mutates from the declared payload.
- inputs[] carries a per-field "source". ONLY sources userInput, selectedEntity and routeParam are the
  public BFF/usecase input surface — put THOSE in the function input[] (required ones from
  inputs[].required). EVERY other source is CONTEXT, resolved server-side, and MUST NOT appear in the
  public input[] (the client never sends it): systemDefault, currentWorkspace, actorSession,
  businessContext, activeLifecycleInstance, previousStepOutput, and anything in contextResolution[].
- contextResolution[] is not extra user input. systemDefault values use ctx.clock/ctx.idGenerator;
  currentWorkspace/actorSession/businessContext values come from RequestContext sessionContext metadata
  when available; selectedEntity and routeParam are accepted only when represented by a public input.
- activeLifecycleInstance means "the single OPEN/active instance of a lifecycle aggregate" (e.g. the one
  Shift with status 'open'). RESOLVE it inside the usecase by querying that aggregate's port
  (resolveRepository + list/find by the active status) and use the found id — NEVER declare its id as a
  public input nor require it from the client. If none is open, apply the L4 rule (empty result or the
  documented validation error), never a "missing input" error.
- businessContext.activeCompanyId and businessContext.activeUnitId map to
  ctx.sessionContext.activeCompanyId / ctx.sessionContext.activeUnitId (also mirrored under
  ctx.sessionContext.businessContext). Use them for business scope; never ask the actor to type those
  ids as regular input. Apply such a scope filter ONLY on a field that ACTUALLY exists in the entity/MDM
  model; if the entity declares no scoping field, do NOT invent one (e.g. a fake companyId) — record a
  modeling gap and skip the filter instead of matching against a non-existent field.
- Never require an id manually when the L4 contract says it is resolved by context.

Entities in "mdmRefs" are master data in the shared 102034 store: there is NO port for them - reference
them BY ID (the id is an input field) and read by id via ctx.mdm.entity.get({ mdmId }) or bulk read via
ctx.mdm.collection.getMany({ mdmIds }). For MDM-owned create/update/delete/link/list operations use
ctx.mdm.entity.create/update/inactivate/delete/link/unlink and ctx.mdm.collection.listByType/
relatedOfMany/hydrateMany. For prospect/pre-qualified lead workflows use the explicit prospect facade:
ctx.mdm.prospect.create/get/listByType/update/promoteToEntity. Never use ctx.mdm.entity for prospects.
Module-specific MDM fields live under details.<moduleId>; relationships to other MDM records use
ctx.mdm.entity.link/unlink, not raw related ids embedded in JSON.
Never put an mdmRef in ports, never resolveRepository it, and never use raw
runtime primitives such as ctx.data.mdmDocument, ctx.data.mdmEntityIndex, ctx.data.mdmRelationship,
tx.mdmDocument, tx.mdmEntityIndex or tx.mdmRelationship.
Plural-first: never call ctx.mdm.entity.get inside a loop; collect ids and use ctx.mdm.collection.getMany
or hydrateMany before joining results in memory.

"eventWrites" are append-only events this usecase MUST emit when it mutates the owning aggregate (so the
history is never lost). For each: if persisted (telemetry/audit), build the event record and append it
through its port (use its "port" id — it is already in your ports) INSIDE the same transaction as the
aggregate write; never update or delete it. If NOT persisted (purpose "reaction"), enqueue it on the
platform outbox instead of a local port. Always create the event when the corresponding transition
happens — do NOT leave the record only in memory.

"rulesApplied" are L4 rule ids/prose, not generated modules. There is currently no
layer_3_domain/rules generator. Apply each listed rule inline in this usecase file: use an imported
domain invariant when one exists in dependsFiles, or write a small local helper/function in this file.
NEVER import from layer_3_domain/rules/*, NEVER invent modules such as comboRule or menuItemRules, and
include the rule id in validation error details when the rule blocks the operation.

Return functions[] (usually ONE, named from the operationId; MAY be several with different IO). Each
function declares EXPLICIT fields:
- input[]: { name, type, required, ofEntity? } — the fields the command receives (camelCase). For a
  "create" derive from the entity's writable fields (minus server-generated ids/timestamps); for
  "query"/"view" the filter fields; for "update" id + changed fields.
- output[]: { name, type, ofEntity? } — what the function returns (camelCase). For mutations usually
  the affected aggregate id(s) + status; for queries the projected entity fields.
- inputTypeName/outputTypeName (PascalCase), ports[], rulesApplied[], transactional, steps[].
Top-level: usecaseId, ports (union), rulesApplied. Types: uuid|string|text->string, money|number->
number, boolean, date|datetime->string, {Entity} ref->string. Call "{{toolName}}" with the single
usecase (status/result). No prose.
`;
