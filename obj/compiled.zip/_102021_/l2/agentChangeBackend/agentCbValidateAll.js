/// <mls fileReference="_102021_/l2/agentChangeBackend/agentCbValidateAll.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { readBackendScan, enqueueNext, createUpdateStatusIntent, isRecord, readStringArray, lowerFirst, logPrefix } from '/_102021_/l2/agentChangeBackend/cbShared.js';
// Parse the FIRST `export const ... = {...} as const;` (the artifact). NB: parseDefsSource in cbShared
// uses the LAST ` as const;`, which on an l1 defs (artifact + pipeline) would span both exports and
// fail; here we need only the artifact's data block.
function parseArtifact(content) {
    const s = content.indexOf('= ');
    const e = content.indexOf(' as const;');
    if (s === -1 || e <= s)
        return undefined;
    try {
        const o = JSON.parse(content.slice(s + 2, e));
        return isRecord(o) ? o : undefined;
    }
    catch {
        return undefined;
    }
}
// Module-local l1 imports of a generated .ts: `from '/_<project>_/l1/<folder>/<name>.js'`. Returns the
// tsSet key (`${folder}::${shortName}`) so the caller can check the target was actually generated.
// Cross-project imports (e.g. /_102034_/ platform) and non-l1 imports are ignored on purpose.
function collectL1Imports(content, project) {
    const out = [];
    const re = /from\s+['"]\/_(\d+)_\/l1\/([^'"]+)['"]/g;
    let m;
    while ((m = re.exec(content)) !== null) {
        if (Number(m[1]) !== project)
            continue;
        const path = m[2].replace(/\.(?:d\.ts|ts|js)$/u, '');
        const lastSlash = path.lastIndexOf('/');
        const folder = lastSlash >= 0 ? path.slice(0, lastSlash) : '';
        const shortName = lastSlash >= 0 ? path.slice(lastSlash + 1) : path;
        out.push({ key: `${folder}::${shortName.toLowerCase()}`, target: `_${project}_/l1/${path}` });
    }
    return out;
}
function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
function fieldNameFromRef(value) {
    const raw = String(value ?? '').trim();
    if (!raw)
        return '';
    const parts = raw.split('.');
    return parts[parts.length - 1] || raw;
}
function requiredBoundaryFields(inputContract) {
    const fields = new Set();
    const resolvedSources = new Set(['systemDefault', 'currentWorkspace', 'actorSession']);
    if (!Array.isArray(inputContract))
        return fields;
    for (const input of inputContract) {
        if (!isRecord(input) || input.required !== true)
            continue;
        const source = String(input.source ?? '');
        if (resolvedSources.has(source))
            continue;
        const inputId = fieldNameFromRef(input.inputId);
        const fieldRef = fieldNameFromRef(input.fieldRef);
        if (inputId)
            fields.add(inputId);
        if (fieldRef)
            fields.add(fieldRef);
    }
    return fields;
}
function collectRequiredChecksByHandler(content) {
    const checks = new Map();
    const handlerRe = /export\s+const\s+([A-Za-z0-9_$]+)\s*:\s*BffHandler\s*=\s*async[\s\S]*?=>\s*\{([\s\S]*?)\n\};/g;
    let handlerMatch;
    while ((handlerMatch = handlerRe.exec(content)) !== null) {
        const fields = new Set();
        const body = handlerMatch[2];
        const fieldRe = /field\s*:\s*['"]([A-Za-z0-9_$]+)['"]/g;
        let fieldMatch;
        while ((fieldMatch = fieldRe.exec(body)) !== null)
            fields.add(fieldMatch[1]);
        checks.set(handlerMatch[1], fields);
    }
    return checks;
}
function collectExportedHandlers(content) {
    const handlers = new Set();
    const re = /export\s+const\s+([A-Za-z0-9_$]+)\s*:\s*BffHandler\b/g;
    let match;
    while ((match = re.exec(content)) !== null)
        handlers.add(match[1]);
    return handlers;
}
function collectRouteHandlers(content) {
    const routes = new Map();
    const re = /\{\s*key\s*:\s*['"]([^'"]+)['"]\s*,\s*handler\s*:\s*([A-Za-z0-9_$]+)/g;
    let match;
    while ((match = re.exec(content)) !== null)
        routes.set(match[1], match[2]);
    return routes;
}
function collectUsecaseRules(data) {
    if (!data)
        return [];
    const rules = new Set(readStringArray(data.rulesApplied));
    const functions = Array.isArray(data.functions) ? data.functions : [];
    for (const fn of functions) {
        if (!isRecord(fn))
            continue;
        for (const rule of readStringArray(fn.rulesApplied))
            rules.add(rule);
    }
    return [...rules].filter(Boolean);
}
export function createAgent() {
    return { agentName: 'agentCbValidateAll', agentProject: 102021, agentFolder: 'agentChangeBackend', agentDescription: 'Deterministic non-blocking l1 coverage/integrity report', visibility: 'private', beforePromptStep };
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential) {
    try {
        const scan = await readBackendScan(['toCreate', 'inProgress']);
        const project = mls.actualProject || 0;
        let l1Defs = 0;
        let mdmTableViolations = 0;
        const mdmIds = new Set(scan.entities.filter(e => e.kind === 'mdm').map(e => e.entityId.toLowerCase()));
        const portDefs = new Set(); // lowercased shortNames present in layer_2_application/ports
        const domainDefs = new Set(); // lowercased shortNames present in layer_3_domain/entities
        const mdmDomainArtifacts = [];
        const usecases = [];
        const usecaseFnNames = new Map(); // usecaseId (lc) -> exported function names
        const controllers = []; // handler usecaseRefs per controller
        const tsSet = new Set(); // `${folder}::${shortName}` of MATERIALIZED .ts outputs
        const defsFiles = []; // each .defs.ts (to require a .ts sibling)
        const importReqs = []; // module-local l1 imports to resolve
        const usecaseSources = new Map(); // usecase shortName (lc) -> generated .ts
        const controllerSources = new Map(); // controller shortName (lc) -> generated .ts
        for (const file of Object.values(mls.stor.files)) {
            if (!file || file.project !== project || file.level !== 1 || file.status === 'deleted')
                continue;
            const folder0 = String(file.folder || '');
            const shortName0 = String(file.shortName || '');
            // Collect materialized .ts outputs (not the .defs.ts / .d.ts) for the completeness check, and
            // record their module-local l1 imports for the cross-file resolution check below.
            if (file.extension === '.ts' && !shortName0.endsWith('.defs') && !shortName0.endsWith('.d')) {
                const content = String(await file.getContent());
                tsSet.add(`${folder0}::${shortName0.toLowerCase()}`);
                if (folder0.endsWith('/layer_2_application/usecases')) {
                    usecaseSources.set(shortName0.toLowerCase(), content);
                    if (/\/_\d+_\/l1\/[^'"]*\/layer_3_domain\/rules\//.test(content)) {
                        importReqs.push({
                            from: `${folder0}/${shortName0}`,
                            key: '__invalid_rule_import__',
                            target: 'rulesApplied must be applied inline; layer_3_domain/rules/* is not generated by agentChangeBackend',
                        });
                    }
                }
                if (folder0.endsWith('/adapters/http/controllers'))
                    controllerSources.set(shortName0.toLowerCase(), content);
                for (const req of collectL1Imports(content, project)) {
                    importReqs.push({ from: `${folder0}/${shortName0}`, key: req.key, target: req.target });
                }
                const compact = content.replace(/\s+/g, ' ');
                if (/mdmEntityIndex\.findMany\(\s*\{[^}]*where\s*:\s*\{[^}]*\b(entityType|entityId|productId|warehouseId)\s*:/.test(compact)) {
                    importReqs.push({
                        from: `${folder0}/${shortName0}`,
                        key: '__invalid_mdm_index_filter__',
                        target: 'mdmEntityIndex uses invented fields; use MdmEntityIndexRecord fields and load module data from mdmDocument.details',
                    });
                }
                if (/mdmRelationship/.test(content) && /\b(source_entity_|target_entity_)/.test(content)) {
                    importReqs.push({
                        from: `${folder0}/${shortName0}`,
                        key: '__invalid_mdm_relationship_shape__',
                        target: 'mdmRelationship uses invented source_entity/target_entity fields; use MdmRelationshipRecord fromId/toId/type',
                    });
                }
                continue;
            }
            if (file.extension !== '.defs.ts')
                continue;
            l1Defs++;
            const folder = folder0;
            const shortName = shortName0.toLowerCase();
            defsFiles.push({ folder, shortName });
            if (folder.includes('/adapters/persistence') && mdmIds.has(shortName))
                mdmTableViolations++;
            if (folder.endsWith('/layer_2_application/ports'))
                portDefs.add(shortName);
            else if (folder.endsWith('/layer_3_domain/entities')) {
                if (mdmIds.has(shortName))
                    mdmDomainArtifacts.push(`${folder}/${shortName}.defs.ts`);
                else
                    domainDefs.add(shortName);
            }
            else if (folder.endsWith('/layer_2_application/usecases')) {
                const artifact = parseArtifact(String(await file.getContent()));
                const data = artifact && isRecord(artifact.data) ? artifact.data : undefined;
                usecases.push({ id: shortName, ports: data ? readStringArray(data.ports) : [], rulesApplied: collectUsecaseRules(data) });
                const fns = data && Array.isArray(data.functions) ? data.functions : [];
                usecaseFnNames.set(shortName, new Set(fns.map((f) => String(f?.functionName || '')).filter(Boolean)));
            }
            else if (folder.endsWith('/adapters/http/controllers')) {
                const artifact = parseArtifact(String(await file.getContent()));
                const data = artifact && isRecord(artifact.data) ? artifact.data : undefined;
                const handlers = data && Array.isArray(data.handlers) ? data.handlers : [];
                const routes = data && Array.isArray(data.routes) ? data.routes : [];
                controllers.push({
                    id: shortName,
                    refs: handlers.map((h) => String(h?.usecaseRef || '')).filter(Boolean),
                    handlers: handlers.filter(isRecord).map((h) => ({
                        handlerName: String(h?.handlerName || ''),
                        inputContract: h?.inputContract,
                        usecaseRef: String(h?.usecaseRef || ''),
                    })).filter((h) => !!h.handlerName),
                    routes: routes.filter(isRecord).map((r) => ({
                        key: String(r?.key || ''),
                        handlerName: String(r?.handlerName || ''),
                    })).filter((r) => !!r.key && !!r.handlerName),
                });
            }
        }
        // INTEGRITY: every port a usecase references must have a port .defs.ts AND a domain entity .defs.ts.
        // Catches the "usecase imports a module that was never generated" class of errors before tsc.
        const missing = [];
        for (const artifact of mdmDomainArtifacts) {
            missing.push(`mdm local domain artifact forbidden -> ${artifact}`);
        }
        for (const uc of usecases) {
            for (const p of uc.ports) {
                if (mdmIds.has(p.toLowerCase()))
                    continue; // mdm = master data read by id via 102034; no local port/entity
                const portSn = `${lowerFirst(p)}Repository`.toLowerCase();
                const domSn = lowerFirst(p).toLowerCase();
                if (!portDefs.has(portSn))
                    missing.push(`usecase ${uc.id} -> missing port ${lowerFirst(p)}Repository`);
                if (!domainDefs.has(domSn))
                    missing.push(`usecase ${uc.id} -> missing entity ${lowerFirst(p)}`);
            }
        }
        // COHERENCE (item 3): every controller handler must reference a function the usecase actually
        // exports. Catches the "controller imports an export the usecase never produced" break (orderFlow).
        for (const c of controllers) {
            const fns = usecaseFnNames.get(c.id);
            for (const ref of c.refs) {
                if (ref.includes(' | '))
                    continue; // dispatcher handler delegates to the concrete per-function handlers
                if (!fns) {
                    missing.push(`controller ${c.id} -> usecase defs not found`);
                    break;
                }
                if (!fns.has(ref))
                    missing.push(`controller ${c.id} -> usecase export '${ref}' not found (has: ${[...fns].join(', ') || 'none'})`);
            }
        }
        // ROUTES + HANDLER BOUNDARY: every route from the controller defs must be present in the generated
        // .ts and point to an exported handler. Required field validation must stay within the public L4
        // inputContract; contextResolution-only fields are resolved context, not mandatory request params.
        for (const c of controllers) {
            const handlerNames = new Set(c.handlers.map(h => h.handlerName));
            for (const route of c.routes) {
                if (!handlerNames.has(route.handlerName))
                    missing.push(`controller ${c.id} -> route ${route.key} points to missing handler ${route.handlerName}`);
            }
            const source = controllerSources.get(c.id);
            if (!source)
                continue;
            const exportedHandlers = collectExportedHandlers(source);
            const emittedRoutes = collectRouteHandlers(source);
            const requiredChecks = collectRequiredChecksByHandler(source);
            for (const handler of c.handlers) {
                if (!exportedHandlers.has(handler.handlerName))
                    missing.push(`controller ${c.id} -> handler ${handler.handlerName} not exported in .ts`);
                const allowedRequired = requiredBoundaryFields(handler.inputContract);
                for (const checked of requiredChecks.get(handler.handlerName) ?? []) {
                    if (!allowedRequired.has(checked)) {
                        missing.push(`controller ${c.id} -> handler ${handler.handlerName} requires '${checked}' outside l4 inputContract`);
                    }
                }
            }
            for (const route of c.routes) {
                const emittedHandler = emittedRoutes.get(route.key);
                if (emittedHandler !== route.handlerName) {
                    missing.push(`controller ${c.id} -> route ${route.key} not exported with handler ${route.handlerName}`);
                }
            }
        }
        const moduleName = scan.moduleNames[0] || 'unknown';
        for (const owner of scan.owners) {
            if (owner.kind !== 'operation' || !owner.id)
                continue;
            const controllerId = lowerFirst(owner.id).toLowerCase();
            const controller = controllers.find(c => c.id === controllerId);
            if (!controller)
                continue;
            const expectedRoute = owner.bffName || `${moduleName}.${owner.pageId || owner.id}.${owner.commandName || owner.id}`;
            if (!controller.routes.some(route => route.key === expectedRoute)) {
                missing.push(`controller ${controller.id} -> missing canonical bffName route ${expectedRoute}`);
            }
        }
        // COMPLETENESS (items 4 & 6): every .defs.ts must have its materialized .ts sibling. This is the
        // project-level barrier the per-file Monaco compile cannot see — it stops finalize from marking the
        // owners done while any .ts is still missing (the "finalize before materialization finished" gap).
        for (const d of defsFiles) {
            if (!tsSet.has(`${d.folder}::${d.shortName}`))
                missing.push(`materialization incomplete -> ${d.folder}/${d.shortName}.ts not generated from its .defs.ts`);
        }
        // CROSS-FILE IMPORTS: every module-local l1 import in a generated .ts must resolve to a generated
        // .ts. Root guard for hallucinated modules (e.g. importing layer_3_domain/rules/* — rules live
        // inside the entity, that folder is never generated). Catches it deterministically before the VM build.
        for (const req of importReqs) {
            if (req.key === '__invalid_mdm_index_filter__' || req.key === '__invalid_mdm_relationship_shape__' || req.key === '__invalid_rule_import__') {
                missing.push(`platform contract violation -> ${req.from}.ts: ${req.target}`);
                continue;
            }
            if (!tsSet.has(req.key))
                missing.push(`import unresolved -> ${req.from}.ts imports '${req.target}' which was not generated`);
        }
        // RULES APPLIED: if a usecase defs says a rule is applied, the materialized .ts must mention that
        // rule id. This blocks the concrete "referenced in defs and then disappeared" class, while the
        // explicit rule-import ban above keeps the current strategy inline.
        for (const uc of usecases) {
            if (!uc.rulesApplied.length)
                continue;
            const source = usecaseSources.get(uc.id);
            if (!source)
                continue;
            for (const rule of uc.rulesApplied) {
                if (!new RegExp(`\\b${escapeRegExp(rule)}\\b`).test(source)) {
                    missing.push(`usecase ${uc.id} -> rulesApplied '${rule}' not present in generated .ts`);
                }
            }
        }
        const warnings = mdmTableViolations > 0 ? [`${mdmTableViolations} MDM table artifact(s) found in persistence (should be 0)`] : [];
        if (missing.length) {
            const trace = `INTEGRITY FAILED: ${missing.length} missing-defs reference(s): ${[...new Set(missing)].slice(0, 30).join('; ')}`;
            console.error(`${logPrefix(agent)} ${trace}`);
            return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', trace)];
        }
        // Record the warning details on the step log too (not just the count), so they are visible in the trace.
        const okTrace = warnings.length
            ? `l1 defs=${l1Defs}; ${warnings.length} warning(s): ${warnings.slice(0, 12).join('; ')}`
            : `l1 defs=${l1Defs}; 0 warnings.`;
        return [
            enqueueNext(context, parentStep, step, 'cb-finalize', 'agentCbFinalizeStatus', 'Finalizar todoBackend', {}),
            createUpdateStatusIntent(context, parentStep, step, hookSequential, 'completed', okTrace),
        ];
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return [createUpdateStatusIntent(context, parentStep, step, hookSequential, 'failed', message)];
    }
}
