/// <mls fileReference="_102021_/l2/agentDefsL1/helpers/d1Stor.ts" enhancement="_blank"/>
import { createStorFile } from '/_102027_/l2/libStor.js';
import { assertShortName, displayPath, ownedFolder, } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
/**
 * Host disk path. Called as a method on `mls.stor` so a private field on the
 * host object stays bound. A missing method is Studio, not a failure.
 */
export function hostDiskPath(file) {
    const stor = mls.stor;
    if (typeof stor.diskPath !== 'function')
        return null;
    try {
        return stor.diskPath(file);
    }
    catch {
        return null;
    }
}
export function hostView(file) {
    const diskPath = hostDiskPath(file);
    const local = mls.stor.localStor;
    if (!local || typeof local.listFolder !== 'function')
        return { diskPath, listed: null };
    try {
        const listed = local.listFolder(file.project, file.level, file.folder)
            .filter(item => item.extension === file.extension && !!item.shortName)
            .map(item => item.shortName);
        return { diskPath, listed };
    }
    catch {
        return { diskPath, listed: null };
    }
}
export async function readText(file) {
    assertShortName(file.shortName);
    const stored = mls.stor.files[mls.stor.getKeyToFile(file)];
    if (!stored || stored.status === 'deleted')
        return null;
    if (stored.getValueInfo) {
        try {
            const local = await stored.getValueInfo();
            if (typeof local?.content === 'string')
                return local.content;
        }
        catch { /* index content is the fallback */ }
    }
    if (!stored.getContent)
        return null;
    const content = await stored.getContent();
    if (typeof content === 'string')
        return content;
    if (file.extension === '.json' && content && typeof content === 'object') {
        return `${JSON.stringify(content, null, 2)}\n`;
    }
    return null;
}
export async function writeText(file, content) {
    assertShortName(file.shortName);
    const key = mls.stor.getKeyToFile(file);
    const stored = mls.stor.files[key];
    if (!stored || stored.status === 'deleted') {
        if (stored && stored.status === 'deleted') {
            stored.status = 'changed';
            await mls.stor.localStor.setContent(stored, { contentType: 'string', content });
            return;
        }
        await createStorFile({ ...file, source: content, status: 'new' }, false, false, false);
        return;
    }
    await mls.stor.localStor.setContent(stored, { contentType: 'string', content });
}
export async function readJson(file) {
    const raw = await readText(file);
    if (!raw || !raw.trim())
        return null;
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
/** Writes JSON and returns the exact bytes stored. */
export async function writeJson(file, value) {
    const text = `${JSON.stringify(value, null, 2)}\n`;
    await writeText(file, text);
    return text;
}
/**
 * Removes one file this agent owns. The file identity is the same object a
 * write would use. The planner pipeline and every other folder are refused.
 */
export async function removeOwned(file) {
    const moduleName = file.folder.split('/')[0] || '';
    if (!moduleName || file.folder !== ownedFolder(moduleName)) {
        throw new Error(`agentDefsL1 refuses to remove ${displayPath(file)}`);
    }
    await deleteOne(file);
}
/**
 * Removes one own product def. A directory is not a file, a `.ts` output is
 * not a def, and this is not `/rebuild all`.
 */
export async function removeDefFile(file) {
    const moduleName = file.folder.split('/')[0] || '';
    const pipeline = `${moduleName}/pipeline`;
    const ownProduct = !!moduleName
        && file.extension === '.defs.ts'
        && !!file.shortName
        && !file.shortName.includes('.')
        && !file.shortName.includes('/')
        && (file.folder === moduleName || file.folder.startsWith(`${moduleName}/`))
        && file.folder !== pipeline
        && !file.folder.startsWith(`${pipeline}/`);
    if (!ownProduct)
        throw new Error(`agentDefsL1 refuses to remove ${displayPath(file)}`);
    await deleteOne(file);
}
/**
 * Removes the accepted implement from `l4/<module>/pool/l1` once it is traced. Any other
 * folder, level or name is refused.
 */
export async function removePoolMessage(file) {
    const moduleName = file.folder.split('/')[0] || '';
    const ok = file.level === 4
        && !!moduleName
        && file.folder === `${moduleName}/pool/l1`
        && file.extension === '.json'
        && /^\d{14}_.+_\d+$/u.test(file.shortName);
    if (!ok)
        throw new Error(`agentDefsL1 refuses to remove ${displayPath(file)}`);
    await deleteOne(file);
}
async function deleteOne(file) {
    const stored = mls.stor.files[mls.stor.getKeyToFile(file)];
    if (!stored || stored.status === 'deleted')
        return;
    const local = mls.stor.localStor;
    if (typeof local.deleteFile === 'function') {
        await local.deleteFile(stored);
        return;
    }
    stored.status = 'deleted';
}
