/// <mls fileReference="_102021_/l2/agentDefsL1/helpers/d1TestHost.ts" enhancement="_blank"/>
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _HostStor_base;
export function fileKey(info) {
    return `${info.project}_${info.level}_${info.folder}/${info.shortName}${info.extension}`;
}
function blankFile(params) {
    const file = {
        project: params.project,
        level: params.level,
        folder: params.folder,
        shortName: params.shortName,
        extension: params.extension,
        status: params.status || 'new',
        versionRef: '0',
        content: '',
        updatedAt: 'created',
        getValueInfo: async () => ({ content: file.content }),
        getContent: async () => file.content,
    };
    return file;
}
export function installStudio(project) {
    const files = {};
    const writes = [];
    const host = {
        files,
        writes,
        setProject(next) {
            globalThis.mls.actualProject = next;
        },
    };
    globalThis.mls = {
        actualProject: project,
        events: { addEventListener() { }, removeEventListener() { }, dispatch() { } },
        stor: {
            files,
            getKeyToFile: fileKey,
            addOrUpdateFile: async (params) => {
                const file = blankFile(params);
                files[fileKey(file)] = file;
                return file;
            },
            localStor: {
                setContent: async (file, value) => {
                    file.content = value.content || '';
                    file.updatedAt = 'written';
                    writes.push(fileKey(file));
                    return true;
                },
                deleteFile(file) {
                    file.status = 'deleted';
                    file.updatedAt = 'deleted';
                },
            },
        },
    };
    return host;
}
export function seed(host, info, content, updatedAt = 'seed') {
    const stored = blankFile(info);
    stored.content = content;
    stored.status = 'changed';
    stored.updatedAt = updatedAt;
    host.files[fileKey(stored)] = stored;
    return stored;
}
/** Host stor whose diskPath closes over a private field. Detaching the method throws. */
export class HostStor {
    constructor() {
        _HostStor_base.set(this, '/data/mls-base');
        this.files = {};
        this.writes = [];
        this.localStor = {
            setContent: async (file, value) => {
                file.content = value.content || '';
                file.updatedAt = 'written';
                this.writes.push(fileKey(file));
                return true;
            },
            listFolder: (project, level, folder) => {
                return Object.values(this.files)
                    .filter(file => file.project === project && file.level === level && file.folder === folder && file.status !== 'deleted')
                    .map(file => ({
                    project: file.project,
                    level: file.level,
                    folder: file.folder,
                    shortName: file.shortName,
                    extension: file.extension,
                }));
            },
            deleteFile: (file) => {
                file.status = 'deleted';
                file.updatedAt = 'deleted';
            },
        };
    }
    getKeyToFile(info) {
        return fileKey(info);
    }
    async addOrUpdateFile(params) {
        const file = blankFile(params);
        this.files[fileKey(file)] = file;
        return file;
    }
    diskPath(info) {
        return `${__classPrivateFieldGet(this, _HostStor_base, "f")}/mls-${info.project}/l${info.level}/${info.folder}/${info.shortName}${info.extension}`;
    }
}
_HostStor_base = new WeakMap();
export function installClassHost(project, host) {
    globalThis.mls = {
        actualProject: project,
        events: { addEventListener() { }, removeEventListener() { }, dispatch() { } },
        stor: host,
    };
}
