/// <mls fileReference="_102021_/l2/agentDefsL1/helpers/d1TestResolver.ts" enhancement="_blank"/>
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createD1AgentStep } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { parseFanoutWorkerArg } from '/_102021_/l2/agentDefsL1/helpers/d1Fanout.js';
import { readText, writeText } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { D1_GAP_NONE } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { readContractV2 } from '/_102021_/l2/agentDefsL1/steps/input20/gate.js';
import { readD1InputArtifacts } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
import { RESOLVE_FANOUT } from '/_102021_/l2/agentDefsL1/steps/resolve25/agentD1Resolve.js';
import { resolveUnits } from '/_102021_/l2/agentDefsL1/steps/resolve25/gate.js';
import { readResolveWork } from '/_102021_/l2/agentDefsL1/steps/resolve25/io.js';
export const metaResolver = (route, gap) => {
    const meta = route.meta;
    if (gap.kind === 'entity' && gap.path.startsWith('output.'))
        return meta.output[gap.path.slice('output.'.length)]?.entity ?? D1_GAP_NONE;
    if (gap.kind === 'flatPaging') {
        const names = gap.path.slice('output.'.length).split(', ');
        return Object.values(meta.lists).find(list => names.includes(list.page))?.key ?? D1_GAP_NONE;
    }
    if (gap.kind === 'pageParam') {
        const param = meta.params[gap.path.slice('input.'.length)];
        return param && 'pages' in param ? meta.lists[param.pages]?.key ?? D1_GAP_NONE : D1_GAP_NONE;
    }
    if (gap.kind === 'filterField') {
        const param = meta.params[gap.path.slice('input.'.length)];
        return param && 'filters' in param ? `${param.filters}:${param.field}` : D1_GAP_NONE;
    }
    return D1_GAP_NONE;
};
/**
 * The answers resolve25 would record with `resolver` in place of the model, per route, as `buildD1InputSnapshot`
 * takes them. For the tests that build the inventory without running the hooks.
 */
export function resolverAnswers(artifacts, resolver = metaResolver) {
    const contracts = readContractV2(artifacts.contractTexts);
    const out = new Map();
    for (const unit of resolveUnits(artifacts)) {
        const route = contracts.get(unit.pageId)?.routes.find(item => item.route === unit.route);
        out.set(unit.route, unit.gaps.map(gap => ({ path: gap.path, choice: route ? resolver(route, gap) : D1_GAP_NONE })));
    }
    return out;
}
const PROMPT_FILE = { project: 102021, level: 2, folder: 'agentDefsL1/steps/resolve25', shortName: 'prompt', extension: '.md' };
const PROMPT_DISK = path.join(path.dirname(fileURLToPath(import.meta.url)), '../steps/resolve25/prompt.md');
function workerStep(stepId, prompt, planId = '') {
    return {
        type: 'agent',
        stepId,
        interaction: null,
        stepTitle: 'worker',
        status: 'waiting_human_input',
        nextSteps: [],
        agentName: 'agentDefsL1',
        prompt,
        rags: [],
        planning: { planId, dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
}
/**
 * Runs resolve25 on the hooks: the main step, each route worker answered by `resolver` through the tool, and the
 * barrier. Returns every intent, main first. With no gap there is no worker and no barrier.
 */
export async function runResolve25(agent, agentMeta, ctx, parent, project, moduleName, order, command = 'run', resolver = metaResolver) {
    // The worker reads its prompt from the studio, as in the browser; the test host starts without it.
    if (await readText(PROMPT_FILE) === null)
        await writeText(PROMPT_FILE, readFileSync(PROMPT_DISK, 'utf8'));
    const main = createD1AgentStep('resolve25', moduleName, project, command);
    main.stepId = order;
    const intents = await agent.beforePromptStep(agentMeta, ctx, parent, main, order);
    const fanout = intents.find((intent) => intent.type === 'add-step' && intent.step.planning?.planId === 'resolve25-fanout');
    if (!fanout)
        return intents;
    const args = fanout.executionMode?.type === 'parallel' ? fanout.executionMode.args : [];
    const artifacts = await readD1InputArtifacts(project, moduleName);
    const contracts = readContractV2(artifacts.contractTexts);
    let seq = order * 100;
    for (const arg of args) {
        const worker = workerStep(++seq, arg);
        const prepared = await agent.beforePromptStep(agentMeta, ctx, parent, worker, seq);
        if (!prepared.some(intent => intent.type === 'prompt_ready')) {
            intents.push(...prepared);
            continue;
        }
        const unitId = parseFanoutWorkerArg(RESOLVE_FANOUT, arg)?.unitId;
        const unit = (await readResolveWork(project, moduleName))?.units.find(item => item.unitId === unitId);
        const route = unit ? contracts.get(unit.pageId)?.routes.find(item => item.route === unit.route) : undefined;
        const reply = { answers: Object.fromEntries((unit?.gaps || []).map(gap => [gap.gapId, route ? resolver(route, gap) : D1_GAP_NONE])) };
        worker.interaction = { input: [], cost: 0, trace: [], payload: [{ type: 'function', function: { name: 'resolveRouteGaps', arguments: JSON.stringify(reply) } }] };
        intents.push(...prepared, ...await agent.afterPromptStep(agentMeta, ctx, parent, worker, seq));
    }
    const barrier = workerStep(++seq, JSON.stringify({ planId: 'resolve25-barrier', moduleName, project, command }), 'resolve25-barrier');
    intents.push(...await agent.beforePromptStep(agentMeta, ctx, parent, barrier, seq));
    return intents;
}
