/// <mls fileReference="_102021_/l2/agentDefsL1/agentDefsL1.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { D1_AGENT_NAME, D1_FLOW_ID, buildD1PlannedSteps, helpText, isD1StepId, isDoneAnchor, notImplementedTrace, parseD1Invocation, parseD1StepPrompt, planIdFromPrompt, pipelineFile, requireProject, stoppedTrace, taskModule, taskProject, unknownPlanId, } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { d1StatusMessage, drainWaitingSiblings, hooksFor, markAwaitingStep, planIdOf, updateStatus, } from '/_102021_/l2/agentDefsL1/helpers/d1Dispatch.js';
import { parsePipelineDocument } from '/_102021_/l2/agentDefsL1/helpers/d1Schema.js';
import { readText } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { decideEntry } from '/_102021_/l2/agentDefsL1/steps/entry10/gate.js';
import '/_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry.js';
import '/_102021_/l2/agentDefsL1/steps/input20/agentD1Input.js';
import '/_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain.js';
import '/_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence.js';
import '/_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases.js';
import '/_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers.js';
import '/_102021_/l2/agentDefsL1/steps/support70/agentD1Support.js';
import '/_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize.js';
export function createAgent() {
    return {
        agentName: D1_AGENT_NAME,
        agentProject: 102021,
        agentFolder: 'agentDefsL1',
        agentDescription: 'L1 defs agent — checkpoint, input inventory, domain defs, persistence defs, usecase plans, page controllers, access scope, repository registry and the finalize report. usecases50 calls a model for operation steps only. finalize80 does not.',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const invocation = parseD1Invocation(userPrompt || context.message.content || '');
    if (invocation.refused)
        return statusTask(agent, context, invocation.refused, {});
    const project = requireProject(mls.actualProject);
    if (typeof project !== 'number')
        return statusTask(agent, context, project.refusal, { moduleName: invocation.module });
    if (invocation.command === 'help') {
        return statusTask(agent, context, helpText(invocation.module, project), {
            moduleName: invocation.module,
            project: String(project),
            command: 'help',
        });
    }
    const command = invocation.command === 'resume' ? 'resume' : 'run';
    const raw = await readText(pipelineFile(project, invocation.module));
    const decision = decideEntry(command, project, invocation.module, raw, new Date());
    if (decision.kind === 'refusal') {
        return statusTask(agent, context, decision.refusal, {
            moduleName: invocation.module,
            project: String(project),
            command,
        });
    }
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentDefsL1 deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: invocation.module },
            ],
            taskTitle: `defs ${invocation.module}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'agentDefsL1',
                flowName: D1_FLOW_ID,
                moduleName: invocation.module,
                project: String(project),
                command,
            },
        },
    };
    const steps = buildD1PlannedSteps(invocation.module, project, command).map(step => addStepIntent(context, step));
    return [addMessage, ...steps];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step) || planIdFromPrompt(args || step.prompt || '');
    const hooks = hooksFor(planId);
    if (hooks?.beforePromptStep)
        return hooks.beforePromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isD1StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    if (isDoneAnchor(planId)) {
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Done anchor ${planId} is not a step.`)];
    }
    if (planId && planId !== 'root' && planId !== 'status') {
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', unknownPlanId(planId))];
    }
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step) || planIdFromPrompt(args || step.prompt || '');
    const hooks = hooksFor(planId);
    if (hooks?.afterPromptStep)
        return hooks.afterPromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isD1StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    if (isDoneAnchor(planId)) {
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', `Done anchor ${planId} is not a step.`)];
    }
    if (planId && planId !== 'root' && planId !== 'status') {
        return [updateStatus(context, parentStep, step, hookSequential, 'completed', unknownPlanId(planId))];
    }
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function notImplemented(context, parentStep, step, hookSequential, stepId) {
    const fromPrompt = parseD1StepPrompt(step.prompt || '');
    const moduleName = fromPrompt.kind === 'step' ? fromPrompt.prompt.moduleName : taskModule(context);
    const project = fromPrompt.kind === 'step' ? fromPrompt.prompt.project : taskProject(context);
    if (moduleName && project && taskProject(context) === project && taskModule(context) === moduleName) {
        const raw = await readText(pipelineFile(project, moduleName));
        const pipeline = raw ? parsePipelineDocument(raw) : null;
        if (pipeline && pipeline.project === project && pipeline.moduleName === moduleName) {
            await markAwaitingStep(pipeline, stepId);
        }
    }
    return [
        ...drainWaitingSiblings(context, step, hookSequential, stoppedTrace(stepId), { onlyUnimplemented: true }),
        updateStatus(context, parentStep, step, hookSequential, 'completed', notImplementedTrace(stepId)),
    ];
}
function addStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function statusTask(agent, context, message, memory) {
    const addMessage = d1StatusMessage(agent, context, message, memory);
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Status',
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, addStepIntent(context, result)];
}
