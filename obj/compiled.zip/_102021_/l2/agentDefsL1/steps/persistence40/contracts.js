/// <mls fileReference="_102021_/l2/agentDefsL1/steps/persistence40/contracts.ts" enhancement="_blank"/>
export const D1_PERSISTENCE_VERSION = '2026-09-21-d1-persistence-v1';
/** Prefix for a logical field stored in the runtime `details` JSONB column. One writer, reversible. */
export const D1_JSON_COLUMN_PREFIX = 'json:';
/** Runtime JSONB column name. Not derived per table and not snake-cased. */
export const D1_DETAILS_COLUMN = 'details';
export const D1_PERSISTENCE_ACTIONS = ['create', 'update', 'recompose', 'preserve', 'remove', 'conflict'];
export const ENUMERATION_REASON = 'Table and adapter schemas have no enum values. They stay on the domain draft.';
/** Logical field encoded by one column string. `json:` marks the details envelope. */
export function fieldFromColumn(column) {
    return column.startsWith(D1_JSON_COLUMN_PREFIX) ? column.slice(D1_JSON_COLUMN_PREFIX.length) : column;
}
export function columnForField(field, placement) {
    return placement === 'json' ? `${D1_JSON_COLUMN_PREFIX}${field}` : field;
}
/** Names required by the port and missing from the adapter. */
export function uncoveredMethods(required, implemented) {
    return required.filter(name => !implemented.includes(name));
}
/** A binding round-trips when each column string decodes to its own field and no column is shared. */
export function bindingRoundTripIssues(bindings) {
    const issues = [];
    const seen = new Set();
    for (const binding of bindings) {
        const decoded = fieldFromColumn(binding.column);
        if (decoded !== binding.field || !binding.column) {
            issues.push(`Field ${binding.field} does not round-trip through ${binding.column || '(empty)'}.`);
        }
        if (binding.placement === 'json' && !binding.column.startsWith(D1_JSON_COLUMN_PREFIX)) {
            issues.push(`Field ${binding.field} is marked json but its column is ${binding.column}.`);
        }
        if (binding.placement === 'column' && binding.column.startsWith(D1_JSON_COLUMN_PREFIX)) {
            issues.push(`Field ${binding.field} is marked column but its column is ${binding.column}.`);
        }
        if (seen.has(binding.column))
            issues.push(`Column ${binding.column} is used by more than one field.`);
        if (binding.column)
            seen.add(binding.column);
    }
    return issues;
}
