/// <mls fileReference="_102021_/l2/agentDefsL1/steps/controllers60/gate.ts" enhancement="_blank"/>
import { definitionIssues, pendingDefinition, } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { futureOutputPath, pipelineId, qualifyDefPath, skillPaths, } from '/_102021_/l2/agentDefsL1/helpers/d1Refs.js';
import { renderDefinition, stampDefinition } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { isSafeToken } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { contractInterfaceName, fieldsByEntity, readContractV2, requestServiceProblems, serviceRowsFor, usecaseIdsWithDef, } from '/_102021_/l2/agentDefsL1/steps/controllers60/requestService.js';
import { worstOfList } from '/_102021_/l2/agentDefsL1/steps/input20/gate.js';
import { D1_CONTROLLER_VERSION, ENUMERATION_REASON, ENUMERATION_SOURCE, HANDLER_STEPS, } from '/_102021_/l2/agentDefsL1/steps/controllers60/contracts.js';
/**
 * One controller per page. Ids, route strings and contract symbols are copied.
 * An operation with no grant is an error. There is no public fallback.
 */
export function buildD1Controllers(request) {
    const problems = [];
    const normalizations = [];
    const enumerations = unconsumedEnumerations(request);
    if (!request.accessRead) {
        error(problems, 'ACCESS_UNREADABLE', 'access', 'Access artifact did not parse. No grant was assumed.');
    }
    if (!request.actorsRead) {
        error(problems, 'ACTORS_UNREADABLE', 'needs', 'Page actors did not parse. No actor was assumed.');
    }
    const services = requestServices(request, problems);
    const byPage = new Map();
    for (const service of services) {
        for (const row of service.requests) {
            const route = {
                route: row.route,
                page: service.pageId,
                kind: row.kind,
                usecaseRef: '',
                status: routeStatus(request, row.uses),
            };
            const binding = bindAdapter(request, route, row, problems);
            const list = byPage.get(service.pageId) || [];
            list.push(binding);
            byPage.set(service.pageId, list);
        }
    }
    const controllers = [];
    for (const [pageId, handlers] of byPage) {
        const page = pageFor(request, pageId);
        handlers.sort((left, right) => left.route.localeCompare(right.route));
        const staleRoutes = staleOf(request, pageId, liveRoutes(pageId, services), problems);
        const item = { pageId, defPath: page.defPath, handlers, staleRoutes, definition: null };
        if (!isSafeToken(pageId)) {
            error(problems, 'PAGE_ID', pageId, `Page ${pageId} is not a safe token. No controller file was named.`);
        }
        controllers.push(item);
    }
    const ok = !problems.some(problem => problem.severity === 'error');
    const before = problems.length;
    if (ok) {
        for (const item of controllers)
            fillDefinition(request, item, problems);
    }
    const stillOk = ok && problems.length === before;
    const emit = stillOk ? emitItems(request, controllers, problems) : [];
    if (stillOk)
        emit.push(...emitServices(request, services, problems));
    const emitted = stillOk && !problems.some(problem => problem.severity === 'error') ? emit : [];
    return finish(request, emitted.length > 0 && !problems.some(problem => problem.severity === 'error'), enumerations, controllers, services, problems, normalizations, emitted);
}
/** A grant whose actor is not on this page is a union. The caller does not add it. */
export function grantUnionIssues(pageActors, grantIds, grants) {
    const actors = new Set(pageActors);
    const issues = [];
    for (const grantId of grantIds) {
        const grant = grants.find(item => item.grantId === grantId);
        if (grant && !actors.has(grant.actorRef))
            issues.push(grantId);
    }
    return issues;
}
/** v2 page: the handler calls one request-service function. It does not name a usecase. */
function bindAdapter(request, route, row, problems) {
    const path = route.route;
    const page = pageFor(request, route.page);
    const kind = mapKind(route.kind);
    const contract = request.contracts.find(item => item.pageId === route.page);
    const contractPath = contract?.path || `l2/${request.moduleName}/web/contracts/${route.page}.defs.ts`;
    const contractInterface = contract ? contractInterfaceName(contract.source) : '';
    const serviceFunction = row.route;
    if (!kind)
        error(problems, 'KIND', path, `Route ${path} kind ${route.kind} is not query or command.`);
    if (!contractInterface) {
        error(problems, 'INVALID_REF', path, `Route ${path} has no contract interface.`);
    }
    const entities = [];
    for (const usecaseId of row.uses) {
        const usecase = request.usecases.find(item => item.usecaseId === usecaseId);
        if (usecase && !entities.includes(usecase.entity))
            entities.push(usecase.entity);
    }
    const matched = [];
    for (const entity of entities) {
        for (const grant of matchingGrants(page.actors, entity, request.grants)) {
            if (!matched.includes(grant.grantId))
                matched.push(grant.grantId);
        }
    }
    const kept = finishGrants(request, route, kind, matched, existing => existing.serviceFunction === serviceFunction, problems);
    if (!kept.preserved) {
        const uncovered = entities.filter(entity => matchingGrants(page.actors, entity, request.grants).length === 0);
        const missing = entities.length === 0 ? [path] : uncovered;
        for (const entity of missing) {
            error(problems, 'AUTHORITY_REQUIRED', path, `Operation ${entity} on ${path} has no authority. No permissive fallback was applied.`);
        }
    }
    else if (kept.grantIds.length === 0) {
        error(problems, 'AUTHORITY_REQUIRED', path, `Operation ${path} has no authority. No permissive fallback was applied.`);
    }
    const attached = grantsOnPage(page, kept.grantIds, request);
    const projected = [];
    for (const output of row.outputs) {
        const fields = output.fields.map(name => ({ name, type: 'string', optional: false }));
        const disclosed = discloseProjection(output.entity, fields, attached);
        projected.push(...disclosed.fields);
        if (disclosed.blocked.length || disclosed.opaque.length) {
            error(problems, 'DISCLOSURE', path, disclosureMessage(path, disclosed.blocked, disclosed.opaque));
        }
    }
    return {
        route: route.route,
        pageId: route.page,
        kind: kind || 'query',
        usecaseId: '',
        functionName: '',
        serviceFunction,
        contractPath,
        contractInterface,
        inputSymbol: '',
        outputSymbol: '',
        status: route.status,
        preserved: kept.preserved,
        grantIds: kept.grantIds,
        projection: { shape: projected.length ? 'object' : 'unresolved', fields: projected, envelope: 'passthrough' },
        session: 'verified',
        steps: HANDLER_STEPS,
        scopePlan: scopePlans(attached, request.relationships, problems, path),
    };
}
function grantsOnPage(page, grantIds, request) {
    return grantIds.flatMap(grantId => {
        const grant = request.grants.find(item => item.grantId === grantId);
        return grant && page.actors.includes(grant.actorRef) ? [grant] : [];
    });
}
function finishGrants(request, route, kind, matched, sameHandler, problems) {
    const path = route.route;
    const page = pageFor(request, route.page);
    let grantIds = [...matched];
    let preserved = false;
    if (route.status === 'done') {
        const existing = existingHandler(request, route);
        if (!existing) {
            error(problems, 'HANDLER_MISSING', path, `Done route ${path} has no handler to keep.`);
        }
        else if (!sameHandler(existing) || existing.kind !== (kind || 'query')) {
            error(problems, 'STALE_ARTIFACT', path, `Done route ${path} does not match the handler on disk.`);
        }
        else {
            preserved = true;
            grantIds = [...existing.grantIds];
            const union = grantUnionIssues(page.actors, grantIds, request.grants);
            if (union.length) {
                error(problems, 'GRANT_UNION', path, `Done route ${path} keeps a grant of another page: ${union.join(', ')}.`);
            }
            for (const grantId of grantIds) {
                if (!request.grants.some(item => item.grantId === grantId)) {
                    error(problems, 'INVALID_REF', path, `Grant ${grantId} on ${path} is not in the access artifact.`);
                }
            }
        }
    }
    else {
        const union = grantUnionIssues(page.actors, grantIds, request.grants);
        if (union.length) {
            error(problems, 'GRANT_UNION', path, `Route ${path} would take a grant of another page: ${union.join(', ')}.`);
        }
    }
    return { grantIds, preserved };
}
/**
 * A handler is done only when every usecase it calls is done (the rule input20 uses for the
 * controller file). A request that calls no selected usecase is new.
 */
function routeStatus(request, uses) {
    const statuses = uses.flatMap(usecaseId => {
        const usecase = request.usecases.find(item => item.usecaseId === usecaseId);
        return usecase ? [usecase.status] : [];
    });
    return statuses.length === uses.length && uses.length > 0 ? worstOfList(statuses) : 'toCreate';
}
function liveRoutes(pageId, services) {
    const rows = services.find(item => item.pageId === pageId)?.requests || [];
    return new Set(rows.map(row => row.route));
}
function matchingGrants(actors, entity, grants) {
    const allowed = new Set(actors);
    return grants.filter(grant => allowed.has(grant.actorRef) && grant.entityRefs.includes(entity));
}
/**
 * fieldsOnly addresses a path, the way the access artifact does.
 * `Entity.details.identification` covers that branch and its descendants.
 * It does not cover another field whose last segment is `identification`,
 * and it does not release the parent `details`. The projection keeps the
 * disclosed sub-paths. `fullRecord` keeps every declared field.
 */
function discloseProjection(entity, fields, grants) {
    if (grants.some(grant => grant.disclosure === 'fullRecord')) {
        return { fields: fields.map(field => field.name), blocked: [], opaque: [] };
    }
    const allowed = relativeAllowed(entity, grants);
    const listed = [];
    const blocked = [];
    const opaque = [];
    for (const field of fields)
        coverPath(field.name, field.type, allowed, listed, blocked, opaque);
    return { fields: listed, blocked, opaque };
}
function disclosureMessage(route, blocked, opaque) {
    const parts = [];
    if (blocked.length) {
        parts.push(`Route ${route} projects ${blocked.join(', ')}, which this page's grants do not disclose.`);
    }
    if (opaque.length) {
        parts.push(`Route ${route} projects ${opaque.join(', ')}. A grant names a sub-path, but the nested shape could not be read, so the container was not released.`);
    }
    return parts.join(' ');
}
function relativeAllowed(entity, grants) {
    const prefix = `${entity}.`;
    const out = [];
    for (const grant of grants) {
        for (const item of grant.allowedFields) {
            if (item === entity)
                out.push('');
            else if (item.startsWith(prefix))
                out.push(item.slice(prefix.length));
        }
    }
    return out;
}
function coverPath(path, type, allowed, listed, blocked, opaque) {
    if (pathDisclosed(path, allowed)) {
        listed.push(path);
        return;
    }
    const members = nestedMembers(type);
    if (members === null) {
        listed.push(path);
        if (pathCarrier(path, allowed))
            opaque.push(path);
        else
            blocked.push(path);
        return;
    }
    if (!members.length) {
        if (!pathCarrier(path, allowed)) {
            listed.push(path);
            blocked.push(path);
        }
        return;
    }
    for (const member of members)
        coverPath(`${path}.${member.name}`, member.type, allowed, listed, blocked, opaque);
}
function pathDisclosed(path, allowed) {
    return allowed.some(item => item === path || item === '' || (item !== '' && path.startsWith(`${item}.`)));
}
function pathCarrier(path, allowed) {
    return allowed.some(item => item.startsWith(`${path}.`));
}
function nestedMembers(type) {
    const inner = objectBody(type.trim());
    if (inner === null)
        return null;
    return objectMembers(inner);
}
function objectBody(type) {
    if (!type.startsWith('{'))
        return null;
    let depth = 0;
    let inString = false;
    let quote = '';
    let escaped = false;
    for (let index = 0; index < type.length; index += 1) {
        const char = type[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === quote)
                inString = false;
            continue;
        }
        if (char === '"' || char === "'") {
            inString = true;
            quote = char;
            continue;
        }
        if (char === '{')
            depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0) {
                if (type.slice(index + 1).trim())
                    return null;
                return type.slice(1, index);
            }
        }
    }
    return null;
}
function objectMembers(body) {
    const members = [];
    let index = 0;
    while (index < body.length) {
        while (index < body.length && /[\s,;]/.test(body[index]))
            index += 1;
        if (index >= body.length)
            break;
        const mark = index;
        const name = memberName(body, index);
        if (!name)
            return null;
        index = name.end;
        while (index < body.length && /\s/.test(body[index]))
            index += 1;
        if (body[index] === '?') {
            index += 1;
            while (index < body.length && /\s/.test(body[index]))
                index += 1;
        }
        if (body[index] !== ':')
            return null;
        index += 1;
        const typed = memberType(body, index);
        if (!typed)
            return null;
        index = typed.end;
        if (index === mark)
            return null;
        members.push({ name: name.text, type: typed.text });
    }
    return members;
}
function memberName(body, index) {
    const quote = body[index];
    if (quote === '"' || quote === "'") {
        let end = index + 1;
        let escaped = false;
        while (end < body.length) {
            const char = body[end];
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === quote)
                return { text: body.slice(index + 1, end), end: end + 1 };
            end += 1;
        }
        return null;
    }
    const match = /^[A-Za-z_$][\w$]*/.exec(body.slice(index));
    if (!match)
        return null;
    return { text: match[0], end: index + match[0].length };
}
function memberType(body, start) {
    let index = start;
    while (index < body.length && /\s/.test(body[index]))
        index += 1;
    const from = index;
    let depthBrace = 0;
    let depthBracket = 0;
    let depthParen = 0;
    let depthAngle = 0;
    let inString = false;
    let quote = '';
    let escaped = false;
    while (index < body.length) {
        const char = body[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === quote)
                inString = false;
            index += 1;
            continue;
        }
        if (char === '"' || char === "'") {
            inString = true;
            quote = char;
            index += 1;
            continue;
        }
        const flat = depthBrace === 0 && depthBracket === 0 && depthParen === 0 && depthAngle === 0;
        if (flat && (char === ',' || char === ';'))
            break;
        if (char === '{')
            depthBrace += 1;
        else if (char === '}') {
            if (depthBrace === 0)
                break;
            depthBrace -= 1;
        }
        else if (char === '[')
            depthBracket += 1;
        else if (char === ']') {
            if (depthBracket === 0)
                break;
            depthBracket -= 1;
        }
        else if (char === '(')
            depthParen += 1;
        else if (char === ')') {
            if (depthParen === 0)
                break;
            depthParen -= 1;
        }
        else if (char === '<')
            depthAngle += 1;
        else if (char === '>' && depthAngle > 0)
            depthAngle -= 1;
        index += 1;
    }
    const text = body.slice(from, index).replace(/\s+/g, ' ').trim();
    if (!text)
        return null;
    return { text, end: index };
}
function scopePlans(grants, relationships, problems, path) {
    return grants.map(grant => {
        const rels = relationships
            .filter(rel => grant.entityRefs.includes(rel.from))
            .map(rel => ({ relationshipId: rel.relationshipId, from: rel.from, to: rel.to, field: rel.field }));
        let pending = '';
        if (grant.anchorEntity && !grant.entityRefs.includes(grant.anchorEntity)) {
            const others = relationships.filter(rel => rel.required && grant.entityRefs.includes(rel.from) && rel.to && rel.to !== grant.anchorEntity);
            if (others.length) {
                pending = 'ACCESS_ANCHOR';
                review(problems, 'ACCESS_ANCHOR', path, `Grant ${grant.grantId} anchors on ${grant.anchorEntity}. Relationship ${others.map(rel => rel.relationshipId).join(', ')} binds another required target.`);
            }
        }
        return {
            grantId: grant.grantId,
            actorRef: grant.actorRef,
            entityRefs: [...grant.entityRefs],
            disclosure: grant.disclosure,
            allowedFields: [...grant.allowedFields],
            anchorEntity: grant.anchorEntity,
            relationships: rels,
            pending,
            emittedBy: 'support70',
        };
    });
}
function existingHandler(request, route) {
    const page = request.existing.find(item => item.pageId === route.page);
    if (!page || page.unreadable)
        return null;
    return page.handlers.find(item => item.route === route.route) || null;
}
function staleOf(request, pageId, selected, problems) {
    const existing = request.existing.find(item => item.pageId === pageId);
    if (!existing)
        return [];
    if (existing.unreadable) {
        error(problems, 'STALE_ARTIFACT', pageId, `Controller ${pageId} did not parse. Nothing was overwritten.`);
        return [];
    }
    const removed = new Set((request.removedRoutes || []).map(route => route.route));
    const extra = existing.routes.filter(route => !selected.has(route) && !removed.has(route));
    for (const route of extra) {
        error(problems, 'STALE_ARTIFACT', pageId, `Controller ${pageId} still has route ${route}, which is not selected.`);
    }
    return extra;
}
function requestServices(request, problems) {
    const selected = request.serviceRequests || [];
    const knownFields = fieldsByEntity(request.ontology || {});
    const usecaseIds = usecaseIdsWithDef(request);
    const services = [];
    for (const contract of request.contracts) {
        const parsed = readContractV2(contract.source);
        if (!parsed || parsed.pageId !== contract.pageId) {
            error(problems, 'CONTRACT_UNPARSED', contract.path, parsed
                ? `L2 contract ${contract.path} names page ${parsed.pageId}, not ${contract.pageId}. No handler was planned.`
                : `L2 contract ${contract.path} is not a readable v2 contract. No handler was planned.`);
            continue;
        }
        const pageSelected = selected.filter(item => item.pageId === contract.pageId);
        const selectedCounts = new Map();
        for (const item of pageSelected)
            selectedCounts.set(item.route, (selectedCounts.get(item.route) || 0) + 1);
        const built = serviceRowsFor(contract.pageId, parsed, pageSelected);
        problems.push(...built.problems);
        const pageProblems = requestServiceProblems({
            pageId: contract.pageId,
            contractRoutes: built.routes,
            requests: built.rows,
            usecaseIds,
            fieldsByEntity: knownFields,
            selectedCounts,
        });
        problems.push(...pageProblems);
        const defPath = `l1/${request.moduleName}/layer_2_application/requests/${contract.pageId}.defs.ts`;
        const item = { pageId: contract.pageId, defPath, requests: built.rows, definition: null };
        if (!isSafeToken(contract.pageId)) {
            error(problems, 'PAGE_ID', contract.pageId, `Page ${contract.pageId} is not a safe token. No request service file was named.`);
        }
        const blocked = [...built.problems, ...pageProblems].some(problem => problem.severity === 'error') || !isSafeToken(contract.pageId);
        if (!blocked)
            fillService(request, item, problems);
        services.push(item);
    }
    return services;
}
function fillService(request, item, problems) {
    const usecaseIds = [...new Set(item.requests.flatMap(row => row.uses))].sort();
    const dependencies = [];
    for (const usecaseId of usecaseIds) {
        const usecase = request.usecases.find(entry => entry.usecaseId === usecaseId);
        if (!usecase?.defPath)
            continue;
        dependencies.push(qualifyDefPath(request.project, usecase.defPath));
    }
    dependencies.sort();
    const definition = pendingDefinition('requestService', item.pageId, request.moduleName, {
        pageId: item.pageId,
        requests: item.requests,
    }, dependencies);
    const issues = definitionIssues(definition);
    if (issues.length) {
        error(problems, 'DEFINITION', item.pageId, issues[0]);
        return;
    }
    item.definition = definition;
}
function emitServices(request, services, problems) {
    const out = [];
    for (const item of services) {
        if (!item.definition)
            continue;
        const usecaseIds = [...new Set(item.requests.flatMap(row => row.uses))].sort();
        const dependsOn = [];
        const dependsFiles = [];
        for (const usecaseId of usecaseIds) {
            const usecase = request.usecases.find(entry => entry.usecaseId === usecaseId);
            if (!usecase?.defPath)
                continue;
            dependsOn.push(pipelineId(request.project, request.moduleName, 'usecase', usecaseId));
            dependsFiles.push(qualifyDefPath(request.project, usecase.defPath));
        }
        const qualified = qualifyDefPath(request.project, item.defPath);
        const pipeline = {
            id: pipelineId(request.project, request.moduleName, 'requestService', item.pageId),
            type: 'requestService',
            defPath: qualified,
            outputPath: futureOutputPath(qualified),
            outputAvailability: 'future',
            dependsFiles,
            dependsOn,
            skills: skillPaths('requestService'),
            routes: item.requests.map(row => row.route),
        };
        item.definition = stampDefinition(item.definition, pipeline.defPath, pipeline.dependsFiles);
        const rendered = renderDefinition(item.definition, pipeline.defPath);
        if ('issues' in rendered) {
            error(problems, 'DEFINITION', item.defPath, rendered.issues[0] || 'Definition did not render.');
            item.definition = null;
            continue;
        }
        out.push({ definition: item.definition, pipeline: [pipeline] });
    }
    return out;
}
function fillDefinition(request, item, problems) {
    if (item.handlers.some(handler => handler.grantIds.length === 0))
        return;
    const data = {
        pageId: item.pageId,
        handlers: item.handlers.map(handler => ({
            route: handler.route,
            kind: handler.kind,
            grantIds: handler.grantIds,
            serviceFunction: handler.serviceFunction,
            contractPath: handler.contractPath,
            contractInterface: handler.contractInterface,
        })),
    };
    const definition = pendingDefinition('httpController', item.pageId, request.moduleName, data);
    const issues = definitionIssues(definition);
    if (issues.length) {
        error(problems, 'DEFINITION', item.pageId, issues[0]);
        return;
    }
    item.definition = definition;
}
function emitItems(request, items, problems) {
    const out = [];
    for (const item of items) {
        if (!item.definition)
            continue;
        const pipeline = pipelineFor(request, item);
        const leaked = pipeline.dependsFiles.filter(file => file.includes('/l2/') || file.includes('/adapters/persistence/') || file.includes('/layer_3_'));
        if (leaked.length) {
            error(problems, 'RUNTIME_IMPORT', item.pageId, `Controller depends on ${leaked[0]}.`);
            continue;
        }
        item.definition = stampDefinition(item.definition, pipeline.defPath, pipeline.dependsFiles);
        const rendered = renderDefinition(item.definition, pipeline.defPath);
        if ('issues' in rendered) {
            error(problems, 'DEFINITION', item.defPath, rendered.issues[0] || 'Definition did not render.');
            continue;
        }
        if (/\bimport\b/.test(rendered.source)) {
            error(problems, 'RUNTIME_IMPORT', item.pageId, 'Controller source imports a module.');
            continue;
        }
        out.push({ definition: item.definition, pipeline: [pipeline] });
    }
    return out;
}
function pipelineFor(request, item) {
    const qualified = qualifyDefPath(request.project, item.defPath);
    const dependsOn = [];
    const dependsFiles = [];
    const serviceLogical = `l1/${request.moduleName}/layer_2_application/requests/${item.pageId}.defs.ts`;
    dependsOn.push(pipelineId(request.project, request.moduleName, 'requestService', item.pageId));
    dependsFiles.push(qualifyDefPath(request.project, serviceLogical));
    const scopeLogical = `l1/${request.moduleName}/layer_2_application/scope/accessScope.defs.ts`;
    dependsOn.push(pipelineId(request.project, request.moduleName, 'accessScope', 'accessScope'));
    dependsFiles.push(qualifyDefPath(request.project, scopeLogical));
    // A route with grants resolves its actor through the authority map (support70 writes it).
    if (item.handlers.some(handler => handler.grantIds.length > 0)) {
        const authorityLogical = `l1/${request.moduleName}/layer_1_external/auth/authorityMap.defs.ts`;
        dependsOn.push(pipelineId(request.project, request.moduleName, 'authorityMap', 'authorityMap'));
        dependsFiles.push(qualifyDefPath(request.project, authorityLogical));
    }
    return {
        id: pipelineId(request.project, request.moduleName, 'httpController', item.pageId),
        type: 'httpController',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles,
        dependsOn,
        skills: skillPaths('httpController'),
        routes: item.handlers.map(handler => handler.route),
    };
}
function pageFor(request, pageId) {
    return request.pages.find(item => item.pageId === pageId) || {
        pageId,
        actors: [],
        defPath: `l1/${request.moduleName}/layer_1_external/adapters/http/controllers/${pageId}.defs.ts`,
    };
}
function mapKind(kind) {
    if (kind === 'qry' || kind === 'query')
        return 'query';
    if (kind === 'cmd' || kind === 'command')
        return 'command';
    return '';
}
function unconsumedEnumerations(request) {
    return request.enumerations.map(item => ({
        entityId: item.entityId,
        path: item.path,
        values: [...item.values],
        consumed: false,
        source: ENUMERATION_SOURCE,
        reason: ENUMERATION_REASON,
    }));
}
function finish(request, ok, enumerations, controllers, services, problems, normalizations, emit) {
    if (!normalizations.some(item => item.code === 'ENUMERATIONS_NOT_CONSUMED')) {
        normalizations.push({
            code: 'ENUMERATIONS_NOT_CONSUMED',
            path: ENUMERATION_SOURCE,
            detail: enumerations.length
                ? `${enumerations.length} enum values stay on the domain draft. controllers60 does not copy them.`
                : 'The domain draft has no enumerations. controllers60 did not invent any.',
        });
    }
    sortInPlace(enumerations, item => `${item.entityId}\u0000${item.path}`);
    sortInPlace(problems, item => `${item.path}\u0000${item.code}\u0000${item.message}`);
    sortInPlace(normalizations, item => `${item.path}\u0000${item.code}`);
    controllers.sort((left, right) => left.pageId.localeCompare(right.pageId));
    services.sort((left, right) => left.pageId.localeCompare(right.pageId));
    emit.sort((left, right) => (left.pipeline[0]?.defPath || '').localeCompare(right.pipeline[0]?.defPath || ''));
    const removals = controllerRemovals(request, controllers);
    return {
        schemaVersion: D1_CONTROLLER_VERSION,
        project: request.project,
        moduleName: request.moduleName,
        llmCalls: 0,
        ok,
        measuredRoutes: (request.serviceRequests || []).length,
        measuredPages: new Set((request.serviceRequests || []).map(item => item.pageId)).size,
        enumerations,
        controllers,
        services,
        problems,
        normalizations,
        emit,
        removals,
    };
}
function controllerRemovals(request, controllers) {
    const live = new Set(controllers.filter(item => item.handlers.length > 0).map(item => logicalController(item.defPath)));
    const out = [];
    for (const route of request.removedRoutes || []) {
        if (!route.defPath)
            continue;
        const logical = logicalController(route.defPath);
        if (live.has(logical) || out.some(item => logicalController(item.defPath) === logical))
            continue;
        const qualified = route.defPath.startsWith('_') ? route.defPath : qualifyDefPath(request.project, route.defPath);
        out.push({
            defPath: route.defPath,
            contentHash: route.contentHash,
            outputTs: [futureOutputPath(qualified)].filter(path => path.endsWith('.ts')),
        });
    }
    return out;
}
function logicalController(defPath) {
    return defPath.replace(/^_\d+_\/l1\//, 'l1/');
}
function error(problems, code, path, message) {
    problems.push({ severity: 'error', code, path, message });
}
function review(problems, code, path, message) {
    problems.push({ severity: 'review', code, path, message });
}
function sortInPlace(items, key) {
    items.sort((left, right) => key(left).localeCompare(key(right)));
}
