/// <mls fileReference="_102021_/l2/agentDefsL1/steps/controllers60/gate.ts" enhancement="_blank"/>
import { definitionIssues, pendingDefinition, } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { futureOutputPath, pipelineId, qualifyDefPath, requestServiceDefPath, skillPaths, } from '/_102021_/l2/agentDefsL1/helpers/d1Refs.js';
import { renderDefinition, stampDefinition } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { isSafeToken } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { contractInterfaceName, fieldsByEntity, isRouteGap, readContractV2, requestServiceProblems, serviceRowsFor, usecaseIdsWithDef, } from '/_102021_/l2/agentDefsL1/steps/controllers60/requestService.js';
import { nodeDisclosure } from '/_102021_/l2/helpers/l1Defs/disclosure.js';
import { elementPath, outputViews } from '/_102021_/l2/helpers/l1Defs/requestTree.js';
import { worstOfList } from '/_102021_/l2/agentDefsL1/steps/input20/gate.js';
import { D1_CONTROLLER_VERSION, ENUMERATION_REASON, ENUMERATION_SOURCE, HANDLER_STEPS, } from '/_102021_/l2/agentDefsL1/steps/controllers60/contracts.js';
/**
 * One controller per page. Ids, route strings and contract symbols are copied.
 * An operation with no grant is an error. There is no public fallback.
 */
export function buildD1Controllers(request) {
    const problems = [];
    const normalizations = [];
    const enumerations = unconsumedEnumerations(request);
    if (!request.accessRead) {
        error(problems, 'ACCESS_UNREADABLE', 'access', 'Access artifact did not parse. No grant was assumed.');
    }
    if (!request.actorsRead) {
        error(problems, 'ACTORS_UNREADABLE', 'needs', 'Page actors did not parse. No actor was assumed.');
    }
    const services = requestServices(request, problems);
    const byPage = new Map();
    for (const service of services) {
        for (const row of service.requests) {
            // A route without authority is declared on the request service and has no handler (s0b).
            if (isRouteGap(row))
                continue;
            const route = {
                route: row.route,
                page: service.pageId,
                kind: row.kind,
                usecaseRef: '',
                status: routeStatus(request, row.uses),
            };
            const binding = bindAdapter(request, route, row, problems);
            const list = byPage.get(service.pageId) || [];
            list.push(binding);
            byPage.set(service.pageId, list);
        }
    }
    const controllers = [];
    for (const [pageId, handlers] of byPage) {
        const page = pageFor(request, pageId);
        handlers.sort((left, right) => left.route.localeCompare(right.route));
        const staleRoutes = staleOf(request, pageId, liveRoutes(pageId, services), problems);
        const item = { pageId, defPath: page.defPath, handlers, staleRoutes, definition: null };
        if (!isSafeToken(pageId)) {
            error(problems, 'PAGE_ID', pageId, `Page ${pageId} is not a safe token. No controller file was named.`);
        }
        controllers.push(item);
    }
    const ok = !problems.some(problem => problem.severity === 'error');
    const before = problems.length;
    if (ok) {
        for (const item of controllers)
            fillDefinition(request, item, problems);
    }
    const stillOk = ok && problems.length === before;
    const emit = stillOk ? emitItems(request, controllers, problems) : [];
    if (stillOk)
        emit.push(...emitServices(request, services, problems));
    const emitted = stillOk && !problems.some(problem => problem.severity === 'error') ? emit : [];
    return finish(request, emitted.length > 0 && !problems.some(problem => problem.severity === 'error'), enumerations, controllers, services, problems, normalizations, emitted);
}
/** A grant whose actor is not on this page is a union. The caller does not add it. */
export function grantUnionIssues(pageActors, grantIds, grants) {
    const actors = new Set(pageActors);
    const issues = [];
    for (const grantId of grantIds) {
        const grant = grants.find(item => item.grantId === grantId);
        if (grant && !actors.has(grant.actorRef))
            issues.push(grantId);
    }
    return issues;
}
const ROUTE_GAP_CODES = new Set(['NO_AUTHORITY', 'AUTHORITY_REQUIRED', 'CONTRACT_ACCESS_DIVERGENT']);
/** Grant ids already resolved while sealing the request-service row, before the handler is bound. */
const sealedRoute = new WeakMap();
/**
 * Route-scoped gaps (s0b), written on the row before the request service def is filled.
 * A refused field leaves the projection and becomes `unresolved`. No authority collapses the route
 * to one `unresolved` node and `isRouteGap` then skips the handler.
 */
function sealRoute(request, route, row, problems) {
    const path = route.route;
    const page = pageFor(request, route.page);
    const kind = mapKind(route.kind);
    const contract = request.contracts.find(item => item.pageId === route.page);
    const entities = [];
    for (const usecaseId of row.uses) {
        const usecase = request.usecases.find(item => item.usecaseId === usecaseId);
        if (usecase && !entities.includes(usecase.entity))
            entities.push(usecase.entity);
    }
    const ownerless = row.output.flatMap(node => node.kind === 'computed' && !node.entity ? [node.path] : []);
    const routeGrants = ownerless.length ? routeGrantIds(request, contract?.source || '', path, page, problems) : [];
    const matched = entities.length === 0 ? [...routeGrants] : [];
    for (const entity of entities) {
        for (const grant of matchingGrants(page.actors, entity, request.grants)) {
            if (!matched.includes(grant.grantId))
                matched.push(grant.grantId);
        }
    }
    const kept = finishGrants(request, route, kind, matched, existing => existing.serviceFunction === row.route, problems);
    if (ownerless.length && !kept.grantIds.some(grantId => routeGrants.includes(grantId))) {
        review(problems, 'NO_AUTHORITY', path, `NO_AUTHORITY: ${path} ${ownerless.join(', ')} has no entity, and no route grant valid in the L4 access artifact covers it. No permissive fallback was applied.`);
    }
    const ownerlessOnly = ownerless.length > 0 && entities.length === 0;
    if (ownerlessOnly) {
        // No entity to cover: the authority is the route grants checked above.
    }
    else if (!kept.preserved) {
        const uncovered = entities.filter(entity => matchingGrants(page.actors, entity, request.grants).length === 0);
        const missing = entities.length === 0 ? [path] : uncovered;
        for (const entity of missing) {
            review(problems, 'AUTHORITY_REQUIRED', path, `Operation ${entity} on ${path} has no authority. No permissive fallback was applied.`);
        }
    }
    else if (kept.grantIds.length === 0) {
        review(problems, 'AUTHORITY_REQUIRED', path, `Operation ${path} has no authority. No permissive fallback was applied.`);
    }
    const attached = grantsOnPage(page, kept.grantIds, request);
    const projected = [];
    const refused = [];
    for (const view of outputViews(row.output)) {
        const disclosed = discloseProjection(view, attached, entity => request.ontology?.[entity]);
        if (disclosed.blocked.length || disclosed.opaque.length) {
            const message = disclosureMessage(path, disclosed.blocked, disclosed.opaque);
            review(problems, 'DISCLOSURE', path, message);
            for (const field of [...disclosed.blocked, ...disclosed.opaque])
                refused.push({ field, reason: `DISCLOSURE: ${message}` });
        }
        for (const field of disclosed.computed) {
            const message = `COMPUTED_NOT_DISCLOSED: ${path} ${field}`;
            review(problems, 'COMPUTED_NOT_DISCLOSED', path, message);
            refused.push({ field, reason: message });
        }
        const refusedFields = new Set(refused.map(item => item.field));
        for (const field of view.fields)
            if (!refusedFields.has(field))
                projected.push(field);
    }
    stripRefused(row, refused);
    const routeGaps = problems.filter(item => item.path === path && ROUTE_GAP_CODES.has(item.code));
    if (routeGaps.length) {
        const reason = routeGaps.map(item => item.message.startsWith(item.code) ? item.message : `${item.code}: ${item.message}`).join(' ');
        row.output = [{ kind: 'unresolved', path: row.route, reason }];
    }
    const sealed = { grantIds: kept.grantIds, preserved: kept.preserved, projected: routeGaps.length ? [] : projected };
    sealedRoute.set(row, sealed);
    return sealed;
}
function stripRefused(row, refused) {
    if (!refused.length)
        return;
    const pending = new Map(refused.map(item => [item.field, item.reason]));
    const kept = [];
    for (const node of row.output) {
        if (node.kind === 'unresolved') {
            kept.push(node);
            continue;
        }
        if (node.kind === 'computed') {
            const key = node.path.split('.')[0];
            const field = pathFrom(node.path, key) || key;
            const reason = pending.get(field);
            if (reason) {
                pending.delete(field);
                kept.push({ kind: 'unresolved', path: node.path, reason });
                continue;
            }
            kept.push(node);
            continue;
        }
        const key = node.path.split('.')[0];
        const prefix = pathFrom(elementPath(node), key);
        node.fields = node.fields.filter(item => {
            const field = prefix ? `${prefix}.${item.field}` : item.field;
            const reason = pending.get(field);
            if (!reason)
                return true;
            pending.delete(field);
            const path = field === key || field.startsWith(`${key}.`) ? field : `${key}.${field}`;
            kept.push({ kind: 'unresolved', path, reason });
            return false;
        });
        kept.push(node);
    }
    for (const [field, reason] of pending)
        kept.push({ kind: 'unresolved', path: field, reason });
    row.output = kept;
}
function pathFrom(path, key) {
    if (path === key)
        return '';
    return path.startsWith(`${key}.`) ? path.slice(key.length + 1) : path;
}
/** v2 page: the handler calls one request-service function. It does not name a usecase. */
function bindAdapter(request, route, row, problems) {
    const path = route.route;
    const page = pageFor(request, route.page);
    const kind = mapKind(route.kind);
    const contract = request.contracts.find(item => item.pageId === route.page);
    const contractPath = contract?.path || `l2/${request.moduleName}/web/contracts/${route.page}.defs.ts`;
    const contractInterface = contract ? contractInterfaceName(contract.source) : '';
    const serviceFunction = row.route;
    if (!kind)
        error(problems, 'KIND', path, `Route ${path} kind ${route.kind} is not query or command.`);
    if (!contractInterface) {
        error(problems, 'INVALID_REF', path, `Route ${path} has no contract interface.`);
    }
    const kept = sealedRoute.get(row) || sealRoute(request, route, row, problems);
    const attached = grantsOnPage(page, kept.grantIds, request);
    const projected = kept.projected;
    return {
        route: route.route,
        pageId: route.page,
        kind: kind || 'query',
        usecaseId: '',
        functionName: '',
        serviceFunction,
        contractPath,
        contractInterface,
        inputSymbol: '',
        outputSymbol: '',
        status: route.status,
        preserved: kept.preserved,
        grantIds: kept.grantIds,
        projection: { shape: projected.length ? 'object' : 'unresolved', fields: projected, envelope: 'passthrough' },
        session: 'verified',
        steps: HANDLER_STEPS,
        scopePlan: scopePlans(attached, request.relationships, problems, path),
    };
}
/**
 * The grants a route declares (`access.grants`) that the L4 access artifact has, for an actor of this page and of the
 * route. L4 stays the source: a route grant it does not have, or of an actor that does not match, is an error here
 * (`CONTRACT_ACCESS_DIVERGENT`). The actor list is compared only when the parser split it into ids (as input20 does);
 * a grant id that is not an id is refused.
 */
function routeGrantIds(request, source, path, page, problems) {
    const access = readContractV2(source)?.routes.find(item => item.route === path)?.access;
    if (!access)
        return [];
    const actorsSplit = access.actors.every(actor => isSafeToken(actor));
    const valid = [];
    for (const grantId of access.grants) {
        const grant = isSafeToken(grantId) ? request.grants.find(item => item.grantId === grantId) : undefined;
        if (!grant) {
            review(problems, 'CONTRACT_ACCESS_DIVERGENT', path, `CONTRACT_ACCESS_DIVERGENT: ${path} grant ${grantId} is not in the L4 access artifact. L4 stays the source.`);
            continue;
        }
        if (!page.actors.includes(grant.actorRef) || (actorsSplit && !access.actors.includes(grant.actorRef))) {
            review(problems, 'CONTRACT_ACCESS_DIVERGENT', path, `CONTRACT_ACCESS_DIVERGENT: ${path} grant ${grantId} is for actor ${grant.actorRef}, who is not an actor of this route and page. L4 stays the source.`);
            continue;
        }
        if (!valid.includes(grantId))
            valid.push(grantId);
    }
    return valid;
}
function grantsOnPage(page, grantIds, request) {
    return grantIds.flatMap(grantId => {
        const grant = request.grants.find(item => item.grantId === grantId);
        return grant && page.actors.includes(grant.actorRef) ? [grant] : [];
    });
}
function finishGrants(request, route, kind, matched, sameHandler, problems) {
    const path = route.route;
    const page = pageFor(request, route.page);
    let grantIds = [...matched];
    let preserved = false;
    if (route.status === 'done') {
        const existing = existingHandler(request, route);
        if (!existing) {
            error(problems, 'HANDLER_MISSING', path, `Done route ${path} has no handler to keep.`);
        }
        else if (!sameHandler(existing) || existing.kind !== (kind || 'query')) {
            error(problems, 'STALE_ARTIFACT', path, `Done route ${path} does not match the handler on disk.`);
        }
        else {
            preserved = true;
            grantIds = [...existing.grantIds];
            const union = grantUnionIssues(page.actors, grantIds, request.grants);
            if (union.length) {
                error(problems, 'GRANT_UNION', path, `Done route ${path} keeps a grant of another page: ${union.join(', ')}.`);
            }
            for (const grantId of grantIds) {
                if (!request.grants.some(item => item.grantId === grantId)) {
                    error(problems, 'INVALID_REF', path, `Grant ${grantId} on ${path} is not in the access artifact.`);
                }
            }
        }
    }
    else {
        const union = grantUnionIssues(page.actors, grantIds, request.grants);
        if (union.length) {
            error(problems, 'GRANT_UNION', path, `Route ${path} would take a grant of another page: ${union.join(', ')}.`);
        }
    }
    return { grantIds, preserved };
}
/**
 * A handler is done only when every usecase it calls is done (the rule input20 uses for the
 * controller file). A request that calls no selected usecase is new.
 */
function routeStatus(request, uses) {
    const statuses = uses.flatMap(usecaseId => {
        const usecase = request.usecases.find(item => item.usecaseId === usecaseId);
        return usecase ? [usecase.status] : [];
    });
    return statuses.length === uses.length && uses.length > 0 ? worstOfList(statuses) : 'toCreate';
}
function liveRoutes(pageId, services) {
    const rows = services.find(item => item.pageId === pageId)?.requests || [];
    return new Set(rows.map(row => row.route));
}
function matchingGrants(actors, entity, grants) {
    const allowed = new Set(actors);
    return grants.filter(grant => allowed.has(grant.actorRef) && grant.entityRefs.includes(entity));
}
/**
 * Each projected path goes through the shared rule (`helpers/l1Defs/disclosure.ts`), the same one
 * the M1 request service applies, on the node the derived route classified (d1_63): an entity path by its ontology
 * path and the grants about that entity, a calculated value only under `fullRecord`, a paging key always.
 * `Entity.details.identification` covers that branch and its descendants, not the parent `details` nor a sibling.
 * A refused path is not projected: it becomes an `unresolved` node (s0b).
 */
function discloseProjection(output, grants, entityDefinition) {
    const blocked = [];
    const opaque = [];
    const computed = [];
    for (const node of output.disclosure) {
        const verdict = nodeDisclosure(grants, node, entityDefinition);
        if (verdict === 'blocked')
            blocked.push(node.field);
        else if (verdict === 'carrier')
            opaque.push(node.field);
        else if (verdict === 'computed')
            computed.push(node.field);
    }
    return { blocked, opaque, computed };
}
function disclosureMessage(route, blocked, opaque) {
    const parts = [];
    if (blocked.length) {
        parts.push(`Route ${route} projects ${blocked.join(', ')}, which this page's grants do not disclose.`);
    }
    if (opaque.length) {
        parts.push(`Route ${route} projects ${opaque.join(', ')}. A grant names a sub-path, but the nested shape could not be read, so the container was not released.`);
    }
    return parts.join(' ');
}
function scopePlans(grants, relationships, problems, path) {
    return grants.map(grant => {
        const rels = relationships
            .filter(rel => grant.entityRefs.includes(rel.from))
            .map(rel => ({ relationshipId: rel.relationshipId, from: rel.from, to: rel.to, field: rel.field }));
        let pending = '';
        if (grant.anchorEntity && !grant.entityRefs.includes(grant.anchorEntity)) {
            const others = relationships.filter(rel => rel.required && grant.entityRefs.includes(rel.from) && rel.to && rel.to !== grant.anchorEntity);
            if (others.length) {
                pending = 'ACCESS_ANCHOR';
                review(problems, 'ACCESS_ANCHOR', path, `Grant ${grant.grantId} anchors on ${grant.anchorEntity}. Relationship ${others.map(rel => rel.relationshipId).join(', ')} binds another required target.`);
            }
        }
        return {
            grantId: grant.grantId,
            actorRef: grant.actorRef,
            entityRefs: [...grant.entityRefs],
            disclosure: grant.disclosure,
            allowedFields: [...grant.allowedFields],
            anchorEntity: grant.anchorEntity,
            relationships: rels,
            pending,
            emittedBy: 'support70',
        };
    });
}
function existingHandler(request, route) {
    const page = request.existing.find(item => item.pageId === route.page);
    if (!page || page.unreadable)
        return null;
    return page.handlers.find(item => item.route === route.route) || null;
}
function staleOf(request, pageId, selected, problems) {
    const existing = request.existing.find(item => item.pageId === pageId);
    if (!existing)
        return [];
    if (existing.unreadable) {
        error(problems, 'STALE_ARTIFACT', pageId, `Controller ${pageId} did not parse. Nothing was overwritten.`);
        return [];
    }
    const removed = new Set((request.removedRoutes || []).map(route => route.route));
    const extra = existing.routes.filter(route => !selected.has(route) && !removed.has(route));
    for (const route of extra) {
        error(problems, 'STALE_ARTIFACT', pageId, `Controller ${pageId} still has route ${route}, which is not selected.`);
    }
    return extra;
}
function requestServices(request, problems) {
    const selected = request.serviceRequests || [];
    const knownFields = fieldsByEntity(request.ontology || {});
    const usecaseIds = usecaseIdsWithDef(request);
    const services = [];
    for (const contract of request.contracts) {
        const parsed = readContractV2(contract.source);
        if (!parsed || parsed.pageId !== contract.pageId) {
            error(problems, 'CONTRACT_UNPARSED', contract.path, parsed
                ? `L2 contract ${contract.path} names page ${parsed.pageId}, not ${contract.pageId}. No handler was planned.`
                : `L2 contract ${contract.path} is not a readable v2 contract. No handler was planned.`);
            continue;
        }
        const pageSelected = selected.filter(item => item.pageId === contract.pageId);
        const selectedCounts = new Map();
        for (const item of pageSelected)
            selectedCounts.set(item.route, (selectedCounts.get(item.route) || 0) + 1);
        const built = serviceRowsFor(contract.pageId, parsed, pageSelected);
        problems.push(...built.problems);
        const check = {
            pageId: contract.pageId,
            contractRoutes: built.routes,
            requests: built.rows,
            usecaseIds,
            fieldsByEntity: knownFields,
            selectedCounts,
        };
        // Fields first, then authority (which may collapse the route), then the handler count, which dispenses a route gap.
        const fieldProblems = requestServiceProblems({ ...check, part: 'fields' });
        problems.push(...fieldProblems);
        for (const row of built.rows) {
            const route = {
                route: row.route,
                page: contract.pageId,
                kind: row.kind,
                usecaseRef: '',
                status: routeStatus(request, row.uses),
            };
            sealRoute(request, route, row, problems);
        }
        const pageProblems = requestServiceProblems({ ...check, part: 'handlers' });
        problems.push(...pageProblems);
        const defPath = requestServiceDefPath(request.moduleName, contract.pageId);
        const item = { pageId: contract.pageId, defPath, requests: built.rows, definition: null };
        if (!isSafeToken(contract.pageId)) {
            error(problems, 'PAGE_ID', contract.pageId, `Page ${contract.pageId} is not a safe token. No request service file was named.`);
        }
        const blocked = [...built.problems, ...fieldProblems, ...pageProblems].some(problem => problem.severity === 'error') || !isSafeToken(contract.pageId);
        if (!blocked)
            fillService(request, item, problems);
        services.push(item);
    }
    return services;
}
function fillService(request, item, problems) {
    const usecaseIds = [...new Set(item.requests.flatMap(row => row.uses))].sort();
    const dependencies = [];
    for (const usecaseId of usecaseIds) {
        const usecase = request.usecases.find(entry => entry.usecaseId === usecaseId);
        if (!usecase?.defPath)
            continue;
        dependencies.push(qualifyDefPath(request.project, usecase.defPath));
    }
    dependencies.sort();
    const definition = pendingDefinition('requestService', item.pageId, request.moduleName, {
        pageId: item.pageId,
        requests: item.requests,
    }, dependencies);
    const issues = definitionIssues(definition);
    if (issues.length) {
        error(problems, 'DEFINITION', item.pageId, issues[0]);
        return;
    }
    item.definition = definition;
}
function emitServices(request, services, problems) {
    const out = [];
    for (const item of services) {
        if (!item.definition)
            continue;
        const usecaseIds = [...new Set(item.requests.flatMap(row => row.uses))].sort();
        const dependsOn = [];
        const dependsFiles = [];
        for (const usecaseId of usecaseIds) {
            const usecase = request.usecases.find(entry => entry.usecaseId === usecaseId);
            if (!usecase?.defPath)
                continue;
            dependsOn.push(pipelineId(request.project, request.moduleName, 'usecase', usecaseId));
            dependsFiles.push(qualifyDefPath(request.project, usecase.defPath));
        }
        const qualified = qualifyDefPath(request.project, item.defPath);
        const pipeline = {
            id: pipelineId(request.project, request.moduleName, 'requestService', item.pageId),
            type: 'requestService',
            defPath: qualified,
            outputPath: futureOutputPath(qualified),
            outputAvailability: 'future',
            dependsFiles,
            dependsOn,
            skills: skillPaths('requestService'),
            routes: item.requests.map(row => row.route),
        };
        item.definition = stampDefinition(item.definition, pipeline.defPath, pipeline.dependsFiles);
        const rendered = renderDefinition(item.definition, pipeline.defPath);
        if ('issues' in rendered) {
            error(problems, 'DEFINITION', item.defPath, rendered.issues[0] || 'Definition did not render.');
            item.definition = null;
            continue;
        }
        out.push({ definition: item.definition, pipeline: [pipeline] });
    }
    return out;
}
function fillDefinition(request, item, problems) {
    if (item.handlers.some(handler => handler.grantIds.length === 0))
        return;
    const data = {
        pageId: item.pageId,
        handlers: item.handlers.map(handler => ({
            route: handler.route,
            kind: handler.kind,
            grantIds: handler.grantIds,
            serviceFunction: handler.serviceFunction,
            contractPath: handler.contractPath,
            contractInterface: handler.contractInterface,
        })),
    };
    const definition = pendingDefinition('httpController', item.pageId, request.moduleName, data);
    const issues = definitionIssues(definition);
    if (issues.length) {
        error(problems, 'DEFINITION', item.pageId, issues[0]);
        return;
    }
    item.definition = definition;
}
function emitItems(request, items, problems) {
    const out = [];
    for (const item of items) {
        if (!item.definition)
            continue;
        const pipeline = pipelineFor(request, item);
        const leaked = pipeline.dependsFiles.filter(file => file.includes('/l2/') || file.includes('/adapters/persistence/') || file.includes('/layer_3_'));
        if (leaked.length) {
            error(problems, 'RUNTIME_IMPORT', item.pageId, `Controller depends on ${leaked[0]}.`);
            continue;
        }
        item.definition = stampDefinition(item.definition, pipeline.defPath, pipeline.dependsFiles);
        const rendered = renderDefinition(item.definition, pipeline.defPath);
        if ('issues' in rendered) {
            error(problems, 'DEFINITION', item.defPath, rendered.issues[0] || 'Definition did not render.');
            continue;
        }
        if (/\bimport\b/.test(rendered.source)) {
            error(problems, 'RUNTIME_IMPORT', item.pageId, 'Controller source imports a module.');
            continue;
        }
        out.push({ definition: item.definition, pipeline: [pipeline] });
    }
    return out;
}
function pipelineFor(request, item) {
    const qualified = qualifyDefPath(request.project, item.defPath);
    const dependsOn = [];
    const dependsFiles = [];
    const serviceLogical = requestServiceDefPath(request.moduleName, item.pageId);
    dependsOn.push(pipelineId(request.project, request.moduleName, 'requestService', item.pageId));
    dependsFiles.push(qualifyDefPath(request.project, serviceLogical));
    const scopeLogical = `l1/${request.moduleName}/layer_2_application/scope/accessScope.defs.ts`;
    dependsOn.push(pipelineId(request.project, request.moduleName, 'accessScope', 'accessScope'));
    dependsFiles.push(qualifyDefPath(request.project, scopeLogical));
    // A route with grants resolves its actor through the authority map (support70 writes it).
    if (item.handlers.some(handler => handler.grantIds.length > 0)) {
        const authorityLogical = `l1/${request.moduleName}/layer_1_external/auth/authorityMap.defs.ts`;
        dependsOn.push(pipelineId(request.project, request.moduleName, 'authorityMap', 'authorityMap'));
        dependsFiles.push(qualifyDefPath(request.project, authorityLogical));
    }
    return {
        id: pipelineId(request.project, request.moduleName, 'httpController', item.pageId),
        type: 'httpController',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles,
        dependsOn,
        skills: skillPaths('httpController'),
        routes: item.handlers.map(handler => handler.route),
    };
}
function pageFor(request, pageId) {
    return request.pages.find(item => item.pageId === pageId) || {
        pageId,
        actors: [],
        defPath: `l1/${request.moduleName}/layer_1_external/adapters/http/controllers/${pageId}.defs.ts`,
    };
}
function mapKind(kind) {
    if (kind === 'qry' || kind === 'query')
        return 'query';
    if (kind === 'cmd' || kind === 'command')
        return 'command';
    return '';
}
function unconsumedEnumerations(request) {
    return request.enumerations.map(item => ({
        entityId: item.entityId,
        path: item.path,
        values: [...item.values],
        consumed: false,
        source: ENUMERATION_SOURCE,
        reason: ENUMERATION_REASON,
    }));
}
function finish(request, ok, enumerations, controllers, services, problems, normalizations, emit) {
    if (!normalizations.some(item => item.code === 'ENUMERATIONS_NOT_CONSUMED')) {
        normalizations.push({
            code: 'ENUMERATIONS_NOT_CONSUMED',
            path: ENUMERATION_SOURCE,
            detail: enumerations.length
                ? `${enumerations.length} enum values stay on the domain draft. controllers60 does not copy them.`
                : 'The domain draft has no enumerations. controllers60 did not invent any.',
        });
    }
    sortInPlace(enumerations, item => `${item.entityId}\u0000${item.path}`);
    sortInPlace(problems, item => `${item.path}\u0000${item.code}\u0000${item.message}`);
    sortInPlace(normalizations, item => `${item.path}\u0000${item.code}`);
    controllers.sort((left, right) => left.pageId.localeCompare(right.pageId));
    services.sort((left, right) => left.pageId.localeCompare(right.pageId));
    emit.sort((left, right) => (left.pipeline[0]?.defPath || '').localeCompare(right.pipeline[0]?.defPath || ''));
    const removals = controllerRemovals(request, controllers);
    return {
        schemaVersion: D1_CONTROLLER_VERSION,
        project: request.project,
        moduleName: request.moduleName,
        llmCalls: 0,
        ok,
        measuredRoutes: (request.serviceRequests || []).length,
        measuredPages: new Set((request.serviceRequests || []).map(item => item.pageId)).size,
        enumerations,
        controllers,
        services,
        problems,
        normalizations,
        emit,
        removals,
    };
}
function controllerRemovals(request, controllers) {
    const live = new Set(controllers.filter(item => item.handlers.length > 0).map(item => logicalController(item.defPath)));
    const out = [];
    for (const route of request.removedRoutes || []) {
        if (!route.defPath)
            continue;
        const logical = logicalController(route.defPath);
        if (live.has(logical) || out.some(item => logicalController(item.defPath) === logical))
            continue;
        const qualified = route.defPath.startsWith('_') ? route.defPath : qualifyDefPath(request.project, route.defPath);
        out.push({
            defPath: route.defPath,
            contentHash: route.contentHash,
            outputTs: [futureOutputPath(qualified)].filter(path => path.endsWith('.ts')),
        });
    }
    return out;
}
function logicalController(defPath) {
    return defPath.replace(/^_\d+_\/l1\//, 'l1/');
}
function error(problems, code, path, message) {
    problems.push({ severity: 'error', code, path, message });
}
function review(problems, code, path, message) {
    problems.push({ severity: 'review', code, path, message });
}
function sortInPlace(items, key) {
    items.sort((left, right) => key(left).localeCompare(key(right)));
}
