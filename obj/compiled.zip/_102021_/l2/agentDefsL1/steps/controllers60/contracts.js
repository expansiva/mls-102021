/// <mls fileReference="_102021_/l2/agentDefsL1/steps/controllers60/contracts.ts" enhancement="_blank"/>
export const D1_CONTROLLER_VERSION = '2026-09-22-d1-controllers-v1';
/** Same trail as domain30 and usecases50. This step does not copy the values either. */
export const ENUMERATION_SOURCE = 'domain30.enumerations';
export const ENUMERATION_REASON = 'Controller projection has no values slot. Enum values stay on the domain draft.';
export const HANDLER_STEPS = ['transport', 'session', 'authorize', 'call', 'project', 'bff'];
