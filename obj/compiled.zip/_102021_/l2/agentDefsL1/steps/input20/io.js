/// <mls fileReference="_102021_/l2/agentDefsL1/steps/input20/io.ts" enhancement="_blank"/>
import { displayPath, inputFile, } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { readWriterReceipts } from '/_102021_/l2/agentDefsL1/helpers/d1Receipt.js';
import { readText, writeJson } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { D1_INPUT_VERSION, contractPath, entityPath, inputPaths, isSafeToken, journeyPath, } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { buildD1InputSnapshot, contractPageIds } from '/_102021_/l2/agentDefsL1/steps/input20/gate.js';
import { readContractAst } from '/_102021_/l2/agentDefsL1/steps/usecases50/contractsAst.js';
/** Reads the object of `export const name = { ... }` without evaluating the file. */
export function parseD1Source(text, kind) {
    const body = kind === 'json' ? text : extractDefsObject(text);
    if (!body)
        return null;
    try {
        return JSON.parse(body);
    }
    catch {
        return null;
    }
}
function extractDefsObject(source) {
    const assignment = source.search(/export\s+const\s+[A-Za-z_$][A-Za-z0-9_$]*\s*=/);
    const start = source.indexOf('{', Math.max(0, assignment));
    if (assignment < 0 || start < 0)
        return '';
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = start; index < source.length; index += 1) {
        const char = source[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === '"')
                inString = false;
            continue;
        }
        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{')
            depth += 1;
        else if (char === '}') {
            depth -= 1;
            if (depth === 0)
                return source.slice(start, index + 1);
        }
    }
    return '';
}
export async function readD1Input(project, moduleName) {
    const raw = await readText(inputFile(project, moduleName));
    if (!raw)
        return null;
    let parsed;
    try {
        parsed = JSON.parse(raw);
    }
    catch {
        return null;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        return null;
    const snapshot = parsed;
    if (snapshot.schemaVersion !== D1_INPUT_VERSION)
        return null;
    if (snapshot.project !== project || snapshot.moduleName !== moduleName)
        return null;
    return snapshot;
}
/** Reads the snapshot inputs and returns the inventory. Writes nothing. */
export async function assembleD1Input(project, moduleName) {
    const previous = await readD1Input(project, moduleName);
    const fixed = await Promise.all(fixedPaths(moduleName).map(path => loadOne(project, path)));
    const byPath = new Map(fixed.map(item => [item.path, item]));
    const journeyIndex = rec(byPath.get(inputPaths(moduleName).journeyIndex)?.parsed);
    const ontologyIndex = rec(byPath.get(inputPaths(moduleName).ontologyIndex)?.parsed);
    const dynamicPaths = [
        ...idList(journeyIndex.journeys, 'journeyId').filter(isSafeToken).map(id => journeyPath(moduleName, id)),
        ...idList(ontologyIndex.entities, 'entityId').filter(isSafeToken).map(id => entityPath(moduleName, id)),
    ];
    const dynamic = await Promise.all(dynamicPaths.map(path => loadOne(project, path)));
    const known = [...fixed, ...dynamic];
    const parsed = new Map(known.map(item => [item.path, item.parsed]));
    const paths = inputPaths(moduleName);
    const pageIds = contractPageIds({
        menu: parsed.get(paths.menu),
        needs: parsed.get(paths.needs),
        effort: parsed.get(paths.effort),
        backend: parsed.get(paths.backend),
    });
    const contracts = await Promise.all(pageIds.map(async (pageId) => {
        const path = contractPath(moduleName, pageId);
        const loaded = await loadContract(project, path);
        return { pageId, loaded };
    }));
    const contractMap = {};
    for (const contract of contracts) {
        contractMap[contract.pageId] = contract.loaded.parsed;
    }
    const loaded = contracts.map(item => item.loaded);
    const artifacts = artifactsFrom(moduleName, known, loaded, parsed, contractMap, [], []);
    const draft = seal(buildD1InputSnapshot({ project, moduleName }, artifacts, previous));
    const [present, writerReceipts] = await Promise.all([
        readPresent(project, draft.files.map(file => file.defPath)),
        readWriterReceipts(project, moduleName),
    ]);
    const sealed = seal(buildD1InputSnapshot({ project, moduleName }, artifactsFrom(moduleName, known, loaded, parsed, contractMap, present, writerReceipts), previous));
    sealed.snapshotHash = await sha256Text(stableStringify(withoutHash(sealed)));
    return sealed;
}
export async function persistD1Input(project, moduleName, snapshot) {
    const existing = await readD1Input(project, moduleName);
    if (existing?.snapshotHash && existing.snapshotHash === snapshot.snapshotHash)
        return { reused: true };
    await writeJson(inputFile(project, moduleName), snapshot);
    return { reused: false };
}
export function fileInfoFromDisplay(project, display) {
    if (!display || display.includes('..'))
        return null;
    const match = /^l(\d+)\/(.+)\/([^/]+)$/.exec(display);
    if (!match)
        return null;
    const fileName = match[3];
    const extension = fileName.endsWith('.defs.ts') ? '.defs.ts' : fileName.includes('.') ? fileName.slice(fileName.indexOf('.')) : '';
    if (!extension)
        return null;
    const shortName = fileName.slice(0, fileName.length - extension.length);
    if (!isSafeToken(shortName))
        return null;
    return {
        project,
        level: Number(match[1]),
        folder: match[2],
        shortName,
        extension,
    };
}
async function readPresent(project, defPaths) {
    const present = [];
    for (const defPath of defPaths) {
        if (!defPath.startsWith('l1/'))
            continue;
        const info = fileInfoFromDisplay(project, defPath);
        if (!info)
            continue;
        const text = await readText(info);
        if (text == null)
            continue;
        present.push({ path: defPath, sha256: await sha256Text(text) });
    }
    return present;
}
function artifactsFrom(moduleName, known, contracts, parsed, contractMap, presentDefs, writerReceipts) {
    const sources = [...known, ...contracts].map(item => item.digest).sort((left, right) => left.path.localeCompare(right.path));
    const paths = inputPaths(moduleName);
    const journeys = {};
    const entities = {};
    for (const [path, value] of parsed) {
        if (path.startsWith(`l4/${moduleName}/journeys/`) && !path.endsWith('/index.defs.ts')) {
            const id = path.split('/').pop()?.replace(/\.defs\.ts$/, '') || '';
            if (id)
                journeys[id] = value;
        }
        if (path.startsWith(`l4/${moduleName}/ontology/`) && !path.endsWith('/index.defs.ts')) {
            const id = path.split('/').pop()?.replace(/\.defs\.ts$/, '') || '';
            if (id)
                entities[id] = value;
        }
    }
    return {
        sources,
        module: parsed.get(paths.module) ?? null,
        journeyIndex: parsed.get(paths.journeyIndex) ?? null,
        journeys,
        ontologyIndex: parsed.get(paths.ontologyIndex) ?? null,
        entities,
        rules: parsed.get(paths.rules) ?? null,
        workflows: parsed.get(paths.workflows) ?? null,
        access: parsed.get(paths.access) ?? null,
        integration: parsed.get(paths.integration) ?? null,
        menu: parsed.get(paths.menu) ?? null,
        needs: parsed.get(paths.needs) ?? null,
        backend: parsed.get(paths.backend) ?? null,
        effort: parsed.get(paths.effort) ?? null,
        planner: parsed.get(paths.planner) ?? null,
        contracts: contractMap,
        presentDefs,
        writerReceipts,
    };
}
function fixedPaths(moduleName) {
    const paths = inputPaths(moduleName);
    return [
        paths.module,
        paths.journeyIndex,
        paths.ontologyIndex,
        paths.rules,
        paths.workflows,
        paths.access,
        paths.integration,
        paths.menu,
        paths.needs,
        paths.backend,
        paths.effort,
        paths.planner,
    ];
}
async function loadContract(project, path) {
    const info = fileInfoFromDisplay(project, path);
    const text = info ? await readText(info) : null;
    if (text == null) {
        return { path, text: null, parsed: null, digest: { path, sha256: '', bytes: 0, schemaVersion: '', state: 'missing' } };
    }
    const ast = readContractAst(text, path);
    const sha256 = await sha256Text(text);
    const bytes = new TextEncoder().encode(text).length;
    return {
        path,
        text,
        parsed: ast,
        digest: { path, sha256, bytes, schemaVersion: '', state: ast.unparsed.length ? 'invalid' : 'present' },
    };
}
async function loadOne(project, path) {
    const info = fileInfoFromDisplay(project, path);
    const text = info ? await readText(info) : null;
    if (text == null) {
        return { path, text: null, parsed: null, digest: { path, sha256: '', bytes: 0, schemaVersion: '', state: 'missing' } };
    }
    const kind = path.endsWith('.json') ? 'json' : 'defs';
    const parsed = parseD1Source(text, kind);
    const sha256 = await sha256Text(text);
    const bytes = new TextEncoder().encode(text).length;
    if (parsed == null) {
        return { path, text, parsed: null, digest: { path, sha256, bytes, schemaVersion: '', state: 'invalid' } };
    }
    return {
        path,
        text,
        parsed,
        digest: { path, sha256, bytes, schemaVersion: textOf(rec(parsed).schemaVersion), state: 'present' },
    };
}
function seal(snapshot) {
    return { ...snapshot, snapshotHash: '' };
}
function withoutHash(snapshot) {
    const copy = { ...snapshot };
    delete copy.snapshotHash;
    return copy;
}
export async function sha256Text(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}
function stableStringify(value) {
    if (Array.isArray(value))
        return `[${value.map(item => stableStringify(item)).join(',')}]`;
    if (value && typeof value === 'object') {
        const record = value;
        return `{${Object.keys(record).sort().map(key => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(',')}}`;
    }
    return JSON.stringify(value) ?? 'null';
}
function idList(value, key) {
    return Array.isArray(value) ? value.map(item => text(rec(item)[key])).filter(Boolean) : [];
}
function rec(value) {
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function textOf(value) {
    return text(value);
}
export function ownedInputDisplay(project, moduleName) {
    return displayPath(inputFile(project, moduleName));
}
