/// <mls fileReference="_102021_/l2/agentDefsL1/steps/input20/contracts.ts" enhancement="_blank"/>
import { L1_OPERATIONS } from '/_102021_/l2/helpers/l1Defs/operations.js';
import { catalogFilePath, externalConnectionId } from '/_102020_/l2/helpers/connections/catalogPath.js';
export const D1_INPUT_VERSION = '2026-10-01-d1-input-v2';
/** P1 operation vocabulary. Same list as `L1_OPERATIONS`. */
export const D1_P1_OPERATIONS = L1_OPERATIONS;
export const D1_SOURCE_SCHEMAS = {
    module: '2026-09-10-ns5-module-v2',
    journey: '2026-09-10-ns5-journey-v1',
    ontology: '2026-09-17-ns5-ontology-v3.1',
    rules: '2026-09-16-ns5-rules-v2',
    workflows: '2026-09-17-ns5-workflows-v3',
    access: '2026-09-12-ns5-access-v3',
    // v2 (recorded modules) and v3 (adds `connections`). A value import of the W1 constant would leave this agent's graph.
    integration: ['2026-09-12-ns5-integration-v2', '2026-11-17-ns5-integration-v3'],
    menu: '2026-09-20-p2-menu-v2.2',
    needs: '2026-09-21-p2-needs-v1',
    backend: '2026-09-21-p1-backend-v1.2',
    effort: '2026-09-21-p2-effort-v1.2',
    planner: '2026-09-20-p1-pipeline-v1',
};
/** `backend.json.testSupport[]` (p1_12). Same enums as agentPlannerL1 plan20; D1 checks, never fills. */
export const D1_TEST_SUPPORT_STATUSES = ['toCreate', 'toUpdate', 'toRemove', 'done'];
export const D1_TEST_SUPPORT_OWNERS = ['L1', 'runtime'];
export const D1_PLANNER_FLOW = 'agentPlannerL1';
export const D1_EFFORT_BACKEND_REF = 'pool/l2/web/backend.json';
export const D1_ACTIVE_STATUSES = ['toCreate', 'toUpdate', 'done'];
/** The answer that leaves a gap open. Always the last candidate. */
export const D1_GAP_NONE = 'none';
export function inputPaths(moduleName) {
    const root = `l4/${moduleName}`;
    return {
        module: `${root}/module.defs.ts`,
        journeyIndex: `${root}/journeys/index.defs.ts`,
        ontologyIndex: `${root}/ontology/index.defs.ts`,
        rules: `${root}/rules.defs.ts`,
        workflows: `${root}/workflows.defs.ts`,
        access: `${root}/access.defs.ts`,
        integration: `${root}/integration.defs.ts`,
        menu: `${root}/pool/l2/web/menu.json`,
        needs: `${root}/pool/l1/web/needs.json`,
        backend: `${root}/pool/l2/web/backend.json`,
        effort: `${root}/pool/l2/web/effort.json`,
        planner: `${root}/pool/l1/pipeline.json`,
    };
}
export function journeyPath(moduleName, journeyId) {
    return `l4/${moduleName}/journeys/${journeyId}.defs.ts`;
}
export function entityPath(moduleName, entityId) {
    return `l4/${moduleName}/ontology/${entityId}.defs.ts`;
}
export function contractPath(moduleName, pageId) {
    return `l2/${moduleName}/web/contracts/${pageId}.defs.ts`;
}
/**
 * Catalog file an entity def cites. An `external` entity names its connection by `connectionId` and nothing else
 * (no `source`, no fallback): the file is the one `catalogFilePath` gives. Any other entity cites it by `source`.
 * Empty when there is none.
 */
export function entityCatalogSource(body) {
    const record = (typeof body === 'object' && body !== null ? body : {});
    if (record.kind === 'external')
        return catalogFilePath(externalConnectionId(record));
    return typeof record.source === 'string' ? record.source.trim() : '';
}
export function isSafeToken(value) {
    return /^[A-Za-z][A-Za-z0-9_]*$/.test(value);
}
export function lowerFirst(value) {
    return value ? `${value.charAt(0).toLowerCase()}${value.slice(1)}` : value;
}
