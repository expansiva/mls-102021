/// <mls fileReference="_102021_/l2/agentDefsL1/steps/input20/deriveRequest.ts" enhancement="_blank"/>
import { ontologyFieldPaths } from '/_102021_/l2/agentDefsL1/steps/controllers60/requestService.js';
import { D1_GAP_NONE, } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
/**
 * d1_60: a contract route is read from its types, the ontology and the L4 relationships. `meta` is not read.
 * Names follow the ontology keys (d2_75), so an interface is an entity when its fields are fields of that entity.
 * What the code cannot derive is returned as `unresolved` with its path and reason; nothing is guessed.
 * d1_62: each gap also carries its closed candidates, computed by code from the types, the ontology and the route,
 * with `none` last. `applyResolutions` takes answers to those gaps and derives the route again through the same code:
 * there is no second selection. An answer outside the candidates, or `none`, leaves the gap open.
 * d1_62 r2b: a query input that does not page filters a root output. Its candidates are `<output>:<path>`, the
 * ontology paths of the output entity whose last segment is the input name; with none, the text leaves of the entity.
 * A command input is the payload, not a filter.
 */
/** A list page: `items: X[]` and at least one of these keys. */
const LIST_ITEMS = 'items';
const LIST_KEYS = ['total', 'page', 'pageSize', 'hasMore'];
/** Paging keys rendered flat next to the list in the contracts with meta: `page<List>`, `pageSize<List>`, `hasMore<List>`. `pageSize` first: `page` is its prefix. */
const FLAT_PAGING = ['pageSize', 'page', 'hasMore'];
export function deriveRequest(route, definition, entities) {
    return applyResolutions({ route, definition, entities }, []);
}
/** The route derived again with the answers as input. The one selection the input20 uses (d1_62). */
export function applyResolutions(source, answers) {
    const { route, definition, entities } = source;
    const ctx = {
        projections: new Map(definition.projections.map(item => [item.name, item.body])),
        fields: new Map(Object.entries(entities).map(([entityId, entity]) => [entityId, new Set(ontologyFieldPaths(entity))])),
        texts: new Map(Object.entries(entities).map(([entityId, entity]) => [entityId, textFieldPaths(entity)])),
        links: new Map(Object.entries(entities).map(([entityId, entity]) => [entityId, entityLinks(entity)])),
        rules: route.rules || [],
        answers: new Map(answers.map(item => [item.path, item.choice])),
        outputs: [],
        unresolved: [],
        computedBy: [],
        listIds: new Map(),
        pageKeys: new Set(),
        shadow: false,
    };
    const root = members(route.output);
    const flat = flatPaging(root);
    const flatNames = new Set([...flat.values()].flatMap(group => Object.values(group)));
    for (const member of root) {
        if (flatNames.has(member.name))
            continue;
        visit(ctx, member.name, member.type, null);
    }
    bindFlatLists(ctx, flat, root.filter(member => !flatNames.has(member.name) && interfaceRef(ctx, member.type)?.many).map(member => member.name));
    const inputs = members(route.input);
    const params = pageParams(ctx, inputs);
    if (route.kind !== 'cmd')
        params.push(...filterParams(ctx, inputs, root.filter(member => !flatNames.has(member.name)).map(member => member.name)));
    return { outputs: ctx.outputs, params, unresolved: ctx.unresolved, computedBy: ctx.computedBy };
}
function visit(ctx, key, type, parent) {
    const ref = interfaceRef(ctx, type);
    if (ref) {
        classify(ctx, key, ctx.projections.get(ref.name) || '', ref.many, parent, ref.name);
        return;
    }
    const trimmed = type.trim();
    if (trimmed.startsWith('{')) {
        classify(ctx, key, trimmed, false, parent, key);
        return;
    }
    ask(ctx, `output.${key}`, 'value', `Output ${key} is a value (${trimmed}), not an interface; no entity owns it.`, []);
}
function classify(ctx, key, body, many, parent, typeName) {
    const list = members(body);
    if (pageShape(ctx, key, list, parent, typeName))
        return;
    const leaves = [];
    const computed = [];
    const nested = [];
    collect(ctx, list, '', leaves, computed, nested);
    if (!leaves.length) {
        if (!parent && nested.length) {
            // A group of outputs, not an entity: each member is read on its own. A readonly value of the group has no owner.
            for (const path of computed) {
                const rule = ask(ctx, `output.${key}.${path}`, 'computedRule', `Interface ${typeName} groups outputs; it is not a list page (items plus paging keys), so no entity owns its readonly ${path}.`, ctx.rules);
                if (rule)
                    ctx.computedBy.push({ path: `${key}.${path}`, rule });
            }
            for (const item of nested)
                visit(ctx, `${key}.${item.path}`, item.type, null);
            return;
        }
        const rule = ask(ctx, `output.${key}`, 'computedRule', `Interface ${typeName} has no field that is not readonly, so no entity owns it.`, ctx.rules);
        if (rule)
            ctx.computedBy.push({ path: key, rule });
        return;
    }
    // A field that is in no entity may be a flattened ontology path: the candidates are the paths with the same last segment.
    const mapped = [];
    let open = false;
    const paths = leaves.map(leaf => {
        if (ownedByAny(ctx, leaf))
            return leaf;
        const choice = ask(ctx, `output.${key}.${leaf}`, 'fieldPath', `Interface ${typeName}: field ${leaf} is not a field of any entity.`, pathsEndingIn(ctx, leaf));
        if (!choice) {
            open = true;
            return leaf;
        }
        mapped.push({ field: leaf, path: choice });
        return choice;
    });
    if (open) {
        readonlyFields(ctx, key, typeName, computed, null);
        shadowNested(ctx, key, nested);
        return;
    }
    const match = matchEntity(ctx, paths);
    let chosen = match.found.length === 1 ? match.found[0] : null;
    if (!chosen) {
        const entity = ask(ctx, `output.${key}`, 'entity', `Interface ${typeName}: ${match.reason}`, match.found.map(item => item.entity));
        chosen = match.found.find(item => item.entity === entity) || null;
    }
    if (!chosen) {
        readonlyFields(ctx, key, typeName, computed, null);
        shadowNested(ctx, key, nested);
        return;
    }
    const output = { key, entity: chosen.entity, many };
    ctx.outputs.push(output);
    if (parent && !ctx.shadow) {
        const ids = relationshipIds(ctx, parent.entity, chosen.entity);
        output.parent = parent.key;
        const relationship = ids.length === 1
            ? ids[0]
            : ask(ctx, `output.${key}`, 'relationship', `${chosen.entity} inside ${parent.entity} needs one L4 relationship between them; found ${ids.length}.`, ids);
        if (relationship)
            output.relationship = relationship;
    }
    const readonly = readonlyFields(ctx, key, typeName, computed, chosen.entity);
    mapped.push(...readonly.mapped);
    const calculated = readonly.calculated;
    if (calculated.length)
        output.computed = calculated;
    if (chosen.related.length)
        output.related = chosen.related;
    if (mapped.length)
        output.mapped = mapped;
    for (const item of nested)
        visit(ctx, `${key}.${item.path}`, item.type, output);
}
/**
 * d1_63: `readonly` says only that the page does not write the value. A readonly value that is a field of the entity is
 * that field. One whose last segment names other ontology paths asks which (the `fieldPath` gap of a flattened field),
 * so it is asked in the same pass as the other gaps: with the entity still open (`entity` null) the candidates are the
 * paths of any entity, as for a flattened field; once the entity is known, only its own paths are accepted. What is
 * neither, and a gap left open or `none`, stays calculated (closed at disclosure). No choice is made by name.
 */
function readonlyFields(ctx, key, typeName, computed, entity) {
    const mapped = [];
    const calculated = [];
    const own = entity === null ? null : ctx.fields.get(entity) || new Set();
    for (const path of computed) {
        if (own ? own.has(path) : ownedByAny(ctx, path))
            continue;
        const candidates = own
            ? [...own].filter(item => item !== path && item.split('.').pop() === path.split('.').pop())
            : pathsEndingIn(ctx, path.split('.').pop() || path);
        const choice = candidates.length
            ? ask(ctx, `output.${key}.${path}`, 'fieldPath', `Interface ${typeName}: readonly ${path} is not a field of ${entity ?? 'the output entity'}; it may stand for one of its paths.`, candidates)
            : null;
        if (choice)
            mapped.push({ field: path, path: choice });
        else
            calculated.push(path);
    }
    return { mapped, calculated };
}
/**
 * The members nested in an output that is still a gap are read for their own gaps, without outputs: the answers of
 * one pass then reach them. Their relationship to the parent is asked once the parent is known.
 */
function shadowNested(ctx, key, nested) {
    if (!nested.length)
        return;
    const shadow = { ...ctx, outputs: [], computedBy: [], listIds: new Map(), shadow: true };
    const ghost = { key, entity: '', many: false };
    for (const item of nested)
        visit(shadow, `${key}.${item.path}`, item.type, ghost);
}
/**
 * A list page: one interface array and paging values. `items` plus keys that are all paging keys is a list as it is.
 * When the array has another name, or a value is a readonly key outside the paging keys, each such value asks for
 * its paging key. The items are classified either way, so their own gaps show in the same pass. False when the
 * interface is not of that shape.
 */
function pageShape(ctx, key, list, parent, typeName) {
    const arrays = list.filter(member => interfaceRef(ctx, member.type)?.many);
    const values = list.filter(member => !interfaceRef(ctx, member.type) && !member.type.trim().startsWith('{'));
    if (arrays.length !== 1 || !values.length || arrays.length + values.length !== list.length)
        return false;
    const items = arrays[0];
    const named = items.name === LIST_ITEMS;
    if (!values.every(member => member.readonly || LIST_KEYS.includes(member.name)))
        return false;
    const roles = new Map();
    let open = false;
    for (const member of values) {
        if (named && LIST_KEYS.includes(member.name)) {
            roles.set(member.name, member.name);
            continue;
        }
        const role = ask(ctx, `output.${key}.${member.name}`, 'pagingRole', `Interface ${typeName} pages ${items.name}; ${member.name} is not one of the paging keys ${LIST_KEYS.join(', ')} next to items, so the types do not say what it is.`, LIST_KEYS);
        if (!role || [...roles.values()].includes(role))
            open = true;
        else
            roles.set(member.name, role);
    }
    ctx.pageKeys.add(key);
    const itemRef = interfaceRef(ctx, items.type);
    const before = ctx.outputs.length;
    if (itemRef)
        classify(ctx, key, ctx.projections.get(itemRef.name) || '', true, parent, itemRef.name);
    const output = ctx.outputs[before];
    if (!open && output && output.key === key) {
        for (const [name, role] of [...roles].sort((left, right) => pagingOrder(left[1], right[1])))
            setPaging(output, role, name);
        ctx.listIds.set(output, key);
    }
    return true;
}
function collect(ctx, list, prefix, leaves, computed, nested) {
    for (const member of list) {
        const path = prefix ? `${prefix}.${member.name}` : member.name;
        if (interfaceRef(ctx, member.type)) {
            nested.push({ path, type: member.type });
            continue;
        }
        if (member.readonly) {
            computed.push(path);
            continue;
        }
        const type = member.type.trim();
        if (type.startsWith('{'))
            collect(ctx, members(type), path, leaves, computed, nested);
        else
            leaves.push(path);
    }
}
/**
 * The entities whose fields are all the leaves. When none, the entities that own some leaves and whose other
 * leaves each belong to exactly one entity linked to it by an N:1 relationship.
 */
function matchEntity(ctx, leaves) {
    const entityIds = [...ctx.fields.keys()].sort();
    const own = entityIds.filter(entityId => leaves.every(leaf => ctx.fields.get(entityId)?.has(leaf)));
    if (own.length) {
        return { found: own.map(entity => ({ entity, related: [] })), reason: `fields ${leaves.join(', ')} are fields of ${own.join(', ')}; the types do not say which.` };
    }
    const found = [];
    for (const entityId of entityIds) {
        const fields = ctx.fields.get(entityId) || new Set();
        const missing = leaves.filter(leaf => !fields.has(leaf));
        if (missing.length === leaves.length)
            continue;
        const related = [];
        for (const leaf of missing) {
            const owners = (ctx.links.get(entityId) || []).filter(link => link.cardinality === 'N:1' && ctx.fields.get(link.to)?.has(leaf));
            if (owners.length !== 1)
                break;
            related.push({ field: leaf, entity: owners[0].to, relationship: owners[0].relationshipId });
        }
        if (related.length === missing.length)
            found.push({ entity: entityId, related });
    }
    if (found.length) {
        return { found, reason: `fields ${leaves.join(', ')} fit ${found.map(item => item.entity).join(', ')} through N:1 relationships; the types do not say which.` };
    }
    return { found, reason: `fields ${leaves.join(', ')} are not all fields of one entity or of one entity linked to it by an N:1 relationship.` };
}
function ownedByAny(ctx, path) {
    return [...ctx.fields.values()].some(fields => fields.has(path));
}
/** Ontology paths, of any entity of the module, whose last segment is the field name. */
function pathsEndingIn(ctx, field) {
    const out = new Set();
    for (const fields of ctx.fields.values()) {
        for (const path of fields)
            if (path.split('.').pop() === field && path !== field)
                out.add(path);
    }
    return [...out];
}
/**
 * The answer to the gap at `path` when it is one of the candidates and not `none`. Otherwise the gap is recorded,
 * with the candidates sorted and `none` last, and the result is null.
 */
function ask(ctx, path, kind, reason, candidates) {
    const choice = ctx.answers.get(path);
    if (choice !== undefined && choice !== D1_GAP_NONE && candidates.includes(choice))
        return choice;
    gap(ctx, path, kind, reason, candidates);
    return null;
}
function gap(ctx, path, kind, reason, candidates) {
    const closed = [...new Set(candidates)].filter(item => item !== D1_GAP_NONE).sort();
    ctx.unresolved.push({ path, reason, kind, candidates: [...closed, D1_GAP_NONE] });
}
function relationshipIds(ctx, left, right) {
    const ids = new Set();
    for (const link of ctx.links.get(left) || [])
        if (link.to === right)
            ids.add(link.relationshipId);
    for (const link of ctx.links.get(right) || [])
        if (link.to === left)
            ids.add(link.relationshipId);
    return [...ids].sort();
}
function flatPaging(root) {
    const groups = new Map();
    for (const member of root) {
        const prefix = FLAT_PAGING.find(item => member.name.startsWith(item) && /^[A-Z]/u.test(member.name.slice(item.length)));
        if (!prefix)
            continue;
        const suffix = member.name.slice(prefix.length);
        const group = groups.get(suffix) || {};
        group[prefix] = member.name;
        groups.set(suffix, group);
    }
    return groups;
}
/**
 * A flat list pages the one interface array of the route root. With more than one, the root arrays are the
 * candidates (by type, so the gap is complete before any other answer).
 */
function bindFlatLists(ctx, flat, arrayKeys) {
    for (const [suffix, group] of flat) {
        const names = Object.values(group).join(', ');
        const path = `output.${names}`;
        const reason = `Paging keys ${names} page one of ${arrayKeys.length} list outputs; the types do not say which.`;
        const key = arrayKeys.length === 1 ? arrayKeys[0] : ask(ctx, path, 'flatPaging', reason, arrayKeys);
        const output = key ? ctx.outputs.find(item => item.key === key && !item.parent && !ctx.listIds.has(item)) : undefined;
        if (!output) {
            // The one array, or the chosen one, is not derived: the paging keys stay a gap.
            if (key)
                gap(ctx, path, 'flatPaging', `${reason} Output ${key} is not derived.`, arrayKeys);
            continue;
        }
        for (const flatKey of FLAT_PAGING.slice().sort(pagingOrder)) {
            const name = group[flatKey];
            if (name)
                setPaging(output, flatKey, name);
        }
        ctx.listIds.set(output, suffix.charAt(0).toLowerCase() + suffix.slice(1));
        ctx.pageKeys.add(output.key);
    }
    for (const key of arrayKeys)
        if (flat.size)
            ctx.pageKeys.add(key);
}
/**
 * `page`/`pageSize` page the one list of the route; `<list>Page`/`<list>PageSize` page the list whose key ends in `<list>`.
 * Otherwise the candidates are the outputs that are list pages by type. Other inputs stay inputs.
 */
function pageParams(ctx, input) {
    const params = [];
    const lists = [...ctx.listIds.keys()];
    for (const member of input) {
        const stem = pageStem(member.name);
        if (stem === null)
            continue;
        const path = `input.${member.name}`;
        const found = stem === '' ? lists : lists.filter(output => output.key.split('.').pop() === stem);
        let target = found.length === 1 ? found[0] : undefined;
        if (!target) {
            const key = ask(ctx, path, 'pageParam', stem === ''
                ? `Page input ${member.name} pages one of ${found.length} lists; the types do not say which.`
                : `Page input ${member.name} names list ${stem}, and no list output has that key.`, [...ctx.pageKeys]);
            target = key ? lists.find(output => output.key === key) : undefined;
            // The chosen list is not derived as a list: the input stays a gap.
            if (key && !target)
                gap(ctx, path, 'pageParam', `Page input ${member.name}: list ${key} is not derived.`, [...ctx.pageKeys]);
        }
        if (!target)
            continue;
        params.push({ name: member.name, target: target.key, pages: ctx.listIds.get(target) || target.key });
    }
    return params;
}
/**
 * A query input that does not page filters one root output on one field of its entity. The candidates are
 * `<output>:<path>` for the ontology paths whose last segment is the input name (the name itself included); when
 * no output entity has one, the text leaves of those entities. An output whose entity is still a gap offers the
 * paths of each of its candidate entities, so the answers of one pass reach the filter. One candidate on a derived
 * output is the filter; otherwise it is a gap. With no field, the input stays a filter without `field`.
 */
function filterParams(ctx, input, rootKeys) {
    const targets = rootKeys.map(key => {
        const derived = ctx.outputs.find(output => output.key === key && !output.parent);
        if (derived)
            return { key, entities: [derived.entity], known: true };
        const open = ctx.unresolved.find(item => item.path === `output.${key}` && item.kind === 'entity');
        return { key, entities: (open?.candidates || []).filter(item => item !== D1_GAP_NONE), known: false };
    }).filter(target => target.entities.length);
    const params = [];
    for (const member of input) {
        if (pageStem(member.name) !== null)
            continue;
        const same = new Set();
        const texts = new Set();
        for (const target of targets) {
            for (const entity of target.entities) {
                for (const path of ctx.fields.get(entity) || [])
                    if (path.split('.').pop() === member.name)
                        same.add(`${target.key}:${path}`);
                for (const path of ctx.texts.get(entity) || [])
                    texts.add(`${target.key}:${path}`);
            }
        }
        const candidates = [...(same.size ? same : texts)];
        const only = candidates.length === 1 && targets.find(target => target.known && candidates[0].startsWith(`${target.key}:`));
        const choice = only
            ? candidates[0]
            : ask(ctx, `input.${member.name}`, 'filterField', same.size
                ? `Input ${member.name} names a field of more than one output entity; the types do not say which it filters.`
                : `Input ${member.name} is not the last segment of any field of the output entities; it filters one of their text fields.`, candidates);
        const split = choice ? choice.indexOf(':') : -1;
        if (choice && split > 0) {
            params.push({ name: member.name, target: choice.slice(0, split), field: choice.slice(split + 1) });
            continue;
        }
        params.push({ name: member.name, target: targets.length === 1 ? targets[0].key : '' });
    }
    return params;
}
function pageStem(name) {
    if (name === 'page' || name === 'pageSize')
        return '';
    if (name.endsWith('PageSize'))
        return name.slice(0, -'PageSize'.length);
    if (name.endsWith('Page'))
        return name.slice(0, -'Page'.length);
    return null;
}
function setPaging(output, key, name) {
    if (key === 'page')
        output.page = name;
    else if (key === 'pageSize')
        output.pageSize = name;
    else if (key === 'hasMore')
        output.hasMore = name;
    else if (key === 'total')
        output.total = name;
}
function pagingOrder(left, right) {
    return LIST_KEYS.indexOf(left) - LIST_KEYS.indexOf(right);
}
function interfaceRef(ctx, type) {
    const found = /^([A-Z][A-Za-z0-9]*)(\[\])?$/u.exec(type.trim());
    if (!found || !ctx.projections.has(found[1]))
        return null;
    return { name: found[1], many: Boolean(found[2]) };
}
/** Ontology paths whose field type is text (`string`). */
function textFieldPaths(entity) {
    const record = isRecord(entity) && isRecord(entity.record) ? entity.record : entity;
    const out = [];
    const walk = (fields, prefix) => {
        if (!isRecord(fields))
            return;
        for (const [name, value] of Object.entries(fields)) {
            if (!isRecord(value))
                continue;
            const path = prefix ? `${prefix}.${name}` : name;
            if (value.type === 'string')
                out.push(path);
            if (value.type === 'object')
                walk(value.fields, path);
        }
    };
    walk(isRecord(record) ? record.fields : null, '');
    return out;
}
function entityLinks(entity) {
    const relationships = isRecord(entity) && isRecord(entity.relationships) ? entity.relationships : {};
    const out = [];
    for (const value of Object.values(relationships)) {
        if (!isRecord(value) || typeof value.to !== 'string' || typeof value.relationshipId !== 'string')
            continue;
        out.push({ to: value.to, relationshipId: value.relationshipId, cardinality: typeof value.cardinality === 'string' ? value.cardinality : '' });
    }
    return out;
}
/** Members of an interface body or of an inline object type, in order. */
function members(source) {
    let text = source.trim();
    if (text.startsWith('{') && text.endsWith('}'))
        text = text.slice(1, -1);
    const out = [];
    let i = 0;
    while (i < text.length) {
        while (i < text.length && /[\s;]/u.test(text[i]))
            i += 1;
        if (i >= text.length)
            break;
        let readonly = false;
        if (text.startsWith('readonly ', i)) {
            readonly = true;
            i += 'readonly '.length;
        }
        const name = /^[A-Za-z_][A-Za-z0-9_]*/u.exec(text.slice(i))?.[0];
        if (!name)
            break;
        i += name.length;
        if (text[i] === '?')
            i += 1;
        while (text[i] === ' ')
            i += 1;
        if (text[i] !== ':')
            break;
        i += 1;
        const start = i;
        let depth = 0;
        let quote = '';
        while (i < text.length) {
            const ch = text[i];
            if (quote) {
                if (ch === quote)
                    quote = '';
            }
            else if (ch === '\'' || ch === '"')
                quote = ch;
            else if (ch === '{' || ch === '(' || ch === '[' || ch === '<')
                depth += 1;
            else if (ch === '}' || ch === ')' || ch === ']' || ch === '>')
                depth -= 1;
            else if (depth === 0 && (ch === ';' || ch === '\n'))
                break;
            i += 1;
        }
        out.push({ name, readonly, type: text.slice(start, i).trim() });
    }
    return out;
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
