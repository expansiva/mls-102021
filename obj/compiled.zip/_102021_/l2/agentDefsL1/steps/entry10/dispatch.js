/// <mls fileReference="_102021_/l2/agentDefsL1/steps/entry10/dispatch.ts" enhancement="_blank"/>
import { readText, removePoolMessage } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
const POOL_BOXES = ['l1', 'l2', 'l4'];
/** Same name rule as `isPoolMessageShortName`: `<stamp>_<thread>_<round>`. */
function isPoolMessageShortName(shortName) {
    return /^\d{14}_.+_\d+$/u.test(shortName);
}
function displayOf(file) {
    return `l${file.level}/${file.folder}/${file.shortName}${file.extension}`;
}
/** Messages in `l4/<module>/pool/l1` of this project, oldest first. */
function l1BoxFiles(project, moduleName) {
    const folder = `${moduleName}/pool/l1`;
    return Object.values(mls.stor.files)
        .filter((file) => !!file
        && file.project === project
        && Number(file.level) === 4
        && file.status !== 'deleted'
        && String(file.folder || '') === folder
        && file.extension === '.json'
        && isPoolMessageShortName(String(file.shortName || '')))
        .map(file => ({ project, level: 4, folder, shortName: String(file.shortName), extension: '.json' }))
        .sort((left, right) => left.shortName.localeCompare(right.shortName));
}
/** An `implement` addressed to l1, or null. Anything else is not this agent's dispatch. */
async function dispatchLine(file) {
    const text = await readText(file);
    let raw;
    try {
        raw = text ? JSON.parse(text) : null;
    }
    catch {
        return null;
    }
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return null;
    const message = raw;
    if (message.mode !== 'implement' || message.to !== 'l1')
        return null;
    if (typeof message.from !== 'string' || !POOL_BOXES.includes(message.from) || message.from === 'l1')
        return null;
    const thread = typeof message.thread === 'string' ? message.thread.trim() : '';
    if (!thread || typeof message.round !== 'number' || !Number.isInteger(message.round) || message.round < 1)
        return null;
    return { file: displayOf(file), from: message.from, to: 'l1', thread, round: message.round, mode: 'implement' };
}
/** Display paths of the l1 dispatches present now. Read-only; the entry never depends on it. */
export async function listDispatchMessages(project, moduleName) {
    const out = [];
    for (const file of l1BoxFiles(project, moduleName)) {
        const line = await dispatchLine(file);
        if (line)
            out.push(line.file);
    }
    return out;
}
/**
 * The dispatches entry10 listed that are still in pool/l1. Lines already traced are not
 * repeated (a crash after the trace only deletes on the next pass). Nothing else is touched.
 */
export async function dispatchConsumption(project, moduleName, listed, traced, now) {
    const wanted = new Set(listed);
    const lines = [];
    const files = [];
    for (const file of l1BoxFiles(project, moduleName)) {
        if (!wanted.has(displayOf(file)))
            continue;
        const line = await dispatchLine(file);
        if (!line)
            continue;
        files.push(file);
        if (traced.some(item => item.file === line.file && item.outcome === 'processed'))
            continue;
        lines.push({ at: now.toISOString(), ...line, outcome: 'processed' });
    }
    return { lines, files };
}
/**
 * Deletes each file only if `traced` (the report as read back from disk) holds its `processed`
 * line. Otherwise throws before deleting it: trace first, then delete (`deletePoolMessageAt`).
 */
export async function deleteTraced(files, traced) {
    for (const file of files) {
        const path = displayOf(file);
        if (!traced.some(line => line.file === path && line.outcome === 'processed')) {
            throw new Error(`refusing to delete ${path}: no processed trace in the finalize80 report`);
        }
        await removePoolMessage(file);
    }
}
