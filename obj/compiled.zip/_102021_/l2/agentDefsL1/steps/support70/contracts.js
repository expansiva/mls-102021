/// <mls fileReference="_102021_/l2/agentDefsL1/steps/support70/contracts.ts" enhancement="_blank"/>
export const D1_SUPPORT_VERSION = '2026-10-01-d1-support-v2';
/** Same trail as the earlier steps. Uncited values stay on the domain draft. */
export const ENUMERATION_SOURCE = 'domain30.enumerations';
export const ENUMERATION_REASON = 'Scope and registry have no values slot. Enum values stay on the domain draft.';
export const ENUMERATION_CONSUMED_REASON = 'Seed scenarios cite every value of this enum. The values are not copied into rows.';
/** A covered consumer names this field. The union is not runtime enforcement. */
export const ENUMERATION_PROVED_REASON = 'A covered consumer names this entity and path. A type union is not runtime enforcement. Values stay on the domain draft.';
/** Selected transition usecases, keyed by entity and L4 transitionRef. */
export function transitionUsecasesOf(selected) {
    return selected.flatMap(item => item.operation === 'transition' && item.transitionRef
        ? [{ entity: item.entity, transitionRef: item.transitionRef, usecaseId: item.identity || item.usecaseId }]
        : []);
}
/** The usecase of one entity transition, or '' when none was selected. Never a usecase named like the transition. */
export function transitionUsecaseFor(list, entity, transitionRef) {
    const match = list.find(item => item.entity === entity && item.transitionRef === transitionRef);
    return match ? match.usecaseId : '';
}
