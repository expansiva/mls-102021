/// <mls fileReference="_102021_/l2/agentDefsL1/steps/support70/io.ts" enhancement="_blank"/>
import { isRecord } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { draftFile } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { commitD1Unit, logicalDefPath } from '/_102021_/l2/agentDefsL1/helpers/d1Receipt.js';
import { futureOutputPath, qualifyDefPath } from '/_102021_/l2/agentDefsL1/helpers/d1Refs.js';
import { readText, writeJson } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { artifactFile, renderDefinition } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { entityPath, inputPaths, journeyPath } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { resolveAllowedFields } from '/_102021_/l2/helpers/l1Defs/disclosure.js';
import { sourceIdentityHash } from '/_102021_/l2/helpers/l1Defs/identity.js';
import { parseD1Source, readD1Input, sha256Text } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
import { catalogInfo } from '/_102021_/l2/agentDefsL1/steps/domain30/io.js';
import { D1_CONTROLLER_VERSION } from '/_102021_/l2/agentDefsL1/steps/controllers60/contracts.js';
import { D1_DOMAIN_VERSION } from '/_102021_/l2/agentDefsL1/steps/domain30/contracts.js';
import { D1_PERSISTENCE_VERSION } from '/_102021_/l2/agentDefsL1/steps/persistence40/contracts.js';
import { D1_SUPPORT_VERSION, transitionUsecaseFor, operationUsecasesOf, transitionUsecasesOf, } from '/_102021_/l2/agentDefsL1/steps/support70/contracts.js';
import { buildD1Support } from '/_102021_/l2/agentDefsL1/steps/support70/gate.js';
const SUPPORT_TYPES = new Set(['accessScope', 'authorityMap', 'repositoryRegistration', 'persistenceSeeds', 'integrationOutbound', 'workflowProcess']);
export async function assembleD1Support(project, moduleName) {
    const snapshot = await readD1Input(project, moduleName);
    if (!snapshot)
        return { refusal: 'input.json is missing or does not belong to this project. support70 wrote nothing.' };
    if (!snapshot.consumersReleased)
        return { refusal: 'Consumer phases are not released. support70 wrote nothing.' };
    const controllersText = await readText(draftFile(project, moduleName, 'controllers60'));
    if (!controllersText)
        return { refusal: 'controllers60 draft is missing. support70 wrote nothing.' };
    const persistenceText = await readText(draftFile(project, moduleName, 'persistence40'));
    if (!persistenceText)
        return { refusal: 'persistence40 draft is missing. support70 wrote nothing.' };
    const controllers = parseDraft(controllersText, D1_CONTROLLER_VERSION, project, moduleName);
    if (!controllers)
        return { refusal: 'controllers60 draft does not belong to this project. support70 wrote nothing.' };
    const persistence = parseDraft(persistenceText, D1_PERSISTENCE_VERSION, project, moduleName);
    if (!persistence)
        return { refusal: 'persistence40 draft does not belong to this project. support70 wrote nothing.' };
    const domainText = await readText(draftFile(project, moduleName, 'domain30'));
    if (!domainText)
        return { refusal: 'domain30 draft is missing. support70 wrote nothing.' };
    const domain = parseDraft(domainText, D1_DOMAIN_VERSION, project, moduleName);
    if (!domain)
        return { refusal: 'domain30 draft does not belong to this project. support70 wrote nothing.' };
    const paths = inputPaths(moduleName);
    const accessText = await readLogical(project, paths.access);
    const indexText = await readLogical(project, paths.ontologyIndex);
    const access = accessText ? parseD1Source(accessText, 'defs') : null;
    const index = indexText ? parseD1Source(indexText, 'defs') : null;
    const journeys = await journeysOf(project, moduleName);
    const roleTags = await roleTagsOf(project, moduleName, index);
    const usecasesText = await readText(draftFile(project, moduleName, 'usecases50'));
    const usecases = usecasesText ? parseObject(usecasesText) : null;
    const previousText = await readText(draftFile(project, moduleName, 'support70'));
    const previous = previousText ? parseObject(previousText) : null;
    const files = await receiptFiles(project, snapshot.files);
    const entities = await entitiesOf(project, moduleName, index);
    const accessGrants = accessGrantsOf(access, entities);
    const grants = accessGrants.grants;
    const models = modelsOf(domain, index);
    const selected = snapshot.selection.usecases;
    const usecaseIds = [...new Set(selected.flatMap(item => [item.usecaseId, item.identity]))].filter(Boolean).sort();
    const transitionUsecases = transitionUsecasesOf(selected);
    const operationUsecases = operationUsecasesOf(selected);
    const linked = await effectsOf(project, moduleName, selected);
    const processes = await processesOf(project, moduleName, selected);
    const request = {
        project,
        moduleName,
        grants,
        relationships: relationshipsOf(index),
        scopePlans: plansOf(controllers),
        citedGrantIds: citedOf(controllers),
        adapters: adaptersOf(persistence),
        files,
        existingHelpers: helpersOf(previous),
        applicationEdges: [...edgesOf(usecases), ...edgesOf(controllers)],
        formFields: formFieldsOf(controllers),
        enumerations: enumerationsOf(controllers),
        tables: tablesOf(persistence),
        models,
        journeys: journeys.journeys,
        missingJourneys: journeys.missing,
        roleTags: [...roleTags, ...actorTags(grants, models)],
        seedRefs: [],
        existingDatasets: datasetsOf(previous),
        maintenance: null,
        outbound: linked.outbound,
        selectedEventIds: [...snapshot.selection.outbound].sort(),
        usecaseIds,
        transitionUsecases,
        operationUsecases,
        operations: linked.operations,
        processes,
        enumSnapshot: await enumSnapshotOf(project, moduleName, snapshot),
    };
    const testSupport = await testSupportOf(project, snapshot, paths.backend);
    if ('items' in testSupport) {
        if (testSupport.items)
            request.testSupport = testSupport.items;
    }
    else {
        request.testSupportUnread = testSupport.unread;
    }
    return { build: withDisclosureProblems(buildD1Support(request), accessGrants.problems), files };
}
export async function commitD1Support(project, build, files) {
    const draftInfo = draftFile(project, build.moduleName, 'support70');
    const draftText = `${JSON.stringify(build, null, 2)}\n`;
    const currentDraft = await readText(draftInfo);
    if (currentDraft !== draftText)
        await writeJson(draftInfo, build);
    if (!build.ok)
        return { written: [], issues: build.problems.filter(problem => problem.severity === 'error').map(problem => problem.message) };
    const rendered = renderParts(project, build.emit, files);
    if (rendered.issues.length > 0)
        return { written: [], issues: rendered.issues };
    const committed = await commitD1Unit({
        project,
        moduleName: build.moduleName,
        step: 'support70',
        unitId: 'support70',
        draftText,
        parts: [...rendered.parts, ...removalParts(project, build, files)],
    });
    return { written: committed.written, issues: committed.issues };
}
/** A support def is removed only when this build did not keep it for a live consumer. */
export function supportFilesToRemove(build, files) {
    const emitted = new Set(build.emit.map(part => logicalDefPath(part.pipeline[0]?.defPath || '')));
    return files.filter(file => {
        if (file.action !== 'remove')
            return false;
        const path = logicalDefPath(file.defPath);
        if (emitted.has(path))
            return false;
        const kept = build.normalizations.some(item => (item.code === 'REGISTRY_KEPT' || item.code === 'DATASET_KEPT')
            && logicalDefPath(item.path) === path);
        return !kept;
    });
}
function removalParts(project, build, files) {
    return supportFilesToRemove(build, files).map(file => ({
        defPath: qualifyDefPath(project, logicalDefPath(file.defPath)),
        source: '',
        action: 'remove',
        receiptHash: file.contentHash,
        outputTs: [futureOutputPath(logicalDefPath(file.defPath))].filter(Boolean),
    }));
}
function renderParts(project, emit, files) {
    const parts = [];
    const issues = [];
    for (const part of emit) {
        const rendered = renderDefinition(part.definition, part.pipeline[0]?.defPath || '');
        if ('issues' in rendered) {
            issues.push(...rendered.issues);
            continue;
        }
        const defPath = part.pipeline[0]?.defPath || '';
        if (!artifactFile(project, defPath)) {
            issues.push(`defPath is not a file this agent can write: ${defPath}.`);
            continue;
        }
        const logical = logicalDefPath(defPath);
        const receipt = files.find(item => item.defPath === logical || qualifyDefPath(project, item.defPath) === defPath);
        parts.push({
            defPath,
            source: rendered.source,
            receiptHash: receipt?.contentHash || '',
            outputTs: [part.pipeline[0]?.outputPath || ''].filter(Boolean),
            ...(part.blockReason ? { blockReason: part.blockReason } : {}),
        });
    }
    return { parts, issues };
}
async function receiptFiles(project, planned) {
    const files = [];
    for (const file of planned) {
        if (!SUPPORT_TYPES.has(file.artifactType))
            continue;
        const text = await readLogical(project, file.defPath);
        files.push({
            artifactType: file.artifactType,
            defPath: file.defPath,
            action: file.action,
            contentHash: file.contentHash || '',
            currentHash: text == null ? '' : await sourceIdentityHash(text),
        });
    }
    return files;
}
const ENUM_DEF_TYPES = new Set(['usecase', 'domainEntity', 'persistenceSeeds']);
/** Ontology and catalog texts whose snapshot digest matches, plus defs this run already wrote. */
async function enumSnapshotOf(project, moduleName, snapshot) {
    const sources = {};
    for (const source of snapshot.sources) {
        if (source.state !== 'present')
            continue;
        const text = await readLogical(project, source.path);
        if (text == null || await sha256Text(text) !== source.sha256)
            continue;
        sources[source.path] = text;
    }
    const catalogs = new Set();
    for (const text of Object.values(sources)) {
        const parsed = parseD1Source(text, 'defs');
        if (isRecord(parsed) && typeof parsed.source === 'string' && parsed.source)
            catalogs.add(parsed.source);
    }
    for (const source of catalogs) {
        if (sources[source])
            continue;
        const info = catalogInfo(source);
        if (!info)
            continue;
        const text = await readText(info);
        if (text == null)
            continue;
        const listed = snapshot.sources.find(item => item.path === source);
        if (listed && listed.sha256 !== await sha256Text(text))
            continue;
        sources[source] = text;
    }
    const definitions = [];
    for (const file of snapshot.files) {
        if (!ENUM_DEF_TYPES.has(file.artifactType))
            continue;
        const text = await readLogical(project, logicalDefPath(file.defPath));
        if (text)
            definitions.push(text);
    }
    return {
        sources,
        definitions,
        tables: snapshot.selection.tables.map(table => ({ tableId: table.tableId, entityId: table.entity })),
    };
}
/**
 * `testSupport[]` of the backend plan input20 accepted. Read only when the bytes still match
 * the digest of the snapshot; input20 refuses a plan without the array (d1_39). Changed bytes are named.
 */
async function testSupportOf(project, snapshot, backendPath) {
    const listed = snapshot.sources.find(source => source.path === backendPath);
    if (!listed || listed.state !== 'present')
        return { items: undefined };
    const text = await readLogical(project, backendPath);
    if (text == null || await sha256Text(text) !== listed.sha256) {
        return { unread: `${backendPath} changed after input20 (digest differs); its testSupport was not read and the seeds def carries no certification fixture. Run input20 again.` };
    }
    const parsed = parseD1Source(text, 'json');
    return { items: isRecord(parsed) && Array.isArray(parsed.testSupport) ? parsed.testSupport : undefined };
}
async function readLogical(project, logical) {
    const file = artifactFile(project, qualifyDefPath(project, logical));
    if (!file)
        return null;
    return readText(file);
}
function parseDraft(text, schemaVersion, project, moduleName) {
    const parsed = parseObject(text);
    if (!parsed || parsed.schemaVersion !== schemaVersion || parsed.project !== project || parsed.moduleName !== moduleName)
        return null;
    return parsed;
}
function parseObject(text) {
    try {
        const parsed = JSON.parse(text);
        return isRecord(parsed) ? parsed : null;
    }
    catch {
        return null;
    }
}
/** `summaryOnly` is the L4 name of `fieldsOnly`. Any other mode is an error on the grant. */
export function accessGrantsOf(access, entities) {
    if (!isRecord(access) || !Array.isArray(access.grants))
        return { grants: [], problems: [] };
    const grants = [];
    const problems = [];
    for (const grant of access.grants) {
        if (!isRecord(grant) || typeof grant.grantId !== 'string' || typeof grant.actorRef !== 'string')
            continue;
        const disclosure = isRecord(grant.disclosure) ? grant.disclosure : {};
        const scope = isRecord(grant.dataScope) ? grant.dataScope : {};
        const declared = disclosure.mode;
        const known = declared === 'fullRecord' || declared === 'fieldsOnly' || declared === 'summaryOnly';
        if (!known) {
            problems.push({
                severity: 'error',
                code: 'DISCLOSURE_MODE',
                path: grant.grantId,
                message: `Grant ${grant.grantId} disclosure mode ${JSON.stringify(declared ?? null)} is not fullRecord, fieldsOnly, or summaryOnly.`,
            });
            continue;
        }
        const mode = declared === 'summaryOnly' ? 'fieldsOnly' : declared;
        const entityRefs = stringList(grant.entityRefs);
        const allowedFields = stringList(disclosure.allowedFields);
        grants.push({
            grantId: grant.grantId,
            actorRef: grant.actorRef,
            entityRefs,
            disclosure: mode,
            allowedFields: mode === 'fieldsOnly'
                ? resolveAllowedFields({
                    grantId: grant.grantId,
                    entityRefs,
                    allowedFields: Array.isArray(disclosure.allowedFields) ? allowedFields : undefined,
                    deniedFields: stringList(disclosure.deniedFields),
                }, entities)
                : allowedFields,
            anchorEntity: typeof scope.anchorEntity === 'string' ? scope.anchorEntity : '',
            scopeMode: typeof scope.mode === 'string' ? scope.mode : '',
        });
    }
    return { grants, problems };
}
function withDisclosureProblems(build, problems) {
    if (problems.length === 0)
        return build;
    return { ...build, ok: false, problems: [...build.problems, ...problems], emit: [] };
}
async function entitiesOf(project, moduleName, index) {
    const out = {};
    if (!isRecord(index) || !Array.isArray(index.entities))
        return out;
    for (const entity of index.entities) {
        if (!isRecord(entity) || typeof entity.entityId !== 'string')
            continue;
        const text = await readLogical(project, entityPath(moduleName, entity.entityId));
        const parsed = text ? parseD1Source(text, 'defs') : null;
        if (isRecord(parsed))
            out[entity.entityId] = parsed;
    }
    return out;
}
function relationshipsOf(index) {
    if (!isRecord(index) || !Array.isArray(index.relationships))
        return [];
    const out = [];
    for (const rel of index.relationships) {
        if (!isRecord(rel) || typeof rel.relationshipId !== 'string')
            continue;
        out.push({
            relationshipId: rel.relationshipId,
            from: typeof rel.from === 'string' ? rel.from : '',
            to: typeof rel.to === 'string' ? rel.to : '',
            field: typeof rel.field === 'string' ? rel.field : '',
            required: rel.required === true,
        });
    }
    return out;
}
function plansOf(draft) {
    const out = [];
    const seen = new Set();
    for (const controller of arrayOf(draft.controllers)) {
        for (const handler of arrayOf(isRecord(controller) ? controller.handlers : [])) {
            for (const plan of arrayOf(isRecord(handler) ? handler.scopePlan : [])) {
                if (!isRecord(plan) || typeof plan.grantId !== 'string' || seen.has(plan.grantId))
                    continue;
                seen.add(plan.grantId);
                const disclosure = plan.disclosure === 'fullRecord' || plan.disclosure === 'fieldsOnly' ? plan.disclosure : '';
                if (!disclosure)
                    continue;
                out.push({
                    grantId: plan.grantId,
                    actorRef: typeof plan.actorRef === 'string' ? plan.actorRef : '',
                    entityRefs: stringList(plan.entityRefs),
                    disclosure,
                    allowedFields: stringList(plan.allowedFields),
                    anchorEntity: typeof plan.anchorEntity === 'string' ? plan.anchorEntity : '',
                    relationships: arrayOf(plan.relationships).flatMap(rel => {
                        if (!isRecord(rel) || typeof rel.relationshipId !== 'string')
                            return [];
                        return [{
                                relationshipId: rel.relationshipId,
                                from: typeof rel.from === 'string' ? rel.from : '',
                                to: typeof rel.to === 'string' ? rel.to : '',
                                field: typeof rel.field === 'string' ? rel.field : '',
                            }];
                    }),
                    pending: typeof plan.pending === 'string' ? plan.pending : '',
                    emittedBy: 'support70',
                });
            }
        }
    }
    return out;
}
function citedOf(draft) {
    const ids = [];
    for (const controller of arrayOf(draft.controllers)) {
        for (const handler of arrayOf(isRecord(controller) ? controller.handlers : [])) {
            if (!isRecord(handler))
                continue;
            for (const grantId of stringList(handler.grantIds)) {
                if (!ids.includes(grantId))
                    ids.push(grantId);
            }
        }
    }
    return ids;
}
function adaptersOf(draft) {
    const out = [];
    for (const adapter of arrayOf(draft.adapters)) {
        if (!isRecord(adapter) || typeof adapter.portId !== 'string')
            continue;
        const definition = isRecord(adapter.definition) ? adapter.definition : null;
        out.push({
            portId: adapter.portId,
            entityId: typeof adapter.entityId === 'string' ? adapter.entityId : '',
            tableId: typeof adapter.tableId === 'string' ? adapter.tableId : '',
            artifactId: definition && typeof definition.artifactId === 'string' ? definition.artifactId : adapter.portId,
            action: typeof adapter.action === 'string' ? adapter.action : '',
            defPath: typeof adapter.defPath === 'string' ? adapter.defPath : '',
        });
    }
    return out;
}
function helpersOf(draft) {
    if (!draft || draft.schemaVersion !== D1_SUPPORT_VERSION || !Array.isArray(draft.helpers))
        return [];
    const out = [];
    for (const helper of draft.helpers) {
        if (!isRecord(helper) || typeof helper.helperId !== 'string')
            continue;
        out.push({
            helperId: helper.helperId,
            session: 'verified',
            steps: arrayOf(helper.steps).flatMap(step => {
                if (!isRecord(step) || typeof step.relationshipId !== 'string')
                    return [];
                return [{
                        relationshipId: step.relationshipId,
                        from: typeof step.from === 'string' ? step.from : '',
                        to: typeof step.to === 'string' ? step.to : '',
                        field: typeof step.field === 'string' ? step.field : '',
                    }];
            }),
            consumers: stringList(helper.consumers),
        });
    }
    return out;
}
function edgesOf(draft) {
    if (!draft || !Array.isArray(draft.emit))
        return [];
    const out = [];
    for (const part of draft.emit) {
        const pipeline = isRecord(part) && Array.isArray(part.pipeline) ? part.pipeline[0] : null;
        if (!isRecord(pipeline))
            continue;
        out.push({
            id: typeof pipeline.id === 'string' ? pipeline.id : '',
            type: typeof pipeline.type === 'string' ? pipeline.type : '',
            dependsOn: stringList(pipeline.dependsOn),
        });
    }
    return out;
}
function formFieldsOf(draft) {
    const names = [];
    for (const problem of arrayOf(draft.problems)) {
        if (!isRecord(problem) || problem.code !== 'FORM_IDENTITY' || typeof problem.message !== 'string')
            continue;
        const match = /Form field (\w+)/.exec(problem.message);
        if (match && !names.includes(match[1]))
            names.push(match[1]);
    }
    return names;
}
function enumerationsOf(draft) {
    const out = [];
    for (const item of arrayOf(draft.enumerations)) {
        if (!isRecord(item) || typeof item.entityId !== 'string' || typeof item.path !== 'string')
            continue;
        out.push({ entityId: item.entityId, path: item.path, values: stringList(item.values) });
    }
    return out;
}
function arrayOf(value) {
    return Array.isArray(value) ? value : [];
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string' && item.length > 0);
}
function tablesOf(draft) {
    const out = [];
    for (const table of arrayOf(draft.tables)) {
        if (!isRecord(table) || typeof table.tableId !== 'string' || typeof table.entityId !== 'string')
            continue;
        const definition = isRecord(table.definition) ? table.definition : null;
        const data = definition && isRecord(definition.data) ? definition.data : null;
        out.push({
            tableId: table.tableId,
            entityId: table.entityId,
            action: typeof table.action === 'string' ? table.action : '',
            defPath: typeof table.defPath === 'string' ? table.defPath : '',
            uniqueKeys: pairsOf(data?.uniqueKeys),
        });
    }
    return out;
}
function modelsOf(draft, index) {
    const kinds = new Map();
    if (isRecord(index)) {
        for (const entity of arrayOf(index.entities)) {
            if (!isRecord(entity) || typeof entity.entityId !== 'string')
                continue;
            kinds.set(entity.entityId, typeof entity.kind === 'string' ? entity.kind : '');
        }
    }
    const out = [];
    for (const entity of arrayOf(draft.entities)) {
        if (!isRecord(entity) || typeof entity.entityId !== 'string')
            continue;
        const definition = isRecord(entity.definition) ? entity.definition : null;
        const data = definition && isRecord(definition.data) ? definition.data : {};
        const fields = arrayOf(data.fields).flatMap(field => {
            if (!isRecord(field) || typeof field.name !== 'string')
                return [];
            return [{ name: field.name, type: typeof field.type === 'string' ? field.type : '' }];
        });
        const lifecycle = isRecord(data.lifecycle) ? data.lifecycle : {};
        const storageTarget = typeof entity.storageTarget === 'string' ? entity.storageTarget : '';
        const kind = kinds.get(entity.entityId) === 'role' || storageTarget === 'mdm' ? 'role' : 'entity';
        out.push({
            entityId: entity.entityId,
            storageTarget,
            kind,
            namespace: '',
            fields,
            states: arrayOf(lifecycle.states).flatMap(state => {
                if (!isRecord(state) || typeof state.state !== 'string' || !state.state)
                    return [];
                return [state.state];
            }),
            initialState: typeof entity.derivedInitial === 'string' ? entity.derivedInitial : '',
            uniqueKeys: pairsOf(entity.uniqueKeys),
            transitions: arrayOf(lifecycle.transitions).flatMap(transition => {
                if (!isRecord(transition) || typeof transition.transitionId !== 'string')
                    return [];
                return [{
                        transitionId: transition.transitionId,
                        to: typeof transition.to === 'string' ? transition.to : '',
                        ruleRefs: stringList(transition.ruleRefs),
                    }];
            }),
            noteField: fields.find(field => field.name === 'attendanceNote' || field.name.endsWith('.attendanceNote'))?.name || '',
        });
    }
    return out;
}
async function journeysOf(project, moduleName) {
    const journeyIndexText = await readLogical(project, inputPaths(moduleName).journeyIndex);
    const journeyIndex = journeyIndexText ? parseD1Source(journeyIndexText, 'defs') : null;
    if (!isRecord(journeyIndex) || !Array.isArray(journeyIndex.journeys))
        return { journeys: [], missing: [] };
    const journeys = [];
    const missing = [];
    for (const item of journeyIndex.journeys) {
        if (!isRecord(item) || typeof item.journeyId !== 'string' || !item.journeyId)
            continue;
        const text = await readLogical(project, journeyPath(moduleName, item.journeyId));
        const parsed = text ? parseD1Source(text, 'defs') : null;
        if (!isRecord(parsed)) {
            missing.push(item.journeyId);
            continue;
        }
        journeys.push(journeyOf(item.journeyId, parsed));
    }
    return { journeys, missing };
}
function journeyOf(journeyId, parsed) {
    const business = isRecord(parsed.business) ? parsed.business : parsed;
    const entities = [];
    const effects = [];
    for (const step of arrayOf(business.steps)) {
        if (!isRecord(step) || typeof step.entity !== 'string' || !step.entity)
            continue;
        if (!entities.includes(step.entity))
            entities.push(step.entity);
        const effect = typeof step.effect === 'string' ? step.effect : '';
        if (!effect)
            continue;
        effects.push({
            entityId: step.entity,
            effect,
            transitionRef: typeof step.transitionRef === 'string' ? step.transitionRef : '',
        });
    }
    return { journeyId, entities, effects };
}
async function roleTagsOf(project, moduleName, index) {
    if (!isRecord(index) || !Array.isArray(index.entities))
        return [];
    const tags = [];
    for (const entity of index.entities) {
        if (!isRecord(entity) || typeof entity.entityId !== 'string')
            continue;
        const text = await readLogical(project, entityPath(moduleName, entity.entityId));
        const parsed = text ? parseD1Source(text, 'defs') : null;
        if (!isRecord(parsed) || !isRecord(parsed.relationships))
            continue;
        for (const rel of Object.values(parsed.relationships)) {
            if (!isRecord(rel) || typeof rel.role !== 'string' || !rel.role)
                continue;
            const entityId = typeof rel.to === 'string' ? rel.to : '';
            if (!entityId || rel.role === entityId)
                continue;
            if (tags.some(tag => tag.tag === rel.role && tag.entityId === entityId))
                continue;
            tags.push({ tag: rel.role, entityId });
        }
    }
    return tags;
}
function actorTags(grants, models) {
    const ids = new Set(models.map(model => model.entityId));
    const tags = [];
    for (const grant of grants) {
        const tag = grant.actorRef;
        if (!tag || ids.has(tag) || tags.some(item => item.tag === tag))
            continue;
        const entityId = [...ids].find(id => id.toLowerCase() === tag.toLowerCase()) || '';
        tags.push({ tag, entityId });
    }
    return tags;
}
function datasetsOf(draft) {
    if (!draft || draft.schemaVersion !== D1_SUPPORT_VERSION || !isRecord(draft.seedPlan))
        return [];
    const out = [];
    for (const item of arrayOf(draft.seedPlan.datasets)) {
        if (!isRecord(item) || typeof item.datasetId !== 'string' || typeof item.tableId !== 'string')
            continue;
        out.push({ datasetId: item.datasetId, tableId: item.tableId, owners: stringList(item.owners) });
    }
    return out;
}
/** Inbound operations come from the L4 effect, never from a name built out of the entity. */
export function inboundOperation(row, selected) {
    if (typeof row.id !== 'string' || !row.id)
        return null;
    const effect = typeof row.effect === 'string' ? row.effect : '';
    const operations = [];
    if (effect === 'transition') {
        const transitionRef = typeof row.transitionRef === 'string' ? row.transitionRef : '';
        const transitions = transitionUsecasesOf(selected);
        for (const entity of transitionRef ? stringList(row.writes) : []) {
            // Unselected: the entity transition stays named, and the pool check reports it.
            const operation = transitionUsecaseFor(transitions, entity, transitionRef) || `${entity}.${transitionRef}`;
            if (!operations.includes(operation))
                operations.push(operation);
        }
    }
    else if (effect === 'create' || effect === 'update') {
        for (const entity of stringList(row.writes)) {
            const match = selected.find(item => item.entity === entity && item.operation === effect);
            if (match?.usecaseId && !operations.includes(match.usecaseId))
                operations.push(match.usecaseId);
        }
    }
    const known = new Set(selected.flatMap(item => [item.usecaseId, item.identity]).filter(Boolean));
    const consumer = operations.find(item => known.has(item)) || row.id;
    return { id: row.id, kind: 'inbound', operations, mechanism: '', consumer, scheduled: false };
}
async function effectsOf(project, moduleName, selected) {
    const paths = inputPaths(moduleName);
    const integrationText = await readLogical(project, paths.integration);
    const integration = integrationText ? parseD1Source(integrationText, 'defs') : null;
    const known = new Set(selected.flatMap(item => [item.usecaseId, item.identity]).filter(Boolean));
    const payloadCache = new Map();
    const outbound = [];
    if (isRecord(integration)) {
        for (const row of arrayOf(integration.outbound)) {
            if (!isRecord(row) || typeof row.id !== 'string' || !row.id)
                continue;
            const on = typeof row.on === 'string' ? row.on : '';
            outbound.push({
                eventId: row.id,
                on,
                mechanism: typeof row.mechanism === 'string' ? row.mechanism : '',
                payloadDeclared: await payloadOf(project, moduleName, on, payloadCache),
            });
        }
    }
    const operations = [];
    if (isRecord(integration)) {
        for (const row of arrayOf(integration.inbound)) {
            if (!isRecord(row))
                continue;
            const inbound = inboundOperation(row, selected);
            if (inbound)
                operations.push(inbound);
        }
        for (const row of arrayOf(integration.plugins)) {
            if (!isRecord(row) || typeof row.pluginId !== 'string' || !row.pluginId)
                continue;
            const usedBy = stringList(row.usedBy);
            const consumer = usedBy.find(item => inSelected(item, known)) || row.pluginId;
            operations.push({
                id: row.pluginId,
                kind: 'plugin',
                operations: usedBy,
                mechanism: typeof row.mechanism === 'string' ? row.mechanism : '',
                consumer,
                scheduled: false,
            });
        }
    }
    return { outbound, operations };
}
/** L4 processes as plans. Occurrence and operations follow the workflowProcess rule. No def is written. */
export async function processesOf(project, moduleName, selected) {
    const text = await readLogical(project, inputPaths(moduleName).workflows);
    const workflows = text ? parseD1Source(text, 'defs') : null;
    if (!isRecord(workflows))
        return [];
    const transitions = transitionUsecasesOf(selected);
    const operationUsecases = operationUsecasesOf(selected);
    const decisions = arrayOf(workflows.journeyDecisions).flatMap(row => {
        if (!isRecord(row) || row.inProcess !== true || typeof row.journeyId !== 'string' || !row.journeyId)
            return [];
        if (typeof row.processId !== 'string' || !row.processId)
            return [];
        return [{ journeyId: row.journeyId, processId: row.processId }];
    });
    const acts = new Map();
    for (const journeyId of [...new Set(decisions.map(item => item.journeyId))]) {
        acts.set(journeyId, await journeyActs(project, moduleName, journeyId));
    }
    const plans = [];
    for (const row of arrayOf(workflows.processes)) {
        if (!isRecord(row) || typeof row.processId !== 'string' || !row.processId)
            continue;
        const tasks = arrayOf(row.tasks).filter(isRecord);
        const first = tasks[0];
        if (first && first.kind === 'human' && typeof first.journeyRef === 'string' && first.journeyRef && !acts.has(first.journeyRef)) {
            acts.set(first.journeyRef, await journeyActs(project, moduleName, first.journeyRef));
        }
        const humanJourneys = decisions.filter(item => item.processId === row.processId).map(item => item.journeyId);
        const lines = new Map();
        const add = (entity, effect, transitionRef, step) => {
            const name = effect === 'transition' ? transitionRef : effect;
            if (!entity || !name || (effect !== 'create' && effect !== 'update' && effect !== 'transition'))
                return;
            const operation = `${entity}.${name}`;
            const picked = effect === 'transition'
                ? transitionUsecaseFor(transitions, entity, transitionRef) !== ''
                : operationUsecases.some(item => item.entity === entity && item.operation === effect);
            const line = lines.get(operation) || { operation, steps: [], selected: picked };
            if (!line.steps.includes(step))
                line.steps.push(step);
            lines.set(operation, line);
        };
        for (const journeyId of humanJourneys) {
            for (const act of acts.get(journeyId) || []) {
                add(act.entity, act.effect, act.transitionRef, `journey:${journeyId}/${act.stepId}`);
            }
        }
        for (const task of tasks) {
            if (task.kind !== 'mechanical' && task.kind !== 'llm')
                continue;
            const taskId = typeof task.taskId === 'string' ? task.taskId : '';
            if (!taskId)
                continue;
            add(typeof task.entityRef === 'string' ? task.entityRef : '', typeof task.effect === 'string' ? task.effect : '', typeof task.transitionRef === 'string' ? task.transitionRef : '', `task:${taskId}`);
        }
        const functions = arrayOf(row.functions).flatMap(item => (isRecord(item) && typeof item.functionId === 'string' && item.functionId ? [item.functionId] : []));
        plans.push({
            processId: row.processId,
            trigger: triggerOf(isRecord(row.trigger) ? row.trigger : {}),
            occurrence: occurrenceOf(isRecord(row.trigger) ? row.trigger : {}, tasks, acts),
            functions: [...new Set(functions)],
            operations: [...lines.values()].sort((left, right) => left.operation.localeCompare(right.operation)),
            humanJourneys: [...new Set(humanJourneys)],
        });
    }
    return plans;
}
function triggerOf(row) {
    const kind = row.kind === 'event' || row.kind === 'scheduled' ? row.kind : 'manual';
    if (kind === 'event')
        return typeof row.event === 'string' && row.event ? { kind, event: row.event } : { kind };
    if (kind === 'scheduled')
        return typeof row.schedule === 'string' && row.schedule ? { kind, schedule: row.schedule } : { kind };
    return typeof row.actorRef === 'string' && row.actorRef ? { kind, actorRef: row.actorRef } : { kind };
}
function occurrenceOf(trigger, tasks, acts) {
    if (trigger.kind === 'event' && typeof trigger.event === 'string' && trigger.event.includes('.')) {
        return trigger.event.split('.')[0] || '';
    }
    const task = tasks[0];
    if (!task)
        return '';
    if ((task.kind === 'mechanical' || task.kind === 'llm') && typeof task.entityRef === 'string')
        return task.entityRef;
    if (task.kind !== 'human' || typeof task.journeyRef !== 'string')
        return '';
    const steps = acts.get(task.journeyRef) || [];
    const created = steps.find(step => step.effect === 'create');
    return (created || steps[0])?.entity || '';
}
async function journeyActs(project, moduleName, journeyId) {
    const text = await readLogical(project, journeyPath(moduleName, journeyId));
    const parsed = text ? parseD1Source(text, 'defs') : null;
    if (!isRecord(parsed))
        return [];
    const business = isRecord(parsed.business) ? parsed.business : parsed;
    const acts = [];
    for (const step of arrayOf(business.steps)) {
        if (!isRecord(step) || step.kind !== 'act' || typeof step.stepId !== 'string' || !step.stepId)
            continue;
        if (typeof step.entity !== 'string' || !step.entity)
            continue;
        acts.push({
            stepId: step.stepId,
            entity: step.entity,
            effect: typeof step.effect === 'string' ? step.effect : '',
            transitionRef: typeof step.transitionRef === 'string' ? step.transitionRef : '',
        });
    }
    return acts;
}
async function payloadOf(project, moduleName, on, cache) {
    const [entityId, transitionId] = on.split('.');
    if (!entityId || !transitionId || on.split('.').length !== 2)
        return false;
    if (!cache.has(entityId)) {
        const text = await readLogical(project, entityPath(moduleName, entityId));
        cache.set(entityId, text ? parseD1Source(text, 'defs') : null);
    }
    const doc = cache.get(entityId);
    if (!isRecord(doc))
        return false;
    const transition = arrayOf(doc.transitions).find(item => isRecord(item) && item.transitionId === transitionId);
    return isRecord(transition) && Object.hasOwn(transition, 'payload');
}
function inSelected(operation, usecaseIds) {
    if (usecaseIds.has(operation))
        return true;
    const head = operation.split('.')[0] || '';
    return head.length > 0 && usecaseIds.has(head);
}
function pairsOf(value) {
    if (!Array.isArray(value))
        return [];
    return value.flatMap(item => {
        if (!Array.isArray(item))
            return [];
        const row = item.filter((part) => typeof part === 'string' && part.length > 0);
        return row.length ? [row] : [];
    });
}
