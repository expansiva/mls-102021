/// <mls fileReference="_102021_/l2/agentDefsL1/steps/support70/enumerations.ts" enhancement="_blank"/>
import { isRecord } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { parseD1Source } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
import { ENUMERATION_CONSUMED_REASON, ENUMERATION_PROVED_REASON, ENUMERATION_REASON, ENUMERATION_SOURCE, } from '/_102021_/l2/agentDefsL1/steps/support70/contracts.js';
import { resolveModuleEntity, resolvePlatformEntity, } from '/_102034_/l2/mdm/resolveMdmEntity.js';
/** What the report looked at. A union or an owner is not runtime enforcement. */
export const ENUMERATION_LIMITS = 'Covered uses are a seed scenario that names this entity and path, and a domain or usecase def whose type names this path with those literals. A TypeScript union is not runtime enforcement. Ownership is not consumption. No seed, catalog or table is created here.';
/**
 * Projects origin, restriction and proved uses for each enumeration.
 * Does not read the filesystem and does not invent a seed, a catalog or a table.
 */
export function projectEnumerations(input) {
    const snapshot = input.snapshot;
    const bodies = bodiesOf(snapshot?.sources || {});
    const tables = new Map((snapshot?.tables || []).map(table => [table.tableId, table.entityId]));
    const fromDefs = usesFromTexts(snapshot?.definitions || [], input.enumerations, tables);
    const fromSeeds = (input.seedCitations || []).map(citation => useOf('seedScenario', citation.scenarioId, citation.entityId, citation.path, citation.values, true));
    const byKey = new Map();
    for (const use of [...fromSeeds, ...fromDefs]) {
        const key = `${use.entityId}\u0000${use.path}`;
        const list = byKey.get(key) || [];
        const id = `${use.purpose}\u0000${use.consumer}\u0000${use.entityId}\u0000${use.path}`;
        if (!list.some(item => `${item.purpose}\u0000${item.consumer}\u0000${item.entityId}\u0000${item.path}` === id))
            list.push(use);
        byKey.set(key, list);
    }
    return input.enumerations.map(item => {
        const values = [...item.values];
        const origin = originOf(item.entityId, item.path, values, bodies);
        const uses = (byKey.get(`${item.entityId}\u0000${item.path}`) || [])
            .map(use => ({ ...use, editable: use.editable && !origin.derived && !origin.roleBinding }))
            .sort((left, right) => `${left.purpose}\u0000${left.consumer}`.localeCompare(`${right.purpose}\u0000${right.consumer}`));
        const seeded = new Set(uses.filter(use => use.purpose === 'seedScenario').flatMap(use => use.values));
        const fullySeeded = values.length > 0 && values.every(value => seeded.has(value));
        return {
            entityId: item.entityId,
            path: item.path,
            values,
            consumed: uses.length > 0,
            source: ENUMERATION_SOURCE,
            reason: fullySeeded ? ENUMERATION_CONSUMED_REASON : uses.length ? ENUMERATION_PROVED_REASON : ENUMERATION_REASON,
            origin,
            uses,
            limits: ENUMERATION_LIMITS,
        };
    });
}
/** The field a model's lifecycle states belong to, when exactly one enum has that value set. */
export function lifecyclePath(entityId, states, enumerations) {
    if (!states.length)
        return '';
    const matches = enumerations.filter(item => item.entityId === entityId && sameSet(item.values, states));
    return matches.length === 1 ? matches[0].path : '';
}
function originOf(entityId, path, effective, bodies) {
    const unresolved = emptyOrigin();
    const entity = bodies.entities[entityId];
    if (!isRecord(entity))
        return unresolved;
    const source = typeof entity.source === 'string' ? entity.source : '';
    const catalog = source ? bodies.catalogs[source] : undefined;
    const resolved = catalog ? resolvedNodes(entity, bodies.index, catalog, bodies.rules) : null;
    if (resolved) {
        const node = findNode(resolved.module, path);
        const platformValues = platformValuesAt(resolved.platform, path);
        return classifyNode(entity, path, effective, node, platformValues, source);
    }
    if (entity.kind === 'role')
        return { ...unresolved, catalogSource: source };
    const own = fieldAt(entity, path);
    if (!own)
        return { ...unresolved, catalogSource: source };
    const derived = own.derived === true;
    return {
        owner: 'module',
        writer: derived ? 'derived' : 'module',
        derived,
        restriction: 'own',
        catalogValues: [],
        catalogSource: source,
        roleBinding: false,
    };
}
function classifyNode(entity, path, effective, node, platformValues, source) {
    const writer = node?.origin === 'platform' || node?.origin === 'module' || node?.origin === 'derived'
        ? node.origin
        : 'unresolved';
    const derived = writer === 'derived' || node?.derived === true;
    const owner = writer === 'module' ? 'module' : platformValues ? 'platform' : writer === 'unresolved' ? 'unresolved' : 'module';
    const roleBinding = entity.kind === 'role'
        && path === 'details.identification.subtype'
        && effective.length === 1
        && effective[0] === entity.subtype;
    let restriction = 'unresolved';
    if (writer === 'module' || !platformValues)
        restriction = writer === 'unresolved' ? 'unresolved' : 'own';
    else if (effective.some(value => !platformValues.includes(value)))
        restriction = 'invalid';
    else if (sameSet(effective, platformValues))
        restriction = 'inherited';
    else
        restriction = 'subset';
    return {
        owner,
        writer: derived && writer === 'platform' ? 'derived' : writer,
        derived,
        restriction,
        catalogValues: platformValues ? [...platformValues] : [],
        catalogSource: source,
        roleBinding,
    };
}
function resolvedNodes(entity, index, catalog, rules) {
    if (!isModuleEntity(entity) || !isIndex(index) || !isCatalog(catalog) || !isRules(rules))
        return null;
    if (!isRecord(catalog) || !isRecord(catalog.subtypes))
        return null;
    const moduleName = typeof entity.moduleName === 'string' ? entity.moduleName : '';
    const subtype = entity.kind === 'role' && typeof entity.subtype === 'string' ? entity.subtype : undefined;
    if (subtype && !Object.prototype.hasOwnProperty.call(catalog.subtypes, subtype))
        return null;
    const module = resolveModuleEntity(entity, index, catalog, rules);
    const platform = subtype
        ? resolvePlatformEntity(catalog, subtype, moduleName)
        : null;
    return { module, platform };
}
function platformValuesAt(view, path) {
    if (!view)
        return null;
    const node = findNode(view, path);
    if (!node?.values)
        return null;
    return node.values.map(item => item.value);
}
function findNode(view, path) {
    const walk = (nodes) => {
        for (const node of nodes || []) {
            if (node.path === path)
                return node;
            const child = walk(node.children);
            if (child)
                return child;
        }
        return null;
    };
    return walk(view.columns) || walk(view.details);
}
function usesFromTexts(definitions, enumerations, tables) {
    const uses = [];
    for (const text of definitions) {
        const parsed = parseD1Source(text, 'defs');
        if (!isRecord(parsed) || !isRecord(parsed.data))
            continue;
        const data = parsed.data;
        if (parsed.artifactType === 'domainEntity')
            uses.push(...domainUses(data, enumerations));
        else if (parsed.artifactType === 'persistenceSeeds')
            uses.push(...seedUses(data, enumerations, tables));
    }
    return uses;
}
function domainUses(data, enumerations) {
    const entityId = typeof data.entityId === 'string' ? data.entityId : '';
    if (!entityId)
        return [];
    const uses = [];
    for (const field of arrayOf(data.fields)) {
        if (!isRecord(field) || typeof field.name !== 'string' || typeof field.type !== 'string')
            continue;
        const match = enumerations.find(item => item.entityId === entityId && item.path === field.name);
        const literals = closedLiterals(field.type);
        const values = match && literals ? provedValues(literals, match.values) : null;
        if (!match || !values)
            continue;
        uses.push(useOf('domainDef', entityId, entityId, field.name, values, field.derived !== true));
    }
    return uses;
}
function seedUses(data, enumerations, tables) {
    const scenarios = arrayOf(data.scenarios).filter(isRecord);
    const inferred = new Map();
    const pending = new Map();
    for (const scenario of scenarios) {
        if (typeof scenario.stateField === 'string' && scenario.stateField)
            continue;
        const entityId = scenarioEntity(scenario, tables);
        if (!entityId)
            continue;
        const states = stringList(scenario.states);
        pending.set(entityId, [...(pending.get(entityId) || []), ...states]);
    }
    for (const [entityId, states] of pending) {
        const path = lifecyclePath(entityId, [...new Set(states)], enumerations);
        if (path)
            inferred.set(entityId, path);
    }
    const uses = [];
    for (const scenario of scenarios) {
        const scenarioId = typeof scenario.scenarioId === 'string' ? scenario.scenarioId : '';
        const entityId = scenarioEntity(scenario, tables);
        const path = typeof scenario.stateField === 'string' && scenario.stateField
            ? scenario.stateField
            : entityId ? inferred.get(entityId) || '' : '';
        if (!scenarioId || !entityId || !path)
            continue;
        const match = enumerations.find(item => item.entityId === entityId && item.path === path);
        const values = match ? provedValues(stringList(scenario.states), match.values) : null;
        if (!match || !values)
            continue;
        uses.push(useOf('seedScenario', scenarioId, entityId, path, values, true));
    }
    return uses;
}
function scenarioEntity(scenario, tables) {
    if (typeof scenario.entityId === 'string' && scenario.entityId)
        return scenario.entityId;
    const tableId = typeof scenario.tableId === 'string' ? scenario.tableId : '';
    return tableId ? tables.get(tableId) || '' : '';
}
function useOf(purpose, consumer, entityId, path, values, editable) {
    return { purpose, consumer, entityId, path, values: [...values], editable };
}
function provedValues(literals, effective) {
    if (!literals.length)
        return null;
    if (literals.some(value => !effective.includes(value)))
        return null;
    return [...literals];
}
function closedLiterals(type) {
    const parts = splitTop(type.trim(), '|');
    if (!parts.length)
        return null;
    const values = [];
    for (const part of parts) {
        const text = part.trim();
        const match = /^"((?:\\.|[^"\\])*)"$/.exec(text) || /^'((?:\\.|[^'\\])*)'$/.exec(text);
        if (!match)
            return null;
        values.push(match[1].replace(/\\(["'\\])/g, '$1'));
    }
    return values;
}
function splitTop(type, separator) {
    const parts = [];
    let depth = 0;
    let inString = false;
    let quote = '';
    let escaped = false;
    let start = 0;
    for (let index = 0; index < type.length; index += 1) {
        const char = type[index];
        if (inString) {
            if (escaped)
                escaped = false;
            else if (char === '\\')
                escaped = true;
            else if (char === quote)
                inString = false;
            continue;
        }
        if (char === '"' || char === "'") {
            inString = true;
            quote = char;
            continue;
        }
        if (char === '{' || char === '(' || char === '[')
            depth += 1;
        else if (char === '}' || char === ')' || char === ']')
            depth -= 1;
        else if (char === separator && depth === 0) {
            parts.push(type.slice(start, index));
            start = index + 1;
        }
    }
    parts.push(type.slice(start));
    return parts;
}
function bodiesOf(sources) {
    const bodies = { entities: {}, index: null, rules: null, catalogs: {} };
    for (const [path, text] of Object.entries(sources)) {
        const parsed = parseD1Source(text, 'defs');
        if (!isRecord(parsed))
            continue;
        if (typeof parsed.entityId === 'string' && isRecord(parsed.record))
            bodies.entities[parsed.entityId] = parsed;
        else if (isRecord(parsed.groups) && isRecord(parsed.subtypes) && isRecord(parsed.record))
            bodies.catalogs[path] = parsed;
        else if (Array.isArray(parsed.entities) && Array.isArray(parsed.relationships))
            bodies.index = parsed;
        else if (!parsed.entityId && isRecord(parsed.rules))
            bodies.rules = parsed;
    }
    return bodies;
}
function emptyOrigin() {
    return {
        owner: 'unresolved',
        writer: 'unresolved',
        derived: false,
        restriction: 'unresolved',
        catalogValues: [],
        catalogSource: '',
        roleBinding: false,
    };
}
function fieldAt(entity, path) {
    const record = isRecord(entity.record) ? entity.record : null;
    let cursor = record ? record.fields : null;
    const parts = path.split('.');
    for (let index = 0; index < parts.length; index += 1) {
        if (!isRecord(cursor))
            return null;
        const next = cursor[parts[index]];
        if (!isRecord(next))
            return null;
        if (index === parts.length - 1)
            return next;
        cursor = next.fields;
    }
    return null;
}
function sameSet(left, right) {
    if (left.length !== right.length)
        return false;
    const values = new Set(right);
    return left.every(value => values.has(value));
}
function arrayOf(value) {
    return Array.isArray(value) ? value : [];
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string' && item.length > 0);
}
function isModuleEntity(value) {
    return (value.kind === 'role' || value.kind === 'entity' || value.kind === 'platform')
        && typeof value.entityId === 'string'
        && typeof value.moduleName === 'string'
        && typeof value.title === 'string'
        && typeof value.description === 'string'
        && typeof value.displayField === 'string'
        && isRecord(value.record)
        && isRecord(value.relationships)
        && isRecord(value.capabilities)
        && Array.isArray(value.rules)
        && (value.kind !== 'role' || typeof value.subtype === 'string');
}
function isIndex(value) {
    return isRecord(value) && Array.isArray(value.relationships);
}
function isCatalog(value) {
    return isRecord(value) && isRecord(value.groups) && isRecord(value.subtypes) && isRecord(value.record)
        && isRecord(value.capabilities) && isRecord(value.rules);
}
function isRules(value) {
    if (!isRecord(value))
        return false;
    if (value.schemaVersion === '2026-09-10-ns5-rules-v1')
        return Array.isArray(value.rules);
    return isRecord(value.rules);
}
