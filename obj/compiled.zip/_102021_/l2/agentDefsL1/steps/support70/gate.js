/// <mls fileReference="_102021_/l2/agentDefsL1/steps/support70/gate.ts" enhancement="_blank"/>
import { D1_DEFINITION_SCHEMA, D1_MEASURED_PUBLISH, definitionIssues, fictionalMechanism, } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { cycleIssues, futureOutputPath, pipelineId, qualifyDefPath, skillPaths, } from '/_102021_/l2/agentDefsL1/helpers/d1Refs.js';
import { renderDefinition } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { D1_SUPPORT_VERSION, ENUMERATION_SOURCE, } from '/_102021_/l2/agentDefsL1/steps/support70/contracts.js';
import { lifecyclePath, projectEnumerations } from '/_102021_/l2/agentDefsL1/steps/support70/enumerations.js';
const LIVE_ACTIONS = new Set(['create', 'update', 'recompose', 'preserve']);
const WRITE_ACTIONS = new Set(['create', 'update', 'recompose']);
const FORM_IDENTITY = new Set(['actorId', 'userId', 'sessionId', 'scope']);
const APPLICATION = new Set(['usecase', 'httpController', 'accessScope', 'authorityMap', 'repositoryPort']);
const SCOPE_PATH = (moduleName) => `l1/${moduleName}/layer_2_application/scope/accessScope.defs.ts`;
const AUTH_PATH = (moduleName) => `l1/${moduleName}/layer_1_external/auth/authorityMap.defs.ts`;
const REGISTRY_PATH = (moduleName) => `l1/${moduleName}/layer_1_external/adapters/persistence/registerRepositories.defs.ts`;
const SEEDS_PATH = (moduleName) => `l1/${moduleName}/layer_1_external/adapters/persistence/seeds.defs.ts`;
const OUTBOUND_PATH = (moduleName) => `l1/${moduleName}/layer_1_external/adapters/integration/outbound.defs.ts`;
const NOTE_RULE = 'attendanceNoteRequired';
/**
 * Registry, scope and the seed plan. No model call. Grants and anchors are copied.
 * A missing grant or an anchor with no explicit path is a diagnosis.
 * It is not rewritten as organization or public.
 * Seeds describe scenarios. They do not write rows.
 * Effects name the consumer and keep an empty mechanism when none was declared.
 * Nothing is published.
 */
export function buildD1Support(request) {
    const problems = [];
    const normalizations = [];
    noteFormIdentity(request, problems);
    noteReceipts(request, problems);
    const scope = emitScope(request, problems);
    const registry = emitRegistry(request, problems, normalizations);
    const seeds = emitSeeds(request, problems, normalizations);
    const effects = emitEffects(request, problems);
    noteInverted(request, scope.emit, registry.emit, problems);
    noteDag(request, scope.emit, registry.emit, seeds.emit, effects.emit, registry.live, problems);
    const errored = problems.some(problem => problem.severity === 'error');
    const emit = errored ? [] : [...scope.emit, ...registry.emit, ...seeds.emit, ...effects.emit];
    for (const part of emit) {
        const rendered = renderDefinition(part.definition, part.pipeline);
        if ('issues' in rendered) {
            error(problems, 'DEFINITION', part.pipeline[0]?.defPath || '', rendered.issues[0] || 'Definition did not render.');
        }
        else if (/\bimport\b/.test(rendered.source)) {
            error(problems, 'RUNTIME_IMPORT', part.pipeline[0]?.defPath || '', 'Support source imports a module.');
        }
    }
    const stillOk = !problems.some(problem => problem.severity === 'error');
    const enumerations = classifyEnumerations(request, stillOk ? seeds.citations : []);
    return finish(request, stillOk, enumerations, scope.resolutions, scope.helpers, scope.removedHelpers, registry.adapters, problems, normalizations, stillOk ? emit : [], stillOk ? seeds.plan : absentPlan(), stillOk ? effects.report : absentEffects());
}
/** Access scope and the authority map. The map adds no grant. */
export function emitScope(request, problems) {
    const known = new Set(request.grants.map(grant => grant.grantId));
    for (const grantId of [...request.citedGrantIds].sort()) {
        if (!grantId || known.has(grantId))
            continue;
        review(problems, 'GRANT_ABSENT', grantId, `Grant ${grantId} is not in the access artifact. No organization or public scope was created.`);
    }
    const resolutions = request.grants.map(grant => resolveGrant(request, grant, problems));
    resolutions.sort((left, right) => left.grantId.localeCompare(right.grantId));
    const helpers = shareHelpers(resolutions);
    const liveIds = new Set(helpers.map(helper => helper.helperId));
    const removedHelpers = request.existingHelpers
        .map(helper => helper.helperId)
        .filter(helperId => helperId && !liveIds.has(helperId))
        .sort();
    const scopeGrants = resolutions.map(resolution => grantData(resolution));
    const scopeDefinition = definitionFor(request, 'accessScope', 'accessScope', {
        scopeId: 'accessScope',
        grants: scopeGrants,
    });
    const authDefinition = definitionFor(request, 'authorityMap', 'authorityMap', {
        mapId: 'authorityMap',
        entries: resolutions.map(resolution => ({ grantId: resolution.grantId, actorRef: resolution.actorRef })),
    });
    const scopePath = filePath(request, 'accessScope', SCOPE_PATH(request.moduleName));
    const authPath = filePath(request, 'authorityMap', AUTH_PATH(request.moduleName));
    const emit = [];
    if (scopeGrants.length && writable(request, 'accessScope', problems, true)) {
        pushDefinition(emit, scopeDefinition, scopePipeline(request, scopePath), scopePath, problems);
    }
    if (resolutions.length && writable(request, 'authorityMap', problems, true)) {
        pushDefinition(emit, authDefinition, authPipeline(request, authPath, scopePath), authPath, problems);
    }
    return { resolutions, helpers, removedHelpers, emit };
}
/** Live adapters only. The registry depends on them. They do not depend on it. */
export function emitRegistry(request, problems, normalizations) {
    const live = [];
    for (const adapter of request.adapters) {
        if (!LIVE_ACTIONS.has(adapter.action))
            continue;
        if (!adapter.portId || !adapter.defPath) {
            error(problems, 'ADAPTER_UNRESOLVED', adapter.portId || adapter.defPath || 'registry', `Adapter ${adapter.portId || '(missing)'} has no port or path. It was not registered.`);
            continue;
        }
        live.push(adapter);
    }
    live.sort((left, right) => left.portId.localeCompare(right.portId));
    const adapters = live.map(adapter => ({
        portId: adapter.portId,
        adapterArtifactId: adapter.artifactId || adapter.portId,
        factory: adapter.artifactId || adapter.portId,
        defPath: adapter.defPath,
        dependsOn: [pipelineId(request.project, request.moduleName, 'repositoryAdapter', adapter.portId)],
    }));
    const registryFile = request.files.find(file => file.artifactType === 'repositoryRegistration');
    if (registryFile?.action === 'remove' && adapters.length > 0) {
        normalizations.push({
            code: 'REGISTRY_KEPT',
            path: registryFile.defPath,
            detail: 'The registry still has a live adapter. It was not removed.',
        });
    }
    const emit = [];
    if (!adapters.length)
        return { adapters, live, emit };
    if (!writable(request, 'repositoryRegistration', problems, true))
        return { adapters, live, emit };
    const defPath = filePath(request, 'repositoryRegistration', REGISTRY_PATH(request.moduleName));
    const definition = definitionFor(request, 'repositoryRegistration', 'registerRepositories', {
        registrationId: 'registerRepositories',
        adapters: adapters.map(adapter => ({ portId: adapter.portId, adapterArtifactId: adapter.adapterArtifactId })),
    });
    pushDefinition(emit, definition, registryPipeline(request, defPath, adapters), defPath, problems);
    return { adapters, live, emit };
}
/**
 * One seed plan for the local tables. Journeys and models supply scenarios.
 * MDM roles are dependencies, not rows. A ref needs a column relationship.
 */
export function emitSeeds(request, problems, normalizations) {
    const empty = { emit: [], plan: absentPlan(), citations: [] };
    if (request.maintenance?.action === 'reseed') {
        error(problems, 'MAINTENANCE_RESEED', 'seeds', 'Maintenance does not reseed. No rows were written.');
        return empty;
    }
    if (request.maintenance?.action === 'reset') {
        error(problems, 'MAINTENANCE_RESET', 'seeds', 'Maintenance does not reset seed data. No rows were written.');
        return empty;
    }
    for (const journeyId of [...request.missingJourneys].sort()) {
        error(problems, 'SEED_SOURCE_ABSENT', journeyId, `Journey ${journeyId} is named and was not read. No scenario was invented for it.`);
    }
    if (request.missingJourneys.length)
        return empty;
    const scenarios = [];
    const datasets = [];
    const citations = [];
    const localEntities = new Set();
    for (const table of [...request.tables].sort((left, right) => left.tableId.localeCompare(right.tableId))) {
        if (!LIVE_ACTIONS.has(table.action))
            continue;
        const model = request.models.find(item => item.entityId === table.entityId);
        if (!table.tableId || !table.entityId || !table.defPath || !model) {
            error(problems, 'SEED_TABLE', table.tableId || table.entityId || 'seeds', `Table ${table.tableId || '(missing)'} has no model or path. It was not seeded.`);
            continue;
        }
        if (model.storageTarget === 'mdm' || model.kind === 'role') {
            error(problems, 'SEED_MDM', table.tableId, `Table ${table.tableId} belongs to MDM role ${model.entityId}. No local seed and no extra namespace were created.`);
            continue;
        }
        if (model.namespace && model.namespace !== request.moduleName) {
            error(problems, 'SEED_NAMESPACE', model.namespace, `Namespace ${model.namespace} is not the module. No seed namespace was created.`);
            continue;
        }
        const refs = columnRefs(request, model, problems);
        if (problems.some(problem => problem.severity === 'error' && (problem.code === 'SEED_REF_UNRELATED' || problem.code === 'SEED_ROLE_TAG'))) {
            return empty;
        }
        const planning = model.uniqueKeys.length ? model : { ...model, uniqueKeys: table.uniqueKeys };
        const stateField = lifecyclePath(model.entityId, planning.states, request.enumerations);
        const journeys = request.journeys
            .filter(item => item.entities.includes(model.entityId))
            .sort((left, right) => left.journeyId.localeCompare(right.journeyId));
        const built = journeys.length
            ? journeys.map(item => scenarioOf(table.tableId, planning, refs, item, stateField))
            : [modelScenario(table.tableId, planning, refs, stateField)];
        citations.push(...citationsOf(model.entityId, stateField, built));
        scenarios.push(...built);
        const owners = ownerIds(built.map(item => String(item.scenarioId)), request);
        if (!owners.length)
            continue;
        const previous = request.existingDatasets.find(item => item.tableId === table.tableId);
        if (previous && previous.owners.some(owner => !owners.includes(owner))) {
            normalizations.push({
                code: 'DATASET_KEPT',
                path: table.tableId,
                detail: `Dataset ${table.tableId} still has an owner. Removing one owner did not drop it.`,
            });
        }
        datasets.push({ datasetId: table.tableId, tableId: table.tableId, owners });
        localEntities.add(model.entityId);
    }
    if (problems.some(problem => problem.severity === 'error' && problem.code.startsWith('SEED_')))
        return empty;
    if (!scenarios.length)
        return empty;
    const removed = request.files.find(file => file.artifactType === 'persistenceSeeds' && file.action === 'remove');
    if (removed) {
        normalizations.push({
            code: 'DATASET_KEPT',
            path: removed.defPath,
            detail: 'The seed dataset still has an owner. It was not removed.',
        });
    }
    if (!writable(request, 'persistenceSeeds', problems, true))
        return { emit: [], plan: planOf(scenarios, datasets, request, localEntities), citations };
    const dependencies = dependenciesOf(request, localEntities);
    const data = {
        seedId: 'seeds',
        phase: 'plan',
        scenarios,
        dependencies,
        datasets,
    };
    const defPath = filePath(request, 'persistenceSeeds', SEEDS_PATH(request.moduleName));
    const definition = definitionFor(request, 'persistenceSeeds', 'seeds', data);
    const emit = [];
    pushDefinition(emit, definition, seedsPipeline(request, defPath, datasets), defPath, problems);
    if (problems.some(problem => problem.severity === 'error'))
        return empty;
    return { emit, plan: { phase: 'plan', materialized: false, rowCount: 0, datasets, dependencies }, citations };
}
function columnRefs(request, model, problems) {
    const refs = [];
    const relationships = request.relationships
        .filter(rel => rel.from === model.entityId && rel.field)
        .sort((left, right) => left.relationshipId.localeCompare(right.relationshipId));
    for (const rel of relationships) {
        const field = columnField(rel.field, model.entityId);
        if (!rel.relationshipId || structuredField(model, field)) {
            error(problems, 'SEED_REF_UNRELATED', field, `Ref on ${field} has no column relationship. It was not seeded.`);
            continue;
        }
        if (!entityIdOf(request, rel.to)) {
            error(problems, 'SEED_ROLE_TAG', rel.to || field, `Ref target ${rel.to || '(missing)'} is a role tag, not an MDM entity id. No seed namespace was created.`);
            continue;
        }
        refs.push({ field, relationshipId: rel.relationshipId, entityId: rel.to });
    }
    for (const proposed of [...request.seedRefs].sort((left, right) => left.field.localeCompare(right.field))) {
        const match = refs.some(ref => ref.field === proposed.field && ref.relationshipId === proposed.relationshipId && ref.entityId === proposed.entityId);
        if (match)
            continue;
        if (roleTag(request, proposed.entityId)) {
            error(problems, 'SEED_ROLE_TAG', proposed.entityId, `Ref target ${proposed.entityId} is a role tag, not an MDM entity id. No seed namespace was created.`);
        }
        else {
            error(problems, 'SEED_REF_UNRELATED', proposed.field, `Ref on ${proposed.field} has no column relationship. It was not seeded.`);
        }
    }
    refs.sort((left, right) => left.field.localeCompare(right.field));
    return refs;
}
function scenarioOf(tableId, model, refs, journey, stateField) {
    const effect = journey.effects.find(item => item.entityId === model.entityId);
    const transition = effect?.transitionRef
        ? model.transitions.find(item => item.transitionId === effect.transitionRef)
        : undefined;
    const states = [];
    if (transition?.to)
        states.push(transition.to);
    else if (effect?.effect === 'create' && model.initialState)
        states.push(model.initialState);
    const noteState = transition && model.noteField && transition.ruleRefs.includes(NOTE_RULE) ? transition.to : '';
    const requires = noteState ? [model.noteField] : [];
    return scenarioRecord(journey.journeyId, tableId, `journey:${journey.journeyId}`, model, refs, states, requires, noteState, stateField);
}
function modelScenario(tableId, model, refs, stateField) {
    const states = [...model.states];
    const noteState = model.transitions.find(item => item.ruleRefs.includes(NOTE_RULE) && item.to)?.to || '';
    const requires = noteState && model.noteField ? [model.noteField] : [];
    return scenarioRecord(`model-${tableId}`, tableId, `model:${model.entityId}`, model, refs, states, requires, noteState, stateField);
}
function citationsOf(entityId, stateField, scenarios) {
    if (!stateField)
        return [];
    const citations = [];
    for (const scenario of scenarios) {
        const scenarioId = typeof scenario.scenarioId === 'string' ? scenario.scenarioId : '';
        const values = Array.isArray(scenario.states) ? scenario.states.filter((item) => typeof item === 'string' && !!item) : [];
        if (!scenarioId || !values.length)
            continue;
        citations.push({ entityId, path: stateField, scenarioId, values });
    }
    return citations;
}
function scenarioRecord(scenarioId, tableId, source, model, refs, states, requires, noteState, stateField) {
    const constraints = [
        ...uniqueConstraints(model),
        ...refs.map(ref => `ref:${ref.field}:${ref.entityId}`),
        ...states.map(state => `state:${state}`),
        ...requires.map(field => `noteRequired:${field}:${noteState}`),
    ].sort();
    const record = {
        scenarioId,
        tableId,
        source,
        constraints,
        refs: refs.map(ref => ({ ...ref })),
        states: [...states],
        entityId: model.entityId,
    };
    if (stateField)
        record.stateField = stateField;
    if (requires.length)
        record.requires = [...requires];
    return record;
}
function uniqueConstraints(model) {
    return model.uniqueKeys
        .filter(key => key.length > 0)
        .map(key => `uniqueKeys:${key.join('+')}`);
}
function ownerIds(scenarioIds, request) {
    let owners = [...scenarioIds];
    if (request.maintenance?.action === 'removeOwner' && request.maintenance.ownerId) {
        owners = owners.filter(owner => owner !== request.maintenance?.ownerId);
    }
    return [...new Set(owners)].sort();
}
function planOf(scenarios, datasets, request, localEntities) {
    if (!scenarios.length)
        return absentPlan();
    return {
        phase: 'plan',
        materialized: false,
        rowCount: 0,
        datasets: datasets.map(item => ({ ...item, owners: [...item.owners] })),
        dependencies: dependenciesOf(request, localEntities),
    };
}
function dependenciesOf(request, localEntities) {
    const dependencies = [];
    for (const model of [...request.models].sort((left, right) => left.entityId.localeCompare(right.entityId))) {
        const local = localEntities.has(model.entityId);
        if (!local && model.kind !== 'role' && model.storageTarget !== 'mdm')
            continue;
        dependencies.push({
            entityId: model.entityId,
            kind: local ? 'module' : 'mdm',
            seeded: false,
        });
    }
    return dependencies;
}
function entityIdOf(request, value) {
    if (!value || roleTag(request, value))
        return false;
    return request.models.some(model => model.entityId === value);
}
function roleTag(request, value) {
    if (!value)
        return false;
    if (request.models.some(model => model.entityId === value))
        return false;
    return request.roleTags.some(item => item.tag === value);
}
function columnField(raw, entityId) {
    const prefix = `${entityId}.`;
    return raw.startsWith(prefix) ? raw.slice(prefix.length) : raw;
}
function structuredField(model, field) {
    if (field.includes('.'))
        return true;
    const found = model.fields.find(item => item.name === field);
    return found?.type === 'object';
}
function seedsPipeline(request, defPath, datasets) {
    const qualified = qualifyDefPath(request.project, defPath);
    const tables = [...new Set(datasets.map(item => item.tableId))].sort();
    const dependsOn = tables.map(tableId => pipelineId(request.project, request.moduleName, 'table', tableId));
    const dependsFiles = tables.map(tableId => {
        const table = request.tables.find(item => item.tableId === tableId);
        return qualifyDefPath(request.project, table?.defPath || `l1/${request.moduleName}/layer_1_external/adapters/persistence/${tableId}.defs.ts`);
    }).sort();
    return {
        id: pipelineId(request.project, request.moduleName, 'persistenceSeeds', 'seeds'),
        type: 'persistenceSeeds',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles,
        dependsOn,
        skills: skillPaths('persistenceSeeds'),
    };
}
function resolveGrant(request, grant, problems) {
    const plan = request.scopePlans.find(item => item.grantId === grant.grantId);
    const relationships = relationshipsFor(request, grant);
    const anchor = plan?.anchorEntity ?? grant.anchorEntity;
    const entityRefs = [...(plan?.entityRefs || grant.entityRefs)];
    const path = pathToAnchor(entityRefs, anchor, relationships);
    let pending = plan?.pending || '';
    if (!pending && anchor && !entityRefs.includes(anchor)) {
        const others = request.relationships.filter(rel => rel.required && entityRefs.includes(rel.from) && rel.to && rel.to !== anchor);
        if (others.length)
            pending = 'ACCESS_ANCHOR';
    }
    if (pending === 'ACCESS_ANCHOR') {
        review(problems, 'ACCESS_ANCHOR', grant.grantId, `Grant ${grant.grantId} anchors on ${anchor}. The contradictory relationship stays pending for the owner. The anchor was not rewritten.`);
    }
    if (anchor && !entityRefs.includes(anchor) && !path.length) {
        review(problems, 'ANCHOR_UNRESOLVED', grant.grantId, `Grant ${grant.grantId} anchors on ${anchor}, which has no explicit relationship path. The scope was not changed to organization or public.`);
    }
    const helperId = path.length ? `join:${path.map(step => step.relationshipId).join('>')}` : '';
    return {
        grantId: grant.grantId,
        actorRef: grant.actorRef,
        entityRefs,
        disclosure: grant.disclosure,
        allowedFields: grant.disclosure === 'fieldsOnly' ? [...grant.allowedFields] : [],
        anchorEntity: anchor,
        scopeMode: grant.scopeMode,
        session: 'verified',
        path,
        pending,
        helperId,
    };
}
function relationshipsFor(request, grant) {
    const plan = request.scopePlans.find(item => item.grantId === grant.grantId);
    if (plan) {
        return plan.relationships.map(rel => ({
            relationshipId: rel.relationshipId,
            from: rel.from,
            to: rel.to,
            field: rel.field,
            required: request.relationships.find(item => item.relationshipId === rel.relationshipId)?.required === true,
        }));
    }
    return request.relationships.filter(rel => grant.entityRefs.includes(rel.from));
}
/** Shortest chain of relationships that declare a field. An Id suffix is not a field. */
function pathToAnchor(entityRefs, anchor, relationships) {
    if (!anchor || entityRefs.includes(anchor))
        return [];
    const edges = relationships
        .filter(rel => rel.field && rel.from && rel.to)
        .slice()
        .sort((left, right) => left.relationshipId.localeCompare(right.relationshipId));
    const queue = [...entityRefs]
        .sort()
        .map(at => ({ at, steps: [] }));
    const seen = new Set(entityRefs);
    while (queue.length) {
        const current = queue.shift();
        if (!current)
            break;
        for (const edge of edges) {
            if (edge.from !== current.at)
                continue;
            const steps = [...current.steps, {
                    relationshipId: edge.relationshipId,
                    from: edge.from,
                    to: edge.to,
                    field: edge.field,
                }];
            if (edge.to === anchor)
                return steps;
            if (seen.has(edge.to))
                continue;
            seen.add(edge.to);
            queue.push({ at: edge.to, steps });
        }
    }
    return [];
}
function shareHelpers(resolutions) {
    const groups = new Map();
    for (const resolution of resolutions) {
        if (!resolution.helperId)
            continue;
        const existing = groups.get(resolution.helperId);
        if (existing) {
            if (!existing.consumers.includes(resolution.grantId))
                existing.consumers.push(resolution.grantId);
            continue;
        }
        groups.set(resolution.helperId, {
            helperId: resolution.helperId,
            session: 'verified',
            steps: resolution.path.map(step => ({ ...step })),
            consumers: [resolution.grantId],
        });
    }
    const helpers = [...groups.values()];
    for (const helper of helpers)
        helper.consumers.sort();
    helpers.sort((left, right) => left.helperId.localeCompare(right.helperId));
    return helpers;
}
function grantData(resolution) {
    const data = {
        grantId: resolution.grantId,
        actorRef: resolution.actorRef,
    };
    if (resolution.anchorEntity)
        data.anchorEntity = resolution.anchorEntity;
    data.entityRefs = resolution.entityRefs;
    data.disclosure = resolution.disclosure;
    if (resolution.disclosure === 'fieldsOnly')
        data.allowedFields = resolution.allowedFields;
    return data;
}
function noteFormIdentity(request, problems) {
    const names = request.formFields.filter(name => FORM_IDENTITY.has(name)).sort();
    for (const name of names) {
        error(problems, 'FORM_IDENTITY', name, `Form field ${name} is not authentication. The session stays verified. No identity field was added.`);
    }
}
function noteReceipts(request, problems) {
    for (const file of request.files) {
        if (file.action === 'conflict') {
            error(problems, 'RECEIPT_MISMATCH', file.defPath, `File ${file.defPath} has no usable receipt. It was not overwritten.`);
            continue;
        }
        if (!file.contentHash || !file.currentHash)
            continue;
        if (file.contentHash === file.currentHash)
            continue;
        error(problems, 'RECEIPT_MISMATCH', file.defPath, `Receipt hash for ${file.defPath} does not match the bytes on disk. The file was not overwritten.`);
    }
}
function noteInverted(request, scope, registry, problems) {
    const edges = [
        ...request.applicationEdges,
        ...scope.map(part => edgeOf(part.pipeline[0])),
        ...registry.map(part => edgeOf(part.pipeline[0])),
    ];
    for (const edge of edges) {
        if (!APPLICATION.has(edge.type))
            continue;
        for (const dep of edge.dependsOn) {
            if (dep.includes('/repositoryAdapter/') || dep.includes('/repositoryRegistration/')) {
                error(problems, 'INVERTED_IMPORT', edge.id, `Application ${edge.id} depends on ${dep}.`);
            }
        }
    }
}
function noteDag(request, scope, registry, seeds, effects, live, problems) {
    const tableIds = new Set();
    for (const part of seeds) {
        for (const dep of part.pipeline[0]?.dependsOn || []) {
            if (dep.includes('/table/'))
                tableIds.add(dep);
        }
    }
    const nodes = [
        ...scope.map(part => edgeOf(part.pipeline[0])),
        ...registry.map(part => edgeOf(part.pipeline[0])),
        ...seeds.map(part => edgeOf(part.pipeline[0])),
        ...effects.map(part => edgeOf(part.pipeline[0])),
        ...live.map(adapter => ({
            id: pipelineId(request.project, request.moduleName, 'repositoryAdapter', adapter.portId),
            type: 'repositoryAdapter',
            dependsOn: [],
        })),
        ...[...tableIds].sort().map(id => ({ id, type: 'table', dependsOn: [] })),
    ];
    for (const issue of cycleIssues(nodes)) {
        error(problems, 'CYCLE', 'pipeline', issue);
    }
}
function writable(request, artifactType, problems, sharedLive) {
    const file = request.files.find(item => item.artifactType === artifactType);
    if (!file)
        return true;
    if (problems.some(problem => problem.severity === 'error' && problem.code === 'RECEIPT_MISMATCH' && problem.path === file.defPath)) {
        return false;
    }
    if (file.action === 'preserve' || file.action === 'conflict')
        return false;
    if (file.action === 'remove')
        return sharedLive;
    return WRITE_ACTIONS.has(file.action);
}
function filePath(request, artifactType, fallback) {
    return request.files.find(file => file.artifactType === artifactType)?.defPath || fallback;
}
function scopePipeline(request, defPath) {
    const qualified = qualifyDefPath(request.project, defPath);
    return {
        id: pipelineId(request.project, request.moduleName, 'accessScope', 'accessScope'),
        type: 'accessScope',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles: [],
        dependsOn: [],
        skills: skillPaths('accessScope'),
    };
}
function authPipeline(request, defPath, scopePath) {
    const qualified = qualifyDefPath(request.project, defPath);
    const scopeQualified = qualifyDefPath(request.project, scopePath);
    return {
        id: pipelineId(request.project, request.moduleName, 'authorityMap', 'authorityMap'),
        type: 'authorityMap',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles: [scopeQualified],
        dependsOn: [pipelineId(request.project, request.moduleName, 'accessScope', 'accessScope')],
        skills: skillPaths('authorityMap'),
    };
}
function registryPipeline(request, defPath, adapters) {
    const qualified = qualifyDefPath(request.project, defPath);
    const dependsOn = adapters.flatMap(adapter => adapter.dependsOn).sort();
    const dependsFiles = adapters.map(adapter => qualifyDefPath(request.project, adapter.defPath)).sort();
    return {
        id: pipelineId(request.project, request.moduleName, 'repositoryRegistration', 'registerRepositories'),
        type: 'repositoryRegistration',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles,
        dependsOn,
        skills: skillPaths('repositoryRegistration'),
    };
}
function definitionFor(request, artifactType, artifactId, data) {
    return {
        schemaVersion: D1_DEFINITION_SCHEMA,
        artifactType,
        artifactId,
        moduleName: request.moduleName,
        data,
    };
}
function pushDefinition(emit, definition, pipeline, defPath, problems) {
    const issues = definitionIssues(definition);
    if (issues.length) {
        error(problems, 'DEFINITION', defPath, issues[0]);
        return;
    }
    emit.push({ definition, pipeline: [pipeline] });
}
function edgeOf(item) {
    return {
        id: item?.id || '',
        type: item?.type || '',
        dependsOn: [...(item?.dependsOn || [])],
    };
}
function classifyEnumerations(request, citations) {
    return projectEnumerations({
        enumerations: request.enumerations,
        snapshot: request.enumSnapshot,
        seedCitations: citations,
    });
}
/**
 * One outbound def. Events keep the transition as consumer.
 * An empty mechanism stays empty. publishEvent and emitEvent are refused.
 * IQueueRuntime.publish is evidence, not an approved binding.
 * Processes, inbound and plugins stay operations. A scheduled trigger writes no scheduler.
 */
export function emitEffects(request, problems) {
    const empty = { emit: [], report: absentEffects() };
    const known = new Set(request.usecaseIds);
    for (const eventId of [...request.selectedEventIds].sort()) {
        if (request.outbound.some(event => event.eventId === eventId))
            continue;
        error(problems, 'INTEGRATION_OMITTED', eventId, `Outbound ${eventId} was selected and is missing. It was not dropped.`);
    }
    if (problems.some(problem => problem.severity === 'error' && problem.code === 'INTEGRATION_OMITTED'))
        return empty;
    const events = [];
    for (const event of [...request.outbound].sort((left, right) => left.eventId.localeCompare(right.eventId))) {
        const parts = event.on.split('.');
        const entityId = parts[0] || '';
        const transition = parts[1] || '';
        if (!event.eventId || !entityId || !transition || parts.length !== 2 || !known.has(transition)) {
            error(problems, 'INTEGRATION_LINK', event.eventId || event.on, `Outbound ${event.eventId || event.on} does not name a selected usecase.`);
            continue;
        }
        const resolved = resolveMechanism(event.mechanism, event.eventId, problems);
        if (!resolved)
            continue;
        const rules = uniqueRules(request, entityId, transition);
        if (!event.payloadDeclared && rules.length) {
            review(problems, 'PAYLOAD_UNDECLARED', transition, `Transition ${transition} cites ${rules.join(', ')} and declares no payload. No payload was invented.`);
        }
        const row = {
            eventId: event.eventId,
            on: event.on,
            entityId,
            mechanism: resolved.mechanism,
            consumer: transition,
        };
        if (resolved.mechanismRef)
            row.mechanismRef = resolved.mechanismRef;
        events.push(row);
    }
    const processes = [];
    const inbound = [];
    const plugins = [];
    const gaps = [];
    for (const operation of [...request.operations].sort((left, right) => left.id.localeCompare(right.id))) {
        const resolved = resolveMechanism(operation.mechanism, operation.id, problems);
        if (!resolved)
            continue;
        const outside = operation.operations.filter(item => !inPool(item, known));
        if (!operation.operations.length || outside.length) {
            gaps.push({ itemId: operation.id, kind: operation.kind, code: 'POOL_ABSENT' });
            review(problems, 'POOL_ABSENT', operation.id, `${operation.kind} ${operation.id} is not in the selected pool. It was kept and no endpoint was added.`);
        }
        if (operation.scheduled) {
            review(problems, 'SCHEDULER_NOT_WRITTEN', operation.id, `${operation.kind} ${operation.id} declares a scheduled trigger. No runtime scheduler was written.`);
        }
        const row = {
            operations: [...operation.operations],
            mechanism: resolved.mechanism,
            consumer: operation.consumer || operation.id,
        };
        if (operation.kind === 'process')
            processes.push({ processId: operation.id, ...row });
        else if (operation.kind === 'inbound')
            inbound.push({ inboundId: operation.id, ...row });
        else
            plugins.push({ pluginId: operation.id, ...row });
    }
    if (problems.some(problem => problem.severity === 'error'))
        return empty;
    if (!events.length && !processes.length && !inbound.length && !plugins.length)
        return empty;
    const data = { integrationId: 'outbound', events };
    if (processes.length)
        data.processes = processes;
    if (inbound.length)
        data.inbound = inbound;
    if (plugins.length)
        data.plugins = plugins;
    if (gaps.length)
        data.gaps = gaps.sort((left, right) => String(left.itemId).localeCompare(String(right.itemId)));
    if (!writable(request, 'integrationOutbound', problems, true)) {
        return { emit: [], report: { phase: 'plan', executed: false, capability: capabilityOf(false) } };
    }
    const defPath = filePath(request, 'integrationOutbound', OUTBOUND_PATH(request.moduleName));
    const consumers = events.map(event => String(event.consumer));
    const definition = definitionFor(request, 'integrationOutbound', 'outbound', data);
    const emit = [];
    pushDefinition(emit, definition, effectsPipeline(request, defPath, consumers), defPath, problems);
    if (problems.some(problem => problem.severity === 'error'))
        return empty;
    return { emit, report: { phase: 'plan', executed: false, capability: capabilityOf(false) } };
}
function resolveMechanism(raw, label, problems) {
    const mechanism = raw.trim();
    if (fictionalMechanism(mechanism)) {
        error(problems, 'FICTIONAL_API', label, `Mechanism ${mechanism} is not on RequestContext. publishEvent and emitEvent were not written.`);
        return null;
    }
    if (!mechanism) {
        review(problems, 'INTEGRATION_UNBOUND', label, `${label} is preserved. No runtime mechanism is named.`);
        return { mechanism: '', mechanismRef: '' };
    }
    if (mechanism === D1_MEASURED_PUBLISH.symbol) {
        review(problems, 'MECHANISM_INCOMPATIBLE', label, `${label} names ${mechanism}. Postgres publish inserts into mdm_outbox. It is not a module bus.`);
        return { mechanism, mechanismRef: D1_MEASURED_PUBLISH.path };
    }
    review(problems, 'MECHANISM_UNVERIFIED', label, `Mechanism ${mechanism} is not an approved module integration. It was kept and not executed.`);
    return { mechanism, mechanismRef: '' };
}
function uniqueRules(request, entityId, transitionId) {
    const model = request.models.find(item => item.entityId === entityId);
    if (!model)
        return [];
    const cited = new Map();
    for (const transition of model.transitions) {
        for (const rule of transition.ruleRefs)
            cited.set(rule, (cited.get(rule) || 0) + 1);
    }
    const transition = model.transitions.find(item => item.transitionId === transitionId);
    if (!transition)
        return [];
    return transition.ruleRefs.filter(rule => cited.get(rule) === 1);
}
function inPool(operation, usecaseIds) {
    if (usecaseIds.has(operation))
        return true;
    const head = operation.split('.')[0] || '';
    return head.length > 0 && usecaseIds.has(head);
}
function effectsPipeline(request, defPath, consumers) {
    const qualified = qualifyDefPath(request.project, defPath);
    const usecases = [...new Set(consumers)].filter(Boolean).sort();
    return {
        id: pipelineId(request.project, request.moduleName, 'integrationOutbound', 'outbound'),
        type: 'integrationOutbound',
        defPath: qualified,
        outputPath: futureOutputPath(qualified),
        outputAvailability: 'future',
        dependsFiles: usecases.map(id => qualifyDefPath(request.project, `l1/${request.moduleName}/layer_2_application/usecases/${id}.defs.ts`)),
        dependsOn: usecases.map(id => pipelineId(request.project, request.moduleName, 'usecase', id)),
        skills: skillPaths('integrationOutbound'),
    };
}
function capabilityOf(bound) {
    return {
        symbol: D1_MEASURED_PUBLISH.symbol,
        path: D1_MEASURED_PUBLISH.path,
        owner: D1_MEASURED_PUBLISH.owner,
        payload: D1_MEASURED_PUBLISH.payload,
        delivery: D1_MEASURED_PUBLISH.delivery,
        transaction: D1_MEASURED_PUBLISH.transaction,
        requestContextPublish: false,
        bound,
    };
}
function absentEffects() {
    return { phase: 'absent', executed: false, capability: capabilityOf(false) };
}
function laterOf(moduleName, seedPlan, effectPlan) {
    const later = [];
    if (seedPlan.phase !== 'plan') {
        later.push({
            artifactType: 'persistenceSeeds',
            defPath: SEEDS_PATH(moduleName),
            reason: 'No local table was planned. This step did not write a seed plan.',
        });
    }
    if (effectPlan.phase !== 'plan') {
        later.push({
            artifactType: 'integrationOutbound',
            defPath: OUTBOUND_PATH(moduleName),
            reason: 'No outbound event, process, inbound item or plugin was declared. This step did not write an integration def.',
        });
    }
    return later;
}
function registersOf(artifactType) {
    if (artifactType === 'repositoryRegistration')
        return 'adapter factories';
    if (artifactType === 'authorityMap')
        return 'authority entries';
    if (artifactType === 'persistenceSeeds')
        return 'seed plan';
    if (artifactType === 'integrationOutbound')
        return 'outbound events';
    return 'scope grants';
}
function publicationOf(emit) {
    return emit.map(part => {
        const pipeline = part.pipeline[0];
        const artifactType = part.definition.artifactType;
        return {
            artifactType,
            defPath: pipeline?.defPath || '',
            outputPath: pipeline?.outputPath || '',
            registers: registersOf(artifactType),
        };
    }).sort((left, right) => left.defPath.localeCompare(right.defPath));
}
function absentPlan() {
    return { phase: 'absent', materialized: false, rowCount: 0, datasets: [], dependencies: [] };
}
function finish(request, ok, enumerations, resolutions, helpers, removedHelpers, registry, problems, normalizations, emit, seedPlan, effectPlan) {
    const consumed = enumerations.filter(item => item.consumed);
    const unconsumed = enumerations.filter(item => !item.consumed);
    if (consumed.length && !normalizations.some(item => item.code === 'ENUMERATIONS_CONSUMED')) {
        normalizations.push({
            code: 'ENUMERATIONS_CONSUMED',
            path: ENUMERATION_SOURCE,
            detail: `${consumed.length} enum groups have a covered consumer. No rows were written.`,
        });
    }
    if ((unconsumed.length || enumerations.length === 0) && !normalizations.some(item => item.code === 'ENUMERATIONS_NOT_CONSUMED')) {
        normalizations.push({
            code: 'ENUMERATIONS_NOT_CONSUMED',
            path: ENUMERATION_SOURCE,
            detail: unconsumed.length
                ? `${unconsumed.length} enum values stay on the domain draft. support70 does not copy them.`
                : 'The domain draft has no enumerations. support70 did not invent any.',
        });
    }
    sortInPlace(enumerations, item => `${item.entityId}\u0000${item.path}`);
    sortInPlace(problems, item => `${item.path}\u0000${item.code}\u0000${item.message}`);
    sortInPlace(normalizations, item => `${item.path}\u0000${item.code}\u0000${item.detail}`);
    emit.sort((left, right) => (left.pipeline[0]?.defPath || '').localeCompare(right.pipeline[0]?.defPath || ''));
    return {
        schemaVersion: D1_SUPPORT_VERSION,
        project: request.project,
        moduleName: request.moduleName,
        llmCalls: 0,
        ok,
        enumerations,
        resolutions,
        helpers,
        removedHelpers,
        registry,
        publication: {
            stillToRegister: ok ? publicationOf(emit) : [],
            later: laterOf(request.moduleName, ok ? seedPlan : absentPlan(), ok ? effectPlan : absentEffects()),
        },
        seedPlan: ok ? seedPlan : absentPlan(),
        effectPlan: ok ? effectPlan : absentEffects(),
        problems,
        normalizations,
        emit: ok ? emit : [],
    };
}
function error(problems, code, path, message) {
    if (problems.some(problem => problem.severity === 'error' && problem.code === code && problem.path === path && problem.message === message))
        return;
    problems.push({ severity: 'error', code, path, message });
}
function review(problems, code, path, message) {
    if (problems.some(problem => problem.code === code && problem.path === path))
        return;
    problems.push({ severity: 'review', code, path, message });
}
function sortInPlace(items, key) {
    items.sort((left, right) => key(left).localeCompare(key(right)));
}
