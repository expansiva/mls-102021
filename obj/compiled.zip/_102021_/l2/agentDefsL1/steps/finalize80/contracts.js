/// <mls fileReference="_102021_/l2/agentDefsL1/steps/finalize80/contracts.ts" enhancement="_blank"/>
/**
 * v2: `consumed` means a covered consumer was proved for this entity and path.
 * It no longer means "every literal appeared in the seed set".
 * `origin` separates catalog owner, writer and restriction. `uses` names the consumer.
 */
export const D1_REPORT_VERSION = '2026-09-23-d1-report-v2';
/** Recognition by the inventory reader is not a runnable backend. */
export const INVENTORY_NOTE = 'Inventory recognition is not certification of an executable backend.';
/** Product types and the step that writes them. Matching is by artifact type, not by file name. */
export const PHASE_OF_TYPE = {
    domainEntity: 'domain30',
    valueObject: 'domain30',
    repositoryPort: 'persistence40',
    table: 'persistence40',
    repositoryAdapter: 'persistence40',
    usecase: 'usecases50',
    httpController: 'controllers60',
    accessScope: 'support70',
    authorityMap: 'support70',
    repositoryRegistration: 'support70',
    persistenceSeeds: 'support70',
    integrationOutbound: 'support70',
};
export const CHAIN_STEP_IDS = ['entry10', 'input20', 'domain30', 'persistence40', 'usecases50', 'controllers60', 'support70'];
export function parseFinalizeReport(text) {
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch {
        return null;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        return null;
    const report = parsed;
    if (report.schemaVersion !== D1_REPORT_VERSION)
        return null;
    if (report.llmCalls !== 0 || report.repairOpened !== false || report.executableBackend !== false)
        return null;
    if (report.inventoryNote !== INVENTORY_NOTE)
        return null;
    if (!Array.isArray(report.phases) || !Array.isArray(report.findings) || !Array.isArray(report.files))
        return null;
    if (!isEnumBlock(report.enumerations))
        return null;
    if (report.outcome !== 'complete' && report.outcome !== 'held')
        return null;
    if (report.defsStatus !== 'complete' && report.defsStatus !== 'incomplete' && report.defsStatus !== 'notRun')
        return null;
    return report;
}
const RESTRICTIONS = new Set(['inherited', 'subset', 'own', 'invalid', 'unresolved']);
function isEnumBlock(value) {
    if (!value || !Array.isArray(value.consumed) || !Array.isArray(value.notConsumed))
        return false;
    return [...value.consumed, ...value.notConsumed].every(item => isEnumRow(item));
}
function isEnumRow(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        return false;
    const row = value;
    return typeof row.entityId === 'string' && typeof row.path === 'string' && Array.isArray(row.values)
        && Array.isArray(row.uses) && typeof row.limits === 'string'
        && !!row.origin && RESTRICTIONS.has(row.origin.restriction);
}
