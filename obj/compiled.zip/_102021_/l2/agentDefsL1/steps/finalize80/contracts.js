/// <mls fileReference="_102021_/l2/agentDefsL1/steps/finalize80/contracts.ts" enhancement="_blank"/>
export const D1_REPORT_VERSION = '2026-09-22-d1-report-v1';
/** Recognition by the inventory reader is not a runnable backend. */
export const INVENTORY_NOTE = 'Inventory recognition is not certification of an executable backend.';
/** Product types and the step that writes them. Matching is by artifact type, not by file name. */
export const PHASE_OF_TYPE = {
    domainEntity: 'domain30',
    valueObject: 'domain30',
    repositoryPort: 'persistence40',
    table: 'persistence40',
    repositoryAdapter: 'persistence40',
    usecase: 'usecases50',
    httpController: 'controllers60',
    accessScope: 'support70',
    authorityMap: 'support70',
    repositoryRegistration: 'support70',
    persistenceSeeds: 'support70',
    integrationOutbound: 'support70',
};
export const CHAIN_STEP_IDS = ['entry10', 'input20', 'domain30', 'persistence40', 'usecases50', 'controllers60', 'support70'];
export function parseFinalizeReport(text) {
    let parsed;
    try {
        parsed = JSON.parse(text);
    }
    catch {
        return null;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        return null;
    const report = parsed;
    if (report.schemaVersion !== D1_REPORT_VERSION)
        return null;
    if (report.llmCalls !== 0 || report.repairOpened !== false || report.executableBackend !== false)
        return null;
    if (report.inventoryNote !== INVENTORY_NOTE)
        return null;
    if (!Array.isArray(report.phases) || !Array.isArray(report.findings) || !Array.isArray(report.files))
        return null;
    if (report.outcome !== 'complete' && report.outcome !== 'held')
        return null;
    if (report.defsStatus !== 'complete' && report.defsStatus !== 'incomplete' && report.defsStatus !== 'notRun')
        return null;
    return report;
}
