/// <mls fileReference="_102021_/l2/agentDefsL1/steps/finalize80/io.ts" enhancement="_blank"/>
import { isRecord } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { draftFile, pipelineFile, reportFile, } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { fingerprintProject, logicalDefPath } from '/_102021_/l2/agentDefsL1/helpers/d1Receipt.js';
import { futureOutputPath } from '/_102021_/l2/agentDefsL1/helpers/d1Refs.js';
import { parsePipelineDocument } from '/_102021_/l2/agentDefsL1/helpers/d1Schema.js';
import { readText, writeText } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { artifactFile, parseRendered } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { contractPath } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { fileInfoFromDisplay, readD1Input, sha256Text } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
/**
 * Reads the checkpoint, the snapshot, the drafts and the defs on disk.
 * It does not run an earlier phase and it does not call a model.
 */
export async function assembleD1Finalize(project, moduleName) {
    const snapshot = await readD1Input(project, moduleName);
    const drafts = {
        domain30: await readDraft(project, moduleName, 'domain30'),
        persistence40: await readDraft(project, moduleName, 'persistence40'),
        usecases50: await readDraft(project, moduleName, 'usecases50'),
        controllers60: await readDraft(project, moduleName, 'controllers60'),
        support70: await readDraft(project, moduleName, 'support70'),
    };
    const progress = await readProgress(project, moduleName);
    const observed = await readObserved(project, moduleName, snapshot?.files || [], progress);
    const sourceHashes = {};
    for (const source of snapshot?.sources || []) {
        sourceHashes[source.path] = await hashLogical(project, source.path);
    }
    const contracts = {};
    const pages = new Set((snapshot?.selection.routes || []).map(route => route.page).filter(Boolean));
    for (const pageId of pages) {
        const path = contractPath(moduleName, pageId);
        const text = await readLogical(project, path);
        contracts[pageId] = { path, text, hash: text == null ? '' : await sha256Text(text) };
    }
    const futurePresent = await futureOf(project, observed);
    const pipeline = await readPipeline(project, moduleName);
    if (!pipeline)
        return { refusal: 'Checkpoint is missing. finalize80 wrote nothing.' };
    return {
        request: {
            project,
            moduleName,
            pipeline,
            snapshot,
            sourceHashes,
            contracts,
            drafts,
            observed,
            futurePresent,
            children: [],
        },
    };
}
export async function writeD1Report(project, moduleName, report) {
    const file = reportFile(project, moduleName);
    const next = `${JSON.stringify(report, null, 2)}\n`;
    const current = await readText(file);
    if (current === next)
        return false;
    await writeText(file, next);
    return true;
}
async function readDraft(project, moduleName, step) {
    const text = await readText(draftFile(project, moduleName, step));
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
async function readPipeline(project, moduleName) {
    const raw = await readText(pipelineFile(project, moduleName));
    if (!raw)
        return null;
    const pipeline = parsePipelineDocument(raw);
    if (!pipeline || pipeline.project !== project || pipeline.moduleName !== moduleName)
        return null;
    return pipeline;
}
async function readProgress(project, moduleName) {
    const fingerprint = await fingerprintProject(project);
    const folder = `${moduleName}/pipeline/agentDefsL1/traces`;
    const found = [];
    for (const entry of fingerprint) {
        if (entry.level !== 1 || entry.folder !== folder || entry.extension !== '.json')
            continue;
        const text = await readText({ project, level: 1, folder, shortName: entry.shortName, extension: entry.extension });
        if (!text)
            continue;
        try {
            const parsed = JSON.parse(text);
            if (parsed && parsed.moduleName === moduleName && Array.isArray(parsed.files))
                found.push(parsed);
        }
        catch {
            continue;
        }
    }
    return found;
}
async function readObserved(project, moduleName, planned, progress) {
    const receipt = new Map();
    const done = new Set();
    for (const unit of progress) {
        for (const file of unit.files) {
            const logical = logicalDefPath(file.defPath);
            if (file.desiredHash)
                receipt.set(logical, file.desiredHash);
            if (file.status === 'done' && file.action === 'write')
                done.add(logical);
        }
    }
    for (const file of planned) {
        const logical = logicalDefPath(file.defPath);
        if (!receipt.has(logical) && file.action === 'preserve' && file.contentHash)
            receipt.set(logical, file.contentHash);
    }
    const fingerprint = await fingerprintProject(project);
    const byLogical = new Map();
    for (const entry of fingerprint) {
        if (!productDef(entry, moduleName))
            continue;
        const logical = `l1/${entry.folder}/${entry.shortName}${entry.extension}`;
        const text = await readText({ project, level: 1, folder: entry.folder, shortName: entry.shortName, extension: entry.extension });
        byLogical.set(logical, {
            defPath: logical,
            text,
            currentHash: text == null ? '' : await sha256Text(text),
            receiptHash: receipt.get(logical) || '',
            action: planned.find(item => logicalDefPath(item.defPath) === logical)?.action || '',
            ownerRefs: planned.find(item => logicalDefPath(item.defPath) === logical)?.ownerRefs || [],
            unitDone: done.has(logical),
        });
    }
    for (const logical of done) {
        if (byLogical.has(logical))
            continue;
        byLogical.set(logical, {
            defPath: logical,
            text: null,
            currentHash: '',
            receiptHash: receipt.get(logical) || '',
            action: 'write',
            ownerRefs: [],
            unitDone: true,
        });
    }
    return [...byLogical.values()];
}
async function futureOf(project, observed) {
    const present = {};
    for (const item of observed) {
        if (!item.text)
            continue;
        const rendered = parseRendered(item.text);
        if (!rendered || !Array.isArray(rendered.pipeline))
            continue;
        for (const pipelineItem of rendered.pipeline) {
            if (!isRecord(pipelineItem) || typeof pipelineItem.outputPath !== 'string')
                continue;
            const outputPath = pipelineItem.outputPath;
            const info = artifactFile(project, outputPath);
            present[outputPath] = info ? (await readText(info)) != null : false;
            const logicalFuture = futureOutputPath(logicalDefPath(typeof pipelineItem.defPath === 'string' ? pipelineItem.defPath : ''));
            if (logicalFuture && present[logicalFuture] === undefined)
                present[logicalFuture] = present[outputPath];
        }
    }
    return present;
}
function productDef(entry, moduleName) {
    if (entry.level !== 1 || entry.extension !== '.defs.ts')
        return false;
    const pipeline = `${moduleName}/pipeline`;
    if (entry.folder === pipeline || entry.folder.startsWith(`${pipeline}/`))
        return false;
    return entry.folder === moduleName || entry.folder.startsWith(`${moduleName}/`);
}
async function hashLogical(project, path) {
    const text = await readLogical(project, path);
    return text == null ? '' : sha256Text(text);
}
async function readLogical(project, path) {
    const info = fileInfoFromDisplay(project, path);
    if (!info)
        return null;
    return readText(info);
}
