/// <mls fileReference="_102021_/l2/agentDefsL1/steps/resolve25/contracts.ts" enhancement="_blank"/>
export const D1_RESOLVE_VERSION = '2026-10-04-d1-resolve-v1';
