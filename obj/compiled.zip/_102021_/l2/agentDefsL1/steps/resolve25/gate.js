/// <mls fileReference="_102021_/l2/agentDefsL1/steps/resolve25/gate.ts" enhancement="_blank"/>
import { D1_GAP_NONE } from '/_102021_/l2/agentDefsL1/steps/input20/contracts.js';
import { applyResolutions, deriveRequest } from '/_102021_/l2/agentDefsL1/steps/input20/deriveRequest.js';
import { readContractV2 } from '/_102021_/l2/agentDefsL1/steps/input20/gate.js';
import { D1_RESOLVE_VERSION, } from '/_102021_/l2/agentDefsL1/steps/resolve25/contracts.js';
/**
 * resolve25 (d1_62). The gaps are the ones the input20 derivation leaves (`deriveRequest`), from the same sources
 * input20 sealed. One unit per route with a gap. The model answers each gap with one of its candidates; the gate
 * accepts only a candidate, and the receipt keeps route, path, choice and call.
 */
/** Paths whose digest differs between the snapshot and what is read now. Empty means the same sources. */
export function sourcesDrift(sealed, now) {
    const before = new Map(sealed.map(item => [item.path, item.sha256]));
    const after = new Map(now.map(item => [item.path, item.sha256]));
    const drift = [];
    for (const path of new Set([...before.keys(), ...after.keys()])) {
        if (before.get(path) !== after.get(path))
            drift.push(path);
    }
    return drift.sort();
}
/** One unit per contract route the derivation leaves with a gap, in route order. */
export function resolveUnits(artifacts) {
    const routes = [];
    for (const [pageId, definition] of readContractV2(artifacts.contractTexts)) {
        for (const route of definition.routes) {
            const derived = deriveRequest(route, definition, artifacts.entities);
            if (!derived.unresolved.length)
                continue;
            routes.push({
                route: route.route,
                pageId,
                gaps: derived.unresolved.map((gap, index) => ({
                    gapId: `g${index}`,
                    path: gap.path,
                    kind: gap.kind,
                    reason: gap.reason,
                    candidates: [...gap.candidates],
                })),
            });
        }
    }
    routes.sort((left, right) => left.route.localeCompare(right.route));
    return routes.map((item, index) => ({ unitId: `r${index}`, ...item }));
}
/** The reply `{ answers: { g0: '...', ... } }`. Every gap needs one of its candidates; `none` is a candidate. */
export function checkResolveReply(unit, reply) {
    const answers = {};
    const problems = [];
    const given = isRecord(reply) && isRecord(reply.answers) ? reply.answers : null;
    if (!given)
        return { answers, problems: [`The reply has no answers object for route ${unit.route}.`] };
    for (const key of Object.keys(given)) {
        if (!unit.gaps.some(gap => gap.gapId === key))
            problems.push(`${key} is not a gap of route ${unit.route}.`);
    }
    for (const gap of unit.gaps) {
        const choice = given[gap.gapId];
        if (typeof choice !== 'string') {
            problems.push(`${gap.gapId} (${gap.path}) has no answer. Choose one of: ${gap.candidates.join(', ')}.`);
            continue;
        }
        if (!gap.candidates.includes(choice)) {
            problems.push(`${gap.gapId} (${gap.path}) answered '${choice}', which is not a candidate. Choose one of: ${gap.candidates.join(', ')}.`);
            continue;
        }
        answers[gap.gapId] = choice;
    }
    return { answers, problems };
}
/**
 * The receipt from the last attempt of each unit. An accepted choice keeps the plan id of its call. A gap with no
 * accepted choice after the repair, or of a unit that failed operationally, is `none` with an empty call.
 */
export function buildResolveReceipt(work, attempts) {
    let llmCalls = 0;
    const grouped = [];
    for (const unit of work.units) {
        llmCalls += attempts.find(item => item.unitId === unit.unitId)?.calls || 0;
        const row = grouped.find(item => item.route === unit.route);
        if (row)
            row.units.push(unit);
        else
            grouped.push({ route: unit.route, pageId: unit.pageId, units: [unit] });
    }
    const routes = grouped.map(row => {
        const answers = row.units.flatMap(unit => {
            const attempt = attempts.find(item => item.unitId === unit.unitId);
            return unit.gaps.map(gap => {
                const choice = attempt?.answers?.[gap.gapId];
                const accepted = typeof choice === 'string' && gap.candidates.includes(choice);
                return {
                    path: gap.path,
                    kind: gap.kind,
                    choice: accepted ? choice : D1_GAP_NONE,
                    call: accepted && attempt ? attempt.planId : '',
                    gapKey: resolveGapKey(unit.route, gap),
                };
            });
        });
        return { route: row.route, pageId: row.pageId, answers };
    });
    return {
        schemaVersion: D1_RESOLVE_VERSION,
        project: work.project,
        moduleName: work.moduleName,
        sourceKey: work.sourceKey,
        llmCalls,
        routes,
    };
}
/**
 * Routes whose every gap still has an answer on the receipt with the same route and the same `gapKey`.
 * The value is the previous choices by gap id. A route with any new or changed gap is left out.
 */
export function keptRoutes(receipt, units) {
    const kept = new Map();
    for (const unit of units) {
        const row = receipt.routes.find(item => item.route === unit.route);
        if (!row)
            continue;
        const answers = {};
        let all = true;
        for (const gap of unit.gaps) {
            const match = row.answers.find(answer => answer.gapKey === resolveGapKey(unit.route, gap));
            if (!match) {
                all = false;
                break;
            }
            answers[gap.gapId] = match.choice;
        }
        if (all)
            kept.set(unit.unitId, answers);
    }
    return kept;
}
/** Identity of one gap. Synchronous, not a hash. */
function resolveGapKey(route, gap) {
    return JSON.stringify([route, gap.path, gap.kind, gap.reason, [...gap.candidates].sort()]);
}
/**
 * Choices the gate already settled, one list per route, as `applyResolutions` takes them.
 * A gap with no accepted candidate is `none`.
 */
export function settledGapAnswers(work, attempts) {
    const byRoute = new Map();
    for (const unit of work.units) {
        const attempt = attempts.find(item => item.unitId === unit.unitId);
        const list = byRoute.get(unit.route) || [];
        for (const gap of unit.gaps) {
            const choice = attempt?.answers?.[gap.gapId];
            const accepted = typeof choice === 'string' && gap.candidates.includes(choice);
            list.push({ path: gap.path, choice: accepted ? choice : D1_GAP_NONE });
        }
        byRoute.set(unit.route, list);
    }
    return byRoute;
}
/**
 * Gaps `applyResolutions` opens on routes already asked, whose path was not asked yet.
 * A repeated path stays with the choice it has. The caller asks a new path at most once more (d1_91 s2b).
 */
export function unaskedGaps(artifacts, settled, askedPaths) {
    const out = [];
    for (const [pageId, definition] of readContractV2(artifacts.contractTexts)) {
        for (const route of definition.routes) {
            if (!askedPaths.has(route.route))
                continue;
            const derived = applyResolutions({ route, definition, entities: artifacts.entities }, settled.get(route.route) || []);
            const asked = askedPaths.get(route.route) || new Set();
            const gaps = derived.unresolved.filter(gap => !asked.has(gap.path)).map(gap => ({
                path: gap.path,
                kind: gap.kind,
                reason: gap.reason,
                candidates: [...gap.candidates],
            }));
            if (gaps.length)
                out.push({ route: route.route, pageId, gaps });
        }
    }
    return out;
}
/**
 * True when every gap `applyResolutions` still opens, with this receipt's choices, is already on the receipt.
 * A choice that closed its gap may stay on the receipt. A new path the choices opened is not covered.
 */
export function receiptAnswersDerived(receipt, artifacts) {
    const byRoute = new Map(receipt.routes.map(row => [row.route, row.answers]));
    for (const [, definition] of readContractV2(artifacts.contractTexts)) {
        for (const route of definition.routes) {
            const answers = byRoute.get(route.route) || [];
            const derived = applyResolutions({ route, definition, entities: artifacts.entities }, answers.map(item => ({ path: item.path, choice: item.choice })));
            const have = new Set(answers.map(item => item.path));
            if (derived.unresolved.some(gap => !have.has(gap.path)))
                return false;
        }
    }
    return true;
}
/** The answers of one route, as `applyResolutions` takes them. No receipt or no route gives none. */
export function resolveAnswers(receipt, route) {
    const row = receipt?.routes.find(item => item.route === route);
    return row ? row.answers.map(item => ({ path: item.path, choice: item.choice })) : [];
}
/** Every route's answers, as `buildD1InputSnapshot` takes them. No receipt gives no answer. */
export function answersByRoute(receipt) {
    return new Map((receipt?.routes || []).map(row => [row.route, resolveAnswers(receipt, row.route)]));
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
