/// <mls fileReference="_102021_/l2/agentDefsL1/steps/resolve25/io.ts" enhancement="_blank"/>
import { isRecord } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { resolveFile } from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { readText, writeJson } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { D1_RESOLVE_VERSION, } from '/_102021_/l2/agentDefsL1/steps/resolve25/contracts.js';
export function resolveWorkFile(project, moduleName) {
    return { project, level: 1, folder: `${moduleName}/pipeline/agentDefsL1/drafts`, shortName: 'resolve25-work', extension: '.json' };
}
export function resolveAttemptFile(project, moduleName, unitId) {
    return { project, level: 1, folder: `${moduleName}/pipeline/agentDefsL1/traces`, shortName: `resolve25-${unitId}`, extension: '.json' };
}
export async function writeResolveWork(work) {
    await writeJson(resolveWorkFile(work.project, work.moduleName), work);
}
export async function readResolveWork(project, moduleName) {
    const parsed = await readParsed(resolveWorkFile(project, moduleName));
    if (!isRecord(parsed) || parsed.schemaVersion !== D1_RESOLVE_VERSION)
        return null;
    if (parsed.project !== project || parsed.moduleName !== moduleName || !Array.isArray(parsed.units))
        return null;
    return parsed;
}
export async function writeResolveAttempt(project, moduleName, attempt) {
    await writeJson(resolveAttemptFile(project, moduleName, attempt.unitId), attempt);
}
export async function readResolveAttempt(project, moduleName, unitId) {
    const parsed = await readParsed(resolveAttemptFile(project, moduleName, unitId));
    if (!isRecord(parsed) || parsed.unitId !== unitId || typeof parsed.status !== 'string' || !isRecord(parsed.answers))
        return null;
    return parsed;
}
export async function writeResolveReceipt(receipt) {
    await writeJson(resolveFile(receipt.project, receipt.moduleName), receipt);
}
/** The receipt of this project and module, or null when absent or not this shape. */
export async function readResolveReceipt(project, moduleName) {
    const parsed = await readParsed(resolveFile(project, moduleName));
    if (!isRecord(parsed) || parsed.schemaVersion !== D1_RESOLVE_VERSION)
        return null;
    if (parsed.project !== project || parsed.moduleName !== moduleName)
        return null;
    if (typeof parsed.sourceKey !== 'string' || typeof parsed.llmCalls !== 'number' || !Array.isArray(parsed.routes))
        return null;
    return parsed;
}
async function readParsed(file) {
    const text = await readText(file);
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
