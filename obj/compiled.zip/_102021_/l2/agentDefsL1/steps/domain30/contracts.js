/// <mls fileReference="_102021_/l2/agentDefsL1/steps/domain30/contracts.ts" enhancement="_blank"/>
export const D1_DOMAIN_VERSION = '2026-09-21-d1-domain-v1';
export const D1_DOMAIN_ACTIONS = ['create', 'update', 'recompose', 'preserve', 'remove', 'conflict'];
