/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding.ts" enhancement="_blank"/>
import mdm from '/_102034_/l4/ontology/mdm.defs.js';
import { readText } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { isL1Operation } from '/_102021_/l2/helpers/l1Defs/operations.js';
import { D1_MDM_CALLS, } from '/_102021_/l2/agentDefsL1/steps/usecases50/contracts.js';
/** Classification file the agent reads with `readText`. No disk path. Never imported. */
const PLATFORM_KEYS_FILE = {
    project: 102034,
    level: 1,
    folder: 'mdm/defs',
    shortName: 'platformDetailKeys',
    extension: '.ts',
};
const PLATFORM_KEYS_FILE_NAME = `${PLATFORM_KEYS_FILE.shortName}${PLATFORM_KEYS_FILE.extension}`;
const NOT_LOADED = 'platform keys not loaded';
const ENGINE_KEYS = new Set([
    'mdmId', 'subtype', 'status', 'moduleTypes', 'tags', 'relationshipRefs',
    'mergedInto', 'createdAt', 'updatedAt', 'namespaces',
]);
/**
 * Every `details` branch `platformPatchKey` accepts: `identification` and `base` (every record
 * has them), plus one `<subtype>` branch per entry in the ontology's `subtypes` (`mdm.defs.ts`),
 * keyed by the subtype name with its first letter lowercased ("Person" -> "person", "Product" ->
 * "product"...), matching how the engine names the branch on the stored document (mdm.defs.ts
 * "record" comment). No subtype name is hardcoded here: a subtype added to the ontology is a
 * platform branch automatically.
 */
const PLATFORM_BRANCHES = new Set([
    'identification',
    'base',
    ...Object.keys(mdm.subtypes).map(name => name.charAt(0).toLowerCase() + name.slice(1)),
]);
const UNRECOGNIZED_PLATFORM_SET = `MDM_PLATFORM_DETAIL_KEYS set was not recognized in ${PLATFORM_KEYS_FILE_NAME}.`;
let platformKeys = null;
function loadedPlatformKeys() {
    if (!platformKeys)
        throw new Error(NOT_LOADED);
    return platformKeys;
}
/** Literals and `...Name` spreads. Anything else is an unrecognized form. */
function setElements(body) {
    const literals = [];
    const spreads = [];
    const token = /'([^'\\]*)'|"([^"\\]*)"|\.\.\.\s*([A-Za-z_][A-Za-z0-9_]*)|([,\s]+)/g;
    let end = 0;
    for (const match of body.matchAll(token)) {
        if (match.index !== end)
            return null;
        end = match.index + match[0].length;
        if (match[3])
            spreads.push(match[3]);
        else if (match[1] != null || match[2] != null)
            literals.push((match[1] ?? match[2]));
    }
    if (end !== body.length)
        return null;
    if (literals.length === 0 && spreads.length === 0)
        return null;
    return { literals, spreads };
}
/** `export const Name = [ '…', … ] as const` in the same classification file. */
function exportedConstArray(text, name) {
    const block = new RegExp(`export\\s+const\\s+${name}\\s*=\\s*\\[([\\s\\S]*?)\\]\\s*as\\s+const\\b`).exec(text);
    if (!block)
        return null;
    const elements = setElements(block[1]);
    if (!elements || elements.spreads.length > 0)
        return null;
    return elements.literals;
}
/**
 * Keys `entity.update` accepts as a caller patch: `MDM_PLATFORM_DETAIL_KEYS`
 * read from the classification file, minus `ENGINE_KEYS`.
 * The set may list string literals and spreads of `export const` arrays in the
 * same text. A missing export, an unrecognized form, or an empty read throws
 * with the file name. A spread whose name is not in the file throws with that name.
 * An empty set is never returned in place of a failed read.
 */
export function platformKeysFromFacadeText(text) {
    const block = /(?:export\s+)?const\s+MDM_PLATFORM_DETAIL_KEYS\b[\s\S]*?new\s+Set(?:<[^>]*>)?\s*\(\s*\[([\s\S]*?)\]\s*\)/.exec(text);
    if (!block)
        throw new Error(UNRECOGNIZED_PLATFORM_SET);
    const elements = setElements(block[1]);
    if (!elements)
        throw new Error(UNRECOGNIZED_PLATFORM_SET);
    const quoted = [...elements.literals];
    for (const name of elements.spreads) {
        const resolved = exportedConstArray(text, name);
        if (!resolved)
            throw new Error(`${name} is not an exported const array in ${PLATFORM_KEYS_FILE_NAME}.`);
        quoted.push(...resolved);
    }
    if (quoted.length === 0)
        throw new Error(UNRECOGNIZED_PLATFORM_SET);
    const keys = new Set();
    for (const key of quoted) {
        if (!ENGINE_KEYS.has(key))
            keys.add(key);
    }
    return keys;
}
/**
 * Reads `MDM_PLATFORM_DETAIL_KEYS` through the agent file API and caches the
 * platform patch keys. A missing file or an unrecognized set throws with the
 * file name. A loaded cache is returned as-is.
 */
export async function loadFacadePlatformKeys(read = readText) {
    if (platformKeys)
        return platformKeys;
    const text = await read(PLATFORM_KEYS_FILE);
    if (text == null)
        throw new Error(`MDM platform keys file was not read: ${PLATFORM_KEYS_FILE_NAME}`);
    const keys = platformKeysFromFacadeText(text);
    platformKeys = keys;
    return keys;
}
/** Test seam. `null` clears the cache so the binding fails closed. */
export function setFacadePlatformKeysForTest(text) {
    platformKeys = text == null ? null : platformKeysFromFacadeText(text);
}
/** Platform patch keys currently accepted by the facade source. */
export function facadePlatformKeys() {
    return loadedPlatformKeys();
}
const READ_CAPABILITIES = [
    'read.byId',
    'locate.byDocument',
    'locate.byName',
    'locate.byTag',
    'locate.byContact',
    'listLinks',
];
/** Same filter the worker catalog and the gate use before bindMdm. */
export function capabilityApplies(name, operation) {
    if (!isL1Operation(operation))
        return false;
    switch (operation) {
        case 'update': return name === 'edit.platformFields' || name.startsWith('edit.') || name === 'link.contact';
        case 'create': return name.startsWith('register.') || name === 'create' || name === 'link.contact';
        // Candidates are the read table below, not a `list` / `read.` / `locate.` prefix.
        case 'list':
        case 'get': return READ_CAPABILITIES.includes(name);
        case 'transition':
        case 'delete':
        case 'custom': return false;
        default: {
            const never = operation;
            return never;
        }
    }
}
/**
 * Capabilities this operation may name, then the calls bindMdm actually emits.
 * Context, worker schema and the gate all take this result. A locate the input
 * cannot feed is not offered.
 */
export function mdmForOperation(input) {
    loadedPlatformKeys();
    return bindMdm({
        ...input,
        selected: input.capabilities.filter(name => capabilityApplies(name, input.operation)),
    });
}
/** One schema pair per bound call. Alternative writes stay in the catalog. */
export function mdmStepPairs(mdm) {
    const pairs = [];
    const seen = new Set();
    for (const call of mdm.calls) {
        for (const capability of call.capabilities) {
            if (!call.method || !capability)
                continue;
            const key = `${call.method}\u0000${capability}`;
            if (seen.has(key))
                continue;
            seen.add(key);
            pairs.push({ call: call.method, capability });
        }
    }
    return pairs;
}
/**
 * Capabilities the ontology can name and the facade does not implement.
 * Inactivate and reactivate do not write status history. Audit is another module.
 */
export function mdmFacadeGaps() {
    return [
        {
            capability: 'statusHistory.read',
            code: 'MDM_UNBOUND',
            evidence: 'MdmFacade has no status-history read. findStatusHistoryByEntity is a separate usecase routed as mdm.statusHistory.findByEntity. entity.inactivate and entity.reactivate do not write that history.',
        },
        {
            capability: 'audit',
            code: 'MDM_UNBOUND',
            evidence: 'MdmFacade has no audit read. Audit is a separate module (audit.auditLog.load, audit.statusHistory.load), not an entity method.',
        },
    ];
}
export function isMdmFacadeCall(value) {
    return D1_MDM_CALLS.includes(value);
}
/** A patch key the caller module may not write. Platform keys and the caller namespace are allowed. */
export function isForeignMdmPatchKey(namespace, key) {
    if (loadedPlatformKeys().has(key))
        return false;
    return key !== namespace;
}
/**
 * Facade methods named by capabilities alone.
 * Callers that only need the catalog use this. It does not read a contract
 * and it does not invent arguments.
 */
export function mdmCapabilityCalls(selected) {
    const chosen = new Set(selected);
    const calls = [];
    const update = ['edit.platformFields', 'edit.moduleNamespace'].filter(name => chosen.has(name));
    if (update.length)
        calls.push({ method: 'update', capabilities: update });
    if (chosen.has('register.createOrAttach')) {
        const capability = ['register.createOrAttach'];
        calls.push({ method: 'findByDocument', capabilities: capability }, { method: 'create', capabilities: capability }, { method: 'attachRole', capabilities: capability });
    }
    const reads = [
        ['read.byId', 'get'],
        ['locate.byDocument', 'findByDocument'],
        ['locate.byContact', 'findByContact'],
        ['locate.byName', 'listByType'],
        ['locate.byTag', 'listByType'],
        ['listLinks', 'relatedOfMany'],
    ];
    for (const [capability, method] of reads) {
        if (chosen.has(capability))
            calls.push({ method, capabilities: [capability] });
    }
    if (chosen.has('inactivate')) {
        calls.push({ method: 'inactivate', capabilities: ['inactivate'] }, { method: 'reactivate', capabilities: ['inactivate'] });
    }
    if (chosen.has('invite.login'))
        calls.push({ method: 'invite', capabilities: ['invite.login'] });
    if (chosen.has('link.contact'))
        calls.push({ method: 'link', capabilities: ['link.contact'] });
    return calls;
}
export function bindMdm(input) {
    loadedPlatformKeys();
    const role = input.namespace && input.entityId ? `${input.namespace}.${input.entityId}` : '';
    const gaps = [];
    const calls = [];
    const selected = new Set(input.selected);
    const skipped = new Set();
    const fields = input.inputFields ?? null;
    const reason = fields ? '' : (input.contractUnread?.trim() || 'contract absent');
    const platformCapability = input.selected.includes('edit.platformFields')
        ? 'edit.platformFields'
        : input.selected.includes('register.createOrAttach')
            ? 'register.createOrAttach'
            : '';
    const platform = fields && platformCapability
        ? platformPatches(input, platformCapability, gaps)
        : [];
    if (selected.has('edit.platformFields') || selected.has('edit.moduleNamespace')) {
        if (!fields) {
            if (selected.has('edit.platformFields'))
                refuseUnread(gaps, 'edit.platformFields', reason);
            if (selected.has('edit.moduleNamespace'))
                refuseUnread(gaps, 'edit.moduleNamespace', reason);
        }
        else {
            const update = updateCall(input, platform, gaps);
            if (update)
                calls.push(update);
        }
    }
    if (selected.has('register.createOrAttach') || selected.has('create')) {
        if (selected.has('create') && !selected.has('register.createOrAttach')) {
            gaps.push(knownGap('create'));
        }
        else if (!fields) {
            refuseUnread(gaps, 'register.createOrAttach', reason);
        }
        else {
            calls.push(...createOrAttachCalls(input, role, platform, gaps));
        }
    }
    for (const name of READ_CAPABILITIES) {
        if (!selected.has(name))
            continue;
        if (!fields && name !== 'locate.byTag') {
            refuseUnread(gaps, name, reason);
            continue;
        }
        if (fields && !readFeedable(name, fields)) {
            skipped.add(name);
            continue;
        }
        const call = readCall(name, role, fields);
        if (call)
            calls.push(call);
    }
    if (selected.has('inactivate')) {
        if (!fields)
            refuseUnread(gaps, 'inactivate', reason);
        else {
            calls.push(statusCall(input, 'inactivate'));
            calls.push(statusCall(input, 'reactivate'));
        }
    }
    if (selected.has('invite.login')) {
        if (!fields)
            refuseUnread(gaps, 'invite.login', reason);
        else
            calls.push(inviteCall());
    }
    if (selected.has('link.contact')) {
        if (!fields)
            refuseUnread(gaps, 'link.contact', reason);
        else if (!linkFeedable(fields))
            skipped.add('link.contact');
        else
            calls.push(linkCall(fields));
    }
    const skippedReads = [];
    let planned = calls;
    if (input.outputFields == null) {
        skippedReads.push({
            capability: '',
            code: 'OUTPUT_UNREAD',
            evidence: 'Signature output was not read. Reads were not pruned.',
        });
    }
    else {
        const pruned = pruneUnusedReads(planned, input.outputFields, input.operation || '');
        planned = pruned.calls;
        skippedReads.push(...pruned.skipped);
        const still = new Set(planned.flatMap(call => call.capabilities));
        for (const entry of pruned.skipped) {
            if (entry.capability && !still.has(entry.capability))
                skipped.add(entry.capability);
        }
    }
    for (const name of input.selected) {
        if (skipped.has(name))
            continue;
        if (planned.some(call => call.capabilities.includes(name)))
            continue;
        if (gaps.some(gap => gap.capability === name))
            continue;
        gaps.push(knownGap(name));
    }
    gaps.push(...mdmFlowGaps(planned, input, gaps));
    const executable = planned.filter(call => !call.alternative);
    return {
        namespace: input.namespace,
        role,
        atomic: executable.length === 1 && gaps.length === 0,
        calls: planned,
        gaps,
        skipped: skippedReads,
    };
}
/**
 * Where a read result lands in the function output (M1 `pack` / `chosen` / `listReturn`).
 * A point read is packed as `{ id ← mdmId, version, details }`. On list, that pack is an `items` element.
 * `listByType` returns those rows only on list. `relatedOfMany` is not packed (`void links`, empty list return):
 * only a result field name is a place. A later `prior` argument or `prior` clause is the other consumer.
 * Removing one read can drop the earlier read that existed only to feed it, so this runs until stable.
 */
function pruneUnusedReads(calls, outputFields, operation) {
    let current = [...calls];
    const skipped = [];
    for (;;) {
        const drop = current.filter(call => isUnusedRead(call, current, outputFields, operation));
        if (!drop.length)
            break;
        const dropIds = new Set(drop.map(call => call.id));
        for (const call of drop) {
            skipped.push({
                capability: call.capabilities[0] || call.method,
                code: 'RESULT_UNUSED',
                evidence: `${call.id} result (${call.result.join(', ') || '(none)'}) has no output field and no later prior.`,
            });
        }
        current = current.filter(call => !dropIds.has(call.id));
    }
    return { calls: current, skipped };
}
const PACKED_POINT_METHODS = new Set(['get', 'findByDocument', 'findByContact']);
function isUnusedRead(call, calls, outputFields, operation) {
    if (!isPrunableRead(call))
        return false;
    if (citedByLater(call, calls))
        return false;
    return !outputConsumes(call, outputFields, operation);
}
function isPrunableRead(call) {
    if (PACKED_POINT_METHODS.has(call.method) || call.method === 'listByType' || call.method === 'relatedOfMany')
        return true;
    return call.capabilities.some(name => name.startsWith('read.') || name.startsWith('locate.') || name === 'listLinks' || name === 'listByType');
}
function citedByLater(call, calls) {
    const index = calls.findIndex(item => item.id === call.id);
    for (const later of calls.slice(index + 1)) {
        for (const arg of later.arguments) {
            if (arg.origin.kind !== 'prior')
                continue;
            if (!(arg.origin.calls || []).includes(call.id))
                continue;
            if (call.result.includes(arg.origin.path || ''))
                return true;
        }
        for (const clause of later.when) {
            if (clause.kind === 'prior' && clause.call === call.id && call.result.includes(clause.path))
                return true;
        }
    }
    return false;
}
function outputConsumes(call, outputFields, operation) {
    return outputFields.some(field => placedPaths(call, operation).some(place => field.path === place || field.path.startsWith(`${place}.`)));
}
function placedPaths(call, operation) {
    if (call.method === 'relatedOfMany')
        return [...call.result];
    if (call.method === 'listByType') {
        const places = new Set(call.result);
        if (operation === 'list') {
            places.add('items');
            places.add('id');
            places.add('version');
            places.add('details');
        }
        return [...places];
    }
    if (PACKED_POINT_METHODS.has(call.method)) {
        const places = new Set();
        if (call.result.includes('mdmId'))
            places.add('id');
        if (call.result.includes('version'))
            places.add('version');
        if (call.result.includes('details'))
            places.add('details');
        if (operation === 'list')
            places.add('items');
        return [...places];
    }
    return [...call.result];
}
/**
 * Proves the serialized plan. Prior links and the create-or-attach branch are checked
 * whether or not a contract was read. A contract argument with no field list is
 * `MDM_CONTRACT_UNREAD`, not a pass.
 */
export function mdmFlowGaps(calls, input, existing = []) {
    const gaps = [];
    const seen = new Set(existing.map(gap => `${gap.code}\u0000${gap.evidence}`));
    const reason = input.inputFields == null ? (input.contractUnread?.trim() || 'contract absent') : '';
    const push = (capability, evidence) => {
        const key = `MDM_ARGUMENT_UNBOUND\u0000${evidence}`;
        if (seen.has(key))
            return;
        seen.add(key);
        gaps.push({ capability, code: 'MDM_ARGUMENT_UNBOUND', evidence });
    };
    const pushUnread = (capability) => {
        const evidence = `${capability} needs a contract argument. ${reason}`;
        const key = `MDM_CONTRACT_UNREAD\u0000${evidence}`;
        if (seen.has(key))
            return;
        seen.add(key);
        gaps.push({ capability, code: 'MDM_CONTRACT_UNREAD', evidence });
    };
    const role = input.namespace && input.entityId ? `${input.namespace}.${input.entityId}` : '';
    calls.forEach((call, index) => {
        const capability = call.capabilities[0] || call.method;
        if (!call.id)
            push(capability, `${call.method} has no id.`);
        for (const clause of call.when) {
            if (clause.kind === 'prior' && !earlier(calls, index, clause.call || '')) {
                push(capability, `${call.id || call.method} waits on ${clause.call || '(none)'}, which is not an earlier result.`);
            }
            if (clause.kind === 'contract' && input.inputFields == null) {
                pushUnread(capability);
            }
            else if (clause.kind === 'contract' && input.inputFields && !input.inputFields.some(field => field.path === clause.path)) {
                push(capability, `${call.id || call.method} waits on ${clause.path}, which is not on the input.`);
            }
        }
        for (const arg of call.arguments) {
            if (input.inputFields == null && arg.origin.kind === 'contract') {
                pushUnread(capability);
                continue;
            }
            proveArgument(calls, index, call, arg, input, role, push);
        }
        if (call.method === 'update' || call.method === 'inactivate' || call.method === 'reactivate') {
            if (input.inputFields == null) {
                pushUnread(capability);
            }
            else {
                if (!call.arguments.some(arg => arg.name === 'mdmId')) {
                    push(capability, `${call.id || call.method} has no mdmId from the input id.`);
                }
                proveVersion(call, input, push);
            }
        }
        if (call.method === 'create' && call.arguments.some(arg => arg.name === 'expectedVersion')) {
            push(capability, 'entity.create does not take expectedVersion. Create excludes write preconditions.');
        }
        if (call.method === 'attachRole') {
            const id = call.arguments.find(arg => arg.name === 'mdmId');
            if (!id || id.origin.kind !== 'prior') {
                push(capability, 'attachRole mdmId is not an earlier result.');
            }
        }
    });
    const create = calls.find(call => call.method === 'create' && call.capabilities.includes('register.createOrAttach'));
    if (create) {
        for (const locate of calls) {
            if (locate.method !== 'findByDocument' && locate.method !== 'findByContact')
                continue;
            const waits = create.when.some(clause => (clause.kind === 'prior' && clause.call === locate.id && clause.path === 'mdmId' && clause.present === false));
            if (!waits) {
                push('register.createOrAttach', `create does not skip when ${locate.id || locate.method} already found the person.`);
            }
        }
    }
    if (input.inputFields && calls.some(call => call.method === 'findByContact')) {
        if (!contactPair(input.inputFields)) {
            push('locate.byContact', 'findByContact needs contactType and value on this input. The locate capability does not add them.');
        }
    }
    return gaps;
}
function refuseUnread(gaps, capability, reason) {
    const evidence = `${capability} needs a contract argument. ${reason}`;
    if (gaps.some(gap => gap.code === 'MDM_CONTRACT_UNREAD' && gap.capability === capability && gap.evidence === evidence))
        return;
    gaps.push({ capability, code: 'MDM_CONTRACT_UNREAD', evidence });
}
function knownGap(capability) {
    const standing = mdmFacadeGaps().find(gap => gap.capability === capability);
    if (standing)
        return standing;
    return {
        capability,
        code: 'MDM_UNBOUND',
        evidence: `Capability ${capability} has no method on the MDM facade.`,
    };
}
function platformPatches(input, capability, gaps) {
    const args = [];
    const seen = new Set();
    for (const path of input.platformFields) {
        const resolved = platformPatchKey(path);
        if ('gap' in resolved) {
            gaps.push({ capability, code: 'MDM_PATCH_UNBOUND', evidence: resolved.gap });
            continue;
        }
        if (!input.inputFields || !input.inputFields.some(field => field.path === path))
            continue;
        if (seen.has(resolved.key))
            continue;
        seen.add(resolved.key);
        args.push(contractArg(resolved.key, 'patch', resolved.argPath, capability));
    }
    return args;
}
function platformPatchKey(path) {
    const parts = path.split('.');
    if (parts.length < 3 || parts[0] !== 'details') {
        return { gap: `${path} is not a details field entity.update can patch.` };
    }
    const branch = parts[1];
    const leaf = parts[parts.length - 1];
    if (!PLATFORM_BRANCHES.has(branch)) {
        return { gap: `${path} is not a platform branch. Module data is the caller namespace key, not a platform patch.` };
    }
    // A facade object (privacyConsent, …) is one patch key. Subfields share that key and the object path.
    const keys = loadedPlatformKeys();
    if (parts.length > 3 && keys.has(parts[2])) {
        return { key: parts[2], argPath: parts.slice(0, 3).join('.') };
    }
    if (ENGINE_KEYS.has(leaf)) {
        return { gap: `${path} is not an edit.platformFields key. status is inactivate or reactivate; tags are attachRole.` };
    }
    if (!keys.has(leaf)) {
        return { gap: `${path} has no key on entity.update.` };
    }
    return { key: leaf, argPath: path };
}
/**
 * Platform fields and the caller namespace share one `entity.update`.
 * Two updates would each send the same expectedVersion; the second is stale.
 * The facade accepts both key kinds in one patch and bumps version once.
 * expectedVersion is the contract field marked writePrecondition. The plan does not read a newer version.
 */
function updateCall(input, platform, gaps) {
    const capabilities = [];
    const args = [];
    const id = identityArg(input);
    if (id)
        args.push(id);
    const version = versionArg(input);
    if (version)
        args.push(version);
    if (input.selected.includes('edit.platformFields')) {
        capabilities.push('edit.platformFields');
        if (!platform.length && !gaps.some(gap => gap.capability === 'edit.platformFields')) {
            gaps.push({
                capability: 'edit.platformFields',
                code: 'MDM_PATCH_UNBOUND',
                evidence: 'edit.platformFields has no platform field that entity.update can patch.',
            });
        }
        args.push(...platform);
    }
    if (input.selected.includes('edit.moduleNamespace')) {
        capabilities.push('edit.moduleNamespace');
        const namespacePath = `details.${input.namespace}`;
        if (!input.namespace) {
            gaps.push({
                capability: 'edit.moduleNamespace',
                code: 'MDM_UNBOUND',
                evidence: 'edit.moduleNamespace needs the caller module namespace. None is declared.',
            });
        }
        else if (!input.inputFields || !input.inputFields.some(field => field.path === namespacePath)) {
            gaps.push({
                capability: 'edit.moduleNamespace',
                code: 'MDM_ARGUMENT_UNBOUND',
                evidence: `${namespacePath} is not on this operation input.`,
            });
        }
        else {
            args.push(contractArg(input.namespace, 'patch', namespacePath, 'edit.moduleNamespace'));
        }
    }
    if (!capabilities.length)
        return null;
    return {
        id: 'update',
        method: 'update',
        target: 'entity',
        shape: 'write',
        capabilities,
        alternative: false,
        when: [],
        arguments: args,
        result: ['mdmId', 'version', 'details'],
    };
}
/**
 * New person: find (when its input is present), then create, then attachRole.
 * Existing person: a find hit skips create. attachRole reads the mdmId that hit produced.
 * locate.byContact on the role does not add findByContact unless this input declares the pair.
 * Nothing here wraps the sequence in one transaction.
 */
function createOrAttachCalls(input, role, platform, gaps) {
    const capability = 'register.createOrAttach';
    const calls = [];
    const docType = 'details.identification.docType';
    const docId = 'details.identification.docId';
    const fields = input.inputFields;
    if (!fields)
        return [];
    const documentOnInput = fields.some(field => field.path === docType) && fields.some(field => field.path === docId);
    if (documentOnInput) {
        calls.push(point('findByDocument', capability, [
            contractArg('docType', 'selector', docType),
            contractArg('docId', 'selector', docId),
        ], presentWhen(fields, [docType, docId]), 'findDocument'));
    }
    const contact = contactPair(fields);
    if (contact && input.capabilities.includes('locate.byContact')) {
        calls.push(point('findByContact', capability, [
            contractArg('contactType', 'selector', contact.type.path),
            contractArg('value', 'selector', contact.value.path),
        ], presentWhen(fields, [contact.type.path, contact.value.path]), 'findContact'));
    }
    if (!platform.length && !gaps.some(gap => gap.capability === capability)) {
        gaps.push({
            capability,
            code: 'MDM_PATCH_UNBOUND',
            evidence: 'register.createOrAttach has no platform field that entity.create can write.',
        });
    }
    const locateIds = calls.map(call => call.id);
    calls.push({
        id: 'createPerson',
        method: 'create',
        target: 'entity',
        shape: 'write',
        capabilities: [capability],
        alternative: false,
        when: locateIds.map(call => ({ kind: 'prior', call, path: 'mdmId', present: false })),
        arguments: [...platform],
        result: ['mdmId', 'version', 'alreadyExists'],
    });
    calls.push({
        id: 'attachRole',
        method: 'attachRole',
        target: 'entity',
        shape: 'write',
        capabilities: [capability],
        alternative: false,
        when: [],
        arguments: [
            priorArg('mdmId', 'selector', [...locateIds, 'createPerson'], 'mdmId'),
            literalArg('role', 'parameter', role, 'role'),
        ],
        result: ['mdmId', 'version'],
    });
    return calls;
}
function readCall(capability, role, fields) {
    if (capability === 'read.byId') {
        if (!fields)
            return null;
        return point('get', capability, [contractArg('mdmId', 'selector', 'id')], presentWhen(fields, ['id']), 'get');
    }
    if (capability === 'locate.byDocument') {
        if (!fields)
            return null;
        const paths = ['details.identification.docType', 'details.identification.docId'];
        return point('findByDocument', capability, [
            contractArg('docType', 'selector', paths[0]),
            contractArg('docId', 'selector', paths[1]),
        ], presentWhen(fields, paths), 'findByDocument');
    }
    if (capability === 'locate.byContact') {
        if (!fields)
            return null;
        const pair = contactPair(fields);
        if (!pair)
            return null;
        return point('findByContact', capability, [
            contractArg('contactType', 'selector', pair.type.path),
            contractArg('value', 'selector', pair.value.path),
        ], presentWhen(fields, [pair.type.path, pair.value.path]), 'findByContact');
    }
    if (capability === 'locate.byName') {
        if (!fields)
            return null;
        return {
            id: 'listByName',
            method: 'listByType',
            target: 'collection',
            shape: 'collection',
            capabilities: [capability],
            alternative: false,
            when: presentWhen(fields, ['details.identification.name']),
            arguments: [
                literalArg('type', 'parameter', role, 'role'),
                contractArg('name', 'selector', 'details.identification.name'),
            ],
            result: ['items', 'page', 'pageSize', 'total'],
        };
    }
    if (capability === 'locate.byTag') {
        return {
            id: 'listByTag',
            method: 'listByType',
            target: 'collection',
            shape: 'collection',
            capabilities: [capability],
            alternative: false,
            when: [],
            arguments: [literalArg('type', 'parameter', role, 'role')],
            result: ['items', 'page', 'pageSize', 'total'],
        };
    }
    if (capability === 'listLinks') {
        if (!fields)
            return null;
        return {
            id: 'listLinks',
            method: 'relatedOfMany',
            target: 'collection',
            shape: 'collection',
            capabilities: [capability],
            alternative: false,
            when: presentWhen(fields, ['id']),
            arguments: [contractArg('mdmIds', 'selector', 'id')],
            result: ['mdmId', 'relationshipId', 'type', 'direction'],
        };
    }
    return null;
}
function point(method, capability, args, when, id) {
    return {
        id,
        method,
        target: 'entity',
        shape: 'point',
        capabilities: [capability],
        alternative: false,
        when,
        arguments: args,
        result: ['mdmId', 'version', 'details'],
    };
}
/** The method writes the status. The caller passes the id and the expected version, not a status patch. */
function statusCall(input, method) {
    const args = [];
    const id = identityArg(input);
    if (id)
        args.push(id);
    const version = versionArg(input);
    if (version)
        args.push(version);
    return {
        id: method,
        method,
        target: 'entity',
        shape: 'write',
        capabilities: ['inactivate'],
        alternative: true,
        when: [],
        arguments: args,
        result: ['mdmId', 'version'],
    };
}
function inviteCall() {
    return {
        id: 'invite',
        method: 'invite',
        target: 'identity',
        shape: 'write',
        capabilities: ['invite.login'],
        alternative: false,
        when: [],
        arguments: [
            contractArg('mdmId', 'selector', 'id'),
            contractArg('email', 'parameter', 'email'),
            contextArg('moduleId'),
            contextArg('actorId'),
        ],
        result: ['token', 'expiresAt'],
    };
}
function linkCall(fields) {
    return {
        id: 'link',
        method: 'link',
        target: 'entity',
        shape: 'write',
        capabilities: ['link.contact'],
        alternative: false,
        when: presentWhen(fields, ['id', 'toId', 'type']),
        arguments: [
            contractArg('fromId', 'selector', 'id'),
            contractArg('toId', 'selector', 'toId'),
            contractArg('type', 'parameter', 'type'),
        ],
        result: ['id', 'fromId', 'toId', 'type'],
    };
}
function identityArg(input) {
    if (!input.inputFields || !input.inputFields.some(field => field.path === 'id') || mayBeAbsent(input.inputFields, 'id')) {
        return null;
    }
    return contractArg('mdmId', 'selector', 'id');
}
function versionArg(input) {
    if (!input.inputFields)
        return null;
    const marked = input.inputFields.filter(field => field.writePrecondition);
    if (marked.length !== 1 || mayBeAbsent(input.inputFields, marked[0].path))
        return null;
    const path = marked[0].path;
    return { name: 'expectedVersion', role: 'parameter', path, origin: { kind: 'contract', path, evidence: 'writePrecondition' } };
}
function contractArg(name, role, path, capability) {
    const arg = { name, role, path, origin: { kind: 'contract', path } };
    if (capability)
        arg.capability = capability;
    return arg;
}
function literalArg(name, role, value, evidence) {
    return { name, role, value, origin: { kind: 'literal', evidence } };
}
function contextArg(name) {
    return { name, role: 'parameter', value: 'ctx', origin: { kind: 'context', evidence: 'ctx' } };
}
function priorArg(name, role, calls, path) {
    return { name, role, origin: { kind: 'prior', path, calls } };
}
function presentWhen(fields, paths) {
    return paths
        .filter(path => mayBeAbsent(fields, path))
        .map(path => ({ kind: 'contract', path, present: true }));
}
function mayBeAbsent(fields, path) {
    const parts = path.split('.');
    let acc = '';
    for (const part of parts) {
        acc = acc ? `${acc}.${part}` : part;
        if (fields.find(field => field.path === acc)?.optional)
            return true;
    }
    return false;
}
function contactPair(fields) {
    for (const field of fields) {
        if (field.path !== 'contactType' && !field.path.endsWith('.contactType'))
            continue;
        const parent = field.path.slice(0, Math.max(0, field.path.length - 'contactType'.length));
        const value = fields.find(item => item.path === `${parent}value`);
        if (value)
            return { type: field, value };
    }
    return null;
}
function linkFeedable(fields) {
    return ['id', 'toId', 'type'].every(path => fields.some(field => field.path === path));
}
function readFeedable(name, fields) {
    if (name === 'read.byId' || name === 'listLinks')
        return fields.some(field => field.path === 'id');
    if (name === 'locate.byDocument') {
        return fields.some(field => field.path === 'details.identification.docType')
            && fields.some(field => field.path === 'details.identification.docId');
    }
    if (name === 'locate.byContact')
        return contactPair(fields) !== null;
    if (name === 'locate.byName')
        return fields.some(field => field.path === 'details.identification.name');
    if (name === 'locate.byTag')
        return true;
    return false;
}
function proveVersion(call, input, push) {
    const capability = call.capabilities[0] || call.method;
    const version = call.arguments.find(arg => arg.name === 'expectedVersion');
    if (input.inputFields == null)
        return;
    if (!version) {
        push(capability, `${call.id || call.method} has no expectedVersion from a writePrecondition field. The plan does not read the current version.`);
        return;
    }
    if (version.origin.kind !== 'contract') {
        push(capability, `${call.id || call.method} expectedVersion is not the contract precondition.`);
        return;
    }
    const field = input.inputFields.find(item => item.path === version.origin.path && item.writePrecondition);
    if (version.origin.evidence !== 'writePrecondition' || !field || mayBeAbsent(input.inputFields, field.path)) {
        push(capability, `${call.id || call.method} expectedVersion is not a required writePrecondition on this input.`);
    }
}
function proveArgument(calls, index, call, arg, input, role, push) {
    const capability = call.capabilities[0] || call.method;
    const origin = arg.origin;
    if (origin.kind === 'context') {
        if (arg.value !== 'ctx')
            push(capability, `${call.id} argument ${arg.name} is not ctx.`);
        return;
    }
    if (origin.kind === 'literal') {
        if (!arg.value)
            push(capability, `${call.id} argument ${arg.name} has no literal.`);
        if ((arg.name === 'role' || (arg.name === 'type' && origin.evidence === 'role')) && arg.value !== role) {
            push(capability, `${call.id} ${arg.name} ${arg.value || '(none)'} is not ${role}.`);
        }
        return;
    }
    if (origin.kind === 'contract') {
        if (!origin.path) {
            push(capability, `${call.id} argument ${arg.name} has no contract path.`);
            return;
        }
        if (arg.name === 'expectedVersion' || input.inputFields == null)
            return;
        // A facade object (privacyConsent) is one argument. The input may list only a subfield.
        const onInput = input.inputFields.some(field => field.path === origin.path || field.path.startsWith(`${origin.path}.`));
        if (!onInput) {
            push(capability, `${call.id} argument ${arg.name} reads ${origin.path}, which is not on this input.`);
            return;
        }
        if (arg.role !== 'patch' && mayBeAbsent(input.inputFields, origin.path)) {
            const guarded = call.when.some(clause => clause.kind === 'contract' && clause.path === origin.path && clause.present);
            if (!guarded)
                push(capability, `${call.id} argument ${arg.name} reads optional ${origin.path} with no presence condition.`);
        }
        return;
    }
    const ids = origin.calls || [];
    if (!origin.path || !ids.length) {
        push(capability, `${call.id} argument ${arg.name} does not name an earlier result.`);
        return;
    }
    for (const id of ids) {
        const producer = calls.slice(0, index).find(item => item.id === id);
        if (!producer) {
            push(capability, `${call.id} argument ${arg.name} cites ${id}, which is not an earlier call.`);
            continue;
        }
        if (!producer.result.includes(origin.path)) {
            push(capability, `${call.id} argument ${arg.name} cites ${id}.${origin.path}, which that call does not produce.`);
        }
    }
    if (call.method === 'attachRole' && arg.name === 'mdmId')
        proveAttach(calls, index, ids, push);
}
function proveAttach(calls, index, ids, push) {
    const before = calls.slice(0, index);
    const producers = ids.flatMap(id => {
        const call = before.find(item => item.id === id);
        return call ? [call] : [];
    });
    if (producers.some(call => call.when.length === 0 && call.result.includes('mdmId')))
        return;
    const create = producers.find(call => call.method === 'create');
    if (!create) {
        push('register.createOrAttach', 'attachRole has no create result to use when locate misses.');
        return;
    }
    for (const locate of before) {
        if (locate.method !== 'findByDocument' && locate.method !== 'findByContact')
            continue;
        if (!ids.includes(locate.id))
            push('register.createOrAttach', `attachRole does not read ${locate.id}.`);
    }
}
function earlier(calls, index, id) {
    return calls.slice(0, index).some(call => call.id === id);
}
