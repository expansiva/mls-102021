/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/callLog.ts" enhancement="_blank"/>
import { isRecord } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { fingerprintProject } from '/_102021_/l2/agentDefsL1/helpers/d1Receipt.js';
import { readText, writeJson } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
/**
 * Receipts of what usecases50 already observes. One file per observation so
 * parallel workers do not share a counter. A missing folder is not zero.
 */
export const D1_CALL_LOG_VERSION = '2026-09-24-d1-calls-v1';
export const CALL_ABSENT = 'usecases50 call log is absent';
export const CALL_HISTORY_ABSENT = 'generation call history is absent';
export const CALL_UNREADABLE = 'usecases50 call log has an unreadable event';
export const CALL_NO_INVOCATION = 'usecases50 call log has no invocation';
const EVENT_SLUG = {
    prompt_assembled: 'prompt',
    reply_delivered: 'reply',
    reply_absent: 'absent',
    not_dispatched: 'blocked',
    repair_scheduled: 'repair',
};
export function callsFolder(moduleName) {
    return `${moduleName}/pipeline/agentDefsL1/calls`;
}
export function accountCalls(log) {
    const local = { finalizeCalledModel: false, finalizeOpenedRepair: false };
    if (!log)
        return unknown(local, CALL_ABSENT);
    if (log.unreadable)
        return unknown(local, CALL_UNREADABLE);
    const latest = latestInvocation(log.invocations);
    if (!latest)
        return unknown(local, CALL_NO_INVOCATION);
    if (latest.kind === 'resume' && latest.historyAbsent && log.events.length === 0) {
        return {
            ...local,
            repliesDelivered: null,
            repliesUnknown: CALL_HISTORY_ABSENT,
            promptsAssembled: null,
            repairsScheduled: null,
            invocationReplies: 0,
            invocationUnknown: '',
        };
    }
    const replies = log.events.filter(event => event.kind === 'reply_delivered');
    return {
        ...local,
        repliesDelivered: replies.length,
        repliesUnknown: '',
        promptsAssembled: log.events.filter(event => event.kind === 'prompt_assembled').length,
        repairsScheduled: log.events.filter(event => event.kind === 'repair_scheduled').length,
        invocationReplies: replies.filter(event => event.invocation === latest.index).length,
        invocationUnknown: '',
    };
}
export async function readCallLog(project, moduleName) {
    const folder = callsFolder(moduleName);
    const fingerprint = await fingerprintProject(project);
    const names = fingerprint
        .filter(entry => entry.level === 1 && entry.folder === folder && entry.extension === '.json')
        .map(entry => entry.shortName)
        .sort();
    if (!names.length)
        return null;
    const invocations = [];
    const events = [];
    let unreadable = false;
    for (const shortName of names) {
        const parsed = await readJson(project, moduleName, shortName);
        const invocation = parseInvocation(parsed);
        if (invocation) {
            if (shortName !== `i${invocation.index}-${invocation.kind}`)
                unreadable = true;
            invocations.push(invocation);
            continue;
        }
        const event = parseEvent(parsed);
        if (!event) {
            unreadable = true;
            continue;
        }
        const slug = EVENT_SLUG[event.kind];
        if (shortName !== `i${event.invocation}-${slug}-${event.planId}`)
            unreadable = true;
        events.push(event);
    }
    if (new Set(invocations.map(item => item.index)).size !== invocations.length)
        unreadable = true;
    const known = new Set(invocations.map(item => item.index));
    if (events.some(event => !known.has(event.invocation)))
        unreadable = true;
    return { invocations, events: dedupeEvents(events), unreadable };
}
/** A new dispatch. Workers record against this index afterwards. */
export async function openCallDispatch(project, moduleName) {
    const log = await readCallLog(project, moduleName);
    const index = nextIndex(log);
    await writeJson(callFile(project, moduleName, `i${index}-dispatch`), invocationBody('dispatch', index, false));
    return index;
}
/**
 * This invocation added no call. Observations already on disk stay.
 * No observations means the generation total stays unknown.
 */
export async function openCallResume(project, moduleName) {
    const log = await readCallLog(project, moduleName);
    if (log?.unreadable)
        return;
    const index = nextIndex(log);
    const historyAbsent = !log || log.events.length === 0;
    await writeJson(callFile(project, moduleName, `i${index}-resume`), invocationBody('resume', index, historyAbsent));
}
/** First file for this plan and kind wins. A second delivery does not add a row. */
export async function recordCallEvent(project, moduleName, event) {
    const log = await readCallLog(project, moduleName);
    if (!log || log.unreadable)
        return;
    const latest = latestInvocation(log.invocations);
    if (!latest || latest.kind !== 'dispatch')
        return;
    if (!event.planId || !event.usecaseId)
        return;
    const shortName = `i${latest.index}-${EVENT_SLUG[event.kind]}-${event.planId}`;
    const info = callFile(project, moduleName, shortName);
    if (await readText(info))
        return;
    const body = {
        schemaVersion: D1_CALL_LOG_VERSION,
        kind: event.kind,
        usecaseId: event.usecaseId,
        planId: event.planId,
        unitAttempts: event.unitAttempts,
        invocation: latest.index,
    };
    await writeJson(info, body);
}
function unknown(local, reason) {
    return {
        ...local,
        repliesDelivered: null,
        repliesUnknown: reason,
        promptsAssembled: null,
        repairsScheduled: null,
        invocationReplies: null,
        invocationUnknown: reason,
    };
}
function latestInvocation(invocations) {
    return [...invocations].sort((left, right) => left.index - right.index).at(-1) || null;
}
function nextIndex(log) {
    const latest = log ? latestInvocation(log.invocations) : null;
    return latest ? latest.index + 1 : 1;
}
function invocationBody(kind, index, historyAbsent) {
    return { schemaVersion: D1_CALL_LOG_VERSION, kind, index, historyAbsent };
}
function dedupeEvents(events) {
    const seen = new Set();
    const out = [];
    for (const event of events) {
        const id = `${event.invocation}\u0000${event.kind}\u0000${event.planId}`;
        if (seen.has(id))
            continue;
        seen.add(id);
        out.push(event);
    }
    return out;
}
function callFile(project, moduleName, shortName) {
    return { project, level: 1, folder: callsFolder(moduleName), shortName, extension: '.json' };
}
async function readJson(project, moduleName, shortName) {
    const text = await readText(callFile(project, moduleName, shortName));
    if (!text)
        return null;
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
function parseInvocation(value) {
    if (!isRecord(value) || value.schemaVersion !== D1_CALL_LOG_VERSION)
        return null;
    if (value.kind !== 'dispatch' && value.kind !== 'resume')
        return null;
    if (!positive(value.index) || typeof value.historyAbsent !== 'boolean')
        return null;
    return {
        schemaVersion: D1_CALL_LOG_VERSION,
        kind: value.kind,
        index: value.index,
        historyAbsent: value.historyAbsent,
    };
}
function parseEvent(value) {
    if (!isRecord(value) || value.schemaVersion !== D1_CALL_LOG_VERSION)
        return null;
    if (!isEventKind(value.kind))
        return null;
    if (typeof value.usecaseId !== 'string' || !value.usecaseId)
        return null;
    if (typeof value.planId !== 'string' || !value.planId)
        return null;
    if (!nonNegative(value.unitAttempts) || !positive(value.invocation))
        return null;
    return {
        schemaVersion: D1_CALL_LOG_VERSION,
        kind: value.kind,
        usecaseId: value.usecaseId,
        planId: value.planId,
        unitAttempts: value.unitAttempts,
        invocation: value.invocation,
    };
}
function isEventKind(value) {
    return value === 'prompt_assembled'
        || value === 'reply_delivered'
        || value === 'reply_absent'
        || value === 'not_dispatched'
        || value === 'repair_scheduled';
}
function positive(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0;
}
function nonNegative(value) {
    return typeof value === 'number' && Number.isInteger(value) && value >= 0;
}
