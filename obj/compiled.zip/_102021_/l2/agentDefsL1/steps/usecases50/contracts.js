/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/contracts.ts" enhancement="_blank"/>
export const D1_USECASE_VERSION = '2026-09-21-d1-usecases-v1';
/** Same trail as persistence40. This step does not copy the values either. */
export const ENUMERATION_SOURCE = 'domain30.enumerations';
export const ENUMERATION_REASON = 'Usecase projection has no values slot. Enum values stay on the domain draft.';
export const D1_WORKER_KINDS = ['port', 'rule', 'mdm', 'transition', 'effect', 'transaction', 'context'];
export const D1_MDM_CALLS = ['read', 'attach', 'create'];
export const D1_WRITE_CALLS = ['create', 'update', 'transition', 'delete'];
