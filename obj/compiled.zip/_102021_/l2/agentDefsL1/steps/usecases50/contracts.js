/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/contracts.ts" enhancement="_blank"/>
export const D1_USECASE_VERSION = '2026-09-21-d1-usecases-v1';
/** Same trail as persistence40. This step does not copy the values either. */
export const ENUMERATION_SOURCE = 'domain30.enumerations';
export const ENUMERATION_REASON = 'Usecase projection has no values slot. Enum values stay on the domain draft.';
export const D1_WORKER_KINDS = ['port', 'rule', 'mdm', 'transition', 'effect', 'transaction', 'context'];
/**
 * Facade methods a plan may name. `read` and `attach` are not methods:
 * a point read, a collection read and a platform-field update are different calls.
 * The tool offers only the methods the operation's binding names. This list stays
 * the facade, so a manipulated reply can still be recognized and refused.
 */
export const D1_MDM_CALLS = [
    'get',
    'findByDocument',
    'findByContact',
    'listByType',
    'relatedOfMany',
    'create',
    'attachRole',
    'update',
    'inactivate',
    'reactivate',
    'link',
    'invite',
];
export const D1_WRITE_CALLS = ['create', 'update', 'transition', 'delete'];
