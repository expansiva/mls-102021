/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/rulePlan.ts" enhancement="_blank"/>
import { isRecord, isStorageConstraintRow } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { parseD1Source } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
import { capabilityApplies, mdmForOperation, mdmStepPairs } from '/_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding.js';
export { capabilityApplies };
/**
 * Applicability is citation, not a rule name and not a sentence.
 * A transition citation is mandatory on that transition and is not exclusive.
 * A write records uniqueKeys as its own storage row, with no rule id.
 * A module rule no transition cites stays pending on that write.
 * A read does not infer an actor or a route: each rules[] id a transition
 * also cites is one pending row on the operation.
 * A platform catalog entry has no structured method field, so it stays pending.
 */
const WRITE_OPERATIONS = new Set(['create', 'update', 'patch']);
const READ_OPERATIONS = new Set(['list', 'get', 'read']);
/** Rule ids the operation enforces. Pending rows are not in this list. */
export function enforcedRuleIds(rows) {
    const out = [];
    for (const row of rows) {
        if (row.enforcement === 'pending' || !row.ruleId || out.includes(row.ruleId))
            continue;
        out.push(row.ruleId);
    }
    return out;
}
export function originFile(origin) {
    const hash = origin.indexOf('#');
    return hash < 0 ? origin : origin.slice(0, hash);
}
export function planRuleApplicability(input) {
    const rows = [];
    const transitions = input.transitions;
    const moduleRules = input.rules.filter(rule => rule.owner === 'module');
    const citedBy = new Map();
    for (const transition of transitions) {
        for (const ruleId of transition.ruleRefs) {
            const list = citedBy.get(ruleId) || [];
            list.push(transition);
            citedBy.set(ruleId, list);
        }
    }
    const transition = input.operation === 'transition'
        ? transitions.find(item => item.transitionId === input.usecaseId) || null
        : null;
    if (transition) {
        const origin = `l4/${input.moduleName}/ontology/${input.entityId}.defs.ts#transitions.${transition.transitionId}.ruleRefs`;
        for (const ruleId of transition.ruleRefs) {
            push(rows, {
                ruleId,
                origin,
                consumer: `usecase:${input.usecaseId}`,
                enforcement: 'local',
                gap: '',
            });
        }
    }
    const constraint = constraintOrigin(input);
    if (constraint && writesConstraint(input.operation, transition, input.uniqueKeys)) {
        push(rows, {
            ruleId: '',
            origin: constraint,
            consumer: `operation:${input.operation}`,
            enforcement: 'local',
            gap: '',
        });
    }
    if (WRITE_OPERATIONS.has(input.operation)) {
        for (const rule of moduleRules) {
            if (citedBy.get(rule.ruleId)?.length)
                continue;
            push(rows, {
                ruleId: rule.ruleId,
                origin: `${rule.source}#${rule.ruleId}`,
                consumer: `operation:${input.operation}`,
                enforcement: 'pending',
                gap: 'RULE_UNBOUND',
            });
        }
    }
    if (READ_OPERATIONS.has(input.operation)) {
        const origin = `l4/${input.moduleName}/ontology/${input.entityId}.defs.ts#rules`;
        for (const rule of input.rules) {
            if (!citedBy.get(rule.ruleId)?.length)
                continue;
            push(rows, {
                ruleId: rule.ruleId,
                origin,
                consumer: `operation:${input.operation}`,
                enforcement: 'pending',
                gap: 'APPLICABILITY_UNDECLARED',
            });
        }
    }
    for (const rule of input.rules) {
        if (rule.owner !== 'platform')
            continue;
        if (rows.some(row => row.ruleId === rule.ruleId))
            continue;
        push(rows, {
            ruleId: rule.ruleId,
            origin: `${rule.source}#${rule.ruleId}`,
            consumer: `operation:${input.operation}`,
            enforcement: 'pending',
            gap: 'DELEGATION_UNPROVEN',
        });
    }
    rows.sort((left, right) => rowKey(left).localeCompare(rowKey(right)));
    return rows;
}
/**
 * Same plan the gate writes and the fidelity reader recomputes.
 * An ontology file wins over the entity draft. Routes stay on the input.
 * A grant does not place a rule.
 */
export function rulePlanForUsecase(input) {
    const files = input.files || [];
    const ontologyPath = `l4/${input.moduleName}/ontology/${input.entityId}.defs.ts`;
    const ontologyText = fileText(files, ontologyPath);
    const ontology = ontologyText == null ? null : parseD1Source(ontologyText, 'defs');
    const fromFile = ontology != null;
    const transitions = fromFile ? transitionsOf(ontology) : input.entity.transitions.map(cloneTransition);
    const uniqueKeys = fromFile ? uniqueKeysOf(ontology) : input.entity.uniqueKeys?.map(key => [...key]) || [];
    const capabilities = fromFile ? capabilityNamesOf(ontology) : [...(input.entity.capabilities || [])];
    const rules = fromFile
        ? rulesFromFiles(input.moduleName, ontology, transitions, files)
        : input.entity.rules.map(rule => ({
            ruleId: rule.ruleId,
            owner: rule.owner,
            source: rule.source || `l4/${input.moduleName}/rules.defs.ts`,
            text: '',
        }));
    const routes = routesForPlan(input.moduleName, input.entityId, input.routes, files);
    const storage = fromFile ? storageOf(ontology) : input.entity.storageTarget;
    const mdmMethods = storage === 'mdm'
        ? mdmStepPairs(mdmForOperation({
            entityId: input.entityId,
            namespace: '',
            capabilities,
            selected: [],
            platformFields: [],
            operation: input.operation,
            inputFields: null,
        })).map(pair => pair.call)
        : [];
    return planRuleApplicability({
        moduleName: input.moduleName,
        entityId: input.entityId,
        usecaseId: input.usecaseId,
        operation: input.operation,
        rules,
        transitions,
        uniqueKeys,
        capabilities,
        routes,
        mdmMethods,
    });
}
function writesConstraint(operation, transition, uniqueKeys) {
    if (WRITE_OPERATIONS.has(operation))
        return true;
    if (operation !== 'transition' || !transition)
        return false;
    const columns = new Set(uniqueKeys.flat());
    return transition.payload.some(path => columns.has(path));
}
function constraintOrigin(input) {
    const base = `l4/${input.moduleName}/ontology/${input.entityId}.defs.ts`;
    if (input.uniqueKeys.some(key => key.length > 0))
        return `${base}#uniqueKeys`;
    if (input.capabilities.includes('uniqueKey'))
        return `${base}#capabilities.uniqueKey`;
    return null;
}
function push(rows, row) {
    if (!row.ruleId && !isStorageConstraintRow(row))
        return;
    if (rows.some(item => item.ruleId === row.ruleId && item.consumer === row.consumer && item.origin === row.origin && item.gap === row.gap))
        return;
    rows.push(row);
}
function rowKey(row) {
    return `${row.consumer}\u0000${row.ruleId}\u0000${row.origin}\u0000${row.enforcement}`;
}
function routesForPlan(moduleName, entityId, routes, files) {
    const accessText = fileText(files, `l4/${moduleName}/access.defs.ts`);
    const needsText = fileText(files, `l4/${moduleName}/pool/l1/web/needs.json`);
    const access = accessText == null ? null : parseD1Source(accessText, 'defs');
    const needs = needsText == null ? null : parseJson(needsText);
    if (!access || !needs) {
        return routes.map(route => ({
            route: route.route,
            contractPath: route.contractPath,
            grants: route.grants.map(grant => ({ ...grant })),
        }));
    }
    return routes.map(route => {
        const page = pageIdFromContract(moduleName, route.contractPath);
        return {
            route: route.route,
            contractPath: route.contractPath,
            grants: grantsFor(access, pageActors(needs, page), entityId),
        };
    });
}
function rulesFromFiles(moduleName, ontology, transitions, files) {
    const modulePath = `l4/${moduleName}/rules.defs.ts`;
    const moduleBody = parseD1Source(fileText(files, modulePath) || '', 'defs');
    const moduleText = ruleMap(moduleBody);
    const catalogs = catalogMaps(ontology, files);
    const cited = stringList(isRecord(ontology) ? ontology.rules : undefined);
    for (const transition of transitions) {
        for (const ruleId of transition.ruleRefs) {
            if (!cited.includes(ruleId))
                cited.push(ruleId);
        }
    }
    const rules = [];
    for (const ruleId of cited) {
        const catalog = catalogs.find(item => Object.prototype.hasOwnProperty.call(item.rules, ruleId));
        if (catalog) {
            rules.push({ ruleId, owner: 'platform', source: catalog.path, text: catalog.rules[ruleId] });
            continue;
        }
        if (Object.prototype.hasOwnProperty.call(moduleText, ruleId)) {
            rules.push({ ruleId, owner: 'module', source: modulePath, text: moduleText[ruleId] });
            continue;
        }
        rules.push({ ruleId, owner: 'module', source: modulePath, text: '' });
    }
    return rules;
}
function catalogMaps(ontology, files) {
    if (!isRecord(ontology) || typeof ontology.source !== 'string' || !ontology.source.trim())
        return [];
    const path = ontology.source.trim().replace(/^\//, '');
    const text = fileText(files, path) || fileText(files, `/${path}`) || fileText(files, ontology.source.trim());
    const body = text == null ? null : parseD1Source(text, 'defs');
    const rules = ruleMap(body);
    if (!Object.keys(rules).length)
        return [];
    return [{ path: ontology.source.trim(), rules }];
}
function transitionsOf(body) {
    if (!isRecord(body) || !Array.isArray(body.transitions))
        return [];
    const out = [];
    for (const item of body.transitions) {
        if (!isRecord(item) || typeof item.transitionId !== 'string')
            continue;
        out.push({
            transitionId: item.transitionId,
            by: stringList(item.by),
            ruleRefs: stringList(item.ruleRefs),
            payload: stringList(item.payload),
        });
    }
    return out;
}
function cloneTransition(transition) {
    return {
        transitionId: transition.transitionId,
        by: [...transition.by],
        ruleRefs: [...transition.ruleRefs],
        payload: [...transition.payload],
    };
}
function uniqueKeysOf(body) {
    if (!isRecord(body) || !Array.isArray(body.uniqueKeys))
        return [];
    const out = [];
    for (const row of body.uniqueKeys) {
        if (!Array.isArray(row))
            continue;
        const fields = row.filter((item) => typeof item === 'string' && item.length > 0);
        if (fields.length)
            out.push(fields);
    }
    return out;
}
function capabilityNamesOf(body) {
    if (!isRecord(body) || !isRecord(body.capabilities))
        return [];
    const caps = body.capabilities;
    return Object.keys(caps).filter(name => typeof caps[name] === 'string').sort();
}
function storageOf(body) {
    if (!isRecord(body))
        return '';
    if (body.kind === 'role')
        return 'mdm';
    if (isRecord(body.storage) && typeof body.storage.target === 'string')
        return body.storage.target;
    return '';
}
function grantsFor(access, actors, entityId) {
    if (!isRecord(access) || !Array.isArray(access.grants))
        return [];
    const out = [];
    for (const grant of access.grants) {
        if (!isRecord(grant) || typeof grant.grantId !== 'string')
            continue;
        const actorRef = typeof grant.actorRef === 'string' ? grant.actorRef : '';
        if (!actors.includes(actorRef) || !stringList(grant.entityRefs).includes(entityId))
            continue;
        const scope = isRecord(grant.dataScope) && typeof grant.dataScope.mode === 'string' ? grant.dataScope.mode : '';
        out.push({ grantId: grant.grantId, actorRef, scope });
    }
    return out;
}
function pageActors(needs, pageId) {
    if (!pageId || !isRecord(needs) || !Array.isArray(needs.pages))
        return [];
    const page = needs.pages.find(item => isRecord(item) && item.pageId === pageId);
    if (!isRecord(page))
        return [];
    return stringList(page.actors);
}
function pageIdFromContract(moduleName, contractPath) {
    const prefix = `l2/${moduleName}/web/contracts/`;
    const suffix = '.defs.ts';
    if (!contractPath.startsWith(prefix) || !contractPath.endsWith(suffix))
        return '';
    const page = contractPath.slice(prefix.length, -suffix.length);
    if (!page || page.includes('/'))
        return '';
    return page;
}
function ruleMap(body) {
    if (!isRecord(body) || !isRecord(body.rules))
        return {};
    const out = {};
    for (const [ruleId, text] of Object.entries(body.rules)) {
        if (typeof text === 'string')
            out[ruleId] = text;
    }
    return out;
}
function fileText(files, path) {
    const found = files.find(file => file.path === path);
    return found ? found.text : null;
}
function parseJson(text) {
    try {
        return JSON.parse(text);
    }
    catch {
        return null;
    }
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string' && item.length > 0);
}
