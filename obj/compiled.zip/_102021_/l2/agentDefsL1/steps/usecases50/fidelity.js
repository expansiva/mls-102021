/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/fidelity.ts" enhancement="_blank"/>
import { integrationMechanismIssues, isRecord, isStorageConstraintRow } from '/_102021_/l2/agentDefsL1/helpers/d1Artifact.js';
import { declaredDependencyPaths, readDefinitionExport } from '/_102021_/l2/agentDefsL1/helpers/d1Write.js';
import { parseD1Source } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';
import { readContractAst } from '/_102021_/l2/agentDefsL1/steps/usecases50/contractsAst.js';
import { capabilityApplies, capabilityNames, mdmInputFields, namespaceOf, ontologyTransitions, platformFieldPaths, preconditionsFor, } from '/_102021_/l2/agentDefsL1/steps/usecases50/context.js';
import { bindMdm } from '/_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding.js';
import { enforcedRuleIds, originFile, rulePlanForUsecase } from '/_102021_/l2/agentDefsL1/steps/usecases50/rulePlan.js';
const READ_OPERATIONS = new Set(['list', 'get', 'read']);
const UPDATE_OPERATIONS = new Set(['update', 'patch']);
/**
 * Classifies a derived field the same way the gate does.
 * A payload is a write. Identity on a read is a filter; on an update or
 * transition it is a selector. A nested derived field on a read is a filter.
 * `version` on an update or transition is concurrency.
 */
export function fieldUses(input) {
    const uses = [];
    const seen = new Set();
    const add = (path, role, source) => {
        const key = `${source}\u0000${path}\u0000${role}`;
        if (seen.has(key))
            return;
        seen.add(key);
        uses.push({ path, role, source });
    };
    for (const path of input.inputPaths) {
        const field = input.fields.find(item => item.name === path);
        if (!field?.derived)
            continue;
        const role = derivedRole(input.operation, field.name, 'input');
        if (role === 'write' || role === 'ambiguous')
            continue;
        add(path, role, 'input');
    }
    for (const path of input.payloadPaths) {
        const field = input.fields.find(item => item.name === path);
        if (field?.derived)
            continue;
        add(path, 'write', 'payload');
    }
    uses.sort((left, right) => useKey(left).localeCompare(useKey(right)));
    return uses;
}
/**
 * Reads one serialized usecase def and the dependency texts it names.
 * It does not take the draft. A rule id, a file count or a signature is not enough.
 */
export function readUsecaseFidelity(source, files) {
    const problems = [];
    const read = readDefinitionExport(source);
    const definition = read && isRecord(read.definition) ? read.definition : null;
    const data = definition && isRecord(definition.data) ? definition.data : null;
    const dependsFiles = declaredDependencyPaths(source);
    if (!data) {
        return { behavior: null, problems: [{ code: 'DEFINITION', path: '', message: 'Serialized usecase did not parse.' }] };
    }
    const usecaseId = typeof data.usecaseId === 'string' ? data.usecaseId : '';
    const operation = typeof data.operation === 'string' ? data.operation : '';
    const entityId = typeof data.entityId === 'string' ? data.entityId : '';
    const moduleName = definition && typeof definition.moduleName === 'string' ? definition.moduleName : '';
    const ontologyPath = `l4/${moduleName}/ontology/${entityId}.defs.ts`;
    const ontologyText = fileText(files, ontologyPath);
    if (ontologyText == null) {
        fail(problems, 'SOURCE_ABSENT', usecaseId, `Ontology ${ontologyPath} is not a dependency of ${usecaseId}.`);
    }
    const ontology = ontologyText == null ? null : parseD1Source(ontologyText, 'defs');
    if (ontologyText != null && !ontology) {
        fail(problems, 'SOURCE_CHANGED', usecaseId, `Ontology ${ontologyPath} did not parse.`);
    }
    if (!hasDep(dependsFiles, ontologyPath)) {
        fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Ontology ${ontologyPath} is not in dependencies.`);
    }
    const fields = ontology ? recordFields(ontology) : [];
    const transition = ontology
        ? ontologyTransitions(ontology).find(entry => entry.transitionId === usecaseId) || null
        : null;
    const lifecycle = readLifecycle(data);
    if (operation === 'transition') {
        const expected = transition?.payload || [];
        const actual = lifecycle?.payload || [];
        for (const path of expected) {
            if (!actual.includes(path)) {
                fail(problems, 'PAYLOAD_MISSING', usecaseId, `Payload ${path} is on ${usecaseId} and is not in the serialized lifecycle.`);
            }
        }
        if (lifecycle && !sameList(actual, expected)) {
            fail(problems, 'PAYLOAD_MISSING', usecaseId, `Lifecycle payload of ${usecaseId} is not the ontology payload.`);
        }
        if (!lifecycle)
            fail(problems, 'PAYLOAD_MISSING', usecaseId, `Transition ${usecaseId} has no lifecycle reference.`);
    }
    const sequence = readSequence(data);
    if (Array.isArray(data.sequence) && sequence.length !== data.sequence.length) {
        fail(problems, 'DEFINITION', usecaseId, `A step of ${usecaseId} did not parse.`);
    }
    if (operation === 'transition' && !sequence.some(step => step.kind === 'transition')) {
        fail(problems, 'PAYLOAD_MISSING', usecaseId, `Transition ${usecaseId} has no transition step.`);
    }
    for (const step of sequence) {
        if (step.kind !== 'transition')
            continue;
        const expected = transition?.payload || lifecycle?.payload || [];
        for (const path of expected) {
            if (!step.payload.includes(path)) {
                fail(problems, 'PAYLOAD_MISSING', usecaseId, `Payload ${path} is not in the serialized transition step.`);
            }
        }
    }
    const inputPaths = functionInputPaths(data);
    const expectedUses = fieldUses({
        operation,
        fields,
        inputPaths,
        payloadPaths: transition?.payload || [],
    });
    const actualUses = readUses(data);
    for (const use of expectedUses) {
        if (!actualUses.some(item => item.path === use.path && item.role === use.role && item.source === use.source)) {
            fail(problems, 'USE_MISSING', usecaseId, `Use ${use.role} of ${use.path} is not in the serialized def.`);
        }
    }
    const requiredRules = new Set([
        ...(transition?.ruleRefs || []),
        ...stringList(data.rulesApplied),
    ]);
    const ruleRefs = readRuleRefs(data);
    for (const ruleId of requiredRules) {
        const ref = ruleRefs.find(item => item.ruleId === ruleId);
        if (!ref) {
            fail(problems, 'RULE_REF_MISSING', usecaseId, `Rule ${ruleId} is only a name. It has no source path and symbol.`);
            continue;
        }
        if (!hasDep(dependsFiles, ref.path)) {
            fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Rule source ${ref.path} is not in dependencies.`);
        }
        const text = fileText(files, ref.path);
        if (text == null) {
            fail(problems, 'SOURCE_ABSENT', usecaseId, `Rule source ${ref.path} is absent.`);
            continue;
        }
        const body = parseD1Source(text, 'defs');
        const content = ruleText(body, ref.symbol);
        if (!content) {
            fail(problems, 'RULE_TEXT_ABSENT', usecaseId, `Rule ${ref.symbol} has no text in ${ref.path}.`);
        }
    }
    const actualPlan = readRulePlan(data);
    if (!actualPlan) {
        fail(problems, 'RULE_COVERAGE', usecaseId, `Usecase ${usecaseId} has no applicability plan. A rule name is not coverage.`);
    }
    else if (ontology) {
        const expected = rulePlanForUsecase({
            moduleName,
            entityId,
            usecaseId,
            operation,
            files,
            entity: {
                rules: [],
                transitions: [],
                namespace: '',
                storageTarget: '',
            },
            routes: readPlanRoutes(data),
        });
        if (!samePlan(actualPlan, expected)) {
            fail(problems, 'RULE_COVERAGE', usecaseId, `Applicability of ${usecaseId} does not match its sources.`);
        }
        const applied = stringList(data.rulesApplied);
        const enforced = enforcedRuleIds(expected);
        if (!sameStrings(applied, enforced)) {
            fail(problems, 'RULE_COVERAGE', usecaseId, `rulesApplied of ${usecaseId} is not the enforced applicability set.`);
        }
        for (const row of expected) {
            const file = originFile(row.origin);
            if (!file || hasDep(dependsFiles, file))
                continue;
            fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Applicability source ${file} is not in dependencies.`);
        }
    }
    const mdm = readMdm(data);
    if (ontology && isMdmOntology(ontology)) {
        const names = capabilityNames(ontology);
        const read = mdmInputFields(contractFiles(files), readPlanRoutes(data).map(route => ({
            route: route.route,
            page: pageIdOf(route.contractPath),
        })), preconditionsFor(files, moduleName, entityId, []));
        const bound = bindMdm({
            entityId,
            namespace: namespaceOf(ontology),
            capabilities: names,
            selected: names.filter(name => capabilityApplies(name, operation)),
            platformFields: platformFieldPaths(ontology),
            inputFields: read.fields,
            contractUnread: read.unread.join('; '),
        });
        for (const gap of bound.gaps)
            fail(problems, gap.code, usecaseId, gap.evidence);
        if (!mdm) {
            fail(problems, 'MDM_CALL_MISSING', usecaseId, `Usecase ${usecaseId} has no MDM binding.`);
        }
        else {
            for (const call of bound.calls) {
                if (!mdm.calls.some(item => sameCall(item, call))) {
                    fail(problems, 'MDM_CALL_MISSING', usecaseId, `MDM call ${call.method} for ${call.capabilities.join(', ')} is not in the serialized def.`);
                }
            }
        }
    }
    else if (mdm) {
        fail(problems, 'MDM_NAMESPACE', usecaseId, `Usecase ${usecaseId} names MDM for ${entityId}, which is not an MDM role.`);
    }
    const routes = readRoutes(data);
    const contractRefs = readContractRefs(data);
    for (const ref of contractRefs) {
        if (!routes.some(route => route.route === ref.route)) {
            fail(problems, 'PROJECTION_MISSING', usecaseId, `Route ${ref.route} has no projection.`);
        }
    }
    for (const route of routes) {
        if (!hasDep(dependsFiles, route.contractPath)) {
            fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Contract ${route.contractPath} is not in dependencies.`);
        }
        if (route.projection !== 'declared')
            continue;
        const ref = contractRefs.find(item => item.route === route.route);
        if (!ref?.symbol) {
            fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Route ${route.route} has no typed symbol.`);
            continue;
        }
        const text = fileText(files, route.contractPath);
        if (text == null) {
            fail(problems, 'SOURCE_ABSENT', usecaseId, `Contract ${route.contractPath} is absent.`);
            continue;
        }
        const ast = readContractAst(text, route.contractPath);
        const declared = contractedFields(ast, ref.symbol);
        const names = declared?.map(field => field.name) || [];
        if (!declared || !sameList(names, route.outputFields)) {
            fail(problems, 'PROJECTION_MISMATCH', usecaseId, `Route ${route.route} projection does not match ${ref.symbol} in ${route.contractPath}.`);
        }
    }
    const effects = readEffects(data);
    const outboundIssues = outboundMechanismProblems(files);
    for (const effect of effects) {
        if (!hasDep(dependsFiles, effect.path)) {
            fail(problems, 'DEPENDENCY_MISSING', usecaseId, `Effect source ${effect.path} is not in dependencies.`);
        }
        const text = fileText(files, effect.path);
        if (text == null) {
            fail(problems, 'SOURCE_ABSENT', usecaseId, `Effect source ${effect.path} is absent.`);
            continue;
        }
        const body = parseD1Source(text, 'defs');
        if (!eventPresent(body, effect.symbol)) {
            fail(problems, 'EVENT_LOST', usecaseId, `Effect ${effect.symbol} is not in ${effect.path}.`);
        }
        for (const issue of outboundIssues) {
            if (!issue.message.includes(effect.eventId))
                continue;
            fail(problems, issue.code, usecaseId, issue.message);
        }
    }
    const transaction = readTransaction(data);
    if (!transaction) {
        fail(problems, 'TRANSACTION_BOUNDARY', usecaseId, `Usecase ${usecaseId} has no transaction boundary.`);
    }
    else if (transaction === 'local' && !sequence.some(step => step.kind === 'transaction' && step.boundary === 'local')) {
        fail(problems, 'TRANSACTION_BOUNDARY', usecaseId, `Usecase ${usecaseId} says the boundary is local and the sequence has no local transaction step.`);
    }
    else if (transaction === 'none' && sequence.some(step => step.kind === 'transaction')) {
        fail(problems, 'TRANSACTION_BOUNDARY', usecaseId, `Usecase ${usecaseId} says there is no boundary and the sequence has a transaction step.`);
    }
    if (!problems.length && transaction && lifecycleMatches(operation, lifecycle)) {
        return {
            behavior: {
                usecaseId,
                operation,
                sequence,
                uses: actualUses,
                mdm,
                lifecycle,
                rules: ruleRefs,
                transaction,
                effects,
                routes: routes.filter(route => route.projection === 'declared').map(route => ({
                    route: route.route,
                    contractPath: route.contractPath,
                    symbol: contractRefs.find(item => item.route === route.route)?.symbol || '',
                    outputFields: route.outputFields,
                })),
            },
            problems,
        };
    }
    return { behavior: null, problems };
}
function lifecycleMatches(operation, lifecycle) {
    return operation === 'transition' ? lifecycle !== null : true;
}
function derivedRole(operation, fieldName, source) {
    if (source === 'payload')
        return 'write';
    if (fieldName === 'id') {
        if (READ_OPERATIONS.has(operation))
            return 'filter';
        if (UPDATE_OPERATIONS.has(operation) || operation === 'transition')
            return 'selector';
        if (operation === 'create')
            return 'write';
        return 'ambiguous';
    }
    if (fieldName === 'version') {
        if (UPDATE_OPERATIONS.has(operation) || operation === 'transition')
            return 'concurrency';
        return 'write';
    }
    if (READ_OPERATIONS.has(operation) && nestedReadFilter(fieldName))
        return 'filter';
    return 'write';
}
/** A dotted path on a read. The leaf `id` is a homonym, not the identity field. */
function nestedReadFilter(name) {
    const dot = name.lastIndexOf('.');
    if (dot <= 0)
        return false;
    const leaf = name.slice(dot + 1);
    return leaf !== 'id' && leaf !== 'version';
}
function useKey(use) {
    return `${use.source}\u0000${use.path}\u0000${use.role}`;
}
function fail(problems, code, path, message) {
    if (problems.some(item => item.code === code && item.message === message))
        return;
    problems.push({ code, path, message });
}
function strip(path) {
    return path.replace(/^\/?_\d+_\/+/, '');
}
function hasDep(dependsFiles, path) {
    const logical = strip(path);
    return dependsFiles.some(item => strip(item) === logical);
}
function fileText(files, path) {
    const project = embeddedProject(path);
    if (project) {
        const tail = unqualified(path);
        const found = files.find(item => embeddedProject(item.path) === project && unqualified(item.path) === tail);
        return found ? found.text : null;
    }
    const logical = strip(path);
    const found = files.find(item => strip(item.path) === logical);
    return found ? found.text : null;
}
function embeddedProject(path) {
    const match = /^\/?_(\d+)_\/+/.exec(path);
    return match ? match[1] : '';
}
function unqualified(path) {
    return path.replace(/^\/?_\d+_\/+/, '');
}
function sameList(left, right) {
    return left.length === right.length && left.every((item, index) => item === right[index]);
}
function stringList(value) {
    if (!Array.isArray(value))
        return [];
    return value.filter((item) => typeof item === 'string' && item.length > 0);
}
function sameStrings(left, right) {
    if (left.length !== right.length)
        return false;
    const seen = new Set(left);
    return right.every(item => seen.has(item));
}
function readPlanRoutes(data) {
    if (!Array.isArray(data.routeProjections))
        return [];
    const out = [];
    for (const item of data.routeProjections) {
        if (!isRecord(item) || typeof item.route !== 'string')
            continue;
        out.push({
            route: item.route,
            contractPath: typeof item.contractPath === 'string' ? item.contractPath : '',
            grants: [],
        });
    }
    return out;
}
function readRulePlan(data) {
    if (!Array.isArray(data.rulePlan))
        return null;
    const out = [];
    for (const item of data.rulePlan) {
        if (!isRecord(item))
            return null;
        const enforcement = item.enforcement;
        if (enforcement !== 'local' && enforcement !== 'delegated' && enforcement !== 'pending')
            return null;
        if (typeof item.ruleId !== 'string')
            return null;
        if (typeof item.origin !== 'string' || !item.origin)
            return null;
        if (typeof item.consumer !== 'string' || !item.consumer)
            return null;
        if (typeof item.gap !== 'string')
            return null;
        if (enforcement === 'pending' && !item.gap)
            return null;
        if (enforcement !== 'pending' && item.gap)
            return null;
        const row = {
            ruleId: item.ruleId,
            origin: item.origin,
            consumer: item.consumer,
            enforcement,
            gap: item.gap,
        };
        if (!row.ruleId && !isStorageConstraintRow(row))
            return null;
        out.push(row);
    }
    return out;
}
function samePlan(left, right) {
    const key = (row) => `${row.consumer}\u0000${row.ruleId}\u0000${row.origin}\u0000${row.enforcement}\u0000${row.gap}`;
    const a = [...left].map(key).sort();
    const b = [...right].map(key).sort();
    return a.length === b.length && a.every((item, index) => item === b[index]);
}
function recordFields(body) {
    if (!isRecord(body) || !isRecord(body.record) || !isRecord(body.record.fields))
        return [];
    const out = [];
    walkFields(body.record.fields, '', out);
    return out;
}
function walkFields(fields, prefix, out) {
    for (const [key, raw] of Object.entries(fields)) {
        if (!isRecord(raw))
            continue;
        const path = prefix ? `${prefix}.${key}` : key;
        if (isRecord(raw.fields)) {
            walkFields(raw.fields, path, out);
            continue;
        }
        out.push({ name: path, derived: raw.derived === true });
    }
}
function isMdmOntology(body) {
    if (!isRecord(body))
        return false;
    if (isRecord(body.storage) && body.storage.target === 'mdm')
        return true;
    return body.kind === 'role' && typeof body.roleTag === 'string' && body.roleTag.length > 0;
}
function contractedFields(ast, symbol) {
    const found = ast.symbols.filter(item => item.name === symbol);
    if (found.length !== 1)
        return null;
    const item = found[0];
    if (item.shape === 'array' && item.fields.length === 0 && item.element) {
        const inner = ast.symbols.filter(entry => entry.name === item.element);
        if (inner.length !== 1)
            return null;
        return inner[0].fields;
    }
    if (item.shape === 'array' && item.fields.length === 0)
        return null;
    return item.fields;
}
function ruleText(body, symbol) {
    if (!isRecord(body) || !isRecord(body.rules))
        return '';
    const text = body.rules[symbol];
    return typeof text === 'string' ? text.trim() : '';
}
function eventPresent(body, symbol) {
    if (!isRecord(body) || !Array.isArray(body.outbound))
        return false;
    return body.outbound.some(item => isRecord(item) && (item.event === symbol || item.id === symbol));
}
/** Reads persisted integrationOutbound defs. The draft is not consulted. */
function outboundMechanismProblems(files) {
    const problems = [];
    for (const file of files) {
        const rendered = readDefinitionExport(file.text);
        if (!rendered || !isRecord(rendered.definition) || rendered.definition.artifactType !== 'integrationOutbound')
            continue;
        if (!isRecord(rendered.definition.data))
            continue;
        for (const issue of integrationMechanismIssues(rendered.definition.data)) {
            const match = /^(FICTIONAL_API|MECHANISM_REF|MECHANISM_INCOMPATIBLE): /.exec(issue);
            if (!match)
                continue;
            problems.push({ code: match[1], path: file.path, message: issue });
        }
    }
    return problems;
}
function functionInputPaths(data) {
    const functions = Array.isArray(data.functions) ? data.functions : [];
    const first = functions.find(isRecord);
    if (!first || !Array.isArray(first.input))
        return [];
    return first.input.flatMap(field => isRecord(field) && typeof field.name === 'string' ? [field.name] : []);
}
function readLifecycle(data) {
    if (!isRecord(data.lifecycle))
        return null;
    const transitionId = typeof data.lifecycle.transitionId === 'string' ? data.lifecycle.transitionId : '';
    const sourcePath = typeof data.lifecycle.sourcePath === 'string' ? data.lifecycle.sourcePath : '';
    const symbol = typeof data.lifecycle.symbol === 'string' ? data.lifecycle.symbol : '';
    if (!transitionId || !sourcePath || !symbol)
        return null;
    return { transitionId, payload: stringList(data.lifecycle.payload), sourcePath, symbol };
}
function readSequence(data) {
    if (!Array.isArray(data.sequence))
        return [];
    const steps = [];
    for (const raw of data.sequence) {
        const step = asStep(raw);
        if (step)
            steps.push(step);
    }
    return steps;
}
function asStep(value) {
    if (!isRecord(value) || typeof value.kind !== 'string')
        return null;
    if (value.kind === 'port' && typeof value.call === 'string' && typeof value.port === 'string') {
        return { kind: 'port', call: value.call, port: value.port };
    }
    if (value.kind === 'rule' && typeof value.ruleId === 'string')
        return { kind: 'rule', ruleId: value.ruleId };
    if (value.kind === 'mdm' && typeof value.namespace === 'string' && typeof value.call === 'string' && typeof value.entity === 'string' && typeof value.capability === 'string') {
        return { kind: 'mdm', namespace: value.namespace, call: value.call, entity: value.entity, capability: value.capability };
    }
    if (value.kind === 'transition' && typeof value.transitionId === 'string') {
        return { kind: 'transition', transitionId: value.transitionId, payload: stringList(value.payload) };
    }
    if (value.kind === 'effect' && typeof value.eventId === 'string')
        return { kind: 'effect', eventId: value.eventId };
    if (value.kind === 'transaction' && (value.boundary === 'local' || value.boundary === 'external')) {
        return { kind: 'transaction', boundary: value.boundary };
    }
    if (value.kind === 'context' && value.source === 'ctx')
        return { kind: 'context', source: 'ctx' };
    return null;
}
function readUses(data) {
    if (!Array.isArray(data.uses))
        return [];
    const uses = [];
    for (const raw of data.uses) {
        if (!isRecord(raw) || typeof raw.path !== 'string')
            continue;
        if (raw.role !== 'filter' && raw.role !== 'selector' && raw.role !== 'concurrency' && raw.role !== 'write')
            continue;
        if (raw.source !== 'input' && raw.source !== 'payload')
            continue;
        uses.push({ path: raw.path, role: raw.role, source: raw.source });
    }
    uses.sort((left, right) => useKey(left).localeCompare(useKey(right)));
    return uses;
}
function readRuleRefs(data) {
    if (!Array.isArray(data.rules))
        return [];
    return data.rules.flatMap(raw => {
        if (!isRecord(raw) || typeof raw.ruleId !== 'string' || typeof raw.path !== 'string' || typeof raw.symbol !== 'string')
            return [];
        return [{ ruleId: raw.ruleId, path: raw.path, symbol: raw.symbol }];
    });
}
function readMdm(data) {
    if (!isRecord(data.mdm) || !Array.isArray(data.mdm.calls))
        return null;
    const calls = [];
    for (const raw of data.mdm.calls) {
        const call = asCall(raw);
        if (call)
            calls.push(call);
    }
    return {
        namespace: typeof data.mdm.namespace === 'string' ? data.mdm.namespace : '',
        role: typeof data.mdm.role === 'string' ? data.mdm.role : '',
        atomic: data.mdm.atomic === true,
        calls,
        gaps: [],
    };
}
function asCall(value) {
    if (!isRecord(value) || typeof value.method !== 'string')
        return null;
    const target = value.target === 'entity' || value.target === 'collection' || value.target === 'identity' ? value.target : null;
    const shape = value.shape === 'point' || value.shape === 'collection' || value.shape === 'write' ? value.shape : null;
    if (!target || !shape || !Array.isArray(value.capabilities) || typeof value.alternative !== 'boolean')
        return null;
    const args = [];
    if (!Array.isArray(value.arguments))
        return null;
    for (const raw of value.arguments) {
        if (!isRecord(raw) || typeof raw.name !== 'string')
            return null;
        if (raw.role !== 'selector' && raw.role !== 'parameter' && raw.role !== 'patch')
            return null;
        const origin = asOrigin(raw.origin);
        if (!origin)
            return null;
        const arg = { name: raw.name, role: raw.role, origin };
        if (typeof raw.capability === 'string')
            arg.capability = raw.capability;
        if (typeof raw.path === 'string')
            arg.path = raw.path;
        if (typeof raw.value === 'string')
            arg.value = raw.value;
        args.push(arg);
    }
    if (typeof value.id !== 'string' || !value.id)
        return null;
    const when = asWhen(value.when);
    if (!when)
        return null;
    return {
        id: value.id,
        method: value.method,
        target,
        shape,
        capabilities: stringList(value.capabilities),
        alternative: value.alternative,
        when,
        arguments: args,
        result: stringList(value.result),
    };
}
function asOrigin(value) {
    if (!isRecord(value))
        return null;
    if (value.kind !== 'contract' && value.kind !== 'context' && value.kind !== 'literal' && value.kind !== 'prior')
        return null;
    const origin = { kind: value.kind };
    if (typeof value.path === 'string')
        origin.path = value.path;
    if (Array.isArray(value.calls) && value.calls.every(item => typeof item === 'string'))
        origin.calls = stringList(value.calls);
    if (typeof value.evidence === 'string')
        origin.evidence = value.evidence;
    return origin;
}
function asWhen(value) {
    if (!Array.isArray(value))
        return null;
    const clauses = [];
    for (const raw of value) {
        if (!isRecord(raw) || (raw.kind !== 'contract' && raw.kind !== 'prior'))
            return null;
        if (typeof raw.path !== 'string' || typeof raw.present !== 'boolean')
            return null;
        const clause = { kind: raw.kind, path: raw.path, present: raw.present };
        if (typeof raw.call === 'string')
            clause.call = raw.call;
        clauses.push(clause);
    }
    return clauses;
}
function sameCall(left, right) {
    return JSON.stringify(normalizeCall(left)) === JSON.stringify(normalizeCall(right));
}
function normalizeCall(call) {
    return {
        id: call.id,
        method: call.method,
        target: call.target,
        shape: call.shape,
        alternative: call.alternative,
        when: call.when.map(clause => ({
            kind: clause.kind,
            path: clause.path,
            call: clause.call || '',
            present: clause.present,
        })),
        arguments: call.arguments.map(arg => ({
            name: arg.name,
            role: arg.role,
            capability: arg.capability || '',
            path: arg.path || '',
            value: arg.value || '',
            origin: {
                kind: arg.origin.kind,
                path: arg.origin.path || '',
                calls: arg.origin.calls || [],
                evidence: arg.origin.evidence || '',
            },
        })).sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right))),
        capabilities: [...call.capabilities].sort(),
        result: [...call.result],
    };
}
function contractFiles(files) {
    const out = [];
    for (const file of files) {
        const pageId = pageIdOf(file.path);
        if (!file.path.includes('/web/contracts/') || !pageId)
            continue;
        out.push({ pageId, path: file.path, source: file.text });
    }
    return out;
}
function pageIdOf(contractPath) {
    const name = contractPath.split('/').pop() || '';
    return name.endsWith('.defs.ts') ? name.slice(0, -'.defs.ts'.length) : '';
}
function readContractRefs(data) {
    const functions = Array.isArray(data.functions) ? data.functions : [];
    const refs = [];
    for (const fn of functions) {
        if (!isRecord(fn) || !Array.isArray(fn.contractRefs))
            continue;
        for (const raw of fn.contractRefs) {
            if (isRecord(raw) && typeof raw.route === 'string' && typeof raw.symbol === 'string') {
                refs.push({ route: raw.route, symbol: raw.symbol });
            }
        }
    }
    return refs;
}
function readRoutes(data) {
    if (!Array.isArray(data.routeProjections))
        return [];
    return data.routeProjections.flatMap(raw => {
        if (!isRecord(raw) || typeof raw.route !== 'string' || typeof raw.contractPath !== 'string')
            return [];
        return [{
                route: raw.route,
                contractPath: raw.contractPath,
                projection: typeof raw.projection === 'string' ? raw.projection : '',
                outputFields: stringList(raw.outputFields),
            }];
    });
}
function readEffects(data) {
    if (!Array.isArray(data.effects))
        return [];
    return data.effects.flatMap(raw => {
        if (!isRecord(raw) || typeof raw.eventId !== 'string' || typeof raw.path !== 'string' || typeof raw.symbol !== 'string')
            return [];
        return [{ eventId: raw.eventId, path: raw.path, symbol: raw.symbol }];
    });
}
function readTransaction(data) {
    if (!isRecord(data.transaction))
        return null;
    if (data.transaction.boundary === 'local' || data.transaction.boundary === 'none')
        return data.transaction.boundary;
    return null;
}
