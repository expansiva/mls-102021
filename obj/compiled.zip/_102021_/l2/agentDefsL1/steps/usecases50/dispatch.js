/// <mls fileReference="_102021_/l2/agentDefsL1/steps/usecases50/dispatch.ts" enhancement="_blank"/>
import { barrierStepFor, decideFanoutRepairs, fanoutExecution as sharedFanoutExecution, fanoutStepFor, fanoutWorkerArg, firstFanoutWorkerArg, parseFanoutWorkerArg, repairStepFor, FANOUT_TITLE as SHARED_FANOUT_TITLE, } from '/_102021_/l2/agentDefsL1/helpers/d1Fanout.js';
/** usecases50 on the shared fan-out (`helpers/d1Fanout.ts`): one worker per selected usecase. */
export const USECASES_FANOUT = {
    stepId: 'usecases50',
    unitKey: 'usecaseId',
    after: 'persistence40-done',
    noun: 'workers',
    barrierTitle: 'Usecases barrier',
};
export const FANOUT_TITLE = SHARED_FANOUT_TITLE;
/** Compact, stable JSON. One arg is one usecase. */
export function workerArg(arg) {
    const { usecaseId, ...rest } = arg;
    return fanoutWorkerArg(USECASES_FANOUT, { ...rest, unitId: usecaseId });
}
export function parseWorkerArg(value) {
    const parsed = parseFanoutWorkerArg(USECASES_FANOUT, value);
    if (!parsed)
        return null;
    const { unitId, ...rest } = parsed;
    return { ...rest, usecaseId: unitId };
}
export function firstWorkerArg(project, moduleName, usecaseId) {
    return firstFanoutWorkerArg(USECASES_FANOUT, project, moduleName, usecaseId);
}
export function fanoutStep(project, moduleName, args) {
    return fanoutStepFor(USECASES_FANOUT, project, moduleName, args);
}
export function fanoutExecution(args) {
    return sharedFanoutExecution(args);
}
export function barrierStep(project, moduleName, dependsOn, round) {
    return barrierStepFor(USECASES_FANOUT, project, moduleName, dependsOn, round);
}
/** One repair per usecase, and no more than the global ceiling. Same rule as every fan-out step. */
export function decideRepairs(input) {
    const decision = decideFanoutRepairs(USECASES_FANOUT, {
        expected: input.expected,
        attempts: input.attempts.map(item => ({ unitId: item.usecaseId, status: item.status, trace: item.trace, unitAttempts: item.unitAttempts })),
        globalAttempts: input.globalAttempts,
        feedbackFor: input.feedbackFor,
    });
    return {
        repairs: decision.repairs.map(({ unitId, ...rest }) => ({ usecaseId: unitId, ...rest })),
        identified: decision.identified.map(({ unitId, ...rest }) => ({ usecaseId: unitId, ...rest })),
        pause: decision.pause,
    };
}
export function repairStep(project, moduleName, order) {
    const { usecaseId, ...rest } = order;
    return repairStepFor(USECASES_FANOUT, project, moduleName, { ...rest, unitId: usecaseId });
}
