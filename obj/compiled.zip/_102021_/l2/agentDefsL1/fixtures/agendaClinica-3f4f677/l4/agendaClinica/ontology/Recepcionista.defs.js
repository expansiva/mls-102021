/// <mls fileReference="_102047_/l4/agendaClinica/ontology/Recepcionista.defs.ts" enhancement="_blank"/>
export const agendaClinicaEntityRecepcionista = {
    "schemaVersion": "2026-09-17-ns5-ontology-v3.1",
    "moduleName": "agendaClinica",
    "entityId": "Recepcionista",
    "title": "Recepcionista",
    "description": "Pessoa da clínica que atua no cadastro de pacientes, agendamento, confirmação telefônica e registro de faltas.",
    "displayField": "details.identification.name",
    "relationships": {},
    "capabilities": {
        "read.byId": "Consulta uma recepcionista pelo identificador mestre, por leitura direta no índice e no documento, para telas da clínica que já possuem seu registro.",
        "locate.byName": "Localiza recepcionistas pelo nome no índice de pessoas, para a clínica encontrar ou conferir o cadastro antes de usá-lo.",
        "locate.byDocument": "Localiza uma recepcionista pelo documento nacional, consultando o índice para evitar que a clínica duplique a mesma pessoa.",
        "register.createOrAttach": "Cria a pessoa quando ela não existe ou anexa o papel de Recepcionista quando já existe, por deduplicação documental e gravação da marca de papel, para a organização cadastrar a equipe de recepção.",
        "edit.platformFields": "Atualiza os dados de identificação da recepcionista nos campos mantidos pela plataforma, reindexando a identificação quando necessário, para a clínica manter o cadastro correto.",
        "inactivate": "Inativa ou reativa o registro mestre da recepcionista pela situação da plataforma, para a clínica retirar uma recepcionista que não atua mais sem apagar seu histórico.",
        "statusHistory.read": "Exibe o histórico de mudanças de situação do registro mestre, consultando o histórico da plataforma, para a clínica acompanhar inativações e reativações.",
        "audit": "Exibe quem alterou os dados da recepcionista e quando, pela auditoria imutável da plataforma, para a clínica realizar conferências administrativas.",
        "invite.login": "Habilita o acesso da recepcionista por convite, criando o índice de login vinculado ao mesmo registro mestre, para que ela entre no módulo com o perfil de recepcionista."
    },
    "rules": [
        "rule-foreign-namespace-refused",
        "rule-document-shape-validated",
        "rule-identity-never-in-namespace",
        "rule-person-privacy-consent-required-br-eu"
    ],
    "writer": "crud",
    "kind": "role",
    "subtype": "Person",
    "roleTag": "agendaClinica.Recepcionista",
    "source": "/_102034_/l4/ontology/mdm.defs.ts",
    "record": {
        "fields": {
            "id": {
                "type": "uuid",
                "required": true,
                "indexed": true,
                "derived": true,
                "description": "mdmId; stable through promotion and merge."
            },
            "version": {
                "type": "integer",
                "required": true,
                "derived": true,
                "writePrecondition": true,
                "description": "Bumped by the engine on every write; optimistic concurrency."
            },
            "details": {
                "type": "object",
                "required": true,
                "description": "Registro mestre da pessoa que exerce o papel de recepcionista na clínica.",
                "fields": {
                    "identification": {
                        "type": "object",
                        "owner": "platform",
                        "fields": {
                            "subtype": {
                                "type": "enum",
                                "required": true,
                                "indexed": true,
                                "derived": true,
                                "values": [
                                    {
                                        "value": "Person",
                                        "title": "Pessoa",
                                        "description": "Pessoa física que atua como recepcionista."
                                    }
                                ],
                                "description": "Subtipo do registro mestre, definido pela plataforma como pessoa.",
                                "title": "Subtipo",
                                "maxLength": 0,
                                "min": 0,
                                "max": 0
                            },
                            "name": {
                                "type": "string",
                                "required": true,
                                "indexed": true,
                                "maxLength": 0,
                                "description": "Nome pelo qual a recepcionista é identificada na clínica.",
                                "title": "Nome",
                                "min": 0,
                                "max": 0
                            },
                            "status": {
                                "type": "enum",
                                "required": true,
                                "indexed": true,
                                "derived": true,
                                "values": [
                                    {
                                        "value": "Active",
                                        "title": "Ativa",
                                        "description": "Recepcionista disponível no cadastro mestre."
                                    },
                                    {
                                        "value": "Inactive",
                                        "title": "Inativa",
                                        "description": "Recepcionista inativada no cadastro mestre."
                                    },
                                    {
                                        "value": "Merged",
                                        "title": "Unificada",
                                        "description": "Registro unificado a outro registro mestre."
                                    },
                                    {
                                        "value": "Blocked",
                                        "title": "Bloqueada",
                                        "description": "Registro bloqueado pela plataforma."
                                    }
                                ],
                                "title": "Situação",
                                "description": "Situação do registro mestre da recepcionista, controlada pela plataforma.",
                                "maxLength": 0,
                                "min": 0,
                                "max": 0
                            },
                            "docType": {
                                "type": "enum",
                                "indexed": true,
                                "values": [
                                    {
                                        "value": "SSN",
                                        "title": "SSN",
                                        "description": "Número de seguridade social."
                                    },
                                    {
                                        "value": "EIN",
                                        "title": "EIN",
                                        "description": "Número de identificação empresarial."
                                    },
                                    {
                                        "value": "Passport",
                                        "title": "Passaporte",
                                        "description": "Documento de passaporte."
                                    },
                                    {
                                        "value": "DriversLicense",
                                        "title": "Carteira de motorista",
                                        "description": "Documento de habilitação."
                                    },
                                    {
                                        "value": "NationalId",
                                        "title": "Documento nacional",
                                        "description": "Documento nacional de identidade."
                                    },
                                    {
                                        "value": "CPF",
                                        "title": "CPF",
                                        "description": "Cadastro de Pessoas Físicas."
                                    },
                                    {
                                        "value": "CNPJ",
                                        "title": "CNPJ",
                                        "description": "Cadastro Nacional da Pessoa Jurídica."
                                    },
                                    {
                                        "value": "VAT",
                                        "title": "VAT",
                                        "description": "Identificação tributária."
                                    },
                                    {
                                        "value": "Other",
                                        "title": "Outro",
                                        "description": "Outro documento aceito pela plataforma."
                                    }
                                ],
                                "title": "Tipo de documento",
                                "description": "Tipo do documento nacional usado para identificar e evitar duplicidade da recepcionista.",
                                "maxLength": 0,
                                "min": 0,
                                "max": 0
                            },
                            "docId": {
                                "type": "string",
                                "indexed": true,
                                "description": "Número do documento nacional da recepcionista, usado na deduplicação do registro mestre.",
                                "title": "Número do documento",
                                "maxLength": 0,
                                "min": 0,
                                "max": 0
                            },
                            "countryCode": {
                                "type": "string",
                                "required": true,
                                "indexed": true,
                                "pattern": "^[A-Z]{2}$",
                                "maxLength": 0,
                                "default": "US",
                                "description": "Código ISO do país ao qual pertencem o documento e as regras aplicáveis à recepcionista.",
                                "title": "País do documento",
                                "min": 0,
                                "max": 0
                            }
                        },
                        "description": "Dados de identificação da pessoa, mantidos pela plataforma e usados para reconhecer a recepcionista."
                    },
                    "base": {
                        "type": "object",
                        "owner": "platform",
                        "fields": {},
                        "description": "Ramo de dados básicos da plataforma; nenhum dado básico adicional é usado especificamente para o papel de recepcionista."
                    },
                    "person": {
                        "type": "object",
                        "owner": "platform",
                        "fields": {},
                        "description": "Ramo de dados pessoais da plataforma; nenhum dado pessoal adicional é usado especificamente para o papel de recepcionista."
                    },
                    "general": {
                        "type": "object",
                        "owner": "organization",
                        "open": true,
                        "description": "Dados promovidos e mantidos pela organização, apenas disponíveis para leitura neste módulo."
                    },
                    "agendaClinica": {
                        "type": "object",
                        "owner": "module",
                        "fields": {},
                        "description": "Module namespace; the prompt asked for no data of this module about the record."
                    }
                }
            }
        }
    }
};
export default agendaClinicaEntityRecepcionista;
