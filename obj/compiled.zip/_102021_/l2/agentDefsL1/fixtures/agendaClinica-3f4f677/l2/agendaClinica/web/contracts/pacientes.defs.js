export const createPacienteRoute = "agendaClinica.pacientes.cmdCreatePaciente";
export const listPacienteRoute = "agendaClinica.pacientes.qryListPaciente";
