export const createConsultaRoute = "agendaClinica.consultas.cmdCreateConsulta";
export const registrarFaltaRoute = "agendaClinica.consultas.cmdRegistrarFalta";
export const updateConsultaRoute = "agendaClinica.consultas.cmdUpdateConsulta";
export const listConsultaRoute = "agendaClinica.consultas.qryListConsulta";
export const listPacienteRoute = "agendaClinica.consultas.qryListPaciente";
export const listProfissionalRoute = "agendaClinica.consultas.qryListProfissional";
