export const createConsultaRoute = "agendaClinica.pacientes.cmdCreateConsulta";
export const createPacienteRoute = "agendaClinica.pacientes.cmdCreatePaciente";
export const listConsultaRoute = "agendaClinica.pacientes.qryListConsulta";
export const listPacienteRoute = "agendaClinica.pacientes.qryListPaciente";
export const listProfissionalRoute = "agendaClinica.pacientes.qryListProfissional";
