export const createProfissionalRoute = "agendaClinica.dados_recepcionista.cmdCreateProfissional";
export const createRecepcionistaRoute = "agendaClinica.dados_recepcionista.cmdCreateRecepcionista";
export const updateProfissionalRoute = "agendaClinica.dados_recepcionista.cmdUpdateProfissional";
export const updateRecepcionistaRoute = "agendaClinica.dados_recepcionista.cmdUpdateRecepcionista";
export const listProfissionalRoute = "agendaClinica.dados_recepcionista.qryListProfissional";
export const listRecepcionistaRoute = "agendaClinica.dados_recepcionista.qryListRecepcionista";
