/// <mls fileReference="_102047_/l4/agendaClinica/workspaces/overview.defs.ts" enhancement="_blank" />
export const overviewWorkspace = {
    "workspaceId": "overview",
    "title": "Laboratório de revisão humana",
    "kind": "landing",
    "actors": [],
    "operationIds": []
};
export default overviewWorkspace;
