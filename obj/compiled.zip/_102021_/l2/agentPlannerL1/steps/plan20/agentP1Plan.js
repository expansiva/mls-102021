/// <mls fileReference="_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan.ts" enhancement="_blank"/>
import { displayPath, ontologyEntityFile, ontologyIndexFile, readDefsJson, readJson, writeJson, } from '/_102035_/l2/solution/fs.js';
import { listPoolBox, readPoolMessage, tracePoolAt, writePoolMessage, } from '/_102035_/l2/solution/pool.js';
import { P1_DEVICE, P1_FLOW_STEP_IDS, createP1RetryStep, markP1Complete, markP1Step, p1BackendFile, p1DraftFile, p1L4DiffFile, p1NeedsFile, p1PipelineFile, readP1AgentText, readP1Pipeline, } from '/_102021_/l2/agentPlannerL1/helpers/p1Core.js';
import { P1_STEP_HOOKS, drainWaitingSiblings, updateStatus, } from '/_102021_/l2/agentPlannerL1/helpers/p1Dispatch.js';
import { buildP1BackendMessage, buildP1BackendTool, buildP1ResolutionSchema, normalizeP1Backend, parseP1Entity, parseP1L4Diff, parseP1Needs, parseP1OntologyIndex, parseP1Resolution, planP1Backend, unwrapP1ArtifactPayload, } from '/_102021_/l2/agentPlannerL1/steps/plan20/contracts.js';
import { formatP1BackendGate, repairP1Backend, validateP1Backend, } from '/_102021_/l2/agentPlannerL1/steps/plan20/gate.js';
const MAX_REPAIRS = 2;
const MAX_TRANSPORT_RETRIES = 1;
export function composeP1SystemPrompt(skillText, stepPrompt) {
    const skill = skillText.replace(/^(?:\s*<!--[\s\S]*?-->\s*)+/, '').trim();
    return [skill, stepPrompt].filter(Boolean).join('\n\n');
}
export function buildP1PlanHumanPrompt(input) {
    const { needs, inventory, ontology } = input.sources;
    const entityLines = ontology.map(entity => {
        const flags = [entity.family, entity.storageKind, entity.storageTarget].filter(Boolean);
        return `- ${entity.entityId} (${flags.join(', ')})`;
    });
    const inventoryLines = inventory.usecases.map(item => {
        const fn = item.functions.map(fn => fn.name).join(',') || '(none)';
        return `- ${item.usecaseId} file=${item.file} fn=${fn} ports=${item.ports.join(',') || '(none)'}`;
    });
    return [
        `## Module`,
        needs.moduleName,
        '',
        '## Locked draft (deterministic; keep done/toUpdate)',
        JSON.stringify(input.planned.file, null, 2),
        '',
        '## Unresolved candidates (the only thing you decide)',
        JSON.stringify(input.planned.unresolved, null, 2),
        '',
        '## l1 inventory',
        inventory.present ? inventoryLines.join('\n') || '(empty lists)' : '(none — every candidate is toCreate)',
        '',
        '## Entities',
        entityLines.length ? entityLines.join('\n') : '(none)',
        input.gateFeedback ? `\n## Deterministic repair required\n${input.gateFeedback}` : '',
        input.previousDraft ? `\n## Current draft; keep unrelated fields\n${JSON.stringify(input.previousDraft, null, 2)}` : '',
    ].filter(item => item !== '').join('\n');
}
export async function loadP1Ontology(moduleName) {
    const index = await readDefsJson(ontologyIndexFile(moduleName));
    if (!index)
        return [];
    const ids = parseP1OntologyIndex(index);
    const indexRows = Array.isArray(index.entities)
        ? index.entities
        : [];
    const byId = new Map();
    for (const row of indexRows) {
        if (row && typeof row === 'object' && 'entityId' in row && typeof row.entityId === 'string') {
            byId.set(row.entityId, row);
        }
    }
    const out = [];
    for (const entityId of ids) {
        const file = await readDefsJson(ontologyEntityFile(moduleName, entityId));
        const parsed = parseP1Entity(file || byId.get(entityId), byId.get(entityId));
        if (parsed)
            out.push(parsed);
    }
    return out;
}
export async function loadP1PlanSources(moduleName) {
    const pipeline = await requirePipeline(moduleName);
    const rawNeeds = await readJson(p1NeedsFile(moduleName, pipelineDevice(pipeline)));
    if (rawNeeds === null)
        throw new Error('needs.json is missing; entry10 must run first.');
    const needs = parseP1Needs(rawNeeds);
    const ontology = await loadP1Ontology(moduleName);
    const rawDiff = await readJson(p1L4DiffFile(moduleName, pipelineDevice(pipeline)));
    return {
        needs,
        inventory: pipeline.inventory,
        ontology,
        pipeline,
        l4diff: rawDiff === null ? null : parseP1L4Diff(rawDiff),
    };
}
export async function executeP1Plan(moduleName, now, resolution) {
    const sources = await loadP1PlanSources(moduleName);
    const planned = planP1Backend({
        needs: sources.needs,
        inventory: sources.inventory,
        ontology: sources.ontology,
        now,
        resolution,
        l4diff: sources.l4diff,
    });
    const repaired = repairP1Backend(planned.file, sources.needs, sources.ontology, sources.inventory, sources.l4diff);
    const gate = validateP1Backend(repaired, sources.needs, sources.ontology);
    if (!gate.ok)
        throw new Error(formatP1BackendGate(gate.issues));
    return commitP1Plan(sources, repaired, now);
}
export async function beforeP1PlanPromptStep(_agent, context, parentStep, step, hookSequential, args) {
    if (!context.task)
        throw new Error('[agentPlannerL1:plan20] task invalid');
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, args || step.prompt);
        moduleName = parsed.moduleName;
        const sources = await loadP1PlanSources(moduleName);
        const planned = planP1Backend({
            needs: sources.needs,
            inventory: sources.inventory,
            ontology: sources.ontology,
            now: new Date(),
            l4diff: sources.l4diff,
        });
        if (!planned.unresolved.length && !parsed.gateFeedback) {
            const mutationParent = findMutableParent(context, parentStep);
            const delivered = await commitP1Plan(sources, planned.file, new Date());
            return [
                doneAnchor(context, mutationParent, moduleName, delivered),
                updateStatus(context, mutationParent, step, hookSequential, 'completed', `plan20 wrote ${delivered.backendPath}`),
            ];
        }
        const [skill, prompt, previous] = await Promise.all([
            readP1AgentText('skills', 'architecture', '.md'),
            readP1AgentText('steps/plan20', 'prompt', '.md'),
            moduleName ? readJson(p1DraftFile(moduleName, 'plan20')) : Promise.resolve(null),
        ]);
        const schema = buildP1ResolutionSchema();
        const tool = buildP1BackendTool(schema);
        await writeJson(p1DraftFile(moduleName, 'plan20'), planned.file);
        const humanPrompt = buildP1PlanHumanPrompt({
            sources,
            planned,
            gateFeedback: parsed.gateFeedback,
            previousDraft: previous,
        });
        return [promptReady(context, parentStep, hookSequential, args || String(step.prompt || ''), composeP1SystemPrompt(skill, prompt), humanPrompt, tool)];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
export async function afterP1PlanPromptStep(_agent, context, parentStep, step, hookSequential) {
    let moduleName = '';
    try {
        const parsed = resolveArgs(context, step.prompt);
        moduleName = parsed.moduleName;
        const mutationParent = findMutableParent(context, parentStep);
        const payload = unwrapP1ArtifactPayload(step.interaction?.payload?.[0]);
        if (!isRecord(payload)) {
            const failure = readPromptFailure(step, 'plan20 returned no usable backend resolution.');
            if (parsed.transportAttempt < MAX_TRANSPORT_RETRIES) {
                return [
                    addStep(context, mutationParent, createP1RetryStep('plan20', moduleName, 'transport', parsed.transportAttempt + 1)),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `plan20 transport retry ${parsed.transportAttempt + 1} scheduled: ${failure}`),
                ];
            }
            throw new Error(failure);
        }
        const sources = await loadP1PlanSources(moduleName);
        const now = new Date();
        const resolution = parseP1Resolution(payload);
        const planned = planP1Backend({
            needs: sources.needs,
            inventory: sources.inventory,
            ontology: sources.ontology,
            now,
            resolution,
            l4diff: sources.l4diff,
        });
        let draft = normalizeP1Backend(payload, {
            needs: sources.needs,
            inventory: sources.inventory,
            ontology: sources.ontology,
            now,
            resolution,
            l4diff: sources.l4diff,
        });
        if (!draft.endpoints.length)
            draft = planned.file;
        draft = repairP1Backend(draft, sources.needs, sources.ontology, sources.inventory, sources.l4diff);
        let pipeline = await requirePipeline(moduleName);
        pipeline = await writeStepState(pipeline, {
            status: 'running',
            updatedAt: now.toISOString(),
        });
        const draftPath = await writeJson(p1DraftFile(moduleName, 'plan20'), draft);
        const gate = validateP1Backend(draft, sources.needs, sources.ontology);
        if (!gate.ok) {
            const feedback = formatP1BackendGate(gate.issues);
            if (parsed.repairAttempt < MAX_REPAIRS) {
                return [
                    addStep(context, mutationParent, createP1RetryStep('plan20', moduleName, 'repair', parsed.repairAttempt + 1, { gateFeedback: feedback })),
                    updateStatus(context, mutationParent, step, hookSequential, 'completed', `plan20 gate scheduled repair ${parsed.repairAttempt + 1}.`),
                ];
            }
            await writeStepState(pipeline, {
                status: 'failed',
                updatedAt: new Date().toISOString(),
                error: feedback,
                artifactPaths: [draftPath],
            });
            throw new Error(feedback);
        }
        const delivered = await commitP1Plan(sources, draft, now);
        return [
            doneAnchor(context, mutationParent, moduleName, delivered),
            updateStatus(context, mutationParent, step, hookSequential, 'completed', `plan20 wrote ${delivered.backendPath}`),
        ];
    }
    catch (error) {
        const message = errorMessage(error);
        await recordFailure(moduleName, message);
        return [
            ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
            updateStatus(context, parentStep, step, hookSequential, 'failed', message),
        ];
    }
}
async function commitP1Plan(sources, backend, now) {
    const received = await readReceived(sources.pipeline);
    const message = buildP1BackendMessage({ file: backend, received });
    const backendInfo = p1BackendFile(sources.needs.moduleName, backend.device);
    const backendPath = await writeJson(backendInfo, backend);
    const messageInfo = await writePoolMessage(sources.needs.moduleName, message, now);
    const messagePath = displayPath(messageInfo);
    const pipelineInfo = p1PipelineFile(sources.needs.moduleName);
    await tracePoolAt(pipelineInfo, {
        at: now.toISOString(),
        file: messagePath,
        from: message.from,
        to: message.to,
        thread: message.thread,
        round: message.round,
        mode: message.mode,
        outcome: 'delivered',
    });
    const pipeline = await requirePipeline(sources.needs.moduleName);
    const updated = markP1Step(pipeline, 'plan20', {
        status: 'approved',
        updatedAt: now.toISOString(),
        artifactPaths: [backendPath, messagePath],
    });
    await writeJson(pipelineInfo, markP1Complete(updated, now.toISOString()));
    return {
        backend,
        backendPath,
        message,
        messagePath,
        llmCalled: backend.meta.llmCalled,
    };
}
async function readReceived(pipeline) {
    const found = listPoolBox(pipeline.moduleName, 'l1').find(file => displayPath(file) === pipeline.messageFile);
    if (found) {
        try {
            const message = await readPoolMessage(found);
            return { thread: message.thread, round: message.round, mode: message.mode };
        }
        catch { /* fall through */ }
    }
    return { thread: pipeline.thread, round: pipeline.round, mode: 'implement' };
}
async function requirePipeline(moduleName) {
    const pipeline = await readP1Pipeline(moduleName);
    if (!pipeline)
        throw new Error(`l1 pipeline.json is missing for ${moduleName}; entry10 must run first.`);
    return pipeline;
}
function pipelineDevice(pipeline) {
    return P1_DEVICE;
}
async function writeStepState(pipeline, next) {
    const updated = markP1Step(pipeline, 'plan20', next);
    await writeJson(p1PipelineFile(pipeline.moduleName), updated);
    return updated;
}
async function recordFailure(moduleName, error) {
    if (!moduleName)
        return;
    try {
        const pipeline = await readP1Pipeline(moduleName);
        if (!pipeline)
            return;
        await writeJson(p1PipelineFile(moduleName), markP1Step(pipeline, 'plan20', {
            status: 'failed',
            updatedAt: new Date().toISOString(),
            error,
        }));
    }
    catch { /* task trace remains the fallback */ }
}
function resolveArgs(context, value) {
    const root = parseRecord(value);
    const moduleName = text(root.moduleName) || memoryString(context, 'moduleName');
    return {
        planId: text(root.planId) || 'plan20',
        moduleName,
        repairAttempt: integer(root.repairAttempt),
        transportAttempt: integer(root.transportAttempt),
        gateFeedback: text(root.gateFeedback),
    };
}
function promptReady(context, parentStep, hookSequential, args, systemPrompt, humanPrompt, tool) {
    return {
        type: 'prompt_ready',
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        systemPrompt,
        humanPrompt,
        tools: [tool],
        toolChoice: { type: 'function', function: { name: tool.function.name } },
    };
}
function doneAnchor(context, parentStep, moduleName, delivered) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Plan done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName,
            artifactPaths: [delivered.backendPath, delivered.messagePath],
            llmCalled: delivered.llmCalled,
            completedStep: 'plan20',
            nextStep: P1_FLOW_STEP_IDS[1] === 'plan20' ? undefined : P1_FLOW_STEP_IDS[1],
        }),
        planning: { planId: 'plan20-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findMutableParent(context, parentStep) {
    const current = allSteps(context).find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function allSteps(context) {
    const root = context.task?.iaCompressed?.nextSteps || [];
    const out = [];
    const walk = (steps) => {
        for (const step of steps) {
            out.push(step);
            if (step.nextSteps?.length)
                walk(step.nextSteps);
        }
    };
    walk(root);
    return out;
}
function readPromptFailure(step, fallback) {
    const payload = step.interaction?.payload?.[0];
    const recordValue = isRecord(payload) ? payload : parseRecord(payload);
    if (typeof recordValue.result === 'string' && recordValue.result.trim())
        return recordValue.result.trim();
    return fallback;
}
function parseRecord(value) {
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return isRecord(parsed) ? parsed : {};
        }
        catch {
            return {};
        }
    }
    return isRecord(value) ? value : {};
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
function text(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function integer(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : 0;
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
P1_STEP_HOOKS.plan20 = {
    beforePromptStep: beforeP1PlanPromptStep,
    afterPromptStep: afterP1PlanPromptStep,
};
