/// <mls fileReference="_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.defs.ts" enhancement="_blank"/>
export const listChamadoUsecase = {
    "schemaVersion": "2026-06-26",
    "artifactType": "usecase",
    "artifactId": "listChamado",
    "moduleName": "controleChamados",
    "status": "draft",
    "source": {
        "agentName": "agentCbUsecase",
        "stepId": 0,
        "planId": ""
    },
    "data": {
        "usecaseId": "listChamado",
        "rulesApplied": [],
        "mdmRefs": []
    }
};
export default listChamadoUsecase;
export const pipeline = [
    {
        "id": "listChamado__applicationUsecase",
        "type": "applicationUsecase",
        "outputPath": "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.ts",
        "defPath": "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.defs.ts",
        "dependsFiles": [
            "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts",
            "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"
        ],
        "dependsOn": [],
        "skills": [
            "_102021_/l2/agentDefsL1/skills/architecture.md",
            "_102021_/l2/agentDefsL1/skills/usecase.md",
            "_102034_.d.ts"
        ],
        "agent": "agentCbMaterialize"
    }
];
