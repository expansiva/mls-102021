/// <mls fileReference="_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry.ts" enhancement="_blank"/>
import { setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { P1_FLOW_STEP_IDS, buildP1PlannedSteps, executeP1Entry, moduleTokenOk, parseP1StepPrompt, } from '/_102021_/l2/agentPlannerL1/helpers/p1Core.js';
import { P1_STEP_HOOKS, drainWaitingSiblings, planIdOf, updateStatus, } from '/_102021_/l2/agentPlannerL1/helpers/p1Dispatch.js';
export async function beforeP1EntryPromptStep(_agent, context, parentStep, step, hookSequential, args) {
    const parsed = parseP1StepPrompt(args || step.prompt || '');
    if (parsed.kind === 'refusal') {
        const moduleName = moduleNameFromPrompt(args || step.prompt || '');
        if (moduleName && moduleTokenOk(moduleName))
            setModuleRoot(moduleName, null);
        return refuse(context, parentStep, step, hookSequential, parsed.refusal);
    }
    const source = parsed.kind === 'step'
        ? { kind: 'step', moduleName: parsed.moduleName, thread: parsed.thread, file: parsed.file, candidate: parsed.candidate }
        : { kind: 'hand', moduleName: parsed.moduleName, candidate: parsed.candidate };
    const result = await executeP1Entry(source, new Date());
    if ('refusal' in result) {
        return refuse(context, parentStep, step, hookSequential, result.refusal);
    }
    const mutationParent = findOpenParent(context, parentStep);
    const extras = missingPlannedSteps(context, result, parsed.candidate).map(item => addStep(context, mutationParent, item));
    return [
        ...extras,
        doneAnchor(context, mutationParent, result),
        updateStatus(context, mutationParent, step, hookSequential, 'completed', `entry10 recorded thread ${result.pipeline.thread} round ${result.pipeline.round}`),
    ];
}
export async function afterP1EntryPromptStep(_agent, context, parentStep, step, hookSequential) {
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'entry10 already recorded.')];
}
function refuse(context, parentStep, step, hookSequential, message) {
    return [
        ...drainWaitingSiblings(context, step, hookSequential, `stopped: ${message}`),
        updateStatus(context, parentStep, step, hookSequential, 'completed', message),
    ];
}
function missingPlannedSteps(context, result, candidate) {
    const present = new Set(allSteps(context).map(item => planIdOf(item)).filter(Boolean));
    return buildP1PlannedSteps(result.pipeline.moduleName, {
        thread: result.pipeline.thread,
        file: result.pipeline.messageFile,
        candidate,
    }).filter(item => {
        const id = item.planning?.planId || '';
        return id !== 'entry10' && !present.has(id);
    });
}
function doneAnchor(context, parentStep, result) {
    return addStep(context, parentStep, {
        type: 'result',
        stepId: 0,
        interaction: null,
        stepTitle: 'Entry done',
        status: 'completed',
        nextSteps: [],
        result: JSON.stringify({
            moduleName: result.pipeline.moduleName,
            thread: result.pipeline.thread,
            round: result.pipeline.round,
            messageFile: result.pipeline.messageFile,
            sourceMessages: result.pipeline.sourceMessages,
            inventoryPresent: result.pipeline.inventory.present,
            completedStep: 'entry10',
            nextStep: P1_FLOW_STEP_IDS[1],
        }),
        planning: { planId: 'entry10-done', dependsOn: [], executionMode: 'manual_later', executionHost: 'client' },
    });
}
function addStep(context, parentStep, step) {
    return {
        type: 'add-step',
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        step,
    };
}
function findOpenParent(context, parentStep) {
    const current = allSteps(context).find(item => item.stepId === parentStep.stepId);
    if (isOpenAgent(current))
        return current;
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    return root?.type === 'agent' ? root : parentStep;
}
function isOpenAgent(step) {
    return step?.type === 'agent' && step.status !== 'completed' && step.status !== 'failed';
}
function allSteps(context) {
    const root = context.task?.iaCompressed?.nextSteps || [];
    const out = [];
    const walk = (steps) => {
        for (const step of steps) {
            out.push(step);
            if (step.nextSteps?.length)
                walk(step.nextSteps);
        }
    };
    walk(root);
    return out;
}
function moduleNameFromPrompt(prompt) {
    try {
        const parsed = JSON.parse(String(prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName.trim() : '';
    }
    catch {
        return '';
    }
}
P1_STEP_HOOKS.entry10 = {
    beforePromptStep: beforeP1EntryPromptStep,
    afterPromptStep: afterP1EntryPromptStep,
};
