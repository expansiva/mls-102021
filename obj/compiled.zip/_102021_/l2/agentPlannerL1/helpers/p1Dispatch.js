/// <mls fileReference="_102021_/l2/agentPlannerL1/helpers/p1Dispatch.ts" enhancement="_blank"/>
import { writeJson } from '/_102035_/l2/solution/fs.js';
import { P1_AGENT_NAME, ownerStepId, p1PipelineFile, } from '/_102021_/l2/agentPlannerL1/helpers/p1Core.js';
/** Filled by later specs. A missing entry means the step is not implemented yet. */
export const P1_STEP_HOOKS = {};
export function planIdOf(step) {
    return step.planning?.planId || '';
}
export function hooksFor(planId, prompt) {
    const stepId = ownerStepId(planId, prompt);
    if (stepId)
        return P1_STEP_HOOKS[stepId];
    return undefined;
}
export async function markAwaitingStep(pipeline, stepId) {
    const next = {
        ...pipeline,
        status: 'awaitingStep',
        awaitingStep: stepId,
        updatedAt: new Date().toISOString(),
    };
    await writeJson(p1PipelineFile(pipeline.moduleName), next);
    return next;
}
export function p1StatusMessage(agent, context, message) {
    return {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: `<!-- modelType: general -->\n${message}` },
                { type: 'human', content: message },
            ],
            taskTitle: 'planner L1',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: { taskName: 'plannerL1', flowName: P1_AGENT_NAME, statusOnly: 'true' },
        },
    };
}
export function updateStatus(context, parentStep, step, hookSequential, status, traceMsg) {
    return {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status,
        cleaner: 'input_output',
        traceMsg,
    };
}
export function drainWaitingSiblings(context, current, hookSequential, traceMsg, opts) {
    const root = context.task?.iaCompressed?.nextSteps?.[0];
    if (!root)
        return [];
    const intents = [];
    for (const sibling of walk(root.nextSteps || [])) {
        if (sibling.stepId === current.stepId)
            continue;
        if (sibling.status === 'completed' || sibling.status === 'failed')
            continue;
        if (opts?.onlyUnimplemented && hooksFor(planIdOf(sibling), sibling.prompt))
            continue;
        intents.push(updateStatus(context, root, sibling, hookSequential, 'completed', traceMsg));
    }
    return intents;
}
function walk(steps) {
    const out = [];
    for (const step of steps) {
        out.push(step);
        if (step.nextSteps?.length)
            out.push(...walk(step.nextSteps));
    }
    return out;
}
