/// <mls fileReference="_102021_/l2/agentPlannerL1/helpers/p1Core.ts" enhancement="_blank"/>
import { diskFileInfo, displayPath, hostListFolder, moduleFile, moduleFolder, normalizeModuleName, readJson, readPipeline, setModuleRoot, writeJson, } from '/_102035_/l2/solution/fs.js';
import { listPoolBox, readPoolMessage } from '/_102035_/l2/solution/pool.js';
import { readL1Inventory } from '/_102021_/l2/agentPlannerL1/helpers/l1Inventory.js';
export const P1_FLOW_ID = 'agentPlannerL1';
export const P1_FLOW_VERSION = '2026-09-20-p1-flow-v1';
export const P1_AGENT_NAME = 'agentPlannerL1';
export const P1_PIPELINE_SCHEMA_VERSION = '2026-09-20-p1-pipeline-v1';
export const P1_NEEDS_SCHEMA = '2026-09-21-p2-needs-v1';
export const P1_DEVICE = 'web';
/** Steps the current flow.json actually runs. */
export const P1_FLOW_STEP_IDS = ['entry10', 'plan20'];
export const P1_STEP_IDS = P1_FLOW_STEP_IDS;
/** Last step of `docs/flow.json` — plan20 closes the pipeline. */
export const P1_FLOW_LAST_STEP_ID = P1_FLOW_STEP_IDS[P1_FLOW_STEP_IDS.length - 1];
export const P1_STEP_TITLES = {
    entry10: 'Entry',
    plan20: 'Plan',
};
export const P1_STEP_DEPENDS_ON = {
    entry10: [],
    plan20: ['entry10-done'],
};
/** Pool message file: `<stamp>_<thread>_<round>`. `needs.json` does not match. */
const POOL_MESSAGE_SHORT = /^\d{14}_[A-Za-z0-9]+-\d{14}_[123]$/;
/** Copied from `plCore.ts:68,111` — L1 must not import the L4 planner. */
const CANDIDATE_RE = /(^|\s)\/candidate(?:\s+(?!\/)(\S+))?(?=\s|$)/i;
const CANDIDATE_DOTDOT = 'Candidate path must not contain \'..\'.';
/** Same default as `PL_DEFAULT_CANDIDATE_REL` in `plCore.ts`. */
export const P1_DEFAULT_CANDIDATE_REL = 'tobe/plan';
const AGENT_PREFIXES = [
    /@@\s*_102021_\/l2\/agentPlannerL1/gi,
    /@@\s*_102021_agentPlannerL1/gi,
    /@@\s*agentPlannerL1/gi,
];
export function isP1StepId(value) {
    return P1_STEP_IDS.includes(value);
}
export function moduleTokenOk(moduleName) {
    return /^[a-z][A-Za-z0-9]*$/.test(moduleName);
}
/** Copied from `plCore.ts:111`. `..` in the relative path returns `''`. */
export function resolveCandidateFolder(moduleName, relativePath = '') {
    const mod = normalizeModuleName(moduleName);
    const rel = String(relativePath || '').trim().replace(/^\/+|\/+$/g, '') || P1_DEFAULT_CANDIDATE_REL;
    if (rel.includes('..'))
        return '';
    if (rel === mod || rel.startsWith(`${mod}/`))
        return rel;
    return `${mod}/${rel}`;
}
/**
 * Point `moduleFolder` at `candidate`, or restore the canonical root when it is
 * empty. `..` is a refusal, not a silent "no candidate". Always call this before
 * reading l4 / pool / pipeline so a previous task cannot leak its root.
 */
export function applyP1CandidateRoot(moduleName, candidate) {
    const name = normalizeModuleName(moduleName, '');
    if (!name)
        return '';
    const raw = String(candidate || '').trim();
    if (!raw) {
        setModuleRoot(name, null);
        return '';
    }
    if (raw.includes('..')) {
        setModuleRoot(name, null);
        return CANDIDATE_DOTDOT;
    }
    const resolved = resolveCandidateFolder(name, raw);
    if (!resolved) {
        setModuleRoot(name, null);
        return CANDIDATE_DOTDOT;
    }
    setModuleRoot(name, resolved);
    return '';
}
/**
 * Maps child planIds back to the owning step. Done-anchors stay unmatched so they
 * are not dispatched. A step prompt `{ moduleName, thread, file }` (pool dispatch)
 * is entry10.
 */
export function ownerStepId(planId, prompt) {
    if (isP1StepId(planId))
        return planId;
    for (const id of P1_STEP_IDS) {
        if (planId === `${id}-done` || planId.startsWith(`${id}-clarification`))
            return '';
        if (planId.startsWith(`${id}-`))
            return id;
    }
    if (isPoolEntryPrompt(prompt))
        return 'entry10';
    return '';
}
export function isPoolEntryPrompt(prompt) {
    const parsed = parseP1StepPrompt(prompt || '');
    return parsed.kind === 'step';
}
export function parseP1Invocation(value) {
    let raw = String(value || '');
    for (const prefix of AGENT_PREFIXES)
        raw = raw.replace(prefix, ' ');
    const candidateMatch = CANDIDATE_RE.exec(raw);
    const hasCandidate = !!candidateMatch;
    const candidateRel = candidateMatch?.[2] || '';
    const tokens = raw
        .replace(new RegExp(CANDIDATE_RE.source, 'gi'), ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .split(' ')
        .filter(Boolean);
    const module = tokens[0] || '';
    const candidate = hasCandidate && module ? resolveCandidateFolder(module, candidateRel) : '';
    return { module, candidate, hasCandidate };
}
export function p1InvocationRefusal(invocation) {
    if (!invocation.module)
        return 'Pass @@agentPlannerL1 <lowerCamel>.';
    if (!moduleTokenOk(invocation.module))
        return 'Module name must be lowerCamel (example: stockControl).';
    if (invocation.hasCandidate && !invocation.candidate)
        return CANDIDATE_DOTDOT;
    return '';
}
export function parseP1StepPrompt(prompt) {
    let parsed;
    try {
        parsed = JSON.parse(String(prompt || '{}'));
    }
    catch {
        return { kind: 'refusal', refusal: 'step prompt must be JSON.' };
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return { kind: 'refusal', refusal: 'step prompt must be a JSON object.' };
    }
    const raw = parsed;
    const moduleName = typeof raw.moduleName === 'string' ? raw.moduleName.trim() : '';
    const thread = typeof raw.thread === 'string' ? raw.thread.trim() : '';
    const file = typeof raw.file === 'string' ? raw.file.trim() : '';
    const candidate = typeof raw.candidate === 'string' ? raw.candidate.trim() : '';
    if (candidate.includes('..'))
        return { kind: 'refusal', refusal: CANDIDATE_DOTDOT };
    if (moduleName && thread && file)
        return { kind: 'step', moduleName, thread, file, candidate };
    if (moduleName)
        return { kind: 'entry', moduleName, candidate };
    return { kind: 'refusal', refusal: 'step prompt needs moduleName.' };
}
/** `l1/<module>/pipeline/pipeline.json` in the project of the run. */
export function p1PipelineFile(moduleName) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 1,
        folder: `${base.folder}/pipeline`,
        shortName: 'pipeline',
        extension: '.json',
    };
}
/** `l4/<module>/pool/l1/web/needs.json` — written by L2, read here. */
export function p1NeedsFile(moduleName, device = P1_DEVICE) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 4,
        folder: `${base.folder}/pool/l1/${device}`,
        shortName: 'needs',
        extension: '.json',
    };
}
/** `l4/<module>/pool/l1/web/l4diff.json` — written by L4 (p4_09). Absent is valid. */
export function p1L4DiffFile(moduleName, device = P1_DEVICE) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 4,
        folder: `${base.folder}/pool/l1/${device}`,
        shortName: 'l4diff',
        extension: '.json',
    };
}
/** `l4/<module>/pool/l2/web/backend.json` — written by plan20. Not a pool message. */
export function p1BackendFile(moduleName, device = P1_DEVICE) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 4,
        folder: `${base.folder}/pool/l2/${device}`,
        shortName: 'backend',
        extension: '.json',
    };
}
export function createP1Pipeline(moduleName, message, messageFile, now, sourceMessages, needsFile, inventory) {
    const updatedAt = now.toISOString();
    return {
        schemaVersion: P1_PIPELINE_SCHEMA_VERSION,
        flowId: P1_FLOW_ID,
        moduleName,
        status: 'inProgress',
        steps: {
            entry10: {
                status: 'approved',
                updatedAt,
                artifactPaths: [`l1/${moduleFolder(moduleName)}/pipeline/pipeline.json`],
            },
        },
        thread: message.thread,
        round: message.round,
        messageFile,
        sourceMessages,
        needsFile,
        inventory,
        updatedAt,
    };
}
export function createP1AgentStep(stepId, moduleName, entry) {
    const dependsOn = [...P1_STEP_DEPENDS_ON[stepId]];
    const prompt = { planId: stepId, moduleName, thread: entry.thread, file: entry.file };
    if (entry.candidate)
        prompt.candidate = entry.candidate;
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: P1_STEP_TITLES[stepId],
        status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
        nextSteps: [],
        agentName: P1_AGENT_NAME,
        prompt: JSON.stringify(prompt),
        rags: [],
        planning: {
            planId: stepId,
            dependsOn,
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
export function buildP1PlannedSteps(moduleName, entry) {
    return P1_FLOW_STEP_IDS.map(stepId => createP1AgentStep(stepId, moduleName, entry));
}
export function isP1PoolMessageFile(shortName) {
    return POOL_MESSAGE_SHORT.test(shortName);
}
function poolMessageFileName(file) {
    return `${file.shortName}${file.extension}`;
}
function requestKey(moduleName, message) {
    const threadModule = message.thread.replace(/-\d{14}$/, '') || moduleName;
    const artifacts = [...message.artifacts].map(item => item.trim()).filter(Boolean).sort().join('\0');
    return `${threadModule}\0${message.mode}\0${artifacts}`;
}
export function p1DifferentRequestsRefusal(count) {
    return `pool/l1 has ${count} different requests; resolve with the l2 planner`;
}
function matchPoolFile(file, wanted) {
    const path = displayPath(file);
    return path === wanted || file.shortName === wanted || `${file.shortName}${file.extension}` === wanted;
}
function isNeedsArtifact(path) {
    const trimmed = path.trim();
    return trimmed === 'pool/l1/web/needs.json' || /(^|\/)needs\.json$/.test(trimmed);
}
function isL2NeedsMessage(message) {
    return message.from === 'l2' && message.to === 'l1' && message.artifacts.some(isNeedsArtifact);
}
function isRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
async function loadNeeds(moduleName, message) {
    if (!message.artifacts.some(isNeedsArtifact))
        return { refusal: 'needs.json is missing' };
    const needsFile = p1NeedsFile(moduleName);
    const raw = await readJson(needsFile);
    if (raw === null)
        return { refusal: 'needs.json is missing' };
    if (!isRecord(raw))
        return { refusal: 'needs.json schema is unknown' };
    if (raw.schemaVersion !== P1_NEEDS_SCHEMA)
        return { refusal: 'needs.json schema is unknown' };
    return {
        needsFile,
        needs: {
            schemaVersion: String(raw.schemaVersion),
            moduleName: typeof raw.moduleName === 'string' ? raw.moduleName : '',
            device: typeof raw.device === 'string' ? raw.device : undefined,
            pages: Array.isArray(raw.pages) ? raw.pages : [],
        },
    };
}
export async function loadP1Entry(source) {
    const moduleName = normalizeModuleName(source.moduleName, '');
    if (!moduleName || !moduleTokenOk(moduleName)) {
        return { refusal: 'Module name must be lowerCamel (example: stockControl).' };
    }
    const rootRefusal = applyP1CandidateRoot(moduleName, source.candidate || '');
    if (rootRefusal)
        return { refusal: rootRefusal };
    const l4 = await readPipeline(moduleName);
    if (!l4 || l4.status !== 'complete') {
        return { refusal: `Module "${moduleName}" has no complete l4.` };
    }
    const box = listPoolBox(moduleName, 'l1').filter(file => isP1PoolMessageFile(file.shortName));
    if (!box.length)
        return { refusal: `nothing pending for ${moduleName} in pool/l1` };
    const loaded = [];
    for (const file of box) {
        loaded.push({ file, message: await readPoolMessage(file) });
    }
    const needsRequests = loaded.filter(entry => isL2NeedsMessage(entry.message));
    if (!needsRequests.length)
        return { refusal: 'needs.json is missing' };
    const groups = new Map();
    for (const entry of needsRequests) {
        const key = requestKey(moduleName, entry.message);
        const group = groups.get(key) || [];
        group.push(entry);
        groups.set(key, group);
    }
    if (groups.size > 1)
        return { refusal: p1DifferentRequestsRefusal(groups.size) };
    const group = needsRequests;
    const oldest = group[0];
    const sourceMessages = group.map(entry => poolMessageFileName(entry.file));
    if (source.kind === 'step') {
        const specified = group.find(entry => matchPoolFile(entry.file, source.file));
        if (!specified)
            return { refusal: `pool/l1 message not found: ${source.file}` };
        if (specified.message.thread !== source.thread) {
            return { refusal: `message thread does not match '${source.thread}'.` };
        }
    }
    const needs = await loadNeeds(moduleName, oldest.message);
    if ('refusal' in needs)
        return needs;
    return {
        moduleName,
        file: oldest.file,
        message: oldest.message,
        sourceMessages,
        needsFile: needs.needsFile,
        needs: needs.needs,
    };
}
export async function writeP1Entry(loaded, now) {
    await clearP1Scratch(loaded.moduleName);
    const messageFile = displayPath(loaded.file);
    const inventory = await readL1Inventory(moduleFile(loaded.moduleName).project, loaded.moduleName);
    const pipeline = createP1Pipeline(loaded.moduleName, loaded.message, messageFile, now, loaded.sourceMessages, displayPath(loaded.needsFile), inventory);
    await writeJson(p1PipelineFile(loaded.moduleName), pipeline);
    return pipeline;
}
function isP1ScratchFolder(folder, moduleName) {
    const root = moduleFolder(moduleName);
    return folder === `${root}/pipeline` || folder.startsWith(`${root}/pipeline/`);
}
function listP1ScratchFiles(moduleName) {
    const base = moduleFile(moduleName);
    const files = mls.stor.files;
    const found = new Map();
    const remember = (info) => {
        found.set(`${info.folder}/${info.shortName}${info.extension}`, info);
    };
    for (const file of Object.values(files)) {
        if (!file || file.project !== base.project || Number(file.level) !== 1 || file.status === 'deleted')
            continue;
        const folder = String(file.folder || '');
        if (!isP1ScratchFolder(folder, moduleName) || !file.shortName)
            continue;
        remember({
            project: base.project,
            level: 1,
            folder,
            shortName: String(file.shortName),
            extension: String(file.extension || ''),
        });
    }
    const listFolder = hostListFolder();
    if (listFolder) {
        const folders = new Set([`${moduleFolder(moduleName)}/pipeline`]);
        for (const info of found.values())
            folders.add(info.folder);
        for (const folder of folders) {
            for (const info of listFolder(base.project, 1, folder)) {
                if (!info.shortName)
                    continue;
                const key = mls.stor.getKeyToFile(info);
                const indexed = files[key];
                if (indexed?.status === 'deleted')
                    continue;
                if (!indexed)
                    files[key] = diskFileInfo(info);
                remember({
                    project: base.project,
                    level: 1,
                    folder,
                    shortName: String(info.shortName),
                    extension: String(info.extension || ''),
                });
            }
        }
    }
    return [...found.values()];
}
async function clearP1Scratch(moduleName) {
    const files = listP1ScratchFiles(moduleName);
    if (!files.length)
        return;
    const { deleteFile } = await import('/_102027_/l2/libStor.js');
    for (const file of files) {
        await deleteFile(diskFileInfo(file));
    }
}
export async function executeP1Entry(source, now) {
    const loaded = await loadP1Entry(source);
    if ('refusal' in loaded)
        return loaded;
    const pipeline = await writeP1Entry(loaded, now);
    return { pipeline, file: loaded.file, message: loaded.message };
}
export async function readP1Pipeline(moduleName) {
    return readJson(p1PipelineFile(moduleName));
}
/** `l1/<module>/pipeline/<stepId>-draft.json` in the project of the run. */
export function p1DraftFile(moduleName, stepId) {
    const base = moduleFile(moduleName);
    return {
        project: base.project,
        level: 1,
        folder: `${base.folder}/pipeline`,
        shortName: `${stepId}-draft`,
        extension: '.json',
    };
}
/** Files of this agent (prompt.md, skills) live in 102021, not in the run module. */
export function p1AgentFile(folder, shortName, extension) {
    return {
        project: 102021,
        level: 2,
        folder: folder ? `agentPlannerL1/${folder}` : 'agentPlannerL1',
        shortName,
        extension,
    };
}
export async function readP1AgentText(folder, shortName, extension) {
    const fileInfo = p1AgentFile(folder, shortName, extension);
    const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)];
    if (!file || file.status === 'deleted') {
        throw new Error(`agentPlannerL1 file not found: ${displayPath(fileInfo)}`);
    }
    if (file.getValueInfo) {
        try {
            const local = await file.getValueInfo();
            if (typeof local?.content === 'string')
                return local.content;
        }
        catch { /* fall through */ }
    }
    const content = await file.getContent();
    if (typeof content === 'string')
        return content;
    throw new Error(`agentPlannerL1 invalid text file: ${displayPath(fileInfo)}`);
}
/** `complete` = every step of `flow.json` is approved. A failed pipeline stays failed. */
export function markP1Complete(pipeline, now = new Date().toISOString()) {
    if (pipeline.status === 'failed')
        return pipeline;
    for (const stepId of P1_FLOW_STEP_IDS) {
        if (pipeline.steps[stepId]?.status !== 'approved')
            return pipeline;
    }
    return {
        ...pipeline,
        status: 'complete',
        awaitingStep: undefined,
        updatedAt: now,
    };
}
export function markP1Step(pipeline, stepId, next) {
    const current = pipeline.steps[stepId];
    if (current?.status === 'approved') {
        return { ...pipeline, updatedAt: next.updatedAt };
    }
    const failed = next.status === 'failed';
    const approved = next.status === 'approved';
    return {
        ...pipeline,
        steps: { ...pipeline.steps, [stepId]: next },
        updatedAt: next.updatedAt,
        ...(failed ? { status: 'failed', awaitingStep: undefined } : {}),
        ...(approved && pipeline.awaitingStep === stepId
            ? { status: 'inProgress', awaitingStep: undefined }
            : {}),
    };
}
export function createP1RetryStep(stepId, moduleName, kind, attempt, extra = {}) {
    const planId = `${stepId}-${kind}-${attempt}`;
    const suffix = kind === 'repair' ? `R${attempt}` : `T${attempt}`;
    return {
        type: 'agent',
        stepId: 0,
        interaction: null,
        stepTitle: `${P1_STEP_TITLES[stepId]} · ${suffix}`,
        status: 'waiting_human_input',
        nextSteps: [],
        agentName: P1_AGENT_NAME,
        prompt: JSON.stringify({ planId: stepId, moduleName, [`${kind}Attempt`]: attempt, ...extra }),
        rags: [],
        planning: {
            planId,
            dependsOn: [],
            executionMode: 'sequential',
            executionHost: 'client',
        },
    };
}
