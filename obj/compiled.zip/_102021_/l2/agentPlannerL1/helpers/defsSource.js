/// <mls fileReference="_102021_/l2/agentPlannerL1/helpers/defsSource.ts" enhancement="_blank"/>
// The kinds a l4 ontology may DECLARE. `external` is never declared: it is derived from
// `storage.target`, so keeping it out of this list also keeps a typo'd `kind: "external"` falling back
// to `core` instead of silently erasing an entity's persistence.
const ENTITY_KINDS = ['core', 'supporting', 'event', 'metric', 'mdm'];
/**
 * MDM WRITE PATH — off until the general rebuild.
 *
 * The l4 already declares the intention this switch honours (`storage.target: mdm | external |
 * moduleDatabase`, `storage.mdmType`, v6 vocabulary), so reading it is not a new-vocabulary migration:
 * it would change the classification of the module Wagner is testing (run 9 of buildFlowFsm, where
 * Client/Project/InventoryItem carry `target: mdm` and FieldWorker/PlatformUser carry `target:
 * external`) the moment the next generation runs. That is exactly what the ⏸️ of the spec forbids.
 *
 * Flipping this to `true` moves four things at once, which is why it is one constant and not four:
 *   1. `classifyEntityKind` stops mapping `mdm + moduleOwned` to `core` and starts honouring
 *      `storage.target` — so an MDM entity gets no local domain entity, port, adapter or table, and an
 *      `external` one gets none of those and no seeds either;
 *   2. the seed planner routes those entities to `mdmEntities` (102034 registry) instead of
 *      `localTables`, and drops `external` entities from the plan entirely;
 *   3. the usecase item carries `mdmWrites` (mdmType + subtype + idField), so create/update/delete of
 *      master data is generated against `ctx.mdm` — the surface skills/applicationUsecase.md already
 *      documents — instead of a local port;
 *   4. validate-all blocks on a local persistence/port/domain artifact for an MDM entity instead of
 *      only warning about it (`collectPersistencePolicyIssues`).
 *
 * The order of the general rebuild is in the spec: ns4 vocabulary first (`party`, `platformUserId`),
 * then this flag, then `/rebuild all`.
 *
 * FLIPPED ON 2026-08-24 by Wagner's decision, with the next run being a `/rebuild all`. The two
 * prerequisites above were already met. Note what the flip does NOT do: it changes how the NEXT
 * generation classifies entities, so a module generated while it was `false` keeps its local tables
 * until it is rebuilt. There is no partial reversal — a module is generated in one shape or the other.
 */
export const MDM_WRITE_PATH_ENABLED = true;
export function readEntityStorage(parsed) {
    const raw = parsed.storage;
    const storage = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const str = (value) => (typeof value === 'string' ? value.trim() : '');
    return {
        target: str(storage.target),
        scope: str(storage.scope),
        mdmType: str(storage.mdmType),
        idField: str(storage.idField),
    };
}
/** Schema string the NS E4 emits for ontology v7 (`n04`, 2026-09-08). */
export const CB_ONTOLOGY_SCHEMA_V7 = '2026-09-08-ns4-ontology-v7';
/** Named scan error when a v7 entity omits `storage.idField`. Never fall back to a name suffix. */
export const CB_SCAN_ID_FIELD_REQUIRED = 'CB_SCAN_ID_FIELD_REQUIRED';
function readTrimmed(value) {
    return typeof value === 'string' ? value.trim() : '';
}
function isPlainRecord(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
}
/**
 * l4 ontology schema generation. v7 carries `mdmSubtype` / `role` / `displayField` / required
 * `storage.idField`. Anything older is v6 and is read until the module is regenerated (2026-09-08).
 */
export function ontologyDefsVersion(parsed) {
    const version = readTrimmed(parsed.schemaVersion);
    if (version.includes('ontology-v7') || version === CB_ONTOLOGY_SCHEMA_V7)
        return 7;
    if (readTrimmed(parsed.mdmSubtype) || readTrimmed(parsed.displayField))
        return 7;
    return 6;
}
/** Bare string = actor. Time states are computed on read and never persisted by default. */
export function readLifecycleStates(value) {
    if (!Array.isArray(value))
        return [];
    const seen = new Set();
    const out = [];
    for (const item of value) {
        let state = '';
        let reachedBy = 'actor';
        let ruleRef = '';
        if (typeof item === 'string')
            state = item.trim();
        else if (isPlainRecord(item)) {
            state = readTrimmed(item.state);
            if (item.reachedBy === 'command' || item.reachedBy === 'time')
                reachedBy = item.reachedBy;
            ruleRef = readTrimmed(item.ruleRef);
        }
        if (!state || seen.has(state))
            continue;
        seen.add(state);
        out.push({ state, reachedBy, ...(ruleRef ? { ruleRef } : {}) });
    }
    return out;
}
/**
 * v7 fields on an ontology entity. v6 modules keep compiling: missing `mdmSubtype`/`role`/
 * `displayField` are empty strings, and a missing `idField` is not a scan error until v7.
 */
export function readOntologyEntity(parsed) {
    const storage = readEntityStorage(parsed);
    const defsVersion = ontologyDefsVersion(parsed);
    const mdmSubtype = readTrimmed(parsed.mdmSubtype);
    const role = readTrimmed(parsed.role) || storage.mdmType;
    const displayField = readTrimmed(parsed.displayField);
    const entityId = readTrimmed(parsed.entityId) || '<entity>';
    if (defsVersion >= 7 && !storage.idField) {
        return {
            storage, mdmSubtype, role, displayField, defsVersion,
            scanError: {
                code: CB_SCAN_ID_FIELD_REQUIRED,
                message: `${CB_SCAN_ID_FIELD_REQUIRED}: entity '${entityId}' has no storage.idField`,
            },
        };
    }
    return { storage, mdmSubtype, role, displayField, defsVersion };
}
function readFieldIds(value) {
    if (!Array.isArray(value))
        return [];
    return value.map(readTrimmed).filter(Boolean);
}
/** `ontology/index.defs.ts` `relationships[]` — the only FK source on v7. */
export function readOntologyRelationships(index) {
    const rels = Array.isArray(index.relationships) ? index.relationships : [];
    const out = [];
    for (const rel of rels) {
        if (!isPlainRecord(rel))
            continue;
        const fromEntity = readTrimmed(rel.fromEntity);
        const toEntity = readTrimmed(rel.toEntity);
        if (!fromEntity || !toEntity)
            continue;
        const persistence = isPlainRecord(rel.persistence) ? rel.persistence : {};
        const realization = isPlainRecord(rel.realization) ? rel.realization : {};
        const from = isPlainRecord(realization.from) ? realization.from : {};
        const to = isPlainRecord(realization.to) ? realization.to : {};
        out.push({
            fromEntity,
            toEntity,
            type: readTrimmed(rel.type) || 'manyToOne',
            persistenceMode: readTrimmed(persistence.mode),
            fromFieldIds: readFieldIds(from.fieldIds),
            toFieldIds: readFieldIds(to.fieldIds),
        });
    }
    return out;
}
/** Foreign-key field ids declared for `entityId` on either end of a relationship. */
export function fkFieldIdsForEntity(entityId, relationships) {
    const ids = new Set();
    for (const rel of relationships) {
        if (rel.fromEntity === entityId)
            for (const fieldId of rel.fromFieldIds ?? [])
                if (fieldId)
                    ids.add(fieldId);
        if (rel.toEntity === entityId)
            for (const fieldId of rel.toFieldIds ?? [])
                if (fieldId)
                    ids.add(fieldId);
    }
    return ids;
}
/** A declaration that contradicts itself, for the scan to announce instead of resolving in silence. */
export function contradictoryStorageDeclaration(input) {
    const target = input.storage?.target || '';
    const ownership = input.ownership || '';
    if (target === 'mdm' && ownership === 'external') {
        return `declares storage.target 'mdm' with ownership 'external' (undefined by the policy) — read as 'external', so it gets no MDM record`;
    }
    if (target === 'external' && input.kind === 'mdm') {
        return "declares kind 'mdm' with storage.target 'external' — read as 'external', so it gets no MDM record";
    }
    return '';
}
export function classifyEntityKind(input, mdmWritePath = MDM_WRITE_PATH_ENABLED) {
    const ownership = input.ownership || '';
    const target = input.storage?.target || '';
    // Independent of the MDM write path: the l4 says the record is COMPUTED (no table, no seeds).
    // Flag-off used to map `projection + derived` to `metric`, which DOES get a table — run03 emitted
    // InstitutionalHome/PendingItem persistence and died on an empty primaryKey.
    if (target === 'derived')
        return 'derived';
    if (!mdmWritePath)
        return entityKindOf(input.kind, ownership);
    if (target === 'external' || ownership === 'external')
        return 'external';
    // `target: mdm` + `ownership: external` is undefined by the policy — the same hole `core + external`
    // was (ajustesMDM.md item 2). It cannot reach here (external wins above), which is why the CALLER is
    // told to announce it instead of the entity silently leaving MDM.
    if (target === 'mdm')
        return 'mdm';
    if (input.kind === 'projection')
        return 'metric';
    return ENTITY_KINDS.includes(input.kind) ? input.kind : 'core';
}
/** The cut points of the exported value, in the order they should be tried. */
function valueBounds(content) {
    const start = content.indexOf('= ');
    if (start === -1)
        return [];
    const first = content.indexOf(' as const', start);
    const last = content.lastIndexOf(' as const');
    // The first cut wins for a file that appends a second export (saveDefs writes `pipeline` after the
    // value); the last is the fallback for a value that happens to contain the words.
    const ends = first === last ? [first] : [first, last];
    return ends.filter(end => end > start).map(end => [start + 2, end]);
}
export function parseDefsSource(content) {
    for (const [from, to] of valueBounds(content)) {
        try {
            return JSON.parse(content.slice(from, to));
        }
        catch { /* try the other cut */ }
    }
    return null;
}
/**
 * Replace only the value of a defs file, keeping everything the generator wrote around it — the
 * header, the `import type`, the `satisfies` and the trailing exports. The todo files belong to the
 * generator that emitted them; this agent only flips a status inside them.
 */
export function replaceDefsValue(content, value) {
    for (const [from, to] of valueBounds(content)) {
        try {
            JSON.parse(content.slice(from, to));
        }
        catch {
            continue;
        }
        return `${content.slice(0, from)}${JSON.stringify(value, null, 2)}${content.slice(to)}`;
    }
    return null;
}
/**
 * The handler vocabulary is `query | command`, but `operation.kind` speaks the generator's dialect:
 * ns/ns3 said create|update|query|view, ns4 says list|getById|create|update|delete|transition|
 * commandInput. Only reads are queries; everything else writes.
 */
export function handlerKindOf(opKind) {
    return ['query', 'view', 'list', 'getById'].includes(opKind) ? 'query' : 'command';
}
/**
 * ns4 classifies a read-model as `projection`, which is what `metric` already meant here: not an
 * aggregate root by itself, but still backed by a table and seeds WHEN an operation reads it (that
 * is how a dashboard answers at runtime). Casting it silently would land on `core` and give a
 * projection nobody queries a table of its own.
 *
 * `mdm` means two different things in the two vocabularies, and the difference is the OWNERSHIP:
 * here it has always meant "master data read by id through 102034 — no local table, no port, never
 * written locally", while ns4 writes `mdm` + `ownership: moduleOwned` for master data THIS MODULE
 * owns and publishes, and compiles create/update/delete over it. Read as external, those operations
 * have nowhere to live: run 8 of buildFlowFsm generated 4 stub usecases (`functions: []`) for
 * Client/InventoryItem/Project and the final gate failed with 12 "export not found". Owned master
 * data is a local aggregate — table, port, CRUD, seeds — which is exactly `core`.
 */
export function entityKindOf(kind, ownership = '') {
    if (kind === 'projection')
        return 'metric';
    if (kind === 'mdm' && ownership === 'moduleOwned')
        return 'core';
    return ENTITY_KINDS.includes(kind) ? kind : 'core';
}
/** A ns4 workflow: the lifecycle of one entity, with states and transitions and no operations. */
export function isEntityLifecycle(parsed) {
    return typeof parsed.entityRef === 'string' && !!parsed.entityRef.trim()
        && Array.isArray(parsed.states) && Array.isArray(parsed.transitions);
}
/**
 * The module a `TS2792 Cannot find module '<path>'` names, or '' for any other diagnostic.
 *
 * A generated file that imports a platform contract of another project (`/_102034_/l1/...`) compiles
 * against a Monaco model this agent borrows for the compile. When the borrow silently fails the
 * diagnostic is indistinguishable from a real broken import — and the seed run of 2026-08-16 died on
 * one, after two earlier waves had compiled the very same file. Recognizing the shape is what lets
 * the caller ask "does this file actually exist?" instead of blaming the plan.
 */
export function phantomModulePathOf(diagnostic) {
    if (!/TS2792/.test(diagnostic))
        return '';
    const match = /Cannot find module ['"]([^'"]+)['"]/.exec(diagnostic);
    const path = match?.[1] || '';
    return /^\/_\d+_\/l\d+\//.test(path) ? path : '';
}
/** `/_102034_/l1/server/.../contracts.js` -> the file coordinates of its source. */
export function mlsImportPathParts(path) {
    const match = /^\/_(\d+)_\/l(\d+)\/(.+)$/.exec(path);
    if (!match)
        return null;
    const rest = match[3].replace(/\.js$/, '');
    const cut = rest.lastIndexOf('/');
    if (cut <= 0)
        return null;
    return { project: Number(match[1]), level: Number(match[2]), folder: rest.slice(0, cut), shortName: rest.slice(cut + 1) };
}
/**
 * The cross-project module a resolution diagnostic names, whatever the compiler called it
 * (TS2792 "cannot find module … did you mean to set moduleResolution", TS2307 "cannot find module").
 *
 * Used where the file under compile is written by THIS agent from a fixed template — the seeds. There
 * the import is not a claim the LLM made (it only plans data rows), so a module that does not resolve
 * is an environment fact, and asking `mls.stor.files` whether the target exists measures the wrong
 * thing: it measures whether the session indexed the other project, not whether the plan is wrong.
 */
export function aliasModuleResolutionPathOf(diagnostic) {
    if (!/TS(?:2792|2307)/.test(diagnostic))
        return '';
    const match = /Cannot find module ['"]([^'"]+)['"]/.exec(diagnostic);
    const path = match?.[1] || '';
    return /^\/_\d+_\/l\d+\//.test(path) ? path : '';
}
/**
 * Monaco's "model already exists" — raised by `addModels` for a file whose model IS loaded, under a
 * registry key this agent's guard does not compute. The goal of the call (a usable model) is already
 * met, so the caller treats it as success; reading it as a failure logged the same warning forever
 * and left the import unborrowed.
 */
export function isModelAlreadyExistsError(message) {
    return /model already exists/iu.test(message);
}
// ── todoBackend dialect + read-back comparator ────────────────────────────────
/**
 * The generator names the unit of backend work in its own vocabulary. ns4 calls it `useCase` and
 * stores the status in `statusBackend`; ns/ns3 called it `operation` with `status`. The ids are the
 * same operation ids either way, so the alias is a translation, never a second owner model.
 */
const TODO_OWNER_TYPE_ALIASES = { operation: 'operation', workflow: 'workflow', useCase: 'operation' };
const TODO_STATUS_FIELDS = ['status', 'statusBackend'];
export function todoOwnerType(raw) {
    return TODO_OWNER_TYPE_ALIASES[raw] || '';
}
/** The field the file actually uses, so the write-back lands where the read came from. */
export function todoStatusField(raw) {
    return TODO_STATUS_FIELDS.find(field => typeof raw[field] === 'string') || '';
}
/** The key both sides of a read-back agree on: the owner kind AFTER the dialect alias, plus its id. */
export function todoOwnerKey(kind, id) {
    return `${kind}:${id}`;
}
/**
 * Compare the statuses a run BELIEVES it wrote against the ones a todoBackend source actually carries.
 * Pure on purpose: this is the comparator behind the finalize read-back, and it has to be testable
 * without a stor, a model or a browser.
 *
 * Returns `null` when the source cannot be parsed at all — for the caller that is not "no divergence",
 * it is "unreadable", which is its own kind of failure.
 */
export function todoStatusDivergences(content, expected) {
    const parsed = parseDefsSource(content);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
        return null;
    const owners = parsed.owners;
    if (!Array.isArray(owners))
        return null;
    const found = new Map();
    for (const raw of owners) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw))
            continue;
        const record = raw;
        const kind = todoOwnerType(typeof record.ownerType === 'string' ? record.ownerType : '');
        const id = typeof record.ownerId === 'string' ? record.ownerId : '';
        if (!kind || !id)
            continue;
        const field = todoStatusField(record);
        found.set(todoOwnerKey(kind, id), field ? String(record[field]) : '<missing>');
    }
    const divergences = [];
    for (const [key, want] of expected) {
        const got = found.get(key) ?? '<missing>';
        if (got !== want)
            divergences.push({ key, expected: want, found: got });
    }
    return divergences;
}
export function pickTodoBackendReadBack(folders, moduleName = '') {
    const refOf = (folder) => `l5/${folder}/todoBackend.defs.ts`;
    if (!moduleName) {
        const folder = folders[0];
        return folder !== undefined ? { kind: 'file', folder, ref: refOf(folder) } : { kind: 'none' };
    }
    for (const folder of folders) {
        if (folder === moduleName)
            return { kind: 'file', folder, ref: refOf(folder) };
    }
    return folders.length === 0 ? { kind: 'none' } : { kind: 'module-missing', moduleName, ref: refOf(moduleName) };
}
/**
 * Which l5 todoBackend file a status write should mutate. Prefer the file whose folder is the
 * owner's module; if that file exists but does not contain the owner, do NOT fall through to
 * another module (shared ids like `createTask` would corrupt the neighbour). Empty moduleName
 * keeps the historical search-by-owner-identity.
 */
export function selectTodoBackendFileForStatusWrite(files, owner) {
    const moduleName = String(owner.moduleName || '');
    for (const file of files) {
        if (moduleName && file.folder !== moduleName)
            continue;
        const parsed = parseDefsSource(file.content);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
            continue;
        const owners = Array.isArray(parsed.owners)
            ? parsed.owners
            : [];
        const found = owners.some(raw => {
            if (!raw || typeof raw !== 'object' || Array.isArray(raw))
                return false;
            const rec = raw;
            const kind = todoOwnerType(typeof rec.ownerType === 'string' ? rec.ownerType : '');
            const id = typeof rec.ownerId === 'string' ? rec.ownerId : '';
            return kind === owner.kind && id === owner.id;
        });
        if (found)
            return file;
        if (moduleName)
            return undefined;
    }
    return undefined;
}
/**
 * Absent (not empty) when the operation carries no `mdm` block — the l4s that predate the block must
 * produce byte-identical owners, which is what makes this readable without touching the write-path flag.
 */
export function readOwnerMdm(parsed) {
    const raw = parsed.mdm;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        return undefined;
    const record = raw;
    const str = (key) => (typeof record[key] === 'string' ? record[key] : '');
    const mdm = {
        ...(str('lifecycle') ? { lifecycle: str('lifecycle') } : {}),
        ...(str('activeFilterInput') ? { activeFilterInput: str('activeFilterInput') } : {}),
        ...(str('situationOutput') ? { situationOutput: str('situationOutput') } : {}),
    };
    return Object.keys(mdm).length ? mdm : undefined;
}
/** Is this the cadastral pair (as opposed to an ordinary MDM update)? */
export function isMdmLifecycle(mdm) {
    return mdm?.lifecycle === 'inactivate' || mdm?.lifecycle === 'reactivate';
}
/**
 * Pin the l4 `mdm` block onto the usecase defs the model just returned. The model implements the
 * body; this block is not its to invent or drop. Without the pin, `saveDefs` writes the model
 * output and `collectMdmLifecycleIssues` (which reads `data.mdm` of that defs) stays blind — three
 * petShop runs in a row emitted no-op lifecycles with the agent already correct in the build.
 */
export function pinUsecaseL4Mdm(result, ownerMdm) {
    if (ownerMdm)
        result.mdm = ownerMdm;
    else
        delete result.mdm;
}
/**
 * The one input the l4 CANNOT declare. `mdm.activeFilterInput` names a boolean flag (`includeInactive`)
 * that opts into seeing inactive records, but the ns4 gate requires every input `fieldRef` to resolve to
 * a real ontology field — and `includeInactive` is not a field of anything. Measured on the evidence:
 * `listCustomer.defs.ts` declares `activeFilterInput: 'includeInactive'` with `inputs: []`.
 *
 * So the CB materializes it here, at the SINGLE place owners are read, instead of only in the usecase
 * prompt: the http controller derives its boundary contract from `owner.inputs` too, and an input the
 * controller never learned about is a flag the caller cannot pass.
 *
 * `required: false` on purpose — the default behaviour is active-only, and a required flag would make
 * every existing caller of the list illegal.
 */
export function synthesizeMdmInputs(inputs, mdm) {
    const name = mdm?.activeFilterInput || '';
    if (!name || inputs.some(input => input.inputId === name))
        return inputs;
    return [...inputs, {
            inputId: name,
            fieldRef: '',
            type: 'boolean',
            required: false,
            source: 'userInput',
            description: 'Include records inactivated in the MDM index (default: only active ones).',
        }];
}
