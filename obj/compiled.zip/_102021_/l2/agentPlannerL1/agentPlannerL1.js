/// <mls fileReference="_102021_/l2/agentPlannerL1/agentPlannerL1.ts" enhancement="_102027_/l2/enhancementAgent"/>
import { displayPath, setModuleRoot } from '/_102035_/l2/solution/fs.js';
import { P1_AGENT_NAME, buildP1PlannedSteps, isP1StepId, loadP1Entry, moduleTokenOk, parseP1Invocation, p1InvocationRefusal, readP1Pipeline, } from '/_102021_/l2/agentPlannerL1/helpers/p1Core.js';
import { drainWaitingSiblings, hooksFor, markAwaitingStep, p1StatusMessage, planIdOf, updateStatus, } from '/_102021_/l2/agentPlannerL1/helpers/p1Dispatch.js';
import '/_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry.js';
import '/_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan.js';
export function createAgent() {
    return {
        agentName: P1_AGENT_NAME,
        agentProject: 102021,
        agentFolder: 'agentPlannerL1',
        agentDescription: 'L1 planner — backend.json from pool/l1 needs.json and the existing l1 inventory',
        visibility: 'public',
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep,
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const invocation = parseP1Invocation(userPrompt || context.message.content || '');
    const syntax = p1InvocationRefusal(invocation);
    if (syntax) {
        if (invocation.module && moduleTokenOk(invocation.module))
            setModuleRoot(invocation.module, null);
        return statusTask(agent, context, syntax);
    }
    const loaded = await loadP1Entry({
        kind: 'hand',
        moduleName: invocation.module,
        candidate: invocation.candidate,
    });
    if ('refusal' in loaded)
        return statusTask(agent, context, loaded.refusal);
    const entry = {
        thread: loaded.message.thread,
        file: displayPath(loaded.file),
        candidate: invocation.candidate,
    };
    const addMessage = {
        type: 'add-message-ai',
        skipRootLLM: true,
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [
                { type: 'system', content: 'agentPlannerL1 deterministic bootstrap. The root LLM is skipped by AgentIntentAddMessageAI.skipRootLLM.' },
                { type: 'human', content: invocation.module },
            ],
            taskTitle: `plan l1 ${invocation.module}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {
                taskName: 'plannerL1',
                flowName: P1_AGENT_NAME,
                moduleName: invocation.module,
                thread: entry.thread,
                file: entry.file,
                ...(invocation.candidate ? { candidate: invocation.candidate } : {}),
            },
        },
    };
    const steps = buildP1PlannedSteps(invocation.module, entry).map(step => addStepIntent(context, step));
    return [addMessage, ...steps];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId, args || step.prompt);
    if (hooks?.beforePromptStep)
        return hooks.beforePromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isP1StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential, args) {
    const planId = planIdOf(step);
    const hooks = hooksFor(planId, args || step.prompt);
    if (hooks?.afterPromptStep)
        return hooks.afterPromptStep(agent, context, parentStep, step, hookSequential, args);
    if (isP1StepId(planId))
        return notImplemented(context, parentStep, step, hookSequential, planId);
    return [updateStatus(context, parentStep, step, hookSequential, 'completed', 'Root bootstrap completed (no model).')];
}
async function notImplemented(context, parentStep, step, hookSequential, stepId) {
    const moduleName = memoryString(context, 'moduleName') || moduleNameFromPrompt(step);
    if (moduleName) {
        const pipeline = await readP1Pipeline(moduleName);
        if (pipeline)
            await markAwaitingStep(pipeline, stepId);
    }
    const traceMsg = `step ${stepId} not implemented yet`;
    return [
        ...drainWaitingSiblings(context, step, hookSequential, `stopped: awaiting step ${stepId}`, { onlyUnimplemented: true }),
        updateStatus(context, parentStep, step, hookSequential, 'completed', traceMsg),
    ];
}
function addStepIntent(context, step) {
    return {
        type: 'add-step',
        messageId: '',
        threadId: context.message.threadId,
        taskId: '',
        parentStepId: 1,
        step,
    };
}
function statusTask(agent, context, message) {
    const addMessage = p1StatusMessage(agent, context, message);
    const result = {
        type: 'result',
        stepId: 0,
        status: 'completed',
        interaction: null,
        nextSteps: [],
        stepTitle: 'Status',
        result: message,
        planning: { planId: 'status', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
    };
    return [addMessage, addStepIntent(context, result)];
}
function memoryString(context, key) {
    const value = context.task?.iaCompressed?.longMemory?.[key];
    return typeof value === 'string' ? value.trim() : '';
}
function moduleNameFromPrompt(step) {
    try {
        const parsed = JSON.parse(String(step.prompt || '{}'));
        return typeof parsed.moduleName === 'string' ? parsed.moduleName : '';
    }
    catch {
        return '';
    }
}
