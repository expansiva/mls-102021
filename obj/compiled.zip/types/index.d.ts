declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Core" {
    export const D1_FLOW_ID: "agentDefsL1";
    export const D1_FLOW_VERSION: "2026-09-21-d1-flow-v1";
    export const D1_PIPELINE_SCHEMA: "2026-09-21-d1-pipeline-v1";
    export const D1_AGENT_NAME: "agentDefsL1";
    export const D1_FLOW_STEP_IDS: readonly ["entry10", "input20", "resolve25", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export type D1StepId = typeof D1_FLOW_STEP_IDS[number];
    /** Steps that have a hook in this delivery. The flow lists the rest as not implemented. */
    export const D1_IMPLEMENTED_STEP_IDS: readonly ["entry10", "input20", "resolve25", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export const D1_STEP_TITLES: Record<D1StepId, string>;
    /** Dependencies are done-anchors. A draft path must never appear here. */
    export const D1_STEP_DEPENDS_ON: Record<D1StepId, readonly string[]>;
    export const D1_REPAIR_PER_UNIT = 1;
    export const D1_REPAIR_GLOBAL_MAX = 8;
    export const D1_FINALIZE_REPAIR = false;
    export const D1_MAX_PARALLEL = 5;
    export const D1_INTERACTION_CLEANER: "input_output";
    export const D1_CHILDREN_MAY_ADD_STEPS = false;
    export const D1_CHILDREN_MAY_CREATE_TASK = false;
    export const D1_NEVER_DISPATCH: readonly ["agentCbMaterialize", "agentChangeBackend", "agentMaterializeL2"];
    const COMMANDS: readonly ["run", "resume", "help"];
    export type D1Command = typeof COMMANDS[number];
    export const MSG_PATH = "Path must not contain '..'.";
    export const MSG_CANDIDATE_DOTDOT = "Candidate path must not contain '..'.";
    export const MSG_CANDIDATE = "Candidate runs are refused. Nothing was changed.";
    export const MSG_REBUILD = "Rebuild all is refused. Nothing was deleted.";
    export const MSG_ONE_COMMAND = "Pass one command: /run, /resume or /help.";
    export const MSG_USAGE = "Pass @@agentDefsL1 <lowerCamel> /run, /resume or /help.";
    export const MSG_MODULE = "Module name must be lowerCamel (example: stockControl).";
    export const MSG_PROJECT = "Project identity is missing.";
    export const MSG_PROJECT_MISMATCH = "Project identity does not match this task.";
    export interface D1FileInfo {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export type D1PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    export type D1StepStatus = 'running' | 'approved' | 'failed';
    export interface D1StepState {
        status: D1StepStatus;
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
    }
    export interface D1PipelineState {
        schemaVersion: typeof D1_PIPELINE_SCHEMA;
        flowId: typeof D1_FLOW_ID;
        flowVersion: typeof D1_FLOW_VERSION;
        project: number;
        moduleName: string;
        status: D1PipelineStatus;
        awaitingStep?: D1StepId;
        command: 'run' | 'resume';
        steps: Partial<Record<D1StepId, D1StepState>>;
        updatedAt: string;
    }
    export interface D1ParsedInvocation {
        module: string;
        command: D1Command | '';
        refused: string;
    }
    export function isD1StepId(value: string): value is D1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    export function repairAllowed(unitAttempts: number, globalAttempts: number): boolean;
    /** A successor is unlocked only by its done-anchors, never by a draft path. */
    export function successorUnlocked(dependsOn: readonly string[], approvedAnchors: ReadonlySet<string>): boolean;
    export function doneAnchorId(stepId: D1StepId): string;
    export function dynamicPlanId(stepId: D1StepId, kind: 'fanout' | 'worker' | 'repair' | 'barrier', token: string): string;
    /** A parallel child has no planning. Its prompt carries the planId. */
    export function planIdFromPrompt(prompt: string): string;
    /**
     * Maps a child planId back to its step. Done-anchors stay unmatched so they are
     * not dispatched as the step they close.
     */
    export function ownerStepId(planId: string): D1StepId | '';
    export function isDoneAnchor(planId: string): boolean;
    export function assertShortName(shortName: string): void;
    /** Project is part of the path so two modules with the same name do not share a file. */
    export function displayPath(file: D1FileInfo): string;
    /** `l1/<module>/pipeline/agentDefsL1/input.json` — the final inventory, written by resolve25 with the answers (d1_62). */
    export function inputFile(project: number, moduleName: string): D1FileInfo;
    /**
     * `l1/<module>/pipeline/agentDefsL1/input20.json` — the input20 receipt (d1_62): the derivation with its gaps, its
     * problems and the source key. The final `input.json` is written by resolve25.
     */
    export function derivationFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/drafts/<step>.json`. A draft does not approve the step. */
    export function draftFile(project: number, moduleName: string, step: D1StepId): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/resolve25.json` — the resolve25 receipt: one answer per derivation gap (d1_62). */
    export function resolveFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/report.json` — the finalize80 receipt. */
    export function reportFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/pipeline.json` in one project. */
    export function pipelineFile(project: number, moduleName: string): D1FileInfo;
    /**
     * Planner checkpoint, `l4/<module>/pool/l1/pipeline.json` since 27/09 (planning only writes
     * the pool). This agent never writes or removes it.
     */
    export function plannerPipelineFile(project: number, moduleName: string): D1FileInfo;
    export function ownedFolder(moduleName: string): string;
    export function requireProject(value: unknown): number | {
        refusal: string;
    };
    export function parseD1Invocation(value: string): D1ParsedInvocation;
    export function helpText(moduleName: string, project: number): string;
    export function notImplementedTrace(stepId: D1StepId): string;
    export function stoppedTrace(stepId: D1StepId): string;
    export function resumeMissing(moduleName: string, project: number): string;
    export function checkpointConflict(moduleName: string, project: number): string;
    export function checkpointNotIntact(moduleName: string, project: number): string;
    export function unknownPromptField(field: string): string;
    export function unknownPlanId(planId: string): string;
    export interface D1StepPrompt {
        planId: D1StepId;
        moduleName: string;
        project: number;
        command: 'run' | 'resume';
    }
    export type D1ParsedStepPrompt = {
        kind: 'step';
        prompt: D1StepPrompt;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseD1StepPrompt(prompt: string): D1ParsedStepPrompt;
    export function createEntryPipeline(project: number, moduleName: string, now: Date): D1PipelineState;
    export function isIntactCheckpoint(state: D1PipelineState, project: number, moduleName: string): boolean;
    /**
     * Records the first missing step. Does not move the marker forward, does not
     * rewrite an approved step, and does not treat a later callback as progress.
     */
    export function withAwaiting(pipeline: D1PipelineState, stepId: D1StepId, now: string): {
        pipeline: D1PipelineState;
        changed: boolean;
    };
    export function createD1AgentStep(stepId: D1StepId, moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep;
    export function buildD1PlannedSteps(moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep[];
    export function taskProject(context: mls.msg.ExecutionContext): number | null;
    export function taskModule(context: mls.msg.ExecutionContext): string;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Schema" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /** Keys locked to schemas/pipeline-v1.schema.json by the flow contract test. */
    export const PIPELINE_KEYS: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "awaitingStep", "command", "steps", "updatedAt"];
    export const PIPELINE_REQUIRED: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "command", "steps", "updatedAt"];
    export const STEP_STATE_KEYS: readonly ["status", "updatedAt", "artifactPaths", "error"];
    export const PIPELINE_STATUS: readonly ["inProgress", "awaitingStep", "complete", "failed"];
    export const STEP_STATUS: readonly ["running", "approved", "failed"];
    /** Structural gate for the pipeline document. Extra keys are refused, not dropped. */
    export function pipelineIssues(value: unknown): string[];
    export function parsePipelineDocument(raw: string): D1PipelineState | null;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    /** Where this project is read from and saved to. Replaces the `cadastro` blob. */
    export interface ProjectSettingsConfig {
        /** Destination: 'GitHub' | 'GitLab' | 'vm'. Routed by getDefaultDriver in the cfe. */
        driver: string;
        /** >= 3 '/'-separated segments: getMyKeysBranch takes the LAST three as branch/owner/repo. */
        url: string;
        name?: string;
        userAuth?: 'public' | 'private';
    }
    /** Optional cadastro module. It does not decide whether the organization exists. */
    export interface ProjectOnboardingConfig {
        moduleId: string;
        entryPath: string;
        personType: string;
        companyType: string;
        /**
         * Transitional. Prefer `ProjectsConfig.organization.source`.
         * Used only when `organization` itself was omitted. Ignored when that field is set.
         */
        organizationSource?: 'project-file' | 'development-project';
        /** Automatic entry into cadastro. Absent equals true. false keeps provisioning and does not redirect. */
        redirect?: boolean;
    }
    /** Organization identity source. Independent of the cadastro module. Absent `source` means project-file. */
    export interface ProjectOrganizationConfig {
        source?: 'project-file' | 'development-project';
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        clientShell?: ProjectClientShellConfig;
        /** Optional same-origin favicon href (`/…`). Cross-origin values are ignored. */
        favicon?: string;
        /** Destination of this project's source. Read by the runtime login from l5/config.json. */
        projectSettings?: ProjectSettingsConfig;
        /** Declared workspace project ids. Read by cbeLogin.readProjectDependencies. */
        workspaceDependencies?: string[];
        /**
         * Organization identity source. Absent `organization` keeps the transitional onboarding.organizationSource.
         * A valid sites project file still wins over either source.
         */
        organization?: ProjectOrganizationConfig;
        /** Cadastro module tags. Supplied by the module, not fixed in the library. Does not gate organization identity. */
        onboarding?: ProjectOnboardingConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        name?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
        /** Present only when server onboarding is enabled. Paths belong to the client module, not the page being served. */
        onboarding?: {
            entryPath: string;
            moduleBasePath: string;
        };
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
                /** Id of the tab the bar is showing (`app` or `mod-<basePath>`). */
                activeTab: () => string;
                /**
                 * The element hosted by the tab on screen (an HTMLElement; typed unknown like `openTab`): the app region host
                 * for `app`, the element given to `openTab` otherwise. Null while it is not rendered yet. A change of tab is
                 * announced on window as `collab-nav3-tab-change`.
                 */
                activeTabElement?: () => unknown;
                togglePin: (id: string) => void;
                isPinned: (id: string) => boolean;
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     *
     * `clientProjectId` first: it is the workspace's client project, which is what the studio edits.
     * `projectId` is the owner of the SERVED MODULE, so entering through a platform module
     * (monitor/mdm/audit, owned by the master backend) pinned the studio to the master and the client's
     * services never appeared — measured on 102047.collabcodes.com, 23/09/2026.
     * `projectId` stays as the fallback for a server that does not send the new field yet;
     * mls.actualProject is the last resort when the payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /**
         * @deprecated Ignored. Written by a retired agent; molecule tokens (`--ml-*`) are plain keys of
         * `color` / `global` (and `components`) now. Kept optional so an old designSystem.ts still compiles.
         */
        tokenReconciliation?: unknown;
        /**
         * Token values for ONE kind of molecule: molecule tag (`groupentertext--ml-address-field`) → keys,
         * `_dark-<key>` for the dark value. Declared on the molecule's own element, so they win over the
         * `:root` value for that molecule (and what it holds) only.
         */
        components?: Record<string, IKeyValueToken>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `components`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Per-molecule token blocks: `:root <tag> { --key: value; }` for the light keys and
     * `[data-theme="dark"] <tag>, :root.dark <tag> { … }` for the `_dark-` ones. Molecules only READ
     * their tokens, so a declaration on the element wins over the inherited `:root` value. A tag that
     * is not a molecule tag, a malformed key and an empty value are skipped — a bad entry never breaks
     * the stylesheet of the app.
     *
     * @param components - The entry's `components`; absent/empty yields an empty string.
     * @returns The blocks, tags in alphabetical order, or an empty string.
     */
    export function getComponentTokensCss(components?: Record<string, IKeyValueToken>): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
        listenerBound?: true;
    }
}
declare module "_102033_/l2/cbe/studioDraftFiles" {
    export interface DraftDiffFile {
        status: string;
        path: string;
        sha: string | null;
        from?: string;
    }
    export interface DraftFileOp {
        action: 'add' | 'modify' | 'delete';
        path: string;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        sha: string | null;
    }
    export interface DraftFileIdentity {
        project: number;
        level: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    export interface DraftDiffResult {
        head: string;
        /** Commit of main, when the server sent it. */
        main?: string;
        files: DraftDiffFile[];
    }
    /** One editor model of a source file. `.d.ts` has none. */
    export type SourceModelSlot = 'ts' | 'test' | 'html' | 'style' | 'defs';
    export function sourceModelSlot(extension: string): SourceModelSlot | undefined;
    /**
     * Bytes `_checkSameContent` hashes. `.less` drops the token block and trims;
     * every other source file is hashed as stored.
     */
    export function draftContentCrc(text: string, extension: string): string;
    export function rememberSentCrc(file: DraftFileIdentity, crc: string): void;
    export function sentCrcOf(file: DraftFileIdentity): string | undefined;
    /** Window event: the unsaved count may have changed, and no file event fired. 102033 does not import the listener. */
    export const COLLAB_DRAFT_RECOUNT = "collabDraftRecount";
    export interface ICollabDraftRecountDetail {
        project: number;
    }
    export function requestDraftRecount(project: number): void;
    /** Only `enterStudioDraft` opens the hold, before its diff. Other `requestDraftDiff` callers (discard module) never do. */
    export function beginDraftEntrySeed(): void;
    export function draftEntrySeedPending(): boolean;
    /** Seeding finished, saved or failed. The recount is what publishes the cover, once. */
    export function completeDraftEntrySeed(project: number): void;
    /** Window event after a draft restore was accepted. Same name the panel already emits. */
    export const COLLAB_DRAFT_DISCARDED = "collabDraftDiscarded";
    export interface ICollabDraftDiscardedDetail {
        project: number;
        /** Paths restored by this undo. */
        before: string[];
        /** Nothing stays in the diff for those paths. */
        after: string[];
    }
    export function rememberDraftPaths(project: number, paths: readonly string[]): void;
    export function forgetDraftPaths(project: number, paths: readonly string[]): void;
    export function draftPathIsSaved(project: number, path: string): boolean;
    /** A stor row the Save uses to find the draft path a `new` rename should drop. */
    export interface IDraftRenameOriginFile {
        project: number;
        status?: string;
        level?: number;
        folder?: string;
        shortName?: string;
        extension?: string;
        inLocalStorage?: boolean;
        getValueInfo?: () => Promise<{
            originalFolder?: string;
            originalProject?: number;
            originalShortName?: string;
        } | null | undefined>;
    }
    /**
     * Draft path the Save must delete for a `new` file that was renamed after it was saved.
     * The published `renamed` status is left to the driver. A name that was never in the draft
     * is not deleted. A→B→C without a save in the middle drops A, the oldest name still in the draft.
     * A missing, unread, or never-saved origin uses that same older name before giving up.
     */
    export function savedOriginToDrop(file: IDraftRenameOriginFile): Promise<string | undefined>;
    /** Stor row `DriverVm.setContents` treats as a delete. Non-l1/l2/l3 paths stay in the draft. */
    export function deletedDraftFile(project: number, path: string): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        status: 'deleted';
    } | undefined;
    /** True while Discard module is clearing local copies. Those undos must not call the server again. */
    export function draftUndoBrowserOnly(): boolean;
    export function withDraftUndoBrowserOnly<T>(body: () => Promise<T>): Promise<T>;
    export interface IDraftUndoFetchResponse {
        status: number;
        json: () => Promise<unknown>;
    }
    export type DraftUndoFetch = (input: string, init: {
        method: 'POST';
        credentials: 'same-origin';
        headers: {
            'Content-Type': 'application/json';
        };
        body: string;
    }) => Promise<IDraftUndoFetchResponse>;
    /**
     * Paths one Undo sends for a renamed file.
     * A published `renamed` file includes the published name, so that name comes back
     * and the new name leaves. A `new` file includes the saved name only while that
     * name is still in the draft (or the one older name a chain left behind). A name
     * that was never saved is not sent, and a `new` file restores nothing.
     */
    export function undoPathsForDraftFile(file: IDraftRenameOriginFile, currentPath: string, listed: readonly string[]): Promise<string[]>;
    /**
     * One `draftRestorePaths` for every path, then the browser copy, one recount, one preview reload.
     * A rename passes both names (`undoPathsForDraftFile`): the published name comes back and the
     * new name is removed; a `new` file only drops names, because those paths are not on `main`.
     * A server refusal throws before `afterRestore`, so the browser stays as it was.
     */
    export function undoDraftPaths(project: number, slug: string, paths: readonly string[], afterRestore: () => Promise<void>, fetchImpl?: DraftUndoFetch): Promise<void>;
    interface DraftStoredRow {
        versionRef: string;
        status?: string;
        inLocalStorage?: boolean;
        project?: number;
        level?: number;
        shortName?: string;
        folder?: string;
        extension?: string;
        getContent?(): Promise<string | Blob | null>;
        getValueInfo?(): Promise<mls.stor.IFileInfoValue | null | undefined>;
    }
    export interface DraftFilesDeps {
        draftDiff(project: number, slug: string): Promise<DraftDiffResult>;
        hasLocalEdit(project: number, path: string): boolean;
        addOrUpdateFile(info: DraftFileIdentity & {
            versionRef: string;
        }): Promise<unknown>;
        fileKey(info: DraftFileIdentity): string;
        files(): {
            [key: string]: DraftStoredRow;
        };
    }
    export function draftPublishedCommit(): string | undefined;
    /** Keep a non-empty main. An empty value does not wipe a commit already stored. */
    export function rememberDraftMain(main: string): void;
    /** One operation per side of an l1, l2 or l3 diff entry. Anything else is left out. */
    export function draftFileOps(files: DraftDiffFile[]): DraftFileOp[];
    export function requestDraftDiff(project: number, slug: string): Promise<DraftDiffResult>;
    export function applyDraftFiles(project: number, slug: string, deps?: DraftFilesDeps, known?: DraftDiffResult): Promise<{
        added: number;
        changed: number;
        removed: number;
    }>;
}
declare module "_102033_/l2/cbe/studioDraft" {
    export function defaultDraftFor(project: number, defaultDraft?: string): string;
    export function isVmDriver(driver: {
        driverVersion?: string;
    } | null | undefined): boolean;
    export type CollabRunMode = 'studio' | 'production';
    export interface DraftEnterResponse {
        statusCode: number;
        ok: boolean;
        slug?: string;
        head?: string;
        error?: string;
    }
    export interface EnterDraftDeps {
        postExec: (body: {
            action: 'draftEnter';
            project: number;
            draft: string;
        }) => Promise<unknown>;
    }
    export type ServiceWorkerSetModeMessage = {
        action: 'setMode';
        mode: 'production';
    } | {
        action: 'setMode';
        mode: 'studio';
        project: number;
        draft: string;
    };
    export type ServiceWorkerModeMessage = ServiceWorkerSetModeMessage | {
        action: 'getMode';
    };
    export interface ServiceWorkerModeDeps {
        controller?: {
            postMessage: (message: unknown, transfer: Transferable[]) => void;
        };
        MessageChannel: new () => MessageChannel;
        timeoutMs?: number;
    }
    export interface RequestModeChangeDeps {
        project: number;
        resolveDraft: (project: number) => Promise<string>;
        enterDraft: (project: number, slug: string) => Promise<DraftEnterResponse>;
        sendToServiceWorker: (message: ServiceWorkerSetModeMessage) => Promise<unknown>;
        reportError: (message: string) => void;
    }
    /** Token the shell sends with `draftEnter`: `studio.defaultDraft` when it is a slug, otherwise `user`. */
    export function resolveDefaultDraft(project: number, deps: {
        getProjectConf: (project: number) => Promise<{
            studio?: {
                defaultDraft?: string;
            };
        } | null | undefined>;
    }): Promise<string>;
    export function resolveDefaultDraftFromMls(project: number): Promise<string>;
    /**
     * `POST /exec` `{action:'draftEnter', project, draft}`.
     * Same request shape as `studioDraftFiles` `postExec`. The server may not be published yet:
     * callers inject `postExec` (tests pass a fake).
     */
    export function postDraftEnter(body: {
        action: 'draftEnter';
        project: number;
        draft: string;
    }): Promise<unknown>;
    export function enterDraft(project: number, slug: string, deps: EnterDraftDeps): Promise<DraftEnterResponse>;
    /** The page has no service worker in control yet (first visit, or none). An expected state, not a failure. */
    export class ServiceWorkerUnavailableError extends Error {
    }
    /** One round-trip on `ports[0]` (MessageChannel). Reply is the mode state, or `"Error: <cause>"`. */
    export function sendServiceWorkerMode(message: ServiceWorkerModeMessage, deps?: ServiceWorkerModeDeps): Promise<unknown>;
    /** What the service worker last told this tab. Memory only: not storage, not a cookie. */
    export interface CollabModeState {
        mode: CollabRunMode;
        project?: number;
        draft?: string;
    }
    export function modeState(): CollabModeState;
    /** Draft slug while the tab is in studio. Production has none. */
    export function activeDraft(): string | undefined;
    /** Replaces the mirror. A production state keeps no draft slug. */
    export function rememberCollabMode(state: CollabModeState): void;
    /**
     * One service-worker reply applied to the mirror.
     * A failure (`Error`, `"Error: …"`, or an unreadable body) is logged and the tab stays in production.
     */
    export function applyRecordedModeReply(reply: unknown, reportError: (message: string) => void): CollabModeState;
    export interface LoadRecordedModeDeps {
        send: (message: {
            action: 'getMode';
        }) => Promise<unknown>;
        reportError: (message: string) => void;
        /** No service worker in control at boot: logged as a warning and the tab stays in production. */
        reportWarning: (message: string) => void;
        /** When this is false after the reply, a newer mode already won and the mirror is put back. */
        stillCurrent?: () => boolean;
    }
    /** Boot query `{action:'getMode'}` so the tab is born in the mode the service worker stored. */
    export function loadRecordedMode(deps: LoadRecordedModeDeps): Promise<CollabModeState>;
    /**
     * Studio: `draftEnter`, then `{action:'setMode', mode:'studio', project, draft}`.
     * Production: only `{action:'setMode', mode:'production'}`.
     * A service-worker `"Error: …"` leaves the mode unchanged.
     */
    export function requestModeChange(current: CollabRunMode, next: CollabRunMode, deps: RequestModeChangeDeps): Promise<{
        mode: CollabRunMode;
    }>;
    export function readCollabModeNotice(data: unknown): {
        mode: CollabRunMode;
        project?: number;
        draft?: string;
    } | null;
    /**
     * Mode broadcast from the service worker: the mode to show here. The caller applies it locally and
     * must not call `setMode` (that would echo the change back to the service worker).
     */
    export function applyCollabModeNotice(current: CollabRunMode, data: unknown): CollabRunMode;
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    /** One restore for every file. Callers that loop extensions or a folder use this, not one undo per file. */
    export function undoFiles(files: readonly mls.stor.IFileInfo[]): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Stor" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export function readText(file: D1FileInfo): Promise<string | null>;
    export function writeText(file: D1FileInfo, content: string): Promise<void>;
    export function readJson<T>(file: D1FileInfo): Promise<T | null>;
    /** Writes JSON and returns the exact bytes stored. */
    export function writeJson(file: D1FileInfo, value: unknown): Promise<string>;
    /**
     * Removes one file this agent owns. The file identity is the same object a
     * write would use. The planner pipeline and every other folder are refused.
     */
    export function removeOwned(file: D1FileInfo): Promise<void>;
    /**
     * Removes one own product def. A directory is not a file, a `.ts` output is
     * not a def, and this is not `/rebuild all`.
     */
    export function removeDefFile(file: D1FileInfo): Promise<void>;
    /**
     * Removes the accepted implement from `l4/<module>/pool/l1` once it is traced. Any other
     * folder, level or name is refused.
     */
    export function removePoolMessage(file: D1FileInfo): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type D1PipelineState, type D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type D1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type D1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface D1StepHooks {
        beforePromptStep?: D1StepBeforePrompt;
        afterPromptStep?: D1StepAfterPrompt;
    }
    /** Filled by the step module as a side effect. A missing entry is not implemented. */
    export const D1_STEP_HOOKS: Partial<Record<D1StepId, D1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string): D1StepHooks | undefined;
    /**
     * Persists awaitingStep when the marker actually moves. An approved entry10
     * is left untouched. A repeated call does not write.
     */
    export function markAwaitingStep(pipeline: D1PipelineState, stepId: D1StepId, now?: string): Promise<boolean>;
    export function d1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string, memory: Record<string, string>): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
    /**
     * A D1 stop: drains the waiting siblings, then fails the step with the reason.
     * The failed update is last, so the platform sees no active step and pauses
     * the task with the reason instead of closing it as done.
     */
    export function stopStep(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIAgentStep, hookSequential: number, reason: string, opts?: {
        drainTrace?: string;
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/gate" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type EntryDecision = {
        kind: 'record';
        state: D1PipelineState;
    } | {
        kind: 'keep';
    } | {
        kind: 'refusal';
        refusal: string;
    };
    /**
     * Pure entry decision. `keep` writes nothing. A draft on disk is not an input
     * and cannot turn a later step into an approved one.
     */
    export function decideEntry(command: 'run' | 'resume', project: number, moduleName: string, raw: string | null, now: Date): EntryDecision;
}
declare module "_102035_/l2/solution/helpers/ns4ClassicDefs" {
    /**
     * The untyped defs shape of the classic L4 emission, and its reader — PURE, with no storage import.
     * It lives apart from ns4Fs.ts on purpose: ns4Fs pulls in libModel, whose top-level event listener
     * crashes the l2 test stub, and the write/read round trip of these files must stay testable.
     */
    export interface Ns4ClassicDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function ns4ClassicDefsSource(fileInfo: Ns4ClassicDefsFile, exportName: string, value: unknown): string;
    /** Reads a defs file back to its data, exactly as the storage reader does. */
    export function parseNs4ClassicDefsSource<T>(source: string): T | null;
    export function extractNs4ClassicJsonObject(source: string): string;
    /** The single brace/string scanner shared by readers and byte-preserving rewriters. */
    export function scanNs4ClassicJsonObject(source: string): {
        start: number;
        end: number;
    } | null;
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Shape of the level-1 ontology as the solution agents read it. Until ns5_43 these types described files
     * emitted into l4/organization/ontology; that emitter and those files are gone. `level1Catalog.ts`
     * (mls-102035) now derives this shape from l4/ontology/mdm.defs.ts, so these are a READING form and no
     * longer a source.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformEvent {
        eventId: string;
        on: string;
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                services?: readonly string[];
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
        /** Platform events a module may receive with `inbound.from: 'organization'`. No handler in alpha. */
        events?: readonly MdmPlatformEvent[];
    }
}
declare module "_102035_/l2/solution/helpers/organizationTypes" {
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    /**
     * A papel of a module over a level-1 subtype. ns5_43 T4 names the three parts the way the v3 ontology
     * names them (`Ns5OntologyRoleV3`): `subtype` is the MDM subtype, `roleTag` is what `attachRole` writes
     * into `identification.tags`. Registries written before ns5_43 carry `mdmSubtype`/`role` instead; they
     * are read through `ns4RegistryRoleSubtype` / `ns4RegistryRoleTag` and rewritten on the next finalize80.
     */
    export interface Ns4SolutionRegistryRole {
        subtype: string;
        roleTag: string;
        namespace: string;
        /** Legacy spelling of `subtype`, written before ns5_43. Never written again. */
        mdmSubtype?: string;
        /** Legacy spelling of `roleTag`, written before ns5_43. Never written again. */
        role?: string;
    }
    export function ns4RegistryRoleSubtype(role: Ns4SolutionRegistryRole): string;
    export function ns4RegistryRoleTag(role: Ns4SolutionRegistryRole): string;
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    /** Entities this module owns. Siblings read this list instead of opening ontology files. */
    export interface Ns4SolutionRegistryEntity {
        entityId: string;
        /** v2 `kind`, or the v3 `role` / `entity`. */
        kind: string;
        mdmSubtype?: string;
        /** v3 table only: `core | event | supporting`, which v2 carried in `kind` (ns5_43 T4). */
        class?: string;
    }
    /** Outbound events this module publishes. `on` is `Entity.transitionId` or `Entity.create`. */
    export interface Ns4SolutionRegistryEvent {
        eventId: string;
        on: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        entities?: Ns4SolutionRegistryEntity[];
        events?: Ns4SolutionRegistryEvent[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102034_/l1/mdm/defs/ontologyTypes" {
    /**
     * The grammar of the platform ontology — the types `l4/ontology/mdm.defs.ts` is written against, and that
     * `l2/mdm/resolveMdmEntity.ts` and the module ontology of `mls-102035/l2/solution/types.ts` read.
     *
     * A record is `{ id, version, details }`, mirroring `mdm_documents`: `id` and `version` are columns and
     * `details` is the JSONB document, laid out as a map of branches — `identification` (the fields that are
     * also columns of the index table), `base` (common to every subtype), `<subtype>` (exactly one per
     * record), `general` (the organization) and `<moduleId>` (the module namespace). The base is declared
     * ONCE, instead of being repeated in each of the 13 subtypes.
     *
     * Defaults are omitted, not written: `required: false`, `nullable: false`, `title` equal to the id, and
     * the layer — which the branch already gives, since `identification` is a column and every other branch
     * lives in the document.
     *
     * `InferMdmRecord` derives the runtime type of a record from the ontology data, so `tsc` keeps code and
     * ontology on one shape instead of a hand-written interface that drifts.
     */
    /** The scalar forms a field may take. */
    export type MdmScalarKind = 'string' | 'text' | 'integer' | 'number' | 'money' | 'boolean' | 'date' | 'timestamp' | 'uuid';
    export type MdmValueTypeName = 'Address' | 'GeoPoint' | 'PrivacyConsent' | 'ContactSummary';
    export type MdmSubtypeName = 'Person' | 'Company' | 'ContactChannel' | 'Animal' | 'Product' | 'Service' | 'Location' | 'BankAccount' | 'Document' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment';
    /**
     * A field of the closed form. Absent flag = the default; `type` plus its own constraints carry everything,
     * so a constraint is never prose. `of` names a reusable type, `to` a record this one points at — both
     * checked by the compiler because they are unions of the declared names, not `string`.
     */
    export interface MdmDefField {
        type: MdmScalarKind | 'enum' | 'object' | 'record';
        required?: true;
        nullable?: true;
        collection?: true;
        /** A reusable type of `types`. */
        of?: MdmValueTypeName;
        /** Subtypes this field may point at. */
        to?: readonly MdmSubtypeName[];
        /** Closed domain. Plain strings when the label is the code itself. */
        values?: readonly string[];
        /** Inline object. */
        fields?: MdmDefFields;
        maxLength?: number;
        pattern?: string;
        min?: number;
        max?: number;
        default?: string | number | boolean;
        /** On `details` only: the branches the document is split into. */
        groups?: readonly string[];
        unique?: true;
        /** Backed by a real index today (a column of `identification` without it is a column with no index). */
        indexed?: true;
        /** The engine writes it; no form and no tool schema ever asks for it. */
        derived?: true;
        /** A prior read must supply this engine-owned value when a record is written. */
        writePrecondition?: boolean;
        /** Only when it differs from the id. */
        title?: string;
        description?: string;
    }
    export type MdmDefFields = Readonly<Record<string, MdmDefField>>;
    /** Catalog entry. `from`/`to` are subtype names, so a typo is a compile error and not a dead link. */
    export interface MdmDefRelationship {
        type: string;
        title: string;
        description: string;
        from: readonly MdmSubtypeName[];
        to: readonly MdmSubtypeName[];
        bidirectional: boolean;
        /** Values `mdm_relationship.role` accepts for this type. Empty when the type has no meaningful role. */
        roles: readonly string[];
        /** Keys the engine writes on each side's `relationshipRefs`, derived from `mapRelationshipKeys`. */
        compactKeys: {
            from: readonly string[];
            to: readonly string[];
        };
    }
    /**
     * One branch of `details`. `open: true` means the key set is not closed here: `general` is declared by the
     * organization in the project registry, and each module declares its own namespace in its own ontology.
     */
    export interface MdmDefGroup {
        type: 'object';
        owner: 'platform' | 'organization' | 'module';
        description: string;
        fields?: MdmDefFields;
        open?: true;
    }
    /**
     * A subtype carries only its DELTA: its own fields, and the capabilities and rules that are not universal.
     * The ids are plain strings here and are checked against the catalogs of the ontology object itself, in
     * `mdmOntology.test.ts` — the file is one JSON literal, so there is no `keyof typeof` to lean on inside it.
     */
    export interface MdmSubtypeDef {
        title?: string;
        description: string;
        fields: MdmDefFields;
        /** Only what does NOT apply to every subtype. */
        capabilities?: readonly string[];
        /** Only what does NOT apply to every subtype. */
        rules?: readonly string[];
    }
    export interface MdmOntology {
        schemaVersion: string;
        /** The three columns of `mdm_documents`, as fields, plus what a screen shows to recognise the record. */
        record: {
            fields: MdmDefFields;
            displayField: string;
        };
        types: Readonly<Record<MdmValueTypeName, MdmDefFields>>;
        /** The branches of `details`: `identification`, `base`, `general` and `<moduleId>`. The subtype branch
         * is not here — it comes from `subtypes.<S>.fields`, one per record. */
        groups: Readonly<Record<string, MdmDefGroup>>;
        subtypes: Readonly<Record<MdmSubtypeName, MdmSubtypeDef>>;
        relationships: readonly MdmDefRelationship[];
        /** id → one sentence: what it does · how · who uses it · platform: ready|partial|missing. */
        capabilities: Readonly<Record<string, string>>;
        /** id → one sentence: what is always true · who enforces it · platform. */
        rules: Readonly<Record<string, string>>;
        statuses: readonly string[];
        docTypes: readonly string[];
        storage: {
            indexTable: string;
            prospectIndexTable: string;
            documentTable: string;
            documentColumn: string;
            /** Document-visible columns that carry a real index today. */
            indexedColumns: readonly string[];
            reservedKeys: readonly string[];
        };
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    /**
     * The three families of data, by NATURE, not by origin (`hdm`/`vdm` classify origin and are another
     * axis): `mdm` is the master record of the organization, shared between modules; `tdm` is the movement,
     * the event, the operation of one module; `ddm` is what is recalculated from the other two and has no
     * writer at all.
     */
    export type DataFamilyName = 'mdm' | 'tdm' | 'ddm';
    /** What the platform really offers today for a capability. Measured, never promised. */
    export type DataFamilyReadiness = 'ready' | 'partial' | 'missing';
    /**
     * One capability of a family catalog. `sentence` is the same three-part line the `mdm` catalog writes as
     * prose (what it does · how · who uses it), `platform` the measured status, and `evidence` where it was
     * measured — `file.ts:line` or a section of `l1/mdm/mdmImplementation.md`. `evidence` is for whoever
     * reviews this file; the projection that reaches a prompt drops it.
     */
    export interface DataFamilyCapability {
        sentence: string;
        /** `table`: the module table engine itself. `platform`: lent by an MDM service. */
        source: 'table' | 'platform';
        platform: DataFamilyReadiness;
        evidence: string;
    }
    /**
     * The catalog a table of one family starts from, in the same spirit as `mdm.defs.ts`: the record it
     * carries, the lines the generator should keep in mind while writing it, what it may do, and the gap
     * between this file and the engine. `record.fields` uses the same field grammar as the platform record,
     * so `tsc` checks the shapes here too.
     */
    export interface DataFamilyOntology {
        schemaVersion: string;
        family: DataFamilyName;
        title: string;
        description: string;
        record: {
            fields: MdmDefFields;
        };
        /** One line each, read whole into the fan-out prompt: what this family's table looks like. */
        recommendations: readonly string[];
        capabilities: Readonly<Record<string, DataFamilyCapability>>;
        /** id → one sentence about where and how the rows live. */
        storage: Readonly<Record<string, string>>;
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    type ScalarOf<K extends MdmScalarKind> = K extends 'string' | 'text' | 'date' | 'timestamp' | 'uuid' ? string : K extends 'integer' | 'number' | 'money' ? number : K extends 'boolean' ? boolean : never;
    type DefValue<F extends MdmDefField, O extends MdmOntology> = F extends {
        type: 'enum';
    } ? (F extends {
        values: readonly (infer V)[];
    } ? V : string) : F extends {
        type: 'record';
    } ? string : F extends {
        type: 'object';
    } ? F extends {
        fields: MdmDefFields;
    } ? InferGroup<F['fields'], O> : F extends {
        of: infer V extends MdmValueTypeName;
    } ? InferGroup<O['types'][V], O> : object : F extends {
        type: infer K extends MdmScalarKind;
    } ? ScalarOf<K> : never;
    type DefWrapped<F extends MdmDefField, O extends MdmOntology> = F extends {
        collection: true;
    } ? DefValue<F, O>[] : DefValue<F, O>;
    type DefNulled<F extends MdmDefField, O extends MdmOntology> = F extends {
        nullable: true;
    } ? DefWrapped<F, O> | null : DefWrapped<F, O>;
    type DefRequiredKeys<T extends MdmDefFields> = {
        [K in keyof T]: T[K] extends {
            required: true;
        } ? K : never;
    }[keyof T];
    type DefOptionalKeys<T extends MdmDefFields> = Exclude<keyof T, DefRequiredKeys<T>>;
    /** One group of `details` as a runtime object. */
    export type InferGroup<T extends MdmDefFields, O extends MdmOntology> = {
        [K in DefRequiredKeys<T>]: DefNulled<T[K], O>;
    } & {
        [K in DefOptionalKeys<T>]?: DefNulled<T[K], O>;
    };
    /**
     * The record of one subtype: `{ id, version, details }`, `details` grouped. The subtype group is keyed by
     * the subtype name with a lowercase first letter (`Person` → `person`, `AssetVehicle` → `assetVehicle`),
     * and any other key is a module namespace — an object only that module writes.
     */
    type GroupFields<O extends MdmOntology, K extends string> = O['groups'][K] extends {
        fields: infer F extends MdmDefFields;
    } ? F : MdmDefFields;
    export type InferMdmRecord<O extends MdmOntology, S extends MdmSubtypeName> = {
        id: string;
        version: number;
        details: {
            identification: InferGroup<GroupFields<O, 'identification'>, O>;
        } & {
            base: InferGroup<GroupFields<O, 'base'>, O>;
        } & {
            [K in Uncapitalize<S>]: InferGroup<O['subtypes'][S]['fields'], O>;
        } & {
            general?: object;
        } & {
            [moduleId: string]: object;
        };
    };
}
declare module "_102035_/l2/solution/types" {
    import type { MdmDefField, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    /**
     * p4_20: the read-only view of an artifact type, read only by the `.defs.ts` emitter
     * (`fs.ts` `renderDefsSource`: `as const satisfies Ns5Readonly<T>`). An `as const` literal is
     * read-only all the way down; the Studio compiler (TypeScript 5.0.2) refuses it against a mutable
     * array of `T` (TS1360), 5.9.3 accepts. The value keeps its own `as const` type, so readers of the
     * exported const see no change. The `Ns5*` types themselves stay as they are.
     */
    export type Ns5Readonly<T> = T extends readonly (infer U)[] ? readonly Ns5Readonly<U>[] : T extends object ? {
        readonly [K in keyof T]: Ns5Readonly<T[K]>;
    } : T;
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v2";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-11-ns5-ontology-v2";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_RULES_SCHEMA_VERSION_V2: "2026-09-16-ns5-rules-v2";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-12-ns5-workflows-v2";
    /**
     * ns5_48: v3 adds the `alert` stage (a recurring duty of a person). The shape is a superset of v2,
     * so there is ONE artifact interface and the version is a union — the same move ontology30 made with
     * `NS5_ONTOLOGY_SCHEMA_VERSION_V3`. `workflows50` emits v3; the thirteen recorded runs stay v2 and
     * are replayed through `buildNs5WorkflowsArtifact`.
     */
    export const NS5_WORKFLOWS_SCHEMA_VERSION_V3: "2026-09-17-ns5-workflows-v3";
    export type Ns5WorkflowsSchemaVersion = typeof NS5_WORKFLOWS_SCHEMA_VERSION | typeof NS5_WORKFLOWS_SCHEMA_VERSION_V3;
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-12-ns5-access-v3";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-12-ns5-integration-v2";
    export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION: "2026-09-12-ns5-integration-request-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    /**
     * ns5_49: `workflows50` runs BEFORE `ontology30`. A process stage cites the entity and the transition
     * it makes happen; the ontology then declares them with the stage as owner.
     * ns5_62: `judge35` runs AFTER `ontology30` and BEFORE `rules40`/`access60`. Completeness of the
     * journeys is judged only once the ontology (and the processes) exist. The numeric suffixes are
     * identity, not order — they are frozen so recorded runs keep their step ids.
     */
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "workflows50", "ontology30", "judge35", "rules40", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 copies survivors onto access.defs.ts; finalize80 I3 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    /**
     * access60 actor. `personEntity` is the role record this login is; `''` means this module has
     * none. Optional only so v3 files written before the field still satisfy the type. access60 always
     * writes it. Readers use `personEntity ?? ''`. Absence is not `''` for the gate.
     */
    export interface Ns5AccessActor extends Ns5ModuleActor {
        personEntity?: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, Ns5OntologyDetail>;
    }
    export interface Ns5JourneyStep {
        /** Identity of the step; I6 names a handoff by this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /**
         * Required on `kind: act`. `create` opens the record (or attaches, when mdm);
         * `transition` applies `transitionRef`; `update` writes fields without a state change.
         * Readers: I2, master backend, master frontend.
         */
        effect?: 'create' | 'update' | 'transition';
        /**
         * Required iff `effect === 'transition'`. Ontology `transitionId` of `entity` (lowerCamel).
         * Readers: I2, master backend, master frontend.
         */
        transitionRef?: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
        /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
        icon?: string;
        /**
         * On a branch step, the `stepId` of the `kind: 'decide'` step this branch belongs to.
         * A later step without `decisionRef` is the continuation. journeys20 rejects an unknown or non-decide target.
         */
        decisionRef?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from the pipeline (then access.defs.ts). */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
            icon?: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyDetail {
        /** Typed JSON column and screen formatting. */
        type: Ns5OntologyField['type'];
        /** Planner / UI; rules may cite details.<name>. */
        description: string;
    }
    export interface Ns5OntologyEnumValue {
        /** Stable English lowerCamel code; status.enum.value covers lifecycleStates[].state. */
        value: string;
        /** Screen select/badge label in userLanguage. */
        title: string;
    }
    export interface Ns5OntologyFieldConstraints {
        /** Inclusive lower bound; number, integer or money. */
        min?: number;
        /** Inclusive upper bound; number, integer or money. */
        max?: number;
        /** string or text only. */
        maxLength?: number;
        /** money or number only. */
        precision?: number;
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Simple uniqueness; DDL unique index. Never the identity field. */
        unique?: boolean;
        /** Closed domain; value is the code, title is the screen label. */
        enum?: Ns5OntologyEnumValue[];
        /** Intrinsic to the type (day 1..31, percent 0..100). Never a business policy. */
        constraints?: Ns5OntologyFieldConstraints;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** kind mdm only: level-1 fields this role uses (selection, tightened domain); stores nothing in the module. Readers: f2_04b screen, access60 (ns5_35), masters. */
        fieldsBase?: Ns5OntologyField[];
        /** Composite uniqueness; fieldIds of this entity, never idField. finalize80 I9. */
        uniqueKeys?: string[][];
        /** Calculated values; typed JSON column; rules may cite details.<name>. */
        details?: Record<string, Ns5OntologyDetail>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
        /**
         * How this entity is written. Omitted = `journey` (an `act` writes it as `entity` or `affects`).
         * `crud` = reference catalog nobody creates in a journey (no lifecycle); master
         * frontend emits a data grid, master backend emits CRUD usecases.
         * `inbound` = created/updated by an integration inbound item; integration70 requires
         * a matching `inbound.writes` row. ontology30 normalize drops `crud`/`inbound` when
         * an act already writes the entity. ontology30 / access60 / finalize80 I10 I8.
         * Replaces `maintenance?: 'crud'` (ns5_31).
         */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** Ontology screen edge label; master frontend. One sentence, userLanguage. */
        description: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V3: "2026-09-15-ns5-ontology-v3";
    /**
     * v3.1 (ns5_47): what nobody writes is a `derived` field of the row (`description` says the condition), not a
     * lifecycle state; `time` is therefore gone from `reachedBy` and from `by`. The v3 artifacts already
     * recorded stay readable — the form only lost a way of saying something, so every reader accepts both
     * versions through `isNs5OntologyV3Version` and only the generator emits v3.1.
     */
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V31: "2026-09-17-ns5-ontology-v3.1";
    export type Ns5OntologySchemaVersionV3 = typeof NS5_ONTOLOGY_SCHEMA_VERSION_V3 | typeof NS5_ONTOLOGY_SCHEMA_VERSION_V31;
    /** Every reader of the v3 form asks this, never an equality against one constant. */
    export function isNs5OntologyV3Version(value: unknown): value is Ns5OntologySchemaVersionV3;
    /** Closed-domain value of a v3 field: the bare code, or the code plus its label. */
    export type Ns5OntologyValueV3 = string | {
        value: string;
        title?: string;
        description?: string;
    };
    /** One field of a v3 record. The platform grammar, widened where a module needs it (see above). */
    export interface Ns5OntologyFieldV3 extends Omit<MdmDefField, 'to' | 'values' | 'fields' | 'groups'> {
        /** MDM subtypes AND entity ids of this module. */
        to?: readonly string[];
        values?: readonly Ns5OntologyValueV3[];
        fields?: Ns5OntologyFieldsV3;
        /**
         * Only on a branch of `details`: who writes it. `platform` = the MDM record,
         * `organization` = the promoted layer, `module` = `details.<moduleName>`.
         */
        owner?: 'platform' | 'organization' | 'module';
        /** Only on a branch: the key set is not closed here (declared elsewhere). */
        open?: true;
    }
    export type Ns5OntologyFieldsV3 = Readonly<Record<string, Ns5OntologyFieldV3>>;
    /** One named link of an entity. `relationshipId` is the row of the module index that carries it. */
    export interface Ns5OntologyRelationshipV3 {
        /** Must exist in `index.defs.ts`; that index is the source, this is the reading copy. */
        relationshipId: string;
        /** Entity id of this module, or an MDM subtype. */
        to: string;
        /**
         * `mode: 'fk'` — the column that holds it; `mode: 'throughTable'` — the table walked;
         * absent mode — the MDM relationship type of `mdm.relationships[].type`.
         */
        via: string;
        mode?: 'fk' | 'throughTable';
        /** Which end of the catalog link this entity sits on, when it is not the `from`. */
        direction?: 'from' | 'to';
        /** Role of `mdm_relationship.role`, single or many. */
        role?: string;
        roles?: readonly string[];
        cardinality: '1:1' | '1:N' | 'N:1' | 'N:N';
        /** `true`, or the condition in the user language ("quando menor de 18 anos"). */
        required?: boolean | string;
        /** Walked, never stored. */
        derived?: true;
        /** Only on `throughTable`: the walk, as written. */
        path?: string;
        /** Planner / screen. */
        title: string;
        description?: string;
        /** Narrows the far end, field → accepted values. */
        target?: Readonly<Record<string, readonly string[]>>;
    }
    /** What a `role` and a table share. Exported so `nsArtifactFieldRatchet.test.ts` can reach its keys. */
    export interface Ns5OntologyEntityV3Base<Cap extends string = string, Rule extends string = string> {
        /** Gate: the v3 form. */
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        title: string;
        description: string;
        /** Path a screen shows to recognise the record: `details.identification.name`, `scheduledAt`. */
        displayField: string;
        /** `{ id, version, details }` on a role; plus the indexed columns on an entity. */
        record: {
            fields: Ns5OntologyFieldsV3;
        };
        /** Composite uniqueness, by field id. */
        uniqueKeys?: readonly (readonly string[])[];
        /** ns5_47: only what somebody moves. A condition over data is a `derived` field of the row. */
        lifecycleStates?: readonly {
            state: string;
            reachedBy: 'actor' | 'command';
        }[];
        transitions?: readonly {
            transitionId: string;
            from: readonly string[];
            to: string;
            /** Actor ids of the module; empty when a process owns the move. */
            by: readonly string[];
            description: string;
            /** Record paths the transition command consumes; an explicit empty list means identity only. */
            payload?: readonly string[];
            ruleRefs?: readonly string[];
        }[];
        relationships: Readonly<Record<string, Ns5OntologyRelationshipV3>>;
        /**
         * id → one sentence. A platform id of `mdm.capabilities`, or `<moduleName>.<id>`.
         * Optional per key because an entity picks from the catalog; that `Cap` is an upper bound and not a
         * requirement. Assigning a `const` here therefore does NOT reject an invented id (no excess-property
         * check off a fresh literal) — a reader that wants that proof asserts `Exclude<keyof …, Cap>` is
         * `never`, as `resolveMdmEntity.test.ts` does.
         */
        capabilities: {
            readonly [K in Cap]?: string;
        };
        /** Ids of `mdm.rules` ∪ `ruleId` of the module `rules.defs.ts`. */
        rules: readonly Rule[];
        /** How the entity is written, when it is not a journey. */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    /** A papel of this module over an MDM record. Stores nothing but `details.<moduleName>`. */
    export interface Ns5OntologyRoleV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'role';
        /** The MDM subtype the papel sits on; must be a key of `mdm.subtypes`. */
        subtype: MdmSubtypeName;
        /** `<moduleName>.<entityId>`; what `attachRole` writes into `identification.tags`. */
        roleTag: string;
        /** The platform ontology this papel copies from. */
        source: string;
    }
    /** A table of the module. */
    export interface Ns5OntologyTableV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'entity';
        class: 'core' | 'event' | 'supporting';
        /**
         * `kind` is the family's storage (ns5_46): `relational` is one Postgres table of the module,
         * `timeSeries` a series chunked by time. Optional because the hand-written v3 form predates it and a
         * table without it is read as `relational`.
         */
        storage: {
            target: 'moduleDatabase';
            table: string;
            kind?: 'relational' | 'timeSeries';
        };
        /** What the table starts with in every database, in one sentence (e.g. 'all ISO 3166-1 countries'); absent = no initial data. Test data is not initialData. */
        initialData?: string;
    }
    export type Ns5OntologyEntityV3<Cap extends string = string, Rule extends string = string> = Ns5OntologyRoleV3<Cap, Rule> | Ns5OntologyTableV3<Cap, Rule>;
    /** One row of the v3 index: the canonical list of entities. */
    export interface Ns5OntologyIndexEntityV3 {
        entityId: string;
        kind: 'role' | 'entity';
        /** On `role` only. */
        subtype?: MdmSubtypeName;
        /** On `entity` only. */
        class?: 'core' | 'event' | 'supporting';
    }
    /** One row of the v3 index: the canonical list of links. The entities repeat these for reading. */
    export interface Ns5OntologyIndexRelationshipV3 {
        relationshipId: string;
        from: string;
        to: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        mode: 'fk' | 'mdmRelationship' | 'throughTable';
        /** `mode: 'fk'`: the column, as `Entity.field`. */
        field?: string;
        /** `mode: 'mdmRelationship'`: a `type` of `mdm.relationships`. */
        catalogType?: string;
        /** `mode: 'throughTable'`: the entity walked. */
        through?: string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        description: string;
    }
    export interface Ns5OntologyIndexV3 {
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        businessDomain: string;
        /** Path of the platform ontology this module is written on top of. */
        platformOntology: string;
        /** The branch of `details` only this module writes. */
        moduleNamespace: {
            key: string;
            description: string;
        };
        entities: readonly Ns5OntologyIndexEntityV3[];
        relationships: readonly Ns5OntologyIndexRelationshipV3[];
    }
    /** What a reader gets from an ontology entity file, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5OntologyAnyEntity = Ns5OntologyEntityArtifact | Ns5OntologyEntityV3;
    /** The discriminator every reader of a written entity uses; accepts v3 and v3.1 alike (ns5_47). */
    export function isNs5OntologyEntityV3(entity: Ns5OntologyAnyEntity): entity is Ns5OntologyEntityV3;
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    /**
     * The same catalog as a MAP, aligned with `mls-102034/l4/ontology/mdm.defs.ts`, whose `rules` and
     * `capabilities` are both `Record<id, sentence>` — one id, one sentence, no place to put a second.
     * `rules40` emits this form; the v1 array above stays valid and is still what the recorded runs hold.
     * Read either form through `solution/rulesView.ts`, never by branching on the field.
     *
     * The TOOL still asks for `[{ ruleId, description }]`: a strict tool schema must declare
     * `additionalProperties: false` on every object, so an open key set is not expressible
     * (`steps/ontology30/contractsV3.ts:175` says the same of `record.fields` and `capabilities`).
     * Array to map is the normalize's job.
     */
    export interface Ns5RulesArtifactV2 {
        /** Discriminates the two forms. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION_V2;
        /** Folder. */
        moduleName: string;
        /** `ruleId` to the one business sentence; I4 checks cited ruleRefs exist. */
        rules: Readonly<Record<string, string>>;
    }
    /** What a reader gets from `rules.defs.ts`, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5RulesAny = Ns5RulesArtifact | Ns5RulesArtifactV2;
    export interface Ns5WorkflowTrigger {
        /** Gate: scheduled needs schedule, event needs event, manual needs actorRef. */
        kind: 'scheduled' | 'event' | 'manual';
        /** Required iff kind === 'scheduled'. Prose ("every month, day 1"). Backend job. */
        schedule?: string;
        /** Required iff kind === 'event'. '<Entity>.<transitionId>' of this module (inbound '<mod>.<eventId>' is ns5_31). */
        event?: string;
        /** Required iff kind === 'manual'. */
        actorRef?: string;
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. Unique in the process. */
        taskId: string;
        /**
         * Gate: no neutral value; every stage is one of these. `alert` (v3, ns5_48) is a recurring duty
         * of a person: the schedule is on `trigger`, the instruction is the `description`, and it carries
         * neither journeyRef nor entityRef.
         */
        kind: 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
        /** Required on human and on alert. */
        actorRef?: string;
        /** Required on human, forbidden on alert. The journey the person runs, never a screen step. */
        journeyRef?: string;
        /** Required on mechanical|llm. Entity the stage acts on. */
        entityRef?: string;
        /** Required on mechanical|llm. Same form as act.effect (ns5_28). */
        effect?: 'create' | 'update' | 'transition';
        /** Required iff effect === 'transition'. Ontology transitionId; by is system or the actor. */
        transitionRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. Wait: the pause (time or event) in prose. */
        description: string;
        /** Optional Lucide name (`lucide-static` catalog). Presentation only; absent keeps the screen default. */
        icon?: string;
        /**
         * Whether the process routine asks to be woken while this stage waits (plan §6). Only on kind 'wait'.
         * The routine decides what to do; waking is not a message to a person. Optional only for recorded
         * artifacts; absent → 'none'. `every` is an ISO 8601 duration (PT1H, P1D), required iff mode === 'periodic'.
         */
        wake?: {
            mode: 'none' | 'periodic';
            every?: string;
        };
    }
    export interface Ns5WorkflowFunction {
        /** lowerCamel; unique within the module. */
        functionId: string;
        /** Prose: who calls it (screen, harness, schedule), what it validates, writes, notifies and returns, and what happens on a repeated call. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** How the process starts. Tela da Fase 2, harness, backend job. */
        trigger: Ns5WorkflowTrigger;
        /** finalize80 I6: every journey handoff appears as a human journeyRef. */
        tasks: Ns5WorkflowTask[];
        /** The functions the L1 workflow service implements for this process. Optional only for artifacts saved before functions existed. */
        functions?: Ns5WorkflowFunction[];
        /**
         * Default room of an occurrence, chosen by the module (plan §§5, 9). 'exclusive': one room per occurrence;
         * 'person': the room of the person who owns the occurrence, and only that person enters; 'group': only the
         * members of the group enter. The cm resolves the concrete room and refuses an actor outside the audience.
         * Optional only for artifacts recorded before this spec; readers treat it as absent → 'exclusive'.
         */
        room?: 'exclusive' | 'person' | 'group';
    }
    export interface Ns5JourneyDecision {
        /** Must exist in the journey index. Tela da Fase 2 shows why a journey stayed out. */
        journeyId: string;
        /** One decision per journey in the same LLM call. */
        inProcess: boolean;
        /** Required iff inProcess. */
        processId?: string;
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty processes is valid. v2 recorded on disk stays readable. */
        schemaVersion: Ns5WorkflowsSchemaVersion;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
        /** One row per journey; the screen lists who is in a process. */
        journeyDecisions: Ns5JourneyDecision[];
        /** workflows50 normalize: dropped duplicate stages. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. Unique. */
        grantId: string;
        /** Must be an actorId from access.actors. */
        actorRef: string;
        /** Access matrix screen. */
        title: string;
        /** Access matrix screen. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Pipeline actors plus personEntity. The LLM does not emit this list; access60 merges actorPersons onto it. */
        actors: Ns5AccessActor[];
        /** The grant is the capability. Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. Unique across inbound and outbound. */
        id: string;
        /** Gate vs registry / plugin catalogue / platform events. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** Inbound source: sibling module, `organization` (platform catalog), or external system. */
        from?: string;
        /** Outbound destination: sibling module, `any`, or external system. */
        to?: string;
        /** Event id this row receives (inbound) or publishes (outbound). Defaults to `id`. */
        event?: string;
        /**
         * Inbound: entities of this module the arrival creates/updates.
         * Counts as a writer (ontology30 WITHOUT_WRITER, access60, I10) and as `trigger.event`.
         */
        writes?: string[];
        /** Inbound: what the arrival does to `writes`. Required on inbound. */
        effect?: 'create' | 'update' | 'transition';
        /** Inbound, required iff `effect === 'transition'`. */
        transitionRef?: string;
        /**
         * Outbound: when this module publishes. `Entity.transitionId` or `Entity.create`.
         * Payload is the entity record at that moment (not declared in l4). I12 checks it exists.
         */
        on?: string;
        /** Planner / UI. Cites `inbound.id` when the rule maps a sibling payload. */
        description: string;
        /** Outbound (and inbound leftover): entity ids this row touches. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** `journeyId.stepId` or `processId.taskId` that uses the plugin. I12. */
        usedBy: string[];
    }
    /** Queued request that a sibling (or a predicted module) publish an event. */
    export interface Ns5IntegrationRequestArtifact {
        schemaVersion: typeof NS5_INTEGRATION_REQUEST_SCHEMA_VERSION;
        requestedBy: string;
        eventId: string;
        on?: string;
        entityRefs: string[];
        description: string;
        status: 'requested';
        /** Organization inbox: the predicted module that should publish. */
        to?: string;
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    /** Form change recorded on `pipeline.json` `steps.<step>`. Shape is step-specific. */
    export interface Ns5PipelineNormalization {
        kind: string;
        detail: string;
        entityId?: string;
        grantId?: string;
        journeyId?: string;
        stepId?: string;
        inboundId?: string;
        /** access60 `anchorFromActor`: the anchor the model wrote. */
        from?: string;
        /** access60 `anchorFromActor`: the actor's personEntity. */
        to?: string;
    }
    export interface Ns5PipelineLiftedField {
        entityId: string;
        detail: string;
    }
    /**
     * p4_20: the Studio compile of the `.defs.ts` a step wrote, recorded on `steps.<step>.compile`.
     * `unavailable` is the absence of `mls.l2.typescript` (or of a model/dependency to compile): a state,
     * never a clean compile. Reader: finalize80 (`ns5CompileBlockers`), which runs the oracle only when
     * every writing step recorded `clean`.
     */
    export interface Ns5CompileRecord {
        status: 'clean' | 'errors' | 'unavailable';
        /** How many `.defs.ts` the step asked the compiler about. */
        files: number;
        /** `errors`: one line per diagnostic, prefixed by the display path of the file. */
        errors?: string[];
        /** `unavailable`: why nothing was compiled. */
        reason?: string;
    }
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /**
         * module10: actors the normalize removed because they are external systems, not people
         * (`dropSystemActor<Actor>`). An external system the request names is a plugin or an inbound of
         * integration70, never an actor. The clarification/maintenance screen of Fase 2 reads this to
         * show what the step decided without asking.
         */
        systemDecisions?: Ns5SystemDecision[];
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /**
         * Form changes this step applied (pt→pt-BR, dropCrud, liftedFields, …).
         * Same records as the step draft `normalizations[]`. Fase 2 reads this.
         */
        normalizations?: Ns5PipelineNormalization[];
        /**
         * ontology30: extra fields discarded when a panel entity was lifted
         * (`normalizations[].kind === 'liftedFields'`).
         */
        liftedFields?: Ns5PipelineLiftedField[];
        /**
         * ontology30 v3: rule ids the entities cited, platform and module together. `rules40` receives the
         * module ones as data and has to produce them (ns5_42 T7 records it; ns5_43 T2 wires the reading).
         */
        citedRules?: string[];
        /** ontology30 v3: capability ids the entities cited, catalog and module together. */
        citedCapabilities?: string[];
        /** module10: actors born by the step. Later steps read them via `readNs5Actors`. */
        actors?: Ns5ModuleActor[];
        /** journeys20: actorIds dropped as inferred-external without an exclusive step. */
        droppedActors?: string[];
        /** workflows50: true when processes is [] because there is no handoff, no cross-actor decide and no time/event phrase in the prompt. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
        /** judge35: true when the deterministic candidate list was empty and the step approved without an LLM call. */
        noJudgeSignal?: boolean;
        /** judge35: `transitionUnjustified` verdicts recorded for the human; the transition is not deleted. */
        warnings?: string[];
        /** p4_20: Studio compile of the `.defs.ts` this step wrote. Reader: finalize80. */
        compile?: Ns5CompileRecord;
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module (l1/l2/l4/l5 trees plus l5 json / registry). */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** Display paths unlinked under l1/l2/l4/l5/<module>/. */
        deleted: string[];
        /** Display paths rewritten (l5 jsons and the organization registry). */
        edited: string[];
        at: string;
    }
    /** Mailbox of the module pool: one folder per owner (`l4/<module>/pool/<box>/`). */
    export type PoolBox = 'l1' | 'l2' | 'l4';
    /** Implement = do it; estimate = simulate the change and answer the cost. */
    export type PoolMode = 'implement' | 'estimate';
    /** What the owner did with the message it processed. */
    export type PoolOutcome = 'delivered' | 'processed' | 'disputed';
    /**
     * One processed pool message, appended to `pipeline.json`. Readers: the pool screen (p4_04) and
     * L4 itself (round counting). Helpers in `/_102035_/l2/solution/pool.js`.
     */
    export interface PoolTraceLine {
        /** ISO timestamp of the trace. */
        at: string;
        /** Display path of the message file, e.g. `l4/<module>/pool/l2/<stamp>_<thread>_<round>.json`. */
        file: string;
        from: PoolBox;
        to: PoolBox;
        thread: string;
        round: number;
        mode: PoolMode;
        outcome: PoolOutcome;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /**
         * Thread of the request that created the module (`context.message.threadId`).
         * One per module: `/rebuild all` keeps the value already stored. Token `^[A-Za-z0-9_.-]{1,100}$`.
         */
        messageThreadId?: string;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        /** Pool trace, appended by `tracePool`. Absent in pipelines written before the pool existed. */
        pool?: PoolTraceLine[];
        /**
         * What `agentPlannerL4` entry10 added to `l5/config.json` (reader: that step).
         * Tokens like `workspaceDependencies:+102021`. Absent when nothing was missing.
         */
        l5Adjusted?: string[];
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102035_/l2/solution/helpers/organizationTypes";
}
declare module "_102035_/l2/solution/fs" {
    import type { Ns4SolutionRegistryArtifact } from "_102035_/l2/solution/helpers/organizationTypes";
    import type { Ns5OntologyAnyEntity, Ns5PipelineState, Ns5StepId } from "_102035_/l2/solution/types";
    export type Ns5FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function normalizeModuleName(value: unknown, fallback?: string): string;
    /**
     * Point `moduleFolder` at a root relative to `l4/` (example: `stockControl/tobe/plan`).
     * `null` or `''` restores the canonical folder. Lives on the current `mls` (the task process).
     */
    export function setModuleRoot(moduleName: string, relativeRoot: string | null): void;
    /** Runs `run` and puts every module root back as it was, also when `run` throws: a hook must not leak its root to the next use. */
    export function preserveModuleRoots<T>(run: () => Promise<T>): Promise<T>;
    /** `l4/<mod>` or the `/candidate` override when `setModuleRoot` was called. */
    export function moduleFolder(moduleName: string): string;
    export function moduleFile(moduleName: string): Ns5FileInfo;
    /** Read-only callers such as the Studio module browser must not depend on mls.actualProject. */
    export function moduleFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function journeyFile(moduleName: string, journeyId: string): Ns5FileInfo;
    export function journeyIndexFile(moduleName: string): Ns5FileInfo;
    export function ontologyEntityFile(moduleName: string, entityId: string): Ns5FileInfo;
    export function ontologyIndexFile(moduleName: string): Ns5FileInfo;
    export function rulesFile(moduleName: string): Ns5FileInfo;
    export function workflowsFile(moduleName: string): Ns5FileInfo;
    export function accessFile(moduleName: string): Ns5FileInfo;
    export function integrationFile(moduleName: string): Ns5FileInfo;
    /** `l4/<target>/tobe/integration/<requestedBy>--<eventId>.defs.ts` — no extra dot in shortName. */
    export function integrationRequestFile(targetModule: string, requestedBy: string, eventId: string): Ns5FileInfo;
    export function collectTobeIntegrationFilesCiting(moduleName: string): mls.stor.IFileInfo[];
    export function pipelineFile(moduleName: string): Ns5FileInfo;
    export function pipelineFileForProject(project: number, moduleName: string): Ns5FileInfo;
    /** The pipeline of `l4/<mod>`, whatever root `setModuleRoot` points at. */
    export function canonicalPipelineFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function pipelineJsonFile(moduleName: string, shortName: string): Ns5FileInfo;
    export function pipelineJsonFileForProject(project: number, moduleName: string, shortName: string): Ns5FileInfo;
    export function finalizeReportFile(moduleName: string): Ns5FileInfo;
    export function finalizeReportFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function listPipelineJsonShortNames(moduleName: string): string[];
    export function draftFile(moduleName: string, step: Ns5StepId | string): Ns5FileInfo;
    export function agentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function registryFile(): Ns5FileInfo;
    export function displayPath(fileInfo: Ns5FileInfo): string;
    export function assertShortName(shortName: string): void;
    export function fileExists(fileInfo: Ns5FileInfo): boolean;
    export type Ns5LiveFileRecord = Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        shortName?: string;
        extension?: string;
        status?: string;
        getContent?: () => Promise<unknown>;
    } | undefined>;
    export function liveFiles(files: Ns5LiveFileRecord): NonNullable<Ns5LiveFileRecord[string]>[];
    export function listNs5ModulesFromFiles(files: Ns5LiveFileRecord, project: number): string[];
    export function listNs5Modules(project: number): string[];
    export function listModuleFolders(): Set<string>;
    export function isExactModuleFolder(folder: string, moduleName: string): boolean;
    export const MODULE_TREE_LEVELS: readonly [1, 2, 4, 5];
    export function isProtectedModuleFile(file: {
        level?: number;
        folder?: string;
        shortName?: string;
    }): boolean;
    export function listModuleL4Keys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** Index (`mls.stor.files`) of exact `l<level>/<mod>/**`. Never prefix; never protected paths; never host disk. */
    export function collectExactModuleFiles(moduleName: string, levels?: readonly number[]): mls.stor.IFileInfo[];
    export type Ns5DefsKind = 'journeys' | 'ontology';
    type ListedStorFile = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    /**
     * The `mls.stor.files` entry for `info`, or undefined. The index is the only source the l4 lists,
     * deletes and judges by — it is what the Studio (browser) has; host disk never decides (p4_19).
     */
    export function indexedFile(info: ListedStorFile): mls.stor.IFileInfo | undefined;
    /** shortNames of `.defs.ts` in `l4/<mod>/<kind>/` from the index, including status=deleted; never host disk. */
    export function listModuleDefsShortNames(moduleName: string, kind: Ns5DefsKind): string[];
    export function ns5DefsOrphans(diskShortNames: string[], indexIds: string[]): string[];
    export function reconcileModuleDefs(moduleName: string, kind: Ns5DefsKind, indexIds: string[]): Promise<string[]>;
    export function readJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    export function writeJson(fileInfo: Ns5FileInfo, value: unknown): Promise<string>;
    export function writeDefs(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): Promise<string>;
    export function renderDefsSource(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): string;
    export function readPipeline(moduleName: string): Promise<Ns5PipelineState | null>;
    export function readPipelineForProject(project: number, moduleName: string): Promise<Ns5PipelineState | null>;
    export function writePipeline(state: Ns5PipelineState): Promise<string>;
    export function readAgentText(folder: string, shortName: string, extension?: string): Promise<string>;
    export function readAgentJson<T>(folder: string, shortName: string, extension?: string): Promise<T>;
    export function readDefsJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    /** Preserve the exact L4 source when sealing a release or copying it to the candidate. */
    export function readSourceText(fileInfo: Ns5FileInfo): Promise<string>;
    export function writeSourceText(fileInfo: Ns5FileInfo, source: string): Promise<void>;
    /**
     * An ontology entity file in whichever form it is written (ns5_39 T4). Both forms are one JSON literal,
     * so the reading is the same; only the type of what comes back changes, and `schemaVersion` is the
     * discriminator — v3 (`agendaClinica`) carries `record`, v2 (the other eleven modules) carries `fields`.
     */
    export function readOntologyEntityAny(fileInfo: Ns5FileInfo): Promise<Ns5OntologyAnyEntity | null>;
    export function readSolutionRegistry(): Promise<Ns4SolutionRegistryArtifact | null>;
}
declare module "_102035_/l2/solution/pool" {
    import type { Ns5FileInfo } from "_102035_/l2/solution/fs";
    import type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine } from "_102035_/l2/solution/types";
    export type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine };
    export const POOL_BOXES: readonly ["l1", "l2", "l4"];
    export const POOL_MODES: readonly ["implement", "estimate"];
    export const POOL_OUTCOMES: readonly ["delivered", "processed", "disputed"];
    /** Three rounds per side. At 3/3 without agreement the message is NOT deleted: it becomes a human pending. */
    export const POOL_MAX_ROUND = 3;
    /** The whole message. Nothing is optional; lists may be empty. */
    export interface PoolMessage {
        from: PoolBox;
        to: PoolBox;
        /** `<module>-<yyyymmddhhmmss>` of the message that opened the thread. */
        thread: string;
        /** 1..POOL_MAX_ROUND. */
        round: number;
        mode: PoolMode;
        /** One line. */
        subject: string;
        /** Paths relative to the module folder. */
        artifacts: string[];
        body: string;
    }
    /** `yyyymmddhhmmss` in UTC — the order of the mailbox is the order of the name. */
    export function poolStamp(now: Date): string;
    /** Thread id of a message that opens a conversation about `moduleName`. */
    export function nextThread(moduleName: string, now: Date): string;
    /** Rejects with a named cause; never repairs quietly. */
    export function normalizePoolMessage(value: unknown): PoolMessage;
    /** `l4/<module>/pool/<box>/<shortName>.json`, in the project of the run. */
    export function poolFile(moduleName: string, box: PoolBox, shortName: string): Ns5FileInfo;
    /**
     * Writes the message into the box of `msg.to`. `now` is explicit because the file name carries it
     * and the caller — not the clock — decides which moment the message belongs to.
     */
    export function writePoolMessage(moduleName: string, msg: unknown, now: Date): Promise<Ns5FileInfo>;
    /**
     * `<stamp>_<thread>_<round>`, o nome que o `writePoolMessage` gera. Um `.json` na caixa que não siga
     * isso não é mensagem do pool — a p2_09 põe um `menu.json` ali — e é **ignorado**, não é erro: a caixa
     * é de quem a lê, e nada impede o dono de guardar outro arquivo dentro dela.
     *
     * O padrão fica **frouxo de propósito**: o formato do `thread` e a faixa do `round` são recusados com
     * causa nomeada na leitura (`normalizePoolMessage`), e repeti-los aqui seria a mesma regra em dois
     * lugares. Mais importante: errar para o lado estrito esconderia uma mensagem real da caixa, e caixa
     * que parece vazia faz a guarda de pendência não disparar — é a direção cara do erro.
     */
    export function isPoolMessageShortName(shortName: string): boolean;
    /** Oldest first, by name. Index only (`mls.stor.files`) — what the Studio sees; host disk never adds a message. */
    export function listPoolBoxForProject(project: number, moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function listPoolBox(moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function readPoolMessage(file: Ns5FileInfo): Promise<PoolMessage>;
    /** Any non-empty box — this is what blocks a new `tobe/`. */
    export function poolHasPending(moduleName: string): boolean;
    /**
     * Same normalize and return (`traceId`) as `tracePool`, but writes the line on the
     * `pipeline.json` that `fileInfo` points at — each owner traces on its own file.
     */
    export function tracePoolAt(fileInfo: Ns5FileInfo, line: unknown): Promise<string>;
    /**
     * Appends the line to `pipeline.json` and returns its id — the display path of the message,
     * which is unique per message and is what `deletePoolMessage` demands.
     * Shortcut: traces on the l4 pipeline of `moduleName`.
     */
    export function tracePool(moduleName: string, line: unknown): Promise<string>;
    /** Reads the trace at the given `pipeline.json` (empty when the file has none). */
    export function readPoolTraceAt(fileInfo: Ns5FileInfo): Promise<PoolTraceLine[]>;
    /** Reads the trace of the module (empty when the pipeline has none). */
    export function readPoolTrace(moduleName: string): Promise<PoolTraceLine[]>;
    /**
     * Same check and delete as `deletePoolMessage`, but the trace is read from the `pipeline.json`
     * that `fileInfo` points at — each owner traces (and therefore deletes) on its own file.
     */
    export function deletePoolMessageAt(fileInfo: Ns5FileInfo, file: Ns5FileInfo, traceId: string): Promise<string>;
    /**
     * Last operation of whoever processes a message: only the owner deletes, and only after the
     * trace line is written — `traceId` is the id `tracePool` returned. Shortcut: checks the l4
     * pipeline of `moduleName`.
     */
    export function deletePoolMessage(moduleName: string, file: Ns5FileInfo, traceId: string): Promise<string>;
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/dispatch" {
    /**
     * Optional pool transport (d1_38, chain rule of 28/09: dispatching a run authorizes it).
     * The command authorizes the run. An `implement` in `l4/<module>/pool/l1` may be the dispatch that
     * carried it, never a proof: entry10 only lists the ones present when it ran, and finalize80,
     * once the defs are complete, traces each of those in its report and then deletes it.
     * Estimate messages belong to agentPlannerL1 and are never listed. A later arrival is another
     * execution's and stays. Pool shape follows `solution/pool.ts`; only its types come from 102035.
     */
    import type { PoolTraceLine } from "_102035_/l2/solution/pool";
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /** Display paths of the l1 dispatches present now. Read-only; the entry never depends on it. */
    export function listDispatchMessages(project: number, moduleName: string): Promise<string[]>;
    export interface DispatchConsumption {
        /** Trace lines to append to the report, before any delete. */
        lines: PoolTraceLine[];
        /** Store files to delete once the lines are on disk. */
        files: D1FileInfo[];
    }
    /**
     * The dispatches entry10 listed that are still in pool/l1. Lines already traced are not
     * repeated (a crash after the trace only deletes on the next pass). Nothing else is touched.
     */
    export function dispatchConsumption(project: number, moduleName: string, listed: readonly string[], traced: readonly PoolTraceLine[], now: Date): Promise<DispatchConsumption>;
    /**
     * Deletes each file only if `traced` (the report as read back from disk) holds its `processed`
     * line. Otherwise throws before deleting it: trace first, then delete (`deletePoolMessageAt`).
     */
    export function deleteTraced(files: readonly D1FileInfo[], traced: readonly PoolTraceLine[]): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst" {
    export interface D1ContractField {
        name: string;
        type: string;
        optional: boolean;
    }
    export interface D1ContractSymbol {
        name: string;
        fields: D1ContractField[];
        /** `array` when the exported type is an array. The element fields stay the contracted item. */
        shape: 'object' | 'array';
        /** Element symbol when an array alias points at another type. Empty when the fields are inline. */
        element: string;
    }
    export interface D1ContractAst {
        symbols: D1ContractSymbol[];
        /**
         * Exported declarations this reader could see but not close.
         * Callers surface each entry as `CONTRACT_UNPARSED`. Empty on a file this reader finished.
         */
        unparsed: string[];
    }
    /**
     * Reads exported type shapes. Route identity is the promoted v2 parser, not
     * `export const routes` or a `*Route` const. The first interface, and a name
     * that matches the usecase, are not an identity.
     * Deno loads this file with the agent. It must not import `typescript`.
     */
    export function readContractAst(source: string, fileName: string): D1ContractAst;
    /** The unique symbol of this name, or null when it is missing or duplicated. */
    export function symbolFields(ast: D1ContractAst, name: string): D1ContractField[] | null;
}
declare module "_102021_/l2/helpers/l1Defs/operations" {
    export const L1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export type L1Operation = typeof L1_OPERATIONS[number];
    export const L1_OPERATION_TRAITS: Record<L1Operation, {
        read: boolean;
        write: boolean;
        addressesRecord: boolean;
    }>;
    /**
     * The one source for the reads a port declares for an operation (t1_09 r3, r3p6), read by the D1 port plan
     * and by the M1 usecase body: the operation's own reads, and list for a create that checks unique keys.
     */
    export function portReadsFor(operation: L1Operation, entity: {
        uniqueKeys: readonly (readonly string[])[];
    }): L1Operation[];
    export function isL1Operation(value: string): value is L1Operation;
    /** A transition write: the entity and its L4 transitionRef. */
    export interface L1TransitionWrite {
        entity: string;
        transitionRef: string;
    }
    /** Base transition usecase ids that more than one entity writes (d1_53). */
    export function collidingTransitionIds(writes: Iterable<L1TransitionWrite>): Set<string>;
    /**
     * The one rule for a transition usecase id, for the P1 plan and for a usecase input20 creates from the contract:
     * lowerFirst(transitionRef); when another entity writes the same transition, the entity is appended.
     */
    export function transitionUsecaseId(entity: string, transitionRef: string, colliding: ReadonlySet<string>): string;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/contracts" {
    import type { D1ContractAst } from "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst";
    export const D1_INPUT_VERSION: "2026-10-01-d1-input-v2";
    /** P1 operation vocabulary. Same list as `L1_OPERATIONS`. */
    export const D1_P1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export const D1_SOURCE_SCHEMAS: {
        readonly module: "2026-09-10-ns5-module-v2";
        readonly journey: "2026-09-10-ns5-journey-v1";
        readonly ontology: "2026-09-17-ns5-ontology-v3.1";
        readonly rules: "2026-09-16-ns5-rules-v2";
        readonly workflows: "2026-09-17-ns5-workflows-v3";
        readonly access: "2026-09-12-ns5-access-v3";
        readonly integration: "2026-09-12-ns5-integration-v2";
        readonly menu: "2026-09-20-p2-menu-v2.2";
        readonly needs: "2026-09-21-p2-needs-v1";
        readonly backend: "2026-09-21-p1-backend-v1.2";
        readonly effort: "2026-09-21-p2-effort-v1.2";
        readonly planner: "2026-09-20-p1-pipeline-v1";
    };
    /** `backend.json.testSupport[]` (p1_12). Same enums as agentPlannerL1 plan20; D1 checks, never fills. */
    export const D1_TEST_SUPPORT_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export const D1_TEST_SUPPORT_OWNERS: readonly ["L1", "runtime"];
    export const D1_PLANNER_FLOW: "agentPlannerL1";
    export const D1_EFFORT_BACKEND_REF: "pool/l2/web/backend.json";
    export const D1_ACTIVE_STATUSES: readonly ["toCreate", "toUpdate", "done"];
    export type D1ActiveStatus = typeof D1_ACTIVE_STATUSES[number];
    export type D1PlanStatus = D1ActiveStatus | 'toRemove';
    export type D1FileAction = 'create' | 'update' | 'preserve' | 'recompose' | 'remove' | 'conflict';
    export type D1ProblemSeverity = 'error' | 'review';
    export interface D1InputProblem {
        severity: D1ProblemSeverity;
        code: string;
        path: string;
        message: string;
        ownerRef?: string;
    }
    export interface D1SourceDigest {
        path: string;
        sha256: string;
        bytes: number;
        schemaVersion: string;
        state: 'present' | 'missing' | 'invalid';
    }
    export interface D1PresentDef {
        path: string;
        sha256: string;
    }
    export interface D1InputArtifacts {
        sources: D1SourceDigest[];
        module: unknown;
        journeyIndex: unknown;
        journeys: Record<string, unknown>;
        ontologyIndex: unknown;
        entities: Record<string, unknown>;
        rules: unknown;
        workflows: unknown;
        access: unknown;
        integration: unknown;
        menu: unknown;
        needs: unknown;
        backend: unknown;
        effort: unknown;
        planner: unknown;
        /** Page id → contract AST. Null means the file was looked up and is absent. */
        contracts: Record<string, D1ContractAst | null>;
        /** Page id → contract source. Present when the file was read. */
        contractTexts?: Record<string, string>;
        presentDefs: D1PresentDef[];
        /**
         * Done write rows from the progress file of the step that wrote the def.
         * Not copied into the snapshot. Absent means this caller did not load them.
         */
        writerReceipts?: ReadonlyArray<{
            defPath: string;
            desiredHash: string;
        }>;
    }
    export interface D1PlannerRun {
        flowId: string;
        thread: string;
        round: number;
        schemaVersion: string;
    }
    export interface D1RequestOutput {
        /** Dotted path of the output, from the route output root (`comanda.itens`). */
        key: string;
        entity: string;
        many: boolean;
        page?: string;
        pageSize?: string;
        hasMore?: string;
        /** Key of the page total, when the list carries one (d1_60). */
        total?: string;
        /** Key of the output this one is nested in, when it is a relation (d1_60). */
        parent?: string;
        /** L4 relationshipId that links this output to `parent` (d1_60). */
        relationship?: string;
        /** `readonly` field paths that are no field of `entity`, direct or mapped: calculated (d1_60, d1_63). */
        computed?: string[];
        /** Field paths that belong to an entity linked to `entity` by one N:1 relationship (d1_60). */
        related?: D1RequestRelatedField[];
        /** Contract fields that name an ontology path by a resolution, not by their own path (d1_62). */
        mapped?: D1RequestMappedField[];
    }
    export interface D1RequestMappedField {
        /** Field path as the contract writes it. */
        field: string;
        /** Ontology path of the entity it stands for. */
        path: string;
    }
    /** A readonly value tied to one of the route rules by a resolution (d1_62). */
    export interface D1RequestComputedBy {
        path: string;
        rule: string;
    }
    export interface D1RequestRelatedField {
        field: string;
        entity: string;
        relationship: string;
    }
    /** What a gap asks (d1_62). Each kind has its own closed candidates, computed by code. */
    export type D1RequestGapKind = 'entity' | 'relationship' | 'flatPaging' | 'pageParam' | 'pagingRole' | 'fieldPath' | 'computedRule' | 'value' | 'filterField';
    /** The answer that leaves a gap open. Always the last candidate. */
    export const D1_GAP_NONE = "none";
    /** A part of the route the code could not derive from the types, the ontology and L4 (d1_60). Not an error. */
    export interface D1RequestUnresolved {
        /** `output.<path>` or `input.<name>`. Also the key of its answer. */
        path: string;
        reason: string;
        kind: D1RequestGapKind;
        /** Closed choices computed by code, sorted, with `none` last (d1_62). */
        candidates: string[];
    }
    /** One answer to one gap (d1_62). A choice outside the gap candidates, or `none`, leaves the gap open. */
    export interface D1RequestGapAnswer {
        path: string;
        choice: string;
    }
    /** `field` filters `target`. `pages` names the list organism instead of a field. `optional` is the contract `?`. */
    export interface D1RequestParam {
        name: string;
        target: string;
        field?: string;
        pages?: string;
        /** Present when the contract input is optional. A required param omits it. */
        optional?: boolean;
    }
    export interface D1SelectedRequest {
        route: string;
        pageId: string;
        kind: 'qry' | 'cmd';
        writes: string;
        outputs: D1RequestOutput[];
        params: D1RequestParam[];
        uses: string[];
        /** Readonly values tied to a route rule by a resolve25 answer (d1_62). Present only when there is one. */
        computedBy?: D1RequestComputedBy[];
        /** Present only when something was left unresolved (d1_60). */
        unresolved?: D1RequestUnresolved[];
    }
    export interface D1SelectedUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        /** L4 `transitionId`. Present only when `operation` is `transition`. */
        transitionRef?: string;
        status: D1ActiveStatus;
        existing: string;
        identity: string;
        routes: string[];
    }
    export interface D1SelectedPort {
        portId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1SelectedTable {
        tableId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        action: D1FileAction;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
        /** Present only when this receipt inventoried the bytes at defPath. */
        contentHash?: string;
    }
    export interface D1RemovedItem {
        kind: string;
        id: string;
        defPath: string | null;
        inventoried: boolean;
        contentHash?: string;
    }
    export interface D1InputSnapshot {
        schemaVersion: typeof D1_INPUT_VERSION;
        project: number;
        moduleName: string;
        device: 'web';
        plannerRun: D1PlannerRun | null;
        sources: D1SourceDigest[];
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            requests: D1SelectedRequest[];
            usecases: D1SelectedUsecase[];
            ports: D1SelectedPort[];
            tables: D1SelectedTable[];
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
        removed: D1RemovedItem[];
        problems: D1InputProblem[];
        consumersReleased: boolean;
        snapshotHash: string;
    }
    export function inputPaths(moduleName: string): {
        module: string;
        journeyIndex: string;
        ontologyIndex: string;
        rules: string;
        workflows: string;
        access: string;
        integration: string;
        menu: string;
        needs: string;
        backend: string;
        effort: string;
        planner: string;
    };
    export function journeyPath(moduleName: string, journeyId: string): string;
    export function entityPath(moduleName: string, entityId: string): string;
    export function contractPath(moduleName: string, pageId: string): string;
    export function isSafeToken(value: string): boolean;
    export function lowerFirst(value: string): string;
}
declare module "_102021_/l2/helpers/l1Defs/definition" {
    /**
     * C0 contract for defs v2. Exclusive owner of this file: d1_30.
     *
     * d1_31 (writer/finalize), m1_01 (planner) and m1_04 (tests) import from here:
     *   /_102021_/l2/helpers/l1Defs/definition.js
     *
     * Does not import d1Artifact: d1_31 will import this module, and a reverse
     * runtime import would cycle. Business `data` keeps the D1 field names.
     */
    export const M1_DEFINITION_SCHEMA: "2026-09-24-d1-definition-v2";
    export const M1_RECEIPT_SCHEMA: "2026-09-24-m1-receipt-v1";
    export const D1_DEFINITION_SCHEMA_V1: "2026-09-21-d1-definition-v1";
    export const M1_STATUSES: readonly ["pending", "generated", "blocked", "failed"];
    export type M1Status = typeof M1_STATUSES[number];
    export const M1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound", "workflowProcess"];
    export type M1ArtifactType = typeof M1_ARTIFACT_TYPES[number];
    export const M1_STAGES: readonly ["plan", "generate", "compile", "verify", "promote"];
    export type M1Stage = typeof M1_STAGES[number];
    export const M1_VERIFICATION_KINDS: readonly ["compile", "test", "schema", "hash"];
    export type M1VerificationKind = typeof M1_VERIFICATION_KINDS[number];
    /** Public names d1_31 must import. Do not duplicate these enums in agentDefsL1. */
    export const D1_31_IMPORT: "/_102021_/l2/helpers/l1Defs/definition.js";
    export const D1_31_EXPORTS: readonly ["M1_DEFINITION_SCHEMA", "M1_STATUSES", "M1_ARTIFACT_TYPES", "parseDefinitionSource", "renderDefinition", "definitionIssues", "canonicalProjection", "semanticHash", "referenceIssues", "traverseDefinitions", "statusEvidenceIssues", "generatedAllowsSkip", "receiptIssues", "receiptPathFor", "diagnoseUnit"];
    export interface M1Definition {
        schemaVersion: typeof M1_DEFINITION_SCHEMA;
        artifactType: M1ArtifactType;
        artifactId: string;
        moduleName: string;
        status: M1Status;
        dependencies: string[];
        data: Record<string, unknown>;
    }
    export interface M1Verification {
        id: string;
        kind: M1VerificationKind;
        passed: boolean;
        detail: string;
    }
    export interface M1ReceiptFailure {
        code: string;
        detail: string;
    }
    export interface MaterializationReceipt {
        schemaVersion: typeof M1_RECEIPT_SCHEMA;
        runId: string;
        candidateId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        recipeVersion: string;
        semanticHash: string;
        dependencyHashes: Record<string, string>;
        sourceHashes: Record<string, string>;
        outputHashes: Record<string, string>;
        stage: M1Stage;
        verifications: M1Verification[];
        failures: M1ReceiptFailure[];
        attempts: number;
        reason: string;
    }
    export interface KnownArtifact {
        artifactType: M1ArtifactType;
        artifactId: string;
        defPath: string;
    }
    export interface ReferenceIndex {
        files: readonly string[];
        artifacts: readonly KnownArtifact[];
    }
    export interface IndexedDefinition {
        defPath: string;
        definition: M1Definition;
    }
    export interface UnitDiagnosis {
        unitId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        status: M1Status;
        stage: M1Stage;
        issues: string[];
        inputHash: string;
        outputHash: string;
    }
    export function isM1Status(value: string): value is M1Status;
    export function isM1ArtifactType(value: string): value is M1ArtifactType;
    export function isM1Stage(value: string): value is M1Stage;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function receiptFolder(moduleName: string): string;
    /**
     * Receipt file for one def. The def path is unique on disk; artifactId is not,
     * and a case-only difference is the same file. The base name has no extra dot.
     */
    export function receiptPathFor(defPath: string): string;
    export function outputPathFromDefPath(defPath: string): string;
    export function qualifiedFileIssues(path: string, field: string): string[];
    export function definitionIssues(value: unknown): string[];
    export function parseDefinitionSource(source: string): {
        definition: unknown;
    } | {
        issues: string[];
    };
    export function renderDefinition(definition: M1Definition, defPath: string): {
        source: string;
    } | {
        issues: string[];
    };
    export function readDefinition(value: unknown): M1Definition | {
        issues: string[];
    };
    export function canonicalProjection(definition: M1Definition): Record<string, unknown>;
    export function semanticHash(definition: M1Definition): Promise<string>;
    export function referenceIssues(definition: M1Definition, index: ReferenceIndex): string[];
    export function traverseDefinitions(units: readonly IndexedDefinition[], knownFiles?: readonly string[]): {
        order: string[];
        issues: string[];
    };
    export function receiptIssues(value: unknown): string[];
    export function statusEvidenceIssues(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<string[]>;
    export function generatedAllowsSkip(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<boolean>;
    export function diagnoseUnit(input: {
        defPath: string;
        definition: M1Definition;
        receipt?: MaterializationReceipt | null;
        index?: ReferenceIndex;
        stage?: M1Stage;
        currentDependencyHashes?: Readonly<Record<string, string>>;
    }): Promise<UnitDiagnosis>;
    /** Alpha read of a `ddm`: calculated on read, from the named sources, window and groups. */
    export function derivedReadIssues(value: unknown, issues: string[]): void;
    /** Top-level `data` keys. d1_31 uses this list; agentDefsL1 does not keep a second copy. */
    export function dataAllowList(type: M1ArtifactType): readonly string[];
}
declare module "_102021_/l2/helpers/l1Defs/identity" {
    /**
     * Identity of a def file. A v2 definition hashes the semantic projection, so a
     * status edit is not a new source. Anything else hashes the raw text.
     */
    export function sourceIdentityHash(source: string): Promise<string>;
    /**
     * A receipt matches the disk when the bytes match, the semantic hash matches,
     * or the only difference is the status D1 would have written as pending.
     * An old receipt of the pending file must not look like SOURCE_CHANGED after
     * a legitimate status update.
     */
    export function hashesAgree(disk: string, receiptHash: string): Promise<boolean>;
    export function sha256Text(value: string): Promise<string>;
}
declare module "_102021_/l2/helpers/l1Defs/fixture" {
    /**
     * Certification fixture plan (m1_28). One shape, one producer, two readers:
     * - producer: D1 support70 `emitSeeds`, from `backend.json.testSupport[]` (p1_12, v1.2) and the
     *   local tables persistence40 planned; written as `data.fixture` of the persistenceSeeds def;
     * - readers: M1 `emitPersistence` (renders it as `certificationFixture`, apart from the product
     *   seeds) and the memory harness `testing/fixture.ts` (setup, cases, cleanup).
     * The plan holds no rows, no ids and no grants. Values are derived by the harness from the
     * entity defs and the contracts at execution time. A runtime-owned item keeps its gap here.
     */
    export const M1_FIXTURE_SCHEMA: "2026-09-27-m1-certification-fixture-v1";
    /** Declared destinations. `development` needs the runtime profile of execBFF; it is not run here. */
    export const M1_FIXTURE_TARGETS: readonly ["memory", "development"];
    export type M1FixtureTarget = typeof M1_FIXTURE_TARGETS[number];
    /** Module data the fixture creates, one per local table. */
    export interface M1FixtureDataset {
        supportId: string;
        entityId: string;
        tableId: string;
        /** Local datasets whose ids this one references. Created first, removed last. */
        dependsOn: string[];
        sourceRefs: string[];
    }
    /** Test identity or MDM data the runtime owns. L1 does not create it and does not invent it. */
    export interface M1FixtureRuntimeNeed {
        supportId: string;
        kind: 'identity' | 'mdm';
        entityId: string;
        actorRefs: string[];
        gap: string;
        owner: 'runtime';
    }
    export interface M1FixturePlan {
        schemaVersion: typeof M1_FIXTURE_SCHEMA;
        phase: 'plan';
        targets: M1FixtureTarget[];
        datasets: M1FixtureDataset[];
        runtime: M1FixtureRuntimeNeed[];
        /** testSupport items this plan could not place, with their reason. */
        gaps: string[];
    }
    /**
     * Plan from testSupport and the live local tables. Deterministic; `null` when there is no
     * testSupport (a v1.1 backend plan), so the def stays as before.
     */
    export function planFixture(testSupport: readonly unknown[] | undefined, tables: ReadonlyArray<{
        tableId: string;
        entityId: string;
    }>): M1FixturePlan | null;
    /** Reads `data.fixture` of a persistenceSeeds def. Anything else is refused with its issue. */
    export function readFixturePlan(value: unknown): M1FixturePlan | {
        issues: string[];
    };
    /** Parents before children; `null` on a cycle. */
    export function dependencyOrder(datasets: readonly M1FixtureDataset[]): M1FixtureDataset[] | null;
}
declare module "_102021_/l2/helpers/l1Defs/disclosure" {
    /**
     * The one disclosure rule for a projected path (t1_10 r2, d1_63), read by the D1 controller plan
     * (controllers60) and by the M1 request service (emit.ts) through `nodeDisclosure`. Every entity path rule lives in
     * `pathDisclosure`.
     */
    export interface DisclosureGrant {
        disclosure: string;
        /** `Entity.path` entries. `Entity` alone is the whole record. */
        allowedFields: readonly string[];
        /** Entities the grant is about. Empty: the grant is about every entity of the route. */
        entityRefs: readonly string[];
        /** Actor the grant belongs to. Absent: every such grant is the same single actor. */
        actorRef?: string;
    }
    /** `disclosed`; `carrier` = a grant names a sub-path of it (the container is not released); `blocked`. */
    export type PathDisclosure = 'disclosed' | 'carrier' | 'blocked';
    /** Grants that speak for one entity's output: `entityRefs` names it, or the grant has no `entityRefs`. */
    export function coveringGrants<T extends DisclosureGrant>(grants: readonly T[], entity: string): T[];
    /**
     * Covering grants are grouped by `actorRef` (absent is one actor). Inside an actor a path leaves
     * only when every grant of that actor discloses it. Across actors the path is `disclosed` when
     * some actor discloses it, `carrier` when none does and some actor holds it as a container, else
     * `blocked`. An actor with no grant on the entity is not in the group and does not block.
     * `fullRecord` discloses all; `fieldsOnly`/`summaryOnly` the `<entity>.` allowed fields and what
     * is under them; any other mode nothing.
     * The entity's system paths (primary key and declared concurrency field) leave with any covering
     * grant. They are not business data, so `allowedFields` does not have to name them. A grant that
     * does not cover the entity still discloses nothing.
     */
    export function pathDisclosure(grants: readonly DisclosureGrant[], entity: string, path: string, entityDefinition?: unknown): PathDisclosure;
    /**
     * One projected contract path, classified by what it is in the ontology (d1_63). Both the D1 plan (controllers60) and
     * the M1 request service take them from the request tree of the def (`requestTree.ts` `outputViews`, d1_61).
     * - `entity`: a field of `entity` at the ontology `path` (direct, mapped, a field of an N:1 entity, or a field of a
     *   nested relation, whose `entity` is the related one). Checked by `pathDisclosure`.
     * - `computed`: a readonly value that is no ontology path of `entity`, the entity that owns the output. `entity` is
     *   empty for an aggregate no entity owns (d1_65).
     * - `paging`: a paging key of a list page. Not entity data.
     */
    export type DisclosureNode = {
        kind: 'entity';
        field: string;
        entity: string;
        path: string;
    } | {
        kind: 'computed';
        field: string;
        entity: string;
    } | {
        kind: 'paging';
        field: string;
    };
    /**
     * The nodes of one output. A view of the request tree (`requestTree.ts` `outputViews`, d1_61) carries them; a def
     * written before the tree (`outputs`) has none, and each path is read as a path of its entity.
     */
    export function outputNodes(output: {
        entity: string;
        fields: readonly string[];
        disclosure?: readonly DisclosureNode[];
    }): DisclosureNode[];
    /** `computed`: a calculated value without a `fullRecord` grant of its entity (`COMPUTED_NOT_DISCLOSED`). */
    export type NodeDisclosure = PathDisclosure | 'computed';
    /**
     * The one rule for a classified path. An entity path goes through `pathDisclosure` on its ontology path. A paging key
     * leaves. A calculated value leaves when some actor's grants on its entity are all `fullRecord`, and there is one:
     * an aggregate of records may reveal what the fields do not, so it is closed by default. An actor with no grant
     * on the entity does not block the others.
     */
    export function nodeDisclosure(grants: readonly DisclosureGrant[], node: DisclosureNode, entityDefinition: (entity: string) => unknown): NodeDisclosure;
    /**
     * Primary key and concurrency field of one entity, for a domain def or an ontology entity.
     * The identity is the derived `uuid`, else the first derived field; the concurrency field is the
     * single other derived integer or number. A field that is not marked is not included. Not a name list.
     * `domainOptional` reads these two; it does not keep a second copy of the marks.
     */
    export function systemIdentity(entityDefinition: unknown): string;
    /** The single other derived integer or number, or '' when the entity does not declare exactly one. */
    export function systemVersion(entityDefinition: unknown, identity: string): string;
    export function systemFieldPaths(entityDefinition: unknown): string[];
    export interface DenialGrant {
        grantId: string;
        entityRefs: readonly string[];
        allowedFields?: readonly string[];
        deniedFields?: readonly string[];
    }
    /**
     * `fieldsOnly` read as an explicit allow-list. No `deniedFields`: `allowedFields` as declared.
     * With denials, each `entityRefs` entry is walked on `record.fields` (tree order, no repeats).
     * A ref under a denial drops; an ancestor is replaced by its children; the bare entity never
     * stays (it becomes its first-level fields). A denial of the entity drops it. No `record.fields` throws.
     */
    export function resolveAllowedFields(grant: DenialGrant, entities: Record<string, unknown>): string[];
}
declare module "_102021_/l2/helpers/l1Defs/requestTree" {
    import type { DisclosureNode } from "_102021_/l2/helpers/l1Defs/disclosure";
    /**
     * The output of one request service route as the D1 classified it (d1_61): a tree of contract paths, one node per
     * classified part, written by controllers60 from the derived route (input20 + resolve25). The nesting is the path:
     * `comanda` is the parent of `comanda.itens`. The D1 plan, the M1 request service and the M1 obligations read the
     * same nodes, through `outputViews`.
     */
    /** One contract leaf of a node: `field` relative to the node element, `path` the ontology path of the node entity. */
    export interface RequestTreeField {
        field: string;
        path: string;
    }
    /**
     * - `entity`: the object at `path` is a record of `entity`.
     * - `list`: the array of `entity` at `path`. `items` names the item array inside a page wrapper (`{ items: Row[]; ... }`),
     *   empty when `path` is the array itself. The paging keys are contract paths from the route output root.
     * - `related`: fields of an entity linked by one L4 relationship: an N:1 field next to its owner (same `path`), or a
     *   nested relation (`comanda.itens`). `relationship` is absent while the derivation left it open.
     * - `computed`: a readonly value that is no ontology path. `entity` is the output that owns it (absent in a group of
     *   outputs); `rules` is the rule a resolution tied it to, else the route rules (the candidates).
     * - `unresolved`: what the derivation left open, with the reason.
     */
    export type RequestOutputNode = {
        kind: 'entity';
        path: string;
        entity: string;
        fields: RequestTreeField[];
    } | {
        kind: 'list';
        path: string;
        entity: string;
        items: string;
        page?: string;
        pageSize?: string;
        hasMore?: string;
        total?: string;
        fields: RequestTreeField[];
    } | {
        kind: 'related';
        path: string;
        entity: string;
        relationship?: string;
        fields: RequestTreeField[];
    } | {
        kind: 'computed';
        path: string;
        entity?: string;
        rules: string[];
    } | {
        kind: 'unresolved';
        path: string;
        reason: string;
    };
    export const REQUEST_NODE_KINDS: readonly ["entity", "list", "related", "computed", "unresolved"];
    export const REQUEST_PAGING_KEYS: readonly ["page", "pageSize", "hasMore", "total"];
    /** The route JSDoc as the contract parser read it (d2_78): always the raw text, and the sections it recognized. */
    export interface RequestDoc {
        raw: string;
        purpose?: string;
        input?: string;
        processing?: string;
        output?: string;
    }
    export const REQUEST_DOC_SECTIONS: readonly ["purpose", "input", "processing", "output"];
    /** The contract path of the records of a node: the item array of a page wrapper, else the node path. */
    export function elementPath(node: Extract<RequestOutputNode, {
        fields: RequestTreeField[];
    }>): string;
    /** The tree of a def read back. Null when any node is not a node (fail closed). */
    export function readOutputTree(value: unknown): RequestOutputNode[] | null;
    /** The doc of a def read back: undefined when absent, null when it is not a doc. */
    export function readRequestDoc(value: unknown): RequestDoc | null | undefined;
    /**
     * One root member of the route output with what is under it: `entity` is the entity of the node at `key` (empty for a
     * group of outputs); `fields` the classified contract paths relative to `key`; `disclosure` each of them as the one
     * disclosure rule reads it (`nodeDisclosure`). An `unresolved` node projects nothing and is not disclosed.
     */
    export interface RequestOutputView {
        key: string;
        entity: string;
        fields: string[];
        disclosure: DisclosureNode[];
    }
    export function outputViews(tree: readonly RequestOutputNode[]): RequestOutputView[];
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Artifact" {
    import { type M1ArtifactType, type M1Status } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1FixturePlan } from "_102021_/l2/helpers/l1Defs/fixture";
    export const D1_DEFINITION_SCHEMA: "2026-09-24-d1-definition-v2";
    export type { M1Status, M1Status as D1DefinitionStatus };
    /**
     * Measured on RequestContext.data.pgQueue. RequestContext itself has no publishEvent or emitEvent.
     * Postgres publish inserts into the MDM outbox. It is not a module bus.
     * The constant is evidence of the real API. It is not an approved integrationOutbound binding.
     */
    export const D1_MEASURED_PUBLISH: {
        readonly symbol: "IQueueRuntime.publish";
        readonly path: "mls-102034/l1/server/layer_1_external/data/runtime.ts";
        readonly owner: "RequestContext.data.pgQueue";
        readonly payload: "{ topic: string; payload: unknown }";
        readonly delivery: "Postgres insert into mdm_outbox. Memory keeps an array. No module consumer is registered.";
        readonly transaction: "Postgres publish uses the transaction executor. Memory runInTransaction does not roll back.";
    };
    /** Names that are not methods of RequestContext. Writing them would invent an API. */
    export function fictionalMechanism(value: string): boolean;
    export const D1_CATALOG_SCHEMA: "2026-09-21-d1-catalog-v1";
    /** Closed set. Same list as the v2 contract. Auxiliary names are not dispatched by agentChangeBackend. */
    export const D1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound", "workflowProcess"];
    export type D1ArtifactType = M1ArtifactType;
    /** Types readL1Inventory already filters on. */
    export const D1_INVENTORY_TYPES: readonly ["usecase", "repositoryPort", "table", "httpController"];
    /** Design forecast parts. Not a count of files this agent writes. */
    export const D1_CORE_TYPES: readonly ["domainEntity", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService"];
    export const D1_AUXILIARY_TYPES: readonly ["valueObject", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export const D1_FORECAST_CORE: {
        readonly count: 26;
        readonly parts: {
            readonly domainEntity: 5;
            readonly repositoryPort: 1;
            readonly table: 1;
            readonly repositoryAdapter: 1;
            readonly usecase: 13;
            readonly httpController: 5;
        };
        readonly note: "Design forecast: 5 models, 1 port, 1 table, 1 adapter, 13 usecases and 5 controllers. It is not a count of files this agent generated.";
    };
    export const D1_STORAGE_TARGETS: readonly ["moduleDatabase", "mdm", "external", "derived"];
    export type D1StorageTarget = typeof D1_STORAGE_TARGETS[number];
    export interface D1Field {
        name: string;
        type: string;
        derived?: boolean;
        ref?: string;
        /** Named type of the MDM ontology (`mdm.types`) when `type` is `object`. */
        of?: string;
    }
    export interface D1LifecycleState {
        state: string;
        reachedBy: 'actor' | 'command' | 'time';
    }
    export interface D1Transition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
    }
    export interface D1DomainEntityData {
        entityId: string;
        storageTarget: D1StorageTarget;
        fields: D1Field[];
        lifecycle: {
            states: D1LifecycleState[];
            transitions: D1Transition[];
        };
        invariants: string[];
        imports: string[];
    }
    export interface D1ValueObjectData {
        valueObjectId: string;
        fields: D1Field[];
        referencedBy: string[];
    }
    export interface D1PortMethod {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1RepositoryPortData {
        entityId: string;
        interfaceName: string;
        methods: D1PortMethod[];
    }
    export interface D1TableData {
        tableId: string;
        entityId: string;
        physicalName: string;
        primaryKey: string[];
        uniqueKeys: string[][];
        indexes: Array<{
            name: string;
            columns: string[];
            unique: boolean;
        }>;
    }
    export interface D1RepositoryAdapterData {
        entityId: string;
        portId: string;
        tableId: string;
        columns: Array<{
            field: string;
            column: string;
        }>;
    }
    export interface D1ProjectionField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface D1UsecaseData {
        usecaseId: string;
        entityId: string;
        operation: string;
        rulesApplied: string[];
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        transitionRef?: string;
        mdm?: {
            namespace: string;
            role: string;
            atomic: boolean;
            calls: Array<Record<string, unknown>>;
        };
    }
    export interface D1HttpHandlerV1 {
        route: string;
        kind: 'query' | 'command';
        usecaseId: string;
        grantIds: string[];
    }
    /** Adapter. Types are `<contractInterface>['<route>']['input'|'output']`. */
    export interface D1HttpHandlerAdapter {
        route: string;
        kind: 'query' | 'command';
        grantIds: string[];
        serviceFunction: string;
        contractPath: string;
        contractInterface: string;
    }
    export interface D1HttpControllerData {
        pageId: string;
        handlers: Array<D1HttpHandlerV1 | D1HttpHandlerAdapter>;
    }
    export interface D1AccessJoin {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Path of one entity of the grant. The anchor keeps empty steps. A missing field is this entity's pending only. */
    export interface D1EntityScopePath {
        entityId: string;
        steps: D1AccessJoin[];
        pending: string;
    }
    export interface D1Grant {
        grantId: string;
        actorRef: string;
        anchorEntity?: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields?: string[];
        /** Declared mode. own and organization stay distinct. Never a permissive fallback. */
        scopeMode: string;
        /** Subject comes from the verified session, never from a form field. */
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
    }
    export interface D1AccessScopeData {
        scopeId: string;
        grants: D1Grant[];
    }
    /** A serialized def plus the files it declares. Reconstruction does not read drafts. */
    export interface D1PolicyUnit {
        defPath: string;
        artifactType: string;
        data: unknown;
        dependencies: readonly string[];
    }
    export interface D1ReconstructedPolicy {
        route: string;
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: string;
        allowedFields: string[];
        anchorEntity: string;
        scopeMode: string;
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
        scopePath: string;
    }
    export interface D1AccessPolicyIssue {
        code: 'POLICY_UNBOUND';
        path: string;
        ownerRef: string;
        message: string;
    }
    export interface D1AuthorityMapData {
        mapId: string;
        entries: Array<{
            grantId: string;
            actorRef: string;
        }>;
    }
    export interface D1RegistrationData {
        registrationId: string;
        adapters: Array<{
            portId: string;
            adapterArtifactId: string;
        }>;
    }
    export interface D1SeedRefData {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDependencyData {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedDatasetData {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    /** A plan for the later materializer. `phase` is `plan`. This artifact has no rows. */
    export interface D1SeedsData {
        seedId: string;
        phase?: 'plan';
        scenarios: Array<{
            scenarioId: string;
            tableId: string;
            source?: string;
            constraints: string[];
            refs?: D1SeedRefData[];
            states?: string[];
            requires?: string[];
        }>;
        dependencies?: D1SeedDependencyData[];
        datasets?: D1SeedDatasetData[];
        /** Temporary certification data (m1_28), apart from the product seeds. No rows. */
        fixture?: M1FixturePlan;
    }
    export interface D1IntegrationData {
        integrationId: string;
        events: Array<{
            eventId: string;
            on: string;
            entityId: string;
            mechanism: string;
        }>;
    }
    export interface D1WorkflowProcessData {
        processId: string;
        trigger: {
            kind: 'manual' | 'event' | 'scheduled';
            actorRef?: string;
            event?: string;
            schedule?: string;
        };
        occurrence?: {
            entityId: string;
        };
        functions: string[];
        operations: Array<{
            operation: string;
            steps: string[];
        }>;
    }
    export interface D1Definition<T = Record<string, unknown>> {
        schemaVersion: typeof D1_DEFINITION_SCHEMA;
        artifactType: D1ArtifactType;
        artifactId: string;
        moduleName: string;
        status: M1Status;
        dependencies: string[];
        data: T;
    }
    /** A new def is pending. The caller passes blocked when a concrete external gap is already known. */
    export function pendingDefinition<T extends Record<string, unknown>>(artifactType: D1ArtifactType, artifactId: string, moduleName: string, data: T, dependencies?: readonly string[], status?: M1Status): D1Definition<T>;
    export function isArtifactType(value: string): value is D1ArtifactType;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    /** Copies the shared $defs onto one artifact payload so a tool wrapper can hoist them. */
    export function typeDataSchema(definitionSchema: Record<string, unknown>, typeName: string): Record<string, unknown>;
    export function definitionIssues(value: unknown): string[];
    export function recordFieldIssues(data: unknown): string[];
    export function storageTargetIssues(data: unknown): string[];
    export function lifecycleIssues(data: unknown): string[];
    export function domainImportIssues(moduleName: string, imports: readonly string[], source?: string): string[];
    export function domainEntityIssues(data: unknown): string[];
    export function valueObjectIssues(data: unknown): string[];
    export function repositoryPortIssues(data: unknown): string[];
    export function tableIssues(data: unknown): string[];
    /**
     * artifactId is the logical table id. The inventory reads the entity from data.entityId.
     */
    export function tableIdentityIssues(data: unknown, artifactId: string): string[];
    export function adapterBindingIssues(data: unknown): string[];
    export function adapterLinkIssues(adapter: unknown, port: unknown, table: unknown): string[];
    export function projectionIssues(data: unknown): string[];
    /**
     * The removed v1 shape of a usecase: `routeProjections` and `functions[].contractRefs`.
     * A v2 usecase carries neither; the page request names it in `uses`. Present, even empty, is refused.
     */
    export function usecaseV1Issues(data: unknown): string[];
    export function usecaseIssues(data: unknown): string[];
    /** The unique-key line. It is not a business rule, so `ruleId` stays empty. */
    export function isStorageConstraintRow(row: {
        ruleId: string;
        origin: string;
        consumer: string;
        enforcement: string;
        gap: string;
    }): boolean;
    export function workflowProcessIssues(data: unknown): string[];
    export function requestServiceIssues(data: unknown): string[];
    export function httpControllerIssues(data: unknown): string[];
    export function accessAnchorIssues(data: unknown): string[];
    export function accessScopeIssues(data: unknown): string[];
    /**
     * Rebuilds each handler grant from serialized defs and declared file dependencies.
     * A scope reached through an intermediate def counts. Drafts are not an input.
     */
    export function reconstructAccessPolicy(units: readonly D1PolicyUnit[]): {
        policies: D1ReconstructedPolicy[];
        issues: D1AccessPolicyIssue[];
    };
    export function authorityMapIssues(data: unknown): string[];
    export function authorityGrantIssues(map: unknown, scope: unknown): string[];
    export function registrationIssues(data: unknown): string[];
    export function seedScenarioIssues(data: unknown): string[];
    /** Processes, inbound and plugins stay operations. A gap is a declared item the pool did not select. */
    export function integrationCoverageIssues(data: unknown): string[];
    /** Empty mechanism is reported and the event is left in place. The MDM queue is not a binding. */
    export function integrationMechanismIssues(data: unknown): string[];
    /** Domain imports are checked with the definition's module, not an empty string. */
    export function definitionImportIssues(value: unknown, source?: string): string[];
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Refs" {
    import { D1_CATALOG_SCHEMA, D1_FORECAST_CORE, type D1ArtifactType, type D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    export const D1_OUTPUT_AVAILABILITY: readonly ["future", "present"];
    export type D1OutputAvailability = typeof D1_OUTPUT_AVAILABILITY[number];
    /** What each type may depend on. A usecase must not depend on the registry or the adapter. */
    export const DEPENDS_ALLOWED: Record<D1ArtifactType, readonly D1ArtifactType[]>;
    export interface D1PipelineItem {
        id: string;
        type: D1ArtifactType;
        defPath: string;
        outputPath: string;
        outputAvailability: D1OutputAvailability;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        routes?: string[];
    }
    export interface D1Justification {
        id: string;
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Absence {
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Catalog {
        schemaVersion: typeof D1_CATALOG_SCHEMA;
        project: number;
        moduleName: string;
        items: D1PipelineItem[];
        presentPaths: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
    }
    export interface D1MeasuredPlan {
        project: number;
        moduleName: string;
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            /**
             * Debt for `examples/agendaClinicaExamples.ts`, which still indexes this.
             * No D1 reader fills it. The snapshot from input20 does not have this field.
             */
            routes: Array<{
                route: string;
                page: string;
                kind: string;
                usecaseRef: string;
            }>;
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                routes: string[];
            }>;
            ports: Array<{
                portId: string;
                entity: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
            }>;
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
    }
    export interface D1RefFinding {
        path: string;
        kind: 'presentDef' | 'plannedDef' | 'futureOutput' | 'missingInput' | 'uncontractedDeclaration';
        producerId?: string;
    }
    export interface D1Coverage {
        measured: Record<string, number>;
        measuredCore: number;
        forecastCore: typeof D1_FORECAST_CORE.count;
        forecastNote: typeof D1_FORECAST_CORE.note;
        forecastMatchesMeasured: boolean;
        auxiliaries: D1Justification[];
        absences: D1Absence[];
        futureOutputs: string[];
        missingInputs: string[];
        gaps: string[];
    }
    export function pipelineId(project: number, moduleName: string, type: string, owner: string): string;
    export function qualifyDefPath(project: number, logicalPath: string): string;
    /** Logical path of the page request service. input20 inventories it; controllers60 writes it. */
    export function requestServiceDefPath(moduleName: string, pageId: string): string;
    export function futureOutputPath(defPath: string): string;
    export function skillPaths(type: string): string[];
    export function catalogFromPlan(plan: D1MeasuredPlan, input: {
        presentPaths?: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
        skillsFor?: (type: string) => string[];
    }): D1Catalog;
    export function pipelineItemIssues(value: unknown, project?: number, moduleName?: string): string[];
    export function skillRefIssues(items: readonly {
        skills?: unknown;
    }[], knownSkills: readonly string[]): string[];
    export function duplicateRouteIssues(items: readonly {
        id: string;
        routes?: string[];
    }[]): string[];
    export function catalogIssues(value: unknown, knownSkills?: readonly string[]): string[];
    export function graphIssues(items: readonly D1PipelineItem[]): string[];
    export function cycleIssues(items: readonly {
        id: string;
        dependsOn: string[];
    }[]): string[];
    export function resolveCatalogRefs(catalog: D1Catalog): D1RefFinding[];
    export function coverageReport(catalog: D1Catalog, plan: D1MeasuredPlan, storageByEntity: Readonly<Record<string, D1StorageTarget>>): D1Coverage;
    export function effectCoverageIssues(usecases: readonly {
        effects?: Array<{
            eventId: string;
        }>;
    }[], events: readonly string[]): string[];
    /** An outbound event binds the usecase of its entity and transitionRef, or of its entity and L1 operation. */
    export function integrationLinkIssues(events: readonly {
        eventId: string;
        on: string;
        consumer?: string;
    }[], transitionUsecases: readonly {
        entity: string;
        transitionRef: string;
        usecaseId: string;
    }[], operationUsecases?: readonly {
        entity: string;
        operation: string;
        usecaseId: string;
    }[]): string[];
    /**
     * Schema property path → the function that reads it.
     * A new field without an entry here has no reader and must not be added.
     */
    export const D1_FIELD_READERS: {
        readonly 'definition.schemaVersion': "definitionIssues";
        readonly 'definition.artifactType': "definitionIssues";
        readonly 'definition.artifactId': "definitionIssues";
        readonly 'definition.moduleName': "definitionIssues";
        readonly 'definition.status': "definitionIssues";
        readonly 'definition.dependencies': "definitionIssues";
        readonly 'definition.data': "definitionIssues";
        readonly 'domainEntity.entityId': "domainEntityIssues";
        readonly 'domainEntity.storageTarget': "storageTargetIssues";
        readonly 'domainEntity.fields': "domainEntityIssues";
        readonly 'domainEntity.fields.name': "domainEntityIssues";
        readonly 'domainEntity.fields.type': "domainEntityIssues";
        readonly 'domainEntity.fields.derived': "derivedFieldIssues";
        readonly 'domainEntity.fields.ref': "recordFieldIssues";
        readonly 'domainEntity.lifecycle': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.state': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.reachedBy': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.transitionId': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.from': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.to': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.by': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.ruleRefs': "lifecycleIssues";
        readonly 'domainEntity.invariants': "domainEntityIssues";
        readonly 'domainEntity.imports': "domainImportIssues";
        readonly 'valueObject.valueObjectId': "valueObjectIssues";
        readonly 'valueObject.fields': "valueObjectIssues";
        readonly 'valueObject.fields.name': "valueObjectIssues";
        readonly 'valueObject.fields.type': "valueObjectIssues";
        readonly 'valueObject.fields.derived': "derivedFieldIssues";
        readonly 'valueObject.fields.ref': "recordFieldIssues";
        readonly 'valueObject.referencedBy': "valueObjectIssues";
        readonly 'repositoryPort.entityId': "repositoryPortIssues";
        readonly 'repositoryPort.interfaceName': "repositoryPortIssues";
        readonly 'repositoryPort.methods': "repositoryPortIssues";
        readonly 'repositoryPort.methods.name': "repositoryPortIssues";
        readonly 'repositoryPort.methods.params': "repositoryPortIssues";
        readonly 'repositoryPort.methods.returns': "repositoryPortIssues";
        readonly 'table.tableId': "tableIssues";
        readonly 'table.entityId': "tableIdentityIssues";
        readonly 'table.physicalName': "tableIssues";
        readonly 'table.primaryKey': "tableIssues";
        readonly 'table.uniqueKeys': "tableIssues";
        readonly 'table.indexes': "tableIssues";
        readonly 'table.indexes.name': "tableIssues";
        readonly 'table.indexes.columns': "tableIssues";
        readonly 'table.indexes.unique': "tableIssues";
        readonly 'repositoryAdapter.entityId': "adapterBindingIssues";
        readonly 'repositoryAdapter.portId': "adapterLinkIssues";
        readonly 'repositoryAdapter.tableId': "adapterLinkIssues";
        readonly 'repositoryAdapter.columns': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.field': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.column': "adapterBindingIssues";
        readonly 'usecase.usecaseId': "usecaseIssues";
        readonly 'usecase.entityId': "usecaseIssues";
        readonly 'usecase.operation': "usecaseIssues";
        readonly 'usecase.transitionRef': "planTransition";
        readonly 'usecase.rulesApplied': "usecaseIssues";
        readonly 'usecase.effects': "usecaseIssues";
        readonly 'usecase.effects.eventId': "effectCoverageIssues";
        readonly 'usecase.effects.path': "readUsecaseFidelity";
        readonly 'usecase.effects.symbol': "readUsecaseFidelity";
        readonly 'usecase.derivedRead': "usecaseIssues";
        readonly 'usecase.derivedRead.mode': "usecaseIssues";
        readonly 'usecase.derivedRead.sources': "usecaseIssues";
        readonly 'usecase.derivedRead.windowField': "usecaseIssues";
        readonly 'usecase.derivedRead.groupBy': "usecaseIssues";
        readonly 'usecase.derivedRead.measures': "usecaseIssues";
        readonly 'usecase.mdm': "readUsecaseFidelity";
        readonly 'usecase.mdm.namespace': "readUsecaseFidelity";
        readonly 'usecase.mdm.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.atomic': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.method': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.target': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.shape': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.capabilities': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.alternative': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.name': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.capability': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.id': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.kind': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.call': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.present': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.value': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.kind': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.calls': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.evidence': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.result': "readUsecaseFidelity";
        readonly 'httpController.pageId': "httpControllerIssues";
        readonly 'httpController.handlers': "httpControllerIssues";
        readonly 'httpController.handlers.route': "httpControllerIssues";
        readonly 'httpController.handlers.kind': "httpControllerIssues";
        readonly 'httpController.handlers.usecaseId': "httpControllerIssues";
        readonly 'httpController.handlers.grantIds': "httpControllerIssues";
        readonly 'requestService.pageId': "requestServiceIssues";
        readonly 'requestService.requests': "requestServiceIssues";
        readonly 'requestService.requests.route': "requestServiceIssues";
        readonly 'requestService.requests.kind': "requestServiceIssues";
        readonly 'requestService.requests.uses': "requestServiceIssues";
        readonly 'requestService.requests.transaction': "requestServiceIssues";
        readonly 'requestService.requests.output': "requestServiceIssues";
        readonly 'requestService.requests.output.kind': "requestServiceIssues";
        readonly 'requestService.requests.output.path': "requestServiceIssues";
        readonly 'requestService.requests.output.entity': "requestServiceIssues";
        readonly 'requestService.requests.output.relationship': "requestServiceIssues";
        readonly 'requestService.requests.output.items': "requestServiceIssues";
        readonly 'requestService.requests.output.page': "requestServiceIssues";
        readonly 'requestService.requests.output.pageSize': "requestServiceIssues";
        readonly 'requestService.requests.output.hasMore': "requestServiceIssues";
        readonly 'requestService.requests.output.total': "requestServiceIssues";
        readonly 'requestService.requests.output.fields': "requestServiceIssues";
        readonly 'requestService.requests.output.fields.field': "requestServiceIssues";
        readonly 'requestService.requests.output.fields.path': "requestServiceIssues";
        readonly 'requestService.requests.output.rules': "requestServiceIssues";
        readonly 'requestService.requests.output.reason': "requestServiceIssues";
        readonly 'requestService.requests.rules': "requestServiceIssues";
        readonly 'requestService.requests.doc': "requestServiceIssues";
        readonly 'requestService.requests.doc.raw': "requestServiceIssues";
        readonly 'requestService.requests.doc.purpose': "requestServiceIssues";
        readonly 'requestService.requests.doc.input': "requestServiceIssues";
        readonly 'requestService.requests.doc.processing': "requestServiceIssues";
        readonly 'requestService.requests.doc.output': "requestServiceIssues";
        readonly 'requestService.requests.params': "requestServiceIssues";
        readonly 'requestService.requests.params.name': "requestServiceIssues";
        readonly 'requestService.requests.params.target': "requestServiceIssues";
        readonly 'requestService.requests.params.field': "requestServiceIssues";
        readonly 'requestService.requests.params.pages': "requestServiceIssues";
        readonly 'accessScope.scopeId': "accessScopeIssues";
        readonly 'accessScope.grants': "accessScopeIssues";
        readonly 'accessScope.grants.grantId': "accessScopeIssues";
        readonly 'accessScope.grants.actorRef': "accessScopeIssues";
        readonly 'accessScope.grants.anchorEntity': "accessAnchorIssues";
        readonly 'accessScope.grants.entityRefs': "accessAnchorIssues";
        readonly 'accessScope.grants.disclosure': "accessScopeIssues";
        readonly 'accessScope.grants.allowedFields': "accessScopeIssues";
        readonly 'accessScope.grants.scopeMode': "accessScopeIssues";
        readonly 'accessScope.grants.session': "accessScopeIssues";
        readonly 'accessScope.grants.path': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.entityId': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.relationshipId': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.from': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.to': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.field': "accessScopeIssues";
        readonly 'accessScope.grants.path.pending': "accessScopeIssues";
        readonly 'accessScope.grants.pending': "accessScopeIssues";
        readonly 'authorityMap.mapId': "authorityMapIssues";
        readonly 'authorityMap.entries': "authorityMapIssues";
        readonly 'authorityMap.entries.grantId': "authorityGrantIssues";
        readonly 'authorityMap.entries.actorRef': "authorityMapIssues";
        readonly 'repositoryRegistration.registrationId': "registrationIssues";
        readonly 'repositoryRegistration.adapters': "registrationIssues";
        readonly 'repositoryRegistration.adapters.portId': "registrationIssues";
        readonly 'repositoryRegistration.adapters.adapterArtifactId': "registrationIssues";
        readonly 'persistenceSeeds.seedId': "seedScenarioIssues";
        readonly 'persistenceSeeds.phase': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.scenarioId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.source': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.constraints': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.field': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.relationshipId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.states': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.requires': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.entityId': "seedUses";
        readonly 'persistenceSeeds.scenarios.stateField': "seedUses";
        readonly 'persistenceSeeds.dependencies': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.kind': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.seeded': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.datasetId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.owners': "seedScenarioIssues";
        readonly 'integrationOutbound.integrationId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.eventId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.on': "integrationLinkIssues";
        readonly 'integrationOutbound.events.entityId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.mechanism': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.consumer': "integrationLinkIssues";
        readonly 'integrationOutbound.events.mechanismRef': "integrationMechanismIssues";
        readonly 'integrationOutbound.inbound': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.inboundId': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.pluginId': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.itemId': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.kind': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.code': "integrationCoverageIssues";
        readonly 'workflowProcess.processId': "workflowProcessIssues";
        readonly 'workflowProcess.trigger': "workflowProcessIssues";
        readonly 'workflowProcess.trigger.kind': "workflowProcessIssues";
        readonly 'workflowProcess.trigger.actorRef': "workflowProcessIssues";
        readonly 'workflowProcess.trigger.event': "workflowProcessIssues";
        readonly 'workflowProcess.trigger.schedule': "workflowProcessIssues";
        readonly 'workflowProcess.occurrence': "workflowProcessIssues";
        readonly 'workflowProcess.occurrence.entityId': "workflowProcessIssues";
        readonly 'workflowProcess.functions': "workflowProcessIssues";
        readonly 'workflowProcess.operations': "workflowProcessIssues";
        readonly 'workflowProcess.operations.operation': "workflowProcessIssues";
        readonly 'workflowProcess.operations.steps': "workflowProcessIssues";
        readonly 'pipelineItem.id': "pipelineItemIssues";
        readonly 'pipelineItem.type': "pipelineItemIssues";
        readonly 'pipelineItem.defPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputAvailability': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsFiles': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsOn': "catalogIssues";
        readonly 'pipelineItem.skills': "skillRefIssues";
        readonly 'pipelineItem.routes': "duplicateRouteIssues";
        readonly 'catalog.schemaVersion': "coverageReport";
        readonly 'catalog.project': "coverageReport";
        readonly 'catalog.moduleName': "coverageReport";
        readonly 'catalog.items': "coverageReport";
        readonly 'catalog.presentPaths': "resolveCatalogRefs";
        readonly 'catalog.justifications': "coverageReport";
        readonly 'catalog.justifications.id': "coverageReport";
        readonly 'catalog.justifications.artifactType': "coverageReport";
        readonly 'catalog.justifications.reason': "coverageReport";
        readonly 'catalog.absences': "coverageReport";
        readonly 'catalog.absences.artifactType': "coverageReport";
        readonly 'catalog.absences.reason': "coverageReport";
    };
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Write" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    export interface D1Rendered {
        source: string;
        file: D1FileInfo;
    }
    /**
     * The file identity of a def. Qualified `_project_/l1/...` and logical `l1/...`
     * both go through fileInfoFromDisplay, which is the same parser input20 uses.
     */
    export function artifactFile(project: number, defPath: string): D1FileInfo | null;
    /**
     * Reads the v2 definition. A pipeline or agent export is refused: null, not a
     * silent drop of the second value.
     */
    export function parseRendered(source: string): {
        definition: unknown;
    } | null;
    /**
     * Definition object even when a legacy pipeline export follows it.
     * The pipeline export stays illegal. Callers that need v2 use parseRendered.
     */
    export function readDefinitionExport(source: string): {
        definition: unknown;
        pipelineExport: boolean;
    } | null;
    /** Paths a file declares. v2 uses definition.dependencies. A legacy export's dependsFiles is only a fallback. */
    export function declaredDependencyPaths(source: string): string[];
    /**
     * Files the def actually consumes. Qualified `_NNNNN_/lN/...`, sorted, unique.
     * A logical `lN/...` path is qualified with this project. `mls-NNNNN/...` keeps
     * the project named in the path. A fragment after `#` is not a file.
     */
    export function consumedDependencies(project: number, paths: readonly string[]): string[];
    export function qualifyConsumed(project: number, path: string): string;
    /** Copies consumed files onto the definition. Skills and output paths stay out of the file. */
    export function stampDefinition(definition: D1Definition, defPath: string, paths: readonly string[]): D1Definition;
    /**
     * Renders one v2 defs file. No pipeline export. Issues keep the value intact.
     */
    export function renderDefinition(definition: D1Definition, defPath: string): {
        source: string;
    } | {
        issues: string[];
    };
    export function collisionIssues(defPaths: readonly string[]): string[];
    /**
     * Gate then write. A collision or a definition issue writes nothing.
     * The file passed to writeText is artifactFile, the same identity a later remove must use.
     */
    export function persistDefinitions(project: number, parts: readonly {
        definition: D1Definition;
        defPath: string;
    }[]): Promise<{
        written: D1FileInfo[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Receipt" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export const D1_PROGRESS_SCHEMA: "2026-09-22-d1-progress-v1";
    export interface D1WriterReceipt {
        defPath: string;
        desiredHash: string;
    }
    export interface D1UnitPart {
        defPath: string;
        source: string;
        action?: 'write' | 'remove';
        /** Inventoried hash. Empty when this file has no receipt. */
        receiptHash?: string;
        outputTs?: readonly string[];
        /** Present when the def status is blocked. Written beside the def, not inside it. */
        blockReason?: string;
    }
    export interface D1FileProgress {
        defPath: string;
        action: 'write' | 'remove';
        previousHash: string;
        desiredHash: string;
        status: 'pending' | 'done' | 'conflict';
        outputTs: string[];
    }
    /**
     * Recovery record for one unit. `transaction` is false because stor has no
     * multi-file transaction and no compare-and-swap. mtime is not a version.
     */
    export interface D1UnitProgress {
        schemaVersion: typeof D1_PROGRESS_SCHEMA;
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        runId: string;
        snapshotHash: string;
        draftHash: string;
        transaction: false;
        finalized: boolean;
        invalidated: boolean;
        reported: string[];
        files: D1FileProgress[];
        issues: string[];
    }
    export interface D1CommitUnitInput {
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        draftText: string;
        parts: readonly D1UnitPart[];
        runId?: string;
        snapshotHash?: string;
        /** Test seam. Throws after this many product mutations. */
        failAfterMutations?: number;
        /** Test seam. Runs immediately before the hash is read again. */
        beforeMutate?: (index: number) => Promise<void>;
    }
    export interface D1CommitUnitResult {
        written: string[];
        removed: string[];
        reported: string[];
        issues: string[];
        finalized: boolean;
        invalidated: boolean;
    }
    export interface D1FingerprintEntry {
        key: string;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        hidden: boolean;
        sha256: string;
        mtime: string;
        status: string;
    }
    export function progressFile(project: number, moduleName: string, step: string, unitId: string): D1FileInfo;
    export function logicalDefPath(defPath: string): string;
    /**
     * True only when every product file of this unit still matches the progress
     * hashes. A checkpoint status of completed is not read and is not proof.
     */
    export function unitIsIntact(project: number, moduleName: string, step: string, unitId: string, snapshotHash: string): Promise<boolean>;
    export function commitD1Unit(input: D1CommitUnitInput): Promise<D1CommitUnitResult>;
    /** Every file in this project, including hidden names. mtime is recorded, not trusted. */
    export function fingerprintProject(project: number): Promise<D1FingerprintEntry[]>;
    /**
     * Paths whose bytes, mtime or status changed outside `l1/<module>` product
     * defs and `l1/<module>/pipeline/agentDefsL1`. The planner pipeline is outside.
     */
    export function outsideOwnedWrites(before: readonly D1FingerprintEntry[], after: readonly D1FingerprintEntry[], moduleName: string): string[];
    export function readWriterReceipts(project: number, moduleName: string): Promise<D1WriterReceipt[]>;
}
declare module "_102020_/l2/helpers/contractV2/types" {
    export interface D2ContractV2Location {
        project: number;
        module: string;
        pageId: string;
    }
    export interface D2ContractV2Projection {
        name: string;
        entityId: string;
        requestIds: string[];
        body: string;
        /** The comment above the interface (d2_78). */
        jsdoc?: string;
        /** The fields of the body, one per line, with readonly exposed (d2_78). */
        fields?: Array<{
            name: string;
            type: string;
            optional: boolean;
            readonly: boolean;
        }>;
    }
    /** The comment above a route (d2_78): the four sections when their labels are recognized, always the raw text. */
    export interface D2ContractV2Jsdoc {
        raw: string;
        purpose?: string;
        input?: string;
        processing?: string;
        output?: string;
    }
    export interface D2ContractV2MetaOutput {
        entity: string;
        many: boolean;
    }
    export interface D2ContractV2MetaList {
        key: string;
        page: string;
        pageSize: string;
        hasMore: string;
    }
    export interface D2ContractV2MetaParamFilter {
        filters: string;
        field: string;
    }
    export interface D2ContractV2MetaParamPage {
        pages: string;
    }
    export type D2ContractV2MetaParam = D2ContractV2MetaParamFilter | D2ContractV2MetaParamPage;
    export interface D2ContractV2Meta {
        output: Record<string, D2ContractV2MetaOutput>;
        lists: Record<string, D2ContractV2MetaList>;
        params: Record<string, D2ContractV2MetaParam>;
    }
    export interface D2ContractV2Route {
        route: string;
        kind: 'qry' | 'cmd';
        writes?: string;
        input: string;
        output: string;
        /**
         * Empty in the contract of the BFF per page (d2_78): the contract says what the page needs, not where it comes from.
         * An empty meta is not rendered, and a route without one parses as empty (the L1 readers keep compiling).
         */
        meta: D2ContractV2Meta;
        jsdoc?: D2ContractV2Jsdoc;
        rules: string[];
        access: {
            actors: string[];
            grants: string[];
            scope: string;
        };
    }
    export interface D2ContractV2Definition {
        module: string;
        pageId: string;
        projections: D2ContractV2Projection[];
        routes: D2ContractV2Route[];
    }
}
declare module "_102020_/l2/helpers/contractV2/render" {
    import type { D2ContractV2Definition, D2ContractV2Location } from "_102020_/l2/helpers/contractV2/types";
    export function renderD2ContractV2(location: D2ContractV2Location, definition: D2ContractV2Definition): string;
    export function parseD2ContractV2(source: string): D2ContractV2Definition;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/contracts" {
    import type { RequestDoc, RequestOutputNode } from "_102021_/l2/helpers/l1Defs/requestTree";
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1ActiveStatus, D1RequestComputedBy, D1RequestOutput, D1RequestUnresolved } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export const D1_CONTROLLER_VERSION: "2026-10-01-d1-controllers-adapter";
    /** Same trail as domain30 and usecases50. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Controller projection has no values slot. Enum values stay on the domain draft.";
    export const HANDLER_STEPS: readonly ["transport", "session", "authorize", "call", "project", "bff"];
    export interface D1ControllerProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1ControllerNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ControllerEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1ControllerPage {
        pageId: string;
        actors: string[];
        defPath: string;
    }
    export interface D1ControllerRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
        status: string;
    }
    export interface D1ControllerUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        /** Copied from `selection.usecases[].status`. */
        status: D1ActiveStatus;
        functionName: string;
        defPath: string;
    }
    export interface D1ControllerGrant {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        scopeMode: string;
    }
    export interface D1ControllerRelationship {
        relationshipId: string;
        from: string;
        to: string;
        /** Copied from the relationship. Empty when the relationship declares none. */
        field: string;
        required: boolean;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1ExistingHandler {
        route: string;
        kind: 'query' | 'command';
        usecaseId: string;
        /** Request route this handler calls. Absent on a v1 usecase handler. */
        serviceFunction?: string;
        grantIds: string[];
    }
    /** A controller file already on disk. Parsed, never evaluated. */
    export interface D1ExistingController {
        pageId: string;
        routes: string[];
        handlers: D1ExistingHandler[];
        unreadable: boolean;
    }
    export interface D1EnumerationRef {
        entityId: string;
        path: string;
        values: string[];
    }
    /** One selected contract request. `uses` names usecase ids already in the pool. */
    export interface D1ServiceRequestSource {
        route: string;
        pageId: string;
        kind: 'qry' | 'cmd';
        uses: string[];
        /** The derived outputs (d1_62): the classification says which projected fields are entity fields. */
        outputs: Array<Pick<D1RequestOutput, 'key' | 'entity' | 'many' | 'parent' | 'relationship' | 'computed' | 'related' | 'mapped' | 'page' | 'pageSize' | 'hasMore' | 'total'>>;
        params: Array<{
            name: string;
            target: string;
            field?: string;
            pages?: string;
            optional?: boolean;
        }>;
        /** Readonly values a resolution tied to a route rule (d1_62). */
        computedBy?: D1RequestComputedBy[];
        /** What the derivation left open (d1_60). The `output.` ones become `unresolved` nodes of the tree (d1_61). */
        unresolved?: Array<Pick<D1RequestUnresolved, 'path' | 'reason'>>;
    }
    export interface D1ServiceParam {
        name: string;
        target: string;
        field?: string;
        pages?: string;
        /** Present when the contract input is optional. A required param omits it. */
        optional?: boolean;
    }
    export interface D1ServiceRow {
        route: string;
        kind: 'qry' | 'cmd';
        uses: string[];
        transaction: 'single' | 'none';
        /** The classified output tree (d1_61). It replaces the flat `outputs` of earlier defs. */
        output: RequestOutputNode[];
        params: D1ServiceParam[];
        /** The contract route rules. */
        rules: string[];
        /** The route JSDoc the contract parser read. Absent when the route has none. */
        doc?: RequestDoc;
    }
    export interface D1RequestServiceItem {
        pageId: string;
        defPath: string;
        requests: D1ServiceRow[];
        definition: D1Definition | null;
    }
    export interface D1ControllerRequest {
        project: number;
        moduleName: string;
        pages: D1ControllerPage[];
        usecases: D1ControllerUsecase[];
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        contracts: D1ContractSource[];
        existing: D1ExistingController[];
        enumerations: D1EnumerationRef[];
        accessRead: boolean;
        actorsRead: boolean;
        /** Routes selected for removal. Absent means none. */
        removedRoutes?: readonly D1RemovedRoute[];
        /** Contract v2 requests. Absent on a v1 plan. */
        serviceRequests?: readonly D1ServiceRequestSource[];
        /** Ontology entities keyed by entity id. Absent when the plan has no v2 request. */
        ontology?: Readonly<Record<string, unknown>>;
    }
    export interface D1ScopeRelationship {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Scope plan support70 will emit. The anchor is the one the access artifact declared. */
    export interface D1ScopeGrantPlan {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        relationships: D1ScopeRelationship[];
        pending: string;
        emittedBy: 'support70';
    }
    export interface D1HandlerProjection {
        shape: 'array' | 'object' | 'unresolved';
        fields: string[];
        envelope: 'passthrough';
    }
    export interface D1HandlerBinding {
        route: string;
        pageId: string;
        kind: 'query' | 'command';
        /** Empty when the handler calls the request service instead of a usecase. */
        usecaseId: string;
        functionName: string;
        /** Request route of this page's service. Empty on a v1 binding. */
        serviceFunction: string;
        contractPath: string;
        /** `<Page>Contracts`. Empty on a v1 binding. Not an Input or Output symbol. */
        contractInterface: string;
        inputSymbol: string;
        outputSymbol: string;
        status: string;
        preserved: boolean;
        grantIds: string[];
        projection: D1HandlerProjection;
        session: 'verified';
        steps: typeof HANDLER_STEPS;
        scopePlan: D1ScopeGrantPlan[];
    }
    export interface D1ControllerItem {
        pageId: string;
        defPath: string;
        handlers: D1HandlerBinding[];
        staleRoutes: string[];
        definition: D1Definition | null;
    }
    export interface D1ControllerEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    /** A selected route to drop. Other routes of the same controller stay. */
    export interface D1RemovedRoute {
        route: string;
        pageId: string;
        defPath: string;
        contentHash: string;
    }
    /** Own controller def removed only when the page has no live route left. */
    export interface D1ControllerRemoval {
        defPath: string;
        contentHash: string;
        outputTs: string[];
    }
    export interface D1ControllerBuild {
        schemaVersion: typeof D1_CONTROLLER_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        measuredRoutes: number;
        measuredPages: number;
        enumerations: D1ControllerEnumeration[];
        controllers: D1ControllerItem[];
        services: D1RequestServiceItem[];
        problems: D1ControllerProblem[];
        normalizations: D1ControllerNormalization[];
        emit: D1ControllerEmit[];
        /** Controller defs with no live route. The `.ts` path is reported, not deleted. */
        removals: D1ControllerRemoval[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/requestService" {
    import type { D2ContractV2Definition } from "_102020_/l2/helpers/contractV2/types";
    import type { D1SelectedRequest } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ControllerProblem, D1ControllerRequest, D1ServiceRequestSource, D1ServiceRow } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export interface RequestServiceCheck {
        pageId: string;
        contractRoutes: readonly string[];
        requests: readonly D1ServiceRow[];
        usecaseIds: ReadonlySet<string>;
        fieldsByEntity: ReadonlyMap<string, ReadonlySet<string>>;
        /** Selected rows per route. Defaults to the built rows. */
        selectedCounts?: ReadonlyMap<string, number>;
        /**
         * `fields` checks the rows already built. `handlers` checks route coverage and dispenses a route
         * gap (s0b), so it runs after authority has marked those rows. Default `all`.
         */
        part?: 'fields' | 'handlers' | 'all';
    }
    /** The controllers60 view of one selected request: the derived outputs with their classification, and the params. */
    export function serviceSourceOf(request: D1SelectedRequest): D1ServiceRequestSource;
    /**
     * A route the controller must not handle (s0b): authority or access failed, so the request service
     * carries one `unresolved` node whose path is the route. The handler check dispenses that route.
     */
    export function isRouteGap(row: {
        route: string;
        output: readonly {
            kind: string;
            path: string;
        }[];
    }): boolean;
    /** Leaf paths of a contract interface body. Containers are not paths. */
    export function interfaceFieldPaths(body: string): string[] | null;
    /** Dotted paths of an ontology entity, including object nodes. */
    export function ontologyFieldPaths(entity: unknown): string[];
    /**
     * Each contract route has one request. Every `uses` id is a usecase def.
     * Each projected path is a field of that output's entity. A command is `single`.
     */
    export function requestServiceProblems(input: RequestServiceCheck): D1ControllerProblem[];
    export function serviceRowsFor(pageId: string, definition: D2ContractV2Definition, selected: readonly D1ServiceRequestSource[]): {
        routes: string[];
        rows: D1ServiceRow[];
        problems: D1ControllerProblem[];
    };
    export function fieldsByEntity(ontology: Readonly<Record<string, unknown>>): Map<string, Set<string>>;
    export function usecaseIdsWithDef(request: D1ControllerRequest): Set<string>;
    export function readContractV2(source: string): D2ContractV2Definition | null;
    /** The one `export interface <Page>Contracts` in a v2 file. Empty when it is missing or repeated. */
    export function contractInterfaceName(source: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/deriveRequest" {
    import type { D2ContractV2Definition, D2ContractV2Route } from "_102020_/l2/helpers/contractV2/types";
    import { type D1RequestComputedBy, type D1RequestGapAnswer, type D1RequestOutput, type D1RequestParam, type D1RequestUnresolved } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export interface D1DerivedRequest {
        outputs: D1RequestOutput[];
        params: D1RequestParam[];
        unresolved: D1RequestUnresolved[];
        /** Readonly values tied to a route rule by an answer (d1_62). */
        computedBy: D1RequestComputedBy[];
    }
    /** What `applyResolutions` derives from: the route, its contract and the module ontology. */
    export interface D1DeriveSource {
        route: D2ContractV2Route;
        definition: D2ContractV2Definition;
        entities: Readonly<Record<string, unknown>>;
    }
    export function deriveRequest(route: D2ContractV2Route, definition: D2ContractV2Definition, entities: Readonly<Record<string, unknown>>): D1DerivedRequest;
    /** The route derived again with the answers as input. The one selection the input20 uses (d1_62). */
    export function applyResolutions(source: D1DeriveSource, answers: readonly D1RequestGapAnswer[]): D1DerivedRequest;
}
declare module "_102035_/l2/solution/poolPlan" {
    /**
     * One type per plan file of the pool (the pool contract is the l4's): the shape each producer writes today.
     * Producers and readers import from here; a reader that ignores fields uses `Pick`, a reader that
     * normalizes from disk uses `PoolRaw`. A field only one side declares stays out and is a divergence.
     *
     * - `pool/l2/web/menu.json`   — producer agentPlannerL2 menu20
     * - `pool/l1/web/needs.json`  — producer agentPlannerL2 needs30
     * - `pool/l2/web/backend.json` — producer agentPlannerL1 plan20
     * - `pool/l2/web/effort.json` — producer agentPlannerL2 effort40
     * - `pool/l4/l4diff.json` — producer agentPlannerL4 plDiff
     * - `pool/l4/changeEffort.json` — producer agentPlannerL4 (p4_34)
     */
    /** A plan file as read from disk, before the reader's own normalization: known keys, unknown values. */
    export type PoolRaw<T> = {
        [K in keyof T]?: unknown;
    };
    export const POOL_DEVICES: readonly ["web"];
    export type PoolDevice = typeof POOL_DEVICES[number];
    /** Plan status shared by backend.json and effort.json. */
    export const POOL_PLAN_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export type PoolPlanStatus = typeof POOL_PLAN_STATUSES[number];
    /** Endpoint kind shared by backend.json and effort.json. */
    export const POOL_ENDPOINT_KINDS: readonly ["qry", "cmd"];
    export type PoolEndpointKind = typeof POOL_ENDPOINT_KINDS[number];
    export const POOL_TEST_SUPPORT_OWNERS: readonly ["L1", "runtime"];
    export type PoolTestSupportOwner = typeof POOL_TEST_SUPPORT_OWNERS[number];
    export const MENU_SCHEMA_VERSION: "2026-09-20-p2-menu-v2.2";
    export const MENU_NODE_KINDS: readonly ["hub", "page", "group"];
    export type MenuNodeKind = typeof MENU_NODE_KINDS[number];
    export const MENU_ORGANISM_KINDS: readonly ["list", "detail", "form", "summary", "highlights", "timeline", "actions", "inbox", "alerts"];
    export type MenuOrganismKind = typeof MENU_ORGANISM_KINDS[number];
    export const MENU_ACTIONS: readonly ["new", "change", "keep", "remove"];
    export type MenuAction = typeof MENU_ACTIONS[number];
    export const MENU_PLACEMENTS: readonly ["screenAction", "menuItem", "listWithAdd"];
    export type MenuPlacementKind = typeof MENU_PLACEMENTS[number];
    /** One place for a journey × actor pair. Read by finalize70. */
    export interface MenuPlacement {
        journeyId: string;
        actorRef: string;
        placement: MenuPlacementKind;
        pageId: string;
        reason: string;
    }
    export interface MenuOrganism {
        kind: MenuOrganismKind;
        text: string;
    }
    export interface MenuHubNode {
        id: string;
        kind: 'hub';
        label: string;
        context: string;
        text: string;
        children: MenuNode[];
    }
    export interface MenuPageNode {
        id: string;
        kind: 'page';
        label: string;
        organisms: MenuOrganism[];
        /** Lucide icon name. `""` or absent means no icon. Read by finalize70. */
        icon?: string;
    }
    export interface MenuGroupNode {
        id: string;
        kind: 'group';
        label: string;
        text: string;
        children: MenuNode[];
    }
    export type MenuNode = MenuHubNode | MenuPageNode | MenuGroupNode;
    export type MenuStampedHubNode = Omit<MenuHubNode, 'children'> & {
        action: MenuAction;
        children: MenuStampedNode[];
    };
    export type MenuStampedPageNode = MenuPageNode & {
        action: MenuAction;
    };
    export type MenuStampedGroupNode = Omit<MenuGroupNode, 'children'> & {
        action: MenuAction;
        children: MenuStampedNode[];
    };
    export type MenuStampedNode = MenuStampedHubNode | MenuStampedPageNode | MenuStampedGroupNode;
    export interface PoolMenuMeta {
        journeys: Record<string, string[]>;
        processes: Record<string, string[]>;
        /** Kept record (entityId from recordsKept) → pages that maintain it. Read by needs30. */
        records: Record<string, string[]>;
        /** One place per journey × actor. Optional so a menu written before this field still parses. Read by finalize70. */
        placements?: MenuPlacement[];
    }
    export interface PoolMenuFileMeta extends PoolMenuMeta {
        removed: MenuStampedNode[];
    }
    export interface PoolMenuFile {
        schemaVersion: typeof MENU_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        device: PoolDevice;
        tree: MenuStampedNode[];
        authorities: Record<string, string[]>;
        meta: PoolMenuFileMeta;
    }
    export const POOL_NEEDS_SCHEMA_VERSION: "2026-09-21-p2-needs-v1";
    export const POOL_NEEDS_OPERATIONS: readonly ["create", "update", "transition", "delete"];
    export type PoolNeedsOperation = typeof POOL_NEEDS_OPERATIONS[number];
    export const POOL_NEEDS_SCOPES: readonly ["own", "related", "organization"];
    export type PoolNeedsScope = typeof POOL_NEEDS_SCOPES[number];
    export const POOL_NEEDS_FAMILIES: readonly ["mdm", "ddm", "tdm"];
    export type PoolNeedsFamily = typeof POOL_NEEDS_FAMILIES[number];
    export interface PoolNeedsRead {
        entity: string;
        family: PoolNeedsFamily;
        scope: PoolNeedsScope;
        derived: string[];
        from: string[];
    }
    export interface PoolNeedsWrite {
        entity: string;
        operation: PoolNeedsOperation;
        transitionRef: string;
        from: string[];
    }
    export interface PoolNeedsPage {
        pageId: string;
        actors: string[];
        reads: PoolNeedsRead[];
        writes: PoolNeedsWrite[];
    }
    export interface PoolNeedsFile {
        schemaVersion: typeof POOL_NEEDS_SCHEMA_VERSION;
        moduleName: string;
        device: PoolDevice;
        menuSchema: typeof MENU_SCHEMA_VERSION;
        pages: PoolNeedsPage[];
        meta: {
            sourceMenu: string;
            generatedAt: string;
        };
    }
    export const POOL_BACKEND_SCHEMA_VERSION: "2026-09-21-p1-backend-v1.2";
    export const POOL_BACKEND_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export type PoolBackendOperation = typeof POOL_BACKEND_OPERATIONS[number];
    export const POOL_BACKEND_REMOVED_KINDS: readonly ["usecase", "port", "table"];
    export type PoolBackendRemovedKind = typeof POOL_BACKEND_REMOVED_KINDS[number];
    export const POOL_NO_TABLE: readonly ["ok", "mdm", "none"];
    export type PoolNoTable = typeof POOL_NO_TABLE[number];
    export const POOL_CHANGE_KINDS: readonly ["field", "rule", "grant", "transition", "process", "integration", "entity"];
    export type PoolChangeKind = typeof POOL_CHANGE_KINDS[number];
    export const POOL_CHANGE_OPS: readonly ["added", "changed", "removed"];
    export type PoolChangeOp = typeof POOL_CHANGE_OPS[number];
    /**
     * One unit of test preparation (data, identity, cleanup). Not a grant nor a rule.
     * `executorRef` / `cleanupRef` stay `''` until an owner references a verified capability;
     * then `gap` names what is missing. Same item in backend.json and effort.json.
     */
    export interface PoolTestSupportItem {
        id: string;
        actorRefs: string[];
        entityRefs: string[];
        sourceRefs: string[];
        status: PoolPlanStatus;
        owner: PoolTestSupportOwner;
        executorRef: string;
        cleanupRef: string;
        gap: string;
    }
    export interface PoolBackendEndpoint {
        route: string;
        page: string;
        kind: PoolEndpointKind;
        usecaseRef: string;
        status: PoolPlanStatus;
        tableRefs: string[];
        noTable: PoolNoTable;
    }
    export interface PoolBackendUsecase {
        usecaseId: string;
        entity: string;
        operation: PoolBackendOperation;
        /** L4 `transitionId`. Present only when `operation` is `transition`. */
        transitionRef?: string;
        ports: string[];
        status: PoolPlanStatus;
        existing: string;
        reason: string;
        tableRefs: string[];
        noTable: PoolNoTable;
    }
    export interface PoolBackendPort {
        portId: string;
        entity: string;
        status: PoolPlanStatus;
        tableRefs: string[];
        noTable: PoolNoTable;
    }
    export interface PoolBackendTable {
        tableId: string;
        entity: string;
        status: PoolPlanStatus;
        tableRefs: string[];
        noTable: PoolNoTable;
    }
    export interface PoolBackendRemoved {
        kind: PoolBackendRemovedKind;
        id: string;
        status: 'toRemove';
        reason: string;
        tableRefs: string[];
        noTable: PoolNoTable;
    }
    export interface PoolBackendChange {
        changeId: string;
        kind: PoolChangeKind;
        op: PoolChangeOp;
        entity: string;
        tableRefs: string[];
        noTable: PoolNoTable;
        usecaseRefs: string[];
        reason: string;
        source: string;
    }
    export interface PoolUnmappedChange {
        changeId: string;
        kind: string;
        source: string;
    }
    export interface PoolBackendFile {
        schemaVersion: typeof POOL_BACKEND_SCHEMA_VERSION;
        moduleName: string;
        device: PoolDevice;
        sourceNeeds: string;
        inventoryPresent: boolean;
        endpoints: PoolBackendEndpoint[];
        usecases: PoolBackendUsecase[];
        ports: PoolBackendPort[];
        tables: PoolBackendTable[];
        removed: PoolBackendRemoved[];
        changes: PoolBackendChange[];
        testSupport: PoolTestSupportItem[];
        meta: {
            pages: Record<string, string[]>;
            generatedAt: string;
            llmCalled: boolean;
            unmappedChanges: PoolUnmappedChange[];
        };
    }
    export const POOL_EFFORT_SCHEMA_VERSION: "2026-09-21-p2-effort-v1.2";
    export const POOL_EFFORT_REMOVED_KINDS: readonly ["endpoint", "usecase", "table"];
    export type PoolEffortRemovedKind = typeof POOL_EFFORT_REMOVED_KINDS[number];
    export interface PoolEffortTotalsBucket {
        toCreate: number;
        toUpdate: number;
        toRemove: number;
        done: number;
    }
    export interface PoolEffortTotals {
        screens: PoolEffortTotalsBucket;
        endpoints: PoolEffortTotalsBucket;
        usecases: PoolEffortTotalsBucket;
        tables: PoolEffortTotalsBucket;
    }
    export interface PoolEffortScreen {
        pageId: string;
        label: string;
        actors: string[];
        status: PoolPlanStatus;
        endpoints: string[];
    }
    export interface PoolEffortEndpoint {
        route: string;
        page: string;
        kind: PoolEndpointKind;
        usecaseRef: string;
        status: PoolPlanStatus;
    }
    export interface PoolEffortUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        status: PoolPlanStatus;
        existing: string;
    }
    export interface PoolEffortTable {
        tableId: string;
        entity: string;
        status: PoolPlanStatus;
    }
    export interface PoolEffortRemoved {
        kind: PoolEffortRemovedKind;
        id: string;
        status: 'toRemove';
    }
    /** l4diff item that did not reach any page. Reader: the person, in this JSON. */
    export interface PoolEffortUnattributed {
        changeId: string;
        kind: string;
        op: string;
        reason: string;
    }
    export interface PoolEffortFile {
        schemaVersion: typeof POOL_EFFORT_SCHEMA_VERSION;
        moduleName: string;
        device: PoolDevice;
        totals: PoolEffortTotals;
        screens: PoolEffortScreen[];
        endpoints: PoolEffortEndpoint[];
        usecases: PoolEffortUsecase[];
        tables: PoolEffortTable[];
        removed: PoolEffortRemoved[];
        testSupport: PoolTestSupportItem[];
        unattributed: PoolEffortUnattributed[];
        meta: {
            sourceMenu: string;
            sourceBackend: string;
            sourceVersion: string;
            generatedAt: string;
        };
    }
    /** Identity of a sealed revision, recorded on the L4 pipeline and both l4diff files. */
    export interface PlRevisionIdentity {
        changeId: string;
        revisionId: string;
        baseId: string;
        /** `sha256:` of `manifest.files` JSON with keys sorted. Same digest as `sha256Tobe`. */
        manifestHash: string;
    }
    export const L4_DIFF_SCHEMA: "2026-09-21-p4-l4diff-v1";
    export const L4_DIFF_OPS: readonly ["added", "changed", "removed"];
    export type L4DiffOp = (typeof L4_DIFF_OPS)[number];
    export const L4_DIFF_KINDS: readonly ["entity", "field", "transition", "rule", "grant", "process", "task", "inbound", "outbound", "journey", "step", "artifact"];
    export type L4DiffKind = (typeof L4_DIFF_KINDS)[number];
    export interface L4DiffItem {
        changeId: string;
        kind: L4DiffKind;
        op: L4DiffOp;
        entity: string;
        source: string;
        before?: unknown;
        after?: unknown;
    }
    /**
     * Prose on a v3 field and on an enum value (`Ns5OntologyFieldV3` / `Ns5OntologyValueV3`):
     * `title` and `description` only. `type`, `derived`, `required` and the value code are not text.
     * `values` is not in this list: a label edit is text, an added or removed code is not.
     * `icon` is presentation (Lucide name on a journey, a step or a workflow task). `decisionRef` is not text.
     */
    export const L4_TEXT_ATTRIBUTES: readonly ["title", "description", "icon"];
    export type L4TextAttribute = (typeof L4_TEXT_ATTRIBUTES)[number];
    /**
     * True when every difference on a `changed` item is text (`title` / `description` / `icon`, or an enum label).
     * A `rule` is never text: its description is the rule. Any other key is not text.
     */
    export function isTextOnlyChange(item: L4DiffItem): boolean;
    /**
     * A `changed` journey, step or workflow task whose only differing attribute is `icon`.
     * Text, `decisionRef` or any other key keeps the item on the master path. Added and removed never qualify.
     */
    export function isPresentationOnlyChange(item: L4DiffItem): boolean;
    export interface L4Diff {
        schemaVersion: typeof L4_DIFF_SCHEMA;
        moduleName: string;
        base: string;
        candidate: string;
        /** Null on a canonical run and on a manual root (`tobe/plan`). */
        revision: PlRevisionIdentity | null;
        items: L4DiffItem[];
    }
    export const CHANGE_EFFORT_SCHEMA_VERSION: "2026-10-25-p4-change-effort-v2";
    export const EFFORT_UNIT_KINDS: readonly ["page", "route", "usecase", "entity", "request", "table", "shared", "contract", "workflow", "repository", "authority", "scope", "seeds", "controller", "events"];
    export const EFFORT_MASTER_KINDS: readonly ["l2", "l1"];
    export const EFFORT_ANSWER_STATUSES: readonly ["computed", "abend"];
    export const EFFORT_CONTRACT_VALUES: readonly ["keep", "change"];
    export const CHANGE_EFFORT_STATUSES: readonly ["simple", "contract", "blocked"];
    export interface EffortUnitRef {
        kind: (typeof EFFORT_UNIT_KINDS)[number];
        id: string;
        /** Product def that identifies the unit, relative to the master's project, with the level prefix. Not the materialized file and not a folder. L1: the unit `.defs.ts`. L2 `page`: `l2/<mod>/web/contracts/<pageId>.defs.ts`; shared and page11 follow from `pageId`. */
        path: string;
    }
    export interface EffortAgentRef {
        agent: string;
        command: string;
    }
    export interface EffortMaster {
        project: string;
        kind: (typeof EFFORT_MASTER_KINDS)[number];
        device: PoolDevice;
    }
    /** What each master `describeEffort` receives. How imports this; it does not copy the type. */
    export interface EffortInput {
        module: string;
        base: {
            baseId: string;
            revisionId: string;
        };
        item: L4DiffItem;
    }
    export interface EffortAnswer {
        master: EffortMaster;
        item: string;
        status: (typeof EFFORT_ANSWER_STATUSES)[number];
        create: EffortUnitRef[];
        regenerateDefs: EffortUnitRef[];
        materialize: EffortUnitRef[];
        remove: EffortUnitRef[];
        runAgents: EffortAgentRef[];
        contract: (typeof EFFORT_CONTRACT_VALUES)[number];
        abend?: {
            reason: string;
        };
        /** Set when dispatch skipped both masters because the item is presentation-only (`icon`). */
        presentation?: true;
    }
    /** What a master asks the dispatch to send to the model. `null` from `effortPrompt` means no call. */
    export interface EffortPromptRequest {
        prompt: string;
        schema: object;
    }
    export type EffortPromptFn = (input: EffortInput) => EffortPromptRequest | null | Promise<EffortPromptRequest | null>;
    export type FinishEffortFn = (input: EffortInput, modelOutput: unknown) => EffortAnswer | Promise<EffortAnswer>;
    export interface ChangeEffortMerged {
        create: Array<EffortUnitRef & {
            project: string;
        }>;
        regenerateDefs: Array<EffortUnitRef & {
            project: string;
        }>;
        materialize: Array<EffortUnitRef & {
            project: string;
        }>;
        remove: Array<EffortUnitRef & {
            project: string;
        }>;
        runAgents: EffortAgentRef[];
        abend: Array<{
            item: string;
            master: EffortMaster;
            reason: string;
        }>;
    }
    export interface ChangeEffortFile {
        schemaVersion: typeof CHANGE_EFFORT_SCHEMA_VERSION;
        module: string;
        base: {
            baseId: string;
            revisionId: string;
            candidateRoot: string;
        };
        request: {
            text: string;
            items: L4DiffItem[];
        };
        masters: EffortMaster[];
        perItem: Array<{
            item: string;
            answers: EffortAnswer[];
        }>;
        merged: ChangeEffortMerged;
        untouched: {
            count: number;
            sealHash: string;
        };
        status: (typeof CHANGE_EFFORT_STATUSES)[number];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/input20/gate" {
    import type { D2ContractV2Definition } from "_102020_/l2/helpers/contractV2/types";
    import { type D1ActiveStatus, type D1InputArtifacts, type D1InputSnapshot, type D1RequestGapAnswer } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /**
     * The inventory. `answers` are the resolve25 answers per route (d1_62): without them the requests keep the gaps of
     * the derivation (the input20 view); with them the same derivation gives the final selection (the resolve25 view).
     */
    export function buildD1InputSnapshot(identity: {
        project: number;
        moduleName: string;
    }, artifacts: D1InputArtifacts, previous: D1InputSnapshot | null, answers?: ReadonlyMap<string, readonly D1RequestGapAnswer[]>): D1InputSnapshot;
    export function contractPageIds(artifacts: Pick<D1InputArtifacts, 'menu' | 'needs' | 'effort' | 'backend'>): string[];
    export function readContractV2(texts: Record<string, string> | undefined): Map<string, D2ContractV2Definition>;
    /** `toCreate` over `toUpdate` over `done`. controllers60 applies it per handler. */
    export function worstOfList(statuses: readonly D1ActiveStatus[]): D1ActiveStatus;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1InputArtifacts, type D1InputSnapshot, type D1RequestGapAnswer } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /** Reads the object of `export const name = { ... }` without evaluating the file. */
    export function parseD1Source(text: string, kind: 'json' | 'defs'): unknown | null;
    export function readD1Input(project: number, moduleName: string): Promise<D1InputSnapshot | null>;
    /** The input20 receipt: the snapshot without answers, and the key of its sources (d1_62). */
    export type D1InputDerivation = D1InputSnapshot & {
        sourceKey: string;
    };
    /**
     * Reads the snapshot inputs and returns the inventory. Writes nothing. `previous` is the final `input.json` on disk.
     * Without `answers` it is the input20 view (the gaps stay); with the resolve25 answers it is the final inventory.
     */
    export function assembleD1Input(project: number, moduleName: string, answers?: ReadonlyMap<string, readonly D1RequestGapAnswer[]>): Promise<D1InputSnapshot>;
    /**
     * The same sources input20 reads, as artifacts, without the present defs. A later step compares their digests with
     * the snapshot `sources` to know it reads what input20 sealed (d1_62).
     */
    export function readD1InputArtifacts(project: number, moduleName: string): Promise<D1InputArtifacts>;
    /**
     * The key of the input20 and resolve25 receipts (d1_62): the hash of the snapshot built from the sources alone,
     * without the present defs, the writer receipts, a previous snapshot or answers. Same sources, same key.
     */
    export function d1SourceKey(identity: {
        project: number;
        moduleName: string;
    }, artifacts: D1InputArtifacts): Promise<string>;
    export function readD1Derivation(project: number, moduleName: string): Promise<D1InputDerivation | null>;
    /** Writes `input20.json` unless the same snapshot with the same key is there. */
    export function persistD1Derivation(project: number, moduleName: string, snapshot: D1InputSnapshot, sourceKey: string): Promise<{
        reused: boolean;
    }>;
    export function persistD1Input(project: number, moduleName: string, snapshot: D1InputSnapshot): Promise<{
        reused: boolean;
    }>;
    export function fileInfoFromDisplay(project: number, display: string): D1FileInfo | null;
    export function sha256Text(value: string): Promise<string>;
    export function ownedInputDisplay(project: number, moduleName: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/agentD1Input" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export function beforeD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
    /** Error-severity codes, counts, and up to three ownerRefs. The paths stay in input.json. */
    export function blockingReason(snapshot: Pick<D1InputSnapshot, 'problems'>): string;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Fanout" {
    import { type D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /**
     * Fan-out, barrier and repair of a D1 step that sends one worker per unit to the model (usecases50, resolve25).
     * The step names its unit key; the plan ids, the worker arg and the repair rule are the same for every step.
     */
    export const FANOUT_TITLE = "Generating {{completed}}/{{total}} items, failed {{failed}}";
    export interface D1FanoutConfig {
        stepId: D1StepId;
        /** Arg key that carries the unit id (`usecaseId`, `unitId`). */
        unitKey: string;
        /** Done-anchor the fan-out waits on. */
        after: string;
        /** Plural noun of the trace `queued N <step> <noun>`. */
        noun: string;
        /** Title of the barrier step. */
        barrierTitle: string;
    }
    export interface D1FanoutArg {
        planId: string;
        moduleName: string;
        project: number;
        unitId: string;
        attempt: number;
        unitAttempts: number;
        globalAttempts: number;
        feedback: string;
    }
    export interface D1FanoutAttempt {
        unitId: string;
        status: 'parsed' | 'repairable' | 'operational';
        trace: string;
        unitAttempts: number;
    }
    export interface D1FanoutRepair {
        unitId: string;
        unitAttempts: number;
        globalAttempts: number;
        planId: string;
        feedback: string;
    }
    export interface D1FanoutDecision {
        repairs: D1FanoutRepair[];
        identified: Array<{
            unitId: string;
            trace: string;
            code: string;
        }>;
        pause: boolean;
    }
    /** Compact, stable JSON. One arg is one unit. */
    export function fanoutWorkerArg(config: D1FanoutConfig, arg: D1FanoutArg): string;
    export function parseFanoutWorkerArg(config: D1FanoutConfig, value: string): D1FanoutArg | null;
    export function firstFanoutWorkerArg(config: D1FanoutConfig, project: number, moduleName: string, unitId: string): string;
    /** `round` names a later fan-out of the same step: its plan id must differ, or a barrier that depends on it is unlocked by the first one. */
    export function fanoutStepFor(config: D1FanoutConfig, project: number, moduleName: string, args: readonly string[], round?: string): mls.msg.AIAgentStep;
    export function fanoutExecution(args: readonly string[]): mls.msg.ExecutionMode;
    /**
     * The host marks a parallel parent completed and does not call its afterPrompt.
     * This step depends on the fan-out, so the host unlocks it and runs beforePrompt.
     * A later round depends on the repair plan ids from the round it follows.
     */
    export function barrierStepFor(config: D1FanoutConfig, project: number, moduleName: string, dependsOn: readonly string[], round: string): mls.msg.AIAgentStep;
    /**
     * One repair per unit, and no more than the global ceiling.
     * An operational failure is identified and does not take a repair.
     * A missing trace is still identified.
     */
    export function decideFanoutRepairs(config: D1FanoutConfig, input: {
        expected: readonly string[];
        attempts: readonly D1FanoutAttempt[];
        globalAttempts: number;
        feedbackFor: (unitId: string) => string;
    }): D1FanoutDecision;
    export function repairStepFor(config: D1FanoutConfig, project: number, moduleName: string, order: D1FanoutRepair): mls.msg.AIAgentStep;
    /** A repair for this unit is still open in the task. */
    export function fanoutRepairOpen(config: D1FanoutConfig, context: mls.msg.ExecutionContext, unitId: string): boolean;
    export function isFanoutBarrier(config: D1FanoutConfig, planId: string): boolean;
    export function parseFanoutBarrier(config: D1FanoutConfig, prompt: string): {
        project: number;
        moduleName: string;
    } | null;
    /** The tool reply of a worker step. `key` is the property the reply must carry. */
    export function unwrapToolPayload(step: mls.msg.AIAgentStep, key: string): {
        present: boolean;
        value: unknown;
    };
    export function planIdFromText(prompt: string): string;
    export function addStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIPayload): mls.msg.AgentIntentAddStep;
    export function findOpenParent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep): mls.msg.AIAgentStep;
    export function planPresent(context: mls.msg.ExecutionContext, planId: string): boolean;
    export function findPlanStep(context: mls.msg.ExecutionContext, planId: string): mls.msg.AIAgentStep | null;
    export function allTaskSteps(context: mls.msg.ExecutionContext): mls.msg.AIPayload[];
}
declare module "_102021_/l2/agentDefsL1/steps/resolve25/contracts" {
    import type { D1RequestGapKind } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export const D1_RESOLVE_VERSION: "2026-10-06-d1-resolve-v1";
    /** One derivation gap as the worker sees it. `gapId` is the tool property; `path` is the answer key. */
    export interface D1ResolveGap {
        gapId: string;
        path: string;
        kind: D1RequestGapKind;
        reason: string;
        /** Closed candidates from the derivation, `none` last. */
        candidates: string[];
    }
    /** One route with gaps: one worker. */
    export interface D1ResolveUnit {
        unitId: string;
        route: string;
        pageId: string;
        gaps: D1ResolveGap[];
    }
    export interface D1ResolveWork {
        schemaVersion: typeof D1_RESOLVE_VERSION;
        project: number;
        moduleName: string;
        /** `d1SourceKey` of the sources input20 derived from (d1_62). */
        sourceKey: string;
        units: D1ResolveUnit[];
        repairs: number;
    }
    /** The last attempt of one unit. `answers` holds only the choices that are among the candidates. */
    export interface D1ResolveAttempt {
        unitId: string;
        status: 'parsed' | 'repairable' | 'operational';
        trace: string;
        unitAttempts: number;
        planId: string;
        /** Model calls made for this unit so far (worker plus repair). */
        calls: number;
        answers: Record<string, string>;
    }
    export interface D1ResolveAnswer {
        path: string;
        kind: D1RequestGapKind;
        choice: string;
        /** Plan id of the call that gave the choice. Empty when the gap stayed `none` without an accepted answer. */
        call: string;
        /** Identity of the gap: route, path, kind, reason, candidates sorted. Not a secret. */
        gapKey: string;
    }
    /** `pipeline/agentDefsL1/resolve25.json`. */
    export interface D1ResolveReceipt {
        schemaVersion: typeof D1_RESOLVE_VERSION;
        project: number;
        moduleName: string;
        /** `d1SourceKey` of the sources input20 derived from (d1_62). */
        sourceKey: string;
        llmCalls: number;
        routes: Array<{
            route: string;
            pageId: string;
            answers: D1ResolveAnswer[];
        }>;
    }
}
declare module "_102021_/l2/agentDefsL1/steps/resolve25/gate" {
    import { type D1InputArtifacts, type D1RequestGapAnswer, type D1SourceDigest } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import { type D1ResolveAttempt, type D1ResolveGap, type D1ResolveReceipt, type D1ResolveUnit, type D1ResolveWork } from "_102021_/l2/agentDefsL1/steps/resolve25/contracts";
    /**
     * resolve25 (d1_62). The gaps are the ones the input20 derivation leaves (`deriveRequest`), from the same sources
     * input20 sealed. One unit per route with a gap. The model answers each gap with one of its candidates; the gate
     * accepts only a candidate, and the receipt keeps route, path, choice and call.
     */
    /** Paths whose digest differs between the snapshot and what is read now. Empty means the same sources. */
    export function sourcesDrift(sealed: readonly D1SourceDigest[], now: readonly D1SourceDigest[]): string[];
    /** One unit per contract route the derivation leaves with a gap, in route order. */
    export function resolveUnits(artifacts: Pick<D1InputArtifacts, 'contractTexts' | 'entities'>): D1ResolveUnit[];
    export interface D1ResolveCheck {
        /** Accepted choices by gap id. */
        answers: Record<string, string>;
        /** One line per gap without an accepted choice. Empty is a pass. */
        problems: string[];
    }
    /** The reply `{ answers: { g0: '...', ... } }`. Every gap needs one of its candidates; `none` is a candidate. */
    export function checkResolveReply(unit: D1ResolveUnit, reply: unknown): D1ResolveCheck;
    /**
     * The receipt from the last attempt of each unit. An accepted choice keeps the plan id of its call. A gap with no
     * accepted choice after the repair, or of a unit that failed operationally, is `none` with an empty call.
     */
    export function buildResolveReceipt(work: D1ResolveWork, attempts: readonly D1ResolveAttempt[]): D1ResolveReceipt;
    /**
     * Routes whose every gap still has an answer on the receipt with the same route and the same `gapKey`.
     * The value is the previous choices by gap id. A route with any new or changed gap is left out.
     */
    export function keptRoutes(receipt: D1ResolveReceipt, units: readonly D1ResolveUnit[]): Map<string, Record<string, string>>;
    /**
     * Choices the gate already settled, one list per route, as `applyResolutions` takes them.
     * A gap with no accepted candidate is `none`.
     */
    export function settledGapAnswers(work: D1ResolveWork, attempts: readonly D1ResolveAttempt[]): Map<string, D1RequestGapAnswer[]>;
    /**
     * Gaps `applyResolutions` opens on routes already asked, whose path was not asked yet.
     * A repeated path stays with the choice it has. The caller asks a new path at most once more (d1_91 s2b).
     */
    export function unaskedGaps(artifacts: Pick<D1InputArtifacts, 'contractTexts' | 'entities'>, settled: ReadonlyMap<string, readonly D1RequestGapAnswer[]>, askedPaths: ReadonlyMap<string, ReadonlySet<string>>): Array<{
        route: string;
        pageId: string;
        gaps: Array<Omit<D1ResolveGap, 'gapId'>>;
    }>;
    /**
     * True when every gap `applyResolutions` still opens, with this receipt's choices, is already on the receipt.
     * A choice that closed its gap may stay on the receipt. A new path the choices opened is not covered.
     */
    export function receiptAnswersDerived(receipt: D1ResolveReceipt, artifacts: Pick<D1InputArtifacts, 'contractTexts' | 'entities'>): boolean;
    /** The answers of one route, as `applyResolutions` takes them. No receipt or no route gives none. */
    export function resolveAnswers(receipt: D1ResolveReceipt | null, route: string): D1RequestGapAnswer[];
    /** Every route's answers, as `buildD1InputSnapshot` takes them. No receipt gives no answer. */
    export function answersByRoute(receipt: D1ResolveReceipt | null): Map<string, D1RequestGapAnswer[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/resolve25/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1ResolveAttempt, type D1ResolveReceipt, type D1ResolveWork } from "_102021_/l2/agentDefsL1/steps/resolve25/contracts";
    export function resolveWorkFile(project: number, moduleName: string): D1FileInfo;
    export function resolveAttemptFile(project: number, moduleName: string, unitId: string): D1FileInfo;
    export function writeResolveWork(work: D1ResolveWork): Promise<void>;
    export function readResolveWork(project: number, moduleName: string): Promise<D1ResolveWork | null>;
    export function writeResolveAttempt(project: number, moduleName: string, attempt: D1ResolveAttempt): Promise<void>;
    export function readResolveAttempt(project: number, moduleName: string, unitId: string): Promise<D1ResolveAttempt | null>;
    export function writeResolveReceipt(receipt: D1ResolveReceipt): Promise<void>;
    /** The receipt of this project and module, or null when absent or not this shape. */
    export function readResolveReceipt(project: number, moduleName: string): Promise<D1ResolveReceipt | null>;
}
declare module "_102021_/l2/agentDefsL1/steps/resolve25/worker" {
    import type { D2ContractV2Definition, D2ContractV2Route } from "_102020_/l2/helpers/contractV2/types";
    import type { D1ResolveUnit } from "_102021_/l2/agentDefsL1/steps/resolve25/contracts";
    export const RESOLVE_TOOL_NAME = "resolveRouteGaps";
    /** One property per gap, with its closed candidates as the enum. The model does not write a free name. */
    export function resolveTool(unit: D1ResolveUnit): mls.msg.LLMTool;
    /** The route JSDoc, its input and output types with the interfaces they name, its rules, and the gaps. */
    export function resolveHumanPrompt(input: {
        unit: D1ResolveUnit;
        route: D2ContractV2Route;
        definition: D2ContractV2Definition;
        feedback?: string;
    }): string;
}
declare module "_102021_/l2/agentDefsL1/steps/resolve25/agentD1Resolve" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type D1FanoutConfig } from "_102021_/l2/agentDefsL1/helpers/d1Fanout";
    /**
     * resolve25 (d1_62): between input20 and domain30. No gap, no model call. One worker per route with a gap, on the
     * shared fan-out, barrier and repair (`helpers/d1Fanout.ts`). After that barrier, a route whose accepted answers
     * open a gap that was not asked gets one second round, the same fan-out, gate and repair, and only those gaps
     * (d1_91 s2b). A third new gap is `none`. The receipt `resolve25.json` is keyed by the source key of the input20
     * derivation and keeps both rounds on the same route. With the answers, resolve25 builds and writes the final
     * `input.json` through the same `buildD1InputSnapshot`, with the `input.json` of the run before as previous.
     */
    export const RESOLVE_FANOUT: D1FanoutConfig;
    export function beforeD1ResolvePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1ResolvePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_DOMAIN_VERSION: "2026-09-21-d1-domain-v1";
    export const D1_DOMAIN_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export type D1DomainAction = typeof D1_DOMAIN_ACTIONS[number];
    export type D1RulePlacement = 'invariant' | 'application' | 'platform';
    export interface D1DomainFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1DomainTableRef {
        tableId: string;
        entity: string;
    }
    /** The slice of the input20 inventory this step reads. Matching is by exact id. */
    export interface D1DomainSelection {
        entities: string[];
        files: D1DomainFile[];
        tables: D1DomainTableRef[];
    }
    export interface D1DomainProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1Normalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1PlacedRule {
        ruleId: string;
        owner: 'module' | 'platform';
        /** Module artifact, or the catalog path the entity source names. Spelling is the citation. */
        source: string;
        placement: D1RulePlacement;
    }
    export interface D1Enumeration {
        path: string;
        values: string[];
    }
    export interface D1DomainEntityPlan {
        entityId: string;
        action: string;
        defPath: string;
        storageTarget: string;
        emitsLocalPersistence: false;
        derivedInitial: string | null;
        uniqueKeys: string[][];
        enumerations: D1Enumeration[];
        rules: D1PlacedRule[];
        definition: D1Definition | null;
    }
    export interface D1DomainValuePlan {
        valueObjectId: string;
        defPath: string;
        referencedBy: string[];
        definition: D1Definition | null;
    }
    export interface D1DomainEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1DomainBuild {
        schemaVersion: typeof D1_DOMAIN_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        entities: D1DomainEntityPlan[];
        valueObjects: D1DomainValuePlan[];
        problems: D1DomainProblem[];
        normalizations: D1Normalization[];
        preserved: string[];
        removed: string[];
        emit: D1DomainEmit[];
    }
}
declare module "_102034_/l4/ontology/mdm.defs" {
    export const mdm: {
        readonly schemaVersion: "2026-09-15-mdm-ontology-v2";
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "mdmId; stable through promotion and merge.";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                    readonly writePrecondition: true;
                    readonly description: "Bumped by the engine on every write; optimistic concurrency.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly groups: readonly ["identification", "base", "<subtype>", "general", "<moduleId>"];
                    readonly description: "The JSONB document, as a map of groups (see groups).";
                };
            };
            readonly displayField: "identification.name";
        };
        readonly groups: {
            readonly identification: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "Also columns of the index table; that is what makes them filterable and sortable. A field earns a column only when something has to filter or sort by it.";
                readonly fields: {
                    readonly subtype: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Person", "Company", "ContactChannel", "Animal", "Product", "Service", "Location", "BankAccount", "Document", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
                        readonly description: "Which subtype this record is; it decides which subtype branch the document carries.";
                    };
                    readonly name: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 200;
                        readonly description: "How a human recognises the record. The only text filter there is.";
                    };
                    readonly status: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Active", "Inactive", "Merged", "Blocked"];
                    };
                    readonly docType: {
                        readonly type: "enum";
                        readonly indexed: true;
                        readonly values: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
                    };
                    readonly docId: {
                        readonly type: "string";
                        readonly indexed: true;
                        readonly description: "The document number itself. Unique with docType by design; the unique index does not exist yet, see knownDivergences.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly default: "US";
                        readonly description: "ISO 3166-1 alpha-2. Says which country the document and the legal rules belong to.";
                    };
                    readonly tags: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Module roles, as <moduleId>.<Entity>. Written by attachRole; this is how a module says the record is one of its own. A column with no index.";
                    };
                    readonly mergedInto: {
                        readonly type: "string";
                        readonly derived: true;
                        readonly description: "On the loser of a merge, the mdmId of the winner. A column with no index.";
                    };
                    readonly createdAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                    readonly updatedAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                };
            };
            readonly base: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "What every record has, whatever its subtype, and which nothing filters by.";
                readonly fields: {
                    readonly moduleTypes: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly derived: true;
                        readonly description: "The module roles again, kept for the engine and duplicating tags. Not a field for a reader; read tags.";
                    };
                    readonly aliases: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly description: "Other names the same subject answers to: trade name, maiden name, nickname.";
                    };
                    readonly addresses: {
                        readonly type: "object";
                        readonly of: "Address";
                        readonly collection: true;
                        readonly required: true;
                    };
                    readonly contacts: {
                        readonly type: "object";
                        readonly of: "ContactSummary";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Summary of the ContactChannel records linked by HasContact. A contact is a record, never a string on this one.";
                    };
                    readonly relationshipRefs: {
                        readonly type: "object";
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "The compact keys the engine recomputes on every link and unlink. The key set is relationships[].compactKeys — it is not repeated here, and it is never written by hand.";
                    };
                    readonly notes: {
                        readonly type: "string";
                        readonly maxLength: 1000;
                    };
                };
            };
            readonly general: {
                readonly type: "object";
                readonly owner: "organization";
                readonly open: true;
                readonly description: "Fields promoted by the organization when more than one module needed them; the schema lives in the project registry, so a module reads this branch and does not declare it.";
            };
            readonly "<moduleId>": {
                readonly type: "object";
                readonly owner: "module";
                readonly open: true;
                readonly description: "One key per module id — Record<moduleId, object>. Only that module writes it (MDM_FOREIGN_NAMESPACE otherwise); other modules see the key by name. Never identity, document, contact or login. Example: \"agendaClinica\": { \"prontuario\": \"PR-000123\" } — its schema is the module's own ontology (Paciente.defs.ts).";
            };
        };
        readonly types: {
            readonly Address: {
                readonly type: {
                    readonly type: "enum";
                    readonly required: true;
                    readonly values: readonly ["Residential", "Commercial", "Billing", "Delivery", "Other"];
                };
                readonly label: {
                    readonly type: "string";
                    readonly description: "Short human label for this address. Examples: home, headquarters, warehouse, branch";
                };
                readonly line1: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Primary address line: street and number, PO Box, or rural route. Examples: US \"123 Main St\"; Brazil \"Rua das Flores 100\"; Japan \"1-2-3 Shinjuku\".";
                };
                readonly line2: {
                    readonly type: "string";
                    readonly description: "Secondary line: apartment, suite, floor, unit, building. Examples: US \"Apt 4B\"; Brazil \"Apto 42\"; Japan \"Shinjuku-ku\".";
                };
                readonly line3: {
                    readonly type: "string";
                    readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan). Examples: Brazil \"Jardim Paulista\"; Japan \"Tokyo\".";
                };
                readonly city: {
                    readonly type: "string";
                };
                readonly stateOrProvince: {
                    readonly type: "string";
                    readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                };
                readonly postalCode: {
                    readonly type: "string";
                    readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                };
                readonly countryCode: {
                    readonly type: "string";
                    readonly required: true;
                    readonly maxLength: 2;
                    readonly pattern: "^[A-Z]{2}$";
                    readonly default: "US";
                    readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                };
                readonly formatted: {
                    readonly type: "string";
                    readonly derived: true;
                    readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                };
                readonly geolocation: {
                    readonly type: "object";
                    readonly of: "GeoPoint";
                };
                readonly isPrimary: {
                    readonly type: "boolean";
                    readonly required: true;
                };
            };
            readonly GeoPoint: {
                readonly lat: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -90;
                    readonly max: 90;
                };
                readonly lng: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -180;
                    readonly max: 180;
                };
            };
            readonly PrivacyConsent: {
                readonly consentedAt: {
                    readonly type: "timestamp";
                    readonly required: true;
                };
                readonly consentVersion: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Version of the privacy policy accepted.";
                };
                readonly channel: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "How consent was obtained. Examples: web-signup, paper-form, whatsapp, verbal";
                };
                readonly revokedAt: {
                    readonly type: "timestamp";
                };
                readonly notes: {
                    readonly type: "string";
                };
            };
            readonly ContactSummary: {
                readonly mdmId: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                };
                readonly title: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Human-readable label for this contact in the context of the parent entity. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                };
            };
        };
        readonly subtypes: {
            readonly Person: {
                readonly description: "Natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly gender: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "NonBinary", "NotDisclosed"];
                    };
                    readonly nationality: {
                        readonly type: "string";
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string";
                        readonly maxLength: 120;
                    };
                    readonly photoUrl: {
                        readonly type: "string";
                    };
                    readonly privacyConsent: {
                        readonly type: "object";
                        readonly of: "PrivacyConsent";
                        readonly description: "Required for residents of Brazil (LGPD) and the EU (GDPR).";
                    };
                };
                readonly capabilities: readonly ["locate.byLogin", "locate.users", "invite.login", "register.self", "accessRequest.read", "accessRequest.resolve", "export.personalData", "anonymize"];
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Corporations, LLCs, nonprofits, government entities — and the internal structures of any of them.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["LegalEntity", "Branch", "Franchise", "BusinessUnit", "Group", "Team", "Department", "InternalOrg"];
                        readonly description: "Tells a legal entity apart from an internal structure.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Official registered name.";
                    };
                    readonly tradeName: {
                        readonly type: "string";
                        readonly description: "DBA name. Also goes into aliases, so the text filter finds it.";
                    };
                    readonly legalType: {
                        readonly type: "enum";
                        readonly values: readonly ["Corporation", "LLC", "SoleProp", "Partnership", "Nonprofit", "Government", "Other"];
                    };
                    readonly parentCompanyId: {
                        readonly type: "record";
                        readonly to: readonly ["Company"];
                        readonly description: "Parent in an organizational tree. The link itself is BelongsToGroup, PartOfUnit or SubsidiaryOf.";
                    };
                    readonly externalCode: {
                        readonly type: "string";
                        readonly description: "ERP, HR or legacy code used by the consuming modules.";
                    };
                    readonly foundingDate: {
                        readonly type: "date";
                    };
                    readonly taxRegime: {
                        readonly type: "string";
                        readonly description: "Country-specific tax class: S-Corp and C-Corp in the US, Simples Nacional in Brazil.";
                    };
                    readonly industryCode: {
                        readonly type: "string";
                        readonly description: "NAICS in the US, CNAE in Brazil, or the local equivalent.";
                    };
                    readonly website: {
                        readonly type: "string";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly ContactChannel: {
                readonly description: "A phone, e-mail or social handle as a record of its own, so it can be traced, verified and shared.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Phone", "Email", "WhatsApp", "Instagram", "LinkedIn", "X", "Other"];
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The contact itself, stored unmasked.";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
            readonly Animal: {
                readonly description: "Pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string";
                    };
                    readonly breed: {
                        readonly type: "string";
                    };
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly sex: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "Unknown"];
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly microchip: {
                        readonly type: "string";
                    };
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Breed registry, USDA tag, or official animal id.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly Product: {
                readonly description: "An inventory or catalog item that can be bought, stocked, sold or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string";
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "enum";
                        readonly values: readonly ["Physical", "Digital", "Bundle", "Consumable", "Other"];
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string";
                        readonly description: "unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly description: "True when stock is tracked by location.";
                    };
                };
            };
            readonly Service: {
                readonly description: "A reusable service or offering that can be sold, scheduled, taught or assigned to a place. Courses are services too.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string";
                    };
                    readonly serviceKind: {
                        readonly type: "enum";
                        readonly values: readonly ["Service", "Course", "Cohort", "Subscription", "AppointmentType"];
                        readonly description: "Cohort is a concrete instance of a course.";
                    };
                    readonly serviceType: {
                        readonly type: "enum";
                        readonly values: readonly ["Course", "Consulting", "Maintenance", "Appointment", "Subscription", "Other"];
                    };
                    readonly parentServiceId: {
                        readonly type: "record";
                        readonly to: readonly ["Service"];
                        readonly description: "The base service, when this one is a cohort or a derived offering.";
                    };
                    readonly durationMinutes: {
                        readonly type: "number";
                    };
                    readonly deliveryMode: {
                        readonly type: "enum";
                        readonly values: readonly ["Onsite", "Remote", "Hybrid", "Other"];
                    };
                };
            };
            readonly Location: {
                readonly description: "A physical place used for stock or for delivering a service: room, warehouse, campus, store, branch, shelf.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Room", "Warehouse", "Building", "Campus", "Store", "Office", "Shelf", "Other"];
                    };
                    readonly locationCode: {
                        readonly type: "string";
                    };
                    readonly parentLocationId: {
                        readonly type: "record";
                        readonly to: readonly ["Location"];
                        readonly description: "The larger place this one belongs to.";
                    };
                    readonly capacity: {
                        readonly type: "number";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Routing data only. Balances and transactions belong to the finance module, never here.";
                readonly fields: {
                    readonly bankName: {
                        readonly type: "string";
                    };
                    readonly bankRoutingNumber: {
                        readonly type: "string";
                        readonly description: "ABA routing number in the US; use swift for international.";
                    };
                    readonly accountNumber: {
                        readonly type: "string";
                    };
                    readonly accountType: {
                        readonly type: "enum";
                        readonly values: readonly ["Checking", "Savings", "MoneyMarket", "Payment", "Other"];
                    };
                    readonly swift: {
                        readonly type: "string";
                        readonly description: "BIC/SWIFT, for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string";
                    };
                    readonly pixKey: {
                        readonly type: "string";
                    };
                    readonly pixKeyType: {
                        readonly type: "enum";
                        readonly values: readonly ["CPF", "CNPJ", "Phone", "Email", "RandomKey"];
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                        readonly description: "Verified by micro-deposit, open banking or manual review.";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "An indexed reference to an external file. The file itself never lives in the MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The module that created this record.";
                    };
                    readonly docCategory: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Contract", "Certificate", "IdDocument", "Invoice", "Receipt", "Report", "Photo", "Other"];
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "S3 bucket, or its equivalent, holding the file.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Path inside the bucket. Never rewritten after creation.";
                    };
                    readonly fileName: {
                        readonly type: "string";
                        readonly required: true;
                    };
                    readonly mimeType: {
                        readonly type: "string";
                    };
                    readonly fileSizeKb: {
                        readonly type: "number";
                    };
                    readonly issuedAt: {
                        readonly type: "date";
                    };
                    readonly expiresAt: {
                        readonly type: "date";
                    };
                    readonly issuer: {
                        readonly type: "string";
                        readonly description: "Name of the issuing authority, as free text. Not an mdmId.";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly AssetGeneric: {
                readonly description: "The fallback asset, for what does not fit vehicle, property or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string";
                        readonly description: "furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly manufacturer: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string";
                    };
                    readonly vin: {
                        readonly type: "string";
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly year: {
                        readonly type: "integer";
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly fuelType: {
                        readonly type: "enum";
                        readonly values: readonly ["Gasoline", "Diesel", "Electric", "Hybrid", "Flex", "Other"];
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Real estate: residential, commercial, rural or industrial.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Deed number, cadastral reference, or the local equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                    readonly propertyType: {
                        readonly type: "enum";
                        readonly values: readonly ["Residential", "Commercial", "Rural", "UrbanLot", "Industrial", "Other"];
                    };
                    readonly areaSqft: {
                        readonly type: "number";
                        readonly description: "Area in square feet; the primary unit in the US.";
                    };
                    readonly areaM2: {
                        readonly type: "number";
                        readonly description: "Area in square meters, outside the US.";
                    };
                    readonly taxParcelId: {
                        readonly type: "string";
                        readonly description: "Tax parcel or assessor id in the US, or the local equivalent.";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly acquisitionDate: {
                        readonly type: "date";
                    };
                };
            };
        };
        readonly relationships: readonly [{
            readonly type: "Owns";
            readonly title: "Owns";
            readonly description: "A person or a company owns an asset · metadata: since, ownershipPct";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["ownedAssets"];
                readonly to: readonly ["owners"];
            };
        }, {
            readonly type: "Employs";
            readonly title: "Employs";
            readonly description: "A company employs a person · metadata: role, department, startDate";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["employee", "contractor", "intern"];
            readonly compactKeys: {
                readonly from: readonly ["employees"];
                readonly to: readonly ["employers"];
            };
        }, {
            readonly type: "OffersProduct";
            readonly title: "Offers product";
            readonly description: "A company puts a product in its catalog · metadata: since, supplierSku";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredProducts"];
                readonly to: readonly ["productSuppliers"];
            };
        }, {
            readonly type: "OffersService";
            readonly title: "Offers service";
            readonly description: "A company or a person offers a service · metadata: since, priceTable";
            readonly from: readonly ["Company", "Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredServices"];
                readonly to: readonly ["serviceProviders"];
            };
        }, {
            readonly type: "StocksAt";
            readonly title: "Stocks at";
            readonly description: "A product or a piece of equipment is stocked at a place · metadata: quantity, unit, minLevel";
            readonly from: readonly ["Product", "AssetEquipment"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["stockLocations"];
                readonly to: readonly ["stockedItems"];
            };
        }, {
            readonly type: "Teaches";
            readonly title: "Teaches";
            readonly description: "A person teaches a service or a course · metadata: role, since";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["primary-instructor", "assistant-instructor", "substitute"];
            readonly compactKeys: {
                readonly from: readonly ["taughtServices"];
                readonly to: readonly ["instructors"];
            };
        }, {
            readonly type: "HappensAt";
            readonly title: "Happens at";
            readonly description: "A service is delivered at a place · metadata: scheduleLabel, weekday";
            readonly from: readonly ["Service"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["serviceLocations"];
                readonly to: readonly ["scheduledServices"];
            };
        }, {
            readonly type: "FranchiseOf";
            readonly title: "Franchise of";
            readonly description: "A company operates as a franchise of another · metadata: contractId, territory";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["franchisors"];
                readonly to: readonly ["franchisees"];
            };
        }, {
            readonly type: "BelongsToGroup";
            readonly title: "Belongs to group";
            readonly description: "A company belongs to an economic group · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["subsidiary-brand"];
            readonly compactKeys: {
                readonly from: readonly ["groupParents"];
                readonly to: readonly ["groupMembers"];
            };
        }, {
            readonly type: "PartOfUnit";
            readonly title: "Part of unit";
            readonly description: "An internal structure belongs to a larger one · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["department", "team", "branch-unit"];
            readonly compactKeys: {
                readonly from: readonly ["unitParents"];
                readonly to: readonly ["unitChildren"];
            };
        }, {
            readonly type: "ManagedBy";
            readonly title: "Managed by";
            readonly description: "A person runs a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["manager", "coordinator"];
            readonly compactKeys: {
                readonly from: readonly ["managedOrganizations"];
                readonly to: readonly ["managers"];
            };
        }, {
            readonly type: "ReportsTo";
            readonly title: "Reports to";
            readonly description: "A person reports to another person · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["direct-report", "manager"];
            readonly compactKeys: {
                readonly from: readonly ["reportManagers"];
                readonly to: readonly ["reports"];
            };
        }, {
            readonly type: "AssignedTo";
            readonly title: "Assigned to";
            readonly description: "A person is assigned to a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["member", "assistant", "instructor"];
            readonly compactKeys: {
                readonly from: readonly ["assignments"];
                readonly to: readonly ["assignees"];
            };
        }, {
            readonly type: "Attends";
            readonly title: "Attends";
            readonly description: "A person attends a service or a course · metadata: attendanceStatus";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["enrolled", "completed"];
            readonly compactKeys: {
                readonly from: readonly ["attendedServices"];
                readonly to: readonly ["attendees"];
            };
        }, {
            readonly type: "SuppliesProduct";
            readonly title: "Supplies product";
            readonly description: "A company supplies a product · metadata: leadTimeDays, catalogCode";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliedProducts"];
                readonly to: readonly ["productVendors"];
            };
        }, {
            readonly type: "PartnersWith";
            readonly title: "Partners with";
            readonly description: "A person is a partner in a company · metadata: equityPct, role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["managing-partner", "silent-partner"];
            readonly compactKeys: {
                readonly from: readonly ["partners"];
                readonly to: readonly ["partners"];
            };
        }, {
            readonly type: "Family";
            readonly title: "Family";
            readonly description: "Kinship between two people, read the same way from either side · metadata: degree. An emergency contact is this link with role emergency";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: true;
            readonly roles: readonly ["spouse", "child", "parent", "sibling", "emergency"];
            readonly compactKeys: {
                readonly from: readonly ["family"];
                readonly to: readonly ["family"];
            };
        }, {
            readonly type: "GuardianOf";
            readonly title: "Guardian of";
            readonly description: "A person answers for another person or for an animal · metadata: since, guardianType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person", "Animal"];
            readonly bidirectional: false;
            readonly roles: readonly ["parent", "guardian", "owner", "foster"];
            readonly compactKeys: {
                readonly from: readonly ["pets"];
                readonly to: readonly ["guardians"];
            };
        }, {
            readonly type: "CustomerOf";
            readonly title: "Customer of";
            readonly description: "A person or a company buys from a company · metadata: since, segment";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliers"];
                readonly to: readonly ["customers"];
            };
        }, {
            readonly type: "SupplierOf";
            readonly title: "Supplier of";
            readonly description: "A company supplies another company · metadata: category, contractMdmId";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["customers"];
                readonly to: readonly ["suppliers"];
            };
        }, {
            readonly type: "MemberOf";
            readonly title: "Member of";
            readonly description: "A person is a member of a company or an association · metadata: role, membershipType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["board-member", "honorary"];
            readonly compactKeys: {
                readonly from: readonly ["memberships"];
                readonly to: readonly ["members"];
            };
        }, {
            readonly type: "HoldsAccount";
            readonly title: "Holds account";
            readonly description: "A person or a company holds a bank account · metadata: isPrimary, since";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["BankAccount"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["bankAccounts"];
                readonly to: readonly ["accountHolders"];
            };
        }, {
            readonly type: "SubsidiaryOf";
            readonly title: "Subsidiary of";
            readonly description: "A company is a subsidiary of another · metadata: equityPct, type";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["wholly-owned", "affiliate"];
            readonly compactKeys: {
                readonly from: readonly ["parentCompanies"];
                readonly to: readonly ["subsidiaries"];
            };
        }, {
            readonly type: "LocatedAt";
            readonly title: "Located at";
            readonly description: "A person or a company sits at a property · metadata: locationType";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetProperty"];
            readonly bidirectional: false;
            readonly roles: readonly ["headquarters", "branch", "warehouse"];
            readonly compactKeys: {
                readonly from: readonly ["locations"];
                readonly to: readonly ["locatedEntities"];
            };
        }, {
            readonly type: "Signed";
            readonly title: "Signed";
            readonly description: "A person or a company signed a document · metadata: role";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Document"];
            readonly bidirectional: false;
            readonly roles: readonly ["contractor", "client", "witness", "notary"];
            readonly compactKeys: {
                readonly from: readonly ["documents"];
                readonly to: readonly ["signedBy"];
            };
        }, {
            readonly type: "HasContact";
            readonly title: "Has contact";
            readonly description: "Any record owns a contact channel; this is what fills base.contacts · metadata: isPrimary";
            readonly from: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
            readonly to: readonly ["ContactChannel"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["contacts"];
                readonly to: readonly ["contactOwners"];
            };
        }];
        readonly capabilities: {
            readonly "read.byId": "Reads one record, or a handful at once, when the id is already known · get, getMany and hydrateMany over the index plus the document store, O(1) each · any screen that already holds the mdmId, and every list that has to fill in the records it points at · platform: ready";
            readonly "locate.byName": "Finds records whose name contains the typed text, anywhere in the string · listByType narrows by subtype and status in the index table and then matches the name in memory; aliases are not consulted and there is no default page size · anyone looking a record up · platform: partial";
            readonly "locate.byDocument": "Finds the single record that holds a national document (CPF, CNPJ, SSN, EIN) · findByDocument loads the index and filters in JS · whoever registers, to deduplicate before creating · platform: partial";
            readonly "locate.byContact": "Finds the record that owns a phone, WhatsApp handle or e-mail · findByContact loads every ContactChannel record · whoever answers an inbound call or message · platform: partial";
            readonly "locate.byLogin": "Finds the person behind a login e-mail · mdm_tag row with namespace login, partial unique index on (namespace, tag, module) · the session resolver · platform: ready";
            readonly "locate.users": "Lists people who already have a platform login · ctx.mdm.identity.listUsers({ name?, status?, roleTag?, roleTagMode?, pageSize?, cursor? }) filters a folded literal name, status Active by default or Inactive, Merged, Blocked or all, and one role tag with or without that tag; pages of 1 to 100, default 20, ordered by mdmId in UTF-8 byte order and continued by nextCursor, which is navigation and not a snapshot · the MDM is the one shared by the organization and the VM, with no project filter · ctx.mdm.identity.getLoginEmail(mdmId) reads the login of one person · platform: ready, proved in memory and on PostgreSQL";
            readonly "locate.byTag": "Finds every record carrying a given label — which is how a secondary key works here · mdm.tag.findByTag, over the index idx_mdm_tag_lookup on (entityType, tag, module); the `namespace` column keeps one key space apart from another, and the login e-mail of locate.byLogin is nothing but the namespace 'login' · a module that has to find a record by a code of its own, such as a chart or a badge number · platform: ready";
            readonly "locate.semantic": "Finds a record through a misspelling, a phonetic match or half a name · would need a trigram or tsvector index, or embeddings; searchVector is TEXT compared literally · reception, when the spelling is uncertain · platform: missing";
            readonly "locate.byDocumentField": "Filters or sorts by something that lives only in the document, such as birth month, city or any module field · would need that field promoted to an index column, or a GIN index on details; for a key the module itself controls, locate.byTag already answers without any of that · marketing and reporting · platform: missing";
            readonly "register.createOrAttach": "Creates the record when it does not exist and, either way, marks it with the module role · locate.byDocument, create when absent, then attachRole writes details[moduleId], the tag, the audit row and the recomputed compact refs · whoever registers · platform: ready";
            readonly "register.asProspect": "Records an interested party who has no document yet, and promotes it later · prospect.create with promotionSource and ttlExpiresAt, then promoteToEntity keeping the same mdmId · reception and the public site · platform: ready";
            readonly "edit.platformFields": "Changes the name, document, addresses, consent and the other fields the platform owns · entity.update; touching an identification field also rewrites the index row · whoever maintains the record · platform: partial";
            readonly "edit.moduleNamespace": "Changes only details[moduleId], which is what this module knows about the record · attachRole or update carrying the module key; any other module key is refused · the module itself · platform: ready";
            readonly inactivate: "Takes the record out of use without deleting it · status Active to Inactive, and reactivate undoes it · whoever maintains the record · platform: partial";
            readonly merge: "Joins two records that are the same subject, the loser pointing at the winner · mergeEntity sets status Merged and mergedInto, but the facade neither exports nor routes it · an administrator · platform: missing";
            readonly delete: "Removes the record physically, and is refused while an active relationship exists · entity.delete, error MDM_DELETE_BLOCKED_BY_RELATIONSHIPS · an administrator · platform: ready";
            readonly link: "Creates a versioned relationship, with a role, between two permanent records · link(from, to, type, role); the engine recomputes the compact keys on both sides · whoever maintains the record · platform: ready";
            readonly unlink: "Closes a relationship while keeping its history · unlink sets status Inactive; the row is never deleted · whoever maintains the record · platform: ready";
            readonly "link.contact": "Adds a phone, WhatsApp handle or e-mail that belongs to this record · create a ContactChannel record and link it with HasContact; the engine fills relationshipRefs.contacts · whoever maintains the record · platform: ready";
            readonly listLinks: "Shows the related records, with their validity and role · relationship.list and relatedOfMany · the record screen · platform: ready";
            readonly "attach.document": "Stores a photo, a scan or a signed document against the record, by category · upload to S3 or local disk, a row in mdm_attachment, presigned GET · whoever maintains the record · platform: partial";
            readonly comment: "Leaves a note on the record, with one level of reply and a 15-minute edit window · mdm_comment anchored by entityType, entityId and module · whoever maintains the record · platform: ready";
            readonly tag: "Marks the record with free labels inside the module namespace · mdm_tag, unique on (entityType, entityId, tag, module) · whoever maintains the record · platform: ready";
            readonly "sequence.next": "Issues the next number of a counter, such as a record or order number · mdm_number_sequence with SELECT … FOR UPDATE, key {module}.{entityType}.{scope} · the module, on create · platform: ready";
            readonly "config.kv": "Keeps a small piece of JSON configuration that more than one module reads · mdm.kv.get and mdm.kv.put over mdm_kv, a shared table keyed by one `key` column — no per-record scope, no history and no module column · a module that needs a setting the others also read · platform: ready";
            readonly "statusHistory.read": "Shows when the record changed status and who changed it · mdm_status_history · the record screen · platform: partial";
            readonly audit: "Says who changed what, and when · mdm_audit_log, insert only · an administrator · platform: partial";
            readonly "invite.login": "Gives the person a login so they can see their own data · identity.invite writes the mdm_tag login row and calls collab-auth · whoever maintains the record · platform: ready";
            readonly "register.self": "Links the signed-in account to one Person, or opens an access request when the e-mail already belongs to candidate contacts · POST /session/register reads the e-mail and the name from the resolved session, never from the body, and does not send an invite · the signed-in account · platform: ready";
            readonly "accessRequest.read": "Reads the requester's own request by id, or the organization's follow-up list of reserved candidate tokens · GET /session/registration/request?id= and GET /session/registration/requests; the list exists only while alpha authorities are on in this round · the requester for their own id, and the organization follow-up while alpha is on · platform: ready";
            readonly "accessRequest.resolve": "Resolves one pending request by requestId, expectedVersion and either a reserved candidate token or create-new with no target · POST /session/registration/resolve accepts no e-mail, mdmId, name or organizationKey, sends no invite, and exists only while alpha authorities are on in this round · the organization follow-up while alpha is on · platform: ready";
            readonly "export.personalData": "Hands the subject their own data on request (LGPD art. 18, GDPR art. 15) · would need the document, the links and the attachments in a single export · an administrator · platform: missing";
            readonly anonymize: "Erases the personal data while keeping the record for statistics · would pseudonymize the identification keeping the mdmId · an administrator · platform: missing";
        };
        readonly rules: {
            readonly "rule-person-ssn-unique-for-us": "Two permanent people in the US must not share the same SSN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-person-privacy-consent-required-br-eu": "A person living in Brazil or the EU without a valid privacy consent is forced to Inactive · engine · platform: ready";
            readonly "rule-company-ein-unique-for-us": "Two permanent companies in the US must not share the same EIN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-company-legal-name-required": "A company record is refused without a legalName · engine · platform: ready";
            readonly "rule-contact-value-unique-per-type": "Two contact channels must not share the same contactType and value · engine · platform: partial";
            readonly "rule-bank-account-routing-required-for-us": "A US bank account is refused without a bankRoutingNumber · engine · platform: ready";
            readonly "rule-bank-account-holder-via-relationship": "Who holds a bank account is the HoldsAccount link, never a field of the account · engine · platform: ready";
            readonly "rule-document-parties-via-relationships": "Who signed a document is the Signed link, never a field of the document · engine · platform: ready";
            readonly "rule-document-path-immutable": "Once stored, the storage key of a document is never rewritten · engine · platform: ready";
            readonly "rule-foreign-namespace-refused": "A caller carrying a moduleId may write the platform keys, general and its own key; any other module key is refused with MDM_FOREIGN_NAMESPACE · engine · platform: ready";
            readonly "rule-delete-blocked-by-relationships": "A physical delete is refused while an active relationship exists · engine · platform: ready";
            readonly "rule-document-shape-validated": "Addresses, consent, general and the module namespace are validated on write against the schema derived from this ontology · engine · platform: missing, nothing validates the document today";
            readonly "rule-identity-never-in-namespace": "Identity, document, contact and login are platform layers; a module never redeclares them inside details[moduleId] · engine · platform: partial";
        };
        readonly statuses: readonly ["Active", "Inactive", "Merged", "Blocked"];
        readonly docTypes: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
        readonly storage: {
            readonly indexTable: "mdm_documents_entities_index";
            readonly prospectIndexTable: "mdm_documents_prospects_index";
            readonly documentTable: "mdm_documents";
            readonly documentColumn: "details";
            readonly indexedColumns: readonly ["subtype", "name", "status", "docType", "docId", "countryCode", "createdAt", "updatedAt"];
            readonly reservedKeys: readonly ["identification", "base", "general", "<subtype>", "<moduleId>"];
        };
        readonly knownDivergences: {
            readonly "grouped-document": "The branches of this file are the target. The engine writes and reads a FLAT document today, so identification, base and the subtype branch are all one level.";
            readonly "contacts-written-from-input": "base.contacts is declared derived from HasContact and the engine still writes it raw from the input, duplicating relationshipRefs.contacts.";
            readonly "module-types-duplicates-tags": "base.moduleTypes and identification.tags carry the same module roles. tags is the one with a column; moduleTypes is kept for the engine and should disappear.";
            readonly "doc-unique-missing": "UNIQUE(docType, docId) is promised in defs/ontology.ts and absent from persistence.ts, so the two uniqueness rules are only partly enforced.";
            readonly "privacy-consent-value": "PrivacyConsent (data) and PrivacyConsentValue (interface) declare different fields; the same is true of Address and ContactSummary.";
            readonly "compact-relationship-refs-count": "CompactRelationshipRefs has 22 keys in the data and 48 in the interface; the interface is the real one.";
            readonly "search-vector-type": "searchVector is documented as tsvector and created as TEXT, compared literally, which is why locate.semantic is missing.";
            readonly "relationship-documents-table": "Table mdm_relationship_documents is cited and does not exist.";
            readonly "service-defs-case": "The JSON service definitions use PascalCase where the columns are camelCase.";
            readonly "platform-detail-keys-copy": "The two lists in mdmFacade.ts and integration.ts are gone. One classifier, l1/mdm/defs/platformDetailKeys.ts, keeps catalog names apart from engine-compat extras. mdmId is the flat record id (record.fields.id), not a catalog field and not a module namespace.";
            readonly "prospect-lifecycle-fields": "promotionSource, promotedTo and ttlExpiresAt are the three ProspectLifecycleFields of the current engine and prospect index. They belong to that contract, not to a module namespace and not to a common editable form field. They are not universal inputs of every entity.";
            readonly "emergency-contact-type": "There is no EmergencyContactOf type; a Family link with role emergency carries that meaning.";
            readonly "subtype-enum-narrowed": "identification.subtype is declared here with the 13 values; the engine narrows it per subtype, so a Person record only ever carries \"Person\".";
            readonly "index-only-columns": "The index table also has searchVector and dynamoPk, which are engine internals and no field of the document; one of the 9 indexes is on dynamoPk, which is why indexedColumns lists 8.";
            readonly "registration-draft": "register.self and the organization bootstrap may store a Person while the name or the country is still unknown, and a Company while the legal name is still unknown. The engine marks that case with registrationDraft. That marker is not a form field and is not written into the module namespace. A normal create still requires the name, the country and, for a company, the legal name.";
        };
    };
    export default mdm;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/gate" {
    import { type D1DomainBuild, type D1DomainSelection } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export interface D1DomainRequest {
        project: number;
        moduleName: string;
        selection: D1DomainSelection;
        /** Ontology bodies keyed by entityId. A filename is not an identity. */
        entities: Record<string, unknown>;
        ontologyIndex: unknown;
        /** Module rules artifact. Keys are matched exactly. */
        rules: unknown;
        /** Catalog document keyed by the entity `source` string. Absent means unread. */
        catalogs: Record<string, unknown>;
    }
    /**
     * One deterministic pass from the L4 record tree to domain defs.
     * No model, no eval, and no NS4 field list is rewritten into this tree.
     */
    export function buildD1Domain(request: D1DomainRequest): D1DomainBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export function assembleD1Domain(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1DomainBuild;
    }>;
    export function commitD1Domain(project: number, build: D1DomainBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A catalog may live in another project. `..` and a short name with a dot are refused. */
    export function catalogInfo(source: string): D1FileInfo | null;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/contracts" {
    import type { D1Definition, D1PortMethod } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export const D1_PERSISTENCE_VERSION: "2026-09-21-d1-persistence-v1";
    /** Prefix for a logical field stored in the runtime `details` JSONB column. One writer, reversible. */
    export const D1_JSON_COLUMN_PREFIX: "json:";
    /** Runtime JSONB column name. Not derived per table and not snake-cased. */
    export const D1_DETAILS_COLUMN: "details";
    export const D1_PERSISTENCE_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export const ENUMERATION_REASON: "Table and adapter schemas have no enum values. They stay on the domain draft.";
    export interface D1PersistenceFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1PersistenceProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1PersistenceNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ColumnBinding {
        field: string;
        column: string;
        nullable: boolean;
        placement: 'column' | 'json';
    }
    /** Enum values read from the domain draft and not copied onto a table or adapter. */
    export interface D1UnconsumedEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: 'domain30.enumerations';
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UniqueKeyUse {
        entityId: string;
        tableId: string | null;
        uniqueKeys: string[][];
        consumed: boolean;
        /** Where a consumed key was written, or why it was not. */
        placedOn: string;
    }
    export interface D1PersistencePortPlan {
        portId: string;
        entityId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceTablePlan {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        physicalName: string;
        /** Runtime JSONB column, or null when every field is a real column. */
        detailsColumn: string | null;
        definition: D1Definition | null;
    }
    export interface D1PersistenceAdapterPlan {
        portId: string;
        entityId: string;
        tableId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        bindings: D1ColumnBinding[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1PersistenceBuild {
        schemaVersion: typeof D1_PERSISTENCE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1UnconsumedEnumeration[];
        uniqueKeys: D1UniqueKeyUse[];
        ports: D1PersistencePortPlan[];
        tables: D1PersistenceTablePlan[];
        adapters: D1PersistenceAdapterPlan[];
        problems: D1PersistenceProblem[];
        normalizations: D1PersistenceNormalization[];
        preserved: string[];
        removed: string[];
        emit: D1PersistenceEmit[];
    }
    export interface D1PersistenceRequest {
        project: number;
        moduleName: string;
        selection: {
            ports: Array<{
                portId: string;
                entity: string;
                status: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
                status: string;
            }>;
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                status: string;
            }>;
            files: D1PersistenceFile[];
        };
        domain: D1DomainBuild;
        entities: Record<string, unknown>;
        /** Preserved port bytes keyed by defPath. The value is the definition object. */
        preservedPorts: Record<string, unknown>;
        /** Extra physical names that must equal `storage.table`. Keyed by entity id. */
        physicalCitations: Record<string, string[]>;
        /** Catalog paths this step opened and did not write. */
        catalogsRead: string[];
    }
    /** Logical field encoded by one column string. `json:` marks the details envelope. */
    export function fieldFromColumn(column: string): string;
    export function columnForField(field: string, placement: 'column' | 'json'): string;
    /** Names required by the port and missing from the adapter. */
    export function uncoveredMethods(required: readonly string[], implemented: readonly string[]): string[];
    /** A binding round-trips when each column string decodes to its own field and no column is shared. */
    export function bindingRoundTripIssues(bindings: readonly D1ColumnBinding[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1PersistenceBuild, type D1PersistenceRequest } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    /**
     * One deterministic pass from the domain draft and the L4 record to ports, tables and adapters.
     * No model. Physical names are `storage.table` verbatim. Nothing is snake-cased or pluralized.
     */
    export function buildD1Persistence(request: D1PersistenceRequest): D1PersistenceBuild;
    /** A port file must not depend on an adapter. The check is the application side of the hexagon. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/io" {
    import type { D1PersistenceBuild } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    export function assembleD1Persistence(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1PersistenceBuild;
    }>;
    export function commitD1Persistence(project: number, build: D1PersistenceBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/derivedRead" {
    /** What a `ddm` read computes. The materializer owns how. */
    export interface D1DerivedRead {
        mode: 'onRead';
        sources: string[];
        windowField: string;
        groupBy: string[];
        measures: string[];
    }
    /**
     * The read shape of a `ddm`, or `null` when the ontology has no `aggregate.byWindow`.
     * `problems` names each gap. `derivedRead` still carries whatever was readable.
     */
    export function derivedReadOf(body: unknown, moduleEntityIds: readonly string[], entityId: string): {
        derivedRead: D1DerivedRead;
        problems: string[];
    } | null;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1DerivedRead } from "_102021_/l2/agentDefsL1/steps/usecases50/derivedRead";
    export const D1_USECASE_VERSION: "2026-10-01-d1-usecases-v2";
    /** Same trail as persistence40. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Usecase projection has no values slot. Enum values stay on the domain draft.";
    export const D1_WORKER_KINDS: readonly ["port", "rule", "mdm", "transition", "effect", "transaction", "context"];
    /**
     * Facade methods a plan may name. `read` and `attach` are not methods:
     * a point read, a collection read and a platform-field update are different calls.
     * The tool offers only the methods the operation's binding names. This list stays
     * the facade, so a manipulated reply can still be recognized and refused.
     */
    export const D1_MDM_CALLS: readonly ["get", "findByDocument", "findByContact", "listByType", "relatedOfMany", "create", "attachRole", "update", "inactivate", "reactivate", "link", "invite"];
    export type D1MdmCall = (typeof D1_MDM_CALLS)[number];
    export const D1_WRITE_CALLS: readonly ["create", "update", "transition", "delete"];
    export interface D1UsecaseProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1UsecaseNormalization {
        code: string;
        path: string;
        detail: string;
    }
    /** Domain enum values cited by path and not copied onto a usecase. */
    export interface D1UsecaseEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UsecaseField {
        name: string;
        type: string;
        derived: boolean;
        /** Copied from the ontology. Never inferred from the field name. */
        writePrecondition?: boolean;
        /** True when the ontology field or an ancestor is not required. */
        optional?: boolean;
    }
    export interface D1UsecaseTransition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        /** Field paths the ontology names. Empty when that transition declares none. */
        payload?: string[];
        description?: string;
    }
    export interface D1UsecaseEntity {
        entityId: string;
        storageTarget: string;
        defPath: string;
        /** Empty when the ontology names none. The step does not invent one. */
        namespace: string;
        fields: D1UsecaseField[];
        transitions: D1UsecaseTransition[];
        rules: Array<{
            ruleId: string;
            owner: 'module' | 'platform';
            source?: string;
        }>;
        /** Ontology unique keys. Empty when the entity draft did not carry them. */
        uniqueKeys?: string[][];
        enumerations: Array<{
            path: string;
            values: string[];
        }>;
        /** Capability ids the ontology declares. Absent when this step was not given the body. */
        capabilities?: string[];
        /** Non-derived platform field paths. The MDM binding maps each one to a facade patch key. */
        platformFields?: string[];
        /** Set only when the ontology declares `aggregate.byWindow`. */
        derivedRead?: D1DerivedRead;
        /** Gaps from that read. Empty when `derivedRead` is complete. */
        derivedReadProblems?: string[];
    }
    export interface D1PortSignature {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1UsecasePort {
        portId: string;
        entityId: string;
        defPath: string;
        methods: string[];
        signatures?: D1PortSignature[];
    }
    export interface D1UsecaseSelection {
        usecaseId: string;
        entity: string;
        operation: string;
        /** L4 `transitionId`. Set when `operation` is `transition`. */
        transitionRef?: string;
        routes: string[];
        defPath: string;
    }
    /** The L4 transition this usecase runs. Never the usecaseId. */
    export function transitionRefOf(usecase: {
        operation: string;
        transitionRef?: string;
    }): string;
    export interface D1OutboundEvent {
        eventId: string;
        on: string;
        kind?: string;
        to?: string;
        description?: string;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1WorkerPort {
        kind: 'port';
        call: string;
        port: string;
    }
    export interface D1WorkerRule {
        kind: 'rule';
        ruleId: string;
    }
    export interface D1WorkerMdm {
        kind: 'mdm';
        namespace: string;
        /** Facade method the model named. Not trusted until the gate matches it to a capability. */
        call: string;
        entity: string;
        /** Capability this step claims to execute. */
        capability: string;
    }
    export interface D1WorkerTransition {
        kind: 'transition';
        transitionId: string;
        payload: string[];
    }
    export interface D1WorkerEffect {
        kind: 'effect';
        eventId: string;
    }
    export interface D1WorkerTransaction {
        kind: 'transaction';
        boundary: string;
    }
    export interface D1WorkerContext {
        kind: 'context';
        source: string;
    }
    export type D1WorkerStep = D1WorkerPort | D1WorkerRule | D1WorkerMdm | D1WorkerTransition | D1WorkerEffect | D1WorkerTransaction | D1WorkerContext;
    /** One model reply, already parsed. Operational means the reply never arrived. */
    export interface D1UsecasePlanInput {
        usecaseId: string;
        steps: D1WorkerStep[];
        operational?: boolean;
        trace?: string;
    }
    /** A source the snapshot approved, or a file that was missing or had changed. */
    export interface D1SourceFinding {
        code: 'SOURCE_ABSENT' | 'SOURCE_CHANGED' | 'RULE_TEXT_ABSENT' | 'CONTRACT_UNPARSED';
        path: string;
        message: string;
    }
    export interface D1SourceHash {
        path: string;
        sha256: string;
    }
    export interface D1SourceText {
        path: string;
        text: string;
    }
    /**
     * One applicability row. `enforcement` is the status of this obligation.
     * `local` runs in the usecase. `delegated` would name a structured method; the catalog has none.
     * `pending` is a gap and is not a step. An empty `ruleId` is the storage unique-key row, not a rule.
     */
    export interface D1RulePlanRow {
        ruleId: string;
        origin: string;
        consumer: string;
        enforcement: 'local' | 'delegated' | 'pending';
        gap: string;
    }
    /** One rule the operation is subject to. The text is the source, not a summary. */
    export interface D1RuleText {
        ruleId: string;
        owner: 'module' | 'platform';
        source: string;
        text: string;
    }
    export interface D1ContractPath {
        path: string;
        type: string;
        optional: boolean;
    }
    export interface D1AccessGrant {
        grantId: string;
        actorRef: string;
        scope: string;
        anchorEntity: string;
        scopeDetail: string;
        disclosure: string;
        disclosureDetail: string;
        allowedFields: string[];
    }
    export interface D1RouteContext {
        route: string;
        page: string;
        contractPath: string;
        inputSymbol: string;
        outputSymbol: string;
        inputFields: D1ContractPath[];
        outputFields: D1ContractPath[];
        /** Set when this route's contract does not bind the route. Not a second type. */
        unbound: string;
        access: D1AccessGrant[];
    }
    export interface D1CapabilityText {
        name: string;
        text: string;
    }
    export interface D1JourneyContext {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: Array<{
            stepId: string;
            kind: string;
            transitionRef: string;
            description: string;
        }>;
    }
    /**
     * Business context for one usecase. Contract symbols stay a reading of the L2
     * source. This is not a DTO the gate trusts instead of that source.
     */
    export interface D1UsecaseContext {
        usecaseId: string;
        lifecycle: boolean;
        transition: {
            transitionId: string;
            from: string[];
            to: string;
            by: string[];
            ruleRefs: string[];
            payload: string[];
            description: string;
        } | null;
        capabilities: D1CapabilityText[];
        effectiveFields: string[];
        routes: D1RouteContext[];
        /** Rules this operation enforces. Pending obligations are not in this list. */
        rules: D1RuleText[];
        rulePlan: D1RulePlanRow[];
        /** Texts for pending rows. Not offered to the worker as steps. */
        pendingRules: D1RuleText[];
        portId: string;
        portMethods: D1PortSignature[];
        effects: D1OutboundEvent[];
        journeys: D1JourneyContext[];
        findings: D1SourceFinding[];
        sources: D1SourceHash[];
    }
    /** The human prompt that was handed to the worker, plus the hashes it was built from. */
    export interface D1PromptEvidence {
        usecaseId: string;
        bytes: number;
        sha256: string;
        snapshotHash: string;
        sourceHashes: D1SourceHash[];
        text: string;
    }
    export interface D1UsecaseRequest {
        project: number;
        moduleName: string;
        usecases: D1UsecaseSelection[];
        ports: D1UsecasePort[];
        entities: D1UsecaseEntity[];
        /** Ids only. The gate uses this catalog to validate a returned id. */
        moduleRules: string[];
        outbound: D1OutboundEvent[];
        contracts: D1ContractSource[];
        contexts?: D1UsecaseContext[];
        sourceFindings?: D1SourceFinding[];
        sourceHashes?: D1SourceHash[];
        /** Raw dependency texts. The fidelity reader uses these, not the draft. */
        files?: D1SourceText[];
        plans: D1UsecasePlanInput[];
        llmCalls: number;
    }
    /**
     * Where an argument's value comes from.
     * `prior.calls` are earlier call ids; the first that produced `path` wins.
     * A later call, or an id with no producer, is not a source.
     */
    export interface D1MdmOrigin {
        kind: 'contract' | 'context' | 'literal' | 'prior';
        path?: string;
        calls?: string[];
        /** `writePrecondition` when the ontology mark and the contract field agree. Not a name. */
        evidence?: string;
    }
    /** One value the facade method takes. A patch key the facade does not accept is not represented. */
    export interface D1MdmArgument {
        name: string;
        role: 'selector' | 'parameter' | 'patch';
        /** Set when a shared call's patch is owned by one capability. */
        capability?: string;
        /** Ontology or contract path the value is read from. Mirrors `origin.path` for a contract source. */
        path?: string;
        /** Constant the facade receives when the value is not a field (`role` tag, or `ctx`). */
        value?: string;
        origin: D1MdmOrigin;
    }
    /**
     * The call runs only when every clause holds.
     * A prior clause whose call did not run sees an absent value.
     */
    export interface D1MdmClause {
        kind: 'contract' | 'prior';
        path: string;
        call?: string;
        present: boolean;
    }
    /** One facade invocation. Several capabilities may share it when one patch and one version cover them. */
    export interface D1MdmPlannedCall {
        /** Stable id inside this plan. Later calls cite it; it does not cite them. */
        id: string;
        method: D1MdmCall;
        target: 'entity' | 'collection' | 'identity';
        shape: 'point' | 'collection' | 'write';
        capabilities: string[];
        /** True when the capability is a choice (inactivate or reactivate), not a sequence. */
        alternative: boolean;
        /** Empty means the call always runs. */
        when: D1MdmClause[];
        arguments: D1MdmArgument[];
        result: string[];
    }
    /** A declared capability the facade does not implement, or an argument with no source. */
    export interface D1MdmGap {
        capability: string;
        /**
         * MDM_UNBOUND: no facade method.
         * MDM_PATCH_UNBOUND: a field the facade cannot patch.
         * MDM_ARGUMENT_UNBOUND: a required argument has no contract, context, literal or earlier result.
         * MDM_CONTRACT_UNREAD: the route contract was not read, so a call that needs one was not emitted.
         */
        code: 'MDM_UNBOUND' | 'MDM_PATCH_UNBOUND' | 'MDM_ARGUMENT_UNBOUND' | 'MDM_CONTRACT_UNREAD';
        evidence: string;
    }
    export interface D1UsecaseMdm {
        namespace: string;
        /** Canonical tag `<namespace>.<entityId>`. */
        role: string;
        /**
         * True only when every selected capability is one facade invocation.
         * A sequence of calls is not atomic: the facade does not wrap them.
         */
        atomic: boolean;
        calls: D1MdmPlannedCall[];
        gaps: D1MdmGap[];
    }
    export interface D1UsecaseItem {
        usecaseId: string;
        entityId: string;
        operation: string;
        defPath: string;
        routes: string[];
        trustedContext: 'ctx';
        mdm: D1UsecaseMdm | null;
        transactionBoundary: 'local' | null;
        steps: D1WorkerStep[];
        definition: D1Definition | null;
    }
    export interface D1UsecaseEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1UsecaseBuild {
        schemaVersion: typeof D1_USECASE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: number;
        ok: boolean;
        enumerations: D1UsecaseEnumeration[];
        usecases: D1UsecaseItem[];
        problems: D1UsecaseProblem[];
        normalizations: D1UsecaseNormalization[];
        emit: D1UsecaseEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding" {
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1MdmCall, type D1MdmGap, type D1MdmPlannedCall, type D1UsecaseMdm } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    type ReadFacadeText = (file: D1FileInfo) => Promise<string | null>;
    /**
     * Keys `entity.update` accepts as a caller patch: `MDM_PLATFORM_DETAIL_KEYS`
     * read from the classification file, minus `ENGINE_KEYS`.
     * The set may list string literals and spreads of `export const` arrays in the
     * same text. A missing export, an unrecognized form, or an empty read throws
     * with the file name. A spread whose name is not in the file throws with that name.
     * An empty set is never returned in place of a failed read.
     */
    export function platformKeysFromFacadeText(text: string): ReadonlySet<string>;
    /**
     * Reads `MDM_PLATFORM_DETAIL_KEYS` through the agent file API and caches the
     * platform patch keys. A missing file or an unrecognized set throws with the
     * file name. A loaded cache is returned as-is.
     */
    export function loadFacadePlatformKeys(read?: ReadFacadeText): Promise<ReadonlySet<string>>;
    /** Test seam. `null` clears the cache so the binding fails closed. */
    export function setFacadePlatformKeysForTest(text: string | null): void;
    /** Platform patch keys currently accepted by the facade source. */
    export function facadePlatformKeys(): ReadonlySet<string>;
    /** Same filter the worker catalog and the gate use before bindMdm. */
    export function capabilityApplies(name: string, operation: string): boolean;
    /**
     * Capabilities this operation may name, then the calls bindMdm actually emits.
     * Context, worker schema and the gate all take this result. A locate the input
     * cannot feed is not offered.
     */
    export function mdmForOperation(input: MdmBindInput & {
        operation: string;
    }): MdmBindResult;
    /** One schema pair per bound call. Alternative writes stay in the catalog. */
    export function mdmStepPairs(mdm: D1UsecaseMdm): Array<{
        call: string;
        capability: string;
    }>;
    /**
     * Capabilities the ontology can name and the facade does not implement.
     * Inactivate and reactivate do not write status history. Audit is another module.
     */
    export function mdmFacadeGaps(): D1MdmGap[];
    export function isMdmFacadeCall(value: string): value is D1MdmCall;
    /** A patch key the caller module may not write. Platform keys and the caller namespace are allowed. */
    export function isForeignMdmPatchKey(namespace: string, key: string): boolean;
    /**
     * Facade methods named by capabilities alone.
     * Callers that only need the catalog use this. It does not read a contract
     * and it does not invent arguments.
     */
    export function mdmCapabilityCalls(selected: readonly string[]): Array<{
        method: string;
        capabilities: string[];
    }>;
    /** One field of this operation's input, flattened. `writePrecondition` is the ontology mark, not the name. */
    export interface MdmInputField {
        path: string;
        optional: boolean;
        writePrecondition: boolean;
    }
    export interface MdmBindInput {
        entityId: string;
        namespace: string;
        /** Every capability the role declares. A locate capability does not put its arguments on every input. */
        capabilities: readonly string[];
        /** Capabilities this operation actually uses. */
        selected: readonly string[];
        platformFields: readonly string[];
        /**
         * Fields shared by every resolved route input.
         * `null` means the route contract was not read. A call that needs a contract
         * argument is not emitted (`MDM_CONTRACT_UNREAD`).
         * An empty list means the contract was read and declares nothing.
         */
        inputFields?: readonly MdmInputField[] | null;
        /** Why the contract was not read, one reason per route. Ignored when fields were read. */
        contractUnread?: string;
        /**
         * Output fields of the usecase signature.
         * `null` or omitted: the signature was not read. Reads stay, and `skipped` records `OUTPUT_UNREAD`.
         * An empty list: the signature was read and names no field.
         */
        outputFields?: readonly MdmOutputField[] | null;
        /** Set by `mdmForOperation`. List places a packed read into `items`; other operations do not. */
        operation?: string;
    }
    /** One field of the usecase signature output. */
    export interface MdmOutputField {
        path: string;
    }
    /** A read that was not emitted. Not a refusal: the call is absent and the capability is not a gap. */
    export interface MdmSkipped {
        capability: string;
        code: 'RESULT_UNUSED' | 'OUTPUT_UNREAD';
        evidence: string;
    }
    export interface MdmBindResult extends D1UsecaseMdm {
        skipped: MdmSkipped[];
    }
    export function bindMdm(input: MdmBindInput): MdmBindResult;
    /**
     * Proves the serialized plan. Prior links and the create-or-attach branch are checked
     * whether or not a contract was read. A contract argument with no field list is
     * `MDM_CONTRACT_UNREAD`, not a pass.
     */
    export function mdmFlowGaps(calls: readonly D1MdmPlannedCall[], input: MdmBindInput, existing?: readonly D1MdmGap[]): D1MdmGap[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/rulePlan" {
    import { capabilityApplies } from "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding";
    export { capabilityApplies };
    import type { D1RulePlanRow } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface RulePlanRule {
        ruleId: string;
        owner: 'module' | 'platform';
        source: string;
        text: string;
    }
    export interface RulePlanTransition {
        transitionId: string;
        by: readonly string[];
        ruleRefs: readonly string[];
        payload: readonly string[];
    }
    export interface RulePlanGrant {
        grantId: string;
        actorRef: string;
        scope: string;
    }
    export interface RulePlanRoute {
        route: string;
        contractPath: string;
        grants: readonly RulePlanGrant[];
    }
    export interface RulePlanInput {
        moduleName: string;
        entityId: string;
        usecaseId: string;
        operation: string;
        /** L4 transitionId. Compared with `transitionId`, never with `usecaseId`. */
        transitionRef?: string;
        rules: readonly RulePlanRule[];
        transitions: readonly RulePlanTransition[];
        uniqueKeys: readonly (readonly string[])[];
        capabilities: readonly string[];
        routes: readonly RulePlanRoute[];
        /**
         * Facade methods the binding calls. Not evidence: the catalog names no method
         * in a structured field, and a sentence is not a call.
         */
        mdmMethods: readonly string[];
    }
    export interface RulePlanEntity {
        rules: readonly {
            ruleId: string;
            owner: 'module' | 'platform';
            source?: string;
        }[];
        transitions: readonly RulePlanTransition[];
        uniqueKeys?: readonly (readonly string[])[];
        capabilities?: readonly string[];
        namespace: string;
        storageTarget: string;
        platformFields?: readonly string[];
    }
    export interface RulePlanFile {
        path: string;
        text: string;
    }
    /** Rule ids the operation enforces. Pending rows are not in this list. */
    export function enforcedRuleIds(rows: readonly D1RulePlanRow[]): string[];
    export function originFile(origin: string): string;
    export function planRuleApplicability(input: RulePlanInput): D1RulePlanRow[];
    /**
     * Same plan the gate writes and the fidelity reader recomputes.
     * An ontology file wins over the entity draft. Routes stay on the input.
     * A grant does not place a rule.
     */
    export function rulePlanForUsecase(input: {
        moduleName: string;
        entityId: string;
        usecaseId: string;
        operation: string;
        transitionRef?: string;
        files?: readonly RulePlanFile[];
        entity: RulePlanEntity;
        routes: readonly RulePlanRoute[];
    }): D1RulePlanRow[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/context" {
    import { type D1InputSnapshot, type D1SourceDigest } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ContractField } from "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst";
    import { capabilityApplies, type MdmInputField } from "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding";
    export { capabilityApplies };
    import type { D1ContractPath, D1ContractSource, D1OutboundEvent, D1SourceFinding, D1SourceHash, D1SourceText, D1UsecaseContext, D1UsecaseEntity, D1UsecaseField, D1UsecasePort, D1UsecaseRequest, D1UsecaseSelection } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface JourneyStepView {
        stepId: string;
        kind: string;
        entity: string;
        effect: string;
        transitionRef: string;
        description: string;
    }
    export interface JourneyView {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: JourneyStepView[];
    }
    export interface VerifiedBundle {
        findings: D1SourceFinding[];
        hashes: D1SourceHash[];
        moduleRuleText: Record<string, string> | null;
        moduleRulesPath: string;
        outbound: D1OutboundEvent[];
        integrationPath: string;
        contracts: D1ContractSource[];
        access: unknown | null;
        accessPath: string;
        needs: unknown | null;
        needsPath: string;
        journeys: JourneyView[];
        catalogs: Array<{
            path: string;
            rules: Record<string, string>;
        }>;
        bodies: Record<string, unknown | null>;
        entityPaths: Record<string, string>;
        files: D1SourceText[];
    }
    interface TransitionBody {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        payload: string[];
        description: string;
    }
    /** Reads the snapshot's sources again. A file is kept only when its hash still matches. */
    export function loadVerifiedSources(project: number, moduleName: string, snapshot: D1InputSnapshot, entityIds: readonly string[]): Promise<VerifiedBundle>;
    /**
     * The cut for one usecase: its routes, the rules those routes are subject to,
     * and the lifecycle or MDM capability that operation actually is.
     */
    export function buildUsecaseContexts(input: {
        moduleName: string;
        usecases: readonly D1UsecaseSelection[];
        entities: readonly D1UsecaseEntity[];
        ports: readonly D1UsecasePort[];
        bundle: VerifiedBundle;
    }): D1UsecaseContext[];
    export function formatUsecaseContext(context: D1UsecaseContext): string;
    /** Names the gate may accept on a transition payload. The domain signature is the authority. */
    export function authorizedPayloadNames(request: D1UsecaseRequest, usecaseId: string, inputNames: readonly string[]): Set<string>;
    export interface DomainField {
        name: string;
        type: string;
        fieldRef?: string;
    }
    /** Application signature. Contract symbols are not an input or an output. */
    export function domainSignature(entity: D1UsecaseEntity, operation: string, payload?: readonly string[]): {
        input: DomainField[];
        output: DomainField[];
    };
    /** Leaves of an ontology record. Optional when the field or an ancestor is not required. */
    export function ontologyLeaves(body: unknown): D1UsecaseField[];
    export function blockingFinding(findings: readonly D1SourceFinding[]): D1SourceFinding | null;
    /** A file this context was built from no longer matches the snapshot. */
    export function blockingDrift(project: number, context: D1UsecaseContext, digests: readonly D1SourceDigest[]): Promise<D1SourceFinding | null>;
    export function ontologyTransitions(body: unknown): TransitionBody[];
    export function namespaceOf(body: unknown): string;
    export function capabilityNames(body: unknown): string[];
    export function platformFieldPaths(body: unknown): string[];
    /** Ontology paths marked writePrecondition. A field named version without the mark is not included. */
    export function writePreconditionPaths(body: unknown): string[];
    /**
     * The ontology file wins. When that file is absent, only fields the caller already marked count.
     * An unmarked name is not a precondition.
     */
    export function preconditionsFor(files: readonly {
        path: string;
        text: string;
    }[] | undefined, moduleName: string, entityId: string, fallback: readonly {
        name: string;
        writePrecondition?: boolean;
    }[]): string[];
    /**
     * Optionality and preconditions the ontology actually declares.
     * The domain draft's field list is the fallback when that file is absent.
     * The gate and the fidelity reader must use the same list, or a call the gate
     * stored will not match the call fidelity recomputes.
     */
    export function declaredFieldsFor(files: readonly {
        path: string;
        text: string;
    }[] | undefined, moduleName: string, entityId: string, fallback: readonly {
        name: string;
        optional?: boolean;
    }[]): readonly {
        name: string;
        optional?: boolean;
    }[];
    /** One route whose contract could not be read, and why. */
    export interface MdmContractRead {
        /** Shared fields. `null` when any route contract was not read: one route never borrows another's fields. */
        fields: readonly MdmInputField[] | null;
        /**
         * One reason per route that did not resolve: contract absent, binding absent, binding ambiguous,
         * input not declared, input symbol absent, or input symbol duplicated.
         */
        unread: readonly string[];
    }
    /**
     * Input fields of this operation, taken from the domain signature.
     * `page` and `pageSize` are application paging, not MDM arguments.
     * An empty list means the ontology declares nothing for this operation.
     */
    export function mdmInputFields(input: readonly {
        name: string;
    }[], preconditions: readonly string[], declared?: readonly {
        name: string;
        optional?: boolean;
    }[]): MdmContractRead;
    export function flattenContractFields(fields: readonly D1ContractField[]): D1ContractPath[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/dispatch" {
    import type { D1PromptEvidence } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    import { type D1FanoutConfig } from "_102021_/l2/agentDefsL1/helpers/d1Fanout";
    /** usecases50 on the shared fan-out (`helpers/d1Fanout.ts`): one worker per selected usecase. */
    export const USECASES_FANOUT: D1FanoutConfig;
    export const FANOUT_TITLE = "Generating {{completed}}/{{total}} items, failed {{failed}}";
    export interface D1WorkerArg {
        planId: string;
        moduleName: string;
        project: number;
        usecaseId: string;
        attempt: number;
        unitAttempts: number;
        globalAttempts: number;
        feedback: string;
    }
    export interface D1AttemptTrace {
        usecaseId: string;
        status: 'parsed' | 'repairable' | 'operational';
        trace: string;
        unitAttempts: number;
        reply: unknown;
        /** The prompt the hook assembled. Present after prepareWorker. */
        request?: D1PromptEvidence;
        /** True when the code derived the steps and the model was not called (d1_55). */
        derived?: boolean;
    }
    export interface D1RepairOrder {
        usecaseId: string;
        unitAttempts: number;
        globalAttempts: number;
        planId: string;
        feedback: string;
    }
    export interface D1BarrierDecision {
        repairs: D1RepairOrder[];
        identified: Array<{
            usecaseId: string;
            trace: string;
            code: string;
        }>;
        pause: boolean;
    }
    /** Compact, stable JSON. One arg is one usecase. */
    export function workerArg(arg: D1WorkerArg): string;
    export function parseWorkerArg(value: string): D1WorkerArg | null;
    export function firstWorkerArg(project: number, moduleName: string, usecaseId: string): string;
    export function fanoutStep(project: number, moduleName: string, args: readonly string[]): mls.msg.AIAgentStep;
    export function fanoutExecution(args: readonly string[]): mls.msg.ExecutionMode;
    export function barrierStep(project: number, moduleName: string, dependsOn: readonly string[], round: string): mls.msg.AIAgentStep;
    /** One repair per usecase, and no more than the global ceiling. Same rule as every fan-out step. */
    export function decideRepairs(input: {
        expected: readonly string[];
        attempts: readonly D1AttemptTrace[];
        globalAttempts: number;
        feedbackFor: (usecaseId: string) => string;
    }): D1BarrierDecision;
    export function repairStep(project: number, moduleName: string, order: D1RepairOrder): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/fidelity" {
    import type { D1UsecaseMdm } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface FidelityFile {
        path: string;
        text: string;
    }
    export interface FidelityProblem {
        code: string;
        path: string;
        message: string;
    }
    export interface D1FieldUse {
        path: string;
        role: 'filter' | 'selector' | 'concurrency' | 'write';
        source: 'input' | 'payload';
    }
    export interface UsecaseBehavior {
        usecaseId: string;
        operation: string;
        mdm: D1UsecaseMdm | null;
        rules: Array<{
            ruleId: string;
            path: string;
            symbol: string;
        }>;
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        routes: Array<{
            route: string;
            contractPath: string;
            symbol: string;
            outputFields: string[];
        }>;
    }
    /**
     * Classifies a derived field the same way the gate does.
     * A payload is a write. Identity on a read is a filter; on an update or
     * transition it is a selector. A nested derived field on a read is a filter.
     * `version` on an update or transition is concurrency.
     */
    export function fieldUses(input: {
        operation: string;
        fields: readonly {
            name: string;
            derived: boolean;
        }[];
        inputPaths: readonly string[];
        payloadPaths: readonly string[];
    }): D1FieldUse[];
    /**
     * Reads one serialized usecase def and the dependency texts it names.
     * It does not take the draft. A rule id, a file count or a signature is not enough.
     */
    export function readUsecaseFidelity(source: string, files: readonly FidelityFile[]): {
        behavior: UsecaseBehavior | null;
        problems: FidelityProblem[];
    };
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1UsecaseBuild, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    /**
     * One deterministic pass from the selection, the domain draft and the ports.
     * The model does not order steps.
     */
    export function buildD1Usecases(request: D1UsecaseRequest): D1UsecaseBuild;
    /** A usecase file must not depend on an adapter. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1AttemptTrace } from "_102021_/l2/agentDefsL1/steps/usecases50/dispatch";
    import { D1_USECASE_VERSION, type D1PromptEvidence, type D1UsecaseBuild, type D1UsecasePlanInput, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface D1UsecaseWork {
        schemaVersion: typeof D1_USECASE_VERSION;
        repairs: number;
        request: D1UsecaseRequest;
    }
    export function loadD1UsecaseWork(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        work: D1UsecaseWork;
    }>;
    export function readD1UsecaseWork(project: number, moduleName: string): Promise<D1UsecaseWork | null>;
    export function writeD1UsecaseWork(project: number, work: D1UsecaseWork): Promise<void>;
    export function workFile(project: number, moduleName: string): D1FileInfo;
    export function attemptFile(project: number, moduleName: string, usecaseId: string): D1FileInfo;
    export function writeAttempt(project: number, moduleName: string, attempt: D1AttemptTrace): Promise<void>;
    /** The assembled prompt, written before the model replies. Not an attempt: it has no status. */
    export function writePromptEvidence(project: number, moduleName: string, evidence: D1PromptEvidence): Promise<void>;
    /** A source finding already closed this worker. A later empty reply must not replace it. */
    export function sourceBlockTrace(project: number, moduleName: string, usecaseId: string): Promise<string | null>;
    /** A derived attempt has no model reply. Its trace stays when the host closes the worker without a payload. */
    export function derivedTrace(project: number, moduleName: string, usecaseId: string): Promise<string | null>;
    export function readPromptEvidence(project: number, moduleName: string, usecaseId: string): Promise<D1PromptEvidence | null>;
    /** Usecase defs the plan marks `preserve`. The commit does not send them. */
    export function preservedDefPaths(snapshot: D1InputSnapshot | null): Set<string>;
    /** Usecase ids the plan marks `preserve`. */
    export function preservedUsecaseIds(snapshot: D1InputSnapshot | null): Set<string>;
    export function readAttempts(project: number, moduleName: string, usecaseIds: readonly string[]): Promise<D1AttemptTrace[]>;
    export function commitD1Usecases(project: number, build: D1UsecaseBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    export function plansFromAttempts(attempts: readonly D1AttemptTrace[]): D1UsecasePlanInput[];
    export function buildFromWork(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], llmCalls: number): D1UsecaseBuild;
    /**
     * Defs of units that parsed stay. Each identified unit is one error on its
     * usecase id and has no definition. `ok` stays false.
     */
    export function holdUnresolvedBuild(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], identified: readonly {
        usecaseId: string;
        code: string;
        trace: string;
    }[], llmCalls: number): D1UsecaseBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/callLog" {
    /**
     * Receipts of what usecases50 already observes. One file per observation so
     * parallel workers do not share a counter. A missing folder is not zero.
     */
    export const D1_CALL_LOG_VERSION: "2026-09-24-d1-calls-v1";
    export const CALL_ABSENT = "usecases50 call log is absent";
    export const CALL_HISTORY_ABSENT = "generation call history is absent";
    export const CALL_UNREADABLE = "usecases50 call log has an unreadable event";
    export const CALL_NO_INVOCATION = "usecases50 call log has no invocation";
    export type D1CallEventKind = 'prompt_assembled' | 'reply_delivered' | 'reply_absent' | 'not_dispatched' | 'repair_scheduled'
    /** Steps the code derived. No prompt, no reply, not a model call (d1_55). */
     | 'derived';
    export interface D1CallEvent {
        schemaVersion: typeof D1_CALL_LOG_VERSION;
        kind: D1CallEventKind;
        usecaseId: string;
        planId: string;
        /** Index on the worker arg. Not a call count. */
        unitAttempts: number;
        invocation: number;
    }
    export interface D1CallInvocation {
        schemaVersion: typeof D1_CALL_LOG_VERSION;
        kind: 'dispatch' | 'resume';
        index: number;
        /** True only when this resume found no generation observations. */
        historyAbsent: boolean;
    }
    export interface D1CallLog {
        invocations: D1CallInvocation[];
        events: D1CallEvent[];
        unreadable: boolean;
    }
    /** Counts proved by the log. Null is unmeasured. Zero is a measured receipt count. */
    export interface D1CallAccount {
        /** Host delivered a reply payload. Not units, attempts, prompts, or cost. */
        repliesDelivered: number | null;
        repliesUnknown: string;
        /** Prompts handed to the host. Not completed calls. */
        promptsAssembled: number | null;
        /** Repair steps the barrier opened. Not calls. */
        repairsScheduled: number | null;
        /** Reply payloads of the latest invocation. A resume without a call is 0. */
        invocationReplies: number | null;
        invocationUnknown: string;
        /** finalize80 does not call a model. Local step, not the generation. */
        finalizeCalledModel: false;
        /** finalize80 does not open a repair. Local step, not the generation. */
        finalizeOpenedRepair: false;
    }
    export function callsFolder(moduleName: string): string;
    export function accountCalls(log: D1CallLog | null): D1CallAccount;
    export function readCallLog(project: number, moduleName: string): Promise<D1CallLog | null>;
    /** A new dispatch. Workers record against this index afterwards. */
    export function openCallDispatch(project: number, moduleName: string): Promise<number>;
    /**
     * This invocation added no call. Observations already on disk stay.
     * No observations means the generation total stays unknown.
     */
    export function openCallResume(project: number, moduleName: string): Promise<void>;
    /** First file for this plan and kind wins. A second delivery does not add a row. */
    export function recordCallEvent(project: number, moduleName: string, event: {
        kind: D1CallEventKind;
        usecaseId: string;
        planId: string;
        unitAttempts: number;
    }): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/gate" {
    import { type D1ControllerBuild, type D1ControllerGrant, type D1ControllerRequest } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    /**
     * One controller per page. Ids, route strings and contract symbols are copied.
     * An operation with no grant is an error. There is no public fallback.
     */
    export function buildD1Controllers(request: D1ControllerRequest): D1ControllerBuild;
    /** A grant whose actor is not on this page is a union. The caller does not add it. */
    export function grantUnionIssues(pageActors: readonly string[], grantIds: readonly string[], grants: readonly D1ControllerGrant[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/io" {
    import { type D1ControllerBuild, type D1ControllerGrant, type D1ControllerProblem } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export function assembleD1Controllers(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1ControllerBuild;
    }>;
    export function commitD1Controllers(project: number, build: D1ControllerBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** `summaryOnly` is the L4 name of `fieldsOnly`. Any other mode is an error on the grant. */
    export function accessGrantsOf(access: unknown, ontology: Record<string, unknown>): {
        grants: D1ControllerGrant[];
        problems: D1ControllerProblem[];
    };
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/contracts" {
    import type { D1_MEASURED_PUBLISH, D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1ControllerGrant, D1ControllerRelationship, D1ScopeGrantPlan } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export const D1_SUPPORT_VERSION: "2026-10-01-d1-support-v2";
    /** Same trail as the earlier steps. Uncited values stay on the domain draft. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Scope and registry have no values slot. Enum values stay on the domain draft.";
    export const ENUMERATION_CONSUMED_REASON: "Seed scenarios cite every value of this enum. The values are not copied into rows.";
    /** A covered consumer names this field. The union is not runtime enforcement. */
    export const ENUMERATION_PROVED_REASON: "A covered consumer names this entity and path. A type union is not runtime enforcement. Values stay on the domain draft.";
    export type D1EnumOwner = 'platform' | 'module' | 'unresolved';
    export type D1EnumWriter = 'platform' | 'module' | 'derived' | 'unresolved';
    export type D1EnumRestriction = 'inherited' | 'subset' | 'own' | 'invalid' | 'unresolved';
    export type D1EnumPurpose = 'seedScenario' | 'usecaseDef' | 'domainDef';
    /** One proved use. A homonymous literal on another entity or path is not this use. */
    export interface D1EnumUse {
        purpose: D1EnumPurpose;
        consumer: string;
        entityId: string;
        path: string;
        values: string[];
        /** False when the field is derived, a role binding, or the literal is only on an output. */
        editable: boolean;
    }
    /** Catalog owner, writer and restriction. They are not one badge. */
    export interface D1EnumOrigin {
        owner: D1EnumOwner;
        writer: D1EnumWriter;
        derived: boolean;
        restriction: D1EnumRestriction;
        catalogValues: string[];
        catalogSource: string;
        roleBinding: boolean;
    }
    /** A seed scenario that names one entity and one field. Not a global set of literals. */
    export interface D1SeedCitation {
        entityId: string;
        path: string;
        scenarioId: string;
        values: string[];
    }
    export interface D1SupportProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1SupportNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1SupportEnumeration {
        entityId: string;
        path: string;
        values: string[];
        /** True when `uses` is non-empty. Not runtime enforcement. */
        consumed: boolean;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON | typeof ENUMERATION_CONSUMED_REASON | typeof ENUMERATION_PROVED_REASON;
        origin: D1EnumOrigin;
        uses: D1EnumUse[];
        limits: string;
    }
    export type D1EnumRow = D1SupportEnumeration;
    export interface D1SupportFile {
        artifactType: string;
        defPath: string;
        action: string;
        /** Hash inventoried on the input receipt. Empty when this run has no receipt. */
        contentHash: string;
        /** Hash of the bytes on disk now. Empty when the file is absent. */
        currentHash: string;
    }
    /** An adapter persistence40 already planned. A removed adapter is not live. */
    export interface D1SupportAdapter {
        portId: string;
        entityId: string;
        tableId: string;
        artifactId: string;
        action: string;
        defPath: string;
    }
    export interface D1SupportJoinStep {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Join helper recorded as a def. This step does not write a TypeScript file for it. */
    export interface D1SupportHelper {
        helperId: string;
        session: 'verified';
        steps: D1SupportJoinStep[];
        consumers: string[];
    }
    export interface D1SupportEdge {
        id: string;
        type: string;
        dependsOn: string[];
    }
    /** One entity of the grant. The anchor's steps stay empty. Another entity is pending when no field reaches the anchor. */
    export interface D1EntityScopePath {
        entityId: string;
        steps: D1SupportJoinStep[];
        pending: string;
    }
    export interface D1ScopeResolution {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        /** The mode the access artifact declared. Never replaced by a permissive fallback. */
        scopeMode: string;
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
        helperId: string;
    }
    export interface D1RegistryAdapter {
        portId: string;
        adapterArtifactId: string;
        factory: string;
        defPath: string;
        dependsOn: string[];
    }
    export interface D1PublicationItem {
        artifactType: string;
        defPath: string;
        outputPath: string;
        registers: string;
    }
    export interface D1PublicationLater {
        artifactType: string;
        defPath: string;
        reason: string;
    }
    /** Local table the seed plan may describe. An MDM table is refused. */
    export interface D1SeedTable {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        uniqueKeys: string[][];
    }
    export interface D1SeedTransition {
        transitionId: string;
        to: string;
        ruleRefs: string[];
    }
    /** Model facts the seed plan may cite. It does not invent rows from them. */
    export interface D1SeedModel {
        entityId: string;
        storageTarget: string;
        kind: 'role' | 'entity';
        namespace: string;
        fields: Array<{
            name: string;
            type: string;
        }>;
        states: string[];
        initialState: string;
        uniqueKeys: string[][];
        transitions: D1SeedTransition[];
        /** Empty when the model does not declare the note field. */
        noteField: string;
    }
    export interface D1SeedEffect {
        entityId: string;
        effect: string;
        transitionRef: string;
    }
    export interface D1SeedJourney {
        journeyId: string;
        entities: string[];
        effects: D1SeedEffect[];
    }
    /** A role or actor tag. It is not the MDM entity id. */
    export interface D1SeedRoleTag {
        tag: string;
        entityId: string;
    }
    export interface D1SeedRef {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDataset {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    export interface D1SeedDependency {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedMaintenance {
        action: 'reseed' | 'reset' | 'removeOwner';
        ownerId: string;
    }
    /** Plan versus rows. This step never sets materialized or a row count above zero. */
    export interface D1SeedReport {
        phase: 'plan' | 'absent';
        materialized: false;
        rowCount: 0;
        datasets: D1SeedDataset[];
        dependencies: D1SeedDependency[];
    }
    /** One outbound event from the integration artifact. `mechanism` is empty when the artifact names none. */
    /** A selected transition usecase. Two entities may share the transitionRef (d1_53). */
    export interface D1TransitionUsecase {
        entity: string;
        transitionRef: string;
        usecaseId: string;
    }
    /** Selected transition usecases, keyed by entity and L4 transitionRef. */
    export function transitionUsecasesOf(selected: readonly {
        usecaseId: string;
        entity: string;
        operation: string;
        transitionRef?: string;
        identity: string;
    }[]): D1TransitionUsecase[];
    /** The usecase of one entity transition, or '' when none was selected. Never a usecase named like the transition. */
    export function transitionUsecaseFor(list: readonly D1TransitionUsecase[], entity: string, transitionRef: string): string;
    /** A selected usecase that is not a transition. */
    export interface D1OperationUsecase {
        entity: string;
        operation: string;
        usecaseId: string;
    }
    /** Selected usecases whose operation is not `transition`. `usecaseId` is `identity` when set. */
    export function operationUsecasesOf(selected: readonly {
        usecaseId: string;
        entity: string;
        operation: string;
        identity: string;
    }[]): D1OperationUsecase[];
    export interface D1EffectEvent {
        eventId: string;
        on: string;
        mechanism: string;
        /** True only when the transition object declares `payload`. */
        payloadDeclared: boolean;
    }
    /** An inbound item or plugin. A workflow process is a `D1ProcessPlan`, not an operation. */
    export interface D1EffectOperation {
        id: string;
        kind: 'inbound' | 'plugin';
        operations: string[];
        mechanism: string;
        consumer: string;
        /** A scheduled trigger is preserved as a review. This step does not write a scheduler. */
        scheduled: boolean;
    }
    /** One workflow process read from the L4. `occurrence` is empty when the initial stage does not name an entity. */
    export interface D1ProcessPlan {
        processId: string;
        trigger: {
            kind: 'manual' | 'event' | 'scheduled';
            actorRef?: string;
            event?: string;
            schedule?: string;
        };
        occurrence: string;
        functions: string[];
        operations: Array<{
            operation: string;
            steps: string[];
            selected: boolean;
        }>;
        humanJourneys: string[];
    }
    /** The measured publish API as evidence. Naming it does not bind or execute an effect. */
    export interface D1EffectReport {
        phase: 'plan' | 'absent';
        executed: false;
        capability: {
            symbol: typeof D1_MEASURED_PUBLISH.symbol;
            path: typeof D1_MEASURED_PUBLISH.path;
            owner: typeof D1_MEASURED_PUBLISH.owner;
            payload: typeof D1_MEASURED_PUBLISH.payload;
            delivery: typeof D1_MEASURED_PUBLISH.delivery;
            transaction: typeof D1_MEASURED_PUBLISH.transaction;
            requestContextPublish: false;
            bound: boolean;
        };
    }
    export interface D1SupportRequest {
        project: number;
        moduleName: string;
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        /** Scope plans controllers60 already resolved. The anchor is not corrected here. */
        scopePlans: D1ScopeGrantPlan[];
        /** Grant ids cited by handlers. A missing id is a diagnosis, not a new grant. */
        citedGrantIds: string[];
        adapters: D1SupportAdapter[];
        files: D1SupportFile[];
        /** Helpers already on the draft. A helper stays while one live consumer remains. */
        existingHelpers: D1SupportHelper[];
        /** Edges already emitted by application defs. An adapter or registry edge is inverted. */
        applicationEdges: D1SupportEdge[];
        /** Form field names a contract offered as identity. They are not the session. */
        formFields: string[];
        enumerations: Array<{
            entityId: string;
            path: string;
            values: string[];
        }>;
        /** Local tables persistence40 planned. A role table is not a seed target. */
        tables: D1SeedTable[];
        models: D1SeedModel[];
        journeys: D1SeedJourney[];
        /** Journey ids the index names and this step could not read. */
        missingJourneys: string[];
        roleTags: D1SeedRoleTag[];
        /** Extra refs a caller proposed. A ref without a column relationship is refused. */
        seedRefs: D1SeedRef[];
        /**
         * Ontology, catalog and serialized defs already opened for this run.
         * Absent on a fixture that only classifies seed citations.
         */
        enumSnapshot?: {
            sources: Record<string, string>;
            definitions: string[];
            tables: Array<{
                tableId: string;
                entityId: string;
            }>;
        };
        /** Datasets already shared. Dropping one owner does not drop the dataset. */
        existingDatasets: D1SeedDataset[];
        /**
         * `backend.json.testSupport[]` (p1_12, backend v1.2), already checked by input20 (d1_39). Empty or
         * absent: the seeds def carries no certification fixture.
         */
        testSupport?: unknown[];
        /** Set when the backend plan changed after input20: its testSupport was not read. */
        testSupportUnread?: string;
        maintenance: D1SeedMaintenance | null;
        /** Outbound rows of the integration artifact. */
        outbound: D1EffectEvent[];
        /** Event ids input20 selected. A selected id missing here is an omission. */
        selectedEventIds: string[];
        /** Usecase ids the plan selected. A process, inbound or plugin operation must be one of these. */
        usecaseIds: string[];
        /** Selected transition usecases by entity and L4 transitionRef. An outbound event binds one of these. */
        transitionUsecases: D1TransitionUsecase[];
        /**
         * Selected non-transition usecases. Absent on a fixture built before this list existed.
         * An outbound `Entidade.<op>` binds one of these when it is not a transition.
         */
        operationUsecases?: D1OperationUsecase[];
        /** Inbound and plugins. A workflow does not become an endpoint. */
        operations: D1EffectOperation[];
        /** One plan per L4 process. The def is not emitted here. */
        processes: D1ProcessPlan[];
    }
    export interface D1SupportEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
        /** Set when status is blocked. The receipt, not the def, carries the reason. */
        blockReason?: string;
    }
    export interface D1SupportBuild {
        schemaVersion: typeof D1_SUPPORT_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1SupportEnumeration[];
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        registry: D1RegistryAdapter[];
        publication: {
            stillToRegister: D1PublicationItem[];
            later: D1PublicationLater[];
        };
        /** Separates the seed plan from rows. Rows are not written here. */
        seedPlan: D1SeedReport;
        /** Effect plan. `executed` stays false. An empty mechanism stays unbound. */
        effectPlan: D1EffectReport;
        problems: D1SupportProblem[];
        normalizations: D1SupportNormalization[];
        emit: D1SupportEmit[];
    }
}
declare module "_102034_/l2/mdm/resolveMdmEntity" {
    /**
     * The reader of the ontology: it turns `l4/ontology/mdm.defs.ts` (the platform) and a module ontology in
     * the v3 form (`mls-<client>/l4/<module>/ontology/<Entity>.defs.ts`) into ONE view — the columns, the
     * `details` tree, the links, the capabilities and the rules of a single entity (ns5_39 T3).
     *
     * PURE ON PURPOSE. No `node:*`, no engine (`module.ts`, `mdmFacade.ts`, `persistence.ts`), no I/O: the
     * clarification screen imports this file in the browser and hands it two objects it already read.
     * `resolveMdmEntity.test.ts` asserts that purity against this file's own source, so it cannot rot.
     *
     * What it does NOT do: it does not validate. A divergence is reported ON the node (`conflict`,
     * `tightened`, `unresolved`) for the screen to show — never thrown, never silently repaired. The gate is
     * `ontology30`, and it is still v2 (out of scope here).
     */
    import type { MdmOntology, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    import type { Ns5OntologyEntityV3, Ns5OntologyIndexV3, Ns5RulesAny } from "_102035_/l2/solution/types";
    /** How ready the platform is, read from the tail of the catalog sentence. A badge, never a gate. */
    export type OntologyPlatformStatus = 'ready' | 'partial' | 'missing';
    /** Who writes the field. `derived` wins over `platform`: the engine owns it, so no form may offer it. */
    export type OntologyOrigin = 'platform' | 'module' | 'derived';
    export interface OntologyValue {
        value: string;
        title: string;
    }
    export interface OntologyNode {
        /** Field id inside its parent. */
        id: string;
        /** Full path from the record root: `details.identification.name`, `scheduledAt`. */
        path: string;
        title: string;
        type: string;
        required: boolean;
        nullable: boolean;
        collection: boolean;
        derived: boolean;
        indexed: boolean;
        unique: boolean;
        /** Reusable value type of `mdm.types`. */
        of?: string;
        /** Records this field points at. */
        to?: readonly string[];
        values?: readonly OntologyValue[];
        /** Only on a branch of `details`. */
        owner?: 'platform' | 'organization' | 'module';
        /** The branch declares no closed key set (`general`, the module namespace on the platform side). */
        open?: true;
        description?: string;
        /** Only on a module view. */
        origin?: OntologyOrigin;
        /** The module declares a field the platform already owns under that branch, or an identity field
         * inside its own namespace (`rule-identity-never-in-namespace`). The screen warns. */
        conflict?: true;
        /** The module narrowed a closed domain the platform declares wider. Legitimate; shown as a note. */
        tightened?: true;
        children?: OntologyNode[];
    }
    export interface OntologyRelationshipView {
        /** The name the entity gave the link; on the platform view, the catalog type. */
        name: string;
        /** The row of the module index that carries it. Absent on the platform view. */
        relationshipId?: string;
        /** Catalog type (`GuardianOf`), or the column / table walked. */
        via: string;
        title: string;
        description?: string;
        /** The far end. */
        to: readonly string[];
        /** Which end of the link this entity sits on. */
        side: 'from' | 'to' | 'both';
        mode: 'fk' | 'throughTable' | 'mdmRelationship';
        cardinality?: string;
        required?: boolean | string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        /** Says how the entity and the module index disagree. The index is the source. */
        conflict?: string;
    }
    export interface OntologyCapabilityView {
        id: string;
        /** The catalog sentence for a platform id; the module sentence for a module id. */
        sentence: string;
        /** Only on a platform id: what the platform sentence says about itself. */
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        /** Only on a module view of a platform id: what the module says it uses it for. */
        moduleSentence?: string;
        /** The id is in no catalog. */
        unresolved?: true;
    }
    export interface OntologyRuleView {
        id: string;
        text: string;
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        unresolved?: true;
    }
    export interface OntologyTreeView {
        entityId: string;
        title: string;
        description: string;
        kind: 'platform' | 'role' | 'entity';
        /** The MDM subtype, on the platform view and on a role. */
        subtype?: string;
        displayField: string;
        /**
         * The top-level fields of the record OTHER than `details` — `details` is returned expanded below.
         * `{ id, version }` on an MDM record; on a module table also every indexed column.
         */
        columns: OntologyNode[];
        /** The branches of the document, in the order `record.fields.details.groups` declares. */
        details: OntologyNode[];
        relationships: OntologyRelationshipView[];
        capabilities: OntologyCapabilityView[];
        rules: OntologyRuleView[];
    }
    /** The badge, read from the tail of the catalog sentence. Absent when the sentence does not say. */
    export function readPlatformStatus(sentence: string): OntologyPlatformStatus | undefined;
    /**
     * The whole platform record of one subtype: `{ id, version }` plus the five branches of `details`, the
     * relationship types the subtype takes part in, and the capabilities and rules that reach it.
     *
     * `moduleId` names the module namespace branch; without it the branch keeps the placeholder key
     * `<moduleId>` the ontology itself uses.
     */
    export function resolvePlatformEntity(mdm: MdmOntology, subtype: MdmSubtypeName, moduleId?: string): OntologyTreeView;
    /**
     * The entity of a module, read against the platform it sits on.
     *
     * On a `role`, every node of `details` is marked `platform` / `module` / `derived` by comparing it with
     * the branch the platform declares; a module field that shadows a platform field — or any identity field
     * inside the module namespace — is flagged `conflict`. The capabilities and rules keep BOTH sentences:
     * the catalog's (what the platform does) and the module's (what the clinic uses it for). The links are
     * crossed with the module index, which is the source; a disagreement becomes `conflict` on the link.
     */
    export function resolveModuleEntity(entity: Ns5OntologyEntityV3, index: Ns5OntologyIndexV3, mdm: MdmOntology, moduleRules: Ns5RulesAny): OntologyTreeView;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/enumerations" {
    import { type D1EnumRow, type D1SeedCitation } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /** What the report looked at. A union or an owner is not runtime enforcement. */
    export const ENUMERATION_LIMITS: "Covered uses are a seed scenario that names this entity and path, and a domain or usecase def whose type names this path with those literals. A TypeScript union is not runtime enforcement. Ownership is not consumption. No seed, catalog or table is created here.";
    export interface D1EnumSnapshot {
        sources: Record<string, string>;
        definitions: string[];
        tables: Array<{
            tableId: string;
            entityId: string;
        }>;
    }
    export interface D1EnumInput {
        enumerations: ReadonlyArray<{
            entityId: string;
            path: string;
            values: readonly string[];
        }>;
        snapshot?: D1EnumSnapshot;
        seedCitations?: readonly D1SeedCitation[];
    }
    /**
     * Projects origin, restriction and proved uses for each enumeration.
     * Does not read the filesystem and does not invent a seed, a catalog or a table.
     */
    export function projectEnumerations(input: D1EnumInput): D1EnumRow[];
    /** The field a model's lifecycle states belong to, when exactly one enum has that value set. */
    export function lifecyclePath(entityId: string, states: readonly string[], enumerations: ReadonlyArray<{
        entityId: string;
        path: string;
        values: readonly string[];
    }>): string;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/gate" {
    import { type D1RegistryAdapter, type D1ScopeResolution, type D1EffectReport, type D1SeedCitation, type D1SeedReport, type D1SupportAdapter, type D1SupportBuild, type D1SupportEmit, type D1SupportHelper, type D1SupportNormalization, type D1SupportProblem, type D1SupportRequest } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /**
     * Registry, scope and the seed plan. No model call.
     * A grant keeps its declared mode, the verified session, the relationship path and any pending.
     * A missing grant or an anchor with no explicit path is a diagnosis.
     * It is not rewritten as organization or public.
     * Seeds describe scenarios. They do not write rows.
     * Effects name the consumer and keep an empty mechanism when none was declared.
     * Nothing is published.
     */
    export function buildD1Support(request: D1SupportRequest): D1SupportBuild;
    /** Access scope and the authority map. The map adds no grant. */
    export function emitScope(request: D1SupportRequest, problems: D1SupportProblem[]): {
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        emit: D1SupportEmit[];
    };
    /** Live adapters only. The registry depends on them. They do not depend on it. */
    export function emitRegistry(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        adapters: D1RegistryAdapter[];
        live: D1SupportAdapter[];
        emit: D1SupportEmit[];
    };
    /**
     * One seed plan for the local tables. Journeys and models supply scenarios.
     * MDM roles are dependencies, not rows. A ref needs a column relationship.
     */
    export function emitSeeds(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        emit: D1SupportEmit[];
        plan: D1SeedReport;
        citations: D1SeedCitation[];
    };
    /**
     * One outbound def. An event's consumer is the usecase of its entity and transitionRef.
     * An empty mechanism stays empty. publishEvent and emitEvent are refused.
     * IQueueRuntime.publish is evidence, not an approved binding.
     * Inbound items and plugins stay operations. A workflow process is its own def.
     */
    export function emitEffects(request: D1SupportRequest, problems: D1SupportProblem[]): {
        emit: D1SupportEmit[];
        report: D1EffectReport;
    };
    /**
     * One workflowProcess def per plan. Occurrence is omitted when the plan did not derive one.
     * A gap stays a review. The def is pending. The declared set is workflows, human journeys,
     * the occurrence ontology, then selected usecases. definitionIssues and stampDefinition
     * require that set sorted, and that sorted order is what enters the hash.
     */
    export function emitProcesses(request: D1SupportRequest, problems: D1SupportProblem[]): {
        emit: D1SupportEmit[];
    };
}
declare module "_102021_/l2/agentDefsL1/steps/support70/io" {
    import { type D1SelectedUsecase } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import { type D1EffectOperation, type D1ProcessPlan, type D1SupportBuild, type D1SupportFile } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    import type { D1ControllerGrant, D1ControllerProblem } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export function assembleD1Support(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1SupportBuild;
        files: D1SupportFile[];
    }>;
    export function commitD1Support(project: number, build: D1SupportBuild, files: readonly D1SupportFile[]): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A support def is removed only when this build did not keep it for a live consumer. */
    export function supportFilesToRemove(build: D1SupportBuild, files: readonly D1SupportFile[]): D1SupportFile[];
    /** `summaryOnly` is the L4 name of `fieldsOnly`. Any other mode is an error on the grant. */
    export function accessGrantsOf(access: unknown, entities: Record<string, unknown>): {
        grants: D1ControllerGrant[];
        problems: D1ControllerProblem[];
    };
    /** Inbound operations come from the L4 effect, never from a name built out of the entity. */
    export function inboundOperation(row: Record<string, unknown>, selected: readonly D1SelectedUsecase[]): D1EffectOperation | null;
    /** L4 processes as plans. Occurrence and operations follow the workflowProcess rule. No def is written. */
    export function processesOf(project: number, moduleName: string, selected: readonly D1SelectedUsecase[]): Promise<D1ProcessPlan[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/agentD1Support" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/contracts" {
    import type { D1ArtifactType } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineState, D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1CallAccount, D1CallLog } from "_102021_/l2/agentDefsL1/steps/usecases50/callLog";
    import type { D1EnumOrigin, D1EnumUse } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    import type { PoolTraceLine } from "_102035_/l2/solution/pool";
    /**
     * v2: `consumed` means a covered consumer was proved for this entity and path.
     * It no longer means "every literal appeared in the seed set".
     * `origin` separates catalog owner, writer and restriction. `uses` names the consumer.
     */
    export const D1_REPORT_VERSION: "2026-09-24-d1-report-v3";
    /** Recognition by the inventory reader is not a runnable backend. */
    export const INVENTORY_NOTE: "Inventory recognition is not certification of an executable backend.";
    /** Product types and the step that writes them. Matching is by artifact type, not by file name. */
    export const PHASE_OF_TYPE: Record<D1ArtifactType, D1StepId>;
    export const CHAIN_STEP_IDS: readonly ["entry10", "input20", "resolve25", "domain30", "persistence40", "usecases50", "controllers60", "support70"];
    export interface D1FinalizeChild {
        planId: string;
        status: string;
        artifactPath: string;
        present: boolean;
    }
    export interface D1FinalizeObserved {
        defPath: string;
        text: string | null;
        currentHash: string;
        /** Hash the write receipt expects now. Empty when this file has no such receipt. */
        receiptHash: string;
        action: string;
        ownerRefs: string[];
        unitDone: boolean;
    }
    export interface D1FinalizeContract {
        path: string;
        text: string | null;
        hash: string;
    }
    export interface D1FinalizeRequest {
        project: number;
        moduleName: string;
        /** Rule ids from `l4/<module>/rules.defs.ts`. Empty when that file is absent. */
        moduleRules: string[];
        pipeline: D1PipelineState;
        snapshot: D1InputSnapshot | null;
        sourceHashes: Record<string, string>;
        /** Texts opened for fidelity: snapshot sources and declared read dependencies. Not the usecase draft. */
        dependencyTexts: Record<string, string>;
        contracts: Record<string, D1FinalizeContract>;
        drafts: {
            domain30: unknown;
            persistence40: unknown;
            usecases50: unknown;
            controllers60: unknown;
            support70: unknown;
        };
        observed: D1FinalizeObserved[];
        /** Future output path → the `.ts` file is on disk. Absence is expected. */
        futurePresent: Record<string, boolean>;
        children: D1FinalizeChild[];
        /** Observations usecases50 recorded. Null when that folder was not written. */
        callLog: D1CallLog | null;
    }
    export interface D1FinalizePhase {
        stepId: D1StepId;
        executed: boolean;
        status: 'approved' | 'failed' | 'absent';
        error: string;
    }
    export interface D1FinalizeFinding {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
        ownerRef: string;
    }
    export interface D1FinalizeFile {
        defPath: string;
        action: 'generated' | 'preserved' | 'removed' | 'notGenerated';
        ownerRefs: string[];
        sourceHash: string;
        phase: string;
    }
    export interface D1FinalizeEnum {
        entityId: string;
        path: string;
        /** Effective values declared by the module. Not the catalog. */
        values: string[];
        /** True when `uses` is non-empty. Not runtime enforcement. */
        consumed: boolean;
        origin: D1EnumOrigin;
        uses: D1EnumUse[];
        limits: string;
    }
    export interface D1FinalizePending {
        defPath: string;
        outputPath: string;
        present: boolean;
    }
    export interface D1FinalizeInventory {
        usecaseIds: string[];
        routes: string[];
        portIds: string[];
        tableIds: string[];
    }
    export interface D1FinalizeReport {
        schemaVersion: typeof D1_REPORT_VERSION;
        project: number;
        moduleName: string;
        /**
         * Receipts from the call log. Not a billing total and not a unit count.
         * `finalizeCalledModel` / `finalizeOpenedRepair` describe this step only.
         */
        calls: D1CallAccount;
        executableBackend: false;
        inventoryNote: typeof INVENTORY_NOTE;
        defsStatus: 'complete' | 'incomplete' | 'notRun';
        materialization: 'pending' | 'none';
        outcome: 'complete' | 'held';
        blocking: string;
        phases: D1FinalizePhase[];
        findings: D1FinalizeFinding[];
        /** Steps that declared enum values stay on the domain draft. */
        declaredNotConsumedBy: string[];
        enumerations: {
            consumed: D1FinalizeEnum[];
            notConsumed: D1FinalizeEnum[];
        };
        files: D1FinalizeFile[];
        sources: Array<{
            path: string;
            sha256: string;
            state: string;
        }>;
        materializationPending: D1FinalizePending[];
        coverage: {
            checked: boolean;
            gaps: string[];
        };
        inventory: D1FinalizeInventory;
        snapshotHash: string;
        /**
         * Pool trace of the l1 dispatches this agent consumed (optional transport, d1_38). Written
         * before each delete; absent when no dispatch was ever consumed. Not an authorization.
         */
        pool?: PoolTraceLine[];
    }
    export function parseFinalizeReport(text: string): D1FinalizeReport | null;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/gate" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the request. Does not call a model, does not open a repair, and does
     * not treat a missing future `.ts` as a missing def.
     */
    export function buildD1Finalize(request: D1FinalizeRequest): D1FinalizeReport;
    export function earlierHold(pipeline: D1FinalizeRequest['pipeline']): boolean;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/io" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the checkpoint, the snapshot, the drafts and the defs on disk.
     * It does not run an earlier phase and it does not call a model.
     */
    export function assembleD1Finalize(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        request: D1FinalizeRequest;
    }>;
    export function writeD1Report(project: number, moduleName: string, report: D1FinalizeReport): Promise<boolean>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/agentDefsL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry";
    import "_102021_/l2/agentDefsL1/steps/input20/agentD1Input";
    import "_102021_/l2/agentDefsL1/steps/resolve25/agentD1Resolve";
    import "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain";
    import "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence";
    import "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases";
    import "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers";
    import "_102021_/l2/agentDefsL1/steps/support70/agentD1Support";
    import "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaCatalog" {
    import type { D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Absence, type D1Catalog, type D1Justification, type D1MeasuredPlan } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    /**
     * Consulta declares storage.target moduleDatabase. The other four are kind role
     * and cite the MDM catalog. They have no local table.
     */
    export const AGENDA_ENTITY_STORAGE: Record<string, D1StorageTarget>;
    export const AGENDA_JUSTIFICATIONS: D1Justification[];
    export const AGENDA_ABSENCES: D1Absence[];
    export function agendaCatalog(plan: D1MeasuredPlan): D1Catalog;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaExamples" {
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Catalog, type D1MeasuredPlan, type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export interface D1Example {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export function agendaExamples(catalog: D1Catalog, plan: D1MeasuredPlan): D1Example[];
    /** The listConsulta example also points at L2 contracts. Those paths are not outputs of this catalog. */
    export function listConsultaWithContracts(example: D1Example): D1Example;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1TestHost" {
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export interface StoredFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        status: string;
        versionRef: string;
        content: string;
        updatedAt: string;
        getValueInfo: () => Promise<{
            content: string;
        }>;
        getContent: () => Promise<string>;
    }
    export interface TestHost {
        files: Record<string, StoredFile>;
        writes: string[];
        setProject: (project: number) => void;
    }
    export function fileKey(info: {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }): string;
    export function installStudio(project: number): TestHost;
    export function seed(host: TestHost, info: D1FileInfo, content: string, updatedAt?: string): StoredFile;
    /** Host stor whose diskPath closes over a private field. Detaching the method throws. */
    export class HostStor {
        #private;
        readonly files: Record<string, StoredFile>;
        readonly writes: string[];
        getKeyToFile(info: D1FileInfo): string;
        addOrUpdateFile(params: D1FileInfo & {
            status?: string;
        }): Promise<StoredFile>;
        readonly localStor: {
            setContent: (file: StoredFile, value: {
                content?: string | null;
            }) => Promise<boolean>;
            listFolder: (project: number, level: number, folder: string) => D1FileInfo[];
            deleteFile: (file: StoredFile) => void;
        };
        diskPath(info: D1FileInfo): string;
    }
    export function installClassHost(project: number, host: HostStor): void;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1TestResolver" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import type { D2ContractV2Route } from "_102020_/l2/helpers/contractV2/types";
    import type { createAgent } from "_102021_/l2/agentDefsL1/agentDefsL1";
    import { type D1InputArtifacts, type D1RequestGapAnswer } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ResolveGap } from "_102021_/l2/agentDefsL1/steps/resolve25/contracts";
    /**
     * Test only (d1_62), like `d1TestHost.ts`: it reads the resolve25 prompt from disk. The resolver that stands in for the model: it answers each resolve25 gap from the contract
     * `meta`, which no product source reads. A route without `meta` gets `none`.
     */
    export type D1TestResolver = (route: D2ContractV2Route, gap: Pick<D1ResolveGap, 'path' | 'kind'>) => string;
    export const metaResolver: D1TestResolver;
    /**
     * The answers resolve25 would record with `resolver` in place of the model, per route, as `buildD1InputSnapshot`
     * takes them. For the tests that build the inventory without running the hooks.
     */
    export function resolverAnswers(artifacts: Pick<D1InputArtifacts, 'contractTexts' | 'entities'>, resolver?: D1TestResolver): Map<string, D1RequestGapAnswer[]>;
    type D1Agent = ReturnType<typeof createAgent>;
    /**
     * Runs resolve25 on the hooks: the main step, each route worker answered by `resolver` through the tool, and the
     * barrier. Returns every intent, main first. With no gap there is no worker and no barrier.
     */
    export function runResolve25(agent: D1Agent, agentMeta: IAgentMeta, ctx: mls.msg.ExecutionContext, parent: mls.msg.AIAgentStep, project: number, moduleName: string, order: number, command?: 'run' | 'resume', resolver?: D1TestResolver): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Core" {
    export const M12_AGENT_NAME: "agentMaterializeL1";
    /**
     * Build of this agent, printed in the plan and in every phase trace: the Studio loads an agent by file name from
     * its own stor and compiled cache, so the trace is how a run shows which code it is running.
     */
    export const M12_BUILD: "m12-2026-10-21.48 (an import the Studio could not fetch (a project it has not loaded, no GitHub session) leaves the unit unproven, not failed; the Studio compile is back on: the imports are loaded first and the worker is warmed once with a long deadline before any compile, and a timeout turns the breaker on for the run instead of a 60s wait per file; an import the compiler did not load in time leaves the unit unproven, not failed; a request service waits for the workflow of the processes its routes reach; a readonly output member is set when the object is built; the input validator applies a required path to each item of a list, and a test runs it; a request never types a repository of its own; a child a route writes with its parent, matched by its fields to a 1:N relationship of the l4, gets its port methods and a request section; the workflow transition gate reads each call by its brackets, so a record built inside the call is judged too; a collection of objects is a list in the entity and the usecase signature and is stored whole at its path; a workflow transition must write the state it leads to on the record; a port and its adapter carry the methods a process applies through them and no usecase brings (an operation with no usecase, a system transition); the workflow prompt carries every entity its prose names; the workflow service (\u00A711): a workflows45 phase writes one function per process function from the l4 prose, over a mechanical Task adapter, and a module tick for the scheduled ones; a request whose usecase is a process operation calls the process; own scope read per entity, a direct step is a column and a longer chain a join; a caller needs one grant of the route, own applies only to the grants held and is set before the validation; a contract route the controller def leaves out gets its handler from the contract access; the usecase def carries only its intent (\u00A710): its function, port, selector, transition payload, rules and unique keys follow from the operation, the entity, the table and the l4; an MDM entity no usecase owns is read and written by the request through ctx.mdm, the own-scope anchor being the session actor; MDM links go with their compact keys; no inline or unknown repository; entities are type aliases, so they fit Record-based usecase outputs; tests60 back on, with the code model; a usecase reads only the input it declares, a sequence number is calculated; a transition writes the state it leads to; null from the MDM is absent, never an error; a request takes its contract input type and the controller passes it uncast; the request def goes compact, under the prompt limit; list filters are optional in the scaffold; platform MDM rules belong to the engine; an absent optional output field is left out; compile errors carry line, column and code; l4 collections are lists and MDM entities follow l4 optionality; no input casts in requests; an MDM usecase gets the flat engine shape and the ctx.mdm types; node: means an import, not a local named node; a text or day search is not an exact filter; a rule about a parent record obliges reading it; a rule handed to a usecase in a comment must be in that usecase; a list applies every filter its input declares; the usecase prompt says what each context section decides; a usecase never reads a derived field from a record the repository returned; a stored record comes back with every declared object, even empty; a write keeps the version it read: the repository increments it; usecase context sends the entities its rules name, by title and relationship; repository types only from ports; controller input opens named contract interfaces; requests typed by the contract outputs; no as-unknown/as-any; usecases (input, ctx) only; whole-module registration; controllers after request services; l1 proven by worker diagnostics only, breaker on a silent worker; briefing \u00A72.1: def fields are hints; recipes first; usecases and request services always to the model; prompts declare modelType)";
    export const M12_DOMAIN_AGENT_NAME: "agentM12Domain";
    export const M12_PERSISTENCE_AGENT_NAME: "agentM12Persistence";
    export const M12_SEED_ROWS_AGENT_NAME: "agentM12SeedRows";
    export const M12_SEED_ROW_UNIT_AGENT_NAME: "agentM12SeedRowUnit";
    export const M12_USECASES_AGENT_NAME: "agentM12Usecases";
    export const M12_USECASE_UNIT_AGENT_NAME: "agentM12UsecaseUnit";
    export const M12_WORKFLOWS_AGENT_NAME: "agentM12Workflows";
    export const M12_WORKFLOW_UNIT_AGENT_NAME: "agentM12WorkflowUnit";
    export const M12_REQUESTS_AGENT_NAME: "agentM12Requests";
    export const M12_REQUEST_SERVICE_AGENT_NAME: "agentM12RequestService";
    export const M12_CONTROLLERS_AGENT_NAME: "agentM12Controllers";
    export const M12_TESTS_AGENT_NAME: "agentM12Tests";
    export const M12_TESTS_PAGE_AGENT_NAME: "agentM12TestsPage";
    export const M12_REGISTER_AGENT_NAME: "agentM12Register";
    export const M12_CATALOG_AGENT_NAME: "agentM12Catalog";
    export const M12_FINALIZE_AGENT_NAME: "agentM12Finalize";
    /** The layers a def belongs to, in the order they are materialized. `tests` has no def of its own. */
    /**
     * Dependency order. A controller imports its request service, so with the Studio compiler proving l1 it can only
     * compile after the service exists (05/10/2026: written first, every controller failed "imports unavailable").
     * The folder and step names keep their numbers (controllers30 runs after requests50): renaming them again would
     * leave a stale copy with the same agent name in the Studio stor, which loads the last file it finds.
     */
    export const M12_LAYERS: readonly ["domain", "persistence", "seedRows", "usecases", "workflows", "requests", "controllers", "tests"];
    export type M12Layer = typeof M12_LAYERS[number];
    export const M12_STEP_IDS: readonly ["domain10", "persistence20", "seedRows25", "usecases40", "workflows45", "requests50", "controllers30", "tests60", "register70", "catalog75", "finalize80"];
    export type M12StepId = typeof M12_STEP_IDS[number];
    /** Which layer materializes a def, by its artifactType. Unknown types are not planned (the report names them). */
    export const LAYER_OF_TYPE: Readonly<Record<string, M12Layer>>;
    /** Repair rounds per LLM unit after the first attempt. */
    export const M12_REPAIR_BUDGET = 2;
    /** System + human prompt ceiling per LLM call, in characters. */
    export const M12_PROMPT_LIMIT = 160000;
    /** What the user asked for. */
    export interface M12Request {
        /** Folder prefix under l1, by whole segments; '' = every module of the project. */
        scope: string;
        /** Full path of one `.defs.ts` (or of the `.ts` generated from it); exclusive with scope. */
        target: string;
        /** Regenerate reusable units and overwrite outputs this agent did not write. A target implies it. */
        force: boolean;
    }
    /** The args of every phase step: one module, the request that selects its units. */
    export interface M12RunArgs extends M12Request {
        project: number;
        module: string;
    }
    export type M12MessageInvocation = {
        kind: 'help';
    } | ({
        kind: 'run';
        project: number;
    } & M12Request) | {
        kind: 'refusal';
        diagnostic: string;
    };
    export type M12StepInvocation = ({
        kind: 'run';
    } & M12RunArgs) | {
        kind: 'refusal';
        diagnostic: string;
    };
    export const M12_HELP: string;
    /** A module name: lowerCamel, no path, no separator. */
    export function tokenOk(value: string): boolean;
    /** A page id or unit id: lowerCamel or snake, no dot, no slash. */
    export function unitIdOk(value: string): boolean;
    /** `{"scope":"..."}` / `{"target":"..."}` after the @@ prefix; no JSON means every module. */
    export function parseM12MessageInvocation(value: string, project: number): M12MessageInvocation;
    export function parseM12StepInvocation(value: string, currentProject: number): M12StepInvocation;
    export function runArgsJson(args: M12RunArgs): string;
    export function phasePlanId(stepId: M12StepId, moduleName: string): string;
    export function isM12PhasePlanId(value: string): boolean;
    /**
     * Sequential phase steps: for each module, the selected layers, then the l5 registration when the whole
     * module is in scope, then its report. Every step waits for the previous one; a phase that hosts LLM
     * workers stays open until they finish, so `dependsOn` really waits for the generated files.
     */
    export function buildM12PlannedSteps(project: number, request: M12Request, modules: ReadonlyArray<{
        module: string;
        layers: readonly M12Layer[];
        register: boolean;
    }>): mls.msg.AIAgentStep[];
    export function errorText(error: unknown): string;
    /** Trace strings live in the task record: keep them bounded. */
    export function clip(text: string, max?: number): string;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Intents" {
    export function addM12Step(context: mls.msg.ExecutionContext, parentStepId: number, step: mls.msg.AIPayload, bootstrap?: boolean): mls.msg.AgentIntentAddStep;
    /**
     * `clean`: LLM workers only. `true` = 'input_output' (drops input, payload and trace; on success the artifact
     * is on disk). 'input' drops only the prompt, keeping the trace that says why a unit failed.
     */
    export function updateM12Status(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string, clean?: boolean | 'input'): mls.msg.AgentIntentUpdateStatus;
    export function m12Result(title: string, result: string, planId: string): mls.msg.AIResultStep;
    /**
     * One LLM worker, run in parallel with its siblings under the phase step that hosts it.
     * `wait_after_prompt`: a provider failure in one worker reaches afterPromptStep with no payload and is
     * handled as a failed attempt, instead of failing the whole task.
     */
    export function m12WorkerStep(agentName: string, title: string, planId: string, args: unknown): mls.msg.AIAgentStep;
    export function m12PromptReady(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, prompt: {
        system: string;
        human: string;
        toolName: string;
        toolDescription: string;
        parameters: Record<string, unknown>;
    }): mls.msg.AgentIntentPromptReady;
    /** The tool arguments of the LLM answer, whatever envelope the provider used. */
    export function m12ToolPayload(step: mls.msg.AIAgentStep, toolName: string): unknown;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Names" {
    import type { M12Layer } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    export interface M12FileInfo {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function fileRef(info: M12FileInfo): string;
    /**
     * The file of a ref. Accepts `_N_/lK/...`, the import form `/_N_/lK/....js` (read as its `.ts`) and a
     * local `lK/...` (the current project). Null for anything else, `..` included.
     */
    export function infoOfRef(ref: string, project: number): M12FileInfo | null;
    /** The `.ts` a def materializes into: same folder, same name. */
    export function outputOfDef(def: M12FileInfo): M12FileInfo;
    /** The def of a `.defs.ts` or of the `.ts` generated from it. */
    export function defOfRef(ref: string, project: number): M12FileInfo | null;
    /** Folder of this agent's run files inside the module. */
    export function runFolder(moduleName: string): string;
    /** One status file per unit and layer: one owner per file (the step or worker of that unit). */
    export function unitStatusFile(project: number, moduleName: string, layer: M12Layer, unitId: string): M12FileInfo;
    /** Raw model answers and the bytes a unit had before its first attempt. */
    export function unitDraftFile(project: number, moduleName: string, layer: M12Layer, unitId: string, part: string): M12FileInfo;
    export function reportFile(project: number, moduleName: string): M12FileInfo;
    /** The assistant catalog of one module. catalog75 writes only this file. */
    export function assistantCatalogFile(project: number, moduleName: string): M12FileInfo;
    /** How the last l5 registration of the module ended (register70 writes, finalize80 reads). */
    export function registrationFile(project: number, moduleName: string): M12FileInfo;
    export function projectJsonFile(project: number): M12FileInfo;
    export function rulesFile(project: number, moduleName: string): M12FileInfo;
    export function contractFile(project: number, moduleName: string, pageId: string): M12FileInfo;
    /** The monitor test file of one page: next to its controller, `pageTests` export (skills/monitorTests.md). */
    export function pageTestsFile(project: number, moduleName: string, pageId: string): M12FileInfo;
    /** Wake handler of one `llm` step or one periodic `wait` step. The process file exports this name. */
    export function workflowWakeHandlerName(stepId: string): string;
    /**
     * Fixed export of one wake handler: `ctx` first, then the event. It must stay assignable to `WorkflowWakeHandler`
     * (`/_102034_/l1/workflow/index.js`), which the registration passes it to. An `export async function`, as the gate asks.
     */
    export function workflowWakeHandlerForm(stepId: string): string;
    /** Tick recovery of one process that has an `llm` step. The process file exports this name. */
    export function workflowRecoverName(processId: string): string;
    /** Fixed export of the tick recovery. The clock is `ctx.clock`; there is no `now` argument. */
    export function workflowRecoverForm(processId: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Io" {
    import type { M12Layer } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    export const M12_UNIT_STATUS_VERSION: "2026-10-05-m12-unit-v1";
    /**
     * - done: written and every check passed (the briefing's `generated`); code COMPILE_UNAVAILABLE_L1 = no compiler proved it.
     * - reused: same inputs, untouched output from an earlier done.
     * - blocked: a named gap or a dependency that is not ready; a file may be on disk (see diagnostic).
     * - gap: a declared platform gap (no runtime mechanism); nothing is written and the app still boots.
     * - failed: the unit could not be produced or did not compile.
     * - skipped: an output this agent did not write is protected (use "force": true).
     */
    export type M12UnitState = 'done' | 'reused' | 'blocked' | 'gap' | 'failed' | 'skipped';
    export interface M12UnitStatus {
        schemaVersion: typeof M12_UNIT_STATUS_VERSION;
        layer: M12Layer;
        unitId: string;
        /** The def the unit materializes; '' for a test unit (keyed by page). */
        defRef: string;
        status: M12UnitState;
        /** Machine code of the outcome, e.g. COMPILE_FAILED, RULE_NOT_EMITTED, NEEDS_LLM. '' on done/reused. */
        code: string;
        attempt: number;
        diagnostic: string;
        /** Hash of every input the unit was generated from; equal hash + equal output bytes = reusable. */
        inputHash: string;
        /** fileRef -> sha256 of the bytes this agent wrote. A mismatch on disk means a local edit. */
        outputs: Record<string, string>;
        updatedAt: string;
    }
    /** Units whose state lets a dependent unit go on. */
    export function stateReady(status: M12UnitStatus | null): boolean;
    /**
     * An l1 file generated and checked by every gate except the Studio compiler, which cannot compile l1 from an
     * agent: the unit is `done` with this code, and the report lists it apart as not proven by a compiler.
     */
    export const COMPILE_UNAVAILABLE_L1: "COMPILE_UNAVAILABLE_L1";
    /** A generated unit no compiler proved (COMPILE_UNAVAILABLE_L1). */
    export function unproven(status: M12UnitStatus | null): boolean;
    export function storExists(info: M12FileInfo): boolean;
    /**
     * The file text, or null when the file is absent or unreadable. Never throws.
     * `getContent()` first: after `localStor.setContent` on an existing file, `getValueInfo()` keeps returning the
     * previous bytes while `getContent()` returns the new ones (measured by agenteMaterializeL22, 01/10/2026).
     */
    export function readOptional(info: M12FileInfo): Promise<string | null>;
    export function readJsonOptional<T>(info: M12FileInfo): Promise<T | null>;
    /**
     * The reader the emitters get: any ref form `infoOfRef` accepts. Another project's file loads that project's
     * stor index once; a failure is warned with its cause and read as absent (the emitter then names what is missing).
     */
    export function createReader(project: number): (ref: string) => Promise<string | null>;
    export function sha256Text(text: string): Promise<string>;
    export function hashParts(parts: readonly string[]): Promise<string>;
    /**
     * Persists like `agentDefsL1` `writeText`: a missing or `deleted` file is created with
     * `createStorFile(..., false, false, false)` (no editor model — an l1 model sent to the Studio
     * TypeScript worker never settles, 05/10/2026). Any other file is `localStor.setContent`.
     * The session map keeps the bytes a later phase reads. Returns the hash of those bytes.
     */
    export function writeText(info: M12FileInfo, text: string): Promise<string>;
    /** Writes a generated source and returns the exact bytes it holds (what a compiler would see). */
    export function writeSource(info: M12FileInfo, text: string): Promise<{
        hash: string;
        text: string;
    }>;
    /**
     * Drops a file this agent created in this session (a broken output, the l5 lock): content cleared, out of the
     * index. Membership is the session set `writeText` filled, not `status === 'new'` — the host marks a fresh
     * write `changed`. A file that already existed is never removed here: its previous bytes are written back instead.
     */
    export function removeStorFile(info: M12FileInfo): Promise<void>;
    export function writeJson(info: M12FileInfo, value: unknown): Promise<void>;
    export function readUnitStatus(project: number, moduleName: string, layer: M12Layer, unitId: string): Promise<M12UnitStatus | null>;
    export function writeUnitStatus(project: number, moduleName: string, status: Omit<M12UnitStatus, 'schemaVersion' | 'updatedAt'>): Promise<M12UnitStatus>;
    export type M12ReuseDecision = {
        kind: 'reuse';
    } | {
        kind: 'generate';
    };
    /**
     * Skip when every output file is in the stor and not `deleted`. Generate when `force` is set or any output is
     * missing. A receipt, its hash and its date do not decide. The check is the file identity, so `x.ts` and
     * `x.defs.ts` are different files.
     */
    export function reuseDecision(outputs: readonly M12FileInfo[], force: boolean): Promise<M12ReuseDecision>;
    export function writeDraft(project: number, moduleName: string, layer: M12Layer, unitId: string, part: string, text: string): Promise<void>;
    export function readDraft(project: number, moduleName: string, layer: M12Layer, unitId: string, part: string): Promise<string | null>;
    /** appEnv of l5/project.json, the field the server reads. Absent = presentation (not production). */
    export function readAppEnv(project: number): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/usecaseIntent" {
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    type Read = (ref: string) => Promise<string | null>;
    /** The `export const definition = { … } as const;` of a def source, unvalidated; null when it is not one. */
    export function parseDefinitionExport(source: string): M1Definition | null;
    /** The transition `transitionId` of an l4 ontology: its payload paths; null when the ontology has no such transition. */
    export function transitionPayload(ontologySource: string | null, transitionId: string): string[] | null;
    /**
     * The def as the recipes read it: the declared intent plus what the operation, the entity and the l4 fix. A def that
     * still names its function (the format before 15/10) is returned as it is. `detail` names what could not be derived;
     * the def then comes back without a function and the unit is refused with that cause.
     */
    export function usecasePlan(definition: M1Definition, read: Read): Promise<{
        definition: M1Definition;
        detail: string;
    }>;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/registry" {
    /**
     * Closed handler registry. This file is the only integrator: m1_03, m1_06 and m1_07
     * deliver a MaterializeHandler; wiring it stays here. A type with no named entry is
     * blocked by the planner. Nothing in this module writes a file.
     */
    import { type M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_HANDLER_STAGES: readonly ["structure", "implement"];
    export type M1HandlerStage = typeof M1_HANDLER_STAGES[number];
    /** Platform capabilities a handler may ask the context resolver to load. MDM catalog is not one of them. */
    export const M1_CONTEXT_CAPABILITIES: readonly ["requestContext", "dataRuntime", "tableDefinition", "repositoryRegistry", "mdmFacade"];
    export type M1ContextCapability = typeof M1_CONTEXT_CAPABILITIES[number];
    export interface MaterializeHandler {
        readonly id: string;
        readonly artifactType: M1ArtifactType;
        readonly stage: M1HandlerStage;
        /** False means the recipe is local. Simulate never calls a model for this handler. */
        readonly needsLlm: boolean;
        readonly capabilities: readonly M1ContextCapability[];
    }
    /** Implement recipes. Null is a written absence: no fallback onto the structure scaffolder. */
    export const M1_IMPLEMENT_HANDLERS: Record<M1ArtifactType, MaterializeHandler | null>;
    export const M1_STRUCTURE_HANDLERS: Readonly<Record<M1ArtifactType, MaterializeHandler>>;
    export function handlerFor(type: string, stage?: M1HandlerStage): MaterializeHandler | null;
    export function registeredHandlerIds(stage?: M1HandlerStage): string[];
}
declare module "_102021_/l2/agentMaterializeL1/emitters/catalog" {
    /**
     * Scenario catalog for one module. The monitor imports the rendered module
     * (export `scenarioCatalog` only). The sibling test file of each unit carries
     * the same scenario as data (`renderScenarioTest`); nothing here runs a case.
     */
    import type { M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    import type { M1HandlerStage } from "_102021_/l2/agentMaterializeL1/emitters/registry";
    export const M1_CATALOG_SCHEMA: "2026-09-25-m1-scenario-catalog-v1";
    /** Additive: each case names its runner, and a route case names its caller. */
    export const M1_CATALOG_SCHEMA_V11: "2026-09-26-m1-scenario-catalog-v1.1";
    /** Additive: a route case may name `<seedRef>` params and the entity field each one addresses. */
    export const M1_CATALOG_SCHEMA_V12: "2026-10-02-m1-scenario-catalog-v1.2";
    export const M1_CATALOG_SCHEMAS: readonly ["2026-09-25-m1-scenario-catalog-v1", "2026-09-26-m1-scenario-catalog-v1.1", "2026-10-02-m1-scenario-catalog-v1.2"];
    /** Literal the monitor resolves from a seeded row. Never an invented id. */
    export const M1_SEED_REF: "<seedRef>";
    export type M1CatalogSchema = typeof M1_CATALOG_SCHEMAS[number];
    /** Positive case of an operation that addresses one stored record. */
    export const M1_EXISTING_RECORD = "existing record";
    export const M1_CATALOG_EXPORT: "scenarioCatalog";
    /** Config key x1_02 will read. It is not `frontend.pageTests`. */
    export const M1_CATALOG_CONFIG_KEY: "backend.scenarioCatalog";
    /** Provisional stub from the structure handler. Business expectations do not use this code. */
    export const M1_STUB_ERROR: "USECASE_NOT_IMPLEMENTED";
    export const M1_STUB_STATUS = 501;
    export const M1_GATES: readonly ["compile", "contract", "auth", "business"];
    export type M1Gate = typeof M1_GATES[number];
    export interface M1SyntheticRow {
        entity: string;
        id: string;
        professionalId: string;
        patientId: string;
        scheduledAt: string;
        status: string;
        version: number;
        attendanceNote: string;
    }
    export interface M1ExpectedFailure {
        caseId: string;
        stage: 'structure';
        errorCode: typeof M1_STUB_ERROR;
        status: typeof M1_STUB_STATUS;
    }
    /** Definitive assertion. A repair is not allowed to change it. */
    export interface M1CaseExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        forbiddenFields: string[];
        /** When set, every returned row must carry this actor id. Shape alone does not pass. */
        isolatedActorField: string | null;
    }
    export type M1CaseRunner = 'route' | 'module';
    /** Present only on a route case. Authorities come from the grant, not from the case id. */
    export interface M1CaseCaller {
        source: 'http';
        authorities: string[];
    }
    export interface M1ScenarioCase {
        caseId: string;
        gate: M1Gate;
        mandatory: true;
        source: string;
        expectation: string;
        preconditions: string[];
        synthetic: M1SyntheticRow[];
        actorId: string;
        routine: string;
        mutating: boolean;
        expect: M1CaseExpect;
        expectedFailure: M1ExpectedFailure | null;
        /** Absent on a v1 catalog. */
        runner?: M1CaseRunner;
        /** Absent on a module case and on a v1 catalog. */
        caller?: M1CaseCaller;
        /** Absent before v1.2. Values may be the literal `<seedRef>`. */
        params?: Record<string, string>;
        /** `<Entity>.<field>` for each `<seedRef>` param. Absent before v1.2. */
        paramFieldRefs?: Record<string, string>;
    }
    export interface M1Scenario {
        scenarioId: string;
        source: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        handlerId: string;
        productionFile: string;
        testFile: string;
        cases: M1ScenarioCase[];
    }
    export interface M1ScenarioCatalog {
        schemaVersion: M1CatalogSchema;
        moduleName: string;
        store: 'memory';
        scenarios: M1Scenario[];
    }
    export interface M1CatalogParse {
        catalog: M1ScenarioCatalog | null;
        issues: string[];
    }
    export interface M1RepairProposal {
        caseId: string;
        ok?: boolean;
        status?: number;
        errorCode?: string | null;
        ruleId?: string | null;
        dropForbiddenFields?: readonly string[];
        clearActorFilter?: boolean;
        dropExpectedFailure?: boolean;
        replaceExpectedFailure?: {
            errorCode: string;
            status: number;
        };
    }
    export function canonicalJson(value: unknown): string;
    export function extractCatalogJson(source: string): string | null;
    export function parseCatalog(source: string): M1CatalogParse;
    /** Implement removes the provisional mark. This is not a repair. */
    export function catalogForStage(catalog: M1ScenarioCatalog, stage: M1HandlerStage): M1ScenarioCatalog;
    /**
     * Drops a rule or a filter from a copy of the case. Used only to prove the
     * original assertion fails when that rule is absent. Repair refuses the same edit.
     */
    export function withoutRule(item: M1ScenarioCase, ruleId: string): M1ScenarioCase;
    export function repairRefusal(item: M1ScenarioCase, proposal: M1RepairProposal): string[];
    export function applyRepair(catalog: M1ScenarioCatalog, proposal: M1RepairProposal): {
        catalog: M1ScenarioCatalog;
        refused: string[];
    };
    export function renderMonitorCatalog(catalog: M1ScenarioCatalog, fileReference: string): string;
    /** Qualified file or import (`_NNNNN_/…` or `/_NNNNN_/…`) as `/_NNNNN_/….js`. Anything else is refused. */
    export function moduleSpecifier(file: string): string;
    /** Export of the per-unit `.test.ts`: that unit's scenario, as data. */
    export const M1_TEST_EXPORT: "scenarioCases";
    /**
     * The per-unit `.test.ts` is data: the scenario the monitor runs from the module catalog
     * (`backend.scenarioCatalog`). No import, no runner, nothing executes when it loads, so it
     * compiles in the Studio like any other module (conduta 28/09, rule 4).
     */
    export function renderScenarioTest(scenario: M1Scenario): string;
    /** A test this agent rendered before m1_35: a node runner bound to the catalog. It is rewritten, never kept. */
    export function isLegacyNodeTest(text: string, testFile: string): boolean;
    export function testFileFor(productionFile: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/domainOptional" {
    /**
     * m1_41 b1-P1: which fields a stored record may lack. The domain emitter types them with `?`, and a v2
     * usecase reads its optional input and output fields from the same place: the l4 entity `required`
     * and the fields the server assigns. Moved here from `behavior/emitBehavior.ts` so that structure and
     * behavior share one criterion.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    /**
     * Entity field paths the domain types with `?`: on a module-database or MDM entity, the fields the l4 entity
     * does not require and the server does not assign. Empty for other storage targets or with no l4
     * entity; null when the l4 entity has no readable record fields.
     */
    export function domainOptionalPaths(entity: M1Definition, ontologySource: string | null): Set<string> | null;
    /**
     * The entity path of a usecase signature row: its `fieldRef` without the `<Entity>.` prefix.
     * A row of another entity, or one with no field ref (a page param), is not an entity path: ''.
     */
    export function signatureFieldPath(row: Record<string, unknown>, entityId: string): string;
    /** Names of the signature rows the domain types with `?`. */
    export function optionalSignatureNames(rows: readonly unknown[], entityId: string, optional: ReadonlySet<string>): Set<string>;
    /** Server-assigned values of a new record: the identity, the version and the initial lifecycle state. */
    export function serverAssigned(entity: M1Definition, lifecycle: {
        field: string;
        initial: string;
    }): Map<string, string>;
    /** Field paths the canonical l4 entity marks `required`, walking nested `fields`; null when unreadable. */
    export function ontologyRequired(source: string): Set<string> | null;
    export function identityField(entity: M1Definition): string;
    export function enumField(entity: M1Definition): string;
    export function versionField(entity: M1Definition, identity: string): string;
    export function topFields(entity: M1Definition): Array<{
        name: string;
        type: string;
        derived: boolean;
    }>;
    /**
     * The lifecycle field is the single top-level enum of an entity that declares transitions.
     * Its initial state is the one declared state no transition reaches; otherwise it is ''.
     */
    export function lifecycleStart(definition: M1Definition): {
        field: string;
        initial: string;
    };
}
declare module "_102021_/l2/agentMaterializeL1/emitters/gate" {
    export const FORBIDDEN_ACTOR = "FORBIDDEN_ACTOR";
    export const VALIDATION_ERROR = "VALIDATION_ERROR";
    export const GRANT_ABSENT = "GRANT_ABSENT";
    export const SESSION_UNVERIFIED = "SESSION_UNVERIFIED";
    export const SCOPE_UNBOUND = "SCOPE_UNBOUND";
    export const REPOSITORY_NOT_IMPLEMENTED = "REPOSITORY_NOT_IMPLEMENTED";
    /** A controller with grants and no readable authority map is not emitted. */
    export const AUTHORITY_UNREAD = "AUTHORITY_UNREAD";
    /** A grant the authority map does not name has no actor: the route is refused. */
    export const AUTHORITY_UNMAPPED = "AUTHORITY_UNMAPPED";
    /** A def of the removed v1 shape (m1_41 a): refused, never read through a default. */
    export const DEF_V1_UNSUPPORTED = "DEF_V1_UNSUPPORTED";
    /**
     * Whether a def still carries the v1 shape: an httpController handler with `usecaseId` and no
     * `serviceFunction`, or a usecase function with `contractRefs`. A usecase's own `data.usecaseId` is
     * v2 and is not a marker. `routeProjections` is refused earlier, by the l1Defs schema (m1_41 c1).
     */
    export function isDefV1(data: Record<string, unknown>): boolean;
    export function defV1Detail(artifactId: string): string;
    export interface StructureGrant {
        grantId: string;
        actorRef: string;
        scopeMode: string;
        session: string;
        pending: string;
        disclosure: string;
        /** Record field taken from the grant path. Empty when that path does not resolve. */
        recordField?: string;
        /** Per entity of an own grant, the column that holds the anchor id (one direct step). */
        recordFields?: Readonly<Record<string, string>>;
        entityRefs?: readonly string[];
        selfAnchored?: boolean;
    }
    export interface GateInput {
        source: 'http' | 'message' | 'test';
        authorities: readonly string[];
        grantIds: readonly string[];
        grants: readonly StructureGrant[];
        /** Authority map entries. The actor of a grant comes from here, not from the scope. */
        authority: readonly {
            grantId: string;
            actorRef: string;
        }[];
        params: unknown;
        requiredFields: readonly string[];
    }
    export interface GateDecision {
        ok: boolean;
        status: number;
        errorCode: string | null;
        reachedUsecase: boolean;
    }
    export function resolveGrant(grants: readonly StructureGrant[], grantId: string): StructureGrant | {
        code: string;
        detail: string;
    };
    export function missingField(params: unknown, fields: readonly string[]): string;
    /** Same order the emitted controller uses. A stub result means both gates passed. */
    export function decideRoute(input: GateInput): GateDecision;
    export function stubDecision(): GateDecision;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/emit" {
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type DisclosureNode } from "_102021_/l2/helpers/l1Defs/disclosure";
    import { type RequestOutputNode } from "_102021_/l2/helpers/l1Defs/requestTree";
    import { type StructureGrant } from "_102021_/l2/agentMaterializeL1/emitters/gate";
    /** Raised when the structure handler body changes. An older receipt is a new input. */
    export const STRUCTURE_HANDLER_RECIPE = "2026-10-02-structure-handler-v13";
    export interface EmitFailure {
        code: string;
        detail: string;
    }
    export interface EmitResult {
        source: string;
        runsStub: boolean;
        imports: string[];
    }
    export type StructureRead = (ref: string) => Promise<string | null>;
    /**
     * `optional` names the field paths a stored record may lack; without it every field is required.
     * `enums` maps a field path to the values its source declares; an `enum` field without values stays `string`.
     * The lifecycle states type the entity's single top-level `enum` field.
     */
    export function emitDomain(definition: M1Definition, output: string, optional?: ReadonlySet<string>, enums?: ReadonlyMap<string, readonly string[]>, collections?: ReadonlySet<string>): EmitResult;
    export function emitValueObject(definition: M1Definition, output: string): EmitResult;
    export function emitPort(definition: M1Definition, output: string): EmitResult | EmitFailure;
    export function emitAccess(definition: M1Definition, output: string): EmitResult;
    export function emitAuthority(definition: M1Definition, output: string): EmitResult;
    export function emitUsecase(definition: M1Definition, output: string, read: StructureRead): Promise<EmitResult | EmitFailure>;
    export function emitController(definition: M1Definition, output: string, read: StructureRead): Promise<EmitResult | EmitFailure>;
    interface ClosedUnion {
        path: string;
        values: string[];
    }
    /** Grant and required fields of one v2 route. The adapter names a service function, not a usecase. */
    export function adapterRouteFacts(definition: M1Definition, handler: Record<string, unknown>, read: StructureRead): Promise<{
        grantIds: string[];
        requiredFields: string[];
    } | EmitFailure>;
    export function membersOfType(source: string, typeText: string): {
        requiredFields: string[];
        allowedPaths: string[];
        nullablePaths: string[];
        unions: ClosedUnion[];
    } | null;
    export function routeClause(source: string, route: string): string | null;
    export function clauseValue(clause: string, name: 'input' | 'output'): string | null;
    /** Project-qualified ref of an L1/L2 file a def names relatively; the `_<proj>_/` prefix comes from its dependencies. */
    export function qualifyFile(path: string, dependencies: readonly string[]): string;
    /**
     * Grants of each route a v2 page controller of the module exposes: the handler's `grantIds` read on
     * the module access scope. An undeclared grant id stays `{}` and discloses nothing.
     * A route no controller names is not exposed and has no entry.
     */
    export function exposedRouteGrants(moduleDefinitions: readonly unknown[]): Map<string, Record<string, unknown>[]> | EmitFailure;
    export function validateSource(): string;
    export interface ServiceOutput {
        key: string;
        entity: string;
        fields: string[];
        /** The classified paths of the request tree (d1_61). Absent in a def with the flat `outputs`. */
        disclosure?: DisclosureNode[];
        page: string;
        pageSize: string;
        hasMore: string;
    }
    /**
     * One function per request, keyed by the route. A command resolves repositories on the
     * transaction runtime: the adapter binds `ctx.data.moduleData` when the factory runs.
     * `outputs[].page`, `pageSize` and `hasMore` are the contract pagination keys when the def has them.
     */
    export function emitRequestService(definition: M1Definition, output: string, read: StructureRead, moduleDefinitions: readonly unknown[], stage: 'structure' | 'implement'): Promise<EmitResult | EmitFailure>;
    /**
     * The outputs of one request row, the one M1 reader (emit and obligations). A def with the classified tree (`output`,
     * d1_61) is projected only when every node is one this emitter projects as it is: an `entity` or a flat `list` (no
     * `total`, no page wrapper) at a root member, whose fields are their own ontology paths. Every other node is a named
     * refusal, one line per path in `unsupported`: `REQUEST_SHAPE_UNSUPPORTED: <route> <path> <type>`. The outputs still
     * carry every classified node, so the disclosure check reads the entity, related and computed paths first. The flat
     * paging keys of a list are not projected, as with the flat `outputs`. A def written before the tree (`outputs`) is
     * read by name, as before.
     */
    export function readServiceOutputs(route: string, row: Record<string, unknown>): {
        outputs: ServiceOutput[];
        unsupported: string[];
    } | EmitFailure;
    /** The nodes of a tree this emitter does not project, with the type the refusal names. */
    export function unsupportedShapes(tree: readonly RequestOutputNode[]): Array<{
        path: string;
        type: string;
    }>;
    /** Value bindings the structure emitters write. Types are not included. */
    export function emittedValueExports(definition: M1Definition): readonly string[];
    export function importSpecifier(defPath: string, kind: 'output' | 'defs'): string;
    export function auditImports(source: string, allowed: readonly string[]): string;
    export function grantsOf(data: Record<string, unknown>): StructureGrant[];
    /**
     * Own scope read per entity (the team's notice of 16/10): each entry of the grant `path` is one entity of the grant and
     * its chain to the anchor. One direct step (`Inscricao.participanteId` → Participante) is a column filter: the entity's
     * record field. A longer chain with an inverse step (Evento ← Inscricao.eventoId, Inscricao.participanteId → Participante)
     * is a join the request service applies. The anchor's own entry and a pending entry name no field.
     */
    export function recordFieldsFromGrant(grant: Record<string, unknown>): Record<string, string>;
    /** The record field of `entityId` in an own grant: its direct step to the anchor; '' when it has none. */
    export function recordFieldFor(grant: Record<string, unknown>, entityId: string): string;
    /** The one record field every directly anchored entity of an own grant shares; '' when there is none or they differ. */
    export function recordFieldFromGrant(grant: Record<string, unknown>): string;
    /** The entities of an own grant reached through more than one step, with their chain: the join the request applies. */
    export function scopeJoins(grant: Record<string, unknown>): Array<{
        entityId: string;
        steps: string[];
    }>;
    export function contractMembers(source: string, name: string): {
        requiredFields: string[];
        allowedFields: string[];
        allowedPaths: string[];
    } | null;
    /** Member paths of `name` whose declared type admits `null`. */
    export function contractNullablePaths(source: string, name: string): string[] | null;
    /** `T`, `T[]`, `T | null` or `null | T` of a declared member type: T when it names an interface; '' otherwise. */
    export function namedMemberType(declared: string): string;
    /**
     * Members whose declared type names an interface of the contract and that were not opened: a validator built
     * without them refuses what the contract describes. Empty = every named member was opened.
     */
    export function unopenedNamedMembers(source: string, typeText: string, allowedPaths: readonly string[]): string[];
    /** The l4 entity a domain def types against: its ontology dependency, else the module's ontology file. */
    export function ontologyRef(definition: M1Definition, output: string): string;
    /** Field paths the l4 entity marks `collection: true` (a list), walking nested `fields`; empty when unreadable. */
    export function ontologyCollections(source: string | null): Set<string>;
    /** Enum values the l4 entity declares per field path, walking nested `fields`; empty when unreadable. */
    export function ontologyEnums(source: string | null): Map<string, string[]>;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/processPorts" {
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    export interface M12PortMethod {
        name: string;
        params: string[];
        returns: string;
    }
    /** Entity → the methods its port needs for the processes of the module, beyond what its usecases bring. */
    export function processPortMethods(definitions: readonly M1Definition[]): Map<string, M12PortMethod[]>;
    /**
     * A repositoryPort def with the methods the processes of the module need, and the ones `extra` brings (the children a
     * route writes with its parent); the def itself when it needs none.
     */
    export function withProcessMethods(port: M1Definition, definitions: readonly M1Definition[], extra?: ReadonlyMap<string, readonly M12PortMethod[]>): M1Definition;
    /** A child entity a route writes with its parent: the route input carries its records, and no usecase writes them. */
    export interface M12ChildWrite {
        route: string;
        /** The entity and operation the route declares (`writes: 'Tarefa.create'`). */
        parent: string;
        operation: string;
        /** The input member that carries the child records (`checklist`) and the child entity (`ItemChecklist`). */
        inputKey: string;
        child: string;
        /** The child field that points to the parent (`tarefaId`). */
        foreignKey: string;
    }
    /**
     * The children a route writes with its parent. The contract says only `writes: '<Parent>.<op>'`; its input may carry a
     * member that is not a field of the parent and whose fields are those of an entity the parent reaches by a 1:N
     * relationship of its l4 ontology (minhas_tarefas: `checklist` → ItemChecklist via ItemChecklist.tarefaId). The child is
     * matched by its fields, not by a name: the relationship is `itensChecklist`, the input member `checklist`.
     */
    export function routeChildWrites(definitions: readonly M1Definition[], read: (ref: string) => Promise<string | null>, project: number, moduleName: string): Promise<M12ChildWrite[]>;
    /** The port methods the children written with their parent need: create; on any other write, update and delete too. */
    export function childWriteMethods(writes: readonly M12ChildWrite[]): Map<string, M12PortMethod[]>;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Units" {
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M12Layer, type M12Request } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    export interface M12StorEntry {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        status?: string;
    }
    export interface M12Unit {
        layer: M12Layer;
        unitId: string;
        def: M12FileInfo;
        defRef: string;
        output: M12FileInfo;
        outputRef: string;
        /** The def as the recipes read it: for a usecase, the declared intent plus what its operation and entity fix (§10). */
        definition: M1Definition;
        /** The def as it was declared: what the prompt shows. */
        declared: M1Definition;
        /** Why the plan of a usecase could not be derived ('' when it was, or the unit is not a usecase). */
        planIssue: string;
        /** The def text, part of the unit's input hash. */
        text: string;
    }
    export interface M12ModuleUnits {
        units: M12Unit[];
        /** Defs that could not be read or parsed, or whose type has no layer: named in the report, never dropped. */
        problems: Array<{
            defRef: string;
            code: string;
            detail: string;
        }>;
    }
    export function storEntries(): M12StorEntry[];
    /** The l1 `.defs.ts` entries of one module. The project filter matters: the stor carries the whole closure. */
    export function moduleDefEntries(project: number, moduleName: string, entries: readonly M12StorEntry[]): M12StorEntry[];
    /** Every l1 module of the project that has defs. */
    export function discoverModules(project: number, entries: readonly M12StorEntry[]): string[];
    /** Reads and parses every def of the module. Pure over the stor; writes nothing. */
    export function loadModuleUnits(project: number, moduleName: string, entries: readonly M12StorEntry[]): Promise<M12ModuleUnits>;
    /** The defs of a module the request selects (the others are dependencies only). */
    export function selectUnits(project: number, moduleName: string, units: readonly M12Unit[], request: M12Request): M12Unit[];
    /** The modules a request touches: the scope's module, the target's module, or every module. */
    export function requestModules(project: number, request: M12Request, entries: readonly M12StorEntry[]): {
        modules: string[];
        refusal: string;
    };
    /** The layers that have selected units, in order; tests ride on controllers. */
    export function selectedLayers(units: readonly M12Unit[]): M12Layer[];
    /** Registration covers the whole module: only a run that selected every unit of it registers. */
    export function registersModule(request: M12Request, moduleName: string): boolean;
    /** Parsed definitions of every unit of the module: the `moduleDefinitions` the copied emitters read. */
    export function moduleDefinitions(units: readonly M12Unit[]): unknown[];
    /**
     * Same-layer order: a unit after the units of its layer it depends on (an adapter after its table, a port
     * after its entity). A dependency outside the layer is not ordered here; it is checked by status.
     */
    export function orderWithinLayer(units: readonly M12Unit[]): M12Unit[];
}
declare module "_102021_/l2/agentMaterializeL1/emitters/context" {
    /**
     * Context by artifact type and capability. Paths are real 102034 sources.
     * The MDM catalog (`l4/ontology/mdm.defs.ts`) is a dependency file, not a stand-in
     * for RequestContext or mdmFacade. Domain declarations get no facade.
     * A definition source and a compiled TypeScript signature are different functions:
     * compiledSignature refuses a v2 def.
     */
    import { type M1ArtifactType, type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1ContextCapability } from "_102021_/l2/agentMaterializeL1/emitters/registry";
    export const PLATFORM_FILES: Record<M1ContextCapability, string>;
    export function usesMdm(data: Record<string, unknown>): boolean;
    /** Platform files for a named type. Unknown types get nothing — not the full bundle. */
    export function platformFilesFor(type: M1ArtifactType, data?: Record<string, unknown>): string[];
    export function platformFilesForDefinition(definition: M1Definition): string[];
    /**
     * Compiled signature of a TypeScript file. A v2 definition source is not a signature,
     * even when it contains `export const`.
     */
    export function compiledSignature(source: string): string | null;
    export interface ContextEntry {
        ref: string;
        role: 'platform' | 'def' | 'compiled';
        state: 'read' | 'inaccessible';
        sha256: string | null;
        /** Present only for role `compiled` when the bytes are a real signature. */
        signature: string | null;
    }
    export function renderPrompt(entries: readonly ContextEntry[], unresolved: readonly string[]): string;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/emitBehavior" {
    /**
     * Replaces a structure stub with behavior derived from the defs.
     * List copies the operation, the port and the entity fields. Create stores only the
     * server assignments and the input members the caller sent (absence is kept).
     * A transition copies lifecycle from/to, the selector and the payload paths.
     * A local storage row is the unique-key check. A payload path is required
     * when one local rule names that path. A leftover local rule is not emitted
     * when the route grant is an unresolved own-scope: that case stays blocked.
     * A pending rule row is not emitted. Events stay in a declared list and are
     * not published. A duplicate slot in this store is not a PostgreSQL atomic
     * constraint. A version the contract does not declare is not invented.
     * An MDM usecase walks `mdm.calls` in order. `expectedVersion` is emitted
     * only when a depended ontology field is `writePrecondition` and the
     * operation input carries that path. Create runs only when its `when` says
     * the prior find missed. No new facade is written.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type EmitFailure, type EmitResult, type StructureRead } from "_102021_/l2/agentMaterializeL1/emitters/emit";
    import { lifecycleStart } from "_102021_/l2/agentMaterializeL1/emitters/domainOptional";
    export { lifecycleStart };
    /** Raised when the implement handler body changes. An older receipt is a new input. */
    export const IMPLEMENT_HANDLER_RECIPE = "2026-10-02-implement-handler-v17";
    export const STORAGE_MARK = "// enforce:storage";
    export const PAYLOAD_MARK = "// enforce:payload";
    export const VERSION_MARK = "// enforce:version";
    export const CREATE_MARK = "// enforce:create";
    export const OWN_MARK = "// enforce:own";
    export interface CaseBlock {
        gap: string;
        owner: string;
        ruleId: string;
        unread: boolean;
    }
    export function isDerivedMdm(definition: M1Definition): boolean;
    export function behaviorNeedsLlm(definition: M1Definition): boolean;
    export function withoutStorageChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutPayloadChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutLifecycleChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutVersionChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutScopeChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutCreateChecks(source: string): {
        source: string;
        removed: number;
    };
    export function caseBlock(definition: M1Definition, defPath: string, item: {
        routine: string;
        expect: {
            ruleId: string | null;
        };
    }, read: StructureRead, moduleDefinitions?: readonly unknown[]): Promise<CaseBlock | null>;
    /** A lifecycle or payload rule is proved by calling the usecase, not the route. */
    export function ruleRunsOnUsecase(definition: M1Definition, ruleId: string, read: StructureRead, moduleDefinitions?: readonly unknown[]): Promise<boolean>;
    export function emitBehavior(id: string, definition: M1Definition, output: string, read: StructureRead, moduleDefinitions?: readonly unknown[]): Promise<EmitResult | EmitFailure>;
    /**
     * Routes of a usecase: the
     * `requests[].route` of the module's request services that name the usecase in `uses`. A v2 usecase
     * read without the module defs has no source for its routes: `MODULE_DEFS_UNREAD`, never an empty list.
     */
    export function usecaseRoutes(definition: M1Definition, moduleDefinitions: readonly unknown[]): string[] | EmitFailure;
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls ctx.mdm.prospect.promoteToEntity({ mdmId: prospectMdmId })
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Person | Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Person | Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/personAccess" {
    import type { PrivacyConsentValue } from "_102034_/l1/mdm/module";
    export interface PersonAccessData {
        name?: string | null;
        countryCode?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
    }
    export function isTwoLetterCountry(countryCode: string): boolean;
    export function isValidPrivacyConsent(consent: PrivacyConsentValue | null | undefined): boolean;
    /** Name, country and, in a protected country, a valid consent. Ignores registrationDraft. */
    export function isPersonAccessComplete(detail: PersonAccessData): boolean;
    /** Expects an already normalized ISO code (BR / EU). */
    export function isProtectedPrivacyCountry(countryCode: string): boolean;
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    /**
     * Organization-level registration namespace (the third MDM layer: base · general · module).
     * Schema lives in the project's solution registry (l4); the engine only reserves the key
     * and does not filter it on read.
     */
    export type MdmGeneralNamespace = Record<string, unknown>;
    export const MDM_GENERAL_NAMESPACE = "general";
    export const MDM_ORGANIZATION_MODULE_ID = "organization";
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        /** Platform bootstrap marker. Absent once the type's minimum data is stored. Not a role. */
        registrationDraft?: true;
        createdAt: string;
        updatedAt: string;
        general?: MdmGeneralNamespace;
        /** Computed on facade reads: other modules' namespace keys (no content). Not persisted. */
        namespaces?: string[];
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;
    export type MdmDetailInput = DistributiveOmit<MdmDetailRecord, 'mdmId'> & {
        mdmId?: string;
    };
    export interface MdmDocumentInput {
        mdmId: string;
        version: number;
        details: MdmDetailInput;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface CreateRegistrationEntityParams {
        mdmId: string;
        detail: CreateableMdmDetailInput;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
    export type { PersonAccessData } from "_102034_/l1/mdm/personAccess";
    export { isPersonAccessComplete, isProtectedPrivacyCountry, isValidPrivacyConsent, } from "_102034_/l1/mdm/personAccess";
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts" {
    import type { ContactSummaryValue } from "_102034_/l1/mdm/module";
    export type MdmUserStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmListUsersStatusFilter = MdmUserStatus | 'all';
    export type MdmRoleTagMode = 'with' | 'without';
    export interface MdmListUsersInput {
        name?: string;
        status?: MdmListUsersStatusFilter;
        roleTag?: string;
        roleTagMode?: MdmRoleTagMode;
        pageSize?: number;
        cursor?: string;
    }
    export interface MdmUserSummary {
        mdmId: string;
        version: number;
        name: string;
        loginEmail: string;
        status: MdmUserStatus;
        tags: string[];
        contacts: ContactSummaryValue[];
    }
    export interface MdmListUsersResult {
        items: MdmUserSummary[];
        nextCursor: string | null;
    }
    /** Normalized directory page. `limit` is pageSize + 1. Filters exclude page size. */
    export interface MdmUserDirectoryQuery {
        foldedName: string | null;
        status: MdmListUsersStatusFilter;
        roleTag: string | null;
        roleTagMode: MdmRoleTagMode | null;
        afterMdmId: string | null;
        limit: number;
    }
    export interface MdmUserDirectoryFilter {
        foldedName: string | null;
        status: MdmListUsersStatusFilter;
        roleTag: string | null;
        roleTagMode: MdmRoleTagMode | null;
    }
    /**
     * Index plus the few document fields the facade must check.
     * No private namespaces, consent, tokens, or the whole document.
     */
    export interface MdmUserDirectoryRow {
        mdmId: string;
        name: string;
        status: MdmUserStatus;
        tags: string[];
        version: number | null;
        documentMdmId: string | null;
        documentSubtype: string | null;
        contacts: unknown;
        loginTags: string[];
    }
    export interface MdmIdentityUserReader {
        listPage(query: MdmUserDirectoryQuery): Promise<MdmUserDirectoryRow[]>;
    }
    /** NFD, drop combining marks U+0300..U+036F, then lowercase. Literal characters stay. */
    export function foldUserName(value: string): string;
    /** SHA-256 hex of the stable filter projection. Page size is not part of the key. */
    export function userDirectoryFilterKey(filter: MdmUserDirectoryFilter): string;
    /**
     * Navigation cursor only: base64url JSON `{v,lastMdmId,filterKey}` at most 4 KiB.
     * It is not an authorization grant and it carries no login data.
     */
    export function encodeUserDirectoryCursor(lastMdmId: string, filter: MdmUserDirectoryFilter): string;
    /** Validates a list input and returns the directory query. Unknown fields and bad cursors are 400. */
    export function normalizeListUsersInput(input: unknown): MdmUserDirectoryQuery;
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export type { ProjectClientShellConfig, ProjectConfigRecord, ProjectDynamicRegionConfig, ProjectFrontendPageConfig, ProjectModuleConfig, ProjectModuleFrontendConfig, ProjectModuleFrontendEntrypoint, ProjectNavigationEntry, ProjectPersistenceModuleConfig, ProjectRegionRendererConfig, ProjectShellRegionProfiles, ProjectType, ProjectsConfig, } from "_102029_/l2/runtimeConfigTypes";
    /**
     * `existsSync` for a default location that this process may not be allowed to read (a Deno child only reads its own
     * base): a denied check (`NotCapable`, `EACCES`) counts as absent, with one log line. Any other error still throws.
     */
    export function existsSyncOrDenied(path: string): boolean;
    export function projectsConfigExists(): boolean;
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function resolveWebDistPath(relativePath?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/config/projectMode" {
    export type ProjectMode = 'production' | 'homologation' | 'development' | 'presentation';
    /** A generated module is born in `presentation`; anything unreadable falls back to it, loudly. */
    export const DEFAULT_PROJECT_MODE: ProjectMode;
    export function isProjectMode(value: unknown): value is ProjectMode;
    /** Test modes run against the TEST database and may be written to by the test runner. */
    export function isTestMode(mode: ProjectMode): boolean;
    /**
     * The mode declared by `l5/project.json` of a project. Absent or invalid ⇒ `presentation` with a warning:
     * defaulting to production would point a freshly generated module at real data, which is the one mistake
     * this whole concept exists to prevent.
     */
    /**
     * Did the project DECLARE its mode, or is it running on the default?
     *
     * The difference decides whether a missing `DATABASE_URL_TEST` is a failure: a project that explicitly
     * says `presentation` and has no test connection string is misconfigured and must say so; a project that
     * declared nothing at all is simply older than the modes, and breaking its boot over a default would be
     * this feature's worst outcome.
     */
    export function hasDeclaredProjectMode(projectId?: string | number): boolean;
    export function readProjectMode(projectId?: string | number): ProjectMode;
    /** Which env var holds the connection string for this mode. */
    export function databaseUrlEnvFor(mode: ProjectMode): 'DATABASE_URL' | 'DATABASE_URL_TEST';
    /**
     * The connection string for a mode — and a LEGIBLE failure when a test mode has none.
     *
     * Falling back to `DATABASE_URL` here would be the worst possible bug of this feature: a presentation
     * module quietly writing curated seeds over production data. So the absence is an error, not a default.
     */
    export function resolveDatabaseUrl(mode: ProjectMode): string;
    /**
     * Create the TEST database when it does not exist yet.
     *
     * "Nothing manual per project": provisioning a generated app flows through the publish, so a test mode
     * that points at a database nobody created should create it instead of demanding an SSH session. Only the
     * DATABASE is created — the schema is the bootstrap's job — and only in a test mode: nobody
     * auto-provisions production. Returns what happened, so the caller can log it; a missing privilege is
     * reported, not swallowed, because then the legible failure IS the answer.
     */
    export function ensureTestDatabase(mode: ProjectMode, connect: (adminUrl: string) => Promise<{
        exists: (database: string) => Promise<boolean>;
        create: (database: string) => Promise<void>;
        end: () => Promise<void>;
    }>): Promise<{
        created: boolean;
        database: string;
        reason: string;
    }>;
    /** The database name of a connection string, plus the same string pointed at `postgres` (admin). */
    export function parseDatabaseUrl(url: string): {
        database: string;
        adminUrl: string;
    } | null;
    export interface WriteAttempt {
        /** Where the request came from — the transport stamps it; `test` is the monitor runner. */
        source?: 'http' | 'message' | 'test';
        /** The routine's command segment (`cmdCreateClient`, `qryListClient`). */
        command?: string;
    }
    /**
     * May this request write? The SERVER half of the two defences.
     *
     * The runner is supposed to keep its destructive suite for test modes, but "supposed to" is what let a
     * production run write junk once. The generated vocabulary makes the check deterministic: `cmd*` mutates,
     * `qry*` reads. A read-only smoke from the runner stays allowed everywhere, which is what makes production
     * still observable.
     */
    export function refuseTestWrite(mode: ProjectMode, attempt: WriteAttempt): string;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    /**
     * WHICH DATABASE — the project's mode decides, when it has been given the means to.
     *
     * A project in `development`/`presentation` must talk to the TEST database, never to production: that is
     * the whole point of the modes. The connection string for it lives in `DATABASE_URL_TEST`.
     *
     * Two behaviours on purpose, so the order of operations stops mattering:
     * - the env EXISTS ⇒ the mode decides, and a test mode connects to the test database;
     * - the env does NOT exist ⇒ the legacy `PGHOST/PGDATABASE/...` path, exactly as before. A server that
     *   has not been given the variable yet keeps booting; when it is given one, the new behaviour turns
     *   itself on with no code change.
     *
     * The one thing that never happens is a test mode silently connecting to production: if the mode is a test
     * mode and `DATABASE_URL_TEST` is absent while `DATABASE_URL` is present, that is a legible failure, not a
     * fallback (`resolveDatabaseUrl`).
     */
    function poolConfigFor(env: AppEnv): {
        connectionString: string;
    } | {
        host: string;
        port: number;
        database: string;
        user: string;
        password: string;
    };
    export type PgPoolConfig = ReturnType<typeof poolConfigFor>;
    /** Database the shared pool actually opens: the name in the connection string, or the legacy `pgDatabase`. */
    export function sharedPgDatabaseName(env: AppEnv): string;
    /**
     * Pool settings for a database other than the shared one.
     * With a connection string, only the database name changes. Without one, the legacy host/user/password stay.
     */
    export function pgPoolConfigForDatabase(env: AppEnv, databaseName: string): PgPoolConfig;
    export function getSharedPgPool(env: AppEnv): Pool;
    /** Draft process: MDM reads the app database. Absent variable keeps today's single pool. */
    export function getMdmPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/seedPolicy" {
    import { type ProjectMode } from "_102034_/l1/server/layer_1_external/config/projectMode";
    import type { SeedExportOrigin, SeedPurpose, TableIndexDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export interface SeedPolicyColumn {
        name: string;
        nullable?: boolean;
    }
    /** Table fields the seed policy needs. Rows are read and never written. */
    export interface SeedPolicyTable {
        tableName: string;
        logicalTableName: string;
        storageProfile: string;
        columns: SeedPolicyColumn[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        seedRows?: ReadonlyArray<Record<string, unknown>>;
        initialSeedRows?: ReadonlyArray<Record<string, unknown>>;
    }
    export interface SeedModeInput {
        tableName: string;
        logicalTableName: string;
        projectMode: ProjectMode;
        serverMode: ProjectMode;
    }
    export function readSeedPurpose(value: unknown, origin: Pick<SeedExportOrigin, 'source' | 'seedFor'>): SeedPurpose;
    /** Unprefixed physical name ⇒ platform table. Platform seeds follow serverMode. */
    export function isPlatformSeedTable(table: Pick<SeedPolicyTable, 'tableName' | 'logicalTableName'>): boolean;
    export function seedModeFor(input: SeedModeInput): {
        platform: boolean;
        mode: ProjectMode;
    };
    /** Initial is always eligible. Test follows the same mode rule as today. */
    export function isTestSeedEligible(input: SeedModeInput): boolean;
    /** PK, then unique indexes with no predicate, whose columns all exist and are not nullable. */
    export function completeUniqueKeys(table: Pick<SeedPolicyTable, 'columns' | 'primaryKey' | 'indexes'>): string[][];
    /**
     * Initial rows require Postgres, a declared complete unique key, and columns that exist.
     * dynamoOnly has no seed application in this engine and is refused here.
     */
    export function assertInitialSeed(table: SeedPolicyTable, rows: ReadonlyArray<Record<string, unknown>>, origin: SeedExportOrigin): void;
    /**
     * Selects initial rows always and test rows only in a test mode.
     * A test row that collides with an initial row on any complete unique key is omitted.
     * Returned array is new; `seedRows` and `initialSeedRows` are not modified.
     */
    export function selectEligibleSeedRows(table: SeedPolicyTable, input: SeedModeInput): Record<string, unknown>[];
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    /**
     * Files of a table-defs folder that are imported. `.defs.*` is kept (those are the definitions); a test file is never
     * imported by the app, because it runs its own top-level code inside the server.
     */
    export function selectTableDefinitionFiles(entries: readonly string[]): string[];
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    /** Snapshot row used for the schema hash. Columns in; seedRows out — a seed-only edit must not rebuild. */
    export function toSchemaSnapshotTable(definition: ResolvedTableDefinition): SchemaSnapshot['tables'][number];
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
    /**
     * A module that wants to be woken up exports `onTick` from its persistence file, next to
     * `tableDefinitions` and `viewDefinitions`. The platform only lends the clock: what the module does
     * with the minute — which occurrences it owes, where it records them — is the module's business.
     */
    export type ModuleTickHandler = (ctx: RequestContext, now: Date) => Promise<void> | void;
    export interface ModuleTickRegistration {
        moduleId: string;
        onTick: ModuleTickHandler;
    }
    /**
     * Collects `onTick` the same way `loadViewDefinitions` collects `viewDefinitions` — with one
     * difference on purpose: a module whose import throws is warned about and skipped instead of
     * rejecting the whole load. `loadViewDefinitions` above has no such isolation; the tick runs every
     * minute forever, so one broken module must not silence every other module's clock.
     */
    export function loadModuleTickHandlers(): Promise<ModuleTickRegistration[]>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        /** Case-insensitive substring per column (`ILIKE` in Postgres). Empty/absent values are ignored. */
        ilike?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
        /** Rows to skip after filtering/ordering. Absent = 0. `findMany` without limit/offset is unchanged. */
        offset?: number;
    }
    /** Default page size when a list asks to paginate without saying how many. */
    export const DEFAULT_PAGE_SIZE = 20;
    /** Hard cap: a requested pageSize above this is cut, and the envelope declares the effective size. */
    export const MAX_PAGE_SIZE = 200;
    export interface ResolvedListPage {
        page: number;
        pageSize: number;
        limit: number;
        offset: number;
    }
    /**
     * Convert optional page/pageSize into LIMIT/OFFSET. Default 20, cap 200 — the cut is declared
     * (returned pageSize is the effective one), never silent and never a rejection.
     */
    export function resolveListPage(input?: {
        page?: number;
        pageSize?: number;
    }): ResolvedListPage;
    export function applyFindManyWindow<TRecord>(rows: TRecord[], input?: Pick<IFindManyInput<TRecord>, 'limit' | 'offset'>): TRecord[];
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        /** Rows matching the filter, ignoring limit/offset. Same WHERE as findMany. */
        count(input?: IFindManyInput<TRecord>): Promise<number>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function buildFindManySql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function buildCountSql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    /** Postgres SQLSTATE of a unique-key violation. The memory runtime raises the same code. */
    export const UNIQUE_VIOLATION = "23505";
    /** Same selection the migration uses: initial always, test only in the owning mode, initial wins a key clash. */
    export function copyEligibleSeedRows(definition: ResolvedTableDefinition, env: Pick<AppEnv, 'projectId'>): Record<string, unknown>[];
    /** A disposable sandbox run: initial and test rows in any mode (initial still wins a key clash). */
    export function copySandboxSeedRows(definition: ResolvedTableDefinition): Record<string, unknown>[];
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
    /** In-memory ITableRepository without the persistence registry — fixture for tests, not a generated app. */
    export function createMemoryTableRepository<TRecord extends object>(records: TRecord[]): ITableRepository<TRecord>;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmDocumentInput, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord, MdmKvRecord } from "_102034_/l1/mdm/module";
    import type { MdmIdentityUserReader } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentInput;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        /** Same physical table as `moduleData.getTable('mdmKv')`; bound to the MDM executor. */
        mdmRegistrationKv: ITableRuntime<MdmKvRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        /** Optional directory reader. Absence must not open a global pool. */
        mdmIdentityUsers?: MdmIdentityUserReader;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>, options?: {
            lockKey: string;
        }): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory" {
    export interface ICacheRuntime {
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
    export class CacheRuntimeMemory implements ICacheRuntime {
        private readonly defaultTtlSeconds?;
        private readonly values;
        constructor(defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmDetailRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmDocumentEntity {
        static get(ctx: RequestContext, mdmId: string): Promise<MdmDocumentRecord>;
        static parseDetails(document: MdmDocumentRecord): MdmDetailRecord;
        static create(ctx: RequestContext, record: MdmDocumentRecord): Promise<void>;
        static replace(ctx: RequestContext, record: MdmDocumentRecord, expectedVersion: number): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRecordStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export class MdmRecordEntity {
        static getEntityIndex(ctx: RequestContext, mdmId: string): Promise<MdmEntityIndexRecord>;
        static getProspectIndex(ctx: RequestContext, mdmId: string): Promise<MdmProspectIndexRecord>;
        static findEntityByDocument(ctx: RequestContext, docType?: string | null, docId?: string | null): Promise<MdmEntityIndexRecord | null>;
        static findEntityByContact(ctx: RequestContext, contactType?: string | null, value?: string | null): Promise<MdmEntityIndexRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    export class MdmRelationshipEntity {
        static findOne(ctx: RequestContext, id: string): Promise<{
            scope: 'entity' | 'prospect';
            relationship: MdmRelationshipRecord;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmSupport" {
    import type { MdmProspectStatus, MdmStatus, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CreateRecordParams, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { isPersonAccessComplete, isProtectedPrivacyCountry } from "_102034_/l1/mdm/personAccess";
    export { isPersonAccessComplete, isProtectedPrivacyCountry };
    type RelationshipScope = 'entity' | 'prospect';
    export function getMdmModuleTypes(detail: MdmDetailRecord | Record<string, unknown>): string[];
    export function refreshRelationshipRefs(ctx: RequestContext, relationshipScope: RelationshipScope, mdmIds: string[], enqueueDocumentWrite: (document: {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }) => Promise<void>): Promise<void>;
    export function normalizeCountryCode(countryCode?: string | null): string;
    export function normalizeDocumentId(docId?: string | null): string | null;
    export function normalizeContactValue(value?: string | null): string | null;
    export function normalizeDetailInput(input: CreateRecordParams['detail'], ctx: RequestContext, mdmId: string, options?: {
        registrationDraft?: true;
    }): MdmDetailRecord;
    export function applyPatchToDetail(currentDetail: MdmDetailRecord, patch: Partial<MdmDetailRecord>, ctx: RequestContext): MdmDetailRecord;
    export function normalizeStatus(detail: MdmDetailRecord): MdmStatus | MdmProspectStatus;
    export function validateDetail(detail: MdmDetailRecord): void;
    export function toDocumentRecord(detail: MdmDetailRecord, version: number): {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    };
    export function buildEntityIndex(detail: MdmDetailRecord): MdmEntityIndexRecord;
    export function buildProspectIndex(detail: MdmDetailRecord): MdmProspectIndexRecord;
    export function normalizeEntityStatus(detail: MdmDetailRecord): MdmStatus;
    export function normalizeProspectStatus(detail: MdmDetailRecord): MdmProspectStatus;
    export function buildSearchVector(detail: MdmDetailRecord): string;
    export function relationshipIsBidirectional(type: RelationshipType): boolean;
    export function migrateProspectRelationships(ctx: RequestContext, prospectMdmId: string): Promise<{
        affectedIds: string[];
        migratedRelationships: MdmRelationshipRecord[];
    }>;
    export function buildRelationshipSearchText(relationship: MdmRelationshipRecord): string;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/mdmEntityDefs" {
    import type { EntityDef, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export const mdmEntityDef: EntityDef<MdmDetailRecord, MdmEntityIndexRecord>;
    export const mdmProspectDef: EntityDef<MdmDetailRecord, MdmProspectIndexRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/entityPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateableMdmDetailInput, CreateRecordParams, ListRecordsParams, MergeEntityParams, MdmDocumentRecord, MdmRelationshipDocumentRecord, PromoteProspectParams, RecordDetailResponse, UpdateRecordParams } from "_102034_/l1/mdm/module";
    export function enqueueWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], document: MdmDocumentRecord): Promise<void>;
    export function enqueueRelationshipWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], relationship: MdmRelationshipDocumentRecord): Promise<void>;
    export function createEntity(ctx: RequestContext, params: CreateRecordParams): Promise<{
        alreadyExists: boolean;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: boolean;
        mdmId: string;
        version: number;
    }>;
    type RegistrationDraftDetailInput = Partial<CreateableMdmDetailInput> & {
        subtype: 'Person' | 'Company';
    };
    export function createRegistrationEntity(ctx: RequestContext, params: {
        mdmId: string;
        detail: RegistrationDraftDetailInput;
    }): Promise<{
        alreadyExists: true;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: false;
        mdmId: string;
        version: number;
    }>;
    export function createProspect(ctx: RequestContext, params: CreateRecordParams): Promise<{
        mdmId: string;
        version: number;
    }>;
    export function getEntity(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function getProspect(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function listEntities(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord[]>;
    export function listProspects(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord[]>;
    export function updateEntity(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
    }>;
    export function updateProspect(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus | import("_102034_/l1/mdm/defs/ontology").MdmProspectStatus;
    }>;
    export function promoteProspect(ctx: RequestContext, params: PromoteProspectParams): Promise<{
        promoted: boolean;
        status: string;
        mdmId: string;
        prospectMdmId: string;
        candidateMdmId: string;
    } | {
        promoted: boolean;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
        mdmId: string;
    }>;
    export function mergeEntity(ctx: RequestContext, params: MergeEntityParams): Promise<{
        winnerMdmId: string;
        loserMdmId: string;
        status: string;
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/relationshipPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRelationshipParams, ListRelationshipsParams, SearchParams, UpdateRelationshipParams } from "_102034_/l1/mdm/module";
    export function createRelationship(ctx: RequestContext, params: CreateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            role: string;
            metadata: Record<string, unknown>;
            isBidirectional: boolean;
            validFrom: string;
            validTo: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            createdAt: string;
            updatedAt: string;
        };
    }>;
    export function listRelationships(ctx: RequestContext, params: ListRelationshipsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[]>;
    export function updateRelationship(ctx: RequestContext, params: UpdateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            updatedAt: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            metadata?: Record<string, unknown>;
            role?: string | null;
            validFrom: string;
            validTo?: string | null;
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            isBidirectional: boolean;
            createdAt: string;
        };
    }>;
    export function runSearch(ctx: RequestContext, params: SearchParams): Promise<{
        records: (import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord | import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord)[];
        relationships: import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[];
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export function attachFile(ctx: RequestContext, params: AttachFileParams): Promise<MdmAttachmentRecord>;
    export function detachFile(ctx: RequestContext, params: DetachFileParams): Promise<MdmAttachmentRecord>;
    export function findAttachmentsByEntity(ctx: RequestContext, params: FindAttachmentsByEntityParams): Promise<MdmAttachmentRecord[]>;
}
declare module "_102034_/l1/mdm/defs/platformDetailKeys" {
    /**
     * Runtime classification of MDM `details` keys: platform catalog fields vs engine
     * compatibility extras vs computed. Consumers share this module; they do not keep
     * a mirrored Set. Classification does not grant write access to derived fields.
     */
    /** Names declared by the platform catalog (identification, base, and subtypes). */
    export const MDM_CATALOG_PLATFORM_DETAIL_KEYS: readonly ["subtype", "name", "status", "moduleTypes", "docType", "docId", "countryCode", "tags", "aliases", "contacts", "relationshipRefs", "addresses", "mergedInto", "createdAt", "updatedAt", "privacyConsent", "birthDate", "gender", "nationality", "occupation", "photoUrl", "notes", "companyKind", "parentCompanyId", "externalCode", "legalName", "tradeName", "legalType", "foundingDate", "taxRegime", "industryCode", "website", "sku", "productType", "category", "brand", "unitOfMeasure", "isInventoried", "serviceCode", "serviceKind", "parentServiceId", "serviceType", "durationMinutes", "deliveryMode", "locationType", "locationCode", "parentLocationId", "capacity", "propertyAddress", "assetCategory", "serialNumber", "manufacturer", "model", "contactType", "value", "isVerified", "verifiedAt", "storageBucket", "storagePath", "originModule", "docCategory", "fileName", "mimeType", "bankRoutingNumber", "bankName", "accountNumber", "accountType", "swift", "iban", "pixKey", "pixKeyType", "acquisitionDate", "areaM2", "areaSqft", "breed", "color", "expiresAt", "fileSizeKb", "fuelType", "isNeutered", "issuedAt", "issuer", "microchip", "plate", "propertyType", "registrationNumber", "sex", "species", "taxParcelId", "vin", "year"];
    /**
     * Engine/prospect extras accepted by the current contract. Not catalog fields and
     * not module namespaces. Exported for the parity test; do not copy these strings.
     */
    export const MDM_ENGINE_COMPAT_DETAIL_KEYS: readonly ["mdmId", "registrationDraft", "promotionSource", "promotedTo", "ttlExpiresAt"];
    /** Computed on facade reads; never a persisted module namespace. */
    export const MDM_COMPUTED_DETAIL_KEYS: ReadonlySet<string>;
    export const MDM_PLATFORM_DETAIL_KEYS: ReadonlySet<string>;
    export function isMdmComputedDetailKey(key: string): boolean;
    export function isMdmPlatformDetailKey(key: string): boolean;
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeRedis" {
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export class CacheRuntimeRedis implements ICacheRuntime {
        private readonly defaultTtlSeconds;
        private socket;
        private connecting;
        private queue;
        private readonly target;
        constructor(url: string, defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
        close(): Promise<void>;
        private command;
        private ensureConnected;
        private commandOn;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/identityCache" {
    import { type ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export const IDENTITY_CACHE_KEY_PREFIX = "identity:login:";
    export const DEFAULT_IDENTITY_CACHE_TTL_SECONDS = 300;
    export interface IdentityCacheValue {
        mdmId: string;
        name: string;
    }
    export function identityCacheKey(email: string): string;
    export function identityCacheTtlSeconds(): number;
    /**
     * Pick the cache implementation by capability: Redis when REDIS_URL is present,
     * in-memory otherwise. Never by host name.
     */
    export function createIdentityCache(redisUrl?: string | null): ICacheRuntime;
    export function getSharedIdentityCache(): ICacheRuntime;
    export function resetSharedIdentityCacheForTests(): void;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityLogin" {
    export function normalizeLoginEmail(email: string): string;
    export function assertLoginEmail(email: string): string;
    export function storedLoginEmailFromTags(tags: readonly string[], mdmId: string): string | null;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsecases" {
    import { type PlatformSessionPerson, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type IdentityCacheValue } from "_102034_/l1/server/layer_1_external/cache/identityCache";
    export const MDM_LOGIN_NAMESPACE = "login";
    export const MDM_LOGIN_ENTITY_TYPE = "MdmEntity";
    export interface MdmIdentityInviteInput {
        mdmId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }
    export interface MdmIdentityInviteResult {
        token: string;
        expiresAt: string;
        teamIds?: string[];
    }
    export function lookupLoginEmail(ctx: RequestContext, mdmId: string): Promise<string | null>;
    export function lookupLogin(ctx: RequestContext, email: string): Promise<IdentityCacheValue | null>;
    export function findByLogin(ctx: RequestContext, email: string): Promise<string | null>;
    export function resolveSessionPerson(ctx: RequestContext, email: string): Promise<PlatformSessionPerson | null>;
    export function setLogin(ctx: RequestContext, mdmId: string, email: string): Promise<{
        mdmId: string;
        email: string;
    }>;
    export function createCollabAuthInviteHttp(input: {
        baseUrl: string;
        apiKey: string;
        orgId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }): Promise<MdmIdentityInviteResult>;
    export function invite(ctx: RequestContext, input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsers" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type MdmListUsersInput, type MdmListUsersResult } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    /** Reads one directory page. Does not authorize the caller and does not mutate MDM. */
    export function listUsers(ctx: RequestContext, input?: MdmListUsersInput): Promise<MdmListUsersResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmFacade" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export { MDM_PLATFORM_DETAIL_KEYS, isMdmComputedDetailKey, isMdmPlatformDetailKey, } from "_102034_/l1/mdm/defs/platformDetailKeys";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord, CompactRelationshipRefKey, CreateableMdmDetailInput, MdmDetailRecord, MdmDocumentRecord, MdmEntityIndexRecord, MdmModuleNamespaceValue, MdmProspectIndexRecord, RelationshipStatus } from "_102034_/l1/mdm/module";
    import type { MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import { type MdmIdentityInviteInput, type MdmIdentityInviteResult } from "_102034_/l1/mdm/layer_3_usecases/identityUsecases";
    import type { MdmListUsersInput, MdmListUsersResult, MdmUserSummary } from "_102034_/l1/mdm/layer_3_usecases/identityUsersContracts";
    export type { MdmListUsersInput, MdmListUsersResult, MdmUserSummary };
    export type MdmEntityCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmEntityCreateInput {
        details: MdmEntityCreateDetails;
    }
    export type MdmProspectCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmProspectCreateInput {
        details: MdmProspectCreateDetails;
    }
    export interface MdmEntityUpdateInput {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface MdmProspectUpdateInput extends MdmEntityUpdateInput {
    }
    export interface MdmEntityGetInput {
        mdmId: string;
    }
    export interface MdmProspectGetInput extends MdmEntityGetInput {
    }
    export interface MdmProspectPromoteToEntityInput {
        mdmId: string;
    }
    export interface MdmEntityInactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    /** Mirror of MdmEntityInactivateInput: the cadastral cycle is symmetric, so its input is too. */
    export interface MdmEntityReactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    export interface MdmEntityDeleteInput {
        mdmId: string;
        allowActiveRelationships?: boolean;
    }
    export interface MdmLinkInput {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom?: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface MdmUnlinkInput {
        relationshipId: string;
    }
    export interface MdmGetManyInput {
        mdmIds: string[];
        chunkSize?: number;
    }
    export interface MdmListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmProspectListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmProspectStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmHydrateManyInput extends MdmGetManyInput {
        sections?: string[];
        includeRelationshipRefs?: boolean;
    }
    export interface MdmRelatedOfManyInput {
        mdmIds: string[];
        type?: RelationshipType;
        status?: RelationshipStatus;
    }
    export interface MdmRelatedRef {
        mdmId: string;
        relationshipId: string;
        type: RelationshipType;
        direction: 'from' | 'to';
        role?: string | null;
        metadata?: Record<string, unknown>;
    }
    export interface MdmEntityReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmEntityIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmEntityWriteResult extends MdmEntityReadResult {
        alreadyExists?: boolean;
    }
    export interface MdmProspectReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmProspectIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmProspectWriteResult extends MdmProspectReadResult {
    }
    export type MdmProspectListByTypeItem = MdmProspectIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmProspectListByTypeResult {
        items: MdmProspectListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmProspectPromoteToEntityResult {
        promoted: boolean;
        status: MdmStatus | MdmProspectStatus;
        mdmId: string;
        prospectMdmId?: string;
        candidateMdmId?: string;
    }
    export interface MdmDeleteResult {
        mdmId: string;
        deleted: true;
    }
    export type MdmListByTypeItem = MdmEntityIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmListByTypeResult {
        items: MdmListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmHydratedEntity {
        mdmId: string;
        version: number;
        details: Partial<MdmDetailRecord>;
    }
    export interface MdmFacade {
        entity: MdmEntity;
        prospect: MdmProspect;
        collection: MdmCollection;
        attachment: MdmAttachment;
        identity: MdmIdentity;
    }
    export function isUnrestrictedMdmCaller(moduleId?: string | null): boolean;
    export function projectDetailsForModule(details: MdmDetailRecord | Record<string, unknown>, moduleId?: string | null): MdmDetailRecord;
    export class MdmEntity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmEntityCreateInput): Promise<MdmEntityWriteResult>;
        get(input: MdmEntityGetInput): Promise<MdmEntityReadResult>;
        update(input: MdmEntityUpdateInput): Promise<MdmEntityWriteResult>;
        findByDocument(docType: string, docId: string): Promise<MdmEntityReadResult | null>;
        findByContact(contactType: string, value: string): Promise<MdmEntityReadResult | null>;
        /**
         * Create-or-attach: add tag `<moduleId>.<role>` without duplicating, and optionally write the
         * caller module's namespace. Role may be the entity id (`Cliente`) or the canonical tag.
         */
        attachRole(mdmId: string, role: string, namespace?: MdmModuleNamespaceValue): Promise<MdmEntityWriteResult>;
        inactivate(input: MdmEntityInactivateInput): Promise<MdmEntityWriteResult>;
        /**
         * The other half of the cadastral cycle. An MDM entity is NEVER deleted by a generated module: the
         * tier-1 catalogue emits `inactivate`/`reactivate` for `storage.target: 'mdm'` instead of `delete`,
         * so a generated `cmdReactivate*` had no target here at all until this method existed.
         *
         * Deliberately the exact mirror of `inactivate` — same optimistic version, same single-field patch —
         * because any asymmetry between the two halves shows up as a record that can be hidden and not
         * brought back.
         */
        reactivate(input: MdmEntityReactivateInput): Promise<MdmEntityWriteResult>;
        delete(input: MdmEntityDeleteInput): Promise<MdmDeleteResult>;
        link(input: MdmLinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                role: string;
                metadata: Record<string, unknown>;
                isBidirectional: boolean;
                validFrom: string;
                validTo: string;
                status: RelationshipStatus;
                createdAt: string;
                updatedAt: string;
            };
        }>;
        unlink(input: MdmUnlinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                updatedAt: string;
                status: RelationshipStatus;
                metadata?: Record<string, unknown>;
                role?: string | null;
                validFrom: string;
                validTo?: string | null;
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                isBidirectional: boolean;
                createdAt: string;
            };
        }>;
    }
    export class MdmProspect {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmProspectCreateInput): Promise<MdmProspectWriteResult>;
        get(input: MdmProspectGetInput): Promise<MdmProspectReadResult>;
        update(input: MdmProspectUpdateInput): Promise<MdmProspectWriteResult>;
        listByType(input: MdmProspectListByTypeInput): Promise<MdmProspectListByTypeResult>;
        promoteToEntity(input: MdmProspectPromoteToEntityInput): Promise<MdmProspectPromoteToEntityResult>;
    }
    export class MdmCollection {
        private readonly ctx;
        constructor(ctx: RequestContext);
        getMany(input: MdmGetManyInput): Promise<MdmEntityReadResult[]>;
        listByType(input: MdmListByTypeInput): Promise<MdmListByTypeResult>;
        relatedOfMany(input: MdmRelatedOfManyInput): Promise<Record<string, MdmRelatedRef[]>>;
        hydrateMany(input: MdmHydrateManyInput): Promise<MdmHydratedEntity[]>;
    }
    /**
     * Attachments of any record, through the facade.
     *
     * The usecases already existed (`attachFile`/`detachFile`/`findAttachmentsByEntity`, with write-behind and
     * audit) but nothing in a generated module could reach them: `ctx.mdm` exposed only entity/prospect/
     * collection. This is the wiring, nothing more — no new rule, no new storage.
     *
     * An attachment is ORTHOGONAL to the record it belongs to (`entityType` + `entityId` + `category`), which
     * is why a photo never becomes a field of the ontology. AUTHORIZATION v1 is the owner's: whoever may read
     * or edit the record may list and attach — the caller has already been through the route's own gate, and a
     * finer rule needs the party/dataScope work that is not here yet.
     *
     * The BYTES are not this API's business: it registers metadata plus a `storageKey`. Uploading through
     * `/execBff` (JSON) is never right; that is what the presigned-URL entry point is for.
     */
    export class MdmAttachment {
        private readonly ctx;
        constructor(ctx: RequestContext);
        attach(input: AttachFileParams): Promise<MdmAttachmentRecord>;
        detach(input: DetachFileParams): Promise<{
            id: string;
            deleted: true;
        }>;
        /**
         * LIVE attachments of a record (optionally one category).
         *
         * `detach` is a SOFT delete — it stamps `deletedAt` — and the underlying query does not filter it, so a
         * gallery built straight on it would keep showing a photo the user removed. Filtering here keeps the
         * usecase (and the existing `mdm.attachment.*` route, which returns the full history) untouched, and
         * `includeDetached` is there for whoever wants the history on purpose.
         */
        listByEntity(input: FindAttachmentsByEntityParams & {
            includeDetached?: boolean;
        }): Promise<MdmAttachmentRecord[]>;
    }
    export class MdmIdentity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        findByLogin(email: string): Promise<string | null>;
        setLogin(mdmId: string, email: string): Promise<{
            mdmId: string;
            email: string;
        }>;
        invite(input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
        listUsers(input?: MdmListUsersInput): Promise<MdmListUsersResult>;
        getLoginEmail(mdmId: string): Promise<string | null>;
    }
    export function createMdmFacade(ctx: RequestContext): MdmFacade;
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    import type { MdmFacade } from "_102034_/l1/mdm/layer_3_usecases/mdmFacade";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
            userId?: string;
            authToken?: string;
            /**
             * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
             * usefully — the http transport overwrites them from the JWKS-verified token, and every other
             * identity field of this meta is discarded on that transport. This is the only channel through which
             * a request may tell execBff who it is.
             */
            verifiedUserId?: string;
            verifiedEmail?: string;
            /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
            verifiedAuthorities?: string[];
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            /**
             * "Done through the assistant". Read ONLY when `source` is `message` (a server-side caller) and only the value
             * `nora`; over `http` it is discarded like every other identity claim.
             */
            via?: 'nora';
            actorId?: string;
            actorScope?: string[];
            activeCompanyId?: string;
            activeUnitId?: string;
            workspaceId?: string;
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRegionName = 'header' | 'aside' | 'content';
    export interface FrontendDynamicRegionConfig {
        renderer: FrontendRegionRendererRegistration;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface FrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, FrontendDynamicRegionConfig>;
    }
    export interface FrontendClientShellConfig {
        mode: ShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: FrontendShellRegionProfiles;
            aside?: FrontendShellRegionProfiles;
        };
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
        /** Optional Lucide icon name. Absent when the config item has none. */
        icon?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestBusinessContext {
        activeCompanyId?: string;
        activeUnitId?: string;
    }
    export interface RequestActorSession {
        actorId?: string;
        scope?: string[];
    }
    export interface RequestCurrentWorkspace {
        workspaceId?: string;
    }
    export interface RequestProjectContext {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface RequestOrganizationContext {
        countryCode: string;
        currency?: string;
        timezone?: string;
    }
    /**
     * Typed projection of the signed-in Person onto the session — public contract, not the MDM document.
     * Resolved from the login row of `mdm_tag` for a verified e-mail; absent when the e-mail has no login.
     * The monitor test runner (`source: 'test'`) sets it from the sandbox fixture's seeded Person, with
     * `email` '' when that fixture declares no login (a simulated identity, never an invented e-mail).
     */
    export interface PlatformSessionPerson {
        mdmId: string;
        email: string;
        name: string;
    }
    export interface CollabAuthInviteClient {
        createInvite(input: {
            orgId: string;
            email: string;
            apiKey: string;
            moduleId: string;
            actorId: string;
        }): Promise<{
            token: string;
            expiresAt: string;
            teamIds?: string[];
        }>;
    }
    export interface RequestSessionContext {
        /** The Company the session acts for, resolved by the platform for the organization; it is not the signed-in Person. */
        activeCompanyId?: string;
        activeUnitId?: string;
        actorId?: string;
        actorScope?: string[];
        workspaceId?: string;
        /** Set by `execBff` for a `message` request that carries `via: 'nora'`; never from `http`. The workflow advance marks the history with it. */
        via?: 'nora';
        /** Typed projection of the Person: set when `mdm.identity.findByLogin` resolves the verified e-mail, or by the monitor runner from its sandbox fixture. */
        person?: PlatformSessionPerson;
        businessContext: RequestBusinessContext;
        actorSession: RequestActorSession;
        currentWorkspace: RequestCurrentWorkspace;
        project: RequestProjectContext;
    }
    export interface RequestContext {
        data: IDataRuntime;
        mdm: MdmFacade;
        cache: ICacheRuntime;
        /** Test/override seam for collab-auth invites. Production uses COLLAB_AUTH_* env. */
        collabAuthInvite?: CollabAuthInviteClient;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        sessionContext: RequestSessionContext;
        /**
         * Caller module of this BFF (`ordenServicio2`). Absent on platform/test callers.
         * `organization` is the super module: unfiltered MDM reads and writes.
         */
        moduleId?: string;
        /** Installation/org locale — never derived from UI language. */
        organization: RequestOrganizationContext;
        sandbox?: boolean;
        requestMeta?: {
            requestId?: string;
            /**
             * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
             * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
             */
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ControllerRoute {
        key: string;
        handler: BffHandler;
    }
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
        backendControllers?: string;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        languages?: string[];
        designSystems?: string[];
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
        clientShell?: FrontendClientShellConfig;
        /** Same-origin favicon href injected into the served HTML (`<link rel="icon">`). */
        faviconHref?: string;
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentLimits" {
    export const DEFAULT_ATTACHMENT_MAX_BYTES: number;
    export const DEFAULT_ATTACHMENT_ALLOWED_MIME: readonly ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"];
    export interface AttachmentLimits {
        maxBytes: number;
        allowedMime: readonly string[];
    }
    export function defaultAttachmentLimits(): AttachmentLimits;
    export function parseAllowedMime(value: string | undefined): string[];
    export function validateAttachmentPayload(input: {
        mimeType: string;
        sizeBytes: number;
        limits?: AttachmentLimits;
    }): void;
    /** Decode the body of a dedicated upload route. `data:` URLs are stripped; raw base64 is accepted. */
    export function decodeAttachmentBase64(raw: string): Buffer;
}
declare module "_102034_/l1/server/layer_1_external/storage/objectBuckets" {
    /**
     * Object-storage buckets of a published app.
     *
     * One PERMANENT bucket per client project, named with the project id (default `collab-{projectId}`).
     * Business attachments (a pet photo, a signed PDF) live there and nowhere else — a lifecycle rule
     * that expires objects would leave `mdm_attachment` pointing at a dead key.
     *
     * A second, OPTIONAL tmp bucket (default `collab-{projectId}-tmp`) exists for ephemeral artifacts
     * (LLM images that may vanish). MDM attachments never use it. Empty `S3_BUCKET_TMP` disables it.
     *
     * Without AWS credentials, without a resolvable project id, or with `S3_BUCKET` explicitly empty,
     * the runtime falls back to local disk. The reason is always named — never a generic S3 crash.
     */
    export type ObjectBucketKind = 'permanent' | 'tmp';
    export type ObjectStorageProvider = 's3' | 'local';
    export const DEFAULT_PERMANENT_BUCKET_PATTERN = "collab-{projectId}";
    export const DEFAULT_TMP_BUCKET_PATTERN = "collab-{projectId}-tmp";
    export interface ObjectBucketResolution {
        provider: ObjectStorageProvider;
        projectId: string;
        /** Permanent bucket name (S3) or directory leaf (local). Always set. */
        permanent: string;
        /** Tmp bucket name, or null when the operator disabled it. MDM attach never reads this. */
        tmp: string | null;
        /** Why we are on `local`, empty when S3 is ready. */
        localReason: string;
    }
    export interface ObjectBucketEnv {
        s3BucketPattern?: string | null;
        s3BucketTmpPattern?: string | null;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        projectId?: string;
    }
    export function applyProjectId(pattern: string, projectId: string): string;
    export function resolveObjectBuckets(env: ObjectBucketEnv): ObjectBucketResolution;
    export function bucketFor(kind: ObjectBucketKind, resolution: ObjectBucketResolution): string | null;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        /** Minute tick that calls `onTick` of each module. Same gate as write-behind: postgres only. */
        tickEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
        testsEnabled: boolean;
        projectId?: string;
        projectDomain?: string;
        studioEnabled: boolean;
        activeCompanyId?: string;
        activeUnitId?: string;
        currentWorkspaceId?: string;
        actorId?: string;
        actorScope: string[];
        /**
         * Organization country (ISO 3166-1 alpha-2). Installation default `US` (MDM ontology).
         * Not derived from UI language. Platform org config is a pending source.
         */
        organizationCountryCode: string;
        organizationCurrency?: string;
        organizationTimezone?: string;
        /**
         * Permanent object-storage bucket pattern. `{projectId}` is replaced with the client project
         * (default `collab-{projectId}`). Empty string forces local disk.
         */
        s3BucketPattern: string;
        /** Optional tmp bucket pattern (default `collab-{projectId}-tmp`). Empty disables it. MDM never uses it. */
        s3BucketTmpPattern: string;
        attachmentMaxBytes: number;
        attachmentAllowedMime: string[];
        attachmentLocalDir?: string;
        /**
         * Redis connection URL. Present on the VM (`install.sh` installs Redis); absent on lima.
         * Identity cache branches on this capability, never on the host name.
         */
        redisUrl?: string;
        /** TTL of `identity:login:<email>` cache entries. Default 300 s. */
        identityCacheTtlSeconds: number;
    }
    export function ensureEnvFileLoaded(): void;
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
        /** Partial-index predicate, e.g. `"namespace" = 'login'`. */
        where?: string;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
        seedRows?: Array<Record<string, unknown>>;
    }
    export type SeedPurpose = 'initial' | 'test';
    /** Seed rows shipped in a separate file inside the module's tableDefsDir (so generated
     *  table definitions stay untouched). Discovered by shape, like TableDefinition.
     *  `purpose` omitted means test, so existing exports stay valid. */
    export interface TableSeedRows {
        seedFor: string;
        purpose?: SeedPurpose;
        rows: Array<Record<string, unknown>>;
    }
    /** Provenance of one seed export after it is attached to a resolved table. */
    export interface SeedExportOrigin {
        purpose: SeedPurpose;
        source: string;
        projectId: string;
        moduleId: string;
        seedFor: string;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        logicalTableName: string;
        dynamoResolvedTableName: string | null;
        /** Initial-purpose rows only. Absent on tables that received none. Not part of the schema snapshot. */
        initialSeedRows?: Array<Record<string, unknown>>;
        /** Export groups attached to this table, initial and test, with the module that exported each one. */
        seedOrigins?: SeedExportOrigin[];
    }
    /** Column fields the Postgres rebuild materializes. Seed rows are not part of the snapshot. */
    export interface SchemaSnapshotColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
            columns: SchemaSnapshotColumn[];
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    /** A project is namespaced when it owns application (client) tables. Platform tables live in
     *  master-backend / lib projects and stay on their canonical, shared names. */
    export function isClientProjectType(projectType: string | undefined): boolean;
    /** Physical-name prefix for a client project. `mls` keeps the identifier unquoted-safe in Postgres
     *  (a bare `102051_order` would require quoting everywhere), and readable. */
    export function projectTableNamespacePrefix(projectId: string): string;
    /** Lowercased module token used as the physical-name prefix. `listaAssinatura3` → `listaassinatura3_`.
     *  Keep in sync with `moduleTableNamespacePrefix` in mls-102021 (l2 cannot import this file). */
    export function moduleTableNamespacePrefix(moduleId: string): string;
    /** Strip the module prefix CB now emits on `tableName`, so lookup stays `petition_signature`.
     *  Idempotent on older tables that were generated without the prefix. */
    export function logicalTableNameFromEmitted(emittedName: string, moduleId: string): string;
    /** Lookup keys: repositoryName, unprefixed logical name, physical name, and the CB-emitted
     *  (module-prefixed, pre-project) name adapters copy from TableDefinition.tableName. */
    export function matchesTableLookup(definition: Pick<ResolvedTableDefinition, 'repositoryName' | 'logicalTableName' | 'tableName' | 'projectId'>, key: string): boolean;
    /**
     * Namespaces a physical storage name (Postgres table or DynamoDB table) with the owning project when
     * that project owns application tables, so several client projects can share one database/schema on a
     * VM without colliding on generic names (`order`, `daily_shift`, ...). Platform tables (mdm_*, monitor,
     * _schema_migrations) belong to master/lib projects and are left on their canonical names. Idempotent:
     * a name already carrying the prefix is returned unchanged.
     */
    export function applyProjectTableNamespace(physicalName: string, projectId: string, projectType: string | undefined): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102021_/l2/agentMaterializeL1/steps/seedRows25/context" {
    export const SEED_ROWS_TOOL: "writeSeedRows";
    export const SEED_ROWS_TOOL_DESCRIPTION = "Return the seed rows of one reference table as JSON in code, and an empty notApplicable list";
    export interface SeedColumn {
        name: string;
        type: 'string' | 'integer' | 'boolean' | 'timestamp' | 'uuid' | 'enum' | 'object' | 'unknown';
        required: boolean;
        /** True when the l4 marks the field indexed, so persistence promotes it to a column. */
        indexed: boolean;
        enumValues: string[];
        pattern: string;
        maxLength: number | null;
        fields: SeedColumn[];
    }
    export interface SeedTableUnit {
        scenarioId: string;
        tableId: string;
        /** L4 `moduleName`. The stable primary key is `<moduleName>.<tableId>:<unique key>`. */
        moduleName: string;
        entityId: string;
        description: string;
        createText: string;
        fieldsText: string;
        columns: SeedColumn[];
        /**
         * Column names of the table the persistence step emits (`buildLocalTable`). The runtime refuses a seed key that is
         * not one of them, so the gate does too; `details` is the only nested key. Null until the caller resolves the table.
         */
        tableColumns: string[] | null;
        uniqueKeys: string[][];
        states: string[];
        stateField: string;
        /** The l4 sentence of what this table brings in every database. Empty when the entity has no `initialData`. */
        initialData: string;
        /** True when the l4 entity declares `initialData`. A role never does. */
        loadedBySeed: boolean;
        /** Seed-plan constraints (`ref:`, `state:`, `uniqueKeys:`). Empty for an initial table. */
        constraints: string[];
    }
    export interface SeedRepair {
        problems: string[];
        previous: string | null;
    }
    /** The object literal of an l4 ontology file (`= { … } as const`). */
    export function readOntologyLiteral(source: string): Record<string, unknown> | null;
    /**
     * One table whose l4 entity declares `initialData`. Null for a role, or when the sentence is absent:
     * the caller does not call the model. The description text is not read.
     */
    export function referenceSeedUnit(input: {
        scenarioId: string;
        tableId: string;
        ontologySource: string;
        states: readonly string[];
        stateField: string;
        /** Journey and model scenarios have no `initialData`. Initial tables still require it. */
        requireInitial?: boolean;
        constraints?: readonly string[];
    }): SeedTableUnit | null;
    /** The enum column that holds every state of the scenario, when there is exactly one. */
    export function stateFieldFor(columns: readonly SeedColumn[], states: readonly string[]): string;
    /** Default l4 ontology path of an entity of this module. */
    export function seedOntologyRef(project: number, moduleName: string, entityId: string): string;
    export interface SeedScenarioRef {
        scenarioId: string;
        tableId: string;
        entityId: string;
        states: string[];
        stateField: string;
        constraints: string[];
        source: string;
    }
    /** Scenarios of one persistenceSeeds def. A scenario without a table or an entity is dropped. */
    export function seedScenariosOf(data: unknown): SeedScenarioRef[];
    /**
     * One reference-seed table. Null when the l4 entity has no `initialData`:
     * the caller does not call the model.
     */
    export function referenceSeedFromScenario(input: SeedScenarioRef & {
        ontologySource: string | null;
    }): SeedTableUnit | null;
    export function seedRowsHuman(unit: SeedTableUnit, repair?: SeedRepair): string;
    /** Problems of one answer. Empty means the rows can be emitted. */
    export function seedRowProblems(unit: SeedTableUnit, rows: readonly Record<string, unknown>[]): string[];
    /**
     * One row for a seed-plan scenario. No `purpose` (the emitter marks it `test`).
     * The primary key is filled later, from the unique key, the same way as an initial row.
     * Returns the gate problems instead of a row that breaks columns, types, the unique key, states, or a ref constraint.
     */
    export function draftScenarioRow(unit: SeedTableUnit): Promise<{
        row: Record<string, unknown>;
    } | {
        problems: string[];
    }>;
    /** Fixed clock for actor identity rows. The same actor always gets the same timestamps. */
    export const ACTOR_SEED_AT = "2026-07-01T00:00:00.000Z";
    export interface L4Actor {
        actorId: string;
        name: string;
        personEntity: string;
    }
    /** Actors of an l4 access file. An empty list is a module with no actor. */
    export function l4ActorsOf(accessSource: string | null): L4Actor[];
    /** `roleTag` of an l4 role ontology. Empty when the file has none. */
    export function roleTagOf(ontologySource: string | null): string;
    /** UUID derived from `<module>:actor:<actorId>`. Same input, same id. No random. */
    export function stableActorMdmId(moduleName: string, actorId: string): Promise<string>;
    interface MdmColumn {
        name: string;
        nullable: boolean;
        postgresType: string;
    }
    /** Columns of one `repositoryName` in a MDM table-definition source. Empty recognition throws. */
    export function columnsOfRepository(source: string, repositoryName: string): MdmColumn[];
    /**
     * One Person in `mdmEntityIndex` and the same person in `mdmDocumentCache`, per l4 actor.
     * Columns come from the MDM table definition. A field default comes from the MDM ontology.
     * No `purpose`: the runtime counts the row as `test`. A module with no actor returns nothing.
     */
    export function actorMdmSeedRows(input: {
        moduleName: string;
        accessSource: string | null;
        roleSource: (personEntity: string) => Promise<string | null>;
        /** Full table-definition source. Required once the module has actors. */
        tableSource?: string | null;
        /** Ontology source. Required once the module has actors. */
        ontologySource?: string | null;
    }): Promise<{
        seedFor: string;
        rows: Record<string, unknown>[];
    }[]>;
    /** Parse the tool `code` value. Problems are a refusal, not rows. */
    export function parseSeedRowsCode(code: string): {
        rows: Record<string, unknown>[];
    } | {
        problems: string[];
    };
}
declare module "_102021_/l2/agentMaterializeL1/emitters/emitPersistence" {
    import { type M1Definition, type M1Verification } from "_102021_/l2/helpers/l1Defs/definition";
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import { type EmitFailure, type StructureRead } from "_102021_/l2/agentMaterializeL1/emitters/emit";
    const PLAN_FORMAT = "102034-schema-snapshot";
    export interface ColumnBinding {
        field: string;
        column: string;
        nullable: boolean;
        placement: 'column' | 'json';
    }
    export interface PlannedColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface PlannedIndex {
        name: string;
        columns: string[];
        unique: boolean;
    }
    export interface PlannedTable {
        tableName: string;
        primaryKey: string[];
        columns: PlannedColumn[];
        indexes: PlannedIndex[];
    }
    export interface AdditiveStep {
        op: 'createTable' | 'addColumn' | 'createIndex';
        tableName: string;
        name: string;
    }
    export interface BlockedStep {
        op: 'removeTable' | 'removeColumn' | 'removeIndex' | 'alterColumn';
        tableName: string;
        name: string;
        reason: 'DESTRUCTIVE_OUT_OF_SCOPE';
    }
    export interface AdditivePlan {
        format: typeof PLAN_FORMAT;
        applied: false;
        steps: AdditiveStep[];
        blocked: BlockedStep[];
    }
    export interface PhysicalAssert {
        ok: boolean;
        isolated: boolean;
        code: string;
        detail: string;
    }
    export interface PersistenceEmit {
        source: string;
        imports: string[];
        runsStub: boolean;
        seeds: boolean;
        evidences: M1Verification[];
    }
    interface BuiltTable {
        definition: TableDefinition;
        bindings: ColumnBinding[];
        planned: PlannedTable;
    }
    export function additivePlan(desired: readonly PlannedTable[], previous: readonly PlannedTable[] | null): AdditivePlan;
    export function applyPlan(previous: readonly PlannedTable[] | null, plan: AdditivePlan, desired: readonly PlannedTable[]): {
        ok: boolean;
        tables: PlannedTable[];
    };
    export function assertPhysicalSchema(expected: PlannedTable | null, actual: PlannedTable | null): PhysicalAssert;
    export function withoutUniqueChecks(source: string): string;
    /** Rows the reference-seed unit accepted. They are not a key of the def. */
    export interface ReferenceSeedDataset {
        seedFor: string;
        rows: readonly Record<string, unknown>[];
    }
    export function emitPersistence(id: string, definition: M1Definition, output: string, read: StructureRead, moduleDefinitions?: readonly M1Definition[], referenceSeeds?: readonly ReferenceSeedDataset[]): Promise<PersistenceEmit | EmitFailure>;
    export function buildLocalTable(definition: M1Definition, entity: M1Definition): BuiltTable | EmitFailure;
    export interface WakeRegistration {
        projectId: string;
        moduleId: string;
        processId: string;
        routine: string;
        handler: string;
        specifier: string;
    }
    /** Adapter rows of a registration this agent already wrote. Null when the file is not that shape. */
    export function parseRegistrationRows(source: string): Array<{
        portId: string;
        factory: string;
        specifier: string;
    }> | null;
    export function renderRegistration(output: string, rows: readonly {
        portId: string;
        factory: string;
        specifier: string;
    }[], wakes?: readonly WakeRegistration[]): string;
    /** The bindings with each collection of objects bound once, whole, at its path (json), instead of field by field. */
    export function collapseCollections(bindings: readonly ColumnBinding[], collections: ReadonlySet<string>): ColumnBinding[];
}
declare module "_102035_/l2/solution/studioCompile" {
    export interface StudioFileInfo {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    /**
     * Capability, never host: the Studio compile path needs `mls.l2.typescript.compile` and the
     * `mls.editor` surface `getStudioModel` actually calls. Missing either is `unavailable`, not a
     * clean compile. On the `collabmsg` host `mls.l2.typescript` is a getter that stays `undefined`
     * until the Studio extra-libs are loaded — the same answer.
     */
    export function studioCompileAvailable(): boolean;
    interface BorrowedModel {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }
    /** Mark a compile in flight: releases wait until none is. Pair with `leaveStudioCompile` in a `finally`. */
    export function enterStudioCompile(): void;
    export function leaveStudioCompile(): void;
    /**
     * Release models, once no compile is in flight. `deleteModels` only disposes the model and drops the
     * registry entry; it never touches `mls.stor`, so the file stays intact.
     */
    export function releaseBorrowedModels(borrowed: BorrowedModel[]): void;
    /**
     * Queue every model the verify/preload path borrowed since the last call. Returns how many were queued,
     * for the caller's trace — the actual dispose still waits for `activeCompiles === 0`.
     */
    export function releaseBorrowedModelScope(): number;
    /** How many borrowed models are waiting for the next scope release (telemetry/tests). */
    export function borrowedModelScopeSize(): number;
    /**
     * The editor model of a stor file, created on demand. `null` = the file is not in stor (or deleted).
     * A model this call creates is BORROWED (released by `releaseBorrowedModelScope`); one that already
     * existed belongs to a Studio tab and is never disposed.
     */
    export function getStudioModel(project: number, level: number, folder: string, shortName: string, extension: string): Promise<any | null>;
    /**
     * Compile one stor file through the Studio compiler. `null` = there is no model to compile (the file
     * is not in stor): the caller decides what that means, it is never a clean compile here. Throws what
     * the compiler throws. Call only after `studioCompileAvailable()`.
     */
    export function compileStudioFile(file: StudioFileInfo): Promise<{
        errors: string[];
    } | null>;
    /**
     * Load the model of every `/_<project>_/l<level>/….js` import of `root`, transitively, BEFORE `root`
     * is compiled: an unloaded import resolves to `any` and `satisfies <Type>` would silently pass.
     * Imports are read from the MODEL text (what the compiler sees), falling back to stor — a file just
     * created may have no remote content yet. A dependency whose `.d.ts` is not there yet is compiled
     * once. Returns what could not be loaded or read — whoever compiles `root` must not call the result
     * clean while that list is not empty.
     */
    export function preloadStudioImports(root: StudioFileInfo): Promise<string[]>;
    export function formatCompilerDiagnostic(error: unknown): string;
    export function formatUnknownError(error: unknown): string;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Compile" {
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    export interface M12CompileResult {
        path: string;
        errors: string[];
    }
    interface M12Model {
        model?: {
            getValue(): string;
            setValue?(value: string): void;
        };
        compilerResults?: {
            errors?: unknown[];
            prodDTS?: unknown;
            modelNeedCompile?: boolean;
        };
    }
    export interface M12Compiler {
        available(): boolean;
        enter(): void;
        leave(): void;
        read(info: M12FileInfo): Promise<string | null>;
        model(info: M12FileInfo): Promise<M12Model | null>;
        preload(info: M12FileInfo): Promise<string[]>;
        compile(info: M12FileInfo): Promise<{
            errors: string[];
        } | null>;
    }
    /** Editor slot of a stor file: one per extension family, under one key per (project, folder, shortName). */
    export function modelSlotOf(extension: string): 'ts' | 'defs' | 'test' | 'style' | 'html';
    /** Absolute `/…/x.js` and `/…/x.defs.js` specifiers of `source` as stor files. */
    export function importedFiles(source: string): M12FileInfo[];
    /** How long one call to the Studio TypeScript worker may take before the unit fails instead of hanging. */
    export const M12_COMPILE_TIMEOUT_MS = 60000;
    /**
     * A worker failure (e.g. `DataCloneError` inside `ts.worker.js`, measured 05/10/2026 on an l1 file) never settles
     * the main-thread promise: without a deadline the phase hangs forever. With it, the unit fails by name.
     */
    export function withCompileTimeout<T>(what: string, work: Promise<T>, timeoutMs?: number): Promise<T>;
    /**
     * Where a worker diagnostic points, as " (line L, column C: `…the code there…`)". The worker sends `start` as an
     * offset and no source file, so the shared formatter prints no position; the repair prompt then only said
     * "TS1005 ',' expected" for a 77-line request and the model never found the missing brace (agendaClinica, 07/10).
     */
    export function diagnosticLocation(diagnostic: unknown, text: string): string;
    /**
     * How long the first check after the imports are loaded may take. With the platform server and MDM files of a
     * workflow module in the editor, the worker answered its first request after 222s and every later one at once
     * (tarefas, 19/10/2026); with the 60s deadline each request queued behind that first one timed out in turn.
     */
    export const M12_WARMUP_TIMEOUT_MS = 360000;
    /**
     * Prefix of a compile that did not happen: no Studio compiler, or a TypeScript worker that stopped answering.
     * The unit keeps its file and ends `done COMPILE_UNAVAILABLE_L1` with the cause; it is never a clean compile.
     */
    export const L1_UNAVAILABLE = "M12_COMPILE_UNAVAILABLE_L1";
    /**
     * Switch of the Studio compile. With false every generated file is written and marked unproven
     * (COMPILE_UNAVAILABLE_L1, listed in the report's notCompiled). It was off on 19/10 while the controllers phase
     * looked stuck: the worker was not stuck, it took 222s on its first request once the platform files were loaded
     * (see M12_WARMUP_TIMEOUT_MS), and each 60s request behind it timed out in turn.
     */
    export const M12_STUDIO_COMPILE_ENABLED = true;
    export function isUnavailable(error: string): boolean;
    export function workerDown(): string;
    export function markWorkerDown(cause: string): void;
    /**
     * Compiles `files` in order (dependencies first) against the bytes this run wrote: a file whose stor or model
     * text differs from `expected` is a failure, not a compile of someone else's text.
     */
    export function compileM12Files(files: ReadonlyArray<{
        info: M12FileInfo;
        expected: string;
    }>, compiler?: M12Compiler): Promise<M12CompileResult[]>;
    /** Releases the editor models the compile path borrowed (call at the end of a phase). */
    export function releaseCompileModels(): void;
    export function compileDiagnostics(results: readonly M12CompileResult[]): string[];
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Materialize" {
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type EmitFailure } from "_102021_/l2/agentMaterializeL1/emitters/emit";
    import { type ReferenceSeedDataset } from "_102021_/l2/agentMaterializeL1/emitters/emitPersistence";
    import { type M12Layer, type M12RunArgs } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12Compiler } from "_102021_/l2/agentMaterializeL1/helpers/m12Compile";
    import { type M12UnitStatus } from "_102021_/l2/agentMaterializeL1/helpers/m12Io";
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    import { type M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    /** Raised when a recipe or a check of this agent changes: an older status is a new input. */
    export const M12_RECIPE_VERSION = "2026-10-16-m12-recipe-v22";
    export interface M12Context {
        run: M12RunArgs;
        units: readonly M12Unit[];
        appEnv: string;
        read: (ref: string) => Promise<string | null>;
        /** The Studio compiler unless a test injects one. */
        compiler?: M12Compiler;
        /**
         * Rows the reference-seed step accepted. Read only when emitting `persistenceSeeds`.
         * Absent for every other recipe.
         */
        referenceSeeds?: readonly ReferenceSeedDataset[];
    }
    export function createContext(run: M12RunArgs, units: readonly M12Unit[], appEnv: string, compiler?: M12Compiler): M12Context;
    /**
     * Rule (05/10/2026): a type the recipe derives only sometimes always goes to the model. Usecases (rules the
     * recipe cannot bind) and request services (outputs it cannot project) are written by the model, with the
     * recipe's attempt as a draft; every other type is a recipe.
     */
    export const MODEL_TYPES: ReadonlySet<string>;
    export function unitNeedsLlm(unit: M12Unit): boolean;
    /** The copied routing of agentMaterializeL1, kept for the prompt: why the recipe alone may not derive a usecase. */
    export function recipeWouldAskModel(unit: M12Unit): boolean;
    /** What the recipe produces for a model unit: its source as a draft, or the reason it refuses. Writes nothing. */
    export function recipeDraft(ctx: M12Context, unit: M12Unit): Promise<{
        source: string;
    } | {
        refusal: string;
    }>;
    interface Emitted {
        source: string;
        imports: string[];
        seeds: boolean;
        runsStub: boolean;
    }
    export function emitUnit(ctx: M12Context, unit: M12Unit): Promise<Emitted | EmitFailure>;
    /** The l1 defs of the same module a unit depends on (l2 contracts and l4 sources are inputs, not units). */
    export function dependencyUnits(ctx: M12Context, unit: M12Unit): M12Unit[];
    /**
     * Dependencies whose `.ts` is not in the stor. Empty = ready. A receipt does not decide. Only a dependency of the
     * same or an earlier layer is imported when the unit is emitted; a later one (the usecase an outbound event
     * names) is a reference, not an import, and does not block. `.defs.ts` is not the output.
     */
    /**
     * The workflow units a request service waits for: the processes whose operations its routes reach through the
     * usecases they use (§11: the handler of such a route calls the process). Without the workflow file the request
     * cannot import it; it waited for nothing and spent three model calls on a gate it could not pass (tarefas 19/10).
     */
    export function processUnitsOf(units: readonly M12Unit[], unit: M12Unit): M12Unit[];
    export function blockingDependencies(ctx: M12Context, unit: M12Unit): Promise<string[]>;
    /**
     * Everything the unit's output is derived from: the recipe version, its def, every dependency's text and the
     * output hash its dependency units recorded, the contract a controller reads, the rules text of a usecase.
     */
    export function unitInputHash(ctx: M12Context, unit: M12Unit, extra?: readonly string[]): Promise<string>;
    /** rulePlan rows the generated code must name: local rules (storage rows excluded) and RULE_UNBOUND ones. */
    export function rulesToEnforce(definition: M1Definition): string[];
    /** Rules of the def that the generated source does not name: the copied recipe dropped them. */
    export function rulesNotEmitted(definition: M1Definition, source: string): string[];
    export interface M12UnitOutcome {
        status: M12UnitStatus['status'];
        code: string;
        line: string;
    }
    /** A rule the model declared not applicable to this unit, with why (a rule the D1 attached to the wrong unit). */
    export interface M12RuleNotApplicable {
        ruleId: string;
        reason: string;
    }
    /**
     * Write `source` as the unit's output, compile it, check the rules, record the status. On a compile failure
     * the previous bytes come back (or the new file is removed) so a broken file never stays behind.
     */
    export function writeAndProve(ctx: M12Context, unit: M12Unit, source: string, inputHash: string, attempt?: number, notApplicable?: readonly M12RuleNotApplicable[]): Promise<M12UnitOutcome & {
        errors: string[];
    }>;
    /**
     * One deterministic unit, end to end. A usecase the routing sends to the model is not handled here (the
     * caller dispatches a worker). Never throws: an exception is a failed status with its message.
     */
    export function materializeUnit(ctx: M12Context, unit: M12Unit): Promise<M12UnitOutcome>;
    /** The selected units of one layer, dependencies first. */
    export function layerUnits(selected: readonly M12Unit[], layer: M12Layer): M12Unit[];
    export type { M12FileInfo };
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Phase" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12Layer, type M12RunArgs } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12Context } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    export interface M12Loaded {
        ctx: M12Context;
        selected: M12Unit[];
        problems: Array<{
            defRef: string;
            code: string;
            detail: string;
        }>;
    }
    /** The module as this run sees it: every unit (dependencies) and the selected ones. */
    export function loadRun(run: M12RunArgs): Promise<M12Loaded>;
    /** Every selected unit of `layer`, sequentially (one Studio compile at a time). Lines for the trace. */
    export function runDeterministicLayer(run: M12RunArgs, layer: M12Layer): Promise<string[]>;
    /** A phase agent whose whole job is `runDeterministicLayer`: no LLM, completes when the layer is done. */
    export function deterministicPhaseAgent(agentName: string, folder: string, description: string, layer: M12Layer): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/domain10/agentM12Domain" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/persistence20/agentM12Persistence" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Gates" {
    export interface M12CodeGateInput {
        header: string;
        functionName: string;
        project: number;
        moduleName: string;
        ruleIds: readonly string[];
        /** Record paths the l4 marks derived (`details.disponivel`); a usecase calculates them, never reads them. */
        derivedPaths?: readonly string[];
        /** The def's operation (`list`, `create`, …): a list applies every filter its input declares. */
        operation?: string;
        /** Module rules about the state of a parent record of this entity, with the port that reads that parent. */
        parentRules?: readonly M12ParentRule[];
        /** For a transition usecase: its id and the state it leads to, from the l4 lifecycle. */
        transition?: {
            transitionId: string;
            to: string;
        };
        /** The repository ports of the module (`DespesaRepository`); a name outside them is refused. */
        ports?: readonly string[];
    }
    /**
     * A transition usecase that never writes the state it leads to. The repository's `transition(record, id)` stores the
     * record as given (the id is a label), so a usecase that passes the read record unchanged bumps the version and
     * leaves the state where it was (confirmarConsulta kept `scheduled`, agendaClinica 07/10).
     */
    export function transitionTargetProblems(code: string, transition?: {
        transitionId: string;
        to: string;
    }): string[];
    /** A rule whose text names a parent of the usecase entity (`itensSomenteEmComandaAberta` → the Comanda of an item). */
    export interface M12ParentRule {
        ruleId: string;
        /** Parent entity → its repository port (`Comanda` → `ComandaRepository`). */
        parents: ReadonlyArray<{
            entityId: string;
            port: string;
        }>;
    }
    /**
     * A rule about a parent record that the file names but does not enforce: its ruleId is there, the parent is never
     * read. createItemComanda put `ruleId: 'itensSomenteEmComandaAberta'` on a "comanda and item are required" check and
     * never read the comanda, so an item was launched in a closed comanda. Naming the rule obliges reading the parent.
     */
    export function parentRuleProblems(code: string, parentRules: readonly M12ParentRule[]): string[];
    /** Top-level members of the exported `…Input` interface of a usecase file; empty when there is none. */
    export function inputMembers(code: string): string[];
    /**
     * A usecase that reads an input member its own `…Input` interface does not declare. The interface extends
     * `Record<string, unknown>`, so the read compiles and is `undefined` at run time: createComanda declared only
     * `mesaId` (the number is the system's) and then required `input.number`, so no comanda could be opened (07/10).
     * Reads through a name bound to the input (`const raw = input;`) count too.
     */
    export function undeclaredInputProblems(code: string): string[];
    /**
     * A list usecase that declares a filter in its input and never reads it (listItemComanda took `comandaId` and
     * returned the items of every comanda). A member counts as read through `input.<name>`, through a name bound to the
     * input (`const raw: Record<string, unknown> = input; raw.<name>`), or by destructuring one of them.
     */
    export function listFilterProblems(code: string): string[];
    /**
     * A Node built-in reached from the file (`import … from 'node:fs'`, `import('node:fs')`, `require('node:fs')`). Only
     * a module specifier counts: a local named `node` (`let node: unknown`, as the MDM recipe writes) is not an import.
     */
    export function usesNodeBuiltin(code: string): boolean;
    export function importSpecifiers(code: string): string[];
    /** Parameters of the exported usecase function, counted at depth 0 of its parameter list; -1 when not found. */
    export function usecaseParameterCount(code: string, functionName: string): number;
    /** Names a file imports from a repository port of the module (`…/layer_2_application/ports/….js`). */
    export function portImports(code: string): Set<string>;
    /**
     * Repository problems: a repository type declared in the file, or a `resolveRepository<X>` whose X is not imported
     * from a port. Either one hides the entity's field names from the compiler (fecharComanda read `item.quantity`
     * through its own `ItemComandaRepository`; the field is `details.quantidade`).
     */
    export function repositoryProblems(code: string, knownPorts?: readonly string[]): string[];
    /**
     * A version the usecase increments before a write. The repository adapter compares the incoming version with the
     * stored one and increments it itself, so `version: current.version + 1` is always refused with
     * CONCURRENCY_CONFLICT (fecharComanda and cancelarItemComanda did this).
     */
    export function versionProblems(code: string): string[];
    /**
     * A derived field read from a record the usecase got from a repository (`mesa.details.disponivel` after
     * `const mesa = await mesaRepository.get(id)`). The l4 says it is calculated every time; a stored copy is absent or
     * stale (createComanda refused every mesa: createMesa does not store `disponivel`). A value the usecase calculated
     * itself, or the caller's filter (`input.details?.disponivel`), is not a stored record and passes. Only dotted paths
     * are checked: a bare name would match any `input.<name>`.
     */
    export function derivedReadProblems(code: string, derivedPaths: readonly string[]): string[];
    /** Problems of a model-written usecase file. Empty = the gate passes. */
    export function usecaseGate(code: string, input: M12CodeGateInput): string[];
    /** The marker values a generated case may carry (skills/monitorTests.md); the frontend never sees a row value. */
    export const M12_SEED_MARKERS: readonly ["<seedRef>", "<seedValue>"];
    export interface M12TestCase {
        id: string;
        routine: string;
        params: Record<string, unknown>;
        paramFieldRefs?: Record<string, string>;
        expect: {
            ok: boolean;
            errorCode?: string;
            minItems?: number;
            shape?: 'object' | 'array' | 'paginated';
            itemsKey?: string;
        };
        mutating: boolean;
    }
    export interface M12TestsGateInput {
        routes: ReadonlyArray<{
            route: string;
            kind: 'qry' | 'cmd';
            inputFields: readonly string[];
        }>;
        entities: readonly string[];
    }
    /** Problems of the monitor cases a model proposed for one page. Empty = the gate passes. */
    export function testsGate(cases: readonly M12TestCase[], input: M12TestsGateInput): string[];
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12Worker" {
    import { type M12Layer } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    export interface M12WorkerArgs {
        project: number;
        module: string;
        /** Usecase workers: the def shortName. Test workers: the page id. */
        unitId: string;
        attempt: number;
        force: boolean;
        /** Set only by a sequenced worker: `skeleton`, `final`, or `fn:<name>`. Absent on every other layer. */
        phase?: string;
    }
    export function parseM12WorkerArgs(raw: string, currentProject: number): M12WorkerArgs;
    /** A worker that refuses its own args still leaves a trace in the unit status when the unit can be told. */
    export function recordM12ArgsRefusal(raw: string, layer: M12Layer, diagnostic: string): Promise<void>;
    export function workerPlanId(layer: M12Layer, args: M12WorkerArgs): string;
    export function workerTitle(layer: M12Layer, args: M12WorkerArgs): string;
    export function workerStep(agentName: string, layer: M12Layer, args: M12WorkerArgs): mls.msg.AIAgentStep;
    export function canRepair(args: M12WorkerArgs): boolean;
    /**
     * Either the next attempt (added under the phase step BEFORE this worker completes, so the phase stays open)
     * or the final completion with an M12_FAILED trace.
     */
    export function repairOrGiveUp(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, agentName: string, layer: M12Layer, args: M12WorkerArgs, diagnostic: string): mls.msg.AgentIntent[];
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12Layer } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12Context, type M12RuleNotApplicable } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    /** The tool every model unit answers with: the whole file, and the rules it declares not applicable. */
    export const M12_CODE_SCHEMA: Record<string, unknown>;
    export interface M12Repair {
        problems: string[];
        previous: string | null;
    }
    export interface M12SequenceSpec {
        /** Ordered function phases of the unit: ['skeleton', 'fn:a', 'fn:b'] ('final' is never listed: it only repairs). */
        phases(ctx: M12Context, unit: M12Unit): Promise<string[]>;
        /** Extra system text appended to prompt.md for the phase (file read through ctx.read). */
        promptAddendum(ctx: M12Context, phase: string): Promise<string>;
        parameters(phase: string): Record<string, unknown>;
        context(ctx: M12Context, unit: M12Unit, phase: string, assembled: string, repair?: M12Repair): Promise<string>;
        /** Merge the answer into the assembled file. Problems here are repaired in the same phase. */
        apply(ctx: M12Context, unit: M12Unit, phase: string, assembled: string, payload: Record<string, unknown>): Promise<{
            source: string;
            problems: string[];
        }>;
        /** Gate of the whole assembled file, after the last function. */
        finalProblems(ctx: M12Context, unit: M12Unit, source: string): Promise<string[]>;
    }
    export interface M12ModelLayerSpec {
        /** A mechanical fix of the answer before the gate (type annotations and type imports only, never logic). */
        normalize?(ctx: M12Context, unit: M12Unit, code: string): Promise<string>;
        /** When set, the worker grows one file across phases. Layers without it keep a single call. */
        sequence?: M12SequenceSpec;
        layer: Extract<M12Layer, 'usecases' | 'workflows' | 'requests'>;
        /** Module-wide files the layer's units import, written before any worker is dispatched; the trace lines. */
        prepare?(ctx: M12Context, units: readonly M12Unit[]): Promise<string[]>;
        workerAgentName: string;
        folder: string;
        toolName: string;
        toolDescription: string;
        /** The human prompt of one unit (the system prompt is the step's prompt.md). */
        context(ctx: M12Context, unit: M12Unit, repair?: M12Repair): Promise<string>;
        /** Problems of the answer, before anything is written. */
        gate(ctx: M12Context, unit: M12Unit, code: string, notApplicable: readonly M12RuleNotApplicable[]): Promise<string[]>;
    }
    /**
     * Imports of this project must name a file that exists (the l1 compile is not available to catch it): the
     * outputs this run generated and the page contracts. A platform import (102034) is not looked up: the Studio
     * often has no l1 index of a dependency project loaded, and requiring it refused every model answer
     * ("names a file that does not exist") until the repairs ran out, 05/10/2026. The gates already keep platform
     * imports under /_102034_/l1/.
     */
    export function missingImports(ctx: M12Context, code: string): Promise<string[]>;
    /**
     * The answer's not-applicable list. A rule of this unit needs a reason to be waived. A rule the unit does not list
     * (the prompt shows every rule of the module, and the model says which do not concern it) is not a waiver of
     * anything: it is dropped from the list, not refused. Refusing it rejected a correct fecharComanda until the
     * repairs ran out (05/10/2026).
     */
    export function readNotApplicable(value: unknown, ruleIds: readonly string[]): {
        items: M12RuleNotApplicable[];
        problems: string[];
    };
    /** The phase step of a model layer: every selected unit of the layer goes to one worker. */
    export function modelDispatcherAgent(agentName: string, description: string, spec: M12ModelLayerSpec): IAgentAsync;
    /** The worker of a model layer: prompt, gate, write, prove, repair (never fails the task). */
    export function modelWorkerAgent(description: string, spec: M12ModelLayerSpec): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/seedRows25/agentM12SeedRowUnit" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type SeedRepair, type SeedTableUnit } from "_102021_/l2/agentMaterializeL1/steps/seedRows25/context";
    export interface SeedRowsResult {
        tableId: string;
        rows: Record<string, unknown>[];
        /** Model calls. Zero when the l4 does not say the module seed loads the entity. */
        calls: number;
        /** Set when the repair was also refused. The table then has no rows. */
        reason: string | null;
    }
    export type SeedRowsModel = (human: string, repair?: SeedRepair) => string | Promise<string>;
    /** RFC 4122 UUID version 5 (SHA-1). Web Crypto only: this agent runs in the browser. */
    export function uuidV5(name: string): Promise<string>;
    /**
     * Fills the primary key and the initial control version in code.
     * A row whose unique key is missing is refused: no id is invented.
     */
    export function completeInitialRows(unit: SeedTableUnit, rows: readonly Record<string, unknown>[]): Promise<{
        rows: Record<string, unknown>[];
    } | {
        problems: string[];
    }>;
    /** Gate plus one repair. Does not call the model when `loadedBySeed` is false. */
    export function settleReferenceSeed(unit: SeedTableUnit, model: SeedRowsModel): Promise<SeedRowsResult>;
    /** The host worker: one prompt, the gate, and a single repair. A second refusal leaves the table empty. */
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/seedRows25/agentM12SeedRows" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type ReferenceSeedDataset } from "_102021_/l2/agentMaterializeL1/emitters/emitPersistence";
    import { type M12Context } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    import { type SeedTableUnit } from "_102021_/l2/agentMaterializeL1/steps/seedRows25/context";
    export interface SeedWorkerArgs {
        project: number;
        module: string;
        unitId: string;
        attempt: number;
        force: boolean;
        problems?: string[];
        previous?: string;
    }
    /**
     * Column names of the table def of `tableId`, as the persistence step emits it (`buildLocalTable`).
     * A table def, entity def or table shape that is missing throws: the rows are not checked against a guess.
     */
    export function seedTableColumns(units: readonly M12Unit[], tableId: string): string[];
    /** Tables of this module whose l4 entity declares `initialData`. A seed scenario is not required. Others are absent: no model call. */
    export function referenceSeedTables(ctx: M12Context): Promise<SeedTableUnit[]>;
    /**
     * Tables that already have rows: the def's datasets, and the initial rows the
     * reference-seed unit accepted. A scenario for one of these tables reuses that
     * row (same primary key); it does not add a `test` dataset.
     */
    export function takenSeedTables(prior: readonly unknown[], reference: readonly ReferenceSeedDataset[]): Set<string>;
    /**
     * One accepted row per seed-plan scenario (journey or model). No `purpose`:
     * the emitter marks a dataset that is not the initial unit as `test`.
     * A row the gate refuses is left out. Initial drafts are not touched.
     */
    export function scenarioSeedDatasets(ctx: M12Context): Promise<ReferenceSeedDataset[]>;
    /** One draft per table: accepted rows, or an empty table and the reason after the repair. */
    export function writeSeedTableDraft(project: number, moduleName: string, tableId: string, rows: readonly Record<string, unknown>[], reason: string | null): Promise<void>;
    /**
     * Writes `seeds.ts` when every reference-seed table of the step has `rows`
     * (accepted, or empty with a reason). A `{ pending: true }` draft is not ready.
     * The last worker to finish is the one that sees them all. The file goes through
     * `materializeUnit`, so the unit receipt, the production refusal and the compile gate apply.
     * No reference-seed table: emit at once, with the rows the def already carries.
     * Returns whether a file was written.
     */
    export function emitSeedsWhenReady(ctx: M12Context): Promise<boolean>;
    export function seedWorkerStep(args: SeedWorkerArgs): mls.msg.AIAgentStep;
    export function parseSeedWorkerArgs(raw: string, currentProject: number): SeedWorkerArgs;
    /** One model worker per reference-seed table. A module with none completes without a model call. */
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/helpers/m12MdmLinks" {
    import type { M12Context } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    export const M12_MDM_ONTOLOGY_REF = "_102034_/l4/ontology/mdm.defs.ts";
    export interface M12MdmLink {
        type: string;
        from: {
            entityId: string;
            key: string;
        };
        to: {
            entityId: string;
            key: string;
        };
    }
    /** Relationship type → its compact keys, from the platform MDM ontology (`relationships[].compactKeys`). */
    export function mdmCompactKeys(mdmOntologySource: string | null): Map<string, {
        from: string;
        to: string;
    }>;
    /**
     * The module links through an MDM relationship type. In the l4, the relationship that carries `"direction": "to"`
     * is declared on the target end (GestorEquipe.colaboradores of ReportsTo); the one without it on the source end.
     */
    export function mdmLinks(entityOntologies: ReadonlyArray<{
        entityId: string;
        source: string | null;
    }>, mdmOntologySource: string | null): M12MdmLink[];
    /** The prompt section for the MDM links of a module; '' when it has none. */
    export function mdmLinksSection(links: readonly M12MdmLink[]): string;
    /** The MDM links section of the module of a run, read from its l4 ontologies and the platform MDM ontology. */
    export function moduleMdmLinksSection(ctx: M12Context): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/steps/usecases40/context" {
    import { type M12Context, type M12RuleNotApplicable } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12ParentRule } from "_102021_/l2/agentMaterializeL1/helpers/m12Gates";
    import { type M12Repair } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    import type { M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    export const M12_USECASE_TOOL: "writeUsecase";
    export interface M12UsecaseContext {
        unit: M12Unit;
        functionName: string;
        header: string;
        scaffold: string;
        rules: Array<{
            ruleId: string;
            text: string;
        }>;
        human: string;
    }
    /** The export lines of a TypeScript source: what another file may use from it. */
    export function exportSignatures(source: string): string;
    /** The text of each rule id in `l4/<module>/rules.defs.ts` ("ruleId": "text"). */
    export function ruleTexts(source: string | null, ruleIds: readonly string[]): Array<{
        ruleId: string;
        text: string;
    }>;
    /** Every rule id of `l4/<module>/rules.defs.ts` ("ruleId": "text" inside "rules"). */
    export function allRuleIds(source: string | null): string[];
    /**
     * The entities a rule text names, by their l4 title ("item do cardápio" → ItemCardapio). Longer titles are matched
     * first and consume their span, so "item da comanda" does not also count as "comanda".
     */
    export function citedEntities(text: string, titles: ReadonlyArray<{
        entityId: string;
        title: string;
    }>): string[];
    export interface M12EntityNames {
        entityId: string;
        title: string;
        /** Relationship name and title → target entity ("itens" / "Itens lançados" → ItemComanda). */
        relationships: Array<{
            entityId: string;
            title: string;
        }>;
        /** Record paths the l4 marks `derived` (id and version excluded): calculated, never read from storage. */
        derived: string[];
        /** Entities this one points to by its own foreign key (`ItemComanda.comandaId` → Comanda). */
        parents: string[];
    }
    /** The title and relationships of an l4 ontology entity; null when the file is not the expected JSON. */
    export function ontologyNames(entityId: string, source: string | null): M12EntityNames | null;
    /** The names of each entity of the module, read from its l4 ontology. */
    export function entityNames(ctx: M12Context): Promise<M12EntityNames[]>;
    /**
     * The names a rule of `entityId`'s usecase may use for an entity: every entity title, plus the relationships of
     * `entityId` ("o subtotal da comanda … dos itens" names ItemComanda through Comanda's relationship `itens`).
     */
    export function ruleNames(entityId: string, entities: readonly M12EntityNames[]): Array<{
        entityId: string;
        title: string;
    }>;
    /** `data.derivedRead` when it is the on-read summary. Absent or another shape: null, and the context stays as it is. */
    export function derivedReadValue(data: unknown): {
        sources: string[];
        windowField: string;
        groupBy: string[];
        measures: string[];
    } | null;
    /**
     * The model calculates the summary on read from the list usecases of `sources`.
     * The table and the port of the summary itself are not used.
     */
    export function derivedReadSection(derived: {
        sources: readonly string[];
        windowField: string;
        groupBy: readonly string[];
        measures: readonly string[];
    }, sourceLists: ReadonlyArray<{
        entityId: string;
        importPath: string;
        signatures: string;
    }>): string;
    /** `onboarding.companyType` of a project's `l5/config.json` (`<module>.<Entity>`), or empty. */
    export function companyTypeOf(configText: string | null): string;
    /**
     * The session company is `activeCompanyId`, read from l5. Empty when this module does not own the entity
     * named by `companyType`.
     */
    export function sessionCompanyAnchor(moduleName: string, configText: string | null, entityIds: readonly string[]): string;
    export function loadUsecaseContext(ctx: M12Context, unit: M12Unit, repair?: M12Repair): Promise<M12UsecaseContext>;
    /** For a transition usecase, its id and target state from the l4 lifecycle (`transitions[].to`); null otherwise. */
    export function transitionOf(ctx: M12Context, unit: M12Unit): Promise<{
        transitionId: string;
        to: string;
    } | undefined>;
    /** The `to` of a transition in an l4 ontology source. */
    export function transitionTarget(source: string | null, transitionId: string): {
        transitionId: string;
        to: string;
    } | undefined;
    /** Module rules whose text names a parent of this usecase's entity, each with the port that reads that parent. */
    export function parentRulesOf(ctx: M12Context, unit: M12Unit, entities: readonly M12EntityNames[]): Promise<M12ParentRule[]>;
    export const MDM_ONTOLOGY_REF = "_102034_/l4/ontology/mdm.defs.ts";
    export const MDM_FACADE_REF = "_102034_/l1/mdm/layer_3_usecases/mdmFacade.ts";
    export const MDM_MODULE_REF = "_102034_/l1/mdm/module.ts";
    /** A usecase of an entity kept in the platform MDM: its def has `mdm` (§10), depends on the MDM ontology or calls `ctx.mdm`. */
    export function usesMdm(unit: M12Unit): boolean;
    /** The `subtype` an l4 entity ontology declares (`"subtype": "Person"`), or '' when it declares none. */
    export function entitySubtype(source: string | null): string;
    /**
     * The platform MDM APIs a module must call instead of inventing them. Named types come from the ontology
     * `"of"` and their interfaces from the module exports. Functions and methods come from the facade text.
     * Same text inside `mdmContextSection` and, when a request contract names an MDM entity a usecase already
     * owns, on its own.
     */
    export function mdmPlatformApiSection(ontologySource: string | null, facadeSource?: string | null, moduleSource?: string | null): string;
    /**
     * How the platform MDM stores and returns an entity today, for a usecase of an MDM entity. The ontology of the
     * module groups the fields (`details.identification.name`); the engine is FLAT (`details.name`), which the MDM
     * ontology states in knownDivergences.grouped-document. Without this the model guessed the groups and every read
     * of a patient failed (agendaClinica, 07/10). Verified against mdmFacade.ts and the in-memory engine.
     */
    export function mdmContextSection(moduleName: string, ontologySource: string | null, facadeSource: string | null, platformRuleIds?: readonly string[], moduleSource?: string | null, subtype?: string): string;
    export const M12_USECASE_TOOL_DESCRIPTION = "Return the whole usecase TypeScript file, and the listed rules that do not apply to it";
    /** The usecase gate over the answer: shape, imports, and every listed rule enforced or declared not applicable. */
    export function usecaseAnswerProblems(ctx: M12Context, unit: M12Unit, code: string, notApplicable: readonly M12RuleNotApplicable[]): Promise<string[]>;
    /** Actor ids of an authorityMap source (`"actorRef": "companyOwner"`). */
    export function authorityActorIds(source: string): string[];
    /** Prompt text: a rule check may name only these actor ids. */
    export function authorityActorsText(actorIds: readonly string[]): string;
}
declare module "_102021_/l2/agentMaterializeL1/steps/usecases40/agentM12UsecaseUnit" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12ModelLayerSpec } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    export const USECASE_SPEC: M12ModelLayerSpec;
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/usecases40/agentM12Usecases" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Every usecase goes to one model worker (a type the recipe derives only sometimes always goes to the model). */
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/workflowEmit" {
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    /** The module engine over a supplied Task port, the plan of each process, and the destination status of each operation. */
    export function workflowEngineFile(project: number, moduleName: string): M12FileInfo;
    export interface WorkflowStepEmit {
        stepId: string;
        kind: string;
        title: string;
        actorRef?: string;
        journeyRef?: string;
        next: string[];
        /** Page address and the URL param that opens the record, for a human step whose page resolved. */
        params?: {
            page: string;
            recordParam: string;
        };
        /** `wake.mode` of a wait step. Not copied into the plan. */
        wakeMode?: string;
    }
    export interface WorkflowTableEmit {
        processId: string;
        title: string;
        moduleTitle: string;
        /** Entity of the occurrence record: the first `entityRef` reached from the start step. */
        recordEntity?: string;
        steps: WorkflowStepEmit[];
    }
    /** The module tick, next to the module's composition root (the persistence folder the runtime already loads). */
    export function moduleTickFile(project: number, moduleName: string): M12FileInfo;
    export function workflowFile(project: number, moduleName: string, processId: string): M12FileInfo;
    export function moduleSpecifier(info: M12FileInfo): string;
    /** Step tables copied from `processes[].tasks[]` of an l4 workflows source. `taskId` becomes `stepId`. */
    export function workflowTablesFromL4(source: string | null): WorkflowTableEmit[];
    /**
     * Destination status (`to`) of each transition in the ontology sources.
     * `only` limits the copy to the transition ids of the process operations.
     */
    export function transitionDestinations(sources: readonly (string | null)[], only?: ReadonlySet<string>): Record<string, string>;
    /**
     * The module engine receives the Task port from whoever constructs it (`createModuleWorkflowEngine(port)`).
     * Plans of every process go on `open`. Advance does not take a table.
     */
    export function workflowEngineSource(project: number, moduleName: string, tables: readonly WorkflowTableEmit[], targets: Readonly<Record<string, string>>): string;
    /**
     * The module tick: the minute the platform lends (`moduleTick.ts` of 102034) runs every scheduled process of the
     * module, each through the `onTick` its workflow file exports. A failing process is logged and the others still run.
     */
    export interface TickRecovery {
        processId: string;
        fn: string;
    }
    export function moduleTickSource(project: number, moduleName: string, processIds: readonly string[], recoveries?: readonly TickRecovery[]): string;
    export function tickRecoveries(tables: readonly WorkflowTableEmit[]): TickRecovery[];
    export interface HumanPageSource {
        pageId: string;
        source: string;
    }
    /**
     * Page address of each human step. The record is the first `entityRef` reached from the start step.
     * The page is the first, by `pageId`, whose journey starts with `<journeyRef>/` and whose URL param
     * is `<lowerCamel(entity)>Id`. No entity, no page, or no route: the step stays without `params`.
     */
    export function bindHumanPages(tables: readonly WorkflowTableEmit[], pages: readonly HumanPageSource[], configText: string | null, moduleName: string): {
        tables: WorkflowTableEmit[];
        unresolved: string[];
    };
}
declare module "_102021_/l2/agentMaterializeL1/steps/workflows45/sequence" {
    export const WORKFLOW_NOT_IMPLEMENTED = "NOT_IMPLEMENTED";
    export function notImplementedStub(name: string): string;
    /** Exported functions whose body is only {@link notImplementedStub}. */
    export function notImplementedFunctions(source: string): string[];
    /**
     * Function order of one process: functions no step names, in `facts.functions` order;
     * then the ones steps name, in step order, once each; then `fixedExports` not already listed.
     * `onTick` arrives in `fixedExports` from the caller. A step names its function with `functionRef`
     * (the L4 link). `WorkflowStepEmit` has no such field; this argument does not invent one there.
     */
    export function workflowPhaseOrder(facts: {
        functions: string[];
        trigger: {
            kind: string;
        };
    }, steps: readonly {
        stepId: string;
        functionRef?: string;
    }[], fixedExports: readonly string[]): string[];
    export function findFunction(source: string, name: string): {
        start: number;
        end: number;
    } | null;
    export function replaceFunction(source: string, name: string, functionText: string): string;
    /** Comment immediately above plus the header, closed as ` { … }` with no body. */
    export function functionSignature(source: string, name: string): string;
    export function signaturesOnly(source: string, names: readonly string[]): string;
    /** Appends `import ` lines that are not already present, next to the existing imports. */
    export function mergeImports(source: string, lines: readonly string[]): string;
    /** Inserts helpers before the first exported function (after the imports). `''` returns `source`. */
    export function addHelpers(source: string, helpers: string): string;
    /** Names in `written` that appear as identifiers in `prose`, in `names` order. */
    export function calledFunctions(prose: string, names: readonly string[], written: ReadonlySet<string>): string[];
}
declare module "_102021_/l2/agentMaterializeL1/steps/workflows45/context" {
    import { type WorkflowStepEmit } from "_102021_/l2/agentMaterializeL1/emitters/workflowEmit";
    import { type M12Context, type M12RuleNotApplicable } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12Repair, type M12SequenceSpec } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    import type { M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    export const M12_WORKFLOW_TOOL: "writeWorkflowService";
    export const M12_WORKFLOW_TOOL_DESCRIPTION = "Return the whole workflow service TypeScript file of the process";
    export const EVALUATE_SCHEDULE_REF = "_102034_/l1/server/layer_2_application/schedule/evaluateSchedule.ts";
    /** Public surface of the runtime engine (`/_102034_/l1/workflow/index.js`). */
    export const WORKFLOW_INDEX_REF = "_102034_/l1/workflow/index.ts";
    /** Call shapes `index.ts` re-exports: open, advance, find, the table and the key. */
    export const WORKFLOW_ENGINE_REF = "_102034_/l1/workflow/engine.ts";
    export const WORKFLOW_CONTRACTS_REF = "_102034_/l1/workflow/contracts.ts";
    /** `occurrenceRecordId` and `createOccurrenceContext` (the first `newId` is the record). */
    export const WORKFLOW_RECORD_ID_REF = "_102034_/l1/workflow/occurrenceRecordId.ts";
    /** Platform access-request read API. The screen resolves; this module only reads. */
    export const REGISTRATION_REF = "_102034_/l1/mdm/registration.ts";
    /** Worker view of the module engine: export signatures, with the whole `transitionTo` (its keys) in place of the collapsed line. */
    export function workflowEngineShown(source: string): string;
    /** `onboarding.moduleId` of a project's `l5/config.json`, or empty when the file has none. */
    export function onboardingModuleId(configText: string | null): string;
    /**
     * Export surface of `registration.ts`, read from the source. A union type and a function head span lines;
     * `exportSignatures` stops at the first line, which drops `person.mdmId` and `(ctx, { requestId })`.
     */
    export function registrationSignatures(source: string): string;
    /**
     * The registration read API, only for the onboarding module. The signature is read from `registration.ts`
     * (never a hand copy). Other modules get an empty string.
     */
    export function registrationAccessSection(moduleName: string, configText: string | null, registrationSource: string | null): string;
    /**
     * Rules every process function follows when it calls the module engine. The engine does the owner action;
     * the function supplies the command and applies the L4 system transition from the returned notice state only.
     */
    export function engineUseRules(moduleName: string, processId: string): string;
    /** Steps of one l4 process object (the JSON `l4Process` returns). */
    export function workflowProcessSteps(processJson: string): WorkflowStepEmit[];
    /**
     * Names the process file exports when it has an `llm` step: one wake handler per `llm` step and per periodic
     * `wait`, plus the tick recovery of the process. Empty when the process has no `llm` step.
     */
    export function workflowLlmExportNames(processId: string, steps: readonly WorkflowStepEmit[]): string[];
    /** `export type Name = …;` through the semicolon that closes it. '' when the file does not declare the alias. */
    export function typeAlias(source: string, name: string): string;
    /** Stor ref of the file the workflow index re-exports `name` from. '' when the index declares it itself. */
    export function reexportRef(indexSource: string, name: string): string;
    /**
     * What the model needs to write an `llm` step. Empty when the process has none.
     * Signatures come from the platform files the index re-exports; the import the file writes is the index.
     * `wakeSignature` is the `WorkflowWakeHandler` alias read from the index (or from the file it re-exports).
     */
    export function llmStepSection(processId: string, steps: readonly WorkflowStepEmit[], sources: readonly (string | null)[], wakeSignature?: string): string;
    /**
     * An entity the process only names (not its occurrence, not an operation target) needs its states and transitions
     * (the model guessed them without), not its fields: the generated entity file above already carries those.
     * Anything that does not parse as the ontology object stays whole.
     */
    export function citedOntology(source: string): string;
    /** The facts of a workflowProcess def the context and the gate read. */
    export interface M12WorkflowFacts {
        processId: string;
        trigger: {
            kind: string;
            actorRef: string;
            event: string;
            schedule: string;
        };
        occurrence: string;
        functions: string[];
        operations: Array<{
            operation: string;
            steps: string[];
        }>;
    }
    export function workflowFacts(unit: M12Unit): M12WorkflowFacts;
    /** The process `processId` of an l4 workflows source, as JSON text; '' when it is not there. */
    export function l4Process(source: string | null, processId: string): string;
    /** The usecase that runs one operation (`Entidade.<op>` or `Entidade.<transição>`), among the units of the module. */
    export function operationUsecase(units: readonly M12Unit[], operation: string): M12Unit | undefined;
    /**
     * The module engine (the engine on the cm Task port, the plan of each process, the destination status of each operation),
     * written and compiled before any workflow worker runs. An engine.ts that is already there stays; delete it to regenerate.
     * The lines go to the phase trace.
     */
    export function prepareWorkflows(ctx: M12Context): Promise<string[]>;
    /** One step of the l4 process, with `functionRef` when the task names the function it runs. `WorkflowStepEmit` does not keep that field. */
    export function workflowStepFunctionRefs(processJson: string): Array<{
        stepId: string;
        functionRef?: string;
    }>;
    export function loadWorkflowContext(ctx: M12Context, unit: M12Unit, repair?: M12Repair, focus?: string): Promise<{
        header: string;
        facts: M12WorkflowFacts;
        human: string;
    }>;
    /** Transition id → the state it leads to, from the lifecycle of every entity of the module. */
    export function transitionTargets(units: readonly M12Unit[]): Map<string, string>;
    /** The top-level arguments of every `.transition(…)` call: read by brackets and quotes, never by a fixed shape. */
    export function transitionCalls(code: string): Array<{
        record: string;
        transitionId: string;
    }>;
    /**
     * A port `transition(record, '<id>')` whose record never takes the state the transition leads to. The adapter stores
     * the record as given (the id is a label): the daily notice called concluirAviso and stayed `pending` (tarefas, 16/10),
     * first with a variable, then with the object built inside the call. The state must be written on a field
     * (`status: '<to>'`): inside the object when the call builds it, anywhere in the file when it passes a variable. A bare
     * `return '<to>'` is not a write. The states come from the module lifecycles: nothing here names one.
     */
    export function workflowTransitionProblems(code: string, targets: ReadonlyMap<string, string>): string[];
    /** Problems of a model-written workflow service. Empty = the gate passes. */
    export function workflowGate(code: string, input: {
        header: string;
        facts: M12WorkflowFacts;
        project: number;
        moduleName: string;
        ports: readonly string[];
        targets?: ReadonlyMap<string, string>;
        llmExports?: readonly string[];
    }): string[];
    export function workflowAnswerProblems(ctx: M12Context, unit: M12Unit, code: string, _notApplicable: readonly M12RuleNotApplicable[]): Promise<string[]>;
    export const workflowSequence: M12SequenceSpec;
}
declare module "_102021_/l2/agentMaterializeL1/steps/workflows45/agentM12WorkflowUnit" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12ModelLayerSpec } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    export const WORKFLOW_SPEC: M12ModelLayerSpec;
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/workflows45/agentM12Workflows" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** The Task adapter of the module first, then one model worker per process (materializadorL1.md §11). */
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/tests60/context" {
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    import type { M12Context } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import type { M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    export const M12_TESTS_TOOL: "proposeMonitorCases";
    export const M12_TESTS_SCHEMA: Record<string, unknown>;
    export interface M12ContractRoute {
        route: string;
        kind: 'qry' | 'cmd';
        /** Top-level input member names (`details` for `details: { … }`), the `.required` vocabulary. */
        inputFields: string[];
        actors: string[];
        rules: string[];
    }
    /** The routes of a v2 page contract, read from its text (`'<route>': { kind; input; output; rules; access }`). */
    export function contractRoutes(source: string, moduleName: string, pageId: string): M12ContractRoute[];
    export interface M12TestsContext {
        pageId: string;
        contract: M12FileInfo;
        routes: M12ContractRoute[];
        actor: string;
        entities: string[];
        human: string;
        /** Every input this page's cases are derived from (hashed by the caller). */
        inputs: string[];
    }
    /** `ruleId → code` pairs a materialized request throws as `new AppError('<CODE>', …, { ruleId })`. */
    export function thrownErrorCodes(source: string): Array<{
        ruleId: string;
        code: string;
    }>;
    /** The page of a controller unit and everything its cases are read from. */
    export function loadTestsContext(ctx: M12Context, controller: M12Unit, repair?: {
        problems: string[];
        previous: string | null;
    }): Promise<M12TestsContext>;
}
declare module "_102021_/l2/agentMaterializeL1/steps/requests50/context" {
    import { type M12Context, type M12RuleNotApplicable } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    import { type M12Repair } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    import type { M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    import { type M12ContractRoute } from "_102021_/l2/agentMaterializeL1/steps/tests60/context";
    export const M12_REQUEST_TOOL: "writeRequestService";
    export const M12_REQUEST_TOOL_DESCRIPTION = "Return the whole request service TypeScript file of the page, and the listed rules that do not apply to it";
    export interface M12RequestContext {
        pageId: string;
        /** `export interface <Page>Contracts` of the page contract: the type `requests` is checked against. */
        contractsInterface: string;
        /** The import specifier of the page contract (`/_P_/l2/<mod>/web/contracts/<page>.defs.js`). */
        contractSpecifier: string;
        header: string;
        routes: M12ContractRoute[];
        contractRef: string;
        /** Routes whose input carries an MDM entity no usecase owns: the request writes it through `ctx.mdm`. */
        mdmInputs: M12MdmInput[];
        /** Routes that reach an operation of a workflow process: they call its service (§11). */
        workflowRoutes: M12WorkflowRoute[];
        human: string;
    }
    /** An entity of the module kept in the platform MDM that no usecase reads or writes. */
    export interface M12UnownedMdmEntity {
        entityId: string;
        /** Its member name in a contract (`participante` for Participante). */
        key: string;
        /** The own-scope grants anchored on it (the record of the logged person), and the field the scope writes. */
        anchor: {
            grantIds: string[];
            recordField: string;
        } | null;
    }
    export interface M12MdmInput {
        route: string;
        entityId: string;
        key: string;
    }
    /** MDM entities of the module (`storageTarget: "mdm"`), owned or not. The source `unownedMdmEntities` filters. */
    export function moduleMdmEntities(units: readonly M12Unit[]): Array<{
        entityId: string;
        key: string;
    }>;
    /**
     * Platform MDM APIs for a request whose def calls a usecase of an MDM entity. Empty when it calls none, and empty
     * when an unowned MDM entity is named in the contract: that path already includes `mdmContextSection`, which
     * carries the same lines. `request` is the request-service definition (`data` + `dependencies`); without it the
     * callers that still pass only the contract keep the previous filter.
     */
    export function mdmPlatformSectionForRequest(contractText: string, units: readonly M12Unit[], ontologySource: string | null, facadeSource?: string | null, moduleSource?: string | null, request?: {
        data?: Record<string, unknown>;
        dependencies?: readonly string[];
    } | null): string;
    /**
     * The MDM entities of the module no usecase owns. inscricaoEvento (15/10): the D1 gave Participante no usecase, the
     * request prompt carried no MDM API, and `inscreverEmEvento` had nothing to write the participant with. Read from
     * the defs only: an entity with `storageTarget: "mdm"` and no usecase whose `entityId` is it.
     */
    export function unownedMdmEntities(units: readonly M12Unit[]): M12UnownedMdmEntity[];
    /** The prompt section for the unowned MDM entities a contract names; '' when it names none. */
    export function unownedMdmSection(moduleName: string, entities: readonly M12UnownedMdmEntity[]): string;
    /** The grant ids a contract route lists in its `access`. */
    export function routeGrantIds(contractText: string, route: string): string[];
    /**
     * Who may call each route and what they may see (materializadorL1.md §9 and the own scope per entity). The controller
     * lets in a caller who holds ONE grant of the route; this service decides, by the grants the caller holds, which
     * records belong to them and which fields go back. '' when no route has a grant.
     */
    export function accessSection(routes: readonly M12ContractRoute[], contractText: string, grants: readonly Record<string, unknown>[]): string;
    export interface M12WorkflowRoute {
        route: string;
        processId: string;
        operation: string;
        /** The import specifier of the workflow service of the process. */
        specifier: string;
    }
    /**
     * The routes of a page whose usecase is an operation of a workflow process (materializadorL1.md §11): the handler of
     * such a route calls the function of the process, which reuses the usecase. The operation of a usecase is
     * `Entidade.<operation>`, or `Entidade.<transitionRef>` for a transition, as the process def lists it.
     */
    export function workflowRoutes(units: readonly M12Unit[], requestDef: Record<string, unknown>, project: number, moduleName: string): M12WorkflowRoute[];
    /** A page whose routes reach a process and a file that never imports its workflow service. */
    export function workflowRouteProblems(code: string, routes: readonly M12WorkflowRoute[]): string[];
    /** The routes of a contract whose input carries one of the unowned MDM entities. */
    export function mdmInputRoutes(routes: readonly M12ContractRoute[], entities: readonly M12UnownedMdmEntity[]): M12MdmInput[];
    /** A route that receives an unowned MDM entity and a file that never writes the MDM. */
    export function mdmInputProblems(code: string, inputs: readonly M12MdmInput[]): string[];
    export function loadRequestContext(ctx: M12Context, unit: M12Unit, repair?: M12Repair): Promise<M12RequestContext>;
    /**
     * A request that throws away the contract input type: a parameter `input: Record<string, unknown>` (a helper or a
     * route), or the input — or a name taken from it — cast to `Record<…>`. registrarAtendimento did
     * `const rawDetails = input.details; (rawDetails as Record<string, unknown>).attendanceNote` and read a path the
     * contract does not have (`details.details.attendanceNote`); with the contract type the compiler refuses it.
     */
    export function untypedInputProblems(code: string): string[];
    /** Problems of a model-written request service. Empty = the gate passes. */
    export function requestGate(code: string, input: {
        header: string;
        /** The page `…Contracts` interface; '' skips the typing check (unit tests of other rules). */
        contractsInterface?: string;
        routes: readonly M12ContractRoute[];
        project: number;
        moduleName: string;
        pageId: string;
        waived: ReadonlySet<string>;
    }): string[];
    /**
     * A route rule the request names only in a comment that hands it to a usecase ("createItemComanda enforces
     * itensSomenteEmComandaAberta"). The handoff holds only when that usecase carries the ruleId in its code; the usecase
     * gate then makes it read the record the rule is about. On 06/10 neither side checked the comanda of a launched item.
     */
    export function delegatedRuleProblems(code: string, ruleIds: readonly string[], readUsecase: (name: string) => Promise<string | null>): Promise<string[]>;
    export function requestAnswerProblems(ctx: M12Context, unit: M12Unit, code: string, notApplicable: readonly M12RuleNotApplicable[]): Promise<string[]>;
    /**
     * The type `requests` has: one function per contract route, taking exactly that route's input and returning exactly
     * its output. The input was `Record<string, unknown>` until 07/10: registrarAtendimento read
     * `details.attendanceNote` where the contract sends `details.details.attendanceNote`, and nothing caught it.
     */
    export function requestsTypeOf(contractsInterface: string): string;
    /**
     * The annotation of `requests` is set mechanically to the contract-mapped type (a model kept typing it with the
     * bare `…Contracts` interface, or with `Record<…unknown>`, which hid the output shape from the compiler), and the
     * two type imports it needs are added when missing. Nothing else in the file changes; the compiler proves the
     * result, and a function whose output differs from the contract is a compile error the repair receives.
     */
    export function normalizeRequestsTyping(code: string, contractsInterface: string, contractSpecifier: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/steps/requests50/agentM12RequestService" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12ModelLayerSpec } from "_102021_/l2/agentMaterializeL1/helpers/m12ModelUnits";
    export const REQUEST_SPEC: M12ModelLayerSpec;
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/requests50/agentM12Requests" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Every request service goes to one model worker (a type the recipe derives only sometimes always goes to the model). */
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/controllers30/agentM12Controllers" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/steps/tests60/agentM12Tests" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    /** The input hash of a page's cases: the recipe, everything the prompt reads, and the controller output. */
    export function testsInputHash(inputs: readonly string[], controllerOutputs: Record<string, string>): Promise<string>;
    /**
     * Switch of the phase. Off (false), it dispatches no agentM12TestsPage worker and makes no model request; the unit
     * statuses and the case files of earlier runs stay as they are. Turned off on 09/10 for a measurement, back on.
     */
    export const M12_TESTS_ENABLED = true;
}
declare module "_102021_/l2/agentMaterializeL1/steps/tests60/render" {
    import type { M12TestCase } from "_102021_/l2/agentMaterializeL1/helpers/m12Gates";
    import { type M12FileInfo } from "_102021_/l2/agentMaterializeL1/helpers/m12Names";
    /** Keeps only the keys the monitor reads, in a stable order. Throws on a shape the gate cannot read. */
    export function normalizeTestCases(value: unknown): M12TestCase[];
    /**
     * Read cases first (the monitor runs every read of every file before the rest, in declaration order); inside
     * the rest, declaration order is kept, so a create -> update -> read-back sequence stays as proposed.
     */
    export function orderCases(cases: readonly M12TestCase[]): M12TestCase[];
    export function renderPageTests(input: {
        file: M12FileInfo;
        moduleName: string;
        pageId: string;
        actor: string;
        cases: readonly M12TestCase[];
    }): string;
}
declare module "_102021_/l2/agentMaterializeL1/steps/tests60/agentM12TestsPage" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/busy" {
    export function lockHolder(text: string | null): string;
    /** Refusal text of a held writer or lock: which file, which holder, what to remove when no run is active. */
    export function busyDetail(ref: string, text: string | null): string;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/reconcileL5" {
    /** Role comes from the promoted def's artifactType. Paths are not a classification. */
    export type L5PromotedRole = 'httpController' | 'table' | 'repositoryRegistration' | 'output';
    export interface L5FileFact {
        ref: string;
        source: string | null;
        role: L5PromotedRole;
    }
    export function roleFromArtifactType(artifactType: string): L5PromotedRole;
    /**
     * Files the reconciler may see: promoted outputs (def path → output path) plus the
     * same-module imports those controllers name. No directory convention and no glob.
     */
    export function loadRegistrationFiles(project: number, moduleName: string, units: readonly {
        defPath: string;
        artifactType: string;
    }[], read: (ref: string) => Promise<string | null>): Promise<L5FileFact[]>;
    /** Fields both L5 readers use. `agentFolder` is required only when this publication fills a missing signature. */
    export interface L5BackendSignature {
        masterProject: number;
        runtimeProject: number;
        agentFolder?: string;
    }
    export interface ReconcileL5Input {
        project: number;
        moduleName: string;
        /** development and presentation may register a structure stub. Production must not. */
        allowStructureStub: boolean;
        phase: 'structure' | 'verified';
        projectJson: string | null;
        /**
         * Absent or omitted: the composer falls back to project.json. A string is an existing file.
         * This function never creates that second file.
         */
        runtimeProjectJson?: string | null;
        /**
         * Copied only when masters.backend is absent and the value already satisfies both readers.
         * This module does not invent agentChangeBackend.
         */
        backendSignature?: L5BackendSignature | null;
        files: readonly L5FileFact[];
        catalogRef: string | null;
        /**
         * False when the module defs have no table unit. Omitted keeps the table requirement
         * (a module that declares tables and has no folder stays LOCAL_TABLE_ABSENT).
         */
        localTables?: boolean;
    }
    export interface L5Pending {
        origin: string;
        reason: string;
    }
    export interface L5ReconcileResult {
        action: 'patch' | 'unchanged' | 'pending' | 'invalid';
        /** Null when the caller must keep the previous bytes (absent or unreadable). */
        nextText: string | null;
        /** File the composer reads. A patch applies only to this file. */
        effectiveSource: 'l5/project.json' | 'l5/runtime.project.json';
        backend: Record<string, unknown> | null;
        pendings: L5Pending[];
        detail: string;
    }
    /** Marker on a runtime.project.json snapshot this publication already owns. Not written onto a new file. */
    export const L5_PUBLICATION_OWNER = "agentMaterializeL1";
    export interface L5CommitIo {
        claim(project: number, holder: string): Promise<boolean>;
        release(project: number, holder: string): Promise<void>;
        read(ref: string): Promise<string | null>;
        /** Writes only when the current bytes still equal `expected`. `expected` null means the file is absent. */
        compareAndSwap(ref: string, expected: string | null, next: string): Promise<'ok' | 'conflict'>;
    }
    export function projectJsonRef(project: number): string;
    export function runtimeProjectJsonRef(project: number): string;
    export function projectLockRef(project: number): string;
    /**
     * Lock the project, reread both L5 documents, merge, and compare-and-swap the file the composer
     * reads. A second conflict leaves the bytes another writer stored. Does not regenerate sources.
     */
    export function commitL5Registration(input: Omit<ReconcileL5Input, 'projectJson' | 'runtimeProjectJson'>, io: L5CommitIo, holder: string): Promise<L5ReconcileResult>;
    export function reconcileL5Backend(input: ReconcileL5Input): L5ReconcileResult;
}
declare module "_102021_/l2/agentMaterializeL1/steps/register70/agentM12Register" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12RunArgs } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import type { M12Context } from "_102021_/l2/agentMaterializeL1/helpers/m12Materialize";
    export function createAgent(): IAgentAsync;
    /**
     * The module tick (§11): the scheduled processes whose workflow service is in place run on the minute the platform
     * lends, through `moduleTick.ts` in the persistence folder (next to the composition root the runtime already loads).
     * '' when the module has no scheduled process.
     */
    export function writeModuleTick(ctx: M12Context, run: M12RunArgs): Promise<string>;
    /** Wake handlers on the registration the persistence step already wrote. A file that already lists them stays, unless force. */
    export function writeWakeRegistration(ctx: M12Context, run: M12RunArgs): Promise<string>;
}
declare module "_102020_/l2/helpers/assistantCatalog/asTypes" {
    export type AsTypeNode = {
        kind: 'primitive';
        name: 'string' | 'number' | 'boolean' | 'unknown';
    } | {
        kind: 'literal';
        values: string[];
    } | {
        kind: 'object';
        fields: AsTypeField[];
    } | {
        kind: 'array';
        of: AsTypeNode;
    } | {
        kind: 'tuple';
        items: AsTypeNode[];
    } | {
        kind: 'ref';
        name: string;
    };
    export interface AsTypeField {
        name: string;
        optional: boolean;
        type: AsTypeNode;
    }
    export interface AsContractRoute {
        route: string;
        kind: string;
        writes: string;
        input: AsTypeNode;
    }
    export interface AsEnumValue {
        value: string;
        label: string;
    }
    export type AsInputRole = 'value' | 'ref' | 'version';
    export interface AsInputField {
        path: string;
        label: string;
        description: string;
        wireType: 'string' | 'number' | 'boolean' | 'unknown';
        valueType: string;
        enumValues: AsEnumValue[];
        required: boolean;
        role: AsInputRole;
        ref: string;
    }
    export interface AsCommand {
        route: string;
        module: string;
        kind: 'cmd' | 'qry';
        purpose: string;
        writes: string;
        entity: string;
        inputs: AsInputField[];
        pageParam: string;
        pageSizeParam: string;
    }
    export interface AsRelated {
        path: string;
        entity: string;
        fields: string[];
    }
    export interface AsLookup {
        route: string;
        module: string;
        purpose: string;
        entity: string;
        listPath: string;
        itemsPath: string;
        hasMorePath: string;
        pageParam: string;
        pageSizeParam: string;
        filters: AsInputField[];
        related: AsRelated[];
    }
    export interface AsEntityField {
        path: string;
        title: string;
        description: string;
        type: string;
        required: boolean;
        derived: boolean;
        to: string[];
        enumValues: AsEnumValue[];
    }
    export interface AsEntity {
        module: string;
        entityId: string;
        title: string;
        displayField: string;
        fields: AsEntityField[];
    }
    export interface AsCatalog {
        commands: AsCommand[];
        queries: AsCommand[];
        lookups: AsLookup[];
        entities: AsEntity[];
        issues: string[];
    }
    export interface AsModuleSources {
        module: string;
        routeKeys: string[];
        requests: string[];
        contracts: string[];
        ontology: string[];
    }
    export interface AsRefIntent {
        lookupRoute: string;
        lookupParams: Record<string, string>;
        matchEntity: string;
        matchText: string;
    }
    export interface AsPicked {
        id: string;
        label: string;
        version?: number;
    }
    export interface AsCandidate {
        route: string;
        title: string;
        reason: string;
        values: Record<string, string>;
        refs: Record<string, AsRefIntent>;
    }
    export interface AsOption {
        id: string;
        label: string;
        description?: string;
        recommended?: boolean;
    }
    export interface AsQuestion {
        id: string;
        title?: string;
        question: string;
        options: AsOption[];
        allowNotes?: boolean;
        notesPlaceholder?: string;
    }
    export interface AsPending {
        kind: 'questions' | 'confirm';
        title: string;
        intro: string;
        questions: AsQuestion[];
        picks: Record<string, Record<string, AsPicked>>;
        freeRefs: string[];
    }
    export const AS_STATE_SCHEMA: "agentAssistant-state-v4";
    export type AsMode = 'alternatives' | 'sequence' | 'question' | 'manual';
    export interface AsManualSelection {
        modules: string[];
        pages: Array<{
            module: string;
            pageId: string;
        }>;
        journeys: Array<{
            module: string;
            journeyId: string;
        }>;
    }
    export interface AsFinal {
        kind: 'answer' | 'message';
        text: string;
    }
    export interface AsActionResult {
        route: string;
        title: string;
        params: Record<string, unknown>;
        summary: string[];
        ok: boolean;
        data: unknown;
        error: {
            code: string;
            message: string;
        } | null;
    }
    export interface AsState {
        schema: typeof AS_STATE_SCHEMA;
        project: number;
        userText: string;
        userLanguage: string;
        reply: string;
        round: number;
        mode: AsMode;
        candidates: AsCandidate[];
        queue: AsCandidate[];
        authorized: boolean;
        results: AsActionResult[];
        final: AsFinal | null;
        manual: AsManualSelection | null;
        route: string;
        title: string;
        values: Record<string, string>;
        refs: Record<string, AsRefIntent>;
        picked: Record<string, AsPicked>;
        pending: AsPending | null;
    }
    export interface AsAnswer {
        id: string;
        optionId: string;
        notes?: string;
    }
    export type AsNext = {
        kind: 'reply';
        text: string;
    } | {
        kind: 'ask';
        pending: AsPending;
    } | {
        kind: 'ready';
    } | {
        kind: 'finished';
        results: AsActionResult[];
    };
    export interface AsRow {
        id: string;
        label: string;
        version?: number;
        texts: Record<string, string>;
    }
    export interface AsBffResponse {
        ok: boolean;
        data: unknown;
        error: {
            code: string;
            message: string;
            details?: unknown;
        } | null;
    }
    export type AsBffCall = (routine: string, params: Record<string, unknown>) => Promise<AsBffResponse>;
}
declare module "_102020_/l2/helpers/assistantCatalog/asSource" {
    import type { AsContractRoute, AsTypeNode } from "_102020_/l2/helpers/assistantCatalog/asTypes";
    export function extractExportedObject(source: string): unknown;
    type Token = {
        kind: 'punct' | 'string' | 'ident' | 'number';
        value: string;
    };
    export function tokenize(text: string): Token[];
    export function parseTypeText(text: string): AsTypeNode;
    export interface AsParsedContract {
        types: Record<string, AsTypeNode>;
        routes: AsContractRoute[];
    }
    export function parseContractSource(source: string): AsParsedContract;
    export interface AsTypeLeaf {
        path: string;
        required: boolean;
        type: AsTypeNode;
    }
    export function flattenType(node: AsTypeNode, types: Record<string, AsTypeNode>, prefix?: string, required?: boolean, depth?: number): AsTypeLeaf[];
}
declare module "_102020_/l2/helpers/assistantCatalog/asCatalog" {
    import type { AsCatalog, AsEntity, AsEntityField, AsLookup, AsModuleSources } from "_102020_/l2/helpers/assistantCatalog/asTypes";
    export function buildCatalog(modules: AsModuleSources[]): AsCatalog;
    export function mapWireToEntityField(wirePath: string, entity: AsEntity | undefined): AsEntityField | undefined;
    export function lookupNeedsParams(lookup: AsLookup): boolean;
    export function lookupsFor(catalog: AsCatalog, module: string, entityId: string): AsLookup[];
    export function findEntity(catalog: AsCatalog, module: string, entityId: string): AsEntity | undefined;
    export function catalogForPrompt(catalog: AsCatalog): Record<string, unknown>;
    export function humanize(name: string): string;
    export function asRecord(value: unknown): Record<string, unknown>;
    export function asArray(value: unknown): unknown[];
    export function asString(value: unknown): string;
}
declare module "_102021_/l2/agentMaterializeL1/steps/catalog75/describe" {
    export interface CatalogWriteUsecase {
        entityId: string;
        operation: string;
        transitionRef: string;
    }
    export interface TitleOfCommandInput {
        usecaseText: string;
        journeyTexts: readonly string[];
        sharedPageText: string;
        purpose: string;
    }
    export interface TitleOfQueryInput {
        entity: string;
        journeyTexts: readonly string[];
        sharedPageText: string;
        purpose: string;
    }
    export interface RouteAccess {
        actors: string[];
        rules: string[];
    }
    export interface CatalogPage {
        address: string;
        recordParam?: string;
    }
    export interface PageOfRouteInput {
        route: string;
        project: string;
        module: string;
        configText: string;
        sharedPageText?: string;
    }
    export function titleOfCommand(input: TitleOfCommandInput): string;
    export function titleOfQuery(input: TitleOfQueryInput): string;
    export function accessOfRoute(contractSource: string, route: string): RouteAccess;
    export function pageOfRoute(input: PageOfRouteInput): CatalogPage | undefined;
    export function optionsOnly(contractSource: string, route: string): boolean;
}
declare module "_102021_/l2/agentMaterializeL1/steps/catalog75/risk" {
    export type AssistantRisk = 'read' | 'write' | 'sensitive';
    export type RiskReason = 'delete' | 'finalState' | 'effects' | 'outbound' | 'llm' | 'unclassified';
    /** One write usecase of the command. `null` means the route names a usecase that has no def. */
    export interface RiskCommandInput {
        usecases: ReadonlyArray<string | null>;
        ontologies: readonly string[];
        integration: string | null;
        /** `l4/<module>/workflows.defs.ts`. */
        workflows: string | null;
        /** `l1/<module>/layer_2_application/workflows/*.defs.ts`. */
        workflowOperations: readonly string[];
    }
    export interface CommandRisk {
        risk: 'write' | 'sensitive';
        reasons: RiskReason[];
    }
    export function riskOfQuery(): 'read';
    /** Lifecycle states, then transition targets, that never appear in a transition `from`. */
    export function finalStates(ontologyText: string): string[];
    export function riskOfCommand(input: RiskCommandInput): 'write' | 'sensitive';
    export function commandRisk(input: RiskCommandInput): CommandRisk;
}
declare module "_102021_/l2/agentMaterializeL1/steps/catalog75/assistantCatalogBuild" {
    import type { AsEntity, AsInputField, AsLookup } from "_102020_/l2/helpers/assistantCatalog/asTypes";
    import { type CatalogPage } from "_102021_/l2/agentMaterializeL1/steps/catalog75/describe";
    import { type AssistantRisk } from "_102021_/l2/agentMaterializeL1/steps/catalog75/risk";
    export const ASSISTANT_CATALOG_SCHEMA = "assistant-catalog-v1";
    export interface AssistantCatalogInputs {
        project: string;
        module: string;
        routeKeys: readonly string[];
        requests: readonly string[];
        contracts: readonly string[];
        ontology: readonly string[];
        usecases: readonly string[];
        journeys: readonly string[];
        integration: string | null;
        workflows: string | null;
        workflowOperations: readonly string[];
        sharedPages: readonly string[];
        config: string;
    }
    export interface AssistantCatalogAction {
        route: string;
        module: string;
        kind: 'cmd' | 'qry';
        purpose: string;
        writes: string;
        entity: string;
        inputs: AsInputField[];
        pageParam: string;
        pageSizeParam: string;
        actionId: string;
        routes: string[];
        title: string;
        actors: string[];
        rules: string[];
        assistant: 'included' | 'excluded';
        risk: AssistantRisk;
        page?: CatalogPage;
    }
    export interface AssistantCatalog {
        schemaVersion: typeof ASSISTANT_CATALOG_SCHEMA;
        module: string;
        commands: AssistantCatalogAction[];
        queries: AssistantCatalogAction[];
        lookups: AsLookup[];
        entities: AsEntity[];
        issues: string[];
    }
    export function buildAssistantCatalog(inputs: AssistantCatalogInputs): {
        catalog: AssistantCatalog;
        text: string;
    };
    export function renderAssistantCatalog(project: string, moduleName: string, catalog: AssistantCatalog): string;
}
declare module "_102021_/l2/agentMaterializeL1/steps/catalog75/agentM12Catalog" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12RunArgs } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    export function createAgent(): IAgentAsync;
    /** Drops an optional @@agentM12Catalog prefix so the same JSON the planned step carries also works alone. */
    export function catalogStepArgs(value: string): string;
    /** Reads the module and writes its catalog. Returns the trace. The only write is assistantCatalog.ts. */
    export function emitAssistantCatalog(run: M12RunArgs): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/steps/finalize80/agentM12Finalize" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12Layer } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12UnitState, type M12UnitStatus } from "_102021_/l2/agentMaterializeL1/helpers/m12Io";
    export function createAgent(): IAgentAsync;
    export const M12_REPORT_VERSION: "2026-10-05-m12-report-v1";
    export interface M12Report {
        schemaVersion: typeof M12_REPORT_VERSION;
        project: number;
        moduleName: string;
        /** complete: every selected unit done or reused (a declared platform gap allowed); partial otherwise. */
        status: 'complete' | 'partial';
        counts: Record<M12UnitState, number>;
        byLayer: Partial<Record<M12Layer, Record<string, number>>>;
        /** Every unit that is not done or reused, with its code: nothing is dropped. */
        open: Array<{
            layer: M12Layer;
            unitId: string;
            status: M12UnitState;
            code: string;
            diagnostic: string;
        }>;
        /** Units generated and through every gate that no compiler proved (COMPILE_UNAVAILABLE_L1). */
        notCompiled: string[];
        /** Selected units with no status file (the phase did not reach them). */
        missing: string[];
        defProblems: Array<{
            defRef: string;
            code: string;
            detail: string;
        }>;
        registration: {
            action: string;
            detail: string;
        } | null;
        createdAt: string;
    }
    export function buildM12Report(project: number, moduleName: string, units: readonly M12UnitStatus[], missing: readonly string[], defProblems: M12Report['defProblems'], registration: M12Report['registration']): M12Report;
    export function summarizeM12Report(report: M12Report): string;
}
declare module "_102021_/l2/agentMaterializeL1/agentMaterializeL1" {
    import type { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type M12Layer, type M12Request } from "_102021_/l2/agentMaterializeL1/helpers/m12Core";
    import { type M12Unit } from "_102021_/l2/agentMaterializeL1/helpers/m12Units";
    import "_102021_/l2/agentMaterializeL1/steps/domain10/agentM12Domain";
    import "_102021_/l2/agentMaterializeL1/steps/persistence20/agentM12Persistence";
    import "_102021_/l2/agentMaterializeL1/steps/seedRows25/agentM12SeedRows";
    import "_102021_/l2/agentMaterializeL1/steps/seedRows25/agentM12SeedRowUnit";
    import "_102021_/l2/agentMaterializeL1/steps/usecases40/agentM12Usecases";
    import "_102021_/l2/agentMaterializeL1/steps/usecases40/agentM12UsecaseUnit";
    import "_102021_/l2/agentMaterializeL1/steps/workflows45/agentM12Workflows";
    import "_102021_/l2/agentMaterializeL1/steps/workflows45/agentM12WorkflowUnit";
    import "_102021_/l2/agentMaterializeL1/steps/requests50/agentM12Requests";
    import "_102021_/l2/agentMaterializeL1/steps/requests50/agentM12RequestService";
    import "_102021_/l2/agentMaterializeL1/steps/controllers30/agentM12Controllers";
    import "_102021_/l2/agentMaterializeL1/steps/tests60/agentM12Tests";
    import "_102021_/l2/agentMaterializeL1/steps/tests60/agentM12TestsPage";
    import "_102021_/l2/agentMaterializeL1/steps/register70/agentM12Register";
    import "_102021_/l2/agentMaterializeL1/steps/catalog75/agentM12Catalog";
    import "_102021_/l2/agentMaterializeL1/steps/finalize80/agentM12Finalize";
    /**
     * Materializes the L1 backend of a module (recipes first: domain -> persistence -> controllers; then the model:
     * usecases -> request services -> monitor tests; then the l5 registration and a report) from the defs v2, following
     * mls-102047/materializadorL1.md. No JSON = every module of the current project, `{"scope":"<folder>"}`
     * or `{"target":"<path of a .defs.ts>"}`. The root is deterministic; see flow.json.
     */
    export function createAgent(): IAgentAsync;
    export interface M12ModulePlan {
        module: string;
        layers: M12Layer[];
        register: boolean;
        units: M12Unit[];
        problems: Array<{
            defRef: string;
            code: string;
            detail: string;
        }>;
    }
    export function planReport(request: M12Request, modules: readonly M12ModulePlan[]): string;
}
declare module "_102021_/l2/agentMaterializeL1/core/io" {
    /** Read port for simulate. There is no write, delete, migrate or model method on purpose. */
    export interface MaterializeReadIo {
        read(ref: string): Promise<string | null>;
    }
    export function contentHash(value: string): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/core/registry" {
    /**
     * Closed handler registry. This file is the only integrator: m1_03, m1_06 and m1_07
     * deliver a MaterializeHandler; wiring it stays here. A type with no named entry is
     * blocked by the planner. Nothing in this module writes a file.
     */
    import { type M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_HANDLER_STAGES: readonly ["structure", "implement"];
    export type M1HandlerStage = typeof M1_HANDLER_STAGES[number];
    /** Platform capabilities a handler may ask the context resolver to load. MDM catalog is not one of them. */
    export const M1_CONTEXT_CAPABILITIES: readonly ["requestContext", "dataRuntime", "tableDefinition", "repositoryRegistry", "mdmFacade"];
    export type M1ContextCapability = typeof M1_CONTEXT_CAPABILITIES[number];
    export interface MaterializeHandler {
        readonly id: string;
        readonly artifactType: M1ArtifactType;
        readonly stage: M1HandlerStage;
        /** False means the recipe is local. Simulate never calls a model for this handler. */
        readonly needsLlm: boolean;
        readonly capabilities: readonly M1ContextCapability[];
    }
    /** Implement recipes. Null is a written absence: no fallback onto the structure scaffolder. */
    export const M1_IMPLEMENT_HANDLERS: Record<M1ArtifactType, MaterializeHandler | null>;
    export const M1_STRUCTURE_HANDLERS: Readonly<Record<M1ArtifactType, MaterializeHandler>>;
    export function handlerFor(type: string, stage?: M1HandlerStage): MaterializeHandler | null;
    export function registeredHandlerIds(stage?: M1HandlerStage): string[];
}
declare module "_102021_/l2/agentMaterializeL1/emitters/fixture/tarefas/access.defs" {
    export const tarefasAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "tarefas";
        readonly actors: readonly [{
            readonly actorId: "membroEquipe";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Membro da equipe";
            readonly description: "Cria tarefas, executa as que lhe são atribuídas (inicia e envia para revisão) e revisa as que criou (aceita, devolve com motivo ou cancela).";
            readonly personEntity: "MembroEquipe";
        }, {
            readonly actorId: "gestor";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gestor";
            readonly description: "Faz tudo o que o membro faz e, além disso, vê e acompanha todas as tarefas da equipe, mantém as listas, reatribui e cancela tarefas.";
            readonly personEntity: "MembroEquipe";
        }];
        readonly grants: readonly [{
            readonly grantId: "membroTarefasProprias";
            readonly actorRef: "membroEquipe";
            readonly title: "Tarefas que criei ou que me foram atribuídas";
            readonly description: "O membro cria tarefas, executa as que lhe são atribuídas, revisa, devolve, cancela e reatribui as que criou e edita os campos das tarefas que vê, junto com a checklist.";
            readonly entityRefs: readonly ["Tarefa", "ItemChecklist"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Tarefas em que o membro da sessão é o responsável ou o criador, e os itens de checklist dessas tarefas.";
                readonly anchorEntity: "MembroEquipe";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O membro vê a tarefa completa, incluindo motivo de devolução, andamento e checklist.";
            };
        }, {
            readonly grantId: "membroAvisosProprios";
            readonly actorRef: "membroEquipe";
            readonly title: "Meus avisos diários de vencimento";
            readonly description: "O membro consulta o aviso diário com as suas tarefas abertas que vencem hoje ou estão atrasadas.";
            readonly entityRefs: readonly ["AvisoVencimento"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente os avisos em que o membro da sessão é o responsável.";
                readonly anchorEntity: "MembroEquipe";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O membro vê o aviso inteiro com as tarefas listadas.";
            };
        }, {
            readonly grantId: "membroConsultaListas";
            readonly actorRef: "membroEquipe";
            readonly title: "Escolher a lista da tarefa";
            readonly description: "O membro consulta as listas para escolher onde a nova tarefa ficará.";
            readonly entityRefs: readonly ["Lista"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas as listas da organização.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Nome, situação, tipo e descrição da lista; os indicadores de acompanhamento ficam com o gestor.";
                readonly allowedFields: readonly ["Lista.nome", "Lista.ativa", "Lista.details.tipo", "Lista.details.descricao"];
            };
        }, {
            readonly grantId: "membroEscolheResponsavel";
            readonly actorRef: "membroEquipe";
            readonly title: "Escolher responsável na equipe";
            readonly description: "O membro vê os nomes das pessoas da equipe para atribuir ou reatribuir a tarefa.";
            readonly entityRefs: readonly ["MembroEquipe"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas as pessoas da equipe.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Somente nome e situação (ativo ou inativo) de cada membro.";
                readonly allowedFields: readonly ["MembroEquipe.details.identification.name", "MembroEquipe.details.identification.status"];
            };
        }, {
            readonly grantId: "gestorTarefasEquipe";
            readonly actorRef: "gestor";
            readonly title: "Todas as tarefas da equipe";
            readonly description: "O gestor vê, acompanha, edita, reatribui e cancela qualquer tarefa da equipe, além de fazer tudo o que o membro faz, com a checklist.";
            readonly entityRefs: readonly ["Tarefa", "ItemChecklist"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas as tarefas e itens de checklist da organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O gestor vê a tarefa completa em lista ou em quadro por situação.";
            };
        }, {
            readonly grantId: "gestorListas";
            readonly actorRef: "gestor";
            readonly title: "Manter listas";
            readonly description: "O gestor cadastra, altera e acompanha as listas que agrupam tarefas por projeto ou área.";
            readonly entityRefs: readonly ["Lista"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas as listas da organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O gestor vê a lista inteira, incluindo a quantidade de tarefas abertas.";
            };
        }, {
            readonly grantId: "gestorMembros";
            readonly actorRef: "gestor";
            readonly title: "Pessoas da equipe";
            readonly description: "O gestor mantém o cadastro das pessoas da equipe neste módulo e escolhe responsáveis ao reatribuir.";
            readonly entityRefs: readonly ["MembroEquipe"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todas as pessoas da equipe.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Dados de identificação e contato do membro, sem o registro de consentimento de privacidade.";
                readonly deniedFields: readonly ["MembroEquipe.details.person.privacyConsent"];
            };
        }, {
            readonly grantId: "gestorAvisosProprios";
            readonly actorRef: "gestor";
            readonly title: "Meus avisos diários de vencimento";
            readonly description: "Como responsável de tarefas, o gestor consulta o seu aviso diário de tarefas que vencem hoje ou estão atrasadas.";
            readonly entityRefs: readonly ["AvisoVencimento"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente os avisos em que o gestor da sessão é o responsável.";
                readonly anchorEntity: "MembroEquipe";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O gestor vê o aviso inteiro com as tarefas listadas.";
            };
        }];
    };
    export type TarefasAccessType = typeof tarefasAccess;
    export default tarefasAccess;
}
declare module "_102021_/l2/agentMaterializeL1/emitters/fixture/tarefas/ontology/MembroEquipe.defs" {
    export const tarefasEntityMembroEquipe: {
        readonly schemaVersion: "2026-09-17-ns5-ontology-v3.1";
        readonly moduleName: "tarefas";
        readonly entityId: "MembroEquipe";
        readonly title: "Membro da equipe";
        readonly description: "Pessoa da equipe que cria, executa e revisa tarefas; é responsável ou criadora de tarefas. O gestor também é um membro da equipe.";
        readonly displayField: "details.identification.name";
        readonly relationships: {
            readonly tarefasResponsavel: {
                readonly relationshipId: "tarefaResponsavel";
                readonly to: "Tarefa";
                readonly via: "Tarefa.responsavelId";
                readonly cardinality: "1:N";
                readonly title: "Tarefas sob responsabilidade";
                readonly description: "Tarefas que o membro executa.";
                readonly mode: "fk";
                readonly direction: "to";
                readonly required: true;
            };
            readonly tarefasCriadas: {
                readonly relationshipId: "tarefaCriador";
                readonly to: "Tarefa";
                readonly via: "Tarefa.criadorId";
                readonly cardinality: "1:N";
                readonly title: "Tarefas criadas";
                readonly description: "Tarefas que o membro criou e revisa.";
                readonly mode: "fk";
                readonly direction: "to";
                readonly required: true;
            };
            readonly avisosVencimento: {
                readonly relationshipId: "avisoResponsavel";
                readonly to: "AvisoVencimento";
                readonly via: "AvisoVencimento.responsavelId";
                readonly cardinality: "1:N";
                readonly title: "Avisos diários de vencimento";
                readonly description: "Avisos diários das tarefas abertas que vencem hoje ou estão atrasadas.";
                readonly mode: "fk";
                readonly direction: "to";
                readonly required: true;
            };
        };
        readonly capabilities: {
            readonly "read.byId": "Lê o membro pelo mdmId para mostrar responsável e criador nas listas e no quadro de tarefas; usado por todas as telas de tarefas.";
            readonly "locate.byName": "Busca membros ativos pelo nome para escolher o novo responsável ao criar ou reatribuir uma tarefa; usado pelo membro e pelo gestor.";
            readonly "locate.byLogin": "Resolve o membro da sessão pelo e-mail de login, base das visões 'minhas tarefas' e 'tarefas que criei'; usado pela plataforma.";
            readonly "register.createOrAttach": "Cria ou anexa a pessoa com o papel tarefas.MembroEquipe, sem duplicar quem já existe no cadastro mestre; usado pelo gestor ao montar a equipe.";
            readonly "edit.platformFields": "Corrige o nome e o país do membro no cadastro mestre; usado pelo gestor.";
            readonly inactivate: "Inativa o membro que saiu da equipe, que deixa de aparecer na escolha de responsável, e o reativa se voltar; usado pelo gestor.";
            readonly "link.contact": "Vincula o e-mail ou telefone do membro por HasContact, usado nos avisos de tarefa; usado pelo gestor.";
            readonly listLinks: "Mostra os vínculos do membro, como a quem se reporta na equipe; usado na ficha do membro.";
            readonly "invite.login": "Dá login ao membro para que ele veja e execute suas tarefas; usado pelo gestor.";
            readonly audit: "Mostra quem alterou o cadastro do membro e quando; usado pelo gestor.";
        };
        readonly rules: readonly ["rule-foreign-namespace-refused", "rule-identity-never-in-namespace", "rule-document-shape-validated", "rule-person-privacy-consent-required-br-eu", "rule-delete-blocked-by-relationships", "responsavelDeveSerMembroAtivo"];
        readonly writer: "crud";
        readonly kind: "role";
        readonly subtype: "Person";
        readonly roleTag: "tarefas.MembroEquipe";
        readonly source: "/_102034_/l4/ontology/mdm.defs.ts";
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly indexed: true;
                    readonly derived: true;
                    readonly description: "mdmId; stable through promotion and merge.";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                    readonly writePrecondition: true;
                    readonly description: "Bumped by the engine on every write; optimistic concurrency.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly description: "Registro mestre da pessoa da equipe, como a plataforma o guarda.";
                    readonly fields: {
                        readonly identification: {
                            readonly type: "object";
                            readonly owner: "platform";
                            readonly fields: {
                                readonly subtype: {
                                    readonly type: "enum";
                                    readonly required: true;
                                    readonly indexed: true;
                                    readonly derived: true;
                                    readonly values: readonly [{
                                        readonly value: "Person";
                                        readonly title: "Pessoa";
                                    }];
                                    readonly description: "Sempre pessoa: o membro da equipe é uma pessoa física.";
                                    readonly title: "Subtipo";
                                };
                                readonly name: {
                                    readonly type: "string";
                                    readonly required: true;
                                    readonly indexed: true;
                                    readonly maxLength: 200;
                                    readonly description: "Nome do membro como aparece nas tarefas (responsável e criador) e na escolha de quem recebe a tarefa.";
                                    readonly title: "Nome";
                                };
                                readonly status: {
                                    readonly type: "enum";
                                    readonly required: true;
                                    readonly indexed: true;
                                    readonly derived: true;
                                    readonly values: readonly [{
                                        readonly value: "Active";
                                        readonly title: "Ativo";
                                    }, {
                                        readonly value: "Inactive";
                                        readonly title: "Inativo";
                                    }, {
                                        readonly value: "Merged";
                                        readonly title: "Mesclado";
                                    }, {
                                        readonly value: "Blocked";
                                        readonly title: "Bloqueado";
                                    }];
                                    readonly title: "Situação no cadastro";
                                    readonly description: "Ativo pode receber tarefas; inativo deixa de aparecer na escolha de responsável.";
                                };
                                readonly countryCode: {
                                    readonly type: "string";
                                    readonly required: true;
                                    readonly indexed: true;
                                    readonly pattern: "^[A-Z]{2}$";
                                    readonly maxLength: 2;
                                    readonly default: "US";
                                    readonly description: "País do membro, que define as regras de privacidade aplicáveis.";
                                    readonly title: "País";
                                };
                                readonly tags: {
                                    readonly type: "string";
                                    readonly required: true;
                                    readonly collection: true;
                                    readonly derived: true;
                                    readonly description: "Papéis de módulo da pessoa; inclui tarefas.MembroEquipe.";
                                    readonly title: "Papéis";
                                };
                            };
                            readonly description: "Colunas de índice da plataforma usadas para localizar o membro.";
                        };
                        readonly base: {
                            readonly type: "object";
                            readonly owner: "platform";
                            readonly fields: {
                                readonly contacts: {
                                    readonly type: "object";
                                    readonly required: true;
                                    readonly collection: true;
                                    readonly of: "ContactSummary";
                                    readonly derived: true;
                                    readonly description: "Resumo dos canais de contato vinculados, lido para os avisos ao responsável e ao criador.";
                                    readonly title: "Contatos";
                                };
                            };
                            readonly description: "Dados comuns da plataforma; o módulo não usa nenhum além dos contatos derivados.";
                        };
                        readonly person: {
                            readonly type: "object";
                            readonly owner: "platform";
                            readonly fields: {
                                readonly privacyConsent: {
                                    readonly type: "object";
                                    readonly of: "PrivacyConsent";
                                    readonly description: "Consentimento LGPD do membro, exigido pela plataforma para residentes no Brasil.";
                                    readonly title: "Consentimento de privacidade";
                                };
                            };
                            readonly description: "Ramo de pessoa física da plataforma.";
                        };
                        readonly general: {
                            readonly type: "object";
                            readonly owner: "organization";
                            readonly open: true;
                            readonly description: "Campos promovidos pela organização; o módulo apenas lê.";
                        };
                        readonly tarefas: {
                            readonly type: "object";
                            readonly owner: "module";
                            readonly fields: {};
                            readonly description: "Module namespace; the prompt asked for no data of this module about the record.";
                        };
                    };
                };
            };
        };
    };
    export type TarefasEntityMembroEquipeType = typeof tarefasEntityMembroEquipe;
    export default tarefasEntityMembroEquipe;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/domainOptional" {
    /**
     * m1_41 b1-P1: which fields a stored record may lack. The domain emitter types them with `?`, and a v2
     * usecase reads its optional input and output fields from the same place: the l4 entity `required`
     * and the fields the server assigns. Moved here from `behavior/emitBehavior.ts` so that structure and
     * behavior share one criterion.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    /**
     * Entity field paths the domain types with `?`: on a module-database entity, the fields the l4 entity
     * does not require and the server does not assign. Empty for other storage targets or with no l4
     * entity; null when the l4 entity has no readable record fields.
     */
    export function domainOptionalPaths(entity: M1Definition, ontologySource: string | null): Set<string> | null;
    /**
     * The entity path of a usecase signature row: its `fieldRef` without the `<Entity>.` prefix.
     * A row of another entity, or one with no field ref (a page param), is not an entity path: ''.
     */
    export function signatureFieldPath(row: Record<string, unknown>, entityId: string): string;
    /** Names of the signature rows the domain types with `?`. */
    export function optionalSignatureNames(rows: readonly unknown[], entityId: string, optional: ReadonlySet<string>): Set<string>;
    /** Server-assigned values of a new record: the identity, the version and the initial lifecycle state. */
    export function serverAssigned(entity: M1Definition, lifecycle: {
        field: string;
        initial: string;
    }): Map<string, string>;
    /** Field paths the canonical l4 entity marks `required`, walking nested `fields`; null when unreadable. */
    export function ontologyRequired(source: string): Set<string> | null;
    export function identityField(entity: M1Definition): string;
    export function enumField(entity: M1Definition): string;
    export function versionField(entity: M1Definition, identity: string): string;
    export function topFields(entity: M1Definition): Array<{
        name: string;
        type: string;
        derived: boolean;
    }>;
    /**
     * The lifecycle field is the single top-level enum of an entity that declares transitions.
     * Its initial state is the one declared state no transition reaches; otherwise it is ''.
     */
    export function lifecycleStart(definition: M1Definition): {
        field: string;
        initial: string;
    };
}
declare module "_102021_/l2/agentMaterializeL1/testing/catalog" {
    /**
     * Scenario catalog for one module. The monitor imports the rendered module
     * (export `scenarioCatalog` only). The sibling test file of each unit carries
     * the same scenario as data (`renderScenarioTest`); nothing here runs a case.
     */
    import type { M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    import type { M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    export const M1_CATALOG_SCHEMA: "2026-09-25-m1-scenario-catalog-v1";
    /** Additive: each case names its runner, and a route case names its caller. */
    export const M1_CATALOG_SCHEMA_V11: "2026-09-26-m1-scenario-catalog-v1.1";
    /** Additive: a route case may name `<seedRef>` params and the entity field each one addresses. */
    export const M1_CATALOG_SCHEMA_V12: "2026-10-02-m1-scenario-catalog-v1.2";
    export const M1_CATALOG_SCHEMAS: readonly ["2026-09-25-m1-scenario-catalog-v1", "2026-09-26-m1-scenario-catalog-v1.1", "2026-10-02-m1-scenario-catalog-v1.2"];
    /** Literal the monitor resolves from a seeded row. Never an invented id. */
    export const M1_SEED_REF: "<seedRef>";
    export type M1CatalogSchema = typeof M1_CATALOG_SCHEMAS[number];
    /** Positive case of an operation that addresses one stored record. */
    export const M1_EXISTING_RECORD = "existing record";
    export const M1_CATALOG_EXPORT: "scenarioCatalog";
    /** Config key x1_02 will read. It is not `frontend.pageTests`. */
    export const M1_CATALOG_CONFIG_KEY: "backend.scenarioCatalog";
    /** Provisional stub from the structure handler. Business expectations do not use this code. */
    export const M1_STUB_ERROR: "USECASE_NOT_IMPLEMENTED";
    export const M1_STUB_STATUS = 501;
    export const M1_GATES: readonly ["compile", "contract", "auth", "business"];
    export type M1Gate = typeof M1_GATES[number];
    export interface M1SyntheticRow {
        entity: string;
        id: string;
        professionalId: string;
        patientId: string;
        scheduledAt: string;
        status: string;
        version: number;
        attendanceNote: string;
    }
    export interface M1ExpectedFailure {
        caseId: string;
        stage: 'structure';
        errorCode: typeof M1_STUB_ERROR;
        status: typeof M1_STUB_STATUS;
    }
    /** Definitive assertion. A repair is not allowed to change it. */
    export interface M1CaseExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        forbiddenFields: string[];
        /** When set, every returned row must carry this actor id. Shape alone does not pass. */
        isolatedActorField: string | null;
    }
    export type M1CaseRunner = 'route' | 'module';
    /** Present only on a route case. Authorities come from the grant, not from the case id. */
    export interface M1CaseCaller {
        source: 'http';
        authorities: string[];
    }
    export interface M1ScenarioCase {
        caseId: string;
        gate: M1Gate;
        mandatory: true;
        source: string;
        expectation: string;
        preconditions: string[];
        synthetic: M1SyntheticRow[];
        actorId: string;
        routine: string;
        mutating: boolean;
        expect: M1CaseExpect;
        expectedFailure: M1ExpectedFailure | null;
        /** Absent on a v1 catalog. */
        runner?: M1CaseRunner;
        /** Absent on a module case and on a v1 catalog. */
        caller?: M1CaseCaller;
        /** Absent before v1.2. Values may be the literal `<seedRef>`. */
        params?: Record<string, string>;
        /** `<Entity>.<field>` for each `<seedRef>` param. Absent before v1.2. */
        paramFieldRefs?: Record<string, string>;
    }
    export interface M1Scenario {
        scenarioId: string;
        source: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        handlerId: string;
        productionFile: string;
        testFile: string;
        cases: M1ScenarioCase[];
    }
    export interface M1ScenarioCatalog {
        schemaVersion: M1CatalogSchema;
        moduleName: string;
        store: 'memory';
        scenarios: M1Scenario[];
    }
    export interface M1CatalogParse {
        catalog: M1ScenarioCatalog | null;
        issues: string[];
    }
    export interface M1RepairProposal {
        caseId: string;
        ok?: boolean;
        status?: number;
        errorCode?: string | null;
        ruleId?: string | null;
        dropForbiddenFields?: readonly string[];
        clearActorFilter?: boolean;
        dropExpectedFailure?: boolean;
        replaceExpectedFailure?: {
            errorCode: string;
            status: number;
        };
    }
    export function canonicalJson(value: unknown): string;
    export function extractCatalogJson(source: string): string | null;
    export function parseCatalog(source: string): M1CatalogParse;
    /** Implement removes the provisional mark. This is not a repair. */
    export function catalogForStage(catalog: M1ScenarioCatalog, stage: M1HandlerStage): M1ScenarioCatalog;
    /**
     * Drops a rule or a filter from a copy of the case. Used only to prove the
     * original assertion fails when that rule is absent. Repair refuses the same edit.
     */
    export function withoutRule(item: M1ScenarioCase, ruleId: string): M1ScenarioCase;
    export function repairRefusal(item: M1ScenarioCase, proposal: M1RepairProposal): string[];
    export function applyRepair(catalog: M1ScenarioCatalog, proposal: M1RepairProposal): {
        catalog: M1ScenarioCatalog;
        refused: string[];
    };
    export function renderMonitorCatalog(catalog: M1ScenarioCatalog, fileReference: string): string;
    /** Qualified file or import (`_NNNNN_/…` or `/_NNNNN_/…`) as `/_NNNNN_/….js`. Anything else is refused. */
    export function moduleSpecifier(file: string): string;
    /** Export of the per-unit `.test.ts`: that unit's scenario, as data. */
    export const M1_TEST_EXPORT: "scenarioCases";
    /**
     * The per-unit `.test.ts` is data: the scenario the monitor runs from the module catalog
     * (`backend.scenarioCatalog`). No import, no runner, nothing executes when it loads, so it
     * compiles in the Studio like any other module (conduta 28/09, rule 4).
     */
    export function renderScenarioTest(scenario: M1Scenario): string;
    /** A test this agent rendered before m1_35: a node runner bound to the catalog. It is rewritten, never kept. */
    export function isLegacyNodeTest(text: string, testFile: string): boolean;
    export function testFileFor(productionFile: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/gate" {
    export const FORBIDDEN_ACTOR = "FORBIDDEN_ACTOR";
    export const VALIDATION_ERROR = "VALIDATION_ERROR";
    export const GRANT_ABSENT = "GRANT_ABSENT";
    export const SESSION_UNVERIFIED = "SESSION_UNVERIFIED";
    export const SCOPE_UNBOUND = "SCOPE_UNBOUND";
    export const REPOSITORY_NOT_IMPLEMENTED = "REPOSITORY_NOT_IMPLEMENTED";
    /** A controller with grants and no readable authority map is not emitted. */
    export const AUTHORITY_UNREAD = "AUTHORITY_UNREAD";
    /** A grant the authority map does not name has no actor: the route is refused. */
    export const AUTHORITY_UNMAPPED = "AUTHORITY_UNMAPPED";
    /** A def of the removed v1 shape (m1_41 a): refused, never read through a default. */
    export const DEF_V1_UNSUPPORTED = "DEF_V1_UNSUPPORTED";
    /**
     * Whether a def still carries the v1 shape: an httpController handler with `usecaseId` and no
     * `serviceFunction`, or a usecase function with `contractRefs`. A usecase's own `data.usecaseId` is
     * v2 and is not a marker. `routeProjections` is refused earlier, by the l1Defs schema (m1_41 c1).
     */
    export function isDefV1(data: Record<string, unknown>): boolean;
    export function defV1Detail(artifactId: string): string;
    export interface StructureGrant {
        grantId: string;
        actorRef: string;
        scopeMode: string;
        session: string;
        pending: string;
        disclosure: string;
        /** Record field taken from the grant path. Empty when that path does not resolve. */
        recordField?: string;
    }
    export interface GateInput {
        source: 'http' | 'message' | 'test';
        authorities: readonly string[];
        grantIds: readonly string[];
        grants: readonly StructureGrant[];
        /** Authority map entries. The actor of a grant comes from here, not from the scope. */
        authority: readonly {
            grantId: string;
            actorRef: string;
        }[];
        params: unknown;
        requiredFields: readonly string[];
    }
    export interface GateDecision {
        ok: boolean;
        status: number;
        errorCode: string | null;
        reachedUsecase: boolean;
    }
    export function resolveGrant(grants: readonly StructureGrant[], grantId: string): StructureGrant | {
        code: string;
        detail: string;
    };
    export function missingField(params: unknown, fields: readonly string[]): string;
    /** Same order the emitted controller uses. A stub result means both gates passed. */
    export function decideRoute(input: GateInput): GateDecision;
    export function stubDecision(): GateDecision;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/emit" {
    /**
     * Renders one structure file from a v2 def. Imports are only platform files,
     * an existing l2 contract, or the output of a dependency. A missing source
     * is a named failure, not an import of a file that does not exist.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type DisclosureNode } from "_102021_/l2/helpers/l1Defs/disclosure";
    import { type RequestOutputNode } from "_102021_/l2/helpers/l1Defs/requestTree";
    import { type StructureGrant } from "_102021_/l2/agentMaterializeL1/handlers/structure/gate";
    /** Raised when the structure handler body changes. An older receipt is a new input. */
    export const STRUCTURE_HANDLER_RECIPE = "2026-10-02-structure-handler-v13";
    export interface EmitFailure {
        code: string;
        detail: string;
    }
    export interface EmitResult {
        source: string;
        runsStub: boolean;
        imports: string[];
    }
    export type StructureRead = (ref: string) => Promise<string | null>;
    /**
     * `optional` names the field paths a stored record may lack; without it every field is required.
     * `enums` maps a field path to the values its source declares; an `enum` field without values stays `string`.
     * The lifecycle states type the entity's single top-level `enum` field.
     */
    export function emitDomain(definition: M1Definition, output: string, optional?: ReadonlySet<string>, enums?: ReadonlyMap<string, readonly string[]>): EmitResult;
    export function emitValueObject(definition: M1Definition, output: string): EmitResult;
    export function emitPort(definition: M1Definition, output: string): EmitResult | EmitFailure;
    export function emitAccess(definition: M1Definition, output: string): EmitResult;
    export function emitAuthority(definition: M1Definition, output: string): EmitResult;
    export function emitUsecase(definition: M1Definition, output: string, read: StructureRead): Promise<EmitResult | EmitFailure>;
    export function emitController(definition: M1Definition, output: string, read: StructureRead): Promise<EmitResult | EmitFailure>;
    /** Grant and required fields of one v2 route. The adapter names a service function, not a usecase. */
    export function adapterRouteFacts(definition: M1Definition, handler: Record<string, unknown>, read: StructureRead): Promise<{
        grantIds: string[];
        requiredFields: string[];
    } | EmitFailure>;
    /** Project-qualified ref of an L1/L2 file a def names relatively; the `_<proj>_/` prefix comes from its dependencies. */
    export function qualifyFile(path: string, dependencies: readonly string[]): string;
    /**
     * Grants of each route a v2 page controller of the module exposes: the handler's `grantIds` read on
     * the module access scope. An undeclared grant id stays `{}` and discloses nothing.
     * A route no controller names is not exposed and has no entry.
     */
    export function exposedRouteGrants(moduleDefinitions: readonly unknown[]): Map<string, Record<string, unknown>[]> | EmitFailure;
    export interface ServiceOutput {
        key: string;
        entity: string;
        fields: string[];
        /** The classified paths of the request tree (d1_61). Absent in a def with the flat `outputs`. */
        disclosure?: DisclosureNode[];
        page: string;
        pageSize: string;
        hasMore: string;
    }
    /**
     * One function per request, keyed by the route. A command resolves repositories on the
     * transaction runtime: the adapter binds `ctx.data.moduleData` when the factory runs.
     * `outputs[].page`, `pageSize` and `hasMore` are the contract pagination keys when the def has them.
     */
    export function emitRequestService(definition: M1Definition, output: string, read: StructureRead, moduleDefinitions: readonly unknown[], stage: 'structure' | 'implement'): Promise<EmitResult | EmitFailure>;
    /**
     * The outputs of one request row, the one M1 reader (emit and obligations). A def with the classified tree (`output`,
     * d1_61) is projected only when every node is one this emitter projects as it is: an `entity` or a flat `list` (no
     * `total`, no page wrapper) at a root member, whose fields are their own ontology paths. Every other node is a named
     * refusal, one line per path in `unsupported`: `REQUEST_SHAPE_UNSUPPORTED: <route> <path> <type>`. The outputs still
     * carry every classified node, so the disclosure check reads the entity, related and computed paths first. The flat
     * paging keys of a list are not projected, as with the flat `outputs`. A def written before the tree (`outputs`) is
     * read by name, as before.
     */
    export function readServiceOutputs(route: string, row: Record<string, unknown>): {
        outputs: ServiceOutput[];
        unsupported: string[];
    } | EmitFailure;
    /** The nodes of a tree this emitter does not project, with the type the refusal names. */
    export function unsupportedShapes(tree: readonly RequestOutputNode[]): Array<{
        path: string;
        type: string;
    }>;
    /** Value bindings the structure emitters write. Types are not included. */
    export function emittedValueExports(definition: M1Definition): readonly string[];
    export function importSpecifier(defPath: string, kind: 'output' | 'defs'): string;
    export function auditImports(source: string, allowed: readonly string[]): string;
    export function grantsOf(data: Record<string, unknown>): StructureGrant[];
    /** The single path hop of the one non-anchor entity names the record field. A missing or contradictory path does not. */
    export function recordFieldFromGrant(grant: Record<string, unknown>): string;
    export function contractMembers(source: string, name: string): {
        requiredFields: string[];
        allowedFields: string[];
        allowedPaths: string[];
    } | null;
    /** Member paths of `name` whose declared type admits `null`. */
    export function contractNullablePaths(source: string, name: string): string[] | null;
    /** The l4 entity a domain def types against: its ontology dependency, else the module's ontology file. */
    export function ontologyRef(definition: M1Definition, output: string): string;
    /** Enum values the l4 entity declares per field path, walking nested `fields`; empty when unreadable. */
    export function ontologyEnums(source: string | null): Map<string, string[]>;
}
declare module "_102021_/l2/agentMaterializeL1/register/cbReconcileBackendConfig" {
    export interface LiveBackendModule {
        moduleId: string;
        backendControllers: string;
        /** Absent when the module backend has controllers and no persistence block. */
        tableDefsDir?: string;
        /** Derived at compose time from disk (`moduleTick.ts` next to tableDefsDir). Never copied from the old config. */
        persistenceEntrypoint?: string;
    }
    export interface ReconcileBackendConfigResult<M extends Record<string, unknown>, P extends Record<string, unknown>> {
        modules: M[];
        persistenceModules: P[];
        discarded: string[];
    }
    export function formatDiscardedOrphans(discarded: readonly string[]): string;
    export function liveBackendModulesFromL5(l5Modules: unknown): LiveBackendModule[];
    /** Drop l5/project.json backend blocks whose persistence dir is gone, except the module this run owns. */
    export function pruneOrphanL5BackendModules<M extends Record<string, unknown>>(modules: readonly M[] | undefined, currentModuleName: string, tableDefsExists: (moduleName: string) => boolean): {
        modules: M[];
        discarded: string[];
    };
    export function reconcileClientBackendRegistration<M extends Record<string, unknown>, P extends Record<string, unknown>>(existingModules: readonly M[] | undefined, existingPersistence: readonly P[] | undefined, live: readonly LiveBackendModule[]): ReconcileBackendConfigResult<M, P>;
}
declare module "_102021_/l2/agentMaterializeL1/steps/seedRows25/fixture/Country.defs" {
    export const onboardingEntityCountry: {
        readonly schemaVersion: "2026-09-17-ns5-ontology-v3.1";
        readonly moduleName: "onboarding";
        readonly entityId: "Country";
        readonly title: "Country";
        readonly description: "The module's own country list: two-letter ISO code and English name, loaded by the module seed and maintained by the company owner (add, edit, inactivate). Shown with the country name in the user language; platform records keep only the code.";
        readonly initialData: "Every ISO 3166-1 country with its two-letter code and English name, loaded by the module seed.";
        readonly displayField: "name";
        readonly relationships: {};
        readonly capabilities: {
            readonly "read.byId": "Reads one country by its id when the owner opens it to edit its name; used by the company owner on the country list.";
            readonly "locate.byColumn": "Lists countries filtered by status and ordered by name, paged; the active list feeds the country choice in the person and company forms, and the owner sees all statuses.";
            readonly "locate.byText": "Searches the country list by part of the code or the English name; used by the company owner in the country search box.";
            readonly count: "Counts the countries a filter matches, to show the total on the country list header; used by the company owner.";
            readonly create: "Writes a new country with its two-letter ISO code and English name, active from the start; used by the company owner and by the module seed.";
            readonly update: "Fixes the English name or localized names of an existing country; used by the company owner. The code is not changed.";
            readonly transition: "Moves a country from active to inactive through the inactivateCountry transition, guarded by the module; used by the company owner.";
            readonly uniqueKey: "Refuses a second country with the same ISO code through a UNIQUE index on the code column; enforced by the engine on write.";
        };
        readonly rules: readonly ["countryCodeUnique", "countryCodeIsoTwoLetters", "onlyOwnerMaintainsCountries", "inactiveCountryNotSelectable", "unknownCountryNeverDefaulted"];
        readonly kind: "entity";
        readonly class: "supporting";
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly table: "onboarding_country";
            readonly kind: "relational";
        };
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly title: "Id";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                };
                readonly code: {
                    readonly type: "string";
                    readonly required: true;
                    readonly unique: true;
                    readonly indexed: true;
                    readonly title: "ISO code";
                    readonly description: "Two-letter ISO country code in upper case. This is the only country value the platform person and company records keep.";
                    readonly pattern: "^[A-Z]{2}$";
                    readonly maxLength: 2;
                };
                readonly name: {
                    readonly type: "string";
                    readonly required: true;
                    readonly indexed: true;
                    readonly title: "Name (English)";
                    readonly description: "English name of the country. It is searched and used to sort the list. The screen shows the name in the user language.";
                    readonly maxLength: 120;
                };
                readonly status: {
                    readonly type: "enum";
                    readonly required: true;
                    readonly indexed: true;
                    readonly values: readonly [{
                        readonly value: "active";
                        readonly title: "Active";
                        readonly description: "Can be chosen in the person and company forms.";
                    }, {
                        readonly value: "inactive";
                        readonly title: "Inactive";
                        readonly description: "Can no longer be chosen in new forms.";
                    }];
                    readonly title: "Status";
                    readonly description: "Whether the country can be chosen in new forms. Inactive countries stay on record but cannot be chosen.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly title: "Details";
                    readonly description: "Display data of the country that nothing filters by.";
                    readonly fields: {
                        readonly localizedNames: {
                            readonly type: "object";
                            readonly collection: true;
                            readonly title: "Localized names";
                            readonly description: "Name of the country in each language the screen supports. When the user language has no entry, the English name is shown.";
                            readonly fields: {
                                readonly locale: {
                                    readonly type: "string";
                                    readonly required: true;
                                    readonly title: "Language";
                                    readonly description: "Language code of the translated name, for example en or pt-BR.";
                                    readonly maxLength: 10;
                                };
                                readonly name: {
                                    readonly type: "string";
                                    readonly required: true;
                                    readonly title: "Name in this language";
                                    readonly description: "Country name as shown to a person who uses this language.";
                                    readonly maxLength: 120;
                                };
                            };
                        };
                    };
                };
            };
        };
        readonly uniqueKeys: readonly [readonly ["code"]];
        readonly lifecycleStates: readonly [{
            readonly state: "active";
            readonly reachedBy: "actor";
        }, {
            readonly state: "inactive";
            readonly reachedBy: "actor";
        }];
        readonly transitions: readonly [{
            readonly transitionId: "inactivateCountry";
            readonly from: readonly ["active"];
            readonly to: "inactive";
            readonly by: readonly ["companyOwner"];
            readonly description: "The company owner inactivates a country so it can no longer be chosen in new person or company forms. Records that already hold its code are not changed.";
            readonly payload: readonly [];
            readonly ruleRefs: readonly ["onlyOwnerMaintainsCountries", "inactiveCountryNotSelectable"];
        }];
    };
    export type OnboardingEntityCountryType = typeof onboardingEntityCountry;
    export default onboardingEntityCountry;
}
declare module "_102021_/l2/agentMaterializeL1/steps/seedRows25/fixture/PrivacyText.defs" {
    export const onboardingEntityPrivacyText: {
        readonly schemaVersion: "2026-09-17-ns5-ontology-v3.1";
        readonly moduleName: "onboarding";
        readonly entityId: "PrivacyText";
        readonly title: "Privacy text";
        readonly description: "Read-only privacy text, one per version, loaded by the module seed. The current version is the latest one; it is shown with an unchecked acceptance when the chosen country requires consent.";
        readonly initialData: "The organization's privacy texts, one row per version, loaded by the module seed.";
        readonly displayField: "version";
        readonly relationships: {};
        readonly capabilities: {
            readonly "read.byId": "Reads one version of the privacy text by its id, for example to show again the text the person accepted.";
            readonly "locate.byColumn": "Finds the current privacy text by ordering on the published date, newest first, and taking the first row; the Complete my access screen reads it along with the person data.";
            readonly count: "Counts the privacy text versions loaded by the seed, so the screen can tell when no text is available and consent cannot be asked.";
            readonly uniqueKey: "Stops the seed from loading two rows with the same version, so every consent points at exactly one text.";
            readonly create: "Used only by the module seed to load each version of the privacy text; no screen creates, edits or deletes a privacy text.";
        };
        readonly rules: readonly ["privacyTextReadOnly", "currentPrivacyTextIsLatest", "privacyTextVersionUnique", "consentRecordsShownVersion"];
        readonly writer: "crud";
        readonly kind: "entity";
        readonly class: "supporting";
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly table: "onboarding_privacytext";
            readonly kind: "relational";
        };
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly title: "Id";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                };
                readonly publishedAt: {
                    readonly type: "timestamp";
                    readonly required: true;
                    readonly indexed: true;
                    readonly title: "Published at";
                    readonly description: "When this version was loaded by the module seed. The current version is the latest one, so the list is ordered by this date.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly title: "Details";
                    readonly description: "Content of this version of the privacy text.";
                    readonly fields: {
                        readonly title: {
                            readonly type: "string";
                            readonly required: true;
                            readonly title: "Title";
                            readonly description: "Heading shown above the privacy text on the consent request.";
                            readonly maxLength: 200;
                        };
                        readonly body: {
                            readonly type: "text";
                            readonly required: true;
                            readonly title: "Text";
                            readonly description: "Full privacy text shown with the unchecked acceptance box when the chosen country requires consent.";
                        };
                        readonly language: {
                            readonly type: "string";
                            readonly title: "Language";
                            readonly description: "Language the text is written in (for example en or pt-BR).";
                            readonly maxLength: 10;
                        };
                    };
                };
            };
        };
        readonly uniqueKeys: readonly [readonly ["version"]];
    };
    export type OnboardingEntityPrivacyTextType = typeof onboardingEntityPrivacyText;
    export default onboardingEntityPrivacyText;
}
declare module "_102021_/l2/agentMaterializeL1/testing/obligations" {
    /**
     * Authenticated route cases (m1_27). The oracle is read from the L2 contract of the
     * route, the access grants and the authority map; never from the emitted handler. A
     * case with authorities needs a test identity the runtime provisions. Kinds the monitor can
     * already run (identity per case, runtime m1_35 item 2) leave here for the catalog. own/other,
     * disclosure and rollback stay, with the reason on the gap. The memory harness (testing/fixture.ts,
     * m1_28) still runs what stays against the emitted code.
     * A grant proves behaviour; it is not a rule id (d1_26 r2, m1_10), so `ruleId` stays null.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1CaseCaller } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    import { type DisclosureNode } from "_102021_/l2/helpers/l1Defs/disclosure";
    /** Runtime proof: credential -> actor -> personEntity and the test identities are the runtime's. */
    export const M1_OBLIGATION_BLOCKER: "RUNTIME_IDENTITY_PENDING";
    export const M1_OBLIGATION_OWNER: "runtime 102034";
    /** "Nothing written" after a failed command: the memory runtime does not undo (102034 runInTransaction); only Postgres proves it. */
    export const M1_OBLIGATION_BLOCKER_POSTGRES: "POSTGRES_ONLY";
    export const M1_OBLIGATION_OWNER_POSTGRES: "runtime 102034 (DATABASE_URL_TEST)";
    export type M1ObligationKind = 'contract' | 'minimalInput' | 'noIdentity' | 'own' | 'other' | 'disclosure' | 'shape' | 'success' | 'rollback';
    /**
     * Kinds the monitor runs once a declared actor without an identity is blocked, never anonymous
     * (runtime m1_35 item 2). The others stay obligations: own/other need a row owned by that actor,
     * disclosure needs nested `observation.fields`, rollback only Postgres proves.
     */
    export const M1_MONITOR_CASE_KINDS: readonly ["contract", "minimalInput", "noIdentity", "shape", "success"];
    /** False only when identity-per-case is closed and the monitor can run this kind. */
    export function obligationStays(kind: M1ObligationKind, identityClosed: boolean): boolean;
    /** Why a kind is not a catalog case. Empty when the monitor can run it. */
    export function obligationStayText(kind: M1ObligationKind): string;
    /**
     * Actor the fixture binds: `member` holds the role, `owner` owns the addressed rows,
     * `other` holds the same role and owns none of them, `none` has the authority and no identity.
     */
    export type M1ObligationIdentity = 'member' | 'owner' | 'other' | 'none';
    export interface M1ObligationExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: null;
        /** Contract leaves no route grant discloses. */
        forbiddenPaths: string[];
        /** Contract paths every route grant discloses. A returned leaf outside them is a leak. Empty: not checked. */
        allowedPaths: string[];
        /** Every returned row carries the bound actor id in this field. */
        isolatedActorField: string | null;
    }
    export interface M1Obligation {
        caseId: string;
        kind: M1ObligationKind;
        routine: string;
        grantIds: string[];
        actorRef: string;
        identity: M1ObligationIdentity;
        caller: M1CaseCaller;
        /** Contract input members. The body holds the required ones, minus `omitted`. */
        input: {
            required: string[];
            optional: string[];
            omitted: string[];
        };
        mutating: boolean;
        expect: M1ObligationExpect;
        /** Refs the oracle was read from. A change in any of them invalidates the case. */
        sources: string[];
        blocker: typeof M1_OBLIGATION_BLOCKER | typeof M1_OBLIGATION_BLOCKER_POSTGRES;
        owner: typeof M1_OBLIGATION_OWNER | typeof M1_OBLIGATION_OWNER_POSTGRES;
        /** Required input paths that address a stored field. Value is always `<seedRef>`. */
        params: Record<string, string>;
        /** `<Entity>.<field>` for each key of `params`, from the usecase or the contract meta. */
        paramFieldRefs: Record<string, string>;
    }
    export interface M1ObligationObservation {
        ok: boolean;
        status: number;
        errorCode: string | null;
        data: unknown;
        /** Identity the runner bound for this case; '' for `none`. */
        actorId: string;
    }
    export interface RouteRef {
        controller: M1Definition;
        defPath: string;
        route: string;
        kind: string;
        grantIds: string[];
        /** The L2 contract file and its route interface. '' on a v1 handler, which is refused. */
        contractPath: string;
        contractInterface: string;
    }
    /** `gaps`: visible lines that go with the obligations (a command with one usecase has no rollback case). */
    export type RouteObligations = {
        obligations: M1Obligation[];
        gaps: string[];
    } | {
        gap: string;
    };
    export function routeObligations(ref: RouteRef, defs: ReadonlyMap<string, M1Definition>, texts: Readonly<Record<string, string>>): RouteObligations;
    interface RequestOutput {
        key: string;
        entity: string;
        fields: string[];
        /** The classified paths of the request tree (d1_61). Absent in a def with the flat `outputs`. */
        disclosure?: DisclosureNode[];
    }
    /**
     * Members of an inline type literal (`{ a: T; b?: { c: U } }`). Paths are dotted; a path is
     * required when it has no `?` of its own (as `contractMembers`). Null when the text is not one.
     */
    export function literalMembers(source: string): {
        required: string[];
        allowedPaths: string[];
    } | null;
    /**
     * Written apart from the controller emitter on purpose. `fullRecord` discloses every
     * contract path; `fieldsOnly`/`summaryOnly` the `<entityId>.` allowed fields and what is
     * under them; any other mode, or a grant that is not declared, discloses nothing.
     */
    export function disclosure(output: Pick<RequestOutput, 'entity' | 'fields' | 'disclosure'>, grants: readonly Record<string, unknown>[], entityDefinition?: (entity: string) => unknown): {
        allowed: string[];
        forbidden: string[];
    };
    /** '' when the observation meets the obligation; otherwise the first difference. */
    export function obligationMiss(obligation: M1Obligation, observation: M1ObligationObservation): string;
    /**
     * Hash of every source ref; an unreadable ref is `absent` and invalidates its cases. A def is
     * hashed by its semantic hash, so the run rewriting its status does not move the oracle; any
     * other source (an L2 contract) by its content.
     */
    export function obligationSourceHashes(obligations: readonly M1Obligation[], texts: Readonly<Record<string, string>>): Promise<Record<string, string>>;
    /** Cases whose oracle read a source that changed or went missing. The others keep their proof. */
    export function staleObligations(obligations: readonly M1Obligation[], before: Readonly<Record<string, string>>, after: Readonly<Record<string, string>>): string[];
}
declare module "_102021_/l2/agentMaterializeL1/testing/verify" {
    /**
     * Classifies one batch against the catalog. Stage comes from the handler
     * registered by m1_01. An unstructured exception or a broken compile is
     * never expected-red.
     */
    import type { MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import type { MaterializeHandler, M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    import { type M1ScenarioCase } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    export const M1_CHECKPOINT_SCHEMA: "2026-09-25-m1-checkpoint-v1";
    export const M1_CHECKPOINT_BUDGET_MS: number;
    export const M1_VERDICTS: readonly ["passed", "expectedRed", "failed", "blocked", "skipped", "inconclusive"];
    export type M1Verdict = typeof M1_VERDICTS[number];
    export const M1_BROKEN: readonly ["none", "compile", "import", "transport"];
    export type M1Broken = typeof M1_BROKEN[number];
    /** What one case did. The caller fills this. This module does not call a database. */
    export interface M1Observation {
        caseId: string;
        durationMs: number;
        broken: M1Broken;
        thrown: boolean;
        skipped: boolean;
        inconclusive: boolean;
        blocked: boolean;
        blockOwner: string;
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        fields: string[];
        rowActorIds: string[];
        reason: string;
    }
    export interface M1Evidence {
        caseId: string;
        verdict: M1Verdict;
        errorCode: string | null;
        status: number | null;
        durationMs: number;
        detail: string;
    }
    export interface M1CheckpointCounts {
        passed: number;
        expectedRed: number;
        failed: number;
        blocked: number;
        skipped: number;
        inconclusive: number;
    }
    export interface M1Checkpoint {
        schemaVersion: typeof M1_CHECKPOINT_SCHEMA;
        runId: string;
        inputHash: string;
        commit: string;
        stage: M1HandlerStage;
        handlerId: string;
        startedAt: string;
        finishedAt: string;
        budgetMs: typeof M1_CHECKPOINT_BUDGET_MS;
        counts: M1CheckpointCounts;
        durationsMs: {
            total: number;
        };
        ready: boolean;
        accepted: boolean;
        evidence: M1Evidence[];
        nextAction: string;
        monitor: {
            delivered: boolean;
            error: string | null;
        };
    }
    /** Verification request. The handler and the read port belong to m1_01. */
    export interface MaterializeVerificationRequest {
        handler: MaterializeHandler;
        io: MaterializeReadIo;
        catalogRef: string;
        /** When set, only this artifact's scenarios are scored. An empty match is not a failed batch. */
        artifactId?: string;
        observations: readonly M1Observation[];
        runId: string;
        commit: string;
        startedAt: string;
        finishedAt: string;
        monitorError: string | null;
    }
    export function checkpointDue(elapsedMs: number, batchClosed: boolean): boolean;
    export function classifyCase(stage: M1HandlerStage, item: M1ScenarioCase, observation: M1Observation | undefined): M1Evidence;
    export function verifyBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    /**
     * The agent's own gate (m1_34). The agent runs in the browser and does not run a case, so a case
     * with no observation and a predicted ok/status decide nothing: the case verdict is the monitor's
     * (m1_35). What blocks is only what the agent sees without running: a broken compile or import, an
     * unstructured exception, and a def gap with an owner (held). The catalog checks stay fail-closed.
     */
    export function gateBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    export function noteMonitorFailure(report: M1Checkpoint, error: string): M1Checkpoint;
}
declare module "_102021_/l2/helpers/planPostprocess/usedRemoved" {
    import type { D1InputArtifacts } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /** A `toRemove` usecase a contract route still calls, with the entity and operation from the snapshot. */
    export interface UsedRemovedUsecase {
        id: string;
        routes: string[];
        entity: string;
        operation: string;
    }
    /**
     * Drop usecase rows from `removed`, then a removed id that shows up in `selection.requests[].uses`
     * is still required. `entity` and `operation` come from `selection.usecases`.
     */
    export function usedRemovedUsecases(identity: {
        project: number;
        moduleName: string;
    }, artifacts: D1InputArtifacts): UsedRemovedUsecase[];
}
declare module "_102021_/l2/agentNewReleaseL1/helpers/keptUsecases" {
    import type { D1InputArtifacts } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import { usedRemovedUsecases } from "_102021_/l2/helpers/planPostprocess/usedRemoved";
    export { usedRemovedUsecases };
    /** A `toRemove` usecase a contract route still calls. `routes` are the request routes. */
    export interface KeptUsecase {
        id: string;
        routes: string[];
    }
    /** Defect notice: the postprocess left a `toRemove` usecase that a route still calls. */
    export function keptLines(kept: readonly KeptUsecase[]): string[];
    /** `backend` and `effort` parsed as objects. Anything else cannot host the oracle. */
    export function plansAreReadable(artifacts: D1InputArtifacts): boolean;
}
declare module "_102021_/l2/agentNewReleaseL1/helpers/undo" {
    import { type Ns5FileInfo } from "_102035_/l2/solution/fs";
    export interface PreparedRecord {
        at: string;
        moved: string[];
        saved: string[];
        plannerAbsent: boolean;
        /** Usecases left out of `removed` because a contract route still calls them. */
        kept?: Array<{
            id: string;
            routes: string[];
        }>;
    }
    export type UndoOutcome = {
        ok: true;
    } | {
        ok: false;
        text: string;
    };
    /** Drop what `/run` wrote, put `_old` back, restore the three `l4` files, then remove `_old`. */
    export function undoPrepared(moduleName: string): Promise<UndoOutcome>;
    export function removeIndexed(info: Ns5FileInfo): Promise<void>;
}
declare module "_102021_/l2/agentNewReleaseL1/helpers/compare" {
    export type CompareOutcome = {
        ok: true;
        text: string;
    } | {
        ok: false;
        kind: 'refused' | 'failed';
        text: string;
    };
    /** `@@agentNewReleaseL1 <module> /compare`. Restores the plan on every path and drops `_old` last. */
    export function compareModule(moduleName: string): Promise<CompareOutcome>;
    /** Parsed definition without model prose (`doc` at any depth) and without the envelope `status`. Keys are sorted. */
    export function structureOf(source: string): unknown;
}
declare module "_102021_/l2/agentNewReleaseL1/helpers/prepare" {
    export type PrepareOutcome = {
        ok: true;
        text: string;
    } | {
        ok: false;
        kind: 'refused' | 'failed';
        text: string;
    };
    /** `@@agentNewReleaseL1 <module>`: move `l1/<module>` aside and write a creation copy of the plan. */
    export function prepareModule(moduleName: string): Promise<PrepareOutcome>;
}
declare module "_102021_/l2/helpers/planPostprocess/correctPlan" {
    import type { UsedRemovedUsecase } from "_102021_/l2/helpers/planPostprocess/usedRemoved";
    export interface PlanCorrection {
        usecase: string;
        from: 'toRemove';
        to: 'done';
        reason: 'exists in l1';
        routes: string[];
    }
    export interface CorrectedPlan {
        backend: Record<string, unknown>;
        effort: Record<string, unknown>;
        corrections: PlanCorrection[];
    }
    /** Put a `toRemove` usecase that a route still calls back into `usecases` as `done`. Other kinds stay. */
    export function correctPlan(input: {
        moduleName: string;
        backend: Record<string, unknown>;
        effort: Record<string, unknown>;
        used: readonly UsedRemovedUsecase[];
    }): CorrectedPlan;
}
declare module "_102021_/l2/helpers/planPostprocess/postprocess" {
    import { type PlanCorrection } from "_102021_/l2/helpers/planPostprocess/correctPlan";
    export type PostprocessOutcome = {
        ok: true;
        corrections: PlanCorrection[];
        text: string;
    } | {
        ok: false;
        reason: string;
    };
    /** Before prepare: fix pool plans and always leave `postprocess.json`, including an empty correction list. */
    export function postprocessPlan(moduleName: string): Promise<PostprocessOutcome>;
}
declare module "_102021_/l2/agentNewReleaseL1/helpers/report" {
    import { type Ns5FileInfo } from "_102035_/l2/solution/fs";
    export const NEW_RELEASE_USAGE = "Usage: @@agentNewReleaseL1 <module> [/compare]";
    export type NewReleaseInvocation = {
        ok: true;
        module: string;
        compare: boolean;
    } | {
        ok: false;
        help: string;
    };
    /** `<module>` prepares. `<module> /compare` is the second call. Any other flag is the usage line. */
    export function parseNewReleaseInvocation(userPrompt: string): NewReleaseInvocation;
    /** `<unit>.defs.ts` → `<unit>.ts`. Any other path is not a generated source. */
    export function sourcePathOfDef(defPath: string): string | null;
    /** `deleteFile` failed. Names the path and lists the files already deleted. */
    export function reportDeleteFailed(path: string, error: string, deleted: readonly string[]): string;
    /** The step status is always `completed`. The prefix is what the reader sees. */
    export type ReleaseStatusKind = 'done' | 'refused' | 'failed';
    export function releaseStatusText(message: string, kind: ReleaseStatusKind): string;
    /** Short motive for the step title. The full text stays in the step result. */
    export function releaseStepTitle(text: string): string;
    export type ReleaseRunPhase = 'effort' | 'plan' | 'portrait' | 'defs' | 'sources' | 'guard';
    export interface ReleaseRunPhaseLine {
        phase: ReleaseRunPhase;
        status: 'ok' | 'refused' | 'failed';
        note: string;
    }
    /** `l1/<module>/pipeline/agentNewReleaseL1/run.json`. The effort phase replaces the previous run. */
    export function runFile(moduleName: string): Ns5FileInfo;
    export function recordPhase(moduleName: string, phase: ReleaseRunPhase, status: ReleaseRunPhaseLine['status'], note: string): Promise<void>;
}
declare module "_102021_/l2/agentNewReleaseL1/agentNewReleaseL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentPlannerL1/helpers/defsSource" {
    /**
     * Pure readers of the l4/l5 defs dialects, with no platform imports, so they can be tested directly.
     * Two generators write the artifacts this agent reads: ns/ns3 emitted `} as const;`, and ns4 emits
     * `} as const satisfies <Artifact>;` over a typed import.
     */
    export type CbEntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm' | 'external' | 'derived';
    /**
     * MDM WRITE PATH — off until the general rebuild.
     *
     * The l4 already declares the intention this switch honours (`storage.target: mdm | external |
     * moduleDatabase`, `storage.mdmType`, v6 vocabulary), so reading it is not a new-vocabulary migration:
     * it would change the classification of the module Wagner is testing (run 9 of buildFlowFsm, where
     * Client/Project/InventoryItem carry `target: mdm` and FieldWorker/PlatformUser carry `target:
     * external`) the moment the next generation runs. That is exactly what the ⏸️ of the spec forbids.
     *
     * Flipping this to `true` moves four things at once, which is why it is one constant and not four:
     *   1. `classifyEntityKind` stops mapping `mdm + moduleOwned` to `core` and starts honouring
     *      `storage.target` — so an MDM entity gets no local domain entity, port, adapter or table, and an
     *      `external` one gets none of those and no seeds either;
     *   2. the seed planner routes those entities to `mdmEntities` (102034 registry) instead of
     *      `localTables`, and drops `external` entities from the plan entirely;
     *   3. the usecase item carries `mdmWrites` (mdmType + subtype + idField), so create/update/delete of
     *      master data is generated against `ctx.mdm` — the surface skills/applicationUsecase.md already
     *      documents — instead of a local port;
     *   4. validate-all blocks on a local persistence/port/domain artifact for an MDM entity instead of
     *      only warning about it (`collectPersistencePolicyIssues`).
     *
     * The order of the general rebuild is in the spec: ns4 vocabulary first (`party`, `platformUserId`),
     * then this flag, then `/rebuild all`.
     *
     * FLIPPED ON 2026-08-24 by Wagner's decision, with the next run being a `/rebuild all`. The two
     * prerequisites above were already met. Note what the flip does NOT do: it changes how the NEXT
     * generation classifies entities, so a module generated while it was `false` keeps its local tables
     * until it is rebuilt. There is no partial reversal — a module is generated in one shape or the other.
     */
    export const MDM_WRITE_PATH_ENABLED = true;
    /** What `storage` declares about an entity: where it lives, and under which master-data type. */
    export interface CbEntityStorage {
        target: string;
        scope: string;
        mdmType: string;
        idField: string;
    }
    export function readEntityStorage(parsed: Record<string, unknown>): CbEntityStorage;
    /** Schema string the NS E4 emits for ontology v7 (`n04`, 2026-09-08). */
    export const CB_ONTOLOGY_SCHEMA_V7 = "2026-09-08-ns4-ontology-v7";
    /** Named scan error when a v7 entity omits `storage.idField`. Never fall back to a name suffix. */
    export const CB_SCAN_ID_FIELD_REQUIRED = "CB_SCAN_ID_FIELD_REQUIRED";
    /**
     * l4 ontology schema generation. v7 carries `mdmSubtype` / `role` / `displayField` / required
     * `storage.idField`. Anything older is v6 and is read until the module is regenerated (2026-09-08).
     */
    export function ontologyDefsVersion(parsed: Record<string, unknown>): number;
    export type CbLifecycleReachedBy = 'actor' | 'command' | 'time';
    export interface CbLifecycleStateDecl {
        state: string;
        reachedBy: CbLifecycleReachedBy;
        ruleRef?: string;
    }
    /** Bare string = actor. Time states are computed on read and never persisted by default. */
    export function readLifecycleStates(value: unknown): CbLifecycleStateDecl[];
    export interface CbOntologyEntityRead {
        storage: CbEntityStorage;
        mdmSubtype: string;
        role: string;
        displayField: string;
        defsVersion: number;
        scanError?: {
            code: string;
            message: string;
        };
    }
    /**
     * v7 fields on an ontology entity. v6 modules keep compiling: missing `mdmSubtype`/`role`/
     * `displayField` are empty strings, and a missing `idField` is not a scan error until v7.
     */
    export function readOntologyEntity(parsed: Record<string, unknown>): CbOntologyEntityRead;
    export interface CbOntologyRelationshipRead {
        fromEntity: string;
        toEntity: string;
        type: string;
        persistenceMode: string;
        fromFieldIds: string[];
        toFieldIds: string[];
    }
    /** `ontology/index.defs.ts` `relationships[]` — the only FK source on v7. */
    export function readOntologyRelationships(index: Record<string, unknown>): CbOntologyRelationshipRead[];
    /** Foreign-key field ids declared for `entityId` on either end of a relationship. */
    export function fkFieldIdsForEntity(entityId: string, relationships: ReadonlyArray<{
        fromEntity: string;
        toEntity: string;
        fromFieldIds?: readonly string[];
        toFieldIds?: readonly string[];
    }>): Set<string>;
    /**
     * The kind this agent generates from, deciding between the two vocabularies AND the two policies.
     *
     * With the write path OFF the answer is exactly what it has always been (`entityKindOf`), so a run of
     * the current module is byte-identical. With it ON, `storage.target` — the field that actually carries
     * the l4 intention — wins over the pair kind/ownership: `mdm` means master data owned by 102034 (the
     * module writes it THROUGH the facade), and `external` means an identity that lives outside this
     * product (a platform user), which must never become a local table and must never be seeded.
     */
    /**
     * What a caller knows about an entity. `storage` is PARTIAL because only `readEntityStorage` produces the
     * complete block — a caller that has just `{ target }` (a fixture, a scan of an older l4) asks the same
     * question and must not have to invent the other three fields.
     */
    export interface CbEntityClassification {
        kind: string;
        ownership?: string;
        storage?: Partial<CbEntityStorage>;
    }
    /** A declaration that contradicts itself, for the scan to announce instead of resolving in silence. */
    export function contradictoryStorageDeclaration(input: CbEntityClassification): string;
    export function classifyEntityKind(input: CbEntityClassification, mdmWritePath?: boolean): CbEntityKind;
    export function parseDefsSource(content: string): unknown;
    /**
     * Replace only the value of a defs file, keeping everything the generator wrote around it — the
     * header, the `import type`, the `satisfies` and the trailing exports. The todo files belong to the
     * generator that emitted them; this agent only flips a status inside them.
     */
    export function replaceDefsValue(content: string, value: unknown): string | null;
    /**
     * The handler vocabulary is `query | command`, but `operation.kind` speaks the generator's dialect:
     * ns/ns3 said create|update|query|view, ns4 says list|getById|create|update|delete|transition|
     * commandInput. Only reads are queries; everything else writes.
     */
    export function handlerKindOf(opKind: string): 'query' | 'command';
    /**
     * ns4 classifies a read-model as `projection`, which is what `metric` already meant here: not an
     * aggregate root by itself, but still backed by a table and seeds WHEN an operation reads it (that
     * is how a dashboard answers at runtime). Casting it silently would land on `core` and give a
     * projection nobody queries a table of its own.
     *
     * `mdm` means two different things in the two vocabularies, and the difference is the OWNERSHIP:
     * here it has always meant "master data read by id through 102034 — no local table, no port, never
     * written locally", while ns4 writes `mdm` + `ownership: moduleOwned` for master data THIS MODULE
     * owns and publishes, and compiles create/update/delete over it. Read as external, those operations
     * have nowhere to live: run 8 of buildFlowFsm generated 4 stub usecases (`functions: []`) for
     * Client/InventoryItem/Project and the final gate failed with 12 "export not found". Owned master
     * data is a local aggregate — table, port, CRUD, seeds — which is exactly `core`.
     */
    export function entityKindOf(kind: string, ownership?: string): CbEntityKind;
    /** A ns4 workflow: the lifecycle of one entity, with states and transitions and no operations. */
    export function isEntityLifecycle(parsed: Record<string, unknown>): boolean;
    /**
     * The module a `TS2792 Cannot find module '<path>'` names, or '' for any other diagnostic.
     *
     * A generated file that imports a platform contract of another project (`/_102034_/l1/...`) compiles
     * against a Monaco model this agent borrows for the compile. When the borrow silently fails the
     * diagnostic is indistinguishable from a real broken import — and the seed run of 2026-08-16 died on
     * one, after two earlier waves had compiled the very same file. Recognizing the shape is what lets
     * the caller ask "does this file actually exist?" instead of blaming the plan.
     */
    export function phantomModulePathOf(diagnostic: string): string;
    /** `/_102034_/l1/server/.../contracts.js` -> the file coordinates of its source. */
    export function mlsImportPathParts(path: string): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
    } | null;
    /**
     * The cross-project module a resolution diagnostic names, whatever the compiler called it
     * (TS2792 "cannot find module … did you mean to set moduleResolution", TS2307 "cannot find module").
     *
     * Used where the file under compile is written by THIS agent from a fixed template — the seeds. There
     * the import is not a claim the LLM made (it only plans data rows), so a module that does not resolve
     * is an environment fact, and asking `mls.stor.files` whether the target exists measures the wrong
     * thing: it measures whether the session indexed the other project, not whether the plan is wrong.
     */
    export function aliasModuleResolutionPathOf(diagnostic: string): string;
    /**
     * Monaco's "model already exists" — raised by `addModels` for a file whose model IS loaded, under a
     * registry key this agent's guard does not compute. The goal of the call (a usable model) is already
     * met, so the caller treats it as success; reading it as a failure logged the same warning forever
     * and left the import unborrowed.
     */
    export function isModelAlreadyExistsError(message: string): boolean;
    const TODO_STATUS_FIELDS: readonly ["status", "statusBackend"];
    export function todoOwnerType(raw: string): 'operation' | 'workflow' | '';
    /** The field the file actually uses, so the write-back lands where the read came from. */
    export function todoStatusField(raw: Record<string, unknown>): typeof TODO_STATUS_FIELDS[number] | '';
    /** The key both sides of a read-back agree on: the owner kind AFTER the dialect alias, plus its id. */
    export function todoOwnerKey(kind: string, id: string): string;
    export interface CbTodoDivergence {
        /** `operation:listBusinessHours` — todoOwnerKey of the owner that does not match. */
        key: string;
        expected: string;
        /** The status the source carries, or `<missing>` when the owner is not in it at all. */
        found: string;
    }
    /**
     * Compare the statuses a run BELIEVES it wrote against the ones a todoBackend source actually carries.
     * Pure on purpose: this is the comparator behind the finalize read-back, and it has to be testable
     * without a stor, a model or a browser.
     *
     * Returns `null` when the source cannot be parsed at all — for the caller that is not "no divergence",
     * it is "unreadable", which is its own kind of failure.
     */
    export function todoStatusDivergences(content: string, expected: ReadonlyMap<string, string>): CbTodoDivergence[] | null;
    /**
     * Which l5 todoBackend file the finalize read-back should open. `moduleName` empty keeps the
     * historical first-file-in-the-project behaviour (single-module runs). Folder is compared by
     * equality, never substring: a module `todo` must not match `todoAvancado`.
     *
     * `none` = this project has no todoBackend at all (caller reports skip).
     * `module-missing` = other modules have a file, this one does not (the run wrote owners whose
     * file vanished — not the same as skip).
     */
    export type CbTodoReadBackPick = {
        kind: 'file';
        folder: string;
        ref: string;
    } | {
        kind: 'none';
    } | {
        kind: 'module-missing';
        moduleName: string;
        ref: string;
    };
    export function pickTodoBackendReadBack(folders: readonly string[], moduleName?: string): CbTodoReadBackPick;
    /**
     * Which l5 todoBackend file a status write should mutate. Prefer the file whose folder is the
     * owner's module; if that file exists but does not contain the owner, do NOT fall through to
     * another module (shared ids like `createTask` would corrupt the neighbour). Empty moduleName
     * keeps the historical search-by-owner-identity.
     */
    export function selectTodoBackendFileForStatusWrite<T extends {
        folder: string;
        content: string;
    }>(files: readonly T[], owner: {
        kind: string;
        id: string;
        moduleName: string;
    }): T | undefined;
    /**
     * MDM semantics the ns4 catalogue attaches to an operation whose entity declares
     * `storage.target: 'mdm'` (`Ns4E8MdmSemantics` -> `Ns4ClassicOperation.mdm`). Measured on
     * `mls-102047/l4/petShop/operations/`:
     *
     *   inactivateCustomer.defs.ts -> `"mdm": { "lifecycle": "inactivate" }`
     *   listCustomer.defs.ts       -> `"mdm": { "activeFilterInput": "includeInactive",
     *                                           "situationOutput": "active" }`
     *
     * It exists because master data is NEVER deleted: the tier-1 catalogue emits the inactivate/reactivate
     * pair instead of a delete, the list hides inactive records by default, and the situation shown on
     * screen derives from the MDM index status — never from an invented local `active` field.
     *
     * `activeFilterInput` names an input that does NOT exist in the operation's `inputs[]` (the ns4 gate
     * requires every input fieldRef to resolve to a real ontology field, and `includeInactive` is not one),
     * so the CB is what has to materialize it. See `synthesizeMdmInputs` in cbShared.
     */
    export interface CbOwnerMdm {
        /** 'inactivate' | 'reactivate' — the cadastral pair that replaces delete for master data. */
        lifecycle?: string;
        /** Name of the boolean input that opts INTO seeing inactive records. */
        activeFilterInput?: string;
        /** Name of the derived output field carrying the situation (from the index status). */
        situationOutput?: string;
    }
    /**
     * Absent (not empty) when the operation carries no `mdm` block — the l4s that predate the block must
     * produce byte-identical owners, which is what makes this readable without touching the write-path flag.
     */
    export function readOwnerMdm(parsed: Record<string, unknown>): CbOwnerMdm | undefined;
    /** Is this the cadastral pair (as opposed to an ordinary MDM update)? */
    export function isMdmLifecycle(mdm: CbOwnerMdm | undefined): boolean;
    /**
     * Pin the l4 `mdm` block onto the usecase defs the model just returned. The model implements the
     * body; this block is not its to invent or drop. Without the pin, `saveDefs` writes the model
     * output and `collectMdmLifecycleIssues` (which reads `data.mdm` of that defs) stays blind — three
     * petShop runs in a row emitted no-op lifecycles with the agent already correct in the build.
     */
    export function pinUsecaseL4Mdm(result: Record<string, unknown>, ownerMdm: CbOwnerMdm | undefined): void;
    /** Structural mirror of cbShared.CbOperationInput — declared here so this module stays platform-free. */
    export interface CbMdmOperationInput {
        inputId: string;
        fieldRef: string;
        type?: string;
        required: boolean;
        source: string;
        description: string;
    }
    /**
     * The one input the l4 CANNOT declare. `mdm.activeFilterInput` names a boolean flag (`includeInactive`)
     * that opts into seeing inactive records, but the ns4 gate requires every input `fieldRef` to resolve to
     * a real ontology field — and `includeInactive` is not a field of anything. Measured on the evidence:
     * `listCustomer.defs.ts` declares `activeFilterInput: 'includeInactive'` with `inputs: []`.
     *
     * So the CB materializes it here, at the SINGLE place owners are read, instead of only in the usecase
     * prompt: the http controller derives its boundary contract from `owner.inputs` too, and an input the
     * controller never learned about is a flag the caller cannot pass.
     *
     * `required: false` on purpose — the default behaviour is active-only, and a required flag would make
     * every existing caller of the list illegal.
     */
    export function synthesizeMdmInputs(inputs: CbMdmOperationInput[], mdm: CbOwnerMdm | undefined): CbMdmOperationInput[];
}
declare module "_102021_/l2/agentPlannerL1/helpers/l1Inventory" {
    /** agentChangeBackend was deleted (p4_15); this is now the single source for the owner status enum. */
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export interface L1InventoryField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface L1InventoryFunction {
        name: string;
        input: L1InventoryField[];
        output: L1InventoryField[];
    }
    export interface L1InventoryUsecase {
        usecaseId: string;
        file: string;
        /** Empty when the def on disk is still the pre-d1_74 shape (no entityId/operation). */
        entityId?: string;
        operation?: string;
        transitionRef?: string;
        functions: L1InventoryFunction[];
        ports: string[];
        rulesApplied: string[];
        statusBackend: OwnerStatus | '';
    }
    export interface L1InventoryPort {
        portId: string;
        entity: string;
    }
    export interface L1InventoryTable {
        tableId: string;
        entity: string;
    }
    export interface L1Inventory {
        routes: string[];
        usecases: L1InventoryUsecase[];
        ports: L1InventoryPort[];
        tables: L1InventoryTable[];
        present: boolean;
    }
    /**
     * Snapshot of the existing l1 of `module` in `project`. Pure over `mls.stor`.
     * No l1 (and no backend block) ⇒ `present: false` and empty lists.
     * Status comes from `l5/<mod>/todoBackend.defs.ts owners[]`, never from `status: draft` in the defs.
     */
    export function readL1Inventory(project: number, moduleName: string): Promise<L1Inventory>;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Core" {
    import { type Ns5FileInfo } from "_102035_/l2/solution/fs";
    import { type PoolMessage, type PoolTraceLine } from "_102035_/l2/solution/pool";
    import type { Ns5PipelineStatus, Ns5PipelineStepState } from "_102035_/l2/solution/types";
    import { type L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    export const P1_FLOW_ID: "agentPlannerL1";
    export const P1_FLOW_VERSION: "2026-09-20-p1-flow-v1";
    export const P1_AGENT_NAME: "agentPlannerL1";
    export const P1_PIPELINE_SCHEMA_VERSION: "2026-09-20-p1-pipeline-v1";
    export const P1_NEEDS_SCHEMA: "2026-09-21-p2-needs-v1";
    export const P1_DEVICE: "web";
    export type P1Device = typeof P1_DEVICE;
    /** Steps the current flow.json actually runs. */
    export const P1_FLOW_STEP_IDS: readonly ["entry10", "plan20"];
    export const P1_STEP_IDS: readonly ["entry10", "plan20"];
    export type P1FlowStepId = typeof P1_FLOW_STEP_IDS[number];
    export type P1StepId = typeof P1_STEP_IDS[number];
    /** Last step of `docs/flow.json` — plan20 closes the pipeline. */
    export const P1_FLOW_LAST_STEP_ID: P1FlowStepId;
    export const P1_STEP_TITLES: Record<P1StepId, string>;
    export const P1_STEP_DEPENDS_ON: Record<P1StepId, readonly string[]>;
    /** Same default as `PL_DEFAULT_CANDIDATE_REL` in `plCore.ts`. */
    export const P1_DEFAULT_CANDIDATE_REL: "tobe/plan";
    export interface P1ParsedInvocation {
        module: string;
        /** Resolved `l4/` folder when `/candidate` is present; otherwise `''`. */
        candidate: string;
        /** True when the `/candidate` token was present, even if the path was refused. */
        hasCandidate: boolean;
    }
    export type P1EntrySource = {
        kind: 'hand';
        moduleName: string;
        candidate?: string;
    } | {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate?: string;
    };
    export interface P1Needs {
        schemaVersion: string;
        moduleName: string;
        device?: string;
        pages?: unknown[];
    }
    export interface P1PipelineState {
        schemaVersion: typeof P1_PIPELINE_SCHEMA_VERSION;
        flowId: typeof P1_FLOW_ID;
        moduleName: string;
        status: Ns5PipelineStatus;
        awaitingStep?: P1StepId;
        steps: Partial<Record<P1StepId, Ns5PipelineStepState>>;
        thread: string;
        round: number;
        messageFile: string;
        sourceMessages: string[];
        needsFile: string;
        inventory: L1Inventory;
        pool?: PoolTraceLine[];
        /**
         * Display paths of the duplicates consumed with `messageFile`. The pool enum has no
         * `superseded` outcome yet, so their trace line is `processed` and this list names them.
         */
        supersededMessages?: string[];
        updatedAt: string;
    }
    export interface P1LoadedEntry {
        moduleName: string;
        file: Ns5FileInfo;
        message: PoolMessage;
        sourceMessages: string[];
        needsFile: Ns5FileInfo;
        needs: P1Needs;
    }
    export type P1LoadResult = P1LoadedEntry | {
        refusal: string;
    };
    export type P1ExecuteResult = {
        pipeline: P1PipelineState;
        file: Ns5FileInfo;
        message: PoolMessage;
    } | {
        refusal: string;
    };
    export function isP1StepId(value: string): value is P1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    /** Copied from `plCore.ts:111`. `..` in the relative path returns `''`. */
    export function resolveCandidateFolder(moduleName: string, relativePath?: string): string;
    /**
     * Point `moduleFolder` at `candidate`, or restore the canonical root when it is
     * empty. `..` is a refusal, not a silent "no candidate". Always call this before
     * reading l4 / pool / pipeline so a previous task cannot leak its root.
     */
    export function applyP1CandidateRoot(moduleName: string, candidate: string): string;
    /**
     * Maps child planIds back to the owning step. Done-anchors stay unmatched so they
     * are not dispatched. A step prompt `{ moduleName, thread, file }` (pool dispatch)
     * is entry10.
     */
    export function ownerStepId(planId: string, prompt?: string): P1StepId | '';
    export function isPoolEntryPrompt(prompt?: string): boolean;
    export function parseP1Invocation(value: string): P1ParsedInvocation;
    export function p1InvocationRefusal(invocation: P1ParsedInvocation): string;
    export type P1StepPrompt = {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate: string;
    } | {
        kind: 'entry';
        moduleName: string;
        candidate: string;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseP1StepPrompt(prompt: string): P1StepPrompt;
    /**
     * `l4/<module>/pool/l1/pipeline.json` — the planner trace lives in its own box (27/09:
     * planning only writes the pool). Not a pool message: `listPoolBox` ignores the name.
     */
    export function p1PipelineFile(moduleName: string): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/needs.json` — written by L2, read here. */
    export function p1NeedsFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/l4diff.json` — written by L4 (p4_09). Absent is valid. */
    export function p1L4DiffFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l2/web/backend.json` — written by plan20. Not a pool message. */
    export function p1BackendFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    export function createP1Pipeline(moduleName: string, message: PoolMessage, messageFile: string, now: Date, sourceMessages: string[], needsFile: string, inventory: L1Inventory): P1PipelineState;
    export function createP1AgentStep(stepId: P1StepId, moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep;
    export function buildP1PlannedSteps(moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep[];
    export function isP1PoolMessageFile(shortName: string): boolean;
    export const P1_ONLY_IMPLEMENT = "pool/l1 has no estimate message; implement belongs to agentDefsL1, not to the planner";
    export function p1DifferentRequestsRefusal(count: number): string;
    export function loadP1Entry(source: P1EntrySource): Promise<P1LoadResult>;
    export function writeP1Entry(loaded: P1LoadedEntry, now: Date): Promise<P1PipelineState>;
    /**
     * Consume the messages this run read at entry (`sourceMessages`), never a fresh listing:
     * a message that arrived during the run stays. Trace first, then delete — a failure before
     * the trace keeps the message. `messageFile` is `processed`; the others are duplicates
     * listed in `supersededMessages`. Returns the display paths deleted.
     */
    export function consumeP1Messages(moduleName: string, now: Date): Promise<string[]>;
    export function executeP1Entry(source: P1EntrySource, now: Date): Promise<P1ExecuteResult>;
    export function readP1Pipeline(moduleName: string): Promise<P1PipelineState | null>;
    /** `l4/<module>/pool/l1/<stepId>-draft.json` — scratch of this box, not a pool message. */
    export function p1DraftFile(moduleName: string, stepId: P1StepId): Ns5FileInfo;
    /** Files of this agent (prompt.md, skills) live in 102021, not in the run module. */
    export function p1AgentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function readP1AgentText(folder: string, shortName: string, extension: string): Promise<string>;
    /** `complete` = every step of `flow.json` is approved. A failed pipeline stays failed. */
    export function markP1Complete(pipeline: P1PipelineState, now?: string): P1PipelineState;
    export function markP1Step(pipeline: P1PipelineState, stepId: P1StepId, next: Ns5PipelineStepState): P1PipelineState;
    export function createP1RetryStep(stepId: P1StepId, moduleName: string, kind: 'repair' | 'transport', attempt: number, extra?: Record<string, unknown>): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type P1PipelineState, type P1StepId } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    export type P1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type P1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface P1StepHooks {
        beforePromptStep?: P1StepBeforePrompt;
        afterPromptStep?: P1StepAfterPrompt;
    }
    /** Filled by later specs. A missing entry means the step is not implemented yet. */
    export const P1_STEP_HOOKS: Partial<Record<P1StepId, P1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string, prompt?: string): P1StepHooks | undefined;
    export function markAwaitingStep(pipeline: P1PipelineState, stepId: P1StepId): Promise<P1PipelineState>;
    export function p1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/contracts" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1Device } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import { type L1Operation } from "_102021_/l2/helpers/l1Defs/operations";
    import type { PoolMessage } from "_102035_/l2/solution/pool";
    import type { PoolBackendFile, PoolBackendTable, PoolNeedsFile, PoolNeedsPage, PoolNeedsRead, PoolNeedsWrite, PoolTestSupportItem, PoolUnmappedChange } from "_102035_/l2/solution/poolPlan";
    export const P1_BACKEND_SCHEMA_VERSION: "2026-09-21-p1-backend-v1.2";
    export const P1_BACKEND_ARTIFACT: "pool/l2/web/backend.json";
    export const P1_L4DIFF_SCHEMA: "2026-09-21-p4-l4diff-v1";
    export const P1_KINDS: readonly ["qry", "cmd"];
    export type P1Kind = typeof P1_KINDS[number];
    export const P1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export type P1Operation = L1Operation;
    export const P1_PLAN_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export type P1PlanStatus = typeof P1_PLAN_STATUSES[number];
    export const P1_NEEDS_FAMILIES: readonly ["mdm", "ddm", "tdm"];
    export type P1NeedsFamily = typeof P1_NEEDS_FAMILIES[number];
    export const P1_WRITE_OPERATIONS: ("custom" | "delete" | "get" | "create" | "update" | "transition" | "list")[];
    export type P1WriteOperation = typeof P1_WRITE_OPERATIONS[number];
    export const P1_REMOVED_KINDS: readonly ["usecase", "port", "table"];
    export type P1RemovedKind = typeof P1_REMOVED_KINDS[number];
    export const P1_NO_TABLE: readonly ["ok", "mdm", "none"];
    export type P1NoTable = typeof P1_NO_TABLE[number];
    export const P1_CHANGE_KINDS: readonly ["field", "rule", "grant", "transition", "process", "integration", "entity"];
    export type P1ChangeKind = typeof P1_CHANGE_KINDS[number];
    export const P1_CHANGE_OPS: readonly ["added", "changed", "removed"];
    export type P1ChangeOp = typeof P1_CHANGE_OPS[number];
    export const P1_TEST_SUPPORT_OWNERS: readonly ["L1", "runtime"];
    export type P1TestSupportOwner = typeof P1_TEST_SUPPORT_OWNERS[number];
    /**
     * needs.json as plan20 reads it (`parseP1Needs`): no `menuSchema`/`meta`, and `scope`/`operation` as tolerant as the parse.
     */
    export type P1NeedsRead = Omit<PoolNeedsRead, 'scope'> & {
        scope: string;
    };
    export type P1NeedsWrite = Omit<PoolNeedsWrite, 'operation'> & {
        operation: P1WriteOperation;
    };
    export type P1NeedsPage = Omit<PoolNeedsPage, 'reads' | 'writes'> & {
        reads: P1NeedsRead[];
        writes: P1NeedsWrite[];
    };
    export type P1NeedsView = Pick<PoolNeedsFile, 'schemaVersion' | 'moduleName' | 'device'> & {
        pages: P1NeedsPage[];
    };
    export interface P1EntityView {
        entityId: string;
        family: P1NeedsFamily;
        storageKind: string;
        storageTarget: string;
        transitions: string[];
        rules: string[];
        /** Entities this one points to by its own fk column (`relationships[].via` = `<self>.<field>`). */
        fkTargets?: string[];
        /** `transitions[].from` by transitionId. */
        transitionFrom?: Record<string, string[]>;
    }
    /** access.defs.ts actor; `personEntity` is `''` when the actor declares none. */
    export interface P1ActorView {
        actorId: string;
        personEntity: string;
    }
    export interface P1L4DiffItem {
        changeId: string;
        kind: P1ChangeKind;
        op: P1ChangeOp;
        entity: string;
        source: string;
        before: Record<string, unknown>;
        after: Record<string, unknown>;
    }
    export interface P1L4DiffFile {
        schemaVersion: typeof P1_L4DIFF_SCHEMA;
        moduleName: string;
        base: string;
        candidate: string;
        items: P1L4DiffItem[];
        unmapped: PoolUnmappedChange[];
    }
    export interface P1UnresolvedItem {
        kind: 'alias' | 'merge';
        candidateUsecaseId: string;
        entity: string;
        operation: string;
        reason: string;
    }
    export interface P1BackendAlias {
        candidateUsecaseId: string;
        existingUsecaseId: string;
        reason: string;
    }
    export interface P1BackendMerge {
        usecaseId: string;
        entity: string;
        operation: 'custom';
        ports: string[];
        replaces: string[];
        reason: string;
    }
    export interface P1BackendResolution {
        aliases: P1BackendAlias[];
        merges: P1BackendMerge[];
    }
    export interface P1PlanBackendInput {
        needs: P1NeedsView;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        now: Date;
        resolution?: P1BackendResolution | null;
        l4diff?: P1L4DiffFile | null;
        /** access.defs.ts actors; absent ⇒ every needs actor becomes a named gap. */
        actors?: readonly P1ActorView[];
    }
    export interface P1PlanBackendResult {
        file: PoolBackendFile;
        unresolved: P1UnresolvedItem[];
    }
    export function isP1Kind(value: string): value is P1Kind;
    export function isP1Operation(value: string): value is P1Operation;
    export function isP1PlanStatus(value: string): value is P1PlanStatus;
    export function isP1NeedsFamily(value: string): value is P1NeedsFamily;
    export function isP1WriteOperation(value: string): value is P1WriteOperation;
    export function isP1NoTable(value: string): value is P1NoTable;
    export function isP1ChangeKind(value: string): value is P1ChangeKind;
    export function isP1ChangeOp(value: string): value is P1ChangeOp;
    export function p1BackendSubject(moduleName: string, device?: P1Device): string;
    export function p1BackendBody(file: PoolBackendFile): string;
    export function buildP1BackendMessage(input: {
        file: PoolBackendFile;
        received: Pick<PoolMessage, 'thread' | 'round' | 'mode'>;
    }): PoolMessage;
    export function p1UsecaseId(operation: P1Operation, entity: string, transitionRef?: string): string;
    export function p1Route(moduleName: string, page: string, kind: P1Kind, usecaseId: string): string;
    export function p1PortId(entity: string): string;
    export function p1TableId(entity: string): string;
    export function parseP1Needs(value: unknown): P1NeedsView;
    export function parseP1Entity(value: unknown, indexRow?: unknown): P1EntityView | null;
    export function parseP1Actors(value: unknown): P1ActorView[];
    export function parseP1OntologyIndex(value: unknown): string[];
    export function parseP1L4Diff(value: unknown): P1L4DiffFile | null;
    export function parseP1Resolution(value: unknown): P1BackendResolution;
    /** Incomplete alias or merge items. `parseP1Resolution` still drops them; callers that must not drop in silence use this. */
    export function checkP1Resolution(value: unknown): string[];
    export function planP1Backend(input: P1PlanBackendInput): P1PlanBackendResult;
    export function normalizeP1Backend(value: unknown, fallback: P1PlanBackendInput): PoolBackendFile;
    export function buildP1BackendTool(schema: Record<string, unknown>): mls.msg.LLMTool;
    export function buildP1ResolutionSchema(): Record<string, unknown>;
    export function unwrapP1ArtifactPayload(value: unknown): unknown;
    export function stampP1Backend(file: PoolBackendFile, ctx: {
        ontology: Map<string, P1EntityView>;
        inventory: L1Inventory;
        needs: P1NeedsView;
        l4diff: P1L4DiffFile | null;
        actors: readonly P1ActorView[];
    }): PoolBackendFile;
    /**
     * Test preparation derived from needs (journey refs, page actors), access actors
     * (personEntity) and the ontology (own fk targets, lifecycle `from` of needed transitions).
     * No runtime capability is referenced here, so every item is `toCreate` with a named gap.
     */
    export function planP1TestSupport(input: {
        needs: P1NeedsView;
        ontology: Map<string, P1EntityView>;
        actors: readonly P1ActorView[];
        tables: readonly PoolBackendTable[];
    }): PoolTestSupportItem[];
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/gate" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1ActorView, type P1EntityView, type P1L4DiffFile, type P1NeedsView } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    import type { PoolBackendFile } from "_102035_/l2/solution/poolPlan";
    export interface P1BackendGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface P1BackendGateResult {
        ok: boolean;
        issues: P1BackendGateIssue[];
    }
    export function validateP1Backend(file: PoolBackendFile, needs: P1NeedsView, ontology: readonly P1EntityView[]): P1BackendGateResult;
    export function repairP1Backend(file: PoolBackendFile, needs: P1NeedsView, ontology: readonly P1EntityView[], inventory?: L1Inventory, l4diff?: P1L4DiffFile | null, actors?: readonly P1ActorView[]): PoolBackendFile;
    export function formatP1BackendGate(issues: readonly P1BackendGateIssue[]): string;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type PoolMessage } from "_102035_/l2/solution/pool";
    import { type P1PipelineState } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1ActorView, type P1BackendResolution, type P1EntityView, type P1L4DiffFile, type P1NeedsView, type P1PlanBackendResult } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    import type { PoolBackendFile } from "_102035_/l2/solution/poolPlan";
    export interface P1PlanSources {
        needs: P1NeedsView;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        pipeline: P1PipelineState;
        l4diff: P1L4DiffFile | null;
        actors: P1ActorView[];
    }
    export interface P1DeliverPlanResult {
        backend: PoolBackendFile;
        backendPath: string;
        message: PoolMessage;
        messagePath: string;
        llmCalled: boolean;
    }
    export function composeP1SystemPrompt(skillText: string, stepPrompt: string): string;
    export function buildP1PlanHumanPrompt(input: {
        sources: P1PlanSources;
        planned: P1PlanBackendResult;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function loadP1Ontology(moduleName: string): Promise<P1EntityView[]>;
    export function loadP1PlanSources(moduleName: string): Promise<P1PlanSources>;
    export function executeP1Plan(moduleName: string, now: Date, resolution?: P1BackendResolution | null): Promise<P1DeliverPlanResult>;
    export function beforeP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/agentPlannerL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry";
    import "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/helpers/effort/describeEffort" {
    import type { EffortAnswer, EffortInput, EffortPromptRequest } from "_102035_/l2/solution/poolPlan";
    /** Pure. `defs` maps each product def path to its `.defs.ts` source. `sources` maps the same path to the sibling `.ts` text; omitted keeps the previous answer. `contracts` maps pageId to L2 contract source. */
    export function describeEffortFrom(input: EffortInput, defs: Record<string, string>, sources?: Record<string, string>, contracts?: Record<string, string>): EffortAnswer;
    /** Pure. A prompt only for `rule added`; every other item is null and `describeEffort` answers it. Null when an L2 contract route already cites the rule. */
    export function effortPromptFrom(input: EffortInput, defs: Record<string, string>, contracts?: Record<string, string>): EffortPromptRequest | null;
    /** Pure. Checks the model output and builds the effort answer. A bad shape abends; it is never "nothing to do". */
    export function finishEffortFrom(input: EffortInput, defs: Record<string, string>, modelOutput: unknown, contracts?: Record<string, string>): EffortAnswer;
    /** Reads product `.defs.ts` under `l1/<module>/` from `mls.stor.files` and classifies the item. */
    export function describeEffort(input: EffortInput): Promise<EffortAnswer>;
    /** Same read as `describeEffort`. Null unless the item is `rule added`. */
    export function effortPrompt(input: EffortInput): Promise<EffortPromptRequest | null>;
    /** Same read as `describeEffort`, then `finishEffortFrom`. */
    export function finishEffort(input: EffortInput, modelOutput: unknown): Promise<EffortAnswer>;
}
declare module "_102021_/l2/helpers/l1Fixtures/fixtureDisk" {
    /** Client copies are stored as `.txt` so `scanImportRefs` does not compile them. */
    export function fixtureLogicalName(storedName: string): string;
    export function fixtureLogicalRel(rel: string): string;
    export function resolveFixtureFile(abs: string): string;
    export function restoreFixtureTree(root: string): void;
    export function copyFixtureSources(src: string, dest: string): void;
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
