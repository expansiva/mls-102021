declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPlanner" {
    export type PlannerStatus = 'ok' | 'needs_input' | 'failed';
    export interface PlannerOutput<T> {
        status: PlannerStatus;
        result: T;
        questions: string[];
        trace: string[];
    }
    export interface PlannerExtractConfig<T> {
        toolName: string;
        preNormalizeResult?: (value: unknown) => unknown;
        normalizeResult: (value: unknown) => T;
    }
    export function createPlannerToolSchema(toolName: string, description: string, resultSchema: Record<string, unknown>): mls.msg.LLMTool;
    export function extractPlannerOutput<T>(payload: unknown, config: PlannerExtractConfig<T>): PlannerOutput<T>;
    export function validateJsonSchema(value: unknown, schema: unknown, path: string): void;
    export function parseMaybeJson(value: unknown): unknown;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function assertRecord(value: unknown, path: string): Record<string, unknown>;
    export function assertArray(value: unknown, path: string): unknown[];
    export function assertString(value: unknown, path: string): string;
    export function optionalString(value: unknown): string | undefined;
    export function optionalStringArray(value: unknown): string[] | undefined;
    export function normalizeStringList(value: unknown, path: string): string[];
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbDefsSource" {
    /**
     * Pure readers of the l4/l5 defs dialects, with no platform imports, so they can be tested directly.
     * Two generators write the artifacts this agent reads: ns/ns3 emitted `} as const;`, and ns4 emits
     * `} as const satisfies <Artifact>;` over a typed import.
     */
    export type CbEntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm' | 'external' | 'derived';
    /**
     * MDM WRITE PATH — off until the general rebuild.
     *
     * The l4 already declares the intention this switch honours (`storage.target: mdm | external |
     * moduleDatabase`, `storage.mdmType`, v6 vocabulary), so reading it is not a new-vocabulary migration:
     * it would change the classification of the module Wagner is testing (run 9 of buildFlowFsm, where
     * Client/Project/InventoryItem carry `target: mdm` and FieldWorker/PlatformUser carry `target:
     * external`) the moment the next generation runs. That is exactly what the ⏸️ of the spec forbids.
     *
     * Flipping this to `true` moves four things at once, which is why it is one constant and not four:
     *   1. `classifyEntityKind` stops mapping `mdm + moduleOwned` to `core` and starts honouring
     *      `storage.target` — so an MDM entity gets no local domain entity, port, adapter or table, and an
     *      `external` one gets none of those and no seeds either;
     *   2. the seed planner routes those entities to `mdmEntities` (102034 registry) instead of
     *      `localTables`, and drops `external` entities from the plan entirely;
     *   3. the usecase item carries `mdmWrites` (mdmType + subtype + idField), so create/update/delete of
     *      master data is generated against `ctx.mdm` — the surface skills/applicationUsecase.md already
     *      documents — instead of a local port;
     *   4. validate-all blocks on a local persistence/port/domain artifact for an MDM entity instead of
     *      only warning about it (`collectPersistencePolicyIssues`).
     *
     * The order of the general rebuild is in the spec: ns4 vocabulary first (`party`, `platformUserId`),
     * then this flag, then `/rebuild all`.
     *
     * FLIPPED ON 2026-08-24 by Wagner's decision, with the next run being a `/rebuild all`. The two
     * prerequisites above were already met. Note what the flip does NOT do: it changes how the NEXT
     * generation classifies entities, so a module generated while it was `false` keeps its local tables
     * until it is rebuilt. There is no partial reversal — a module is generated in one shape or the other.
     */
    export const MDM_WRITE_PATH_ENABLED = true;
    /** What `storage` declares about an entity: where it lives, and under which master-data type. */
    export interface CbEntityStorage {
        target: string;
        scope: string;
        mdmType: string;
        idField: string;
    }
    export function readEntityStorage(parsed: Record<string, unknown>): CbEntityStorage;
    /**
     * The kind this agent generates from, deciding between the two vocabularies AND the two policies.
     *
     * With the write path OFF the answer is exactly what it has always been (`entityKindOf`), so a run of
     * the current module is byte-identical. With it ON, `storage.target` — the field that actually carries
     * the l4 intention — wins over the pair kind/ownership: `mdm` means master data owned by 102034 (the
     * module writes it THROUGH the facade), and `external` means an identity that lives outside this
     * product (a platform user), which must never become a local table and must never be seeded.
     */
    /**
     * What a caller knows about an entity. `storage` is PARTIAL because only `readEntityStorage` produces the
     * complete block — a caller that has just `{ target }` (a fixture, a scan of an older l4) asks the same
     * question and must not have to invent the other three fields.
     */
    export interface CbEntityClassification {
        kind: string;
        ownership?: string;
        storage?: Partial<CbEntityStorage>;
    }
    /** A declaration that contradicts itself, for the scan to announce instead of resolving in silence. */
    export function contradictoryStorageDeclaration(input: CbEntityClassification): string;
    export function classifyEntityKind(input: CbEntityClassification, mdmWritePath?: boolean): CbEntityKind;
    export function parseDefsSource(content: string): unknown;
    /**
     * Replace only the value of a defs file, keeping everything the generator wrote around it — the
     * header, the `import type`, the `satisfies` and the trailing exports. The todo files belong to the
     * generator that emitted them; this agent only flips a status inside them.
     */
    export function replaceDefsValue(content: string, value: unknown): string | null;
    /**
     * The handler vocabulary is `query | command`, but `operation.kind` speaks the generator's dialect:
     * ns/ns3 said create|update|query|view, ns4 says list|getById|create|update|delete|transition|
     * commandInput. Only reads are queries; everything else writes.
     */
    export function handlerKindOf(opKind: string): 'query' | 'command';
    /**
     * ns4 classifies a read-model as `projection`, which is what `metric` already meant here: not an
     * aggregate root by itself, but still backed by a table and seeds WHEN an operation reads it (that
     * is how a dashboard answers at runtime). Casting it silently would land on `core` and give a
     * projection nobody queries a table of its own.
     *
     * `mdm` means two different things in the two vocabularies, and the difference is the OWNERSHIP:
     * here it has always meant "master data read by id through 102034 — no local table, no port, never
     * written locally", while ns4 writes `mdm` + `ownership: moduleOwned` for master data THIS MODULE
     * owns and publishes, and compiles create/update/delete over it. Read as external, those operations
     * have nowhere to live: run 8 of buildFlowFsm generated 4 stub usecases (`functions: []`) for
     * Client/InventoryItem/Project and the final gate failed with 12 "export not found". Owned master
     * data is a local aggregate — table, port, CRUD, seeds — which is exactly `core`.
     */
    export function entityKindOf(kind: string, ownership?: string): CbEntityKind;
    /** A ns4 workflow: the lifecycle of one entity, with states and transitions and no operations. */
    export function isEntityLifecycle(parsed: Record<string, unknown>): boolean;
    /**
     * The module a `TS2792 Cannot find module '<path>'` names, or '' for any other diagnostic.
     *
     * A generated file that imports a platform contract of another project (`/_102034_/l1/...`) compiles
     * against a Monaco model this agent borrows for the compile. When the borrow silently fails the
     * diagnostic is indistinguishable from a real broken import — and the seed run of 2026-08-16 died on
     * one, after two earlier waves had compiled the very same file. Recognizing the shape is what lets
     * the caller ask "does this file actually exist?" instead of blaming the plan.
     */
    export function phantomModulePathOf(diagnostic: string): string;
    /** `/_102034_/l1/server/.../contracts.js` -> the file coordinates of its source. */
    export function mlsImportPathParts(path: string): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
    } | null;
    /**
     * The cross-project module a resolution diagnostic names, whatever the compiler called it
     * (TS2792 "cannot find module … did you mean to set moduleResolution", TS2307 "cannot find module").
     *
     * Used where the file under compile is written by THIS agent from a fixed template — the seeds. There
     * the import is not a claim the LLM made (it only plans data rows), so a module that does not resolve
     * is an environment fact, and asking `mls.stor.files` whether the target exists measures the wrong
     * thing: it measures whether the session indexed the other project, not whether the plan is wrong.
     */
    export function aliasModuleResolutionPathOf(diagnostic: string): string;
    /**
     * Monaco's "model already exists" — raised by `addModels` for a file whose model IS loaded, under a
     * registry key this agent's guard does not compute. The goal of the call (a usable model) is already
     * met, so the caller treats it as success; reading it as a failure logged the same warning forever
     * and left the import unborrowed.
     */
    export function isModelAlreadyExistsError(message: string): boolean;
    const TODO_STATUS_FIELDS: readonly ["status", "statusBackend"];
    export function todoOwnerType(raw: string): 'operation' | 'workflow' | '';
    /** The field the file actually uses, so the write-back lands where the read came from. */
    export function todoStatusField(raw: Record<string, unknown>): typeof TODO_STATUS_FIELDS[number] | '';
    /** The key both sides of a read-back agree on: the owner kind AFTER the dialect alias, plus its id. */
    export function todoOwnerKey(kind: string, id: string): string;
    export interface CbTodoDivergence {
        /** `operation:listBusinessHours` — todoOwnerKey of the owner that does not match. */
        key: string;
        expected: string;
        /** The status the source carries, or `<missing>` when the owner is not in it at all. */
        found: string;
    }
    /**
     * Compare the statuses a run BELIEVES it wrote against the ones a todoBackend source actually carries.
     * Pure on purpose: this is the comparator behind the finalize read-back, and it has to be testable
     * without a stor, a model or a browser.
     *
     * Returns `null` when the source cannot be parsed at all — for the caller that is not "no divergence",
     * it is "unreadable", which is its own kind of failure.
     */
    export function todoStatusDivergences(content: string, expected: ReadonlyMap<string, string>): CbTodoDivergence[] | null;
    /**
     * MDM semantics the ns4 catalogue attaches to an operation whose entity declares
     * `storage.target: 'mdm'` (`Ns4E8MdmSemantics` -> `Ns4ClassicOperation.mdm`). Measured on
     * `mls-102047/l4/petShop/operations/`:
     *
     *   inactivateCustomer.defs.ts -> `"mdm": { "lifecycle": "inactivate" }`
     *   listCustomer.defs.ts       -> `"mdm": { "activeFilterInput": "includeInactive",
     *                                           "situationOutput": "active" }`
     *
     * It exists because master data is NEVER deleted: the tier-1 catalogue emits the inactivate/reactivate
     * pair instead of a delete, the list hides inactive records by default, and the situation shown on
     * screen derives from the MDM index status — never from an invented local `active` field.
     *
     * `activeFilterInput` names an input that does NOT exist in the operation's `inputs[]` (the ns4 gate
     * requires every input fieldRef to resolve to a real ontology field, and `includeInactive` is not one),
     * so the CB is what has to materialize it. See `synthesizeMdmInputs` in cbShared.
     */
    export interface CbOwnerMdm {
        /** 'inactivate' | 'reactivate' — the cadastral pair that replaces delete for master data. */
        lifecycle?: string;
        /** Name of the boolean input that opts INTO seeing inactive records. */
        activeFilterInput?: string;
        /** Name of the derived output field carrying the situation (from the index status). */
        situationOutput?: string;
    }
    /**
     * Absent (not empty) when the operation carries no `mdm` block — the l4s that predate the block must
     * produce byte-identical owners, which is what makes this readable without touching the write-path flag.
     */
    export function readOwnerMdm(parsed: Record<string, unknown>): CbOwnerMdm | undefined;
    /** Is this the cadastral pair (as opposed to an ordinary MDM update)? */
    export function isMdmLifecycle(mdm: CbOwnerMdm | undefined): boolean;
    /**
     * Pin the l4 `mdm` block onto the usecase defs the model just returned. The model implements the
     * body; this block is not its to invent or drop. Without the pin, `saveDefs` writes the model
     * output and `collectMdmLifecycleIssues` (which reads `data.mdm` of that defs) stays blind — three
     * petShop runs in a row emitted no-op lifecycles with the agent already correct in the build.
     */
    export function pinUsecaseL4Mdm(result: Record<string, unknown>, ownerMdm: CbOwnerMdm | undefined): void;
    /** Structural mirror of cbShared.CbOperationInput — declared here so this module stays platform-free. */
    export interface CbMdmOperationInput {
        inputId: string;
        fieldRef: string;
        type?: string;
        required: boolean;
        source: string;
        description: string;
    }
    /**
     * The one input the l4 CANNOT declare. `mdm.activeFilterInput` names a boolean flag (`includeInactive`)
     * that opts into seeing inactive records, but the ns4 gate requires every input `fieldRef` to resolve to
     * a real ontology field — and `includeInactive` is not a field of anything. Measured on the evidence:
     * `listCustomer.defs.ts` declares `activeFilterInput: 'includeInactive'` with `inputs: []`.
     *
     * So the CB materializes it here, at the SINGLE place owners are read, instead of only in the usecase
     * prompt: the http controller derives its boundary contract from `owner.inputs` too, and an input the
     * controller never learned about is a flag the caller cannot pass.
     *
     * `required: false` on purpose — the default behaviour is active-only, and a required flag would make
     * every existing caller of the list illegal.
     */
    export function synthesizeMdmInputs(inputs: CbMdmOperationInput[], mdm: CbOwnerMdm | undefined): CbMdmOperationInput[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbWorkspace" {
    export interface CbBffCallInput {
        name: string;
        from: string;
        type?: string;
    }
    export interface CbBffCallOutputField {
        name: string;
        from?: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: CbBffCallOutputField[];
        };
    }
    export interface CbBffCallOutput {
        kind: 'object' | 'list' | 'paginated';
        fields: CbBffCallOutputField[];
    }
    export interface CbBffCallUse {
        operationId: string;
        optional?: boolean;
    }
    export interface CbBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: CbBffCallUse[];
        input: CbBffCallInput[];
        output?: CbBffCallOutput;
        route: string;
    }
    export interface CbWorkspace {
        workspaceId: string;
        moduleName: string;
        title: string;
        actors: string[];
        kind: string;
        purpose: string;
        bffCalls: CbBffCall[];
        operationIds: string[];
    }
    export interface CbActor {
        actorId: string;
        title: string;
        roleScope: string;
        moduleName: string;
    }
    export function readActorsField(obj: Record<string, unknown>): string[];
    export function readModuleActors(obj: Record<string, unknown>, moduleName: string): CbActor[];
    /**
     * ns4 has no `actors.defs.ts`: the audience of the module is the access matrix, whose profiles are
     * exactly the ids the operations already name in `actors[]`. `kind` (internal/external/system) is
     * the role scope.
     */
    export function readAccessMatrixActors(obj: Record<string, unknown>, moduleName: string): CbActor[];
    export function parseWorkspaceDefs(obj: Record<string, unknown>, moduleName: string): CbWorkspace | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTraceScope" {
    /** Called by the scan once the target module is resolved; every later write is scoped by it. */
    export function setCbTraceModule(moduleName: string): void;
    /** `<module>/trace` when the module is known, else the legacy bare `trace`. */
    export function cbTraceFolder(): string;
    /** Where the previous versions of this agent wrote: readers fall back to it so a run in flight that
     *  started before this change still finds its own state. */
    export const CB_TRACE_LEGACY_FOLDER = "trace";
    /** Stor identity of a CB step dump. JSON on purpose — not a defs artifact.
     *  (`defsRef` would force `.defs.ts` and the buildCI tsc would compile the JSON.) */
    export function agentTraceFileInfo(moduleName: string, agentName: string, stepId: unknown, project?: number): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig" {
    export interface LiveBackendModule {
        moduleId: string;
        backendControllers: string;
        tableDefsDir: string;
    }
    export interface ReconcileBackendConfigResult<M extends Record<string, unknown>, P extends Record<string, unknown>> {
        modules: M[];
        persistenceModules: P[];
        discarded: string[];
    }
    export function formatDiscardedOrphans(discarded: readonly string[]): string;
    export function liveBackendModulesFromL5(l5Modules: unknown): LiveBackendModule[];
    /** Drop l5/project.json backend blocks whose persistence dir is gone, except the module this run owns. */
    export function pruneOrphanL5BackendModules<M extends Record<string, unknown>>(modules: readonly M[] | undefined, currentModuleName: string, tableDefsExists: (moduleName: string) => boolean): {
        modules: M[];
        discarded: string[];
    };
    export function reconcileClientBackendRegistration<M extends Record<string, unknown>, P extends Record<string, unknown>>(existingModules: readonly M[] | undefined, existingPersistence: readonly P[] | undefined, live: readonly LiveBackendModule[]): ReconcileBackendConfigResult<M, P>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbScope" {
    import type { CbOwner, CbEntity, CbRelationship, CbWorkspace, CbActor } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    /**
     * The phases a run is grouped into, in order. Pure so a test can read them without the platform:
     * cbShared re-exports and uses them.
     */
    export const CB_PHASES: {
        readonly preparation: {
            readonly planId: "cb-phase-preparation";
            readonly title: "Preparação";
        };
        readonly generation: {
            readonly planId: "cb-phase-generation";
            readonly title: "Geração";
        };
        readonly judge: {
            readonly planId: "cb-phase-judge";
            readonly title: "Validação (juiz)";
        };
        readonly materialization: {
            readonly planId: "cb-phase-materialization";
            readonly title: "Materialização";
        };
        readonly seeds: {
            readonly planId: "cb-phase-seeds";
            readonly title: "Seeds";
        };
        readonly finalization: {
            readonly planId: "cb-phase-finalization";
            readonly title: "Finalização";
        };
    };
    export type CbPhaseKey = keyof typeof CB_PHASES;
    export interface CbScopeInput {
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        allModuleNames: string[];
        /** Explicit target module (CLI arg or longMemory). Empty = auto: first sorted module with owners. */
        requestedModule: string;
    }
    /** One l4 owner or one todo entry, reduced to what reconciliation needs. */
    export interface CbReconcileEntry {
        key: string;
        moduleName: string;
    }
    export interface CbReconcileInput {
        l4Owners: CbReconcileEntry[];
        todoOwners: CbReconcileEntry[];
        /** Unreadable/invalid todo files, with the module the file belongs to. */
        todoErrors: Array<{
            moduleName: string;
            message: string;
        }>;
        /** Canonical target module; empty means auto-discovery (every module that HAS a todo). */
        targetModule: string;
    }
    export interface CbReconcileResult {
        errors: string[];
        warnings: string[];
    }
    export interface CbScopeResult {
        moduleName: string;
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        warning: string | null;
    }
    /**
     * BACKFILL entity fields the ontology never declared, from the L4 owners' declared shapes.
     *
     * The e3 ontology writes `fields` for core/event/mdm entities but leaves a `kind: "metric"` entity with
     * NO fields at all (cafeFlow: ShiftClosingReport, OperationalDashboard, AiSalesSummary). Those entities
     * still become real aggregates — deriveAggregates promotes any entity an operation acts on as a root —
     * so they get a domain entity, a port, a table and seeds, all built from an EMPTY field list. The damage
     * observed in 102051:
     *   - seeds wrote only the FK/PK columns, leaving `details` (JSONB) empty, so getShiftClosingReport
     *     answered ok=true with just two ids (bug-shift-closing-report-payload.md) and getAiSalesSummary
     *     crashed on `dashboard.todaySalesTotal.toFixed(2)` (bug-ai-sales-summary.md);
     *   - validateSeedPlan could not object: it iterates `entity.fields`, which was empty;
     *   - and the domain entity only HAD its 14 fields because the pre-T5 generator let the LLM invent them
     *     from the L4 context. With T5 making that step deterministic (fields come from the scan), the next
     *     run would emit an EMPTY interface and break every usecase reading it.
     *
     * The authoritative source is already in L4 and machine-readable: every owner `outputShape` field (and
     * every operation input) carries `fieldRef: "<Entity>.<field>"` plus `type`/`required`. Reading those
     * back is deterministic — no LLM, no guessing. Only entities with NO ontology fields are touched, so a
     * properly-declared ontology is never overridden.
     */
    export function backfillEntityFieldsFromOwners(entities: CbEntity[], owners: CbOwner[]): CbEntity[];
    /**
     * Entities are identified by MODULE + id. A project keeps the generations the generator left behind
     * and they share entity ids (34 of them between buildFlowFsm46 and 47), so deduping by id alone let
     * whichever file the store yielded last decide the module of a shared id — and the module scope then
     * dropped an entity its own module legitimately declares, quietly shortening the ontology.
     */
    export function upsertEntity(entities: CbEntity[], entity: CbEntity): void;
    /**
     * Resolve a requested module name against the ones that exist. Module names are canonical camelCase
     * but are typed by hand ('buildFlowFSM47'), and an unmatched case used to filter everything to empty.
     */
    export function resolveModuleName(requested: string, names: string[]): string;
    /**
     * Reconcile the l4 owners against the todo — FOR THE TARGET MODULE ONLY.
     *
     * A project accumulates modules the generator left behind (the ns4 iteration writes buildFlowFsm39…47
     * side by side, and only the last one has a todo). Reconciling project-wide killed a run whose target
     * module was intact, because a previous generation's 108 operations had no todo of their own. Those
     * are not this run's business: they become ONE warning per module and their owners simply never carry
     * a status, so nothing downstream can treat them as pending work.
     */
    export function reconcileBackendTodo(input: CbReconcileInput): CbReconcileResult;
    /** Resolve the target module and filter every collection to it. The target is the explicit requested
     * module, else the first (sorted) module that has owners in the caller's requested statuses, else the
     * first module overall. A requested-but-absent module yields empty owners plus a warning (so the run
     * finishes cleanly with "no work" instead of silently spanning modules). Relationships are kept only
     * when BOTH endpoints are in-scope entities, so no seeded/generated artifact dangles across modules. */
    export function scopeBackendScan(input: CbScopeInput): CbScopeResult;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPromptBudget" {
    /**
     * How much of the module fits in ONE model call.
     *
     * Every whole-project step of this agent eventually meets the same wall: the prompt is the module,
     * and the module keeps growing. cb-gen-domain and cb-gen-usecase already fan out; the judge was the
     * last whole-project step of the usecase phase, and with 119 operations (ns4) its pairs prompt grew
     * to megabytes — the intents POST answered 413 and the step hung forever in waiting_human_input,
     * with nothing recorded on the task.
     *
     * Pure: no platform imports, so the packing rules are unit-testable.
     */
    /** Hard ceiling for a single prompt. Beyond this the transport rejects the POST. */
    export const MAX_PROMPT_BYTES = 200000;
    /** One judge batch: bounded by SIZE first (usecase defs vary a lot) and by count as a sanity cap. */
    export const JUDGE_BATCH_MAX_BYTES = 120000;
    export const JUDGE_BATCH_MAX_PAIRS = 15;
    export interface CbJudgeQueueEntry {
        ownerId: string;
        bytes: number;
    }
    export interface CbJudgeBatchPlan {
        batch: string[];
        pending: string[];
    }
    /**
     * Greedy packing in queue order: take pairs while they fit. The first entry is ALWAYS taken even
     * when it alone exceeds the budget — a queue that cannot drain is worse than one oversized call, and
     * the prompt guard below still reports it if it is truly out of bounds.
     */
    export function planJudgeBatch(queue: readonly CbJudgeQueueEntry[], maxBytes?: number, maxPairs?: number): CbJudgeBatchPlan;
    /**
     * The message for a prompt that cannot be posted, or null when it fits. Reported as a step failure
     * instead of letting the transport answer 413 as an uncaught client error — a size wall must always
     * arrive as a readable error on the task, naming the step that has to batch.
     */
    export function promptSizeError(label: string, humanPrompt: string, systemPrompt?: string): string | null;
    export function byteLength(value: string): number;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbCostReport" {
    export interface CbPhaseCost {
        cost: number;
        calls: number;
        inputTokens: number;
        outputTokens: number;
    }
    export type CbCostReport = Record<string, CbPhaseCost>;
    /** Parse the charged cost + token counts from an LLM step's interaction trace. The provider lines carry
     *  `... cost:$0.0199 ...` and `... inputTokens:7954 outputTokens:85 ...`; a step may have several provider
     *  attempts (primary + fallback) — SUM them, since the run is charged for each attempt. */
    export function parseStepCost(traceLines: readonly string[]): {
        cost: number;
        inputTokens: number;
        outputTokens: number;
    };
    /** Add one LLM call's cost to a phase bucket (returns a NEW report; pure). */
    export function accumulatePhaseCost(report: CbCostReport, phase: string, delta: {
        cost: number;
        inputTokens: number;
        outputTokens: number;
    }): CbCostReport;
    /** Roll up the report: total cost/calls and the single most expensive phase. */
    export function summarizeCost(report: CbCostReport): {
        totalCost: number;
        totalCalls: number;
        topPhase: string | null;
        topPhaseCost: number;
    };
    /** One-line human summary for the final task trace (T7 visibility). */
    export function formatCostSummary(report: CbCostReport): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbShared" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, type PlannerExtractConfig, type PlannerOutput } from "_102021_/l2/agentChangeBackend/helpers/cbPlanner";
    import { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, type CbEntityKind, type CbTodoDivergence, type CbOwnerMdm } from "_102021_/l2/agentChangeBackend/helpers/cbDefsSource";
    import { type CbWorkspace, type CbActor } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    export { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, };
    export type { CbEntityKind };
    export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, };
    export type { PlannerExtractConfig, PlannerOutput };
    /** Loose planner config: validates the envelope and returns the `result` object as a record. Each
     * agent reads the array property it expects (items/aggregates/tables/...). */
    export function plannerConfig(toolName: string): PlannerExtractConfig<Record<string, unknown>>;
    /** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
     * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
    export function batchSchema(itemSchema: Record<string, unknown>): Record<string, unknown>;
    export function asArray(value: unknown): Record<string, unknown>[];
    export type ExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export const ALL_STATUSES: readonly OwnerStatus[];
    export type EntityKind = CbEntityKind;
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export type EventPurpose = 'telemetry' | 'audit' | 'reaction';
    export interface EventPolicy {
        purpose: EventPurpose;
        retentionDays?: number;
    }
    export const DEFAULT_EVENT_RETENTION_DAYS = 90;
    export type CbFileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export interface CbAccessPattern {
        kind: string;
        description: string;
        entity?: string;
        keyField?: string;
        filters?: string[];
        sort?: string[];
        pagination?: string;
        selection?: string;
        output?: string[];
    }
    export interface CbOutputField {
        name: string;
        type: 'string' | 'number' | 'boolean' | 'array' | 'object' | 'json';
        required: boolean;
        fieldRef?: string;
        item?: {
            fields: CbOutputField[];
        };
    }
    export interface CbOutputShape {
        kind: 'object' | 'list' | 'paginated';
        fields: CbOutputField[];
    }
    export interface CbOperationInput {
        inputId: string;
        fieldRef: string;
        /** l4 v2 (N1b): every input declares an explicit `type` OR a `fieldRef` — so the usecase/contract
         * input is 100% derivable without re-inferring free inputs (page/pageSize/minPrice) from prose. */
        type?: string;
        required: boolean;
        source: string;
        description: string;
        /** Closed union for list controls (`sortBy` field ids, `sortOrder` asc|desc). */
        enumValues?: string[];
    }
    export interface CbContextResolution {
        inputId?: string;
        targetRef: string;
        source: string;
        originRef: string;
        description: string;
    }
    export interface CbOwner {
        kind: 'operation' | 'workflow';
        id: string;
        pageId: string;
        commandName: string;
        bffName: string;
        title: string;
        entity: string;
        opKind: string;
        /** Actors allowed on this operation. l4 v2 declares `actors: string[]`; v1 `actor: string` (folded to a 1-array). */
        actors: string[];
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern?: CbAccessPattern;
        /** Canonical output structure from l4 (Option 3): the usecase output type is pinned to this. */
        outputShape?: CbOutputShape;
        inputs: CbOperationInput[];
        contextResolution: CbContextResolution[];
        acceptanceAssertions: string[];
        /** MDM semantics of the operation (`Ns4E8MdmSemantics`): the cadastral lifecycle pair, the
         *  active-only filter of a list, the derived situation output. Absent for every l4 that predates the
         *  block, which is what keeps those modules generating exactly as before. */
        mdm?: CbOwnerMdm;
        /** Status from l5/{module}/todoBackend.defs.ts. This is the only source of generation state. */
        todoStatus: string;
        /** Deprecated compatibility alias for prompts that still print owners as statusBackend. */
        statusBackend: string;
        /** Legacy inline status read from l4 only to warn about divergence; never used for decisions. */
        inlineStatusBackend: string;
        moduleName: string;
    }
    export interface CbEntity {
        entityId: string;
        title: string;
        kind: EntityKind;
        ownership: string;
        moduleName: string;
        fields?: Record<string, unknown>[];
        eventPolicy?: EventPolicy;
        storageTarget?: string;
        mdmType?: string;
        idField?: string;
    }
    export interface CbRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        persistenceMode?: string;
    }
    export interface CbAggregate {
        aggregateId: string;
        rootEntity: string;
        embeddedMembers: string[];
        events: string[];
        mdmRefs: string[];
    }
    export interface CbEventTarget {
        entityId: string;
        ownerEntity: string;
        purpose: EventPurpose;
        retentionDays?: number;
        persisted: boolean;
        fields?: Record<string, unknown>[];
    }
    export type { CbBffCallInput, CbBffCallOutputField, CbBffCallOutput, CbBffCallUse, CbBffCall, CbWorkspace, CbActor, } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    import { type CbPhaseKey } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export { CB_PHASES } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export type { CbPhaseKey } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export interface CbScan {
        project: number;
        moduleNames: string[];
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        aggregates: CbAggregate[];
        events: CbEventTarget[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        siteMaps: Record<string, Record<string, unknown>>;
        warnings: string[];
    }
    export function readBackendScan(statuses?: readonly string[], context?: mls.msg.ExecutionContext, targetModuleOverride?: string): Promise<CbScan>;
    export function deriveEventTargets(entities: CbEntity[], relationships: CbRelationship[]): CbEventTarget[];
    export function deriveAggregates(entities: CbEntity[], relationships: CbRelationship[], operatedRootIds?: Set<string>): CbAggregate[];
    export interface CbColumnPlan {
        fieldId: string;
        reason: string;
    }
    export interface CbTablePlan {
        tableId: string;
        rootEntity: string;
        ownership: string;
        indexedColumns: CbColumnPlan[];
        detailsFields: string[];
        childCollections: string[];
    }
    /** Heuristic: a field needs a real column when it is the id (PK), a reference/FK (type is an entity
     * id or ends with "Id"), a status/lifecycle field, or an ordering timestamp (createdAt). Everything
     * else goes into details JSONB. Deterministic column plan consumed by the table/adapter generators. */
    export function planTableColumns(fields: Record<string, unknown>[], knownEntityIds: Set<string>): {
        indexed: CbColumnPlan[];
        details: string[];
    };
    export function domainEntityFileInfo(m: string, entityId: string): CbFileInfo;
    export function valueObjectFileInfo(m: string, memberId: string): CbFileInfo;
    export function repositoryPortFileInfo(m: string, entityId: string): CbFileInfo;
    export function usecaseFileInfo(m: string, usecaseId: string): CbFileInfo;
    export function persistenceTableFileInfo(m: string, tableId: string): CbFileInfo;
    export function repositoryAdapterFileInfo(m: string, entityId: string): CbFileInfo;
    export function httpControllerFileInfo(m: string, pageId: string): CbFileInfo;
    /** Newest mtime (ms) among all L4 `.defs.ts` of the project — the "input changed" watermark. Any l1
     * defs written at/after this is current; anything older (or a changed L4) forces regeneration. */
    export function newestL4DefsMs(project: number): number;
    /** Pure staleness decision (extracted for unit testing): a generated defs is current when it exists
     * (non-null mtime) and was written at/after the L4 watermark. */
    export function defsIsCurrent(defsMs: number | null, l4WatermarkMs: number): boolean;
    /** Whether the generated `.defs.ts` for `fileInfo` can be reused (exists + at/after the L4 watermark). */
    export function defsCurrent(fileInfo: CbFileInfo, l4WatermarkMs: number): boolean;
    /** A /rebuild forces fresh output — reuse is bypassed. (run/bare reuses current defs.) */
    export function isRebuildCommand(context: mls.msg.ExecutionContext): boolean;
    export const CB_AGENT_PROJECT = 102021;
    export const CB_AGENT_FOLDER = "agentChangeBackend";
    /** Read a co-located LLM prompt at runtime. Prompts live next to their step agent as
     * `agentChangeBackend/steps/<slug>/prompt.md` (moved into the step folders on 2026-07-11,
     * step 4; inline template strings were extracted in step 2). Each file
     * keeps its `<!-- modelType: ... -->` marker; the caller still replaces the {{toolName}} placeholder.
     * `folderRel` is relative to this agent folder (e.g. 'steps/gen-domain'); fixed to project 102021 (the
     * agent's own files), NOT the client mls.actualProject. */
    export function readCbPrompt(folderRel: string, shortName?: string): Promise<string>;
    export function defsRef(fileInfo: CbFileInfo): string;
    /** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
    export function dtsRef(fileInfo: CbFileInfo): string;
    /** Standard planning envelope shared by every .defs.ts data block. */
    export function buildArtifact(artifactType: string, artifactId: string, moduleName: string, agentName: string, data: unknown): Record<string, unknown>;
    /** Materialization context for a layer: the hexagonal base architecture skill + the per-type skill
     * (both co-located with this agent) + the platform defs. */
    export function layerSkills(skillFile: string): string[];
    export interface CbPipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath: string;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        rulesPath?: string;
        rulesApplied?: string[];
        agent: string;
    }
    /** Build the pipeline item that makes a .defs.ts self-sufficient for materialization (agentCbMaterialize
     * in-flow, or the cbMaterializeCli Node runner): it carries the outputPath (.ts), the dependsFiles
     * (.d.ts of the inner callee layer) and skills (the LLM context = layer skill + platform defs).
     * See spec.md (auto-suficiência). */
    export function buildPipelineItem(shortName: string, type: string, fileInfo: CbFileInfo, dependsFiles: string[], skills: string[], opts?: {
        rulesPath?: string;
        rulesApplied?: string[];
    }): CbPipelineItem;
    /** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
     * (optionally) the `export const pipeline`. Force-overwrites. */
    export function saveDefs(fileInfo: CbFileInfo, exportName: string, data: unknown, pipeline?: CbPipelineItem[]): Promise<string>;
    /** Write a .defs.ts verbatim. Used to update a file this agent does not own the shape of. */
    export function writeDefsSource(fileInfo: CbFileInfo, src: string): Promise<string>;
    export function saveBackendWorkspaceConfig(): Promise<string>;
    export function saveAgentTrace(context: mls.msg.ExecutionContext, agentName: string, step: mls.msg.AIAgentStep, counters?: Record<string, unknown>): Promise<void>;
    /** Update only l5/{module}/todoBackend.defs.ts. l4 owner defs are read-only for this agent. */
    export function setTodoBackendStatus(owner: CbOwner, status: OwnerStatus): Promise<boolean>;
    export interface CbTodoReadBack {
        /** l5 ref of the file that was checked, or '' when no todoBackend file was found. */
        ref: string;
        checked: number;
        /** The durable content (localStor/IndexedDB). This is what a NEXT run of this agent reads. */
        stor: {
            unreadable: boolean;
            divergent: CbTodoDivergence[];
        };
        /** The Monaco model, when one exists. This is what an EXPORT to disk writes. */
        model: {
            present: boolean;
            unreadable: boolean;
            divergent: CbTodoDivergence[];
        };
    }
    /** Every surface of the read-back that disagrees with what the run believes it wrote. */
    export function todoReadBackDivergences(readBack: CbTodoReadBack | null): CbTodoDivergence[];
    export function todoReadBackIsClean(readBack: CbTodoReadBack | null): boolean;
    /**
     * Is this a read-back the run must DIE on? Divergence on either surface, yes — that is the lost update.
     * An unparseable STOR, yes — the durable state stopped being readable. An unparseable MODEL, no, only a
     * loud warning: that is somebody editing todoBackend.defs.ts in a Studio tab with the syntax momentarily
     * broken, which is their editor and not this agent's write.
     */
    export function todoReadBackIsFatal(readBack: CbTodoReadBack | null): boolean;
    /**
     * Re-read todoBackend and compare it with the statuses this run believes it wrote — on BOTH surfaces
     * that can become the file on disk. Reading only the stor is not enough: in the petShop incident the
     * stor was RIGHT (65 done) and the stale Monaco model was what got exported, so a stor-only read-back
     * would have passed the run that produced the corrupt file.
     */
    export function readBackTodoBackend(expected: ReadonlyMap<string, string>): Promise<CbTodoReadBack | null>;
    export function createUpdateStatusIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg?: string, cleaner?: 'input' | 'input_output', newTaskTitle?: string): mls.msg.AgentIntentUpdateStatus;
    export function createAgentStepPayload(planId: string, agentName: string, stepTitle: string, args: unknown, dependsOn: string[], executionMode: ExecutionMode, status?: mls.msg.AIStepStatus, dynamicSource?: unknown): mls.msg.AIAgentStep;
    /**
     * Start the next step INSIDE its phase. Steps that stay in the same phase keep using `enqueueNext`:
     * their parent already IS the phase, so a sibling lands in it for free. Only a phase TRANSITION goes
     * through here.
     *
     * A phase can only receive children while it is open, so it is created lazily with its first child
     * inside it (agentCbPhase adds that child from within the phase's own hook) — never pre-created empty
     * and then completed, which would make every later child throw.
     */
    export function enqueueNextInPhase(context: mls.msg.ExecutionContext, currentStep: mls.msg.AIAgentStep, phase: CbPhaseKey, planId: string, agentName: string, stepTitle: string, args?: unknown, onFailure?: mls.msg.AIAgentStep['onFailure']): mls.msg.AgentIntentAddStep;
    /** An agent step with this planId that can still receive children. */
    export function findOpenStepByPlanId(context: mls.msg.ExecutionContext, planId: string): mls.msg.AIAgentStep | null;
    export function createAddStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep): mls.msg.AgentIntentAddStep;
    export function createPromptReadyIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, hookSequential: number, args: string, systemPrompt: string, humanPrompt: string, toolSchema: mls.msg.LLMTool, toolName: string): mls.msg.AgentIntentPromptReady;
    /**
     * How many children of a fan-out run at once. Run 9 finished with 0 provider errors and 0 fallbacks
     * while the effective parallelism was only ~2× (LLM time 2:06 against 1:02 of wall clock) — the
     * provider had room, so the default moved from 5/10 to 20. A single place decides it.
     */
    export const CB_MAX_PARALLEL = 20;
    /** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
    export function createParallelStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args: string[], dependsOn?: string[], maxParallel?: number): mls.msg.AgentIntentAddStep;
    export function logPrefix(agent: IAgentMeta | {
        agentName: string;
    }): string;
    export function planIdOf(step: mls.msg.AIPayload | undefined): string;
    /** The CLI command the root stored in the task longMemory (rebuild-all | rebuild-defs | run | help). */
    export function readCliCommand(context: mls.msg.ExecutionContext): string;
    /** T11: true when the run was started with `--no-assets` — the optional seed-image step is skipped
     *  entirely (it completes with a warning and the seeds stay intact). Mirrors readCliCommand. */
    export function readNoAssets(context: mls.msg.ExecutionContext): boolean;
    /** The target module the root stored in the task longMemory. Empty means "auto": readBackendScan
     * scopes to the first (sorted) module with owners in the requested statuses. Mirrors readCliCommand. */
    export function readTargetModule(context: mls.msg.ExecutionContext): string;
    /** Count of l1 files `/rebuild all` archived at bootstrap — empty when this run did not archive. */
    export function readRebuildArchived(context: mls.msg.ExecutionContext): string;
    /** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
     * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
     * compile; parallelization is a later optimization. */
    export function enqueueNext(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, currentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args?: unknown, onFailure?: mls.msg.AIAgentStep['onFailure']): mls.msg.AgentIntentAddStep;
    export function readString(value: unknown): string;
    export function readStringArray(value: unknown): string[];
    export function lowerFirst(value: string): string;
    export function capitalize(value: string): string;
    export function toSafeShortName(value: string): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbCli" {
    export type CbCommandKind = 'rebuild-all' | 'rebuild-defs' | 'rebuild-seeds' | 'run' | 'help';
    /** Parse the user prompt into a CLI command plus an OPTIONAL target module. Lenient: mention stripped,
     * command keyword matched anywhere. The module is the first token that is NOT a CLI keyword and not a
     * slash-flag (case is PRESERVED — module names are case-sensitive). 'all' is a keyword, never a module.
     * Empty (bare @@changeBackend) is the autonomous default -> 'run'. A bare non-keyword token
     * (e.g. "@@changeBackend cafeFlow") means: run (continue) that specific module. */
    export function parseCli(raw: string | undefined): {
        kind: CbCommandKind;
        module: string;
        noAssets: boolean;
    };
    /** The human message content stored on the bootstrap step: the prompt with the mention stripped and
     * lowercased. Kept separate from parseCli (which preserves module case). */
    export function normalizePrompt(raw: string | undefined): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbArchive" {
    /** Backend generated l1 lives under `<module>/layer_*`. Scope so one module never touches another. */
    export function isGeneratedBackendFolder(folder: string, modules: string[]): boolean;
    /** Keys of l1 files that `/rebuild all` must archive before regenerating. */
    export function listBackendL1ArchiveKeys(files: Record<string, {
        project?: number;
        level?: number;
        status?: string;
        folder?: string;
    } | null | undefined>, project: number, moduleName: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/steps/rebuild-defs-cleanup/agentCbRebuildDefsCleanup" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export { isGeneratedBackendFolder, listBackendL1ArchiveKeys } from "_102021_/l2/agentChangeBackend/helpers/cbArchive";
    /** Soft-delete every l1 artifact of the module (defs and derived .ts). Platform trash, never `rm`. */
    export function archiveGeneratedBackendModule(project: number, moduleName: string): Promise<string[]>;
}
declare module "_102021_/l2/agentChangeBackend/agentChangeBackend" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/localDocRefs.test" { }
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102021_/l2/agentChangeBackend/nodejsSaveConfigJson" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbAgentTrace.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbBuildStamp" {
    /**
     * PROVENANCE of the running agent code: WHICH version of this agent produced this run.
     *
     * Not "is it stale?" — that question cannot be answered from inside the agent, and asking it produced a
     * wrong diagnosis once already. What happened on 2026-08-22 (run cb-run-…01-34-27): the MDM F1 was in
     * nobody's build because it had never been committed. The `obj/compiled.zip` in play was perfectly
     * CONSISTENT — its `fileinfos.json` and its `.js` both sat on commit 308ab97 — and the run executed the
     * last PUBLISHED build, correctly. Measured, not argued: for `helpers/cbShared.ts` the build recorded
     * `1ef6d903…`, which is exactly `git rev-parse 308ab97:l2/agentChangeBackend/helpers/cbShared.ts`,
     * while the working copy on the author's disk hashed to `5691b296…`. There was no build bug and nothing
     * to "recompile": what puts code on the platform is commit + push (the `build.yml` Action compiles and
     * commits `obj/compiled.zip`).
     *
     * So the useful line in a trace is not an alarm, it is an IDENTITY a human can match with git.
     *
     * WHAT THIS CANNOT DO — by construction, not by omission:
     *   - It cannot see work that was never committed and pushed: the platform has never seen it. No
     *     measurement from inside the agent finds it, by timestamp or by hash.
     *   - It cannot tell whether the built `.js` matches the `.ts` of the same commit. That would be a bug in
     *     the Action, and the place to catch it is there.
     *   - It is NOT a gate: it never blocks, never fails a run, and emits no warning. A source being edited
     *     locally is the NORMAL state of whoever is editing (a file "in development" keeps its local version
     *     instead of the build's `.js` — `cfe-collab-front-end/src/stor/stor.server.ts`), so treating that as
     *     an anomaly would be noise, not signal.
     */
    /** The project this agent's code lives in. */
    export const CB_AGENT_PROJECT = 102021;
    /** Only this agent's own sources: another folder's version says nothing about which agent ran. */
    export const CB_AGENT_SOURCE_PREFIX = "l2/agentChangeBackend/";
    /**
     * The files a human checks first, in `git`. Kept short on purpose — the digest already covers everything;
     * these exist so a reader has something to paste into `git rev-parse <commit>:<path>` without unzipping.
     */
    export const CB_BUILD_ANCHORS: readonly string[];
    /** One entry of the build's own manifest (`fileinfos.json` inside obj/compiled.zip). */
    export interface CbBuildFile {
        shortPath: string;
        /** git blob OID of the source AT THE BUILD COMMIT. Verified: equals `git hash-object <file>`. */
        versionRef: string;
    }
    export interface CbAgentProvenance {
        project: number;
        /**
         * Stable digest of the agent's `shortPath:versionRef` pairs. Two runs with the same buildRef executed
         * the same code; different buildRefs executed different code. Match a single file with
         * `git rev-parse <commit>:<path>` (or `git hash-object <file>` for a working copy).
         */
        buildRef: string;
        /** How many of this agent's sources went into the digest. */
        files: number;
        /** versionRef per anchor file; `absent` when the manifest has no entry (e.g. a file never committed). */
        anchors: Record<string, string>;
        /**
         * Last push registered on the project. NOT the build time: the platform webhook writes it on every
         * push (`cbe-collab-back-end/.../executeOnProjectUpdated.ts`) and the backend uses it to invalidate the
         * zip cache, so a push that produces no new build already moves it.
         */
        lastPushAt: string | null;
        /** How many of this agent's sources are being edited locally. Informational: this is normal. */
        localEdits: number;
        error?: string;
    }
    /**
     * FNV-1a over the sorted `shortPath:versionRef` pairs. Local and pure on purpose: the digest has to be
     * reproducible in a test without a platform, and it only has to be stable, not cryptographic.
     */
    export function digestBuildFiles(files: readonly CbBuildFile[]): string;
    /**
     * PURE. Builds the provenance from the manifest the browser already holds.
     *
     * The manifest is the right source precisely BECAUSE it is not perturbed by local editing: it is what
     * the build recorded. `mls.stor.files[].versionRef` is not usable here — a locally created file is
     * stamped `'0'` by `createStorFile`, so a digest over it would change as soon as anyone edits.
     */
    export function buildProvenance(project: number, files: readonly CbBuildFile[], options: {
        prefix: string;
        anchors: readonly string[];
        lastPushAt?: string | null;
        localEdits?: number;
        error?: string;
    }): CbAgentProvenance;
    /** The one line a trace carries. No warning path: there is no measured signal that warrants one. */
    export function describeProvenance(provenance: CbAgentProvenance | null): string;
    /**
     * Read the provenance of the running agent. Fail-soft by contract: any throw becomes an empty
     * `buildRef` plus the reason, and never touches the run.
     */
    export function readAgentProvenance(project?: number): Promise<CbAgentProvenance>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbBuildStamp.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbCli.test" { }
declare module "_102029_/l2/clientBoundarySources" {
    /**
     * The only L4 sources whose values cross the browser/BFF boundary.
     * Keep backend validation and frontend contract generation aligned by importing this module.
     */
    export const CLIENT_BOUNDARY_SOURCES: readonly ["userInput", "selectedEntity", "routeParam"];
    export type ClientBoundarySource = typeof CLIENT_BOUNDARY_SOURCES[number];
    export type ClientInputPresentation = 'form' | 'selection' | 'route';
    export function isClientBoundarySource(source: unknown): source is ClientBoundarySource;
    export function clientInputPresentation(source: unknown): ClientInputPresentation | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbComponentValidators" {
    /** Module-local l1 imports of a generated .ts: `from '_<project>_/l1/<folder>/<name>'`. Returns
     * the tsSet key (`${folder}::${shortName}`) so the caller can check the target was actually generated.
     * Cross-project imports (e.g. /_102034_/ platform) and non-l1 imports are ignored on purpose. */
    export function collectL1Imports(content: string, project: number): {
        key: string;
        target: string;
    }[];
    /**
     * Same field (name + ofEntity) on input and output must have the same form. be5: weeklySchedule
     * input `json` × output `string` — list shows a blob, create/update reject the string the list emits.
     * Gate the DEFS, not the generated .ts (aliases like WeeklySchedule vs string are unresolvable).
     */
    export function collectIoShapeSymmetryIssues(fn: {
        functionName?: string;
        input?: unknown;
        output?: unknown;
    }): string[];
    /** Ontology type named by `Entity.field` (empty when the ref does not resolve). */
    export function ontologyTypeForFieldRef(fieldRef: string, entities: Array<{
        entityId: string;
        fields?: unknown[];
    }>): string;
    /**
     * When l4 flattened a structured ontology field (json → string) onto outputShape, rewrite the
     * output type to the ontology type so W2 can pass. Caller records a systemDecision per change.
     */
    export function alignOutputShapeToOntology<S extends {
        kind: string;
        fields: Array<{
            name: string;
            type: string;
            required: boolean;
            fieldRef?: string;
        }>;
    }>(shape: S, entities: Array<{
        entityId: string;
        fields?: unknown[];
    }>): {
        shape: S;
        aligned: Array<{
            fieldRef: string;
            from: string;
            to: string;
        }>;
    };
    /** Drop bffCalls whose required usecase was never materialized (abandoned owner — no controller pair). */
    export function bffCallsWithMaterializedUsecase<T extends {
        uses: Array<{
            operationId: string;
            optional?: boolean;
        }>;
    }>(calls: T[], usecaseIds: ReadonlySet<string>): {
        kept: T[];
        skipped: string[];
    };
    /** l4 contract defs a generated controller lists in `dependsFiles`. Empty/unreadable content used to
     * be dropped from the materialize prompt with only a console.warn, so controllers shipped without
     * their wire contract (ctx422 / versionRef 0). */
    export function collectL4ContractDependsRefs(defsSource: string): string[];
    export function collectUnreadL4ContractFindings(defsSource: string, readable: (ref: string) => boolean): string[];
    /** Generated defs shortName must not contain extra dots (convention after nomes_sem_ponto). */
    export function collectDottedShortNameFindings(files: {
        shortName: string;
    }[]): string[];
    export function collectRelativeImportIssues(code: string): string[];
    export function escapeRegExp(value: string): string;
    export function fieldNameFromRef(value: unknown): string;
    export function requiredBoundaryFields(inputContract: unknown): Set<string>;
    export function collectRequiredChecksByHandler(content: string): Map<string, Set<string>>;
    export function collectExportedHandlers(content: string): Set<string>;
    export function collectRouteHandlers(content: string): Map<string, string>;
    export function normalizeRuleId(rule: string): string;
    export function collectUsecaseRules(data: unknown): string[];
    /** Method names declared on a repository port interface, read from the generated port `.ts`/`.d.ts`.
     * Walks the interface body brace-matched; matches member signatures `name(...)` / `name<...>(...)`. */
    export function extractInterfaceMethods(portSource: string, interfaceName: string): Set<string>;
    /** Repository method calls in a usecase that are NOT declared on the bound port interface. Binds each
     * `const v = resolveRepository<IXRepository>(...)` variable to its interface, then checks every
     * `v.method(` call. Interfaces absent from `methodsByInterface` (port source unresolved) are skipped,
     * so this never false-positives. The finding lists the port's real methods for a deterministic repair. */
    export function collectRepositoryMethodMisuse(code: string, methodsByInterface: Map<string, Set<string>>): string[];
    /**
     * A repository re-bound through a CAST to invent a method it does not have.
     *
     * The delete usecases of the buildFlowFsm run all did this:
     * `const deletedClient = clients as unknown as { delete(id: string): Promise<void> }; await
     * deletedClient.delete(...)`. The port declares no `delete`, so at runtime the property is `undefined`,
     * the call throws a TypeError, and the client sees `INTERNAL_ERROR: Unexpected error` — 7 of the 22
     * failures of the production suite, all of them unreadable. `collectRepositoryMethodMisuse` cannot see
     * it: it tracks bindings made by `resolveRepository<I…>`, and the cast creates a NEW name it never
     * heard of. The cast IS the escape from that gate.
     *
     * There is no legitimate version of this: if the port has no `delete`, the entity is not deletable, and
     * the usecase has to SAY so — the one generated file that did (`ProjectCoordinationAssignment
     * repository does not support deletion`, a readable CONFLICT) is the shape the other seven owe.
     */
    /**
     * A delete operation whose port has no `delete` compiles, then 409s
     * `"<Entity> repository does not support deletion"` (petShop `cmdDeleteScheduleBlock`).
     * Either the port declares `delete`, or the operation should not exist. Ports that could not be
     * loaded are skipped (empty map) so this never false-positives. Called from validate-all against
     * the PORT source (finding routed to the port defRef); not from the usecase materialize worker.
     * `inactivate*` is a status update (`getById` → `save`), not a port method — do not match it here.
     */
    export function collectDeleteOperationPortGaps(usecaseId: string, methodsByInterface: Map<string, Set<string>>): string[];
    export function collectRepositoryCastIssues(code: string): string[];
    /**
     * The MDM facade's `entity.related(key)` takes a TYPED CompactRelationshipRefKey. Models invent a key
     * and force it past the type with a string-literal cast — `entity.related(key as 'o')`,
     * `x.relatedIds(rel as "OffersProduct")` erro4). The isolated in-loop compile missed
     * it (the platform type was not loaded), so it only surfaced in the project `tsc`. A cast to a string
     * literal inside a related()/relatedIds() call is never legitimate — a real key is a typed constant,
     * never something you cast a literal into. Flag it as a repair finding: the linked id must be read from a
     * DECLARED entity field (e.g. `menuCategoryId`), not a guessed relationship key.
     */
    export function collectInventedRelationshipKeyIssues(code: string): string[];
    /** Double-check (vs H1): keep only the compiler errors that reproduced in BOTH passes. A finding present
     * in the first compile but not the recompile was a transient (Monaco model lag / imports not yet
     * settled) and must not force a full LLM re-generation of a file that was already correct. */
    export function stableCompilerErrors(first: string[], second: string[]): string[];
    /** Cascade dedup (vs H2): among the files flagged by the whole-project compile, a file that IMPORTS
     * another flagged file is reporting DERIVED errors from that broken import — repair only the ROOT this
     * round and DEFER the importer. Pure over (flagged keys, importsOf); the caller resolves imports (I/O).
     * `importsOf(key)` returns the l1 import keys of that file (same `${folder}::${shortName}` space). */
    export function selectCompilerRepairRoots(flaggedKeys: Iterable<string>, importsOf: (key: string) => string[], familiesOf?: (key: string) => string[]): {
        roots: string[];
        cascades: string[];
    };
    /** TS code + quoted identifier, so `'pet' is possibly 'null'` and `'service' is possibly 'null'` are distinct. */
    export function compilerErrorFamily(error: string): string;
    /**
     * After a repair, keep the UNION of both compiles — never drop a family as "flaky". g1 found two
     * families in createServiceAppointment, the repair fixed `pet`, g2's double-check then discarded
     * `service` as non-reproducing and health closed `passed` with a real tsc error still on disk.
     */
    export function compilerErrorsAfterRepair(first: string[], second: string[]): string[];
    /** Health may close `passed` only when every previous family was re-checked on this pass. */
    export function compilerFindingsBlockingPassed(input: {
        currentByFile: Map<string, string[]>;
        previousFamiliesByFile?: Map<string, string[]>;
    }): string[];
    /** User-facing AppError messages must be English (or i18n). Cheap scan of generated usecases. */
    export function collectNonEnglishAppErrorMessages(code: string): string[];
    export interface EventForPortCheck {
        entityId: string;
        ownerEntity: string;
    }
    export function eventPortBelongsToOwner(event: EventForPortCheck, ownerRefs: readonly string[], mutated: ReadonlySet<string>): boolean;
    /**
     * T12 item 4 — POST-condition on the saved usecase defs: the owner's PRINCIPAL aggregate (l4
     * `entity`) must appear in `data.ports` whenever it has a local port (an aggregate root or a persisted
     * event). MDM entities are excluded (read by id via 102034, never a port).
     *
     * This is checked on the SAVED defs by the judge — not on the model's raw output — because the ports
     * are derived deterministically by the agent AFTER the model answers. So a violation here means the
     * DERIVATION missed a case (the erro4/erro5 createStockAdjustment bug), not that the model misbehaved:
     * it routes to a cheap phase-1 defs repair instead of 3 LLM repair attempts during materialization.
     * Returns [] when the owner's entity legitimately has no port.
     */
    export function missingPrincipalPortIssues(owner: {
        id: string;
        entity: string;
    }, declaredPorts: readonly string[], localPortIds: ReadonlySet<string>, // aggregate roots ∪ persisted event ids
    mdmIds: ReadonlySet<string>): string[];
    /**
     * T12 item 3 — SAFETY BELT for the materialize worker. Independently of how the defs were derived, the
     * worker's prompt must show the model every port the usecase will actually resolve. Returns the port
     * entity ids that the defs `data` references (top-level `ports` + `functions[].ports`) but whose
     * `.d.ts` pair is NOT already in `dependsFiles` — the worker then loads those pairs into the context.
     *
     * Narrow by construction (only ids the defs itself names, never the whole module) so T5's context
     * savings hold. Immunizes against future derivation gaps without regenerating old defs.
     */
    export function portsMissingFromDependsFiles(data: unknown, dependsFiles: readonly string[]): string[];
    export function ownershipCheckIsInconclusive(expectedIdCount: number, generatedDefsCount: number): boolean;
    /** The warning emitted in place of the (suppressed) orphan findings. */
    export function ownershipInconclusiveWarning(generatedDefsCount: number): string;
    export interface DefsFileForOwnership {
        folder: string;
        shortName: string;
        real: string;
    }
    /**
     * The ORPHAN-DEFS check, pure. A usecase defs is owned by an operation; a v2 controller defs is owned by
     * an operation OR a workspace. Callers pass the id sets built from an ALL_STATUSES scan (A1) — ownership
     * does not depend on pending status.
     *
     * Gated PER CHECK, not on the sum: usecase ownership comes ONLY from `expectedOperationIds` (which the
     * scan filters by owner status), while controller ownership also accepts `expectedWorkspaceIds` — and
     * scan.workspaces is NOT status-filtered. Summing them would leave the usecase guard dead on a v2 module
     * (0 operations + N workspaces != 0), i.e. exactly the erro5 case this guard exists for.
     */
    export function collectOrphanDefsFindings(defsFiles: readonly DefsFileForOwnership[], expectedOperationIds: ReadonlySet<string>, expectedWorkspaceIds: ReadonlySet<string>): {
        findings: string[];
        warnings: string[];
    };
    export interface OwnerForRouteCheck {
        kind: string;
        id: string;
        bffName?: string;
        pageId?: string;
        commandName?: string;
    }
    export interface ControllerForRouteCheck {
        id: string;
        routes: ReadonlyArray<{
            key: string;
        }>;
    }
    /**
     * V1-only canonical bffName route check, pure (v2 controllers are per-WORKSPACE and covered by
     * collectV2ControllerCoherenceIssues). Every operation owner that HAS a controller must expose its
     * canonical route. Works off an ALL_STATUSES scan (A1) so a `done` owner is still checked — with the old
     * pending-filtered scan this check silently passed on every post-gen-http run.
     */
    export function collectMissingCanonicalRouteIssues(owners: readonly OwnerForRouteCheck[], controllers: readonly ControllerForRouteCheck[], moduleName: string, lowerFirstFn: (value: string) => string): string[];
    /** Top-level `function name(...) {...}` / `const name = (...) => {...}` blocks, brace-matched. */
    export function extractFunctionBlocks(code: string): Array<{
        name: string;
        body: string;
    }>;
    /** Findings for adapters that parse a `details` envelope without merging over defaults. A candidate is
     * any function that calls `JSON.parse` on an expression mentioning `details` (so `ctx.mdm` reads of
     * `entity.details.<module>`, which never JSON.parse, are not candidates). */
    export function collectDetailsDefaultingIssues(code: string): string[];
    /** JSONB column names declared on a table def (.ts with postgresType, or planner .defs.ts with type). */
    export function jsonbColumnsFromTableSource(source: string): {
        tableName: string;
        columns: string[];
    } | null;
    /**
     * `JSON.parse(row.<col>)` on a JSONB column: pg already returns an object, parse throws, mute catch
     * empties the domain. Finding is textual; the legitimate parse is `typeof row.col === 'string' ? JSON.parse(row.col) : (row.col ?? {})`.
     */
    export function collectJsonbRowParseFindings(adapterSource: string, jsonbColumns: ReadonlySet<string>, label: string): string[];
    /** l4 `fields[].fieldId` — the vocabulary of JSONB `details` keys (and of domain fields). */
    export function fieldIdsFromL4Fields(fields: unknown): Set<string>;
    /**
     * Adapter `parseDetails`/`toDomain`/`toRow` that addresses `details.<chave>` with a key that is not
     * an l4 fieldId. Seeds write fieldId (camelCase); a snake_case key inside the JSONB envelope is
     * unread data (blank column, value still in the row). Inverse: toRow/detailsDefaults writing a key
     * outside the same vocabulary. Empty fieldIds skips (nothing to compare).
     */
    export function collectDetailsKeyIssues(adapterSource: string, fieldIds: ReadonlySet<string>, label: string): string[];
    /** Collection fields of a generated domain entity, as `valueObjectName -> the entity's field name`
     * (e.g. `OrderItem -> items` for `items: OrderItem[]`).
     *
     * WHY this indirection exists: the TableDefinition declares embedded child collections by ENTITY ID
     * (`childCollections: ['OrderItem']`), but the domain-entity materializer names the field itself
     * (`items: OrderItem[]`) and the adapter reads THAT name (`d.items`). Seeding the envelope under the
     * entity id would write `details.OrderItem` while the adapter reads `details.items` — the row looks
     * seeded and the collection still arrives empty. Since seeds are generated AFTER materialization, the
     * real field name is readable from the generated entity source instead of guessed from a convention. */
    export function extractCollectionFieldNames(entitySource: string): Map<string, string>;
    export interface V2WorkspaceForCheck {
        workspaceId: string;
        bffCalls: Array<{
            bffId: string;
        }>;
    }
    export function collectV2ControllerCoherenceIssues(workspaces: V2WorkspaceForCheck[], controllerSources: Map<string, string>): string[];
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/taskDetailsRoundTrip" {
    export const TASK_L4_FIELDS: {
        fieldId: string;
    }[];
    export const TASK_FIELD_IDS: string[];
    export interface TaskRow {
        task_id: string;
        owner_user_id: string;
        status: string;
        created_at: string;
        details: Record<string, unknown> | string | null;
    }
    export interface TaskDetails {
        title: string;
        description: string | null;
        priority: string;
        dueDate: string | null;
    }
    export interface Task {
        taskId: string;
        title: string;
        description: string | null;
        status: string;
        priority: string;
        dueDate: string | null;
        ownerUserId: string;
        createdAt: string;
    }
    /** Seed-shaped row: details written under fieldId (camelCase), the way gen-seeds emits the envelope. */
    export const TASK_SEED_ROW: TaskRow;
    export function parseDetails(row: TaskRow): TaskDetails;
    export function toDomain(row: TaskRow): Task;
    export function toRow(task: Task): TaskRow;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbComponentValidators.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbConsoleGuard.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbContracts" {
    import type { CbBffCall } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    export interface CbOpOutputShapeView {
        kind: string;
        fields: Array<{
            name: string;
            type?: string;
            item?: unknown;
        }>;
    }
    /** The array-carrying field of a paginated operation outputShape (the `$items` target). The first field
     * of type 'array' (or one with a nested `item`) — real outputShapes have exactly one. `list` shapes are
     * flat (no array field) and return null. */
    export function resolveItemsArrayField(shape: CbOpOutputShapeView | null | undefined): string | null;
    export interface CbResolvedProjectionField {
        name: string;
        operationId: string;
        path: string[];
        fromItems: boolean;
    }
    /** Parse a bffCall `from` path (`<op>.<field>` | `<op>.$items.<col>`) into its parts. Returns null for a
     * malformed/empty `from`, or for a bare `<op>.$items` (the whole array — handled by the array field). */
    export function parseFromPath(from: string | undefined): {
        operationId: string;
        fromItems: boolean;
        path: string[];
    } | null;
    /** Resolve a bffCall's output per the CANONICAL v2 shapes (confirmed against the real contracts,
     * newSolution_10 §A2):
     *   object    -> topFields = the projected object fields; no array.
     *   list      -> itemFields = flat `<op>.$items.<col>` columns; the WIRE is a BARE array (arrayFieldName null).
     *   paginated -> one array field with nested `item.fields` (declared name, e.g. `reservations`) + meta
     *                (total/page/pageSize) as topFields; the WIRE wraps `{ <arrayFieldName>: item[], ...meta }`. */
    export interface CbResolvedProjection {
        kind: 'object' | 'list' | 'paginated';
        itemFields: CbResolvedProjectionField[];
        topFields: CbResolvedProjectionField[];
        arrayFieldName: string | null;
        arrayOperationId: string | null;
    }
    export function resolveBffProjection(bff: CbBffCall): CbResolvedProjection;
    export function envelopeKindOf(bff: CbBffCall): 'object' | 'list' | 'paginated';
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbContracts.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbCostReport.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbFindingSeverity" {
    export type FindingSeverity = 'blocking' | 'degradable';
    export function partitionFindings(findings: string[]): {
        blocking: string[];
        degradable: string[];
    };
    export function findingSeverity(finding: string): FindingSeverity;
    /** Seeds are test data: empty tables are a valid, visible app. Includes compiler errors ON seeds.ts. */
    export function isSeedFinding(finding: string): boolean;
    /**
     * Persistence-policy findings about artifacts that can be omitted from publication (adapter/port/domain
     * /seed rows). A leaked TABLE is structural (migrate would create it) and stays blocking.
     */
    export function isOmittablePolicyFinding(finding: string): boolean;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbFindingSeverity.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbHealthReport" {
    export const MAX_HEALTH_ROUNDS = 20;
    /**
     * Merge a new report snapshot into the existing cb-health-report.json content.
     * - top level = the LAST state (the flattened report), backward-compatible with readers of the old shape;
     * - `rounds` = the accumulated snapshots (oldest first), capped at MAX_HEALTH_ROUNDS.
     * A snapshot never carries its own `rounds` key, so the array does not grow quadratically.
     */
    export function buildHealthReportContent(existingRaw: string | null, report: Record<string, unknown>, now: string): string;
    /**
     * The last validate-all of a run is often a CLEAN pass (post-seeds, findings 0). It used to write
     * `repairHistory: []` and `globalAttempts: 0` over the top of the file because repair state was
     * cleared after the previous success. The rounds array still held the repair-round snapshots.
     * Fold the longest history and the max attempts so the top-level health a post-mortem reads first
     * matches the steps that actually ran.
     */
    export function foldRepairAudit(existingRaw: string | null, current: {
        repairHistory?: unknown;
        globalAttempts?: unknown;
    }): {
        repairHistory: string[];
        globalAttempts: number;
    };
    /**
     * Seeds verdicts are written by gen-seeds (`degraded` on give-up, `ok` on full convergence) and must
     * survive a later validate-all snapshot that does not mention seeds. The fold takes the MOST RECENT
     * snapshot that mentions seeds: `ok` clears the top-level fields (a prior-run `degraded` still sitting
     * in `rounds` is a ghost); `degraded` is copied through so `passed` at the top does not erase the give-up.
     */
    export function foldSeedsDegraded(existingRaw: string | null, current: {
        seeds?: unknown;
        seedError?: unknown;
        seedSkipped?: unknown;
    }): {
        seeds?: 'degraded';
        seedError?: string;
        seedSkipped?: unknown;
    };
    export function foldOperationsCoverage(existingRaw: string | null, current: {
        operations?: unknown;
        operationsMissing?: unknown;
    }): {
        operations?: 'degraded';
        operationsMissing?: unknown;
    };
    export interface OperationsMissingReport {
        noUsecase: string[];
        noEndpoint: string[];
        declared: number;
        covered: number;
    }
    export type OperationsCoverageVerdict = {
        operations: 'ok';
    } | {
        operations: 'degraded';
        operationsMissing: OperationsMissingReport;
    };
    export function expectedRoutesByOperation(workspaces: ReadonlyArray<{
        bffCalls: ReadonlyArray<{
            route: string;
            uses: ReadonlyArray<{
                operationId: string;
            }>;
        }>;
    }>): Record<string, string[]>;
    /**
     * One-way check: l4-declared operations that did not become a usecase and/or a route.
     * Extra usecases nobody calls are ignored on purpose.
     */
    export function compareOperationsCoverage(input: {
        declared: readonly string[];
        usecaseNames: Iterable<string>;
        routeKeys: Iterable<string>;
        expectedRoutesByOperation?: Readonly<Record<string, readonly string[]>>;
    }): OperationsCoverageVerdict;
    export function operationsCoverageLogLine(verdict: OperationsCoverageVerdict): string;
    /** Keep the highest models.peak seen in any snapshot — be5 closed with registry 104 but the leak is the peak. */
    export function foldModelsPeak(existingRaw: string | null, current: {
        models?: unknown;
    }): {
        registry: number;
        pendingRelease: number;
        peak: number;
    } | undefined;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbLocalStepTitle" {
    export function localStepTitle(context: mls.msg.ExecutionContext, step: {
        stepId: number;
    }, title: string): void;
    export function startLocalStepTick(context: mls.msg.ExecutionContext, step: {
        stepId: number;
    }, makeTitle: (elapsedSec: number) => string): () => void;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbLocalStepTitle.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore" {
    export interface PipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath?: string;
        dependsFiles?: string[];
        dependsOn?: string[];
        skills?: string[];
        rulesApplied?: string[];
        agent?: string;
    }
    export interface ParsedDefs {
        dataExportName: string | null;
        artifact: Record<string, unknown> | null;
        data: unknown;
        item: PipelineItem | null;
    }
    export interface PlannedItem {
        item: PipelineItem;
        rank: number;
        stale: boolean;
        reason: string;
    }
    export interface MaterializeEnv {
        readRef(ref: string): Promise<string | null>;
        modifiedMs(ref: string): Promise<number | null>;
    }
    export interface GenResult {
        code: string;
    }
    export function layerRank(type: string): number;
    export function orderItems(items: PipelineItem[]): PipelineItem[];
    export function isStale(defsMs: number | null, tsMs: number | null, tsExists?: boolean): boolean;
    export function parseDefs(src: string): ParsedDefs;
    export const GEN_TOOL_NAME = "submitGeneratedTs";
    export const GEN_TOOL: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitGeneratedTs";
            readonly description: "Submit the complete generated TypeScript file content.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["code"];
                readonly properties: {
                    readonly code: {
                        readonly type: "string";
                        readonly description: "Complete TypeScript file content. Must start with the /// <mls fileReference=\"...\"> header.";
                    };
                };
            };
        };
    };
    export const DEFAULT_MODEL_TYPE = "code";
    export function parseModelType(systemPrompt: string): string | null;
    export function buildSystemPrompt(skillSections: string[], outputPath: string, modelType: string): string;
    export function buildHumanPrompt(data: unknown, contextSections: string[], outputPath: string): string;
    /**
     * The platform header is DERIVED from the file being written, never taken from the model's output.
     *
     * It used to be kept whenever the output already began with `///`, on the assumption that a model
     * echoing the header echoes it right. Two files of the buildFlowFsm run came back with
     * `enhancement="blank"` instead of `_blank` (`usecases/updateChangeOrder.ts` and
     * `adapters/persistence/changeOrderRepositoryAdapter.ts`) — written during a repair round, where the
     * model rewrites the whole file and retypes the first line. Nothing downstream reads the header, so it
     * failed silently. The path is just as forgeable as the enhancement, so both are rebuilt here: this
     * agent knows exactly which file it is saving, and the model's opinion about it is not needed.
     */
    export function applyHeader(outputPath: string, code: string): string;
    /** True when a repair finding is a pure COMPILER error (from the per-file compile `compiler: ...` or the
     *  whole-project compile `compiler -> ...`). Micro-repair only applies when ALL findings are compiler. */
    export function isCompilerFinding(finding: string): boolean;
    /** T6: should ONE targeted rescue round fire (outside the global budget)? Only for a SMALL, compiler-only
     *  residual after the global budget is exactly spent — a larger or non-compiler residual is a genuine
     *  failure, not a last-mile fix. The caller bumps globalAttempts past the budget so this is a one-shot
     *  (`globalAttempts === budget` becomes false on the re-check). Pure/testable. */
    export function shouldTargetedRescue(input: {
        globalAttempts: number;
        budget: number;
        targetCount: number;
        maxTargets: number;
        findings: string[];
    }): boolean;
    export function buildMicroRepairPrompt(input: {
        outputPath: string;
        code: string;
        findings: string[];
        contextSections: string[];
        pitfalls: string | null;
    }): {
        system: string;
        human: string;
    };
    export const CONTRACTS_102034: readonly string[];
    export function expandContextRef(ref: string, artifactType?: string, hasMdmRefs?: boolean): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbSyntaxValidation" {
    /** Deterministic TypeScript syntax checks available even when Monaco is unavailable. */
    export function syntaxDiagnostics(content: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo" {
    import type { PipelineItem } from "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore";
    export interface ParsedMlsPath {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    /** Extract the `pipeline` array from a .defs.ts content string. */
    export function parsePipelineFromContent(content: string): PipelineItem[] | null;
    /** Scan every l1 .defs.ts (with a pipeline) of a module. */
    export function scanL1DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    /**
     * Whether the file is in this session's index at all — which `getFileModified` cannot say, because it
     * answers `null` both for "absent" and for "present, no usable timestamp". Conflating the two made a
     * resumed session read every generated .ts as never-generated and re-materialize files that were
     * already current (run of 2026-08-17: 14 of 34 controllers rewritten for nothing).
     */
    export function fileIsPresent(project: number, level: number, folder: string, shortName: string, extension: string): boolean;
    /** updatedAt (ms) of a file, MAX_SAFE_INTEGER when new/changed without a timestamp, else null. */
    export function getFileModified(project: number, level: number, folder: string, shortName: string, extension: string): number | null;
    /** Read any file by its full MLS path string. */
    export function getContentByMlsPath(mlsPath: string): Promise<string | null>;
    /** Parse a MLS path like `_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts`. */
    export function parseMlsPath(mlsPath: string): ParsedMlsPath | null;
    /**
     * Release everything the compiles queued, once no compile is in flight. `releaseBorrowedModels` only
     * drains at a quiescent point, and a long sweep (the whole-module compile borrows the imports of ~200
     * files) never reaches one on its own: the queue grows, the Monaco models pile up and the tab runs
     * out of memory. A caller that works in blocks calls this between them.
     */
    export function flushBorrowedModels(): Promise<{
        released: number;
        pending: number;
    }>;
    /**
     * Release every model of the module this agent is responsible for.
     *
     * `addModels` loads ALL siblings of a shortName — the `.defs.ts` rides along with the `.ts` — and not
     * every path releases symmetrically, so after run 9 the tab held 464 Monaco models against 256 registry
     * entries (208 orphans) plus ~all the module's defs. The delete now reaches an orphan by URI (platform
     * F2), so a final sweep can actually clean up.
     *
     * A file whose model was ALREADY in the registry when the run started belongs to the Studio (an open
     * tab) and is never touched — the same ownership rule the per-compile borrow uses.
     */
    export function sweepModuleModels(project: number, moduleName: string, keep: ReadonlySet<string>): {
        swept: number;
        kept: number;
    };
    /** The registry keys present right now — the caller snapshots them at the start of a run to know
     *  which models were NOT loaded by this agent (an open Studio tab). */
    export function modelRegistryKeys(): Set<string>;
    export function modelCounts(): {
        registry: number;
        pendingRelease: number;
        peak: number;
    };
    /**
     * ONE compile pass over a whole set of files.
     *
     * `compileSavedTsAndGetErrors` per file costs `N × the platform`: each call re-borrows the models of
     * its imports, re-typechecks everything the program reaches, and releases — ~6s per file, so the
     * validate gate of a 193-file module took ~20 minutes and the flagged ones paid it twice (the
     * anti-flaky double check). The TS worker, on the other hand, keeps an incremental program: load the
     * models ONCE and asking it for the diagnostics of each file is cheap from the second question on.
     *
     * The stable model set also removes the source of the flakiness the double compile existed for (a
     * model appearing halfway through the sweep), so callers ask once and re-ask only the flagged ones.
     *
     * Returns null when the worker is unavailable — the caller then keeps the per-file path, because a
     * missing optimization must never cost the gate.
     */
    export function compileModuleAndGetErrors(project: number, files: Array<{
        folder: string;
        shortName: string;
    }>): Promise<Map<string, string[]> | null>;
    /** Small deterministic fallback for syntax that TypeScript rejects before type checking. */
    export interface SaveGeneratedTsResult {
        ok: boolean;
        /** TypeScript errors of the per-file compile (spec item 11: feed the compiler error back into the
         * repair prompt). Empty when clean or when the compile environment is unavailable. */
        compileErrors: string[];
        /** Deterministic INTRA-FILE syntax findings (subset of compileErrors). Never a false positive —
         * callers gate on these immediately even when the cross-file compile is deferred. */
        syntaxErrors: string[];
        /**
         * Errors blaming an import whose source IS on disk — the model did not load, the plan is fine.
         * They are also in `compileErrors`; a caller must never route these to an LLM repair.
         */
        infraErrors: string[];
        /** False means Monaco/project compilation was unavailable; syntax fallback still ran. */
        compilerAvailable: boolean;
    }
    /** Save (create or overwrite) a generated file with an ARBITRARY extension, WITHOUT compiling. Used for
     * byte-mirror artifacts (l1 contract copies `.ts`/`.d.ts` — B5) where the whole-project compile in
     * validate-all owns correctness; a per-file compile of a `.d.ts` twin would be meaningless. Mirrors the
     * write path of saveGeneratedTs (createStorFile with the Monaco model registered so later files import it). */
    export function saveGeneratedFile(project: number, level: number, folder: string, shortName: string, extension: string, content: string): Promise<boolean>;
    /** Save (create or overwrite) a generated .ts file, force a recompile and report its errors. */
    export function saveGeneratedTs(project: number, level: number, folder: string, shortName: string, content: string): Promise<SaveGeneratedTsResult>;
    /** Whole-project compile check (used by cb-validate-all): compile an already-saved generated .ts and
     * return its errors. At that point every generated file exists, so findings are REAL — unlike the
     * per-file compile during the layer sweep, which is deferred (see agentCbMaterialize). Returns []
     * when Monaco is unavailable — the deterministic checks remain the floor. */
    export function compileSavedTsAndGetErrors(project: number, folder: string, shortName: string): Promise<string[]>;
    /** Pull the arguments of a named tool call out of the model payload (several shapes supported). */
    export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmGuards" {
    export function collectRawMdmAccessIssues(code: string): string[];
    export function collectMdmLifecycleIssues(code: string, lifecycle: string | undefined): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmGuards.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmPolicy" {
    /**
     * Persistence-policy gate: the l4 says WHERE an entity lives, and this is the deterministic check that
     * the generated l1 obeys it. Pure (no platform imports) so it is unit-tested directly.
     *
     * Run 9 of buildFlowFsm is the case it exists for: Client, Project and InventoryItem declare
     * `storage.target: 'mdm'` and FieldWorker/PlatformUser declare `'external'`, and the run still
     * produced local tables — seeded ones, duplicating the organization's people. Nothing FAILED, because
     * a local table for master data is perfectly valid code; only the policy was violated. A finding is
     * the only thing that turns that class of defect from invisible into blocking.
     *
     * The gate reads what is ON DISK (artifact short names), never a plan: a plan that promised the right
     * thing and materialized the wrong one is exactly what has to be caught.
     */
    export interface CbPolicyEntity {
        entityId: string;
        kind: string;
        storageTarget: string;
    }
    export interface CbPolicyArtifacts {
        /** lowercased shortNames of `layer_3_domain/entities/*.defs.ts` */
        domainEntities?: Iterable<string>;
        /** lowercased shortNames of `layer_2_application/ports/*.defs.ts` (`<entity>Repository`) */
        ports?: Iterable<string>;
        /** lowercased shortNames of `adapters/persistence/**` (table defs + adapters) */
        persistence?: Iterable<string>;
        /** entity ids (any case) that the seed plan writes LOCAL rows for */
        seededLocalEntities?: Iterable<string>;
    }
    /**
     * One finding per (entity, forbidden artifact). `storage.target` is quoted verbatim so the reader can
     * go straight to the l4 line that was ignored.
     */
    export function collectPersistencePolicyIssues(entities: CbPolicyEntity[], artifacts: CbPolicyArtifacts): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmPolicy.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbNs4Dialect.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepairLock" {
    export function serializeRepairMutation<T>(operation: () => Promise<T>): Promise<T>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepairCore" {
    /** Max REPAIR attempts per component after the first failure (first try + 2 repairs = 3 LLM calls). */
    export const COMPONENT_REPAIR_BUDGET = 2;
    /** Previous rejected code is truncated before it goes into the state/prompt. */
    export const MAX_LAST_CODE = 6000;
    export type CbRepairSource = 'component-validate' | 'validate-all' | 'judge';
    export interface CbComponentRepair {
        target: string;
        attempts: number;
        findings: string[];
        /** Findings from EARLIER attempts that the last output resolved. Fed back so the model does not
         * regress them while fixing the current findings (run 102049-e: attempt 3 fixed the compiler
         * finding but reintroduced the rulesApplied finding of attempt 1 — whack-a-mole until budget). */
        priorFindings?: string[];
        lastCode?: string;
        source: CbRepairSource;
        updatedAt: string;
    }
    /**
     * Merge a component's repair entry across attempts/rounds. Carries forward:
     * - `priorFindings` = findings an earlier attempt already RESOLVED (present before, absent now) — fed
     *   back so the model does not regress them (anti whack-a-mole);
     * - `lastCode` = the last rejected code (or a freshly supplied one) — so the model FIXES it instead of
     *   re-rolling from scratch.
     * The `attempts` value is the caller's policy: recordComponentFailure increments it; the validate-all
     * GLOBAL round resets it to 0 (the round grants a fresh worker budget — the global budget is the
     * anti-loop). This is what lets a g2 round remember what g1 already fixed instead of repeating it.
     */
    export function mergeComponentRepair(prev: CbComponentRepair | undefined, target: string, findings: string[], opts: {
        attempts: number;
        source: CbRepairSource;
        lastCode?: string;
    }): CbComponentRepair;
    /** Repair section appended to the worker's human prompt on a retry. */
    export function buildRepairPromptSection(entry: CbComponentRepair): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepair.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepair" {
    import { type CbCostReport } from "_102021_/l2/agentChangeBackend/helpers/cbCostReport";
    import { type CbComponentRepair, type CbRepairSource } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    export { COMPONENT_REPAIR_BUDGET, mergeComponentRepair, buildRepairPromptSection } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    export type { CbComponentRepair, CbRepairSource } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    /** Max full validate-all -> re-materialize repair rounds. */
    export const GLOBAL_REPAIR_BUDGET = 2;
    /** Max judge passes (initial critique + 1 post-repair verification). */
    export const JUDGE_MAX_RUNS = 2;
    /** Routing taxonomy (improveAddNewSolution2_1.md §2). fora_de_escopo findings are discarded. */
    export type CbFindingType = 'estrutural' | 'decisao' | 'fora_de_escopo';
    export interface CbJudgeFinding {
        ownerId: string;
        type: CbFindingType;
        severity: 'error' | 'warning';
        message: string;
        suggestion?: string;
    }
    export interface CbRepairState {
        schemaVersion: string;
        componentRepairs: Record<string, CbComponentRepair>;
        globalAttempts: number;
        judgeRuns: number;
        /** Durable audit of every repair occurrence in the run ("target :: attempt n :: finding"). The
         * fan-out children are DELETED by the runtime after completion, so this history is what survives;
         * cb-validate-all embeds it in the task trace before clearing the state. */
        history: string[];
        updatedAt: string;
    }
    /** Append a timestamped line to the durable repair history (bounded). Exported so the validate-all
     *  global repair round can record which defRefs it forced stale (it mutates the state object directly
     *  in one read/save transaction). */
    export function pushHistory(state: CbRepairState, entry: string): void;
    export function readRepairState(): Promise<CbRepairState>;
    export function saveRepairState(state: CbRepairState): Promise<boolean>;
    /** Wipe the whole repair state (validate-all passed: the run converged). */
    export function clearRepairState(): Promise<void>;
    /** Repair target key for the usecase DEFS phase (shared by agentCbUsecase and agentCbJudge). */
    export function usecaseDefsTarget(ownerId: string): string;
    export function getComponentRepair(target: string): Promise<CbComponentRepair | null>;
    /** Record a failed attempt (increments the budget) and keep the findings + rejected code for the retry prompt. */
    export function recordComponentFailure(target: string, findings: string[], lastCode?: string, source?: CbRepairSource): Promise<CbComponentRepair>;
    /** Set findings WITHOUT burning component budget (used by the validate-all global round, which grants
     * the component a fresh worker budget — the global round has its own budget). */
    export function setComponentFindings(target: string, findings: string[], source: CbRepairSource): Promise<void>;
    export function clearComponentRepair(target: string): Promise<void>;
    /** True while the component may still be retried (attempts consumed <= budget). */
    export function hasRepairBudget(entry: CbComponentRepair | null | undefined): boolean;
    /** Persist the validate-all outcome + repair audit to l4/trace/cb-health-report.json. The task dump
     * keeps interaction null on deterministic steps and the repair state is cleared on success, so this
     * file is the DURABLE record of what was repaired in the run (survives task cleanup). */
    export function saveHealthReport(report: Record<string, unknown>): Promise<void>;
    /** Accumulate ONE LLM step's cost into l4/trace/cb-cost.json under `phase`. Cost comes from the
     *  authoritative `interaction.cost` (this step's LLM charge, retries included, no child cost); token
     *  counts are parsed from the trace (not carried on the interaction). Best-effort + serialized (fan-out
     *  workers write concurrently); never throws into the flow. */
    export function recordLlmCost(phase: string, interaction: mls.msg.AIInteraction | null | undefined): Promise<void>;
    export function readCostReport(): Promise<CbCostReport>;
    /** Read the last-state cb-health-report.json (top level = the last snapshot). Used by the final summary
     *  (T6) to surface residual compiler findings that would otherwise live only in this file. */
    export function readHealthReport(): Promise<Record<string, unknown> | null>;
    /** Bump the .defs.ts updatedAt so the materialize dispatcher sees the component as stale again. */
    export function forceDefsStale(defRef: string): boolean;
    /**
     * The dossier of one run, written where the module's trace lives.
     *
     * Everything here was reconstructed BY HAND after each run, from the task record plus the console: the
     * cost and calls per phase, the repair history, the residual findings and the model counts. Writing it
     * once, at the end, makes the next post-mortem a file read.
     */
    export function saveRunReport(report: Record<string, unknown>): Promise<string | null>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRunDossier" {
    /**
     * Flatten the live task tree into the records the run dossier stores.
     *
     * Child-step traces do not survive in the persisted `iaCompressed` (the msgtask dump of a finished
     * run only keeps the root). Reading them HERE, at finalize, from the in-memory tree, is the only
     * chance to keep title/status/last-trace of every step as a file.
     */
    export interface RunStepRecord {
        stepId: number;
        type: string;
        title: string;
        status: string;
        agentName?: string;
        lastTrace?: string;
    }
    export function collectRunStepRecords(roots: unknown): RunStepRecord[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRunDossier.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbSchemas" {
    export const domainEntityResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly title: {
                readonly type: "string";
            };
            readonly fields: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["fieldId", "type", "required"];
                    readonly properties: {
                        readonly fieldId: {
                            readonly type: "string";
                        };
                        readonly type: {
                            readonly type: "string";
                        };
                        readonly required: {
                            readonly type: "boolean";
                        };
                        readonly description: {
                            readonly type: "string";
                        };
                        readonly enum: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
            readonly valueObjects: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly invariants: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly statusEnum: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const repositoryPortResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "interfaceName", "methods"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly interfaceName: {
                readonly type: "string";
            };
            readonly methods: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const persistenceTableResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["tableId", "tableName", "columns", "primaryKey"];
        readonly properties: {
            readonly tableId: {
                readonly type: "string";
            };
            readonly tableName: {
                readonly type: "string";
            };
            readonly columns: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly primaryKey: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly indexes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly detailsColumn: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["enabled"];
                readonly properties: {
                    readonly enabled: {
                        readonly type: "boolean";
                    };
                    readonly columnName: {
                        readonly type: "string";
                    };
                    readonly childCollections: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                };
            };
            readonly appendOnly: {
                readonly type: "boolean";
            };
            readonly purpose: {
                readonly type: "string";
            };
            readonly retentionDays: {
                readonly type: "number";
            };
        };
    };
    export const repositoryAdapterResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "className", "portRef", "tableRef"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly className: {
                readonly type: "string";
            };
            readonly portRef: {
                readonly type: "string";
            };
            readonly tableRef: {
                readonly type: "string";
            };
            readonly mdmReads: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly notes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const usecaseResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["usecaseId", "ports", "functions"];
        readonly properties: {
            readonly usecaseId: {
                readonly type: "string";
            };
            readonly ports: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly rulesApplied: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly functions: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["functionName", "inputTypeName", "outputTypeName", "input", "output"];
                    readonly properties: {
                        readonly functionName: {
                            readonly type: "string";
                        };
                        readonly inputTypeName: {
                            readonly type: "string";
                        };
                        readonly outputTypeName: {
                            readonly type: "string";
                        };
                        readonly input: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                    readonly fieldRef: {
                                        readonly type: "string";
                                    };
                                    readonly item: {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly properties: {
                                            readonly fields: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly type: "object";
                                                    readonly additionalProperties: false;
                                                    readonly required: readonly ["name", "type"];
                                                    readonly properties: {
                                                        readonly name: {
                                                            readonly type: "string";
                                                        };
                                                        readonly type: {
                                                            readonly type: "string";
                                                        };
                                                        readonly required: {
                                                            readonly type: "boolean";
                                                        };
                                                        readonly description: {
                                                            readonly type: "string";
                                                        };
                                                        readonly ofEntity: {
                                                            readonly type: "string";
                                                        };
                                                        readonly fieldRef: {
                                                            readonly type: "string";
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly output: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                    readonly fieldRef: {
                                        readonly type: "string";
                                    };
                                    readonly item: {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly properties: {
                                            readonly fields: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly type: "object";
                                                    readonly additionalProperties: false;
                                                    readonly required: readonly ["name", "type"];
                                                    readonly properties: {
                                                        readonly name: {
                                                            readonly type: "string";
                                                        };
                                                        readonly type: {
                                                            readonly type: "string";
                                                        };
                                                        readonly required: {
                                                            readonly type: "boolean";
                                                        };
                                                        readonly description: {
                                                            readonly type: "string";
                                                        };
                                                        readonly ofEntity: {
                                                            readonly type: "string";
                                                        };
                                                        readonly fieldRef: {
                                                            readonly type: "string";
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly ports: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly rulesApplied: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly transactional: {
                            readonly type: "boolean";
                        };
                        readonly steps: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
    };
    export const httpControllerResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["pageId", "controllerName", "handlers", "routes"];
        readonly properties: {
            readonly pageId: {
                readonly type: "string";
            };
            readonly controllerName: {
                readonly type: "string";
            };
            readonly handlers: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly routes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const seedPlanResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary", "localTables", "mdmEntities"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly localTables: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly mdmEntities: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const judgeResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["findings"];
        readonly properties: {
            readonly findings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const finalSummaryResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly ownersDone: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly warnings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbScope.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore" {
    export const SEED_T0 = "2026-07-01T08:00:00.000Z";
    export const SEED_T1 = "2026-07-01T09:00:00.000Z";
    export const SEED_WINDOW_START = "2026-07-01T00:00:00.000Z";
    export const SEED_WINDOW_END = "2026-07-08T00:00:00.000Z";
    export const SEED_PLAN_START = "/* <agentCbSeedsPlan>";
    export const SEED_PLAN_END = "</agentCbSeedsPlan> */";
    export const SEED_ASSET_URLS_START = "// <agentCbSeedAssetUrls>";
    export const SEED_ASSET_URLS_END = "// </agentCbSeedAssetUrls>";
    export interface SeedFieldDefinition {
        fieldId: string;
        type: string;
        required: boolean;
        enumValues: string[];
    }
    export interface SeedEntityDefinition {
        entityId: string;
        title: string;
        kind: string;
        fields: SeedFieldDefinition[];
        /**
         * The lifecycle states this module actually OPERATES on — the union of `fromStates` of the entity's
         * workflow transitions. Not every declared state: a screen that decides on a state filters by it, and
         * that is the set a seed has to cover. Absent for an entity with no workflow (nothing to cover).
         */
        operatedStates?: string[];
    }
    export interface SeedTableColumn {
        name: string;
        type: string;
        nullable: boolean;
    }
    export interface SeedTableDefinition {
        tableId: string;
        tableName: string;
        seedFor: string;
        /** Real table columns. MUST include the details column when the TableDefinition enables it — the
         * emitter only writes a row property for a declared column, so omitting it DROPS the whole details
         * payload (102051: every seeded row lost its planned `details`, see detailsColumnName). */
        columns: SeedTableColumn[];
        primaryKey: string[];
        /** The JSONB envelope column declared by `detailsColumn` in the TableDefinition (`enabled` + a
         * `columnName` that is conventionally, but not necessarily, `details`). Empty when the table has none. */
        detailsColumnName?: string;
        /** Embedded child collections stored INSIDE the details envelope (declared by the TableDefinition).
         * Surfaced to the planner so an aggregate that owns children (e.g. order items) actually gets them. */
        childCollections?: string[];
    }
    /** The details envelope column of a table plan: the explicit declaration when present, else the
     * conventional `details` if such a column exists. Keeps the compiler honest about WHERE the JSONB goes
     * without hardcoding the name at every use site. */
    export function detailsColumnOf(table: Pick<SeedTableDefinition, 'columns' | 'detailsColumnName'>): string;
    export interface SeedReference {
        ref: string;
    }
    export interface SeedAssetRef {
        asset: string;
        kind: 'image';
    }
    export type SeedValue = string | number | boolean | null | SeedReference | SeedAssetRef;
    export interface SeedFieldValue {
        name: string;
        value: SeedValue;
    }
    export interface SeedChildRow {
        key: string;
        fields: SeedFieldValue[];
    }
    export interface SeedChildCollection {
        name: string;
        rows: SeedChildRow[];
    }
    export interface SeedLocalRow {
        key: string;
        columns: SeedFieldValue[];
        details: SeedFieldValue[];
        children: SeedChildCollection[];
    }
    export interface SeedLocalTable {
        tableId: string;
        rows: SeedLocalRow[];
    }
    export interface SeedMdmRelationship {
        targetRef: string;
        type: string;
        metadata: SeedFieldValue[];
        isBidirectional: boolean;
    }
    export interface SeedMdmRow {
        key: string;
        fields: SeedFieldValue[];
        relationships: SeedMdmRelationship[];
    }
    export interface SeedMdmEntity {
        entityId: string;
        rows: SeedMdmRow[];
    }
    export interface SeedPlan {
        summary: string;
        localTables: SeedLocalTable[];
        mdmEntities: SeedMdmEntity[];
    }
    export interface SeedRuleDefinition {
        ruleId: string;
        title: string;
        description: string;
        appliesTo: string[];
    }
    export interface SeedRelationshipDefinition {
        fromEntity: string;
        toEntity: string;
        type: string;
    }
    /** A deterministic batch of seed-plan targets. All references emitted by a target in a wave resolve
     * to a target in an earlier wave, or to another target in that same wave (a dependency cycle). */
    export interface SeedPlanningWave {
        index: number;
        tableIds: string[];
        mdmEntityIds: string[];
    }
    export interface SeedPlanProgress {
        plan: SeedPlan;
        partial: boolean;
        completedWaveIndexes: number[];
    }
    export interface SeedReferenceCatalogItem {
        ref: string;
        label: string;
        context: string;
    }
    export interface SeedPlanPromptOptions {
        catalog?: SeedReferenceCatalogItem[];
        priorSummary?: string;
        wave?: SeedPlanningWave;
        estimatedOutputTokens?: number;
    }
    export const MAX_SEED_WAVE_OUTPUT_TOKENS = 12000;
    /** An L4 actor (platform user role). Some FK fields (e.g. an assignee or the actorSession-resolved
     * worker on an event) reference a platform-user identity, NOT a module-owned entity — there is no
     * table/MDM entity to seed. The generator synthesizes a small, deterministic pool of platform-user
     * identities per actor so those FKs resolve to real MDM Person records instead of a fabricated table. */
    export interface SeedActorDefinition {
        actorId: string;
        title: string;
    }
    export interface SeedTimeWindow {
        start: string;
        end: string;
    }
    export interface SeedBuildInput {
        project: number;
        moduleName: string;
        language: string;
        entities: SeedEntityDefinition[];
        tablePlans: SeedTableDefinition[];
        ruleIds: string[];
        /** Full L4 rule text for the applied ruleIds. Passed to the planner so rule conformance is guided
         * by L4 semantics instead of hardcoded, domain-specific checks. */
        rules?: SeedRuleDefinition[];
        /** L4 relationship graph, so the planner models MDM relationships generically (no invented,
         * per-domain type names baked into this generator). */
        relationships?: SeedRelationshipDefinition[];
        /** L4 actors. The generator exposes a resolvable platform-user identity pool per actor so FKs that
         * reference a platform user (assignees, actorSession-resolved fields) never fabricate a table. */
        actors?: SeedActorDefinition[];
        /** Allowed timestamp window; every timestamp must be ISO 8601 within it. */
        timeWindow?: SeedTimeWindow;
        /** Targets deliberately left with NO seed rows (a wave that never converged). Recorded in the
         * emitted artifact so downstream consumers can tell "empty by design" from "generation lost it". */
        skipped?: SeedSkippedTargets;
        /**
         * Canonical tags (`<module>.<Entity>`) that generated usecases actually read through `ctx.mdm`
         * (`listByType` or lifecycle). Derived from the pinned `mdm` block + generated sources — never
         * guessed from an entity name. While `MDM_WRITE_PATH_ENABLED` is false those entities still have
         * LOCAL tables; the index must be seeded too or lists/inactivate return empty/NOT_FOUND (be5).
         */
        mdmRequiredTags?: string[];
        plan: SeedPlan;
    }
    /** Machine-readable seed coverage: which targets have NO rows on purpose. The seed give-up narrows
     * tablePlans/entities so a non-converging wave cannot fail the whole backend — which silently left
     * tables with zero rows (102051: AiSalesSummary, AiPromotionSuggestion). A test generator asserting
     * "at least one row" against those produces impossible cases, so the fact is published, not implied. */
    export interface SeedSkippedTargets {
        tables: string[];
        mdmEntities: string[];
        reason: string;
        /** Violations of EACH planner attempt, in order. The give-up reason used to keep only the last. */
        attempts?: {
            attempt: number;
            errors: string[];
        }[];
    }
    /** One planner try for a seed wave. Kept across repair steps so a later try cannot silently regress
     * a field that already validated, and so give-up can name every attempt's violations. */
    export interface SeedAttemptRecord {
        attempt: number;
        plan: SeedPlan;
        errors: string[];
    }
    export interface SeedBuildResult {
        errors: string[];
        content?: string;
        summary: string;
    }
    /**
     * Partitions seed targets by their real dependency graph. MDM starts in the first wave, ordinary
     * persistence tables in the second, and supporting/event tables in the third; a dependency moves
     * only its dependant forward. Strongly connected targets stay together so mutual references remain
     * valid within one LLM call.
     */
    export function deriveSeedPlanningWaves(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>): SeedPlanningWave[];
    /** Keeps a wave under the output budget by assigning whole dependency components to sequential
     * batches. An SCC is never split, so references inside a planning wave remain valid. */
    export function splitSeedPlanningWave(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave, maxTokens?: number): SeedPlanningWave[];
    export function estimateSeedPlanningWaveTokens(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave): number;
    /** Selects exactly the L4/table definitions that a wave may create. Rules and relationships are
     * filtered too, so unrelated definitions never inflate the planner context. Coverage of ctx.mdm
     * tags is scoped the same way: a wave cannot seed (or be failed for) a tag whose entity is not
     * in the wave. Full-tag coverage is the merge-final validator's job. */
    export function seedPlanInputForWave(input: Omit<SeedBuildInput, 'plan'>, wave: SeedPlanningWave): Omit<SeedBuildInput, 'plan'>;
    export function isSeedAssetRef(value: unknown): value is SeedAssetRef;
    /** Turns a tool-call result into a defensive internal representation. Validation below remains the
     * authority: malformed values become empty and produce objective findings instead of being trusted. */
    /**
     * Drop columns the compiler already owns, so a planner that echoes them does not fail the wave.
     *
     * The prompt says PKs are compiled from tableId+row key and the JSONB envelope is `row.details`,
     * never a `columns` entry. Repair waves still put `"name":"pet_id","value":null` and
     * `"name":"details","value":null` in `columns` — which `validateSeedPlan` reports as
     * `unknown persistence column` and then skips the rest of the module (petShop wave 3: Pet /
     * ScheduleBlock / InstitutionalPresentation generated, then discarded). Stripping those names is
     * the legitimate path; unknown *other* columns stay fatal.
     */
    /** `petShop.BusinessHours` (the ctx.mdm tag) → `BusinessHours` (the entity id). */
    export function stripModuleEntityPrefix(id: string, moduleName: string): string;
    export function normalizeSeedPlan(plan: SeedPlan, tablePlans?: Iterable<SeedTableDefinition>, moduleName?: string): SeedPlan;
    export function parseSeedPlan(value: unknown): SeedPlan;
    /** Reads the persisted plan embedded in seeds.ts. A valid plan is reused so materializing the same
     * L4/table input never asks the model for a different fixture mass. */
    export function extractSeedPlanFromSource(source: string): SeedPlan | null;
    /** Reads either a completed or interrupted seed run from the persisted envelope. */
    export function extractSeedPlanProgressFromSource(source: string): SeedPlanProgress | null;
    /** Reads the published seed coverage (targets intentionally left with no rows) back from a generated
     * seeds.ts. Returns null when the artifact declares nothing skipped — i.e. full coverage. Consumers
     * (register -> l5 config, and any test generator) use this instead of inferring from missing exports. */
    export function extractSeedSkippedFromSource(source: string): SeedSkippedTargets | null;
    export function parseSeedAttemptRecords(value: unknown): SeedAttemptRecord[];
    /**
     * A repair must not regress a field that already validated. Take the newer plan as the skeleton
     * (keys, extra rows) and restore any prior value that was valid when the newer one is missing or
     * invalid. Row keys that only differ by whitespace (`pet thor` vs `pet_thor`) match so a repair
     * that fixed the key does not drop the fields that were already good.
     */
    export function recoverSeedPlanFromPrior(prior: SeedPlan, next: SeedPlan, priorErrors: string[], nextErrors: string[]): SeedPlan;
    export function formatSeedGiveUpReason(waveIndex: number, attempts: SeedAttemptRecord[], maxAttempts: number): string;
    /** Prefer a fully valid attempt; otherwise recover valid fields forward from earlier tries. The
     * recovered plan is used only when it validates — a still-invalid plan must not be planted. */
    export function selectSeedPlanAfterAttempts(attempts: SeedAttemptRecord[], validate: (plan: SeedPlan) => string[]): {
        plan: SeedPlan;
        errors: string[];
    };
    /** A partial seeds.ts remains valid TypeScript so an interrupted flow can be resumed without
     * re-planning completed waves. It intentionally exports no runtime rows until final compilation. */
    export function buildPartialSeedSource(input: Pick<SeedBuildInput, 'project' | 'moduleName' | 'language'>, progress: Pick<SeedPlanProgress, 'plan' | 'completedWaveIndexes'>): string;
    export function mergeSeedPlans(current: SeedPlan, next: SeedPlan): SeedPlan;
    export function seedReferenceCatalog(plan: SeedPlan): SeedReferenceCatalogItem[];
    /**
     * The 102034 `MdmSubtype` union is CLOSED (Person | Company | Product | Service | Location | Asset* |
     * Animal | BankAccount | Document | ContactChannel), so every module entity that lands in MDM has to be
     * mapped onto one of them. The heuristic is shared with the usecase generator (the write path passes the
     * same subtype `ctx.mdm.entity.create` expects) so a seeded row and a runtime-created row of the same
     * entity never disagree. Its limit is real and recorded in ajustes_ns4.md: an entity with no natural
     * subtype (a construction project) falls back to 'Product'.
     */
    export function mdmSubtypeFor(entityId: string): string;
    /**
     * A `{ ref }` is only legitimate on a foreign key. `weeklySchedule: { ref: "local:BusinessHours.x" }`
     * was compiled to the row's own uuid (be5 qryListBusinessHours). Auto-reference is always an error.
     */
    export function fieldAllowsSeedRef(fieldName: string, knownEntityIds: Iterable<string>): boolean;
    /** A `…Date` field is a CALENDAR DATE; a `…At` field is an INSTANT.
     *
     * The validator used to demand a full ISO datetime for both (`/(At|Date)$/`), so a planner that wrote
     * `"2026-07-03"` for `workDate`/`dueDate`/`issueDate`/`plannedStartDate`/`shiftDate` was rejected — 16 of
     * the 19 findings that burned both repair attempts in 102045/buildFlowFsm, and the same failure that
     * killed wave 2 of cafeFlow run14. The planner was RIGHT: generated usecases compare these fields as
     * plain `YYYY-MM-DD` strings (e.g. `shift.shiftDate >= periodStart` built from `iso.slice(0, 10)`), so a
     * datetime stored there silently breaks same-day comparisons. Date-only is therefore ACCEPTED for a
     * `…Date` field; `…At` stays strict, because an instant with no time is a different kind of wrong. */
    export function isDateOnlyField(fieldName: string): boolean;
    /**
     * Does an `…Id` field actually REFERENCE something seedable — a module entity or a platform-user
     * identity? Only then must its value be a symbolic `{ ref }`.
     *
     * The old rule was "every field ending in Id must be a { ref }", which is false for identifiers that are
     * plain data: `taxId` on an MDM Client is a tax number, not a pointer, and there is no `Tax` entity to
     * point at — yet the planner was told three times to make it symbolic (102045/buildFlowFsm), an
     * impossible instruction that burned the repair budget and forced the give-up.
     *
     * Matching is by SUFFIX against the known entity names, so a decorated id still resolves:
     * `topMenuItemId` ends with `MenuItemId` -> `MenuItem` exists -> a ref IS required (keeping it strict
     * avoids reintroducing dangling references). `closedByUserId` is platform-user-shaped -> strict too.
     * Only when nothing can be pointed at is a literal accepted.
     */
    export function idFieldHasResolvableTarget(fieldId: string, knownEntityIds: Iterable<string>): boolean;
    /** MDM index label: `name` on the envelope, else `fullName`/`title`, else the row key. Shared by
     * the validator (allows synthetic `name`), the local→MDM mirror, and the index emitter. */
    export function mdmIndexName(fields: Map<string, unknown> | Record<string, unknown> | SeedFieldValue[], fallbackKey: string): string;
    /** Deterministic validation of the plan before any seed source is saved. */
    export function validateSeedPlan(input: SeedBuildInput, knownReferences?: Iterable<string>): string[];
    /**
     * Canonical tags generated usecases actually hit via `ctx.mdm`. The pinned `mdm` block does not
     * carry the entity name — that comes from the operation's `entity`. `listByType({ type })` in the
     * generated .ts is the other surface. Never infer a tag from a name that has no mdm block / call.
     */
    export function collectRequiredMdmTags(input: {
        moduleName: string;
        mdmOwners: Array<{
            entity: string;
            mdm?: unknown;
        }>;
        usecaseSources?: Iterable<string>;
    }): string[];
    /** MDM ids that a give-up must publish: kind `mdm` OR a required ctx.mdm tag that has no plan row. */
    export function skippedMdmEntityIds(input: Pick<SeedBuildInput, 'entities' | 'mdmRequiredTags' | 'moduleName'>, seededMdmIds: Set<string>): string[];
    /** Every tag a generated usecase reads through ctx.mdm needs at least one MDM plan row with that tag. */
    export function collectRequiredMdmTagCoverage(input: SeedBuildInput): string[];
    /**
     * Copy local rows of a ctx.mdm-read entity into `mdmEntities`, same keys (so emitted ids match).
     * MDM cadastral `status` is Active — the local lifecycle status stays on the local table.
     */
    export function mirrorLocalRowsAsMdmPlan(plan: SeedPlan, tags: readonly string[], moduleName: string, timeWindow?: SeedTimeWindow): SeedPlan;
    /**
     * Clone a planned row for each OPERATED lifecycle state the plan missed. The validator already
     * demands one row per operated state; the planner historically covered only "main" states and
     * the wave gave up (be5 wave 6: ServiceExecution arrived).
     */
    export function coverMissingOperatedStates(plan: SeedPlan, input: Pick<SeedBuildInput, 'entities'>): SeedPlan;
    /** Deterministic repairs the LLM is taught to do but often misses in two attempts: operated-state
     * coverage and MDM index rows for tags the generated usecases already call. */
    export function repairSeedPlanDeterministically(plan: SeedPlan, input: Omit<SeedBuildInput, 'plan'> & {
        plan?: SeedPlan;
    }): SeedPlan;
    /**
     * Every OPERATED lifecycle state of an entity needs at least one seeded row in it.
     *
     * A screen that decides on a state filters by it, so a state nobody seeded makes that screen open empty
     * and its test fail for a reason that has nothing to do with the screen: the buildFlowFsm production run
     * had all three change-order journeys reporting `expected >= 1 item(s), got 0` because no ChangeOrder
     * was seeded as `submitted` or `pendingClientApproval`. One incomplete generator, five failures.
     *
     * "Operated" is the union of the `fromStates` of the entity's workflow transitions — the states some
     * transition READS. Requiring every DECLARED state instead would demand a row for terminal states nobody
     * queries and inflate every plan (the cafeFlow fixture alone would need 6 more rows), so the rule follows
     * the workflow, not the enum. Entities with no workflow, and entities the plan gave up on, are silent.
     */
    export function collectLifecycleStateCoverage(input: SeedBuildInput): string[];
    export function seedAssetUrlsBlock(urls: Record<string, string>, warnings?: string[]): string;
    export function updateSeedAssetUrlsInSource(source: string, urls: Record<string, string>, warnings?: string[]): string;
    /** Compile a validated plan. IDs, relationship IDs and structural MDM records are always generated
     * locally; only the business scenario itself comes from the LLM plan. */
    export function buildSeedSource(input: SeedBuildInput): SeedBuildResult;
    export function seedPlanPromptContext(input: Omit<SeedBuildInput, 'plan'>, repairFindings?: string[], options?: SeedPlanPromptOptions): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbTableIndexes" {
    export function isRedundantPrimaryKeyIndex(input: {
        tableName: string;
        primaryKey: readonly string[];
        indexName: string;
        indexColumns: readonly string[];
    }): boolean;
    /** Strip colliding PK indexes from a planner table item (or a TableDefinition-shaped object) before save. */
    export function sanitizePlannerTableItem<T extends Record<string, unknown>>(item: T): T;
    /** Findings for validate-all: a table defs/ts that still declares a redundant PK index. */
    export function collectRedundantPkIndexFindings(source: string, label: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/fixtures/appointmentAvailability" {
    export const appointmentAvailabilityTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: {
            name: string;
            postgresType: string;
            description: string;
        }[];
        primaryKey: string[];
        indexes: ({
            name: string;
            columns: string[];
            unique: boolean;
        } | {
            name: string;
            columns: string[];
            unique?: undefined;
        })[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/fixtures/serviceExecution" {
    export const serviceExecutionTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: ({
            name: string;
            postgresType: string;
            description: string;
            nullable?: undefined;
        } | {
            name: string;
            postgresType: string;
            nullable: boolean;
            description: string;
        })[];
        primaryKey: string[];
        indexes: {
            name: string;
            columns: string[];
        }[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTableIndexes.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbWorkspace.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/promptMarkers.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalSummary.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalSummary" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalizeStatus.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalizeStatus" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102025_/l2/toolSchemaLint" {
    export function lintToolSchema(parametersJson: string): string[] | null;
}
declare module "_102025_/l2/testLlmClient" {
    export interface CollabLlmConfig {
        baseUrl: string;
        token: string;
        org?: string;
    }
    export interface ToolProviderResult {
        modelType: string;
        status: number;
        text: string;
        args: unknown;
        schemaReject: boolean;
    }
    export function liveTestsEnabled(): boolean;
    export function liveRuns(): number;
    export function parseEnvFile(content: string): CollabLlmConfig;
    export function callToolProvider(cfg: CollabLlmConfig, opts: {
        modelType: string;
        system: string;
        human: string;
        tool: unknown;
        maxTokens?: number;
        timeoutMs?: number;
    }): Promise<ToolProviderResult>;
    export function callBothModelTypes(cfg: CollabLlmConfig, opts: {
        system: string;
        human: string;
        tool: unknown;
        maxTokens?: number;
    }): Promise<ToolProviderResult[]>;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/agentCbRepositoryAdapter.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/agentCbRepositoryAdapter" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/pet" {
    export const petTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: {
            name: string;
            postgresType: string;
            description: string;
        }[];
        primaryKey: string[];
        indexes: {
            name: string;
            columns: string[];
            unique: boolean;
        }[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/petRepositoryAdapter" {
    export const PET_ADAPTER_DEFECT: string;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-domain/agentCbDomainEntity.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-domain/agentCbDomainEntity" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-http/agentCbHttpController.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-http/agentCbHttpController" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-port/agentCbRepositoryPort.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-port/agentCbRepositoryPort" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/agentCbSeedAssets.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/seedAssetsCore" {
    import { type SeedEntityDefinition, type SeedPlan } from "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore";
    export const SEED_ASSET_SCHEMA_VERSION = 1;
    export interface SeedAssetManifestEntry {
        id: string;
        path: string;
        publicUrl: string;
        source: 'imagem';
        promptHash: string;
        status: 'ready' | 'failed';
        warning?: string;
    }
    export interface SeedAssetManifest {
        schemaVersion: number;
        moduleId: string;
        assets: SeedAssetManifestEntry[];
    }
    export interface SeedAssetRequest {
        assetId: string;
        targetPath: string;
        path: string;
        publicUrl: string;
        alt: string;
        prompt: string;
        promptHash: string;
        format: 'webp';
        maxWidth: number;
    }
    export function emptySeedAssetManifest(moduleId: string): SeedAssetManifest;
    export function parseSeedAssetManifest(value: unknown, moduleId: string): SeedAssetManifest;
    export function putSeedAssetManifestEntry(manifest: SeedAssetManifest, entry: SeedAssetManifestEntry): SeedAssetManifest;
    export function readySeedAssetUrls(manifest: SeedAssetManifest): Record<string, string>;
    export function seedAssetWarnings(manifest: SeedAssetManifest): string[];
    export function collectSeedAssetRequests(moduleId: string, plan: SeedPlan, entities: SeedEntityDefinition[]): SeedAssetRequest[];
    export const SEED_ASSET_CAP = 8;
    export function capSeedAssetRequests(requests: readonly SeedAssetRequest[], cap?: number): {
        kept: SeedAssetRequest[];
        dropped: string[];
    };
    /** Trace line for the dropped candidates (empty when nothing was capped). */
    export function seedAssetCapWarning(dropped: readonly string[], cap?: number): string;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/agentCbSeedAssets" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/seedAssetsCore.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-seeds/agentCbSeeds.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-seeds/agentCbSeeds" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/agentCbPersistenceTable.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/agentCbPersistenceTable" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-usecase/agentCbUsecase.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/gen-usecase/agentCbUsecase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/judge/judgeShared" {
    import { type CbScan, type CbOwner } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    import { type CbJudgeFinding } from "_102021_/l2/agentChangeBackend/helpers/cbRepair";
    /** Step args of every judge step of a run: which pass it is, its scope and (for a worker) its slice. */
    export interface CbJudgeArgs {
        judgeRun: number;
        owners: string[];
        queue: string[] | null;
        batchIndex: number;
        /** Which RUN of the task these findings belong to (see judgeFindingsFileInfo). */
        runId: string;
    }
    export function judgeArgsOf(step: mls.msg.AIAgentStep): CbJudgeArgs;
    /** Read the saved usecase defs data for the given operation owners (null when missing). */
    export function readUsecaseDefsByOwner(scan: CbScan, operations: CbOwner[]): Promise<Map<string, Record<string, unknown> | null>>;
    /** The operation owners in scope for this judge run (all on run 1; only the repaired subset after). */
    export function scopedOperations(scan: CbScan, step: mls.msg.AIAgentStep): {
        judgeRun: number;
        operations: CbOwner[];
    };
    /**
     * The slice of the module THIS step judges, and what is left for the next one.
     *
     * 119 pairs of (L4 contract + generated usecase defs) pretty-printed is megabytes: the intents POST
     * answered 413 and the step hung forever. The batch is planned from the real byte size of each pair,
     * and both hooks plan it the same way from the same step args — nothing extra has to be threaded
     * through, and the after-hook always knows exactly which owners the model just saw.
     */
    export function planJudgeSlice(step: mls.msg.AIAgentStep, operations: CbOwner[], defsByOwner: Map<string, Record<string, unknown> | null>): {
        pairsByOwner: Map<string, unknown>;
        batch: CbOwner[];
        pending: string[];
        batchIndex: number;
        totalQueued: number;
    };
    /** Deterministic pre-findings: an operation owner whose usecase .defs.ts is missing entirely, plus
     *  (T12) one whose defs omit the principal aggregate's local port — a DERIVATION gap that would
     *  otherwise only surface as broken TypeScript after 2-3 expensive materialization repairs. */
    export function missingDefsFindings(defsByOwner: Map<string, Record<string, unknown> | null>, scan: CbScan, operations: CbOwner[]): CbJudgeFinding[];
    /** The reduced L4 contract the judge compares against (authoritative side). */
    export function ownerContract(o: CbOwner): {
        ownerId: string;
        opKind: string;
        entity: string;
        actors: string[];
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbAccessPattern;
        inputs: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbOperationInput[];
        contextResolution: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbContextResolution[];
        acceptanceAssertions: string[];
    };
    /**
     * Where a worker leaves what it found, so the collector can union the batches. The disk is truth: the
     * runtime discards a fan-out child's return value.
     *
     * The RUN is part of the name. The findings of a previous execution stay in `l4/trace` (they are the
     * audit of that run), and a new judge run 1 would otherwise read them as its own and route usecases to
     * repair over findings nobody made this time.
     */
    export function judgeFindingsFileInfo(runId: string, judgeRun: number, batchIndex: number): Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    /** The shortName prefix every batch file of one (run, judge pass) shares. */
    export function judgeFindingsPrefix(runId: string, judgeRun: number): string;
    export interface CbJudgeBatchFindings {
        runId: string;
        judgeRun: number;
        batchIndex: number;
        owners: string[];
        findings: CbJudgeFinding[];
        savedAt: string;
    }
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { judgeArgsOf } from "_102021_/l2/agentChangeBackend/steps/judge/judgeShared";
    export function createAgent(): IAgentAsync;
    export { judgeArgsOf };
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudgeBatch" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudgeCollect" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/materialize/agentCbMaterialize.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/materialize/agentCbMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/phase/agentCbPhase.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/phase/agentCbPhase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/rebuild-defs-cleanup/agentCbRebuildDefsCleanup.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/register/agentCbRegister.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/register/agentCbRegister" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbLockOwners.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbLockOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbScanCreateOwners.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbScanCreateOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbValidateL4Readiness.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbValidateL4Readiness" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/validate-all/agentCbValidateAll.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/validate-all/agentCbValidateAll" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
