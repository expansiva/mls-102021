declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPlanner" {
    export type PlannerStatus = 'ok' | 'needs_input' | 'failed';
    export interface PlannerOutput<T> {
        status: PlannerStatus;
        result: T;
        questions: string[];
        trace: string[];
    }
    export interface PlannerExtractConfig<T> {
        toolName: string;
        preNormalizeResult?: (value: unknown) => unknown;
        normalizeResult: (value: unknown) => T;
    }
    export function createPlannerToolSchema(toolName: string, description: string, resultSchema: Record<string, unknown>): mls.msg.LLMTool;
    export function extractPlannerOutput<T>(payload: unknown, config: PlannerExtractConfig<T>): PlannerOutput<T>;
    export function validateJsonSchema(value: unknown, schema: unknown, path: string): void;
    export function parseMaybeJson(value: unknown): unknown;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function assertRecord(value: unknown, path: string): Record<string, unknown>;
    export function assertArray(value: unknown, path: string): unknown[];
    export function assertString(value: unknown, path: string): string;
    export function optionalString(value: unknown): string | undefined;
    export function optionalStringArray(value: unknown): string[] | undefined;
    export function normalizeStringList(value: unknown, path: string): string[];
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     * collabBoot.projectId is authoritative (cbeMiniCfe feeds mls.setActualProject from it);
     * mls.actualProject is the fallback when the boot payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbAccess" {
    /**
     * Pure readers of l4 access-bindings + V4 operationAuthorityRefs, and the template emitters for the
     * person-scope predicate and the profile→authority table. No platform imports — unit-tested directly.
     *
     * The l4 is the only source of meaning. Field ids come from the declared anchor hops, never from a
     * name suffix. Missing authority on a V4 module is a named scan error, never a permissive fallback.
     */
    export const CB_ACCESS_BINDINGS_SCHEMA_V1 = "2026-09-08-ns4-access-bindings-v1";
    export const CB_ACCESS_MATRIX_SCHEMA_V4 = "2026-08-13-ns4-access-matrix-v4";
    export const CB_PERSON_LOGIN_FIELD = "platformUserId";
    export const CB_SCAN_AUTHORITY_REQUIRED = "CB_SCAN_AUTHORITY_REQUIRED";
    export const CB_SCAN_ACCESS_BINDINGS_WITHOUT_V4 = "CB_SCAN_ACCESS_BINDINGS_WITHOUT_V4";
    export const CB_SCAN_AUTHORITY_WITHOUT_BINDINGS = "CB_SCAN_AUTHORITY_WITHOUT_BINDINGS";
    export type CbAccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type CbAnchorDirection = 'forward' | 'incoming';
    export interface CbAccessAnchorHop {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: CbAnchorDirection;
    }
    export interface CbAccessAnchor {
        hops: CbAccessAnchorHop[];
        terminus: {
            entityRef: string;
            fieldId: string;
        };
    }
    export interface CbAccessBinding {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        mode: CbAccessScopeMode;
        description: string;
        anchor: CbAccessAnchor | null;
        projectionRef: string;
    }
    export interface CbSynthesizedAuthority {
        authorityRef: string;
        entityRef: string;
        profileRef: string;
        mode: CbAccessScopeMode;
        description: string;
        anchor: CbAccessAnchor | null;
    }
    export interface CbOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        authorityRefs: string[];
    }
    export interface CbAccessProfile {
        profileId: string;
        actorRefs: string[];
        kind: string;
    }
    export interface CbAccessGrant {
        profileRef: string;
        authorityRef: string;
        mode: CbAccessScopeMode;
    }
    export interface CbModuleAccess {
        hasV4: boolean;
        hasBindings: boolean;
        operationAuthorityRefs: CbOperationAuthorityRef[];
        bindings: CbAccessBinding[];
        synthesized: CbSynthesizedAuthority[];
        profiles: CbAccessProfile[];
        grants: CbAccessGrant[];
    }
    export interface CbEntityAccessCatalog {
        entityId: string;
        kind: string;
        storageTarget: string;
        mdmType: string;
        role: string;
        idField: string;
    }
    export interface CbOwnerAccess {
        authorityRefs: string[];
        publicRoute: boolean;
        scope: CbOwnerScope;
    }
    export interface CbOwnerScope {
        mode: CbAccessScopeMode | 'mixed' | 'none';
        authorityRefs: string[];
        description: string;
        projectionRef: string;
        anchor: CbAccessAnchor | null;
        helperName: string;
        alreadyApplied: boolean;
    }
    export interface CbScopeWalkStep {
        kind: 'sessionPersons' | 'join' | 'project';
        entityRef: string;
        mdmType: string;
        matchField: string;
        collectField: string;
        via: 'mdm' | 'port';
    }
    export interface CbScopeWalkPlan {
        filterFieldId: string;
        steps: CbScopeWalkStep[];
    }
    /** `access/access-bindings.defs.ts` — bindings + synthesized authorities. Empty when unreadable. */
    export function readAccessBindings(parsed: Record<string, unknown>): Pick<CbModuleAccess, 'bindings' | 'synthesized'>;
    /** V4 `operationAuthorityRefs` plus the profile/grant table from the access matrix. */
    export function readAccessMatrixV4(parsed: Record<string, unknown>): Pick<CbModuleAccess, 'hasV4' | 'operationAuthorityRefs' | 'profiles' | 'grants'>;
    export function mergeModuleAccess(matrix: ReturnType<typeof readAccessMatrixV4> | undefined, bindings: ReturnType<typeof readAccessBindings> | undefined): CbModuleAccess | undefined;
    export function authorityRefsForOperation(access: CbModuleAccess, operationId: string): string[];
    export function helperNameForOperation(operationId: string): string;
    export function resolveOwnerAccess(access: CbModuleAccess, owner: {
        id: string;
        entity: string;
    }): CbOwnerAccess | undefined;
    export function accessScanWarnings(access: CbModuleAccess | undefined, operationIds: readonly string[]): string[];
    export function customScopeRecords(access: CbModuleAccess | undefined, owners: ReadonlyArray<{
        id: string;
        entity: string;
    }>): Array<{
        operationId: string;
        description: string;
    }>;
    /**
     * Reverse-walk the declared hops from the Person terminus back to the operation entity.
     * Field ids are those of the hops — never inferred from a name.
     */
    export function planAnchorWalk(startEntity: string, anchor: CbAccessAnchor, entities: readonly CbEntityAccessCatalog[]): CbScopeWalkPlan | undefined;
    export interface ProfileAuthorityRow {
        profileId: string;
        actorIds: string[];
        roleScopes: string[];
        authorityRefs: string[];
    }
    export function buildProfileAuthorityTable(moduleName: string, access: CbModuleAccess): ProfileAuthorityRow[];
    export function operationAuthorityModes(access: CbModuleAccess, operationId: string, entityRef: string): Array<{
        authorityRef: string;
        mode: CbAccessScopeMode;
    }>;
    export function emitProfileAuthoritiesTs(moduleName: string, access: CbModuleAccess, owners: ReadonlyArray<{
        id: string;
        entity: string;
    }>): string;
    export function emitSessionScopeTs(moduleName: string, project: number, access: CbModuleAccess, owners: ReadonlyArray<{
        id: string;
        entity: string;
    }>, entities: readonly CbEntityAccessCatalog[]): string;
    export function pinUsecaseScope(result: Record<string, unknown>, scope: CbOwnerScope | undefined): void;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbDefsSource" {
    /**
     * Pure readers of the l4/l5 defs dialects, with no platform imports, so they can be tested directly.
     * Two generators write the artifacts this agent reads: ns/ns3 emitted `} as const;`, and ns4 emits
     * `} as const satisfies <Artifact>;` over a typed import.
     */
    export type CbEntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm' | 'external' | 'derived';
    /**
     * MDM WRITE PATH — off until the general rebuild.
     *
     * The l4 already declares the intention this switch honours (`storage.target: mdm | external |
     * moduleDatabase`, `storage.mdmType`, v6 vocabulary), so reading it is not a new-vocabulary migration:
     * it would change the classification of the module Wagner is testing (run 9 of buildFlowFsm, where
     * Client/Project/InventoryItem carry `target: mdm` and FieldWorker/PlatformUser carry `target:
     * external`) the moment the next generation runs. That is exactly what the ⏸️ of the spec forbids.
     *
     * Flipping this to `true` moves four things at once, which is why it is one constant and not four:
     *   1. `classifyEntityKind` stops mapping `mdm + moduleOwned` to `core` and starts honouring
     *      `storage.target` — so an MDM entity gets no local domain entity, port, adapter or table, and an
     *      `external` one gets none of those and no seeds either;
     *   2. the seed planner routes those entities to `mdmEntities` (102034 registry) instead of
     *      `localTables`, and drops `external` entities from the plan entirely;
     *   3. the usecase item carries `mdmWrites` (mdmType + subtype + idField), so create/update/delete of
     *      master data is generated against `ctx.mdm` — the surface skills/applicationUsecase.md already
     *      documents — instead of a local port;
     *   4. validate-all blocks on a local persistence/port/domain artifact for an MDM entity instead of
     *      only warning about it (`collectPersistencePolicyIssues`).
     *
     * The order of the general rebuild is in the spec: ns4 vocabulary first (`party`, `platformUserId`),
     * then this flag, then `/rebuild all`.
     *
     * FLIPPED ON 2026-08-24 by Wagner's decision, with the next run being a `/rebuild all`. The two
     * prerequisites above were already met. Note what the flip does NOT do: it changes how the NEXT
     * generation classifies entities, so a module generated while it was `false` keeps its local tables
     * until it is rebuilt. There is no partial reversal — a module is generated in one shape or the other.
     */
    export const MDM_WRITE_PATH_ENABLED = true;
    /** What `storage` declares about an entity: where it lives, and under which master-data type. */
    export interface CbEntityStorage {
        target: string;
        scope: string;
        mdmType: string;
        idField: string;
    }
    export function readEntityStorage(parsed: Record<string, unknown>): CbEntityStorage;
    /** Schema string the NS E4 emits for ontology v7 (`n04`, 2026-09-08). */
    export const CB_ONTOLOGY_SCHEMA_V7 = "2026-09-08-ns4-ontology-v7";
    /** Named scan error when a v7 entity omits `storage.idField`. Never fall back to a name suffix. */
    export const CB_SCAN_ID_FIELD_REQUIRED = "CB_SCAN_ID_FIELD_REQUIRED";
    /** Named scan error when a V4 module has an operation with no authorityRefs. Never a permissive fallback. */
    export { CB_SCAN_AUTHORITY_REQUIRED, CB_SCAN_ACCESS_BINDINGS_WITHOUT_V4, CB_SCAN_AUTHORITY_WITHOUT_BINDINGS, CB_ACCESS_BINDINGS_SCHEMA_V1, CB_ACCESS_MATRIX_SCHEMA_V4, readAccessBindings, readAccessMatrixV4, mergeModuleAccess, pinUsecaseScope, } from "_102021_/l2/agentChangeBackend/helpers/cbAccess";
    /**
     * l4 ontology schema generation. v7 carries `mdmSubtype` / `role` / `displayField` / required
     * `storage.idField`. Anything older is v6 and is read until the module is regenerated (2026-09-08).
     */
    export function ontologyDefsVersion(parsed: Record<string, unknown>): number;
    export type CbLifecycleReachedBy = 'actor' | 'command' | 'time';
    export interface CbLifecycleStateDecl {
        state: string;
        reachedBy: CbLifecycleReachedBy;
        ruleRef?: string;
    }
    /** Bare string = actor. Time states are computed on read and never persisted by default. */
    export function readLifecycleStates(value: unknown): CbLifecycleStateDecl[];
    export interface CbOntologyEntityRead {
        storage: CbEntityStorage;
        mdmSubtype: string;
        role: string;
        displayField: string;
        defsVersion: number;
        scanError?: {
            code: string;
            message: string;
        };
    }
    /**
     * v7 fields on an ontology entity. v6 modules keep compiling: missing `mdmSubtype`/`role`/
     * `displayField` are empty strings, and a missing `idField` is not a scan error until v7.
     */
    export function readOntologyEntity(parsed: Record<string, unknown>): CbOntologyEntityRead;
    export interface CbOntologyRelationshipRead {
        fromEntity: string;
        toEntity: string;
        type: string;
        persistenceMode: string;
        fromFieldIds: string[];
        toFieldIds: string[];
    }
    /** `ontology/index.defs.ts` `relationships[]` — the only FK source on v7. */
    export function readOntologyRelationships(index: Record<string, unknown>): CbOntologyRelationshipRead[];
    /** Foreign-key field ids declared for `entityId` on either end of a relationship. */
    export function fkFieldIdsForEntity(entityId: string, relationships: ReadonlyArray<{
        fromEntity: string;
        toEntity: string;
        fromFieldIds?: readonly string[];
        toFieldIds?: readonly string[];
    }>): Set<string>;
    /**
     * The kind this agent generates from, deciding between the two vocabularies AND the two policies.
     *
     * With the write path OFF the answer is exactly what it has always been (`entityKindOf`), so a run of
     * the current module is byte-identical. With it ON, `storage.target` — the field that actually carries
     * the l4 intention — wins over the pair kind/ownership: `mdm` means master data owned by 102034 (the
     * module writes it THROUGH the facade), and `external` means an identity that lives outside this
     * product (a platform user), which must never become a local table and must never be seeded.
     */
    /**
     * What a caller knows about an entity. `storage` is PARTIAL because only `readEntityStorage` produces the
     * complete block — a caller that has just `{ target }` (a fixture, a scan of an older l4) asks the same
     * question and must not have to invent the other three fields.
     */
    export interface CbEntityClassification {
        kind: string;
        ownership?: string;
        storage?: Partial<CbEntityStorage>;
    }
    /** A declaration that contradicts itself, for the scan to announce instead of resolving in silence. */
    export function contradictoryStorageDeclaration(input: CbEntityClassification): string;
    export function classifyEntityKind(input: CbEntityClassification, mdmWritePath?: boolean): CbEntityKind;
    export function parseDefsSource(content: string): unknown;
    /**
     * Replace only the value of a defs file, keeping everything the generator wrote around it — the
     * header, the `import type`, the `satisfies` and the trailing exports. The todo files belong to the
     * generator that emitted them; this agent only flips a status inside them.
     */
    export function replaceDefsValue(content: string, value: unknown): string | null;
    /**
     * The handler vocabulary is `query | command`, but `operation.kind` speaks the generator's dialect:
     * ns/ns3 said create|update|query|view, ns4 says list|getById|create|update|delete|transition|
     * commandInput. Only reads are queries; everything else writes.
     */
    export function handlerKindOf(opKind: string): 'query' | 'command';
    /**
     * ns4 classifies a read-model as `projection`, which is what `metric` already meant here: not an
     * aggregate root by itself, but still backed by a table and seeds WHEN an operation reads it (that
     * is how a dashboard answers at runtime). Casting it silently would land on `core` and give a
     * projection nobody queries a table of its own.
     *
     * `mdm` means two different things in the two vocabularies, and the difference is the OWNERSHIP:
     * here it has always meant "master data read by id through 102034 — no local table, no port, never
     * written locally", while ns4 writes `mdm` + `ownership: moduleOwned` for master data THIS MODULE
     * owns and publishes, and compiles create/update/delete over it. Read as external, those operations
     * have nowhere to live: run 8 of buildFlowFsm generated 4 stub usecases (`functions: []`) for
     * Client/InventoryItem/Project and the final gate failed with 12 "export not found". Owned master
     * data is a local aggregate — table, port, CRUD, seeds — which is exactly `core`.
     */
    export function entityKindOf(kind: string, ownership?: string): CbEntityKind;
    /** A ns4 workflow: the lifecycle of one entity, with states and transitions and no operations. */
    export function isEntityLifecycle(parsed: Record<string, unknown>): boolean;
    /**
     * The module a `TS2792 Cannot find module '<path>'` names, or '' for any other diagnostic.
     *
     * A generated file that imports a platform contract of another project (`/_102034_/l1/...`) compiles
     * against a Monaco model this agent borrows for the compile. When the borrow silently fails the
     * diagnostic is indistinguishable from a real broken import — and the seed run of 2026-08-16 died on
     * one, after two earlier waves had compiled the very same file. Recognizing the shape is what lets
     * the caller ask "does this file actually exist?" instead of blaming the plan.
     */
    export function phantomModulePathOf(diagnostic: string): string;
    /** `/_102034_/l1/server/.../contracts.js` -> the file coordinates of its source. */
    export function mlsImportPathParts(path: string): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
    } | null;
    /**
     * The cross-project module a resolution diagnostic names, whatever the compiler called it
     * (TS2792 "cannot find module … did you mean to set moduleResolution", TS2307 "cannot find module").
     *
     * Used where the file under compile is written by THIS agent from a fixed template — the seeds. There
     * the import is not a claim the LLM made (it only plans data rows), so a module that does not resolve
     * is an environment fact, and asking `mls.stor.files` whether the target exists measures the wrong
     * thing: it measures whether the session indexed the other project, not whether the plan is wrong.
     */
    export function aliasModuleResolutionPathOf(diagnostic: string): string;
    /**
     * Monaco's "model already exists" — raised by `addModels` for a file whose model IS loaded, under a
     * registry key this agent's guard does not compute. The goal of the call (a usable model) is already
     * met, so the caller treats it as success; reading it as a failure logged the same warning forever
     * and left the import unborrowed.
     */
    export function isModelAlreadyExistsError(message: string): boolean;
    const TODO_STATUS_FIELDS: readonly ["status", "statusBackend"];
    export function todoOwnerType(raw: string): 'operation' | 'workflow' | '';
    /** The field the file actually uses, so the write-back lands where the read came from. */
    export function todoStatusField(raw: Record<string, unknown>): typeof TODO_STATUS_FIELDS[number] | '';
    /** The key both sides of a read-back agree on: the owner kind AFTER the dialect alias, plus its id. */
    export function todoOwnerKey(kind: string, id: string): string;
    export interface CbTodoDivergence {
        /** `operation:listBusinessHours` — todoOwnerKey of the owner that does not match. */
        key: string;
        expected: string;
        /** The status the source carries, or `<missing>` when the owner is not in it at all. */
        found: string;
    }
    /**
     * Compare the statuses a run BELIEVES it wrote against the ones a todoBackend source actually carries.
     * Pure on purpose: this is the comparator behind the finalize read-back, and it has to be testable
     * without a stor, a model or a browser.
     *
     * Returns `null` when the source cannot be parsed at all — for the caller that is not "no divergence",
     * it is "unreadable", which is its own kind of failure.
     */
    export function todoStatusDivergences(content: string, expected: ReadonlyMap<string, string>): CbTodoDivergence[] | null;
    /**
     * Which l5 todoBackend file the finalize read-back should open. `moduleName` empty keeps the
     * historical first-file-in-the-project behaviour (single-module runs). Folder is compared by
     * equality, never substring: a module `todo` must not match `todoAvancado`.
     *
     * `none` = this project has no todoBackend at all (caller reports skip).
     * `module-missing` = other modules have a file, this one does not (the run wrote owners whose
     * file vanished — not the same as skip).
     */
    export type CbTodoReadBackPick = {
        kind: 'file';
        folder: string;
        ref: string;
    } | {
        kind: 'none';
    } | {
        kind: 'module-missing';
        moduleName: string;
        ref: string;
    };
    export function pickTodoBackendReadBack(folders: readonly string[], moduleName?: string): CbTodoReadBackPick;
    /**
     * Which l5 todoBackend file a status write should mutate. Prefer the file whose folder is the
     * owner's module; if that file exists but does not contain the owner, do NOT fall through to
     * another module (shared ids like `createTask` would corrupt the neighbour). Empty moduleName
     * keeps the historical search-by-owner-identity.
     */
    export function selectTodoBackendFileForStatusWrite<T extends {
        folder: string;
        content: string;
    }>(files: readonly T[], owner: {
        kind: string;
        id: string;
        moduleName: string;
    }): T | undefined;
    /**
     * MDM semantics the ns4 catalogue attaches to an operation whose entity declares
     * `storage.target: 'mdm'` (`Ns4E8MdmSemantics` -> `Ns4ClassicOperation.mdm`). Measured on
     * `mls-102047/l4/petShop/operations/`:
     *
     *   inactivateCustomer.defs.ts -> `"mdm": { "lifecycle": "inactivate" }`
     *   listCustomer.defs.ts       -> `"mdm": { "activeFilterInput": "includeInactive",
     *                                           "situationOutput": "active" }`
     *
     * It exists because master data is NEVER deleted: the tier-1 catalogue emits the inactivate/reactivate
     * pair instead of a delete, the list hides inactive records by default, and the situation shown on
     * screen derives from the MDM index status — never from an invented local `active` field.
     *
     * `activeFilterInput` names an input that does NOT exist in the operation's `inputs[]` (the ns4 gate
     * requires every input fieldRef to resolve to a real ontology field, and `includeInactive` is not one),
     * so the CB is what has to materialize it. See `synthesizeMdmInputs` in cbShared.
     */
    export interface CbOwnerMdm {
        /** 'inactivate' | 'reactivate' — the cadastral pair that replaces delete for master data. */
        lifecycle?: string;
        /** Name of the boolean input that opts INTO seeing inactive records. */
        activeFilterInput?: string;
        /** Name of the derived output field carrying the situation (from the index status). */
        situationOutput?: string;
    }
    /**
     * Absent (not empty) when the operation carries no `mdm` block — the l4s that predate the block must
     * produce byte-identical owners, which is what makes this readable without touching the write-path flag.
     */
    export function readOwnerMdm(parsed: Record<string, unknown>): CbOwnerMdm | undefined;
    /** Is this the cadastral pair (as opposed to an ordinary MDM update)? */
    export function isMdmLifecycle(mdm: CbOwnerMdm | undefined): boolean;
    /**
     * Pin the l4 `mdm` block onto the usecase defs the model just returned. The model implements the
     * body; this block is not its to invent or drop. Without the pin, `saveDefs` writes the model
     * output and `collectMdmLifecycleIssues` (which reads `data.mdm` of that defs) stays blind — three
     * petShop runs in a row emitted no-op lifecycles with the agent already correct in the build.
     */
    export function pinUsecaseL4Mdm(result: Record<string, unknown>, ownerMdm: CbOwnerMdm | undefined): void;
    /** Structural mirror of cbShared.CbOperationInput — declared here so this module stays platform-free. */
    export interface CbMdmOperationInput {
        inputId: string;
        fieldRef: string;
        type?: string;
        required: boolean;
        source: string;
        description: string;
    }
    /**
     * The one input the l4 CANNOT declare. `mdm.activeFilterInput` names a boolean flag (`includeInactive`)
     * that opts into seeing inactive records, but the ns4 gate requires every input `fieldRef` to resolve to
     * a real ontology field — and `includeInactive` is not a field of anything. Measured on the evidence:
     * `listCustomer.defs.ts` declares `activeFilterInput: 'includeInactive'` with `inputs: []`.
     *
     * So the CB materializes it here, at the SINGLE place owners are read, instead of only in the usecase
     * prompt: the http controller derives its boundary contract from `owner.inputs` too, and an input the
     * controller never learned about is a flag the caller cannot pass.
     *
     * `required: false` on purpose — the default behaviour is active-only, and a required flag would make
     * every existing caller of the list illegal.
     */
    export function synthesizeMdmInputs(inputs: CbMdmOperationInput[], mdm: CbOwnerMdm | undefined): CbMdmOperationInput[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore" {
    export interface PipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath?: string;
        dependsFiles?: string[];
        dependsOn?: string[];
        skills?: string[];
        rulesApplied?: string[];
        agent?: string;
    }
    export interface ParsedDefs {
        dataExportName: string | null;
        artifact: Record<string, unknown> | null;
        data: unknown;
        item: PipelineItem | null;
    }
    export interface PlannedItem {
        item: PipelineItem;
        rank: number;
        stale: boolean;
        reason: string;
    }
    export interface MaterializeEnv {
        readRef(ref: string): Promise<string | null>;
        modifiedMs(ref: string): Promise<number | null>;
    }
    export interface GenResult {
        code: string;
    }
    export function layerRank(type: string): number;
    /** Seeds are planned as JSON and compiled locally. An LLM rewrite would break determinism. */
    export function isDeterministicMaterializeType(type: string): boolean;
    export function orderItems(items: PipelineItem[]): PipelineItem[];
    export function isStale(tsExists: boolean): boolean;
    export function parseDefs(src: string): ParsedDefs;
    export const GEN_TOOL_NAME = "submitGeneratedTs";
    export const GEN_TOOL: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitGeneratedTs";
            readonly description: "Submit the complete generated TypeScript file content.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["code"];
                readonly properties: {
                    readonly code: {
                        readonly type: "string";
                        readonly description: "Complete TypeScript file content. Must start with the /// <mls fileReference=\"...\"> header.";
                    };
                };
            };
        };
    };
    export const DEFAULT_MODEL_TYPE = "code";
    export function parseModelType(systemPrompt: string): string | null;
    export function buildSystemPrompt(skillSections: string[], outputPath: string, modelType: string): string;
    export function buildHumanPrompt(data: unknown, contextSections: string[], outputPath: string): string;
    /**
     * The platform header is DERIVED from the file being written, never taken from the model's output.
     *
     * It used to be kept whenever the output already began with `///`, on the assumption that a model
     * echoing the header echoes it right. Two files of the buildFlowFsm run came back with
     * `enhancement="blank"` instead of `_blank` (`usecases/updateChangeOrder.ts` and
     * `adapters/persistence/changeOrderRepositoryAdapter.ts`) — written during a repair round, where the
     * model rewrites the whole file and retypes the first line. Nothing downstream reads the header, so it
     * failed silently. The path is just as forgeable as the enhancement, so both are rebuilt here: this
     * agent knows exactly which file it is saving, and the model's opinion about it is not needed.
     */
    export function applyHeader(outputPath: string, code: string): string;
    /**
     * Hygiene of the same seam as `applyHeader`: derive `.js` on path specifiers instead of trusting
     * the LLM. The Node ESM contract is guaranteed at rewrite time in `scripts/build.mjs` (complete
     * `.js` when the target exists in dist). This pass keeps generated source consistent with the skill;
     * it is not the defense that keeps the BFF alive.
     */
    export function ensureJsImportExtensions(code: string): string;
    /** True when a repair finding is a pure COMPILER error (from the per-file compile `compiler: ...` or the
     *  whole-project compile `compiler -> ...`). Micro-repair only applies when ALL findings are compiler. */
    export function isCompilerFinding(finding: string): boolean;
    /** T6: should ONE targeted rescue round fire (outside the global budget)? Only for a SMALL, compiler-only
     *  residual after the global budget is exactly spent — a larger or non-compiler residual is a genuine
     *  failure, not a last-mile fix. The caller bumps globalAttempts past the budget so this is a one-shot
     *  (`globalAttempts === budget` becomes false on the re-check). Pure/testable. */
    export function shouldTargetedRescue(input: {
        globalAttempts: number;
        budget: number;
        targetCount: number;
        maxTargets: number;
        findings: string[];
    }): boolean;
    /** After the repair budget (and the one-shot rescue) are spent, leftover compiler findings
     * degrade — they must not stall the run. Structural blocking findings still fail. */
    export function compilerFindingsDegradeAfterBudget(input: {
        blocking: string[];
        globalAttempts: number;
        budget: number;
    }): boolean;
    export function buildMicroRepairPrompt(input: {
        outputPath: string;
        code: string;
        findings: string[];
        contextSections: string[];
        pitfalls: string | null;
    }): {
        system: string;
        human: string;
    };
    export const CONTRACTS_102034: readonly string[];
    export function expandContextRef(ref: string, artifactType?: string, hasMdmRefs?: boolean): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSyntaxValidation" {
    /** Deterministic TypeScript syntax checks available even when Monaco is unavailable. */
    export function syntaxDiagnostics(content: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbProjectTsc" {
    export interface TscDiagnostic {
        project: number;
        folder: string;
        shortName: string;
        code: string;
        message: string;
    }
    export function parseTscDiagnostics(output: string): TscDiagnostic[];
    export function mlsBaseFromDiskPath(abs: string): string | null;
    /** Group tsc errors onto `${folder}::${shortName}`. In-scope files always appear (possibly empty);
     * other l1 files of the same module appear only when they have errors (seeds.ts, dto, …). */
    export function groupTscErrorsByFile(diagnostics: readonly TscDiagnostic[], files: Array<{
        folder: string;
        shortName: string;
    }>, project: number): Map<string, string[]>;
    export type CompileGatePath = 'monaco' | 'project-tsc' | 'unavailable';
    export interface CompileModuleTrace {
        path: CompileGatePath;
        reason?: string;
        rawDiagnostics: number;
        afterFilter: number;
        files: number;
    }
    export function countGroupedDiagnostics(grouped: Map<string, string[]>): number;
    export function formatCompileModuleTrace(trace: CompileModuleTrace): string;
    /** Instrument the project-tsc path: spawn-null vs parsed vs leftover after the in-module filter. */
    export function traceProjectTscResult(output: string | null, files: Array<{
        folder: string;
        shortName: string;
    }>, project: number, reasonIfNull: string): {
        grouped: Map<string, string[]> | null;
        trace: CompileModuleTrace;
    };
    export function mergeCompileTargets(inScope: Array<{
        folder: string;
        shortName: string;
        real: string;
    }>, compiled: Map<string, string[]>): Array<{
        folder: string;
        shortName: string;
        real: string;
    }>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo" {
    import type { PipelineItem } from "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore";
    import { type CompileModuleTrace } from "_102021_/l2/agentChangeBackend/helpers/cbProjectTsc";
    export interface ParsedMlsPath {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    /** Extract the `pipeline` array from a .defs.ts content string. */
    export function parsePipelineFromContent(content: string): PipelineItem[] | null;
    /** Scan every l1 .defs.ts (with a pipeline) of a module. */
    export function scanL1DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    /**
     * Whether the file is in this session's index at all — which `getFileModified` cannot say, because it
     * answers `null` both for "absent" and for "present, no usable timestamp". Conflating the two made a
     * resumed session read every generated .ts as never-generated and re-materialize files that were
     * already current (run of 2026-08-17: 14 of 34 controllers rewritten for nothing).
     */
    export function fileIsPresent(project: number, level: number, folder: string, shortName: string, extension: string): boolean;
    /** updatedAt (ms) of a file, MAX_SAFE_INTEGER when new/changed without a timestamp, else null. */
    export function getFileModified(project: number, level: number, folder: string, shortName: string, extension: string): number | null;
    /** Read any file by its full MLS path string. */
    export function getContentByMlsPath(mlsPath: string): Promise<string | null>;
    /** Parse a MLS path like `_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts`. */
    export function parseMlsPath(mlsPath: string): ParsedMlsPath | null;
    /**
     * Release everything the compiles queued, once no compile is in flight. `releaseBorrowedModels` only
     * drains at a quiescent point, and a long sweep (the whole-module compile borrows the imports of ~200
     * files) never reaches one on its own: the queue grows, the Monaco models pile up and the tab runs
     * out of memory. A caller that works in blocks calls this between them.
     */
    export function flushBorrowedModels(): Promise<{
        released: number;
        pending: number;
    }>;
    /**
     * Release every model of the module this agent is responsible for.
     *
     * `addModels` loads ALL siblings of a shortName — the `.defs.ts` rides along with the `.ts` — and not
     * every path releases symmetrically, so after run 9 the tab held 464 Monaco models against 256 registry
     * entries (208 orphans) plus ~all the module's defs. The delete now reaches an orphan by URI (platform
     * F2), so a final sweep can actually clean up.
     *
     * A file whose model was ALREADY in the registry when the run started belongs to the Studio (an open
     * tab) and is never touched — the same ownership rule the per-compile borrow uses.
     */
    export function sweepModuleModels(project: number, moduleName: string, keep: ReadonlySet<string>): {
        swept: number;
        kept: number;
    };
    /** The registry keys present right now — the caller snapshots them at the start of a run to know
     *  which models were NOT loaded by this agent (an open Studio tab). */
    export function modelRegistryKeys(): Set<string>;
    export function modelCounts(): {
        registry: number;
        pendingRelease: number;
        peak: number;
    };
    export function storDiskPath(info: {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }): string | null;
    export interface CompileModuleOutcome {
        errors: Map<string, string[]> | null;
        trace: CompileModuleTrace;
    }
    export function compileModuleAndGetErrors(project: number, files: Array<{
        folder: string;
        shortName: string;
    }>): Promise<CompileModuleOutcome>;
    /** Small deterministic fallback for syntax that TypeScript rejects before type checking. */
    export interface SaveGeneratedTsResult {
        ok: boolean;
        /** TypeScript errors of the per-file compile (spec item 11: feed the compiler error back into the
         * repair prompt). Empty when clean or when the compile environment is unavailable. */
        compileErrors: string[];
        /** Deterministic INTRA-FILE syntax findings (subset of compileErrors). Never a false positive —
         * callers gate on these immediately even when the cross-file compile is deferred. */
        syntaxErrors: string[];
        /**
         * Errors blaming an import whose source IS on disk — the model did not load, the plan is fine.
         * They are also in `compileErrors`; a caller must never route these to an LLM repair.
         */
        infraErrors: string[];
        /** False means Monaco/project compilation was unavailable; syntax fallback still ran. */
        compilerAvailable: boolean;
    }
    /**
     * Keep an ALREADY EXISTING Monaco model in sync with the content just persisted. Not cosmetic: the
     * Studio<->disk sync reads a file from its model first and only falls back to the stor content when
     * there is no model, and libModel.createModel hands back an existing model untouched (no setValue).
     * So without this, the SECOND write onwards updates the stor while the model stays frozen at the
     * first one, and the next export writes that first snapshot over the good content — the petShop lost
     * update of 2026-08-21 (65 todoBackend writes, disk got the state after write #1).
     *
     * Never CREATES a model: an unowned model is a leak (see releaseBorrowedModels/sweepModuleModels), and
     * with no model the export already reads the stor, which is correct. Hook writers call this; they must
     * not mention `mls.editor` themselves.
     */
    export function refreshExistingModel(file: mls.stor.IFileInfo, src: string): void;
    /** Read an already-existing Monaco model. Never creates one. `failed` is a throw from getModel/getValue. */
    export function readExistingModelValue(file: mls.stor.IFileInfo): {
        present: boolean;
        value: string | null;
        failed: boolean;
    };
    /** Save (create or overwrite) a generated file with an ARBITRARY extension, WITHOUT compiling. Used for
     * byte-mirror artifacts (l1 contract copies `.ts`/`.d.ts` — B5) where the whole-project compile in
     * validate-all owns correctness; a per-file compile of a `.d.ts` twin would be meaningless. Later
     * compile loads the model on demand via addModels; an open tab is synced, never created. */
    export function saveGeneratedFile(project: number, level: number, folder: string, shortName: string, extension: string, content: string): Promise<boolean>;
    /** Save (create or overwrite) a generated .ts file, force a recompile and report its errors. */
    export function saveGeneratedTs(project: number, level: number, folder: string, shortName: string, content: string): Promise<SaveGeneratedTsResult>;
    /** Whole-project compile check (used by cb-validate-all): compile an already-saved generated .ts and
     * return its errors. At that point every generated file exists, so findings are REAL — unlike the
     * per-file compile during the layer sweep, which is deferred (see agentCbMaterialize). Returns []
     * when Monaco is unavailable — the deterministic checks remain the floor. */
    export function compileSavedTsAndGetErrors(project: number, folder: string, shortName: string): Promise<string[]>;
    /** Pull the arguments of a named tool call out of the model payload (several shapes supported). */
    export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbWorkspace" {
    export interface CbBffCallInput {
        name: string;
        from: string;
        type?: string;
    }
    export interface CbBffCallOutputField {
        name: string;
        from?: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: CbBffCallOutputField[];
        };
    }
    export interface CbBffCallOutput {
        kind: 'object' | 'list' | 'paginated';
        fields: CbBffCallOutputField[];
    }
    export interface CbBffCallUse {
        operationId: string;
        optional?: boolean;
    }
    export interface CbBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: CbBffCallUse[];
        input: CbBffCallInput[];
        output?: CbBffCallOutput;
        route: string;
    }
    export interface CbWorkspace {
        workspaceId: string;
        moduleName: string;
        title: string;
        actors: string[];
        kind: string;
        purpose: string;
        bffCalls: CbBffCall[];
        operationIds: string[];
    }
    export interface CbActor {
        actorId: string;
        title: string;
        roleScope: string;
        moduleName: string;
    }
    export function readActorsField(obj: Record<string, unknown>): string[];
    export function readModuleActors(obj: Record<string, unknown>, moduleName: string): CbActor[];
    /**
     * ns4 has no `actors.defs.ts`: the audience of the module is the access matrix, whose profiles are
     * exactly the ids the operations already name in `actors[]`. `kind` (internal/external/system) is
     * the role scope.
     */
    export function readAccessMatrixActors(obj: Record<string, unknown>, moduleName: string): CbActor[];
    export function parseWorkspaceDefs(obj: Record<string, unknown>, moduleName: string): CbWorkspace | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTraceScope" {
    /** Called by the scan once the target module is resolved; every later write is scoped by it. */
    export function setCbTraceModule(moduleName: string): void;
    /** Empty when the scan has not resolved a module — callers must not invent a pipeline folder. */
    export function cbCurrentTraceModule(): string;
    export const CB_TRACE_LAYER = "l1";
    /** `l4/<module>/pipeline/trace/l1`. Empty when the module is unknown — never the bare `trace`. */
    export function cbLayerTraceFolder(moduleName: string): string;
    export function cbTraceFolder(): string;
    /** Readers look only at the current layer folder. Leftover layout is invisible on purpose. */
    export function cbTraceReadFolders(): string[];
    export function isCbLayerTraceFolder(folder: string, moduleName: string): boolean;
    export function listCbLayerTraceKeys(files: Record<string, {
        project?: number;
        level?: number;
        status?: string;
        folder?: string;
    } | null | undefined>, project: number, moduleName: string): string[];
    /** Stor identity of a CB step dump. JSON on purpose — not a defs artifact.
     *  (`defsRef` would force `.defs.ts` and the buildCI tsc would compile the JSON.) */
    export function agentTraceFileInfo(moduleName: string, agentName: string, stepId: unknown, project?: number): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbLifecycle" {
    export interface CbLifecycleTransition {
        transitionId: string;
        fromStates: string[];
        toState: string;
    }
    export interface CbEntityLifecycle {
        workflowId: string;
        entityRef: string;
        moduleName: string;
        states: string[];
        initialState: string;
        /** States the l4 file labelled terminal — informational. The matrix is the authority. */
        declaredTerminalStates: string[];
        transitions: CbLifecycleTransition[];
    }
    /** Compact per-entity payload for gen-domain / gen-usecase. */
    export interface CbLifecyclePrompt {
        workflowId: string;
        entityRef: string;
        states: string[];
        initialState: string;
        /** States with NO outgoing edge in `allowed`. Empty = no state is terminal. */
        terminalStates: string[];
        allowed: Record<string, string[]>;
    }
    /** Same shape `isEntityLifecycle` recognises, plus the transition rows. */
    export function parseEntityLifecycle(parsed: Record<string, unknown>, moduleName?: string): CbEntityLifecycle | null;
    export function allowedMatrix(lifecycle: CbEntityLifecycle): Record<string, string[]>;
    export function compactLifecycleForPrompt(lifecycle: CbEntityLifecycle): CbLifecyclePrompt;
    export function lifecycleForEntity(lifecycles: readonly CbEntityLifecycle[] | undefined, entityId: string): CbLifecyclePrompt | undefined;
    export function pairKey(from: string, to: string): string;
    export function allowedPairs(lifecycle: CbEntityLifecycle): Set<string>;
    /**
     * A generated `*_STATUS_TRANSITIONS` map (domain skill) or any `Record<Status, Status[]>` object
     * of that name. The usecase typically only calls `canTransition*`; the pairs live on this map.
     */
    export function extractStatusTransitionMap(source: string): Record<string, string[]> | null;
    export function collectLifecycleContradictionFindings(input: {
        lifecycle: CbEntityLifecycle | CbLifecyclePrompt | undefined;
        source?: string;
        invariants?: readonly string[];
        label?: string;
    }): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbReconcileBackendConfig" {
    export interface LiveBackendModule {
        moduleId: string;
        backendControllers: string;
        tableDefsDir: string;
    }
    export interface ReconcileBackendConfigResult<M extends Record<string, unknown>, P extends Record<string, unknown>> {
        modules: M[];
        persistenceModules: P[];
        discarded: string[];
    }
    export function formatDiscardedOrphans(discarded: readonly string[]): string;
    export function liveBackendModulesFromL5(l5Modules: unknown): LiveBackendModule[];
    /** Drop l5/project.json backend blocks whose persistence dir is gone, except the module this run owns. */
    export function pruneOrphanL5BackendModules<M extends Record<string, unknown>>(modules: readonly M[] | undefined, currentModuleName: string, tableDefsExists: (moduleName: string) => boolean): {
        modules: M[];
        discarded: string[];
    };
    export function reconcileClientBackendRegistration<M extends Record<string, unknown>, P extends Record<string, unknown>>(existingModules: readonly M[] | undefined, existingPersistence: readonly P[] | undefined, live: readonly LiveBackendModule[]): ReconcileBackendConfigResult<M, P>;
}
declare module "_102029_/l2/mlsDepManifest" {
    export interface MlsDepManifest {
        workspaceDependencies: string[];
    }
    export interface MlsDepWriteIo {
        read?(path: string): string;
        write(path: string, source: string): void;
    }
    /** Sorted unique ids: l5 list ∪ each master's runtimeProject ∪ the Studio pair ∪ 102041 when 102033 is present. */
    export function buildMlsDepWorkspaceIds(l5Config: unknown, l5Project: unknown): string[];
    export function serializeMlsDepJson(ids: readonly string[]): string;
    export function mlsDepJsonContents(l5Config: unknown, l5Project: unknown): string;
    export function mlsDepPathFromL5ConfigPath(configPath: string): string;
    /** Byte-identical content is a no-op so a second merge does not dirty the worktree. */
    export function emitMlsDepJson(destPath: string, l5Config: unknown, l5Project: unknown, io: MlsDepWriteIo): boolean;
    /**
     * Host-only write of `<client>/mlsDep.json`. No-op in the browser (no diskPath / no write
     * capability). Branches on capability, not on host name.
     */
    export function emitMlsDepJsonIfHostDisk(project: number, l5Config: unknown, l5Project: unknown): boolean;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPortMethods" {
    export interface OperationDeleteRef {
        id: string;
        entity: string;
        opKind?: string;
    }
    export interface PortPlanItem {
        entityId: string;
        embeddedMembers: string[];
        requiredMethods: string[];
    }
    export interface PortMethodSig {
        name: string;
        params: string[];
        returns: string;
        description: string;
    }
    export interface CbSystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    export const DELETE_PORT_METHOD: PortMethodSig;
    /** l4 operation that deletes an aggregate: id `deleteX` (same gate as collectDeleteOperationPortGaps) or kind `delete`. */
    export function isDeleteOperation(op: {
        id: string;
        opKind?: string;
    }): boolean;
    export function deleteTargetEntityIdsFromOperations(operations: readonly OperationDeleteRef[]): Set<string>;
    export function requiredMethodsForEntity(entityId: string, deleteTargetEntityIds: ReadonlySet<string>): string[];
    export function buildPortPlanItems(aggregates: ReadonlyArray<{
        rootEntity: string;
        embeddedMembers: string[];
    }>, deleteTargetEntityIds: ReadonlySet<string>): PortPlanItem[];
    export function unionMethodNames(...lists: readonly (readonly string[])[]): string[];
    export interface PortMethodPlanEntry {
        name: string;
        params: string[] | null;
        returns: string;
    }
    /** Full `data.methods` entries (name + params + returns). `params: null` / empty `returns` = unusable. */
    export function portMethodSigsFromPortData(data: unknown): PortMethodPlanEntry[];
    export function methodNamesFromPortData(data: unknown): string[];
    /** Plan `returns` is often a bare type (`void`, `Ticket | null`); the interface is always async. */
    export function promisedPortReturnType(returns: string): string;
    export function methodNamesFromPortDefsSource(source: string): string[];
    /** `requiredMethods` as persisted on the port `.defs.ts` data block. Absent or empty → do not invent. */
    export function requiredMethodsFromPortData(data: unknown): string[];
    export function isAppendOnlyPortData(data: unknown): boolean;
    export interface EnsurePortSourceResult {
        source: string;
        completed: string[];
        findings: string[];
        decisions: CbSystemDecision[];
    }
    /**
     * Materialize-time guarantee on the port `.ts`:
     * 1. Every method in `data.methods` is declared on the interface. Params/returns come from the
     *    plan; a bare return type is wrapped in `Promise<…>` (already-`Promise<…>` is left alone).
     * 2. `requiredMethods` still fills `delete(id: XId): Promise<void>` when the l4 required it and
     *    the plan did not list a usable signature. The two stay complementary.
     * 3. After completion, a plan method still missing is a finding (never silence).
     * Event ports stay append-only: a plan that lists `delete` does not get it (`stripEventPortDelete`).
     */
    export function ensureRequiredPortMethodsInSource(source: string, data: unknown): EnsurePortSourceResult;
    /**
     * If the l4 required `delete` and the model omitted it, add the signature and record a systemDecision.
     * Does not invent `delete` when it was not required. Mutates `item`.
     */
    export function ensureRequiredPortMethods(item: Record<string, unknown>, requiredMethods: readonly string[]): string[];
    /** Event ports are append-only: drop `delete` if the model (or a caller) put it there. */
    export function stripEventPortDelete(item: Record<string, unknown>): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbArchive" {
    /** Backend generated l1 lives under `<module>/layer_*`. Scope so one module never touches another. */
    export function isGeneratedBackendFolder(folder: string, modules: string[]): boolean;
    type StorFileLite = {
        project?: number | string;
        level?: number | string;
        status?: string;
        folder?: string;
        shortName?: string;
        extension?: string;
    } | null | undefined;
    /** Keys of l1 files that `/rebuild all` must archive before regenerating.
     *  Everything under `l1/<mod>/`: `.ts` and `.defs.ts`, every layer, `seeds.ts`,
     *  `registerRepositories.ts`, including leftovers whose stor status is already `deleted`. */
    export function listBackendL1ArchiveKeys(files: Record<string, StorFileLite>, project: number, moduleName: string): string[];
    /** Live (not `deleted`) l1 files still in the index after a wipe. */
    export function countBackendL1LiveFiles(files: Record<string, StorFileLite>, project: number, moduleName: string): number;
    /** Count of l1 files of the module still in the index, including `status=deleted`. */
    export function countBackendL1IndexedFiles(files: Record<string, StorFileLite>, project: number, moduleName: string): number;
    export function rebuildAllWipedMessage(moduleName: string, wiped: number): string;
    /** Parse the archived-key list stored on the run (`rebuildWipedKeys` in longMemory). */
    export function parseWipedKeysJson(raw: string): string[];
    /** Keys archived by THIS run. A previous run's set is ignored when `runId` does not match. */
    export function wipedKeysForRun(state: {
        wipeRunId?: string;
        wipedKeys?: string[];
    }, runId: string): string[];
    /** Drop a key that this run already rematerialized. */
    export function removeWipedKey(keys: readonly string[], regenerated: string): string[];
    /** `/rebuild all` that wiped files and then materialize generated none is a failed run, not `completed`. */
    export function materializeNoneAfterWipeFinding(rebuildWiped: number, materializeCalls: number): string | null;
    /** A wipe that counted files and still left live ones is not a rebuild-all — abort the run. */
    export function rebuildWipeShouldAbort(wiped: number, leftover: number): boolean;
    /** Trace line plus optional finding when a populated module wipes 0, or live files remain. */
    export function describeRebuildWipe(moduleName: string, wiped: number, indexed: number, leftover: number): {
        message: string;
        finding: string | null;
        abort: boolean;
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbScope" {
    import type { CbOwner, CbEntity, CbRelationship, CbWorkspace, CbActor } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    /**
     * The phases a run is grouped into, in order. Pure so a test can read them without the platform:
     * cbShared re-exports and uses them.
     */
    export const CB_PHASES: {
        readonly preparation: {
            readonly planId: "cb-phase-preparation";
            readonly title: "Preparação";
        };
        readonly generation: {
            readonly planId: "cb-phase-generation";
            readonly title: "Geração";
        };
        readonly judge: {
            readonly planId: "cb-phase-judge";
            readonly title: "Validação (juiz)";
        };
        readonly materialization: {
            readonly planId: "cb-phase-materialization";
            readonly title: "Materialização";
        };
        readonly seeds: {
            readonly planId: "cb-phase-seeds";
            readonly title: "Seeds";
        };
        readonly finalization: {
            readonly planId: "cb-phase-finalization";
            readonly title: "Finalização";
        };
    };
    export type CbPhaseKey = keyof typeof CB_PHASES;
    export interface CbScopeInput {
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        allModuleNames: string[];
        /** Explicit target module (CLI arg or longMemory). Empty = auto: first sorted module with owners. */
        requestedModule: string;
    }
    /** One l4 owner or one todo entry, reduced to what reconciliation needs. */
    export interface CbReconcileEntry {
        key: string;
        moduleName: string;
    }
    export interface CbReconcileInput {
        l4Owners: CbReconcileEntry[];
        todoOwners: CbReconcileEntry[];
        /** Unreadable/invalid todo files, with the module the file belongs to. */
        todoErrors: Array<{
            moduleName: string;
            message: string;
        }>;
        /** Canonical target module; empty means auto-discovery (every module that HAS a todo). */
        targetModule: string;
    }
    export interface CbReconcileResult {
        errors: string[];
        warnings: string[];
    }
    /** Owner identity inside one module. Homonyms across modules are distinct owners. */
    export function ownerStatusKey(kind: string, id: string): string;
    export function ownerHasKnownModule(moduleName: string | undefined | null): boolean;
    /**
     * Status lookup: a v2 owner (module known) never inherits another module's todo entry.
     * Layout v1 (flat, module unknown) still falls back to the module-blind first-seen map.
     */
    export function lookupTodoOwner<T>(ownersByModule: ReadonlyMap<string, ReadonlyMap<string, T>>, owner: {
        kind: string;
        id: string;
        moduleName: string;
    }, moduleBlind?: ReadonlyMap<string, T>): T | undefined;
    export function indexTodoOwner<T>(ownersByModule: Map<string, Map<string, T>>, moduleName: string, key: string, value: T): 'added' | 'duplicate';
    export function flattenTodoOwners<T extends {
        moduleName: string;
    }>(ownersByModule: ReadonlyMap<string, ReadonlyMap<string, T>>): Array<{
        key: string;
        moduleName: string;
        owner: T;
    }>;
    /** Read-back retry may rewrite `done` only when the artifacts exist — same principle as `recovered`. */
    export function retryMayWriteTodoStatus(want: string, artifactsExist: boolean): boolean;
    export interface CbScopeResult {
        moduleName: string;
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        warning: string | null;
    }
    /**
     * BACKFILL entity fields the ontology never declared, from the L4 owners' declared shapes.
     *
     * The e3 ontology writes `fields` for core/event/mdm entities but leaves a `kind: "metric"` entity with
     * NO fields at all (cafeFlow: ShiftClosingReport, OperationalDashboard, AiSalesSummary). Those entities
     * still become real aggregates — deriveAggregates promotes any entity an operation acts on as a root —
     * so they get a domain entity, a port, a table and seeds, all built from an EMPTY field list. The damage
     * observed in 102051:
     *   - seeds wrote only the FK/PK columns, leaving `details` (JSONB) empty, so getShiftClosingReport
     *     answered ok=true with just two ids (bug-shift-closing-report-payload.md) and getAiSalesSummary
     *     crashed on `dashboard.todaySalesTotal.toFixed(2)` (bug-ai-sales-summary.md);
     *   - validateSeedPlan could not object: it iterates `entity.fields`, which was empty;
     *   - and the domain entity only HAD its 14 fields because the pre-T5 generator let the LLM invent them
     *     from the L4 context. With T5 making that step deterministic (fields come from the scan), the next
     *     run would emit an EMPTY interface and break every usecase reading it.
     *
     * The authoritative source is already in L4 and machine-readable: every owner `outputShape` field (and
     * every operation input) carries `fieldRef: "<Entity>.<field>"` plus `type`/`required`. Reading those
     * back is deterministic — no LLM, no guessing. Only entities with NO ontology fields are touched, so a
     * properly-declared ontology is never overridden.
     */
    export function backfillEntityFieldsFromOwners(entities: CbEntity[], owners: CbOwner[]): CbEntity[];
    /**
     * Entities are identified by MODULE + id. A project keeps the generations the generator left behind
     * and they share entity ids (34 of them between buildFlowFsm46 and 47), so deduping by id alone let
     * whichever file the store yielded last decide the module of a shared id — and the module scope then
     * dropped an entity its own module legitimately declares, quietly shortening the ontology.
     */
    export function upsertEntity(entities: CbEntity[], entity: CbEntity): void;
    /**
     * Resolve a requested module name against the ones that exist. Module names are canonical camelCase
     * but are typed by hand ('buildFlowFSM47'), and an unmatched case used to filter everything to empty.
     */
    export function resolveModuleName(requested: string, names: string[]): string;
    /**
     * Reconcile the l4 owners against the todo — FOR THE TARGET MODULE ONLY.
     *
     * A project accumulates modules the generator left behind (the ns4 iteration writes buildFlowFsm39…47
     * side by side, and only the last one has a todo). Reconciling project-wide killed a run whose target
     * module was intact, because a previous generation's 108 operations had no todo of their own. Those
     * are not this run's business: they become ONE warning per module and their owners simply never carry
     * a status, so nothing downstream can treat them as pending work.
     */
    export function reconcileBackendTodo(input: CbReconcileInput): CbReconcileResult;
    /** Resolve the target module and filter every collection to it. The target is the explicit requested
     * module, else the first (sorted) module that has owners in the caller's requested statuses, else the
     * first module overall. A requested-but-absent module yields empty owners plus a warning (so the run
     * finishes cleanly with "no work" instead of silently spanning modules). Relationships are kept only
     * when BOTH endpoints are in-scope entities, so no seeded/generated artifact dangles across modules. */
    export function scopeBackendScan(input: CbScopeInput): CbScopeResult;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPromptBudget" {
    /**
     * How much of the module fits in ONE model call.
     *
     * Every whole-project step of this agent eventually meets the same wall: the prompt is the module,
     * and the module keeps growing. cb-gen-domain and cb-gen-usecase already fan out; the judge was the
     * last whole-project step of the usecase phase, and with 119 operations (ns4) its pairs prompt grew
     * to megabytes — the intents POST answered 413 and the step hung forever in waiting_human_input,
     * with nothing recorded on the task.
     *
     * Pure: no platform imports, so the packing rules are unit-testable.
     */
    /** Hard ceiling for a single prompt. Beyond this the transport rejects the POST. */
    export const MAX_PROMPT_BYTES = 200000;
    /** One judge batch: bounded by SIZE first (usecase defs vary a lot) and by count as a sanity cap. */
    export const JUDGE_BATCH_MAX_BYTES = 120000;
    export const JUDGE_BATCH_MAX_PAIRS = 15;
    export interface CbJudgeQueueEntry {
        ownerId: string;
        bytes: number;
    }
    export interface CbJudgeBatchPlan {
        batch: string[];
        pending: string[];
    }
    /**
     * Greedy packing in queue order: take pairs while they fit. The first entry is ALWAYS taken even
     * when it alone exceeds the budget — a queue that cannot drain is worse than one oversized call, and
     * the prompt guard below still reports it if it is truly out of bounds.
     */
    export function planJudgeBatch(queue: readonly CbJudgeQueueEntry[], maxBytes?: number, maxPairs?: number): CbJudgeBatchPlan;
    /**
     * The message for a prompt that cannot be posted, or null when it fits. Reported as a step failure
     * instead of letting the transport answer 413 as an uncaught client error — a size wall must always
     * arrive as a readable error on the task, naming the step that has to batch.
     */
    export function promptSizeError(label: string, humanPrompt: string, systemPrompt?: string): string | null;
    export function byteLength(value: string): number;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbCostReport" {
    export interface CbPhaseCost {
        cost: number;
        calls: number;
        inputTokens: number;
        outputTokens: number;
    }
    export type CbCostReport = Record<string, CbPhaseCost>;
    /** Parse the charged cost + token counts from an LLM step's interaction trace. The provider lines carry
     *  `... cost:$0.0199 ...` and `... inputTokens:7954 outputTokens:85 ...`; a step may have several provider
     *  attempts (primary + fallback) — SUM them, since the run is charged for each attempt. */
    export function parseStepCost(traceLines: readonly string[]): {
        cost: number;
        inputTokens: number;
        outputTokens: number;
    };
    /** Add one LLM call's cost to a phase bucket (returns a NEW report; pure). */
    export function accumulatePhaseCost(report: CbCostReport, phase: string, delta: {
        cost: number;
        inputTokens: number;
        outputTokens: number;
    }): CbCostReport;
    /** Roll up the report: total cost/calls and the single most expensive phase. */
    export function summarizeCost(report: CbCostReport): {
        totalCost: number;
        totalCalls: number;
        topPhase: string | null;
        topPhaseCost: number;
    };
    /** One-line human summary for the final task trace (T7 visibility). */
    export function formatCostSummary(report: CbCostReport): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbShared" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, type PlannerExtractConfig, type PlannerOutput } from "_102021_/l2/agentChangeBackend/helpers/cbPlanner";
    import { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, readOntologyEntity, readOntologyRelationships, fkFieldIdsForEntity, pinUsecaseScope, type CbEntityKind, type CbTodoDivergence, type CbOwnerMdm, type CbLifecycleStateDecl } from "_102021_/l2/agentChangeBackend/helpers/cbDefsSource";
    import { type CbModuleAccess, type CbOwnerScope } from "_102021_/l2/agentChangeBackend/helpers/cbAccess";
    import { type CbWorkspace, type CbActor } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    import { type CbEntityLifecycle } from "_102021_/l2/agentChangeBackend/helpers/cbLifecycle";
    export { parseDefsSource, replaceDefsValue, handlerKindOf, entityKindOf, isEntityLifecycle, classifyEntityKind, readEntityStorage, contradictoryStorageDeclaration, MDM_WRITE_PATH_ENABLED, readOwnerMdm, pinUsecaseL4Mdm, synthesizeMdmInputs, readOntologyEntity, readOntologyRelationships, fkFieldIdsForEntity, pinUsecaseScope, };
    export type { CbEntityKind };
    export type { CbEntityLifecycle, CbLifecyclePrompt } from "_102021_/l2/agentChangeBackend/helpers/cbLifecycle";
    export { parseEntityLifecycle, compactLifecycleForPrompt, lifecycleForEntity, collectLifecycleContradictionFindings } from "_102021_/l2/agentChangeBackend/helpers/cbLifecycle";
    export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, };
    export type { PlannerExtractConfig, PlannerOutput };
    /** Loose planner config: validates the envelope and returns the `result` object as a record. Each
     * agent reads the array property it expects (items/aggregates/tables/...). */
    export function plannerConfig(toolName: string): PlannerExtractConfig<Record<string, unknown>>;
    /** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
     * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
    export function batchSchema(itemSchema: Record<string, unknown>): Record<string, unknown>;
    export function asArray(value: unknown): Record<string, unknown>[];
    export type ExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export const ALL_STATUSES: readonly OwnerStatus[];
    export type EntityKind = CbEntityKind;
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export type EventPurpose = 'telemetry' | 'audit' | 'reaction';
    export interface EventPolicy {
        purpose: EventPurpose;
        retentionDays?: number;
    }
    export const DEFAULT_EVENT_RETENTION_DAYS = 90;
    export type CbFileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export interface CbAccessPattern {
        kind: string;
        description: string;
        entity?: string;
        keyField?: string;
        filters?: string[];
        sort?: string[];
        pagination?: string;
        selection?: string;
        output?: string[];
    }
    export interface CbOutputField {
        name: string;
        type: 'string' | 'number' | 'boolean' | 'array' | 'object' | 'json';
        required: boolean;
        fieldRef?: string;
        item?: {
            fields: CbOutputField[];
        };
    }
    export interface CbOutputShape {
        kind: 'object' | 'list' | 'paginated';
        fields: CbOutputField[];
    }
    export interface CbOperationInput {
        inputId: string;
        fieldRef: string;
        /** l4 v2 (N1b): every input declares an explicit `type` OR a `fieldRef` — so the usecase/contract
         * input is 100% derivable without re-inferring free inputs (page/pageSize/minPrice) from prose. */
        type?: string;
        required: boolean;
        source: string;
        description: string;
        /** Closed union for list controls (`sortBy` field ids, `sortOrder` asc|desc). */
        enumValues?: string[];
    }
    export interface CbContextResolution {
        inputId?: string;
        targetRef: string;
        source: string;
        originRef: string;
        description: string;
    }
    export interface CbOwner {
        kind: 'operation' | 'workflow';
        id: string;
        pageId: string;
        commandName: string;
        bffName: string;
        title: string;
        entity: string;
        opKind: string;
        /** Actors allowed on this operation. l4 v2 declares `actors: string[]`; v1 `actor: string` (folded to a 1-array). */
        actors: string[];
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern?: CbAccessPattern;
        /** Canonical output structure from l4 (Option 3): the usecase output type is pinned to this. */
        outputShape?: CbOutputShape;
        inputs: CbOperationInput[];
        contextResolution: CbContextResolution[];
        acceptanceAssertions: string[];
        /** MDM semantics of the operation (`Ns4E8MdmSemantics`): the cadastral lifecycle pair, the
         *  active-only filter of a list, the derived situation output. Absent for every l4 that predates the
         *  block, which is what keeps those modules generating exactly as before. */
        mdm?: CbOwnerMdm;
        /** Status from l5/{module}/todoBackend.defs.ts. This is the only source of generation state. */
        todoStatus: string;
        /** Deprecated compatibility alias for prompts that still print owners as statusBackend. */
        statusBackend: string;
        /** Legacy inline status read from l4 only to warn about divergence; never used for decisions. */
        inlineStatusBackend: string;
        moduleName: string;
        /** V4 `operationAuthorityRefs` for this operation. Absent on pre-n07 l4 (no V4). */
        authorityRefs?: string[];
        /** True when every authority of the operation is a public grant (anonymous). */
        publicRoute?: boolean;
        /** Person-scope / custom / organization transcription of the covering authorities. */
        scope?: CbOwnerScope;
    }
    export interface CbEntity {
        entityId: string;
        title: string;
        kind: EntityKind;
        ownership: string;
        moduleName: string;
        fields?: Record<string, unknown>[];
        eventPolicy?: EventPolicy;
        storageTarget?: string;
        mdmType?: string;
        idField?: string;
        /** Platform MDM subtype from l4 v7 (`Person` / `Company` / …). Empty on v6 until regeneration. */
        mdmSubtype?: string;
        /** Module role tag `<module>.<Entity>` from l4 v7 `role` (falls back to `storage.mdmType`). */
        role?: string;
        /** Field a person reads to recognise the record (`displayField` on l4 v7). */
        displayField?: string;
        /** 7 when the ontology file is v7; 6 for older modules kept until regeneration (2026-09-08). */
        defsVersion?: number;
        /** Verbatim l4 `description` — used by gen-usecase so a derived projection can name its sources. */
        description?: string;
        /** Verbatim l4 `storage.notes` — where the l4 writes how a derived projection is composed. */
        storageNotes?: string;
        /** Ontology `useRules` ids. Absent/empty when the entity declares none. */
        useRules?: string[];
        /**
         * How a derived projection is computed (`from` / `filter` / `aggregate`). Absent on L4 written
         * before the field — gen-usecase then keeps composing from description/notes.
         */
        derivation?: {
            from: string;
            filter: string;
            aggregate: Array<{
                fieldId: string;
                op: string;
                sourceField?: string;
            }>;
        };
        /** Ontology lifecycleStates. Absent on v6 files and entities without a cycle. */
        lifecycleStates?: CbLifecycleStateDecl[];
    }
    export interface CbRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        persistenceMode?: string;
        /** Field ids on the `from` side (`realization.from.fieldIds`). Empty on v6 until regeneration. */
        fromFieldIds?: string[];
        /** Field ids on the `to` side (`realization.to.fieldIds`). Empty on v6 until regeneration. */
        toFieldIds?: string[];
    }
    export interface CbAggregate {
        aggregateId: string;
        rootEntity: string;
        embeddedMembers: string[];
        events: string[];
        mdmRefs: string[];
    }
    export interface CbEventTarget {
        entityId: string;
        ownerEntity: string;
        purpose: EventPurpose;
        retentionDays?: number;
        persisted: boolean;
        fields?: Record<string, unknown>[];
    }
    export type { CbBffCallInput, CbBffCallOutputField, CbBffCallOutput, CbBffCallUse, CbBffCall, CbWorkspace, CbActor, } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    import { type CbPhaseKey } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export { CB_PHASES } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export type { CbPhaseKey } from "_102021_/l2/agentChangeBackend/helpers/cbScope";
    export interface CbScan {
        project: number;
        moduleNames: string[];
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        aggregates: CbAggregate[];
        events: CbEventTarget[];
        workspaces: CbWorkspace[];
        actors: CbActor[];
        siteMaps: Record<string, Record<string, unknown>>;
        /** ns4 entity lifecycles (`l4/<module>/workflows`). Not owners; the declared from→to matrix. */
        lifecycles: CbEntityLifecycle[];
        /**
         * Aggregate roots whose l4 declares a delete* operation. Derived from ALL operations of the
         * target module (not the pending-status filter): a port must declare delete even when that
         * operation is already `done`. Event entity ids never belong here.
         */
        deleteTargetEntityIds: string[];
        warnings: string[];
        /** V4 + access-bindings of the target module. Absent on pre-n07 l4. */
        access?: CbModuleAccess;
        /** Operations whose covering grant is `custom` — recorder for the run summary. */
        customScopes?: Array<{
            operationId: string;
            description: string;
        }>;
    }
    export function readBackendScan(statuses?: readonly string[], context?: mls.msg.ExecutionContext, targetModuleOverride?: string): Promise<CbScan>;
    export function deriveEventTargets(entities: CbEntity[], relationships: CbRelationship[]): CbEventTarget[];
    export function deriveAggregates(entities: CbEntity[], relationships: CbRelationship[], operatedRootIds?: Set<string>): CbAggregate[];
    export interface CbColumnPlan {
        fieldId: string;
        reason: string;
        type: string;
        enum?: string[];
    }
    export interface CbTablePlan {
        tableId: string;
        rootEntity: string;
        ownership: string;
        indexedColumns: CbColumnPlan[];
        detailsFields: string[];
        childCollections: string[];
    }
    export interface CbColumnPlanOptions {
        entityId?: string;
        idField?: string;
        defsVersion?: number;
        relationships?: readonly CbRelationship[];
    }
    /** A field needs a real column when it is the id (PK), a reference/FK, a status/lifecycle field, or
     * an ordering timestamp (createdAt). Everything else goes into details JSONB.
     * v7: PK = `storage.idField`, FK = `relationships[].realization.*.fieldIds`.
     * v6 (until regeneration, 2026-09-08): suffix `Id` still names a key. */
    export function planTableColumns(fields: Record<string, unknown>[], knownEntityIds: Set<string>, options?: CbColumnPlanOptions): {
        indexed: CbColumnPlan[];
        details: string[];
    };
    export function domainEntityFileInfo(m: string, entityId: string): CbFileInfo;
    export function valueObjectFileInfo(m: string, memberId: string): CbFileInfo;
    export function repositoryPortFileInfo(m: string, entityId: string): CbFileInfo;
    export function usecaseFileInfo(m: string, usecaseId: string): CbFileInfo;
    export function persistenceTableFileInfo(m: string, tableId: string): CbFileInfo;
    export function persistenceSeedsFileInfo(m: string): CbFileInfo;
    export function repositoryAdapterFileInfo(m: string, entityId: string): CbFileInfo;
    export function httpControllerFileInfo(m: string, pageId: string): CbFileInfo;
    /** Newest mtime (ms) among all L4 `.defs.ts` of the project — the "input changed" watermark. Any l1
     * defs written at/after this is current; anything older (or a changed L4) forces regeneration. */
    export function newestL4DefsMs(project: number): number;
    /** Pure staleness decision (extracted for unit testing): a generated defs is current when it exists
     * (non-null mtime) and was written at/after the L4 watermark. */
    export function defsIsCurrent(defsMs: number | null, l4WatermarkMs: number): boolean;
    /** Whether the generated `.defs.ts` for `fileInfo` can be reused (exists + at/after the L4 watermark). */
    export function defsCurrent(fileInfo: CbFileInfo, l4WatermarkMs: number): boolean;
    /** A /rebuild forces fresh output — reuse is bypassed. (run/bare reuses current defs.) */
    export function isRebuildCommand(context: mls.msg.ExecutionContext): boolean;
    export const CB_AGENT_PROJECT = 102021;
    export const CB_AGENT_FOLDER = "agentChangeBackend";
    /** Read a co-located LLM prompt at runtime. Prompts live next to their step agent as
     * `agentChangeBackend/steps/<slug>/prompt.md` (moved into the step folders on 2026-07-11,
     * step 4; inline template strings were extracted in step 2). Each file
     * keeps its `<!-- modelType: ... -->` marker; the caller still replaces the {{toolName}} placeholder.
     * `folderRel` is relative to this agent folder (e.g. 'steps/gen-domain'); fixed to project 102021 (the
     * agent's own files), NOT the client mls.actualProject. */
    export function readCbPrompt(folderRel: string, shortName?: string): Promise<string>;
    export function defsRef(fileInfo: CbFileInfo): string;
    /** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
    export function dtsRef(fileInfo: CbFileInfo): string;
    /** Standard planning envelope shared by every .defs.ts data block. */
    export function buildArtifact(artifactType: string, artifactId: string, moduleName: string, agentName: string, data: unknown): Record<string, unknown>;
    /** Materialization context for a layer: the hexagonal base architecture skill + the per-type skill
     * (both co-located with this agent) + the platform defs. */
    export function layerSkills(skillFile: string): string[];
    export interface CbPipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath: string;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        rulesPath?: string;
        rulesApplied?: string[];
        agent: string;
    }
    /** Build the pipeline item that makes a .defs.ts self-sufficient for materialization (agentCbMaterialize
     * in-flow, or the cbMaterializeCli Node runner): it carries the outputPath (.ts), the dependsFiles
     * (.d.ts of the inner callee layer) and skills (the LLM context = layer skill + platform defs).
     * See spec.md (auto-suficiência). */
    export function buildPipelineItem(shortName: string, type: string, fileInfo: CbFileInfo, dependsFiles: string[], skills: string[], opts?: {
        rulesPath?: string;
        rulesApplied?: string[];
    }): CbPipelineItem;
    /** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
     * (optionally) the `export const pipeline`. Force-overwrites. */
    export function saveDefs(fileInfo: CbFileInfo, exportName: string, data: unknown, pipeline?: CbPipelineItem[]): Promise<string>;
    /** Write a .defs.ts verbatim. Used to update a file this agent does not own the shape of. */
    export function writeDefsSource(fileInfo: CbFileInfo, src: string): Promise<string>;
    export function saveBackendWorkspaceConfig(): Promise<string>;
    export function saveAgentTrace(context: mls.msg.ExecutionContext, agentName: string, step: mls.msg.AIAgentStep, counters?: Record<string, unknown>): Promise<void>;
    /** Update only l5/{module}/todoBackend.defs.ts. l4 owner defs are read-only for this agent. */
    export function setTodoBackendStatus(owner: CbOwner, status: OwnerStatus): Promise<boolean>;
    export interface CbTodoReadBack {
        /** l5 ref of the file that was checked, or '' when no todoBackend file was found. */
        ref: string;
        checked: number;
        /**
         * Set when a module was asked for and other todoBackend files exist, but this module's file does
         * not. Distinct from `null` (project has no todoBackend at all — caller reports skip).
         */
        missingModule?: string;
        /** The durable content (localStor/IndexedDB). This is what a NEXT run of this agent reads. */
        stor: {
            unreadable: boolean;
            divergent: CbTodoDivergence[];
        };
        /** The Monaco model, when one exists. This is what an EXPORT to disk writes. */
        model: {
            present: boolean;
            unreadable: boolean;
            divergent: CbTodoDivergence[];
        };
    }
    /** Every surface of the read-back that disagrees with what the run believes it wrote. */
    export function todoReadBackDivergences(readBack: CbTodoReadBack | null): CbTodoDivergence[];
    export function todoReadBackIsClean(readBack: CbTodoReadBack | null): boolean;
    /**
     * Is this a read-back the run must DIE on? Divergence on either surface, yes — that is the lost update.
     * An unparseable STOR, yes — the durable state stopped being readable. An unparseable MODEL, no, only a
     * loud warning: that is somebody editing todoBackend.defs.ts in a Studio tab with the syntax momentarily
     * broken, which is their editor and not this agent's write.
     */
    export function todoReadBackIsFatal(readBack: CbTodoReadBack | null): boolean;
    /**
     * Re-read todoBackend and compare it with the statuses this run believes it wrote — on BOTH surfaces
     * that can become the file on disk. Reading only the stor is not enough: in the petShop incident the
     * stor was RIGHT (65 done) and the stale Monaco model was what got exported, so a stor-only read-back
     * would have passed the run that produced the corrupt file.
     */
    export function readBackTodoBackend(expected: ReadonlyMap<string, string>, moduleName?: string): Promise<CbTodoReadBack | null>;
    export function createUpdateStatusIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg?: string, cleaner?: 'input' | 'input_output', newTaskTitle?: string): mls.msg.AgentIntentUpdateStatus;
    export function createAgentStepPayload(planId: string, agentName: string, stepTitle: string, args: unknown, dependsOn: string[], executionMode: ExecutionMode, status?: mls.msg.AIStepStatus, dynamicSource?: unknown): mls.msg.AIAgentStep;
    /**
     * Start the next step INSIDE its phase. Steps that stay in the same phase keep using `enqueueNext`:
     * their parent already IS the phase, so a sibling lands in it for free. Only a phase TRANSITION goes
     * through here.
     *
     * A phase can only receive children while it is open, so it is created lazily with its first child
     * inside it (agentCbPhase adds that child from within the phase's own hook) — never pre-created empty
     * and then completed, which would make every later child throw.
     *
     * `dependsOnPlanId` overrides the default barrier (the CURRENT step). A DISPATCHER that just spawned a
     * parallel fan-out must pass the FAN-OUT's planId: the dispatcher completes the instant it returns its
     * intents, so depending on it lets the next phase start while the workers are still writing. That is
     * exactly what happened on 2026-08-28 (102047/todo): cb-judge depended on cb-gen-usecase instead of
     * cb-usecase-fanout, so the judge saw 0/9 usecase defs and cb-gen-http saw 4/9 — 5 bffCalls and a whole
     * workspace silently lost their controller. cb-gen-port already does it right (dependsOn the fan-out).
     */
    export function enqueueNextInPhase(context: mls.msg.ExecutionContext, currentStep: mls.msg.AIAgentStep, phase: CbPhaseKey, planId: string, agentName: string, stepTitle: string, args?: unknown, onFailure?: mls.msg.AIAgentStep['onFailure'], dependsOnPlanId?: string): mls.msg.AgentIntentAddStep;
    /** An agent step with this planId that can still receive children. */
    export function findOpenStepByPlanId(context: mls.msg.ExecutionContext, planId: string): mls.msg.AIAgentStep | null;
    export function createAddStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep): mls.msg.AgentIntentAddStep;
    export function createPromptReadyIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, hookSequential: number, args: string, systemPrompt: string, humanPrompt: string, toolSchema: mls.msg.LLMTool, toolName: string): mls.msg.AgentIntentPromptReady;
    /**
     * How many children of a fan-out run at once. Run 9 finished with 0 provider errors and 0 fallbacks
     * while the effective parallelism was only ~2× (LLM time 2:06 against 1:02 of wall clock) — the
     * provider had room, so the default moved from 5/10 to 20. A single place decides it.
     */
    export const CB_MAX_PARALLEL = 20;
    /** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
    export function createParallelStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args: string[], dependsOn?: string[], maxParallel?: number): mls.msg.AgentIntentAddStep;
    export function logPrefix(agent: IAgentMeta | {
        agentName: string;
    }): string;
    export function planIdOf(step: mls.msg.AIPayload | undefined): string;
    /** The CLI command the root stored in the task longMemory (rebuild-all | rebuild-defs | run | help). */
    export function readCliCommand(context: mls.msg.ExecutionContext): string;
    /** T11: true when the run was started with `--no-assets` — the optional seed-image step is skipped
     *  entirely (it completes with a warning and the seeds stay intact). Mirrors readCliCommand. */
    export function readNoAssets(context: mls.msg.ExecutionContext): boolean;
    /** The target module the root stored in the task longMemory. Empty means "auto": readBackendScan
     * scopes to the first (sorted) module with owners in the requested statuses. Mirrors readCliCommand. */
    export function readTargetModule(context: mls.msg.ExecutionContext): string;
    /** Count of l1 files `/rebuild all` archived at bootstrap — empty when this run did not archive. */
    export function readRebuildArchived(context: mls.msg.ExecutionContext): string;
    /** `rebuild-all wiped <n> file(s) of l1/<mod>` — empty when this run did not archive. */
    export function readRebuildWipeMsg(context: mls.msg.ExecutionContext): string;
    /** Finding when wipe was 0 on a populated module, or live files remained. */
    export function readRebuildWipeFinding(context: mls.msg.ExecutionContext): string;
    /** `/rebuild all` left live l1 files after archiving — the run must abort, not degrade to `/run`. */
    export function readRebuildWipeAbort(context: mls.msg.ExecutionContext): boolean;
    /** Id of the `/rebuild all` that archived `rebuildWipedKeys`. Empty on `/run`. */
    export function readWipeRunId(context: mls.msg.ExecutionContext): string;
    /** Stor keys `/rebuild all` archived at bootstrap. Empty when this run did not archive. */
    export function readRebuildWipedKeys(context: mls.msg.ExecutionContext): string[];
    /** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
     * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
     * compile; parallelization is a later optimization. */
    export function enqueueNext(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, currentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args?: unknown, onFailure?: mls.msg.AIAgentStep['onFailure']): mls.msg.AgentIntentAddStep;
    export function readString(value: unknown): string;
    export function readStringArray(value: unknown): string[];
    export function lowerFirst(value: string): string;
    export function capitalize(value: string): string;
    export function toSafeShortName(value: string): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbCli" {
    export type CbCommandKind = 'rebuild-all' | 'rebuild-defs' | 'rebuild-seeds' | 'run' | 'help';
    /** Parse the user prompt into a CLI command plus an OPTIONAL target module. Lenient: mention stripped,
     * command keyword matched anywhere. The module is the first token that is NOT a CLI keyword and not a
     * slash-flag (case is PRESERVED — module names are case-sensitive). 'all' is a keyword, never a module.
     * Empty (bare @@changeBackend) is the autonomous default -> 'run'. A bare non-keyword token
     * (e.g. "@@changeBackend cafeFlow") means: run (continue) that specific module. */
    export function parseCli(raw: string | undefined): {
        kind: CbCommandKind;
        module: string;
        noAssets: boolean;
        fast: boolean;
        nochain: boolean;
    };
    /** The human message content stored on the bootstrap step: the prompt with the mention stripped and
     * lowercased. Kept separate from parseCli (which preserves module case). */
    export function normalizePrompt(raw: string | undefined): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepairCore" {
    /** Max REPAIR attempts per component after the first failure (first try + 2 repairs = 3 LLM calls). */
    export const COMPONENT_REPAIR_BUDGET = 2;
    /** Previous rejected code is truncated before it goes into the state/prompt. */
    export const MAX_LAST_CODE = 6000;
    export type CbRepairSource = 'component-validate' | 'validate-all' | 'judge';
    export interface CbComponentRepair {
        target: string;
        attempts: number;
        findings: string[];
        /** Findings from EARLIER attempts that the last output resolved. Fed back so the model does not
         * regress them while fixing the current findings (run 102049-e: attempt 3 fixed the compiler
         * finding but reintroduced the rulesApplied finding of attempt 1 — whack-a-mole until budget). */
        priorFindings?: string[];
        lastCode?: string;
        source: CbRepairSource;
        updatedAt: string;
    }
    /**
     * Merge a component's repair entry across attempts/rounds. Carries forward:
     * - `priorFindings` = findings an earlier attempt already RESOLVED (present before, absent now) — fed
     *   back so the model does not regress them (anti whack-a-mole);
     * - `lastCode` = the last rejected code (or a freshly supplied one) — so the model FIXES it instead of
     *   re-rolling from scratch.
     * The `attempts` value is the caller's policy: recordComponentFailure increments it; the validate-all
     * GLOBAL round resets it to 0 (the round grants a fresh worker budget — the global budget is the
     * anti-loop). This is what lets a g2 round remember what g1 already fixed instead of repeating it.
     */
    export function mergeComponentRepair(prev: CbComponentRepair | undefined, target: string, findings: string[], opts: {
        attempts: number;
        source: CbRepairSource;
        lastCode?: string;
    }): CbComponentRepair;
    /** Repair section appended to the worker's human prompt on a retry. */
    export function buildRepairPromptSection(entry: CbComponentRepair): string;
    export type CbCeilingKind = 'repair' | 'hard';
    export interface CbRespawnCount {
        defRef: string;
        repairSpawns: number;
        dispatches: number;
    }
    export interface CbSpawnDecision {
        scheduled: boolean;
        repairSpawns: number;
        repairCeiling: number;
        dispatches: number;
        dispatchCeiling: number;
        blockedBy?: CbCeilingKind;
    }
    /** Hard backstop on total dispatches per component this run. Folgado vs ~4 layers of
     *  legitimate transitive staleness; tight enough to contain a host-absent loop. */
    export const CB_DISPATCH_HARD_CEILING = 10;
    export function resetRespawnCounts(): void;
    export function staleSpawnCeiling(): number;
    export function dispatchHardCeiling(): number;
    /** Count a dispatcher schedule attempt. Only the hard dispatch ceiling applies here;
     *  the repair ceiling lives in `noteRepairAttempt` / `forceRegenerate`. Refusing leaves
     *  the counts unchanged and sets `blockedBy`. */
    export function noteStaleSpawn(defRef: string): CbSpawnDecision;
    /** Count an explicit regenerate (delete the output .ts). Ceiling is COMPONENT_REPAIR_BUDGET + 1;
     *  refusing leaves the counts unchanged and sets `blockedBy: 'repair'`. */
    export function noteRepairAttempt(defRef: string): CbSpawnDecision;
}
declare module "_102021_/l2/agentChangeBackend/steps/rebuild-defs-cleanup/agentCbRebuildDefsCleanup" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export { isGeneratedBackendFolder, listBackendL1ArchiveKeys } from "_102021_/l2/agentChangeBackend/helpers/cbArchive";
    /** Soft-delete `l4/<module>/pipeline/trace/l1/` of this module only. Used by `/rebuild all`. */
    export function clearCbLayerTrace(project: number, moduleName: string): Promise<string[]>;
    /** Soft-delete every l1 artifact of the module (defs and derived .ts). Platform trash, never `rm`. */
    export function archiveGeneratedBackendModule(project: number, moduleName: string): Promise<string[]>;
}
declare module "_102021_/l2/agentChangeBackend/agentChangeBackend" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbAdapterNotes" {
    export const ADAPTER_MODULE_DATA_NOTE = "Persist through ctx.data.moduleData.getTable<Row>('<table>'); never keep rows in a module-level Map/WeakMap/array.";
    export function sanitizeAdapterNotes(notes: string[]): string[];
    /** Rewrite `data.notes` in an adapter .defs.ts source. `null` = no change (or unreadable). */
    export function rewriteAdapterDefsNotes(source: string): string | null;
    /** Source with the `create<Entity>RepositoryAdapter` factory body removed. */
    export function sourceOutsideAdapterFactory(source: string): string;
    export function hasModuleLevelStore(source: string): boolean;
    /**
     * Persistence adapter that does not talk to the runtime store, or keeps its own.
     * Signal A (absence of `ctx.data.moduleData`) only when the module declared a local table.
     * Signal B (module-level Map/WeakMap/array) is never legitimate in adapters/persistence.
     */
    export function collectModuleDataAdapterFindings(source: string, sn: string, declaredTableNames: ReadonlySet<string>): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbBuildStamp" {
    /**
     * PROVENANCE of the running agent code: WHICH version of this agent produced this run.
     *
     * Not "is it stale?" — that question cannot be answered from inside the agent, and asking it produced a
     * wrong diagnosis once already. What happened on 2026-08-22 (run cb-run-…01-34-27): the MDM F1 was in
     * nobody's build because it had never been committed. The `obj/compiled.zip` in play was perfectly
     * CONSISTENT — its `fileinfos.json` and its `.js` both sat on commit 308ab97 — and the run executed the
     * last PUBLISHED build, correctly. Measured, not argued: for `helpers/cbShared.ts` the build recorded
     * `1ef6d903…`, which is exactly `git rev-parse 308ab97:l2/agentChangeBackend/helpers/cbShared.ts`,
     * while the working copy on the author's disk hashed to `5691b296…`. There was no build bug and nothing
     * to "recompile": what puts code on the platform is commit + push (the `build.yml` Action compiles and
     * commits `obj/compiled.zip`).
     *
     * So the useful line in a trace is not an alarm, it is an IDENTITY a human can match with git.
     *
     * WHAT THIS CANNOT DO — by construction, not by omission:
     *   - It cannot see work that was never committed and pushed: the platform has never seen it. No
     *     measurement from inside the agent finds it, by timestamp or by hash.
     *   - It cannot tell whether the built `.js` matches the `.ts` of the same commit. That would be a bug in
     *     the Action, and the place to catch it is there.
     *   - It is NOT a gate: it never blocks, never fails a run, and emits no warning. A source being edited
     *     locally is the NORMAL state of whoever is editing (a file "in development" keeps its local version
     *     instead of the build's `.js` — `cfe-collab-front-end/src/stor/stor.server.ts`), so treating that as
     *     an anomaly would be noise, not signal.
     */
    /** The project this agent's code lives in. */
    export const CB_AGENT_PROJECT = 102021;
    /** Only this agent's own sources: another folder's version says nothing about which agent ran. */
    export const CB_AGENT_SOURCE_PREFIX = "l2/agentChangeBackend/";
    /**
     * The files a human checks first, in `git`. Kept short on purpose — the digest already covers everything;
     * these exist so a reader has something to paste into `git rev-parse <commit>:<path>` without unzipping.
     */
    export const CB_BUILD_ANCHORS: readonly string[];
    /** One entry of the build's own manifest (`fileinfos.json` inside obj/compiled.zip). */
    export interface CbBuildFile {
        shortPath: string;
        /** git blob OID of the source AT THE BUILD COMMIT. Verified: equals `git hash-object <file>`. */
        versionRef: string;
    }
    export interface CbAgentProvenance {
        project: number;
        /**
         * Stable digest of the agent's `shortPath:versionRef` pairs. Two runs with the same buildRef executed
         * the same code; different buildRefs executed different code. Match a single file with
         * `git rev-parse <commit>:<path>` (or `git hash-object <file>` for a working copy).
         */
        buildRef: string;
        /** How many of this agent's sources went into the digest. */
        files: number;
        /** versionRef per anchor file; `absent` when the manifest has no entry (e.g. a file never committed). */
        anchors: Record<string, string>;
        /**
         * Last push registered on the project. NOT the build time: the platform webhook writes it on every
         * push (`cbe-collab-back-end/.../executeOnProjectUpdated.ts`) and the backend uses it to invalidate the
         * zip cache, so a push that produces no new build already moves it.
         */
        lastPushAt: string | null;
        /** How many of this agent's sources are being edited locally. Informational: this is normal. */
        localEdits: number;
        error?: string;
    }
    /**
     * FNV-1a over the sorted `shortPath:versionRef` pairs. Local and pure on purpose: the digest has to be
     * reproducible in a test without a platform, and it only has to be stable, not cryptographic.
     */
    export function digestBuildFiles(files: readonly CbBuildFile[]): string;
    /**
     * PURE. Builds the provenance from the manifest the browser already holds.
     *
     * The manifest is the right source precisely BECAUSE it is not perturbed by local editing: it is what
     * the build recorded. `mls.stor.files[].versionRef` is not usable here — a locally created file is
     * stamped `'0'` by `createStorFile`, so a digest over it would change as soon as anyone edits.
     */
    export function buildProvenance(project: number, files: readonly CbBuildFile[], options: {
        prefix: string;
        anchors: readonly string[];
        lastPushAt?: string | null;
        localEdits?: number;
        error?: string;
    }): CbAgentProvenance;
    /** The one line a trace carries. No warning path: there is no measured signal that warrants one. */
    export function describeProvenance(provenance: CbAgentProvenance | null): string;
    /**
     * Read the provenance of the running agent. Fail-soft by contract: any throw becomes an empty
     * `buildRef` plus the reason, and never touches the run.
     */
    export function readAgentProvenance(project?: number): Promise<CbAgentProvenance>;
}
declare module "_102029_/l2/clientBoundarySources" {
    /**
     * The only L4 sources whose values cross the browser/BFF boundary.
     * Keep backend validation and frontend contract generation aligned by importing this module.
     */
    export const CLIENT_BOUNDARY_SOURCES: readonly ["userInput", "selectedEntity", "routeParam"];
    export type ClientBoundarySource = typeof CLIENT_BOUNDARY_SOURCES[number];
    export type ClientInputPresentation = 'form' | 'selection' | 'route';
    export function isClientBoundarySource(source: unknown): source is ClientBoundarySource;
    export function clientInputPresentation(source: unknown): ClientInputPresentation | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbComponentValidators" {
    /** Module-local l1 imports of a generated .ts: `from '_<project>_/l1/<folder>/<name>'`. Returns
     * the tsSet key (`${folder}::${shortName}`) so the caller can check the target was actually generated.
     * Cross-project imports (e.g. /_102034_/ platform) and non-l1 imports are ignored on purpose. */
    export function collectL1Imports(content: string, project: number): {
        key: string;
        target: string;
    }[];
    /**
     * Same field (name + ofEntity) on input and output must have the same form. be5: weeklySchedule
     * input `json` × output `string` — list shows a blob, create/update reject the string the list emits.
     * Gate the DEFS, not the generated .ts (aliases like WeeklySchedule vs string are unresolvable).
     */
    export function collectIoShapeSymmetryIssues(fn: {
        functionName?: string;
        input?: unknown;
        output?: unknown;
    }): string[];
    /** Ontology type named by `Entity.field` (empty when the ref does not resolve). */
    export function ontologyTypeForFieldRef(fieldRef: string, entities: Array<{
        entityId: string;
        fields?: unknown[];
    }>): string;
    /**
     * When l4 flattened a structured ontology field (json → string) onto outputShape, rewrite the
     * output type to the ontology type so W2 can pass. Caller records a systemDecision per change.
     */
    export function alignOutputShapeToOntology<S extends {
        kind: string;
        fields: Array<{
            name: string;
            type: string;
            required: boolean;
            fieldRef?: string;
        }>;
    }>(shape: S, entities: Array<{
        entityId: string;
        fields?: unknown[];
    }>): {
        shape: S;
        aligned: Array<{
            fieldRef: string;
            from: string;
            to: string;
        }>;
    };
    /** Drop bffCalls whose required usecase was never materialized (abandoned owner — no controller pair). */
    export function bffCallsWithMaterializedUsecase<T extends {
        uses: Array<{
            operationId: string;
            optional?: boolean;
        }>;
    }>(calls: T[], usecaseIds: ReadonlySet<string>): {
        kept: T[];
        skipped: string[];
    };
    /** l4 contract defs a generated controller lists in `dependsFiles`. Empty/unreadable content used to
     * be dropped from the materialize prompt with only a console.warn, so controllers shipped without
     * their wire contract (ctx422 / versionRef 0). */
    export function collectL4ContractDependsRefs(defsSource: string): string[];
    export function collectUnreadL4ContractFindings(defsSource: string, readable: (ref: string) => boolean): string[];
    /** Generated defs shortName must not contain extra dots (convention after nomes_sem_ponto). */
    export function collectDottedShortNameFindings(files: {
        shortName: string;
    }[]): string[];
    export function collectRelativeImportIssues(code: string): string[];
    /** Node ESM does not complete `/_<id>_/l1/.../name` without `.js`. tsc accepts it; the runtime does not. */
    export function collectExtensionlessImportIssues(code: string): string[];
    export function escapeRegExp(value: string): string;
    export function fieldNameFromRef(value: unknown): string;
    export function requiredBoundaryFields(inputContract: unknown): Set<string>;
    export function collectRequiredChecksByHandler(content: string): Map<string, Set<string>>;
    export function collectExportedHandlers(content: string): Set<string>;
    export function collectRouteHandlers(content: string): Map<string, string>;
    export function normalizeRuleId(rule: string): string;
    export function collectUsecaseRules(data: unknown): string[];
    /** Method names declared on a repository port interface, read from the generated port `.ts`/`.d.ts`.
     * Walks the interface body brace-matched; matches member signatures `name(...)` / `name<...>(...)`. */
    export function extractInterfaceMethods(portSource: string, interfaceName: string): Set<string>;
    /** Repository method calls in a usecase that are NOT declared on the bound port interface. Binds each
     * `const v = resolveRepository<IXRepository>(...)` variable to its interface, then checks every
     * `v.method(` call. Interfaces absent from `methodsByInterface` (port source unresolved) are skipped,
     * so this never false-positives. The finding lists the port's real methods for a deterministic repair. */
    export function collectRepositoryMethodMisuse(code: string, methodsByInterface: Map<string, Set<string>>): string[];
    /**
     * A repository re-bound through a CAST to invent a method it does not have.
     *
     * The delete usecases of the buildFlowFsm run all did this:
     * `const deletedClient = clients as unknown as { delete(id: string): Promise<void> }; await
     * deletedClient.delete(...)`. The port declares no `delete`, so at runtime the property is `undefined`,
     * the call throws a TypeError, and the client sees `INTERNAL_ERROR: Unexpected error` — 7 of the 22
     * failures of the production suite, all of them unreadable. `collectRepositoryMethodMisuse` cannot see
     * it: it tracks bindings made by `resolveRepository<I…>`, and the cast creates a NEW name it never
     * heard of. The cast IS the escape from that gate.
     *
     * There is no legitimate version of this: if the port has no `delete`, the entity is not deletable, and
     * the usecase has to SAY so — the one generated file that did (`ProjectCoordinationAssignment
     * repository does not support deletion`, a readable CONFLICT) is the shape the other seven owe.
     */
    /**
     * A delete operation whose port has no `delete` compiles, then 409s
     * `"<Entity> repository does not support deletion"` (petShop `cmdDeleteScheduleBlock`).
     * Either the port declares `delete`, or the operation should not exist. Ports that could not be
     * loaded are skipped (empty map) so this never false-positives. Called from validate-all against
     * the PORT source (finding routed to the port defRef); not from the usecase materialize worker.
     * `inactivate*` is a status update (`getById` → `save`), not a port method — do not match it here.
     */
    export function collectDeleteOperationPortGaps(usecaseId: string, methodsByInterface: Map<string, Set<string>>): string[];
    export function collectRepositoryCastIssues(code: string): string[];
    export function extractRepositoryInterfaceName(portSource: string): string;
    /** Method names on the object returned by `create{Entity}RepositoryAdapter`. Empty when unparseable. */
    export function extractAdapterFactoryMethods(adapterSource: string): Set<string>;
    /**
     * Every method declared on the port interface must exist on the adapter factory return object.
     * Unparseable adapter (no factory/return) is skipped so this never false-positives.
     */
    export function collectAdapterMissingPortMethods(adapterSource: string, portMethods: ReadonlySet<string>, label: string, iface?: string): string[];
    /**
     * The MDM facade's `entity.related(key)` takes a TYPED CompactRelationshipRefKey. Models invent a key
     * and force it past the type with a string-literal cast — `entity.related(key as 'o')`,
     * `x.relatedIds(rel as "OffersProduct")` erro4). The isolated in-loop compile missed
     * it (the platform type was not loaded), so it only surfaced in the project `tsc`. A cast to a string
     * literal inside a related()/relatedIds() call is never legitimate — a real key is a typed constant,
     * never something you cast a literal into. Flag it as a repair finding: the linked id must be read from a
     * DECLARED entity field (e.g. `menuCategoryId`), not a guessed relationship key.
     */
    export function collectInventedRelationshipKeyIssues(code: string): string[];
    /** Double-check (vs H1): keep only the compiler errors that reproduced in BOTH passes. A finding present
     * in the first compile but not the recompile was a transient (Monaco model lag / imports not yet
     * settled) and must not force a full LLM re-generation of a file that was already correct. */
    export function stableCompilerErrors(first: string[], second: string[]): string[];
    /** Cascade dedup (vs H2): among the files flagged by the whole-project compile, a file that IMPORTS
     * another flagged file is reporting DERIVED errors from that broken import — repair only the ROOT this
     * round and DEFER the importer. Pure over (flagged keys, importsOf); the caller resolves imports (I/O).
     * `importsOf(key)` returns the l1 import keys of that file (same `${folder}::${shortName}` space). */
    export function selectCompilerRepairRoots(flaggedKeys: Iterable<string>, importsOf: (key: string) => string[], familiesOf?: (key: string) => string[]): {
        roots: string[];
        cascades: string[];
    };
    /** TS code + quoted identifier, so `'pet' is possibly 'null'` and `'service' is possibly 'null'` are distinct. */
    export function compilerErrorFamily(error: string): string;
    /**
     * After a repair, keep the UNION of both compiles — never drop a family as "flaky". g1 found two
     * families in createServiceAppointment, the repair fixed `pet`, g2's double-check then discarded
     * `service` as non-reproducing and health closed `passed` with a real tsc error still on disk.
     */
    export function compilerErrorsAfterRepair(first: string[], second: string[]): string[];
    /**
     * TS2339 on `never` names the symptom, not the cause: TS cannot see assignments inside a callback
     * and narrows the outer variable to its initializer. Append one sentence; never replace the diagnostic.
     */
    export function annotateCompilerError(error: string): string;
    /** Health may close `passed` only when every previous family was re-checked on this pass. */
    export function compilerFindingsBlockingPassed(input: {
        currentByFile: Map<string, string[]>;
        previousFamiliesByFile?: Map<string, string[]>;
    }): string[];
    /** User-facing AppError messages must be English (or i18n). Cheap scan of generated usecases. */
    export function collectNonEnglishAppErrorMessages(code: string): string[];
    export interface EventForPortCheck {
        entityId: string;
        ownerEntity: string;
    }
    export function eventPortBelongsToOwner(event: EventForPortCheck, ownerRefs: readonly string[], mutated: ReadonlySet<string>): boolean;
    /**
     * T12 item 4 — POST-condition on the saved usecase defs: the owner's PRINCIPAL aggregate (l4
     * `entity`) must appear in `data.ports` whenever it has a local port (an aggregate root or a persisted
     * event). MDM entities are excluded (read by id via 102034, never a port).
     *
     * This is checked on the SAVED defs by the judge — not on the model's raw output — because the ports
     * are derived deterministically by the agent AFTER the model answers. So a violation here means the
     * DERIVATION missed a case (the erro4/erro5 createStockAdjustment bug), not that the model misbehaved:
     * it routes to a cheap phase-1 defs repair instead of 3 LLM repair attempts during materialization.
     * Returns [] when the owner's entity legitimately has no port.
     */
    export function missingPrincipalPortIssues(owner: {
        id: string;
        entity: string;
    }, declaredPorts: readonly string[], localPortIds: ReadonlySet<string>, // aggregate roots ∪ persisted event ids
    mdmIds: ReadonlySet<string>): string[];
    /**
     * T12 item 3 — SAFETY BELT for the materialize worker. Independently of how the defs were derived, the
     * worker's prompt must show the model every port the usecase will actually resolve. Returns the port
     * entity ids that the defs `data` references (top-level `ports` + `functions[].ports`) but whose
     * `.d.ts` pair is NOT already in `dependsFiles` — the worker then loads those pairs into the context.
     *
     * Narrow by construction (only ids the defs itself names, never the whole module) so T5's context
     * savings hold. Immunizes against future derivation gaps without regenerating old defs.
     */
    export function portsMissingFromDependsFiles(data: unknown, dependsFiles: readonly string[]): string[];
    export function ownershipCheckIsInconclusive(expectedIdCount: number, generatedDefsCount: number): boolean;
    /** The warning emitted in place of the (suppressed) orphan findings. */
    export function ownershipInconclusiveWarning(generatedDefsCount: number): string;
    export interface DefsFileForOwnership {
        folder: string;
        shortName: string;
        real: string;
    }
    /**
     * The ORPHAN-DEFS check, pure. A usecase defs is owned by an operation; a v2 controller defs is owned by
     * an operation OR a workspace. Callers pass the id sets built from an ALL_STATUSES scan (A1) — ownership
     * does not depend on pending status.
     *
     * Gated PER CHECK, not on the sum: usecase ownership comes ONLY from `expectedOperationIds` (which the
     * scan filters by owner status), while controller ownership also accepts `expectedWorkspaceIds` — and
     * scan.workspaces is NOT status-filtered. Summing them would leave the usecase guard dead on a v2 module
     * (0 operations + N workspaces != 0), i.e. exactly the erro5 case this guard exists for.
     */
    export function collectOrphanDefsFindings(defsFiles: readonly DefsFileForOwnership[], expectedOperationIds: ReadonlySet<string>, expectedWorkspaceIds: ReadonlySet<string>): {
        findings: string[];
        warnings: string[];
    };
    export interface OwnerForRouteCheck {
        kind: string;
        id: string;
        bffName?: string;
        pageId?: string;
        commandName?: string;
    }
    export interface ControllerForRouteCheck {
        id: string;
        routes: ReadonlyArray<{
            key: string;
        }>;
    }
    /**
     * V1-only canonical bffName route check, pure (v2 controllers are per-WORKSPACE and covered by
     * collectV2ControllerCoherenceIssues). Every operation owner that HAS a controller must expose its
     * canonical route. Works off an ALL_STATUSES scan (A1) so a `done` owner is still checked — with the old
     * pending-filtered scan this check silently passed on every post-gen-http run.
     */
    export function collectMissingCanonicalRouteIssues(owners: readonly OwnerForRouteCheck[], controllers: readonly ControllerForRouteCheck[], moduleName: string, lowerFirstFn: (value: string) => string): string[];
    /** Top-level `function name(...) {...}` / `const name = (...) => {...}` blocks, brace-matched. */
    export function extractFunctionBlocks(code: string): Array<{
        name: string;
        body: string;
    }>;
    /** Findings for adapters that parse a `details` envelope without merging over defaults. A candidate is
     * any function that calls `JSON.parse` on an expression mentioning `details` (so `ctx.mdm` reads of
     * `entity.details.<module>`, which never JSON.parse, are not candidates). */
    export function collectDetailsDefaultingIssues(code: string): string[];
    /** JSONB column names declared on a table def (.ts with postgresType, or planner .defs.ts with type). */
    export function jsonbColumnsFromTableSource(source: string): {
        tableName: string;
        columns: string[];
    } | null;
    /**
     * `JSON.parse(row.<col>)` on a JSONB column: pg already returns an object, parse throws, mute catch
     * empties the domain. Finding is textual; the legitimate parse is `typeof row.col === 'string' ? JSON.parse(row.col) : (row.col ?? {})`.
     */
    export function collectJsonbRowParseFindings(adapterSource: string, jsonbColumns: ReadonlySet<string>, label: string): string[];
    /** l4 `fields[].fieldId` — the vocabulary of JSONB `details` keys (and of domain fields). */
    export function fieldIdsFromL4Fields(fields: unknown): Set<string>;
    /**
     * Adapter `parseDetails`/`toDomain`/`toRow` that addresses `details.<chave>` with a key that is not
     * an l4 fieldId. Seeds write fieldId (camelCase); a snake_case key inside the JSONB envelope is
     * unread data (blank column, value still in the row). Inverse: toRow/detailsDefaults writing a key
     * outside the same vocabulary. Empty fieldIds skips (nothing to compare).
     */
    export function collectDetailsKeyIssues(adapterSource: string, fieldIds: ReadonlySet<string>, label: string): string[];
    /** Collection fields of a generated domain entity, as `valueObjectName -> the entity's field name`
     * (e.g. `OrderItem -> items` for `items: OrderItem[]`).
     *
     * WHY this indirection exists: the TableDefinition declares embedded child collections by ENTITY ID
     * (`childCollections: ['OrderItem']`), but the domain-entity materializer names the field itself
     * (`items: OrderItem[]`) and the adapter reads THAT name (`d.items`). Seeding the envelope under the
     * entity id would write `details.OrderItem` while the adapter reads `details.items` — the row looks
     * seeded and the collection still arrives empty. Since seeds are generated AFTER materialization, the
     * real field name is readable from the generated entity source instead of guessed from a convention. */
    export function extractCollectionFieldNames(entitySource: string): Map<string, string>;
    export interface V2WorkspaceForCheck {
        workspaceId: string;
        bffCalls: Array<{
            bffId: string;
        }>;
    }
    export function collectV2ControllerCoherenceIssues(workspaces: V2WorkspaceForCheck[], controllerSources: Map<string, string>): string[];
    export interface NamedL1Import {
        imported: string;
        local: string;
        project: number;
        folder: string;
        shortName: string;
        specifier: string;
    }
    export function significantCamelWords(name: string): string;
    export function editDistance(a: string, b: string): number;
    export function closestExportedName(imported: string, exported: Iterable<string>): string | null;
    export function collectExportedNames(source: string): Set<string>;
    /** Named `import { a, b } from '/_<project>_/l1/<module>/…'`. Cross-project and runtime paths omitted. */
    export function collectNamedL1Imports(code: string, project: number, moduleName?: string): NamedL1Import[];
    export interface InventedImportRename {
        imported: string;
        exported: string;
        specifier: string;
    }
    export interface InventedImportFix {
        code: string;
        findings: string[];
        renamed: InventedImportRename[];
    }
    /**
     * For each named import of a same-module generated file: if the name is not exported, rename to a
     * close export (same camelCase words or edit distance 1–2) or emit a finding. `targets` is
     * `${folder}::${shortName}` → source of the imported .ts; missing targets are skipped (the unresolved
     * file is a different finding).
     */
    export function applyInventedImportFixes(code: string, project: number, targets: ReadonlyMap<string, string>, moduleName?: string): InventedImportFix;
    export function collectCallbackNullAssignmentIssues(code: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbContracts" {
    import type { CbBffCall } from "_102021_/l2/agentChangeBackend/helpers/cbWorkspace";
    export interface CbOpOutputShapeView {
        kind: string;
        fields: Array<{
            name: string;
            type?: string;
            item?: unknown;
        }>;
    }
    /** The array-carrying field of a paginated operation outputShape (the `$items` target). The first field
     * of type 'array' (or one with a nested `item`) — real outputShapes have exactly one. `list` shapes are
     * flat (no array field) and return null. */
    export function resolveItemsArrayField(shape: CbOpOutputShapeView | null | undefined): string | null;
    export interface CbResolvedProjectionField {
        name: string;
        operationId: string;
        path: string[];
        fromItems: boolean;
    }
    /** Parse a bffCall `from` path (`<op>.<field>` | `<op>.$items.<col>`) into its parts. Returns null for a
     * malformed/empty `from`, or for a bare `<op>.$items` (the whole array — handled by the array field). */
    export function parseFromPath(from: string | undefined): {
        operationId: string;
        fromItems: boolean;
        path: string[];
    } | null;
    /** Resolve a bffCall's output per the CANONICAL v2 shapes (confirmed against the real contracts,
     * newSolution_10 §A2):
     *   object    -> topFields = the projected object fields; no array.
     *   list      -> itemFields = flat `<op>.$items.<col>` columns; the WIRE is a BARE array (arrayFieldName null).
     *   paginated -> one array field with nested `item.fields` (declared name, e.g. `reservations`) + meta
     *                (total/page/pageSize) as topFields; the WIRE wraps `{ <arrayFieldName>: item[], ...meta }`. */
    export interface CbResolvedProjection {
        kind: 'object' | 'list' | 'paginated';
        itemFields: CbResolvedProjectionField[];
        topFields: CbResolvedProjectionField[];
        arrayFieldName: string | null;
        arrayOperationId: string | null;
    }
    export function resolveBffProjection(bff: CbBffCall): CbResolvedProjection;
    export function envelopeKindOf(bff: CbBffCall): 'object' | 'list' | 'paginated';
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmGuards" {
    export function collectRawMdmAccessIssues(code: string): string[];
    export function collectMdmLifecycleIssues(code: string, lifecycle: string | undefined): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTableColumnTypes" {
    export type ColumnTypeFamily = 'text' | 'uuid' | 'integer' | 'numeric' | 'boolean' | 'timestamptz' | 'jsonb';
    export interface L4FieldTypeHint {
        fieldId: string;
        type: string;
    }
    /** Family of an l4 ontology field type. Unknown (entity ids, free strings) → undefined. */
    export function l4TypeFamily(l4Type: string): ColumnTypeFamily | undefined;
    /** Family of a planner `type` or a materialized `postgresType`. */
    export function sqlTypeFamily(sqlType: string): ColumnTypeFamily | undefined;
    /** Canonical planner/SQL type for a known l4 field type. Empty when the l4 type is not a scalar we own. */
    export function columnSqlTypeForL4(l4Type: string): ColumnTypeFamily | '';
    export function l4FieldTypesFromFields(fields: unknown): L4FieldTypeHint[];
    /** Strip numeric (and other incompatible) column types when the l4 field is not that family. */
    export function sanitizePlannerTableColumnTypes<T extends Record<string, unknown>>(item: T, fields: unknown): T;
    /** Findings for validate-all: a table defs/ts whose column family contradicts the l4 field. */
    export function collectColumnTypeMismatchFindings(source: string, fields: unknown, label: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTableIndexes" {
    export function isRedundantPrimaryKeyIndex(input: {
        tableName: string;
        primaryKey: readonly string[];
        indexName: string;
        indexColumns: readonly string[];
    }): boolean;
    /** Strip colliding PK indexes from a planner table item (or a TableDefinition-shaped object) before save. */
    export function sanitizePlannerTableItem<T extends Record<string, unknown>>(item: T): T;
    /** Findings for validate-all: a table defs/ts that still declares a redundant PK index. */
    export function collectRedundantPkIndexFindings(source: string, label: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbCorpus" {
    export const CB_CORPUS_PROJECT_IDS: readonly ["102046", "102047", "102048", "102049", "102051"];
    export type CbCorpusProjectId = (typeof CB_CORPUS_PROJECT_IDS)[number];
    export const CB_CORPUS_GUARD_FAMILIES: readonly ["moduleDataAdapter", "jsonbRowParse", "redundantPkIndex", "columnTypeMismatch", "detailsKey", "rawMdmAccess"];
    export type CbCorpusGuardFamily = (typeof CB_CORPUS_GUARD_FAMILIES)[number];
    export interface CbCorpusFileFinding {
        file: string;
        family: CbCorpusGuardFamily;
        findings: string[];
    }
    export interface CbCorpusProjectResult {
        project: CbCorpusProjectId;
        skipped: boolean;
        warning?: string;
        files: CbCorpusFileFinding[];
    }
    export interface CbCorpusRunResult {
        projects: CbCorpusProjectResult[];
    }
    export interface CbCorpusFamilyBaseline {
        count: number;
        files?: string[];
    }
    export type CbCorpusProjectBaseline = Record<CbCorpusGuardFamily, CbCorpusFamilyBaseline>;
    export interface CbCorpusBaseline {
        projects: Record<string, CbCorpusProjectBaseline>;
    }
    /** Minimal FS surface so this module stays off `node:*` (frontend tsc has `types: []`). */
    export interface CbCorpusIo {
        isDir(absPath: string): boolean;
        isFile(absPath: string): boolean;
        list(absPath: string): string[];
        read(absPath: string): string;
        join(...parts: string[]): string;
    }
    export function runCbCorpus(mlsBase: string, io: CbCorpusIo): CbCorpusRunResult;
    export function summarizeCbCorpus(run: CbCorpusRunResult): CbCorpusBaseline;
    export function diffCbCorpusBaseline(actual: CbCorpusBaseline, expected: CbCorpusBaseline): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbFastHandoff" {
    /**
     * `/fast` chain after a successful backend run. Pure: the final-summary step sends the thread
     * message; this file only decides whether to and what to send.
     */
    export const CB_FAST_HANDOFF_PLAN_ID = "fast-handoff-changeFrontend";
    export function isCbFastMode(longMemory?: Record<string, unknown> | null): boolean;
    export function isCbNochainMode(longMemory?: Record<string, unknown> | null): boolean;
    export function cbNochainSuppressedNote(moduleName: string): string;
    export function buildCbChangeFrontendHandoffMessage(moduleName: string): string;
    export function hasCbFastHandoff(roots: unknown): boolean;
    export function decideCbFastHandoff(input: {
        fast: boolean;
        nochain: boolean;
        success: boolean;
        alreadyDispatched: boolean;
        moduleName: string;
    }): {
        dispatch: boolean;
        message: string;
        suppressed: boolean;
    };
    export const CB_FAST_HANDOFF_MARK_SHORT = "fast-handoff";
    export type CbFastHandoffDegradation = {
        at: string;
        kind: 'fast-handoff-dispatch';
        reason: string;
    };
    export type CbFastHandoffSendResult = {
        dispatched: boolean;
        note: string;
        degradation: CbFastHandoffDegradation | null;
    };
    /**
     * Send + persist the `/fast` handoff. Never throws: a dispatch failure is a recorded
     * degradation so finalize can complete (the CB work is already on disk).
     */
    export function sendCbFastHandoff(input: {
        threadId: string | undefined;
        message: string;
        send: (threadId: string, message: string) => Promise<void>;
        persist: () => Promise<void>;
    }): Promise<CbFastHandoffSendResult>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbFindingSeverity" {
    export type FindingSeverity = 'blocking' | 'degradable';
    export function partitionFindings(findings: string[]): {
        blocking: string[];
        degradable: string[];
    };
    export function findingSeverity(finding: string): FindingSeverity;
    /**
     * A contract routine with no controller: the app BOOTS, the screens that call that routine answer 404.
     * Degradable by the same doctrine as seeds — the gate blocks what stops the app from coming up, and
     * reports the rest. The finding is still recorded and shown; only the run's fate changes.
     */
    export function isMissingContractRouteFinding(finding: string): boolean;
    /** Seeds are test data: empty tables are a valid, visible app. Includes compiler errors ON seeds.ts. */
    export function isSeedFinding(finding: string): boolean;
    /**
     * Persistence-policy findings about artifacts that can be omitted from publication (adapter/port/domain
     * /seed rows). A leaked TABLE is structural (migrate would create it) and stays blocking.
     */
    export function isOmittablePolicyFinding(finding: string): boolean;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbHealthReport" {
    export const MAX_HEALTH_ROUNDS = 20;
    /**
     * Merge a new report snapshot into the existing cb-health-report.json content.
     * - top level = the LAST state (the flattened report), backward-compatible with readers of the old shape;
     * - `rounds` = the accumulated snapshots (oldest first), capped at MAX_HEALTH_ROUNDS.
     * A snapshot never carries its own `rounds` key, so the array does not grow quadratically.
     */
    export function buildHealthReportContent(existingRaw: string | null, report: Record<string, unknown>, now: string): string;
    /**
     * The last validate-all of a run is often a CLEAN pass (post-seeds, findings 0). It used to write
     * `repairHistory: []` and `globalAttempts: 0` over the top of the file because repair state was
     * cleared after the previous success. The rounds array still held the repair-round snapshots.
     * Fold the longest history and the max attempts so the top-level health a post-mortem reads first
     * matches the steps that actually ran.
     */
    export function foldRepairAudit(existingRaw: string | null, current: {
        repairHistory?: unknown;
        globalAttempts?: unknown;
    }): {
        repairHistory: string[];
        globalAttempts: number;
    };
    /**
     * Seeds verdicts are written by gen-seeds (`degraded` on give-up, `ok` on full convergence) and must
     * survive a later validate-all snapshot that does not mention seeds. The fold takes the MOST RECENT
     * snapshot that mentions seeds: `ok` clears the top-level fields (a prior-run `degraded` still sitting
     * in `rounds` is a ghost); `degraded` is copied through so `passed` at the top does not erase the give-up.
     */
    export function foldSeedsDegraded(existingRaw: string | null, current: {
        seeds?: unknown;
        seedError?: unknown;
        seedSkipped?: unknown;
    }): {
        seeds?: 'degraded';
        seedError?: string;
        seedSkipped?: unknown;
    };
    export function foldOperationsCoverage(existingRaw: string | null, current: {
        operations?: unknown;
        operationsMissing?: unknown;
    }): {
        operations?: 'degraded';
        operationsMissing?: unknown;
    };
    export interface OperationsMissingReport {
        noUsecase: string[];
        noEndpoint: string[];
        declared: number;
        covered: number;
    }
    export type OperationsCoverageVerdict = {
        operations: 'ok';
    } | {
        operations: 'degraded';
        operationsMissing: OperationsMissingReport;
    };
    export function expectedRoutesByOperation(workspaces: ReadonlyArray<{
        bffCalls: ReadonlyArray<{
            route: string;
            uses: ReadonlyArray<{
                operationId: string;
            }>;
        }>;
    }>): Record<string, string[]>;
    /** Prefix every missing-route finding carries, so severity/tests can recognise the family. */
    export const MISSING_CONTRACT_ROUTE_PREFIX = "contract route without controller ->";
    /**
     * ROUTE-level coverage: every bffCall the l4 workspaces declare must have a registered controller route.
     *
     * compareOperationsCoverage answers a WEAKER question — "does this operation have SOME endpoint?" — and
     * that is exactly the hole the 102047/todo run fell through: `listTask` is used by taskCatalogue AND
     * taskHub, taskCatalogue's route survived, so listTask counted as covered while the entire taskHub
     * controller was missing. Only the per-route check sees a lost workspace.
     */
    export function collectMissingContractRouteFindings(workspaces: ReadonlyArray<{
        workspaceId: string;
        bffCalls: ReadonlyArray<{
            route: string;
        }>;
    }>, routeKeys: Iterable<string>): string[];
    /**
     * One-way check: l4-declared operations that did not become a usecase and/or a route.
     * Extra usecases nobody calls are ignored on purpose.
     */
    export function compareOperationsCoverage(input: {
        declared: readonly string[];
        usecaseNames: Iterable<string>;
        routeKeys: Iterable<string>;
        expectedRoutesByOperation?: Readonly<Record<string, readonly string[]>>;
    }): OperationsCoverageVerdict;
    export function operationsCoverageLogLine(verdict: OperationsCoverageVerdict): string;
    /**
     * Scan warnings and the finalize read-back/retry summary must survive later snapshots that do not
     * mention them. A snapshot that SETS the field (even to []) is the latest run's value.
     */
    export function foldPipelineNotices(existingRaw: string | null, current: Record<string, unknown>): {
        scanWarnings?: string[];
        todoReadBack?: unknown;
        rebuildWiped?: number;
        rebuildWipedMessage?: string;
        rebuildWipedFinding?: string;
    };
    /** Keep the highest models.peak seen in any snapshot — be5 closed with registry 104 but the leak is the peak. */
    export function foldModelsPeak(existingRaw: string | null, current: {
        models?: unknown;
    }): {
        registry: number;
        pendingRelease: number;
        peak: number;
    } | undefined;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
        senderDeviceId?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        subscription?: PushSubscriptionData;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface PushSubscriptionData {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        expirationTime?: number | null;
    }
    export interface UserNotifications {
        deviceId: string;
        subscription: PushSubscriptionData;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    /** Existing share-link format from createMessageLink: `#message/{threadId}` or `#message/{threadId}/{messageId}`. */
    export function threadOpenFromHash(hash: string): {
        threadId: string;
        messageId?: string;
    } | undefined;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbLocalStepTitle" {
    export function localStepTitle(context: mls.msg.ExecutionContext, step: {
        stepId: number;
    }, title: string): void;
    export function startLocalStepTick(context: mls.msg.ExecutionContext, step: {
        stepId: number;
    }, makeTitle: (elapsedSec: number) => string): () => void;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmPolicy" {
    /**
     * Persistence-policy gate: the l4 says WHERE an entity lives, and this is the deterministic check that
     * the generated l1 obeys it. Pure (no platform imports) so it is unit-tested directly.
     *
     * Run 9 of buildFlowFsm is the case it exists for: Client, Project and InventoryItem declare
     * `storage.target: 'mdm'` and FieldWorker/PlatformUser declare `'external'`, and the run still
     * produced local tables — seeded ones, duplicating the organization's people. Nothing FAILED, because
     * a local table for master data is perfectly valid code; only the policy was violated. A finding is
     * the only thing that turns that class of defect from invisible into blocking.
     *
     * The gate reads what is ON DISK (artifact short names), never a plan: a plan that promised the right
     * thing and materialized the wrong one is exactly what has to be caught.
     */
    export interface CbPolicyEntity {
        entityId: string;
        kind: string;
        storageTarget: string;
    }
    export interface CbPolicyArtifacts {
        /** lowercased shortNames of `layer_3_domain/entities/*.defs.ts` */
        domainEntities?: Iterable<string>;
        /** lowercased shortNames of `layer_2_application/ports/*.defs.ts` (`<entity>Repository`) */
        ports?: Iterable<string>;
        /** lowercased shortNames of `adapters/persistence/**` (table defs + adapters) */
        persistence?: Iterable<string>;
        /** entity ids (any case) that the seed plan writes LOCAL rows for */
        seededLocalEntities?: Iterable<string>;
    }
    /**
     * One finding per (entity, forbidden artifact). `storage.target` is quoted verbatim so the reader can
     * go straight to the l4 line that was ignored.
     */
    export function collectPersistencePolicyIssues(entities: CbPolicyEntity[], artifacts: CbPolicyArtifacts): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPipelineRun" {
    export const CB_PIPELINE_AGENT_SLUG = "changebackend";
    export interface PipelineRunDegradation {
        at: string;
        kind: string;
        reason: string;
        path?: string;
    }
    export interface PipelineRunSummary {
        moduleName: string;
        agent: string;
        command: string;
        startedAt: string | null;
        finishedAt: string;
        verdict: 'completed' | 'failed' | 'degraded';
        reason: string;
        counts: Record<string, unknown>;
        degradations: PipelineRunDegradation[];
        scanWarnings?: string[];
        todoReadBack?: unknown;
        /** Compile gate of this host: ran (Monaco or project tsc) or unavailable. State, not an error. */
        tscGate?: 'ran' | 'unavailable';
    }
    export function nextPipelineRunNn(existingShortNames: readonly string[], agentSlug: string): string;
    export function resolveCbPipelineModule(explicit?: string, longMemory?: unknown): string;
    export function describeCbCommand(longMemory: Record<string, unknown> | null | undefined): string;
    export function listCbPipelineShortNames(moduleName: string): string[];
    /** `seedSkipped` is an object `{ tables, mdmEntities, reason }`. `String(object)` is "[object Object]". */
    export function formatDegradationReason(reason: unknown): string;
    export function buildCbRunSummary(input: {
        moduleName: string;
        command: string;
        noWork: boolean;
        ownersDone: number;
        ownersFlipped: number;
        compilerLeft: boolean;
        health: Record<string, unknown> | null;
        summary: string;
        extraDegradations?: PipelineRunDegradation[];
    }): PipelineRunSummary;
    /** Recording must never change the run outcome. A throw from the writer is swallowed. */
    export function bestEffortRecord(write: () => Promise<unknown>): Promise<void>;
    /** Index the run on a terminal failure so `l4/<module>/pipeline/` is not missing `runNN_changebackend.json`. */
    export function recordFailedCbRun(input: {
        moduleName?: string;
        longMemory?: unknown;
        reason: string;
        health?: Record<string, unknown> | null;
    }): Promise<void>;
    export function saveCbRunSummary(summary: PipelineRunSummary): Promise<string | null>;
    export function cbFastHandoffMarkInfo(moduleName: string, project?: number): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    };
    export function readCbFastHandoffMark(moduleName: string): Promise<{
        to: string;
        message: string;
        at: string;
    } | null>;
    export function writeCbFastHandoffMark(moduleName: string, message: string): Promise<void>;
    /** Keep a reference so the write-folder chokepoint stays in this module's tests. */
    export function cbRunTraceFolder(): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepairLock" {
    export function serializeRepairMutation<T>(operation: () => Promise<T>): Promise<T>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepair" {
    import { type CbCostReport } from "_102021_/l2/agentChangeBackend/helpers/cbCostReport";
    import { type CbComponentRepair, type CbRepairSource } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    export { COMPONENT_REPAIR_BUDGET, mergeComponentRepair, buildRepairPromptSection, resetRespawnCounts, noteStaleSpawn, noteRepairAttempt, staleSpawnCeiling, CB_DISPATCH_HARD_CEILING, dispatchHardCeiling } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    export type { CbComponentRepair, CbRepairSource, CbRespawnCount, CbCeilingKind, CbSpawnDecision } from "_102021_/l2/agentChangeBackend/helpers/cbRepairCore";
    /** Max full validate-all -> re-materialize repair rounds. */
    export const GLOBAL_REPAIR_BUDGET = 2;
    /** Max judge passes (initial critique + 1 post-repair verification). */
    export const JUDGE_MAX_RUNS = 2;
    /** Routing taxonomy (improveAddNewSolution2_1.md §2). fora_de_escopo findings are discarded. */
    export type CbFindingType = 'estrutural' | 'decisao' | 'fora_de_escopo';
    export interface CbJudgeFinding {
        ownerId: string;
        type: CbFindingType;
        severity: 'error' | 'warning';
        message: string;
        suggestion?: string;
    }
    export interface CbRepairState {
        schemaVersion: string;
        componentRepairs: Record<string, CbComponentRepair>;
        globalAttempts: number;
        judgeRuns: number;
        /** Durable audit of every repair occurrence in the run ("target :: attempt n :: finding"). The
         * fan-out children are DELETED by the runtime after completion, so this history is what survives;
         * cb-validate-all embeds it in the task trace before clearing the state. */
        history: string[];
        updatedAt: string;
        /** Run that archived `wipedKeys`. A later run with a different id ignores the set. */
        wipeRunId: string;
        /** Stor keys `/rebuild all` archived in `wipeRunId`. Dropped one by one as materialize succeeds. */
        wipedKeys: string[];
    }
    /** Append a timestamped line to the durable repair history (bounded). Exported so the validate-all
     *  global repair round can record which defRefs it forced stale (it mutates the state object directly
     *  in one read/save transaction). */
    export function pushHistory(state: CbRepairState, entry: string): void;
    export function readRepairState(): Promise<CbRepairState>;
    export function saveRepairState(state: CbRepairState): Promise<boolean>;
    /** Wipe the whole repair state (validate-all passed: the run converged). */
    export function clearRepairState(): Promise<void>;
    /** Persist the `/rebuild all` archive set for this run. Scan calls this AFTER `clearRepairState`. */
    export function recordWipeMemory(runId: string, keys: string[]): Promise<void>;
    /** Drop a stor key after this run rematerialized it. Best-effort: a leftover key re-generates, never skips. */
    export function markWipedKeyGenerated(key: string): Promise<void>;
    /** Repair target key for the usecase DEFS phase (shared by agentCbUsecase and agentCbJudge). */
    export function usecaseDefsTarget(ownerId: string): string;
    export function getComponentRepair(target: string): Promise<CbComponentRepair | null>;
    /** Record a failed attempt (increments the budget) and keep the findings + rejected code for the retry prompt. */
    export function recordComponentFailure(target: string, findings: string[], lastCode?: string, source?: CbRepairSource): Promise<CbComponentRepair>;
    /** Set findings WITHOUT burning component budget (used by the validate-all global round, which grants
     * the component a fresh worker budget — the global round has its own budget). */
    export function setComponentFindings(target: string, findings: string[], source: CbRepairSource): Promise<void>;
    export function clearComponentRepair(target: string): Promise<void>;
    /** True while the component may still be retried (attempts consumed <= budget). */
    export function hasRepairBudget(entry: CbComponentRepair | null | undefined): boolean;
    /** Persist the validate-all outcome + repair audit to l4/trace/cb-health-report.json. The task dump
     * keeps interaction null on deterministic steps and the repair state is cleared on success, so this
     * file is the DURABLE record of what was repaired in the run (survives task cleanup). */
    export function saveHealthReport(report: Record<string, unknown>): Promise<void>;
    /** Accumulate ONE LLM step's cost into l4/trace/cb-cost.json under `phase`. Cost comes from the
     *  authoritative `interaction.cost` (this step's LLM charge, retries included, no child cost); token
     *  counts are parsed from the trace (not carried on the interaction). Best-effort + serialized (fan-out
     *  workers write concurrently); never throws into the flow. */
    export function recordLlmCost(phase: string, interaction: mls.msg.AIInteraction | null | undefined): Promise<void>;
    export function readCostReport(): Promise<CbCostReport>;
    /** Read the last-state cb-health-report.json (top level = the last snapshot). Used by the final summary
     *  (T6) to surface residual compiler findings that would otherwise live only in this file. */
    export function readHealthReport(): Promise<Record<string, unknown> | null>;
    /** Delete the output `.ts` so the next dispatch generates it. The repair ceiling lives here:
     *  the 4th call on the same defRef returns false, records a finding, and leaves the `.ts`. */
    export function forceRegenerate(defRef: string): Promise<boolean>;
    /**
     * The dossier of one run, written where the module's trace lives.
     *
     * Everything here was reconstructed BY HAND after each run, from the task record plus the console: the
     * cost and calls per phase, the repair history, the residual findings and the model counts. Writing it
     * once, at the end, makes the next post-mortem a file read.
     */
    export function saveRunReport(report: Record<string, unknown>): Promise<string | null>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRules" {
    export interface L4RuleDefinition {
        ruleId: string;
        title: string;
        description: string;
        appliesTo: string[];
    }
    /** Heading of the domain/usecase prompt block. Absent from the prompt when the owner has no rules. */
    export const L4_RULES_PROMPT_HEADING = "## L4 rules referenced (id + title + description)";
    /** Parse the `rules` array of one l4 defs object. ns4 names the id `id`; older files use `ruleId`. */
    export function collectRuleDefinitionsFromParsed(parsed: unknown): L4RuleDefinition[];
    /** Full L4 rule text (id + title + description + appliesTo) from every rule set def in the project. */
    export function readRuleDefinitions(project: number): Promise<L4RuleDefinition[]>;
    /**
     * Resolve applied ids against the catalog. Unknown ids stay in the list with empty text — same
     * fallback gen-seeds has always used, so a missing catalog row is visible instead of dropped.
     */
    export function resolveAppliedRules(catalog: L4RuleDefinition[], ruleIds: string[]): L4RuleDefinition[];
    /** Unique rule ids declared on the given entities, in first-seen order. */
    export function ruleIdsOfEntities(entities: ReadonlyArray<{
        entityId: string;
        useRules?: string[];
    }>, entityIds: readonly string[]): string[];
    /**
     * Prompt block for gen-domain / gen-usecase: only the referenced rules, as id + title + description.
     * Empty `ruleIds` → empty string (no section, even if the catalog is large).
     */
    export function appliedRulesPromptSection(catalog: L4RuleDefinition[], ruleIds: string[]): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbRunDossier" {
    /**
     * Flatten the live task tree into the records the run dossier stores.
     *
     * Child-step traces do not survive in the persisted `iaCompressed` (the msgtask dump of a finished
     * run only keeps the root). Reading them HERE, at finalize, from the in-memory tree, is the only
     * chance to keep title/status/last-trace of every step as a file.
     */
    export interface RunStepRecord {
        stepId: number;
        type: string;
        title: string;
        status: string;
        agentName?: string;
        lastTrace?: string;
    }
    export function collectRunStepRecords(roots: unknown): RunStepRecord[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSchemas" {
    export const domainEntityResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly title: {
                readonly type: "string";
            };
            readonly fields: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["fieldId", "type", "required"];
                    readonly properties: {
                        readonly fieldId: {
                            readonly type: "string";
                        };
                        readonly type: {
                            readonly type: "string";
                        };
                        readonly required: {
                            readonly type: "boolean";
                        };
                        readonly description: {
                            readonly type: "string";
                        };
                        readonly enum: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
            readonly valueObjects: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly invariants: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly statusEnum: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const repositoryPortResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "interfaceName", "methods"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly interfaceName: {
                readonly type: "string";
            };
            readonly methods: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const persistenceTableResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["tableId", "tableName", "columns", "primaryKey"];
        readonly properties: {
            readonly tableId: {
                readonly type: "string";
            };
            readonly tableName: {
                readonly type: "string";
            };
            readonly columns: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly primaryKey: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly indexes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly detailsColumn: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["enabled"];
                readonly properties: {
                    readonly enabled: {
                        readonly type: "boolean";
                    };
                    readonly columnName: {
                        readonly type: "string";
                    };
                    readonly childCollections: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                };
            };
            readonly appendOnly: {
                readonly type: "boolean";
            };
            readonly purpose: {
                readonly type: "string";
            };
            readonly retentionDays: {
                readonly type: "number";
            };
        };
    };
    export const repositoryAdapterResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "className", "portRef", "tableRef"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly className: {
                readonly type: "string";
            };
            readonly portRef: {
                readonly type: "string";
            };
            readonly tableRef: {
                readonly type: "string";
            };
            readonly mdmReads: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly notes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const usecaseResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["usecaseId", "ports", "functions"];
        readonly properties: {
            readonly usecaseId: {
                readonly type: "string";
            };
            readonly ports: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly rulesApplied: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly functions: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["functionName", "inputTypeName", "outputTypeName", "input", "output"];
                    readonly properties: {
                        readonly functionName: {
                            readonly type: "string";
                        };
                        readonly inputTypeName: {
                            readonly type: "string";
                        };
                        readonly outputTypeName: {
                            readonly type: "string";
                        };
                        readonly input: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                    readonly fieldRef: {
                                        readonly type: "string";
                                    };
                                    readonly item: {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly properties: {
                                            readonly fields: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly type: "object";
                                                    readonly additionalProperties: false;
                                                    readonly required: readonly ["name", "type"];
                                                    readonly properties: {
                                                        readonly name: {
                                                            readonly type: "string";
                                                        };
                                                        readonly type: {
                                                            readonly type: "string";
                                                        };
                                                        readonly required: {
                                                            readonly type: "boolean";
                                                        };
                                                        readonly description: {
                                                            readonly type: "string";
                                                        };
                                                        readonly ofEntity: {
                                                            readonly type: "string";
                                                        };
                                                        readonly fieldRef: {
                                                            readonly type: "string";
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly output: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                    readonly fieldRef: {
                                        readonly type: "string";
                                    };
                                    readonly item: {
                                        readonly type: "object";
                                        readonly additionalProperties: false;
                                        readonly properties: {
                                            readonly fields: {
                                                readonly type: "array";
                                                readonly items: {
                                                    readonly type: "object";
                                                    readonly additionalProperties: false;
                                                    readonly required: readonly ["name", "type"];
                                                    readonly properties: {
                                                        readonly name: {
                                                            readonly type: "string";
                                                        };
                                                        readonly type: {
                                                            readonly type: "string";
                                                        };
                                                        readonly required: {
                                                            readonly type: "boolean";
                                                        };
                                                        readonly description: {
                                                            readonly type: "string";
                                                        };
                                                        readonly ofEntity: {
                                                            readonly type: "string";
                                                        };
                                                        readonly fieldRef: {
                                                            readonly type: "string";
                                                        };
                                                    };
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        readonly ports: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly rulesApplied: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly transactional: {
                            readonly type: "boolean";
                        };
                        readonly steps: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
    };
    export const httpControllerResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["pageId", "controllerName", "handlers", "routes"];
        readonly properties: {
            readonly pageId: {
                readonly type: "string";
            };
            readonly controllerName: {
                readonly type: "string";
            };
            readonly handlers: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly routes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const seedPlanResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary", "localTables", "mdmEntities"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly localTables: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly mdmEntities: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const judgeResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["findings"];
        readonly properties: {
            readonly findings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const finalSummaryResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly ownersDone: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly warnings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore" {
    import type { L4RuleDefinition } from "_102021_/l2/agentChangeBackend/helpers/cbRules";
    export type SeedRuleDefinition = L4RuleDefinition;
    /** Engine identification default (`defs/ontology.ts` "Default: US"). Used until n06 exposes `ctx.organization.countryCode`. */
    export const MDM_SEED_COUNTRY_CODE = "US";
    export const MDM_SEED_COUNTRY_CODE_ORIGIN: "level1-subtype-default";
    export const SEED_T0 = "2026-07-01T08:00:00.000Z";
    export const SEED_T1 = "2026-07-01T09:00:00.000Z";
    export const SEED_WINDOW_START = "2026-07-01T00:00:00.000Z";
    export const SEED_WINDOW_END = "2026-07-08T00:00:00.000Z";
    export const SEED_PLAN_START = "/* <agentCbSeedsPlan>";
    export const SEED_PLAN_END = "</agentCbSeedsPlan> */";
    export const SEED_ASSET_URLS_START = "// <agentCbSeedAssetUrls>";
    export const SEED_ASSET_URLS_END = "// </agentCbSeedAssetUrls>";
    export const SEED_VALIDATOR_ATTEMPTS = 100;
    /** Leftover valid values per seeded field, for create-command tests that must not reuse a row. */
    export const SEED_SPARES_PER_FIELD = 3;
    export interface SeedFieldDefinition {
        fieldId: string;
        type: string;
        required: boolean;
        enumValues: string[];
        /** Domain export that judges this field. The generator never interprets the rule; it only calls this. */
        validatorExport?: string;
    }
    export interface SeedEntityDefinition {
        entityId: string;
        title: string;
        kind: string;
        fields: SeedFieldDefinition[];
        /**
         * The lifecycle states this module actually OPERATES on — the union of `fromStates` of the entity's
         * workflow transitions. Not every declared state: a screen that decides on a state filters by it, and
         * that is the set a seed has to cover. Absent for an entity with no workflow (nothing to cover).
         */
        operatedStates?: string[];
        /** `storage.idField` from the l4. Required on v7; v6 may omit it (name fallback until regeneration). */
        idField?: string;
        /** Platform MDM subtype from l4 v7. Empty on v6 until the module is regenerated. */
        mdmSubtype?: string;
        /** 7 when the ontology file is v7; 6 for older modules kept until regeneration (2026-09-08). */
        defsVersion?: number;
    }
    export interface SeedTableColumn {
        name: string;
        type: string;
        nullable: boolean;
    }
    export interface SeedTableDefinition {
        tableId: string;
        tableName: string;
        seedFor: string;
        /** Real table columns. MUST include the details column when the TableDefinition enables it — the
         * emitter only writes a row property for a declared column, so omitting it DROPS the whole details
         * payload (102051: every seeded row lost its planned `details`, see detailsColumnName). */
        columns: SeedTableColumn[];
        primaryKey: string[];
        /** The JSONB envelope column declared by `detailsColumn` in the TableDefinition (`enabled` + a
         * `columnName` that is conventionally, but not necessarily, `details`). Empty when the table has none. */
        detailsColumnName?: string;
        /** Embedded child collections stored INSIDE the details envelope (declared by the TableDefinition).
         * Surfaced to the planner so an aggregate that owns children (e.g. order items) actually gets them. */
        childCollections?: string[];
    }
    /** The details envelope column of a table plan: the explicit declaration when present, else the
     * conventional `details` if such a column exists. Keeps the compiler honest about WHERE the JSONB goes
     * without hardcoding the name at every use site. */
    export function detailsColumnOf(table: Pick<SeedTableDefinition, 'columns' | 'detailsColumnName'>): string;
    export interface SeedReference {
        ref: string;
    }
    export interface SeedAssetRef {
        asset: string;
        kind: 'image';
    }
    export type SeedValue = string | number | boolean | null | SeedReference | SeedAssetRef;
    export interface SeedFieldValue {
        name: string;
        value: SeedValue;
    }
    export interface SeedChildRow {
        key: string;
        fields: SeedFieldValue[];
    }
    export interface SeedChildCollection {
        name: string;
        rows: SeedChildRow[];
    }
    export interface SeedLocalRow {
        key: string;
        columns: SeedFieldValue[];
        details: SeedFieldValue[];
        children: SeedChildCollection[];
    }
    export interface SeedLocalTable {
        tableId: string;
        rows: SeedLocalRow[];
    }
    export interface SeedMdmRelationship {
        targetRef: string;
        type: string;
        metadata: SeedFieldValue[];
        isBidirectional: boolean;
    }
    export interface SeedMdmRow {
        key: string;
        fields: SeedFieldValue[];
        relationships: SeedMdmRelationship[];
    }
    export interface SeedMdmEntity {
        entityId: string;
        rows: SeedMdmRow[];
    }
    export interface SeedPlan {
        summary: string;
        localTables: SeedLocalTable[];
        mdmEntities: SeedMdmEntity[];
    }
    export interface SeedRelationshipDefinition {
        fromEntity: string;
        toEntity: string;
        type: string;
        fromFieldIds?: string[];
        toFieldIds?: string[];
    }
    /** A deterministic batch of seed-plan targets. All references emitted by a target in a wave resolve
     * to a target in an earlier wave, or to another target in that same wave (a dependency cycle). */
    export interface SeedPlanningWave {
        index: number;
        tableIds: string[];
        mdmEntityIds: string[];
    }
    export interface SeedPlanProgress {
        plan: SeedPlan;
        partial: boolean;
        completedWaveIndexes: number[];
    }
    export interface SeedReferenceCatalogItem {
        ref: string;
        label: string;
        context: string;
    }
    export interface SeedPlanPromptOptions {
        catalog?: SeedReferenceCatalogItem[];
        priorSummary?: string;
        wave?: SeedPlanningWave;
        estimatedOutputTokens?: number;
    }
    export const MAX_SEED_WAVE_OUTPUT_TOKENS = 12000;
    /** An L4 actor (platform user role). Some FK fields (e.g. an assignee or the actorSession-resolved
     * worker on an event) reference a platform-user identity, NOT a module-owned entity — there is no
     * table/MDM entity to seed. The generator synthesizes a small, deterministic pool of platform-user
     * identities per actor so those FKs resolve to real MDM Person records instead of a fabricated table. */
    export interface SeedActorDefinition {
        actorId: string;
        title: string;
    }
    export interface SeedTimeWindow {
        start: string;
        end: string;
    }
    export interface SeedBuildInput {
        project: number;
        moduleName: string;
        language: string;
        entities: SeedEntityDefinition[];
        tablePlans: SeedTableDefinition[];
        ruleIds: string[];
        /** Full L4 rule text for the applied ruleIds. Passed to the planner so rule conformance is guided
         * by L4 semantics instead of hardcoded, domain-specific checks. */
        rules?: SeedRuleDefinition[];
        /** L4 relationship graph, so the planner models MDM relationships generically (no invented,
         * per-domain type names baked into this generator). */
        relationships?: SeedRelationshipDefinition[];
        /** 7 when the module ontology is v7; 6 for older modules kept until regeneration (2026-09-08). */
        defsVersion?: number;
        /** L4 actors. The generator exposes a resolvable platform-user identity pool per actor so FKs that
         * reference a platform user (assignees, actorSession-resolved fields) never fabricate a table. */
        actors?: SeedActorDefinition[];
        /** Allowed timestamp window; every timestamp must be ISO 8601 within it. */
        timeWindow?: SeedTimeWindow;
        /** Targets deliberately left with NO seed rows (a wave that never converged). Recorded in the
         * emitted artifact so downstream consumers can tell "empty by design" from "generation lost it". */
        skipped?: SeedSkippedTargets;
        /**
         * Canonical tags (`<module>.<Entity>`) that generated usecases actually read through `ctx.mdm`
         * (`listByType` or lifecycle). Derived from the pinned `mdm` block + generated sources — never
         * guessed from an entity name. While `MDM_WRITE_PATH_ENABLED` is false those entities still have
         * LOCAL tables; the index must be seeded too or lists/inactivate return empty/NOT_FOUND (be5).
         */
        mdmRequiredTags?: string[];
        plan: SeedPlan;
    }
    /** Machine-readable seed coverage: which targets have NO rows on purpose. The seed give-up narrows
     * tablePlans/entities so a non-converging wave cannot fail the whole backend — which silently left
     * tables with zero rows (102051: AiSalesSummary, AiPromotionSuggestion). A test generator asserting
     * "at least one row" against those produces impossible cases, so the fact is published, not implied. */
    export interface SeedSkippedTargets {
        tables: string[];
        mdmEntities: string[];
        reason: string;
        /** Violations of EACH planner attempt, in order. The give-up reason used to keep only the last. */
        attempts?: {
            attempt: number;
            errors: string[];
        }[];
    }
    /** One planner try for a seed wave. Kept across repair steps so a later try cannot silently regress
     * a field that already validated, and so give-up can name every attempt's violations. */
    export interface SeedAttemptRecord {
        attempt: number;
        plan: SeedPlan;
        errors: string[];
    }
    export interface SeedBuildResult {
        errors: string[];
        content?: string;
        summary: string;
    }
    /**
     * Partitions seed targets by their real dependency graph. MDM starts in the first wave, ordinary
     * persistence tables in the second, and supporting/event tables in the third; a dependency moves
     * only its dependant forward. Strongly connected targets stay together so mutual references remain
     * valid within one LLM call.
     */
    export function deriveSeedPlanningWaves(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>): SeedPlanningWave[];
    /** Keeps a wave under the output budget by assigning whole dependency components to sequential
     * batches. An SCC is never split, so references inside a planning wave remain valid. */
    export function splitSeedPlanningWave(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave, maxTokens?: number): SeedPlanningWave[];
    export function estimateSeedPlanningWaveTokens(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave): number;
    /** Selects exactly the L4/table definitions that a wave may create. Rules and relationships are
     * filtered too, so unrelated definitions never inflate the planner context. Coverage of ctx.mdm
     * tags is scoped the same way: a wave cannot seed (or be failed for) a tag whose entity is not
     * in the wave. Full-tag coverage is the merge-final validator's job. */
    export function seedPlanInputForWave(input: Omit<SeedBuildInput, 'plan'>, wave: SeedPlanningWave): Omit<SeedBuildInput, 'plan'>;
    export function isSeedAssetRef(value: unknown): value is SeedAssetRef;
    /** Turns a tool-call result into a defensive internal representation. Validation below remains the
     * authority: malformed values become empty and produce objective findings instead of being trusted. */
    /**
     * Drop columns the compiler already owns, so a planner that echoes them does not fail the wave.
     *
     * The prompt says PKs are compiled from tableId+row key and the JSONB envelope is `row.details`,
     * never a `columns` entry. Repair waves still put `"name":"pet_id","value":null` and
     * `"name":"details","value":null` in `columns` — which `validateSeedPlan` reports as
     * `unknown persistence column` and then skips the rest of the module (petShop wave 3: Pet /
     * ScheduleBlock / InstitutionalPresentation generated, then discarded). Stripping those names is
     * the legitimate path; unknown *other* columns stay fatal.
     */
    /** `petShop.BusinessHours` (the ctx.mdm tag) → `BusinessHours` (the entity id). */
    export function stripModuleEntityPrefix(id: string, moduleName: string): string;
    export function normalizeSeedPlan(plan: SeedPlan, tablePlans?: Iterable<SeedTableDefinition>, moduleName?: string): SeedPlan;
    export function parseSeedPlan(value: unknown): SeedPlan;
    /** Reads the persisted plan embedded in seeds.ts. A valid plan is reused so materializing the same
     * L4/table input never asks the model for a different fixture mass. */
    export function extractSeedPlanFromSource(source: string): SeedPlan | null;
    /** Reads either a completed or interrupted seed run from the persisted envelope (seeds.ts comment or seeds.defs.ts). */
    export function extractSeedPlanProgressFromSource(source: string): SeedPlanProgress | null;
    /** Reads the published seed coverage (targets intentionally left with no rows) back from a generated
     * seeds.ts. Returns null when the artifact declares nothing skipped — i.e. full coverage. Consumers
     * (register -> l5 config, and any test generator) use this instead of inferring from missing exports. */
    export function extractSeedSkippedFromSource(source: string): SeedSkippedTargets | null;
    export function parseSeedAttemptRecords(value: unknown): SeedAttemptRecord[];
    /**
     * A repair must not regress a field that already validated. Take the newer plan as the skeleton
     * (keys, extra rows) and restore any prior value that was valid when the newer one is missing or
     * invalid. Row keys that only differ by whitespace (`pet thor` vs `pet_thor`) match so a repair
     * that fixed the key does not drop the fields that were already good.
     */
    export function recoverSeedPlanFromPrior(prior: SeedPlan, next: SeedPlan, priorErrors: string[], nextErrors: string[]): SeedPlan;
    export function formatSeedGiveUpReason(waveIndex: number, attempts: SeedAttemptRecord[], maxAttempts: number): string;
    /** Prefer a fully valid attempt; otherwise recover valid fields forward from earlier tries. The
     * recovered plan is used only when it validates — a still-invalid plan must not be planted. */
    export function selectSeedPlanAfterAttempts(attempts: SeedAttemptRecord[], validate: (plan: SeedPlan) => string[]): {
        plan: SeedPlan;
        errors: string[];
    };
    /** A partial seeds.ts remains valid TypeScript so an interrupted flow can be resumed without
     * re-planning completed waves. It intentionally exports no runtime rows until final compilation. */
    export function buildPartialSeedSource(input: Pick<SeedBuildInput, 'project' | 'moduleName' | 'language'>, progress: Pick<SeedPlanProgress, 'plan' | 'completedWaveIndexes'>): string;
    export function mergeSeedPlans(current: SeedPlan, next: SeedPlan): SeedPlan;
    export function seedReferenceCatalog(plan: SeedPlan): SeedReferenceCatalogItem[];
    /** Named anchor for a seeded row (`petitionPublished`). Stable across runs for a given entity+key. */
    export function seedAnchorName(entityId: string, rowKey: string): string;
    /** Bare `string` (not a literal union). Wrapping anything else with seedStringPassing is a type error. */
    export function seedFieldIsBareString(field: Pick<SeedFieldDefinition, 'type' | 'enumValues'>): boolean;
    /**
     * Domain export that judges a field, only when wrapping it is type-safe: the field is a bare `string`
     * and the function accepts `string`. A literal union is already checked by tsc — wrapping it yields
     * TS2322 (returns `string`) and TS2345 (type-guard param is the union, not `string`). In doubt, skip.
     */
    export function findSeedFieldValidatorExport(entitySource: string, fieldId: string, ruleIds?: string[], field?: Pick<SeedFieldDefinition, 'type' | 'enumValues'>): string | undefined;
    /** Bounded deterministic search: vary trailing digits until `check` accepts, else keep the planned value. */
    export function seedStringPassing(check: (value: string) => boolean, planned: string, attempts?: number): string;
    /**
     * Leftover values that pass the same search as `seedStringPassing` and are not in `used` (the seeded
     * rows). Create-command tests consume these so they do not collide with a unique seeded value.
     * `check` is the domain validator when there is one; otherwise every unused candidate is accepted.
     */
    export function seedSparesPassing(check: (value: string) => boolean, planned: string, used: readonly string[], count?: number, attempts?: number): string[];
    export function seedSourcePurityErrors(source: string): string[];
    export function buildSeedDefsData(input: SeedBuildInput, extra?: {
        partial?: boolean;
        completedWaveIndexes?: number[];
    }): Record<string, unknown>;
    /**
     * A `{ ref }` is only legitimate on a foreign key. `weeklySchedule: { ref: "local:BusinessHours.x" }`
     * was compiled to the row's own uuid (be5 qryListBusinessHours). Auto-reference is always an error.
     */
    export function fieldAllowsSeedRef(fieldName: string, knownEntityIds: Iterable<string>): boolean;
    /** A `…Date` field is a CALENDAR DATE; a `…At` field is an INSTANT.
     *
     * The validator used to demand a full ISO datetime for both (`/(At|Date)$/`), so a planner that wrote
     * `"2026-07-03"` for `workDate`/`dueDate`/`issueDate`/`plannedStartDate`/`shiftDate` was rejected — 16 of
     * the 19 findings that burned both repair attempts in 102045/buildFlowFsm, and the same failure that
     * killed wave 2 of cafeFlow run14. The planner was RIGHT: generated usecases compare these fields as
     * plain `YYYY-MM-DD` strings (e.g. `shift.shiftDate >= periodStart` built from `iso.slice(0, 10)`), so a
     * datetime stored there silently breaks same-day comparisons. Date-only is therefore ACCEPTED for a
     * `…Date` field; `…At` stays strict, because an instant with no time is a different kind of wrong. */
    export function isDateOnlyField(fieldName: string): boolean;
    /**
     * Does an `…Id` field actually REFERENCE something seedable — a module entity or a platform-user
     * identity? Only then must its value be a symbolic `{ ref }`.
     *
     * The old rule was "every field ending in Id must be a { ref }", which is false for identifiers that are
     * plain data: `taxId` on an MDM Client is a tax number, not a pointer, and there is no `Tax` entity to
     * point at — yet the planner was told three times to make it symbolic (102045/buildFlowFsm), an
     * impossible instruction that burned the repair budget and forced the give-up.
     *
     * Matching is by SUFFIX against the known entity names, so a decorated id still resolves:
     * `topMenuItemId` ends with `MenuItemId` -> `MenuItem` exists -> a ref IS required (keeping it strict
     * avoids reintroducing dangling references). `closedByUserId` is platform-user-shaped -> strict too.
     * Only when nothing can be pointed at is a literal accepted.
     */
    export function idFieldHasResolvableTarget(fieldId: string, knownEntityIds: Iterable<string>): boolean;
    /** MDM index label: `name` on the envelope, else `fullName`/`title`, else the row key. Shared by
     * the validator (allows synthetic `name`), the local→MDM mirror, and the index emitter. */
    export function mdmIndexName(fields: Map<string, unknown> | Record<string, unknown> | SeedFieldValue[], fallbackKey: string): string;
    /** Deterministic validation of the plan before any seed source is saved. */
    export function validateSeedPlan(input: SeedBuildInput, knownReferences?: Iterable<string>): string[];
    /**
     * Canonical tags generated usecases actually hit via `ctx.mdm`. The pinned `mdm` block does not
     * carry the entity name — that comes from the operation's `entity`. `listByType({ type })` in the
     * generated .ts is the other surface. Never infer a tag from a name that has no mdm block / call.
     */
    export function collectRequiredMdmTags(input: {
        moduleName: string;
        mdmOwners: Array<{
            entity: string;
            mdm?: unknown;
        }>;
        usecaseSources?: Iterable<string>;
    }): string[];
    /** MDM ids that a give-up must publish: kind `mdm` OR a required ctx.mdm tag that has no plan row. */
    export function skippedMdmEntityIds(input: Pick<SeedBuildInput, 'entities' | 'mdmRequiredTags' | 'moduleName'>, seededMdmIds: Set<string>): string[];
    /** Every tag a generated usecase reads through ctx.mdm needs at least one MDM plan row with that tag. */
    export function collectRequiredMdmTagCoverage(input: SeedBuildInput): string[];
    /**
     * Copy local rows of a ctx.mdm-read entity into `mdmEntities`, same keys (so emitted ids match).
     * MDM cadastral `status` is Active — the local lifecycle status stays on the local table.
     */
    export function mirrorLocalRowsAsMdmPlan(plan: SeedPlan, tags: readonly string[], moduleName: string, timeWindow?: SeedTimeWindow): SeedPlan;
    /**
     * Clone a planned row for each OPERATED lifecycle state the plan missed. The validator already
     * demands one row per operated state; the planner historically covered only "main" states and
     * the wave gave up (be5 wave 6: ServiceExecution arrived).
     */
    export function coverMissingOperatedStates(plan: SeedPlan, input: Pick<SeedBuildInput, 'entities'>): SeedPlan;
    /** Deterministic repairs the LLM is taught to do but often misses in two attempts: operated-state
     * coverage and MDM index rows for tags the generated usecases already call. */
    export function repairSeedPlanDeterministically(plan: SeedPlan, input: Omit<SeedBuildInput, 'plan'> & {
        plan?: SeedPlan;
    }): SeedPlan;
    /**
     * Every OPERATED lifecycle state of an entity needs at least one seeded row in it.
     *
     * A screen that decides on a state filters by it, so a state nobody seeded makes that screen open empty
     * and its test fail for a reason that has nothing to do with the screen: the buildFlowFsm production run
     * had all three change-order journeys reporting `expected >= 1 item(s), got 0` because no ChangeOrder
     * was seeded as `submitted` or `pendingClientApproval`. One incomplete generator, five failures.
     *
     * "Operated" is the union of the `fromStates` of the entity's workflow transitions — the states some
     * transition READS. Requiring every DECLARED state instead would demand a row for terminal states nobody
     * queries and inflate every plan (the cafeFlow fixture alone would need 6 more rows), so the rule follows
     * the workflow, not the enum. Entities with no workflow, and entities the plan gave up on, are silent.
     */
    export function collectLifecycleStateCoverage(input: SeedBuildInput): string[];
    export function seedAssetUrlsBlock(urls: Record<string, string>, warnings?: string[]): string;
    export function updateSeedAssetUrlsInSource(source: string, urls: Record<string, string>, warnings?: string[]): string;
    /** Compile a validated plan. IDs, relationship IDs and structural MDM records are always generated
     * locally; only the business scenario itself comes from the LLM plan. */
    export function buildSeedSource(input: SeedBuildInput): SeedBuildResult;
    export function seedPlanPromptContext(input: Omit<SeedBuildInput, 'plan'>, repairFindings?: string[], options?: SeedPlanPromptOptions): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbTableNames" {
    export const POSTGRES_IDENTIFIER_MAX_LENGTH = 63;
    /** Lowercased module token used as the physical-name prefix. `listaAssinatura3` → `listaassinatura3_`. */
    export function moduleTableNamespacePrefix(moduleId: string): string;
    /** Prefix a physical storage name with the module. Lowercased; a name that already starts with the prefix is unchanged. */
    export function applyModuleTableNamespace(physicalName: string, moduleId: string): string;
    /** Undo the module prefix so lookup stays `petition_signature`, not `listaassinatura3_petition_signature`. */
    export function logicalTableNameFromEmitted(emittedName: string, moduleId: string): string;
    /** Final Postgres identifier after the runtime applies the per-project namespace. */
    export function physicalPostgresTableName(projectId: string, emittedTableName: string): string;
    export function assertPhysicalTableNameFitsPostgres(input: {
        projectId: string;
        moduleId: string;
        tableName: string;
        tableId?: string;
    }): string;
    /** Prefix tableName with the module and fail generation when the final Postgres name would overflow. */
    export function sanitizePlannerTableName<T extends Record<string, unknown>>(item: T, input: {
        moduleId: string;
        projectId: string;
        tableId?: string;
    }): T;
}
declare module "_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce01SessionScope" {
    /**
     * Compile fixture for the ce01-like assigned-direct predicate (Appointment.professionalId → Person).
     * Mirrors the template-emitted helper; frontend tsc is the compile gate.
     */
    interface RequestContext {
        sessionContext?: {
            actorId?: string;
            actorScope?: string[];
        };
        mdm: {
            collection: {
                listByType(input: {
                    type: string;
                    status?: string;
                }): Promise<{
                    items: Array<{
                        mdmId: string;
                        details: Record<string, unknown>;
                    }>;
                }>;
            };
        };
    }
    export interface ScopeFilter {
        fieldId: string;
        allowed: string[];
    }
    export function scopeFilterForListAppointment(ctx: RequestContext): Promise<ScopeFilter | null>;
    export function rowInScope(row: Record<string, unknown>, filter: ScopeFilter): boolean;
}
declare module "_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce05SessionScope" {
    /**
     * Compile fixture for the ce05-like own + projection predicate
     * (OrdenServicio.clienteId → Person). Projection is disclosure, not the person filter.
     */
    interface RequestContext {
        sessionContext?: {
            actorId?: string;
            actorScope?: string[];
        };
        mdm: {
            collection: {
                listByType(input: {
                    type: string;
                    status?: string;
                }): Promise<{
                    items: Array<{
                        mdmId: string;
                        details: Record<string, unknown>;
                    }>;
                }>;
            };
        };
    }
    export interface ScopeFilter {
        fieldId: string;
        allowed: string[];
    }
    export function scopeFilterForInspectOrden(ctx: RequestContext): Promise<ScopeFilter | null>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/fixtures/n09/ce09SessionScope" {
    /**
     * Compile fixture for the ce09-like assigned-via-intermediate predicate
     * (Vehicle ← VehicleAssignment.driverId → Person).
     */
    interface RequestContext {
        sessionContext?: {
            actorId?: string;
            actorScope?: string[];
        };
        mdm: {
            collection: {
                listByType(input: {
                    type: string;
                    status?: string;
                }): Promise<{
                    items: Array<{
                        mdmId: string;
                        details: Record<string, unknown>;
                    }>;
                }>;
            };
        };
    }
    export interface ScopeFilter {
        fieldId: string;
        allowed: string[];
    }
    export function scopeFilterForListVehicle(ctx: RequestContext, listAssignments: () => Promise<Record<string, unknown>[]>): Promise<ScopeFilter | null>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/fixtures/n10/closeTab" {
    /**
     * Compile fixture for a command that writes N entities in one transaction
     * (ce02-like: close the tab, persist the close record, free the table).
     * Frontend tsc is the compile gate.
     */
    interface RequestContext {
        idGenerator: {
            newId(): string;
        };
        clock: {
            nowIso(): string;
        };
        data: {
            runInTransaction<T>(fn: () => Promise<T>): Promise<T>;
        };
    }
    export interface CloseTabInput {
        tabId: string;
    }
    export interface CloseTabOutput {
        tabId: string;
        tableId: string;
        status: string;
    }
    export function closeTab(ctx: RequestContext, input: CloseTabInput): Promise<CloseTabOutput>;
}
declare module "_102021_/l2/agentChangeBackend/helpers/fixtures/n13/listOverdue" {
    /**
     * Compile fixture: a list usecase computes a time status on read and does not persist it.
     * Frontend tsc is the compile gate.
     */
    interface RequestContext {
        clock: {
            nowIso(): string;
        };
    }
    interface Tuition {
        tuitionId: string;
        dueDate: string;
        balance: number;
        status: string;
    }
    export interface ListTuitionInput {
    }
    export interface ListTuitionOutput {
        tuitions: Tuition[];
    }
    export function listTuition(ctx: RequestContext, _input: ListTuitionInput): Promise<ListTuitionOutput>;
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message, PushSubscriptionData } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getPushSubscriptionForBackend?(): Promise<PushSubscriptionData | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getPushSubscriptionForBackend: () => Promise<PushSubscriptionData>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "custom" | "default";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/notificationsRuntime" {
    import type { CollabMessagesEnvironment } from "_102036_/l2/environmentContract";
    /** Bounded poll matching the runtime shell mls-lib load window (~20s at 300ms). */
    export const MLS_LIB_RETRY_MS = 300;
    export const MLS_LIB_RETRIES = 67;
    export function hasPushSubscriptionCapability(): boolean;
    export function isNotificationPermissionDenied(): boolean;
    export const notificationsRuntime: NonNullable<CollabMessagesEnvironment["notifications"]>;
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<msg.PushSubscriptionData>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalSummary" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalizeStatus" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/agentCbRepositoryAdapter" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/pet" {
    export const petTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: {
            name: string;
            postgresType: string;
            description: string;
        }[];
        primaryKey: string[];
        indexes: {
            name: string;
            columns: string[];
            unique: boolean;
        }[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/petRepositoryAdapter" {
    export const PET_ADAPTER_DEFECT: string;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/fixtures/taskDetailsRoundTrip" {
    export const TASK_L4_FIELDS: {
        fieldId: string;
    }[];
    export const TASK_FIELD_IDS: string[];
    export interface TaskRow {
        task_id: string;
        owner_user_id: string;
        status: string;
        created_at: string;
        details: Record<string, unknown> | string | null;
    }
    export interface TaskDetails {
        title: string;
        description: string | null;
        priority: string;
        dueDate: string | null;
    }
    export interface Task {
        taskId: string;
        title: string;
        description: string | null;
        status: string;
        priority: string;
        dueDate: string | null;
        ownerUserId: string;
        createdAt: string;
    }
    /** Seed-shaped row: details written under fieldId (camelCase), the way gen-seeds emits the envelope. */
    export const TASK_SEED_ROW: TaskRow;
    export function parseDetails(row: TaskRow): TaskDetails;
    export function toDomain(row: TaskRow): Task;
    export function toRow(task: Task): TaskRow;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-domain/agentCbDomainEntity" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-http/agentCbHttpController" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-port/agentCbRepositoryPort" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/seedAssetsCore" {
    import { type SeedEntityDefinition, type SeedPlan } from "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore";
    export const SEED_ASSET_SCHEMA_VERSION = 1;
    export interface SeedAssetManifestEntry {
        id: string;
        path: string;
        publicUrl: string;
        source: 'imagem';
        promptHash: string;
        status: 'ready' | 'failed';
        warning?: string;
    }
    export interface SeedAssetManifest {
        schemaVersion: number;
        moduleId: string;
        assets: SeedAssetManifestEntry[];
    }
    export interface SeedAssetRequest {
        assetId: string;
        targetPath: string;
        path: string;
        publicUrl: string;
        alt: string;
        prompt: string;
        promptHash: string;
        format: 'webp';
        maxWidth: number;
    }
    export function emptySeedAssetManifest(moduleId: string): SeedAssetManifest;
    export function parseSeedAssetManifest(value: unknown, moduleId: string): SeedAssetManifest;
    export function putSeedAssetManifestEntry(manifest: SeedAssetManifest, entry: SeedAssetManifestEntry): SeedAssetManifest;
    export function readySeedAssetUrls(manifest: SeedAssetManifest): Record<string, string>;
    export function seedAssetWarnings(manifest: SeedAssetManifest): string[];
    export function collectSeedAssetRequests(moduleId: string, plan: SeedPlan, entities: SeedEntityDefinition[]): SeedAssetRequest[];
    export const SEED_ASSET_CAP = 8;
    export function capSeedAssetRequests(requests: readonly SeedAssetRequest[], cap?: number): {
        kept: SeedAssetRequest[];
        dropped: string[];
    };
    /** Trace line for the dropped candidates (empty when nothing was capped). */
    export function seedAssetCapWarning(dropped: readonly string[], cap?: number): string;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seed-assets/agentCbSeedAssets" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seeds/agentCbSeeds" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/agentCbPersistenceTable" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/fixtures/appointmentAvailability" {
    export const appointmentAvailabilityTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: {
            name: string;
            postgresType: string;
            description: string;
        }[];
        primaryKey: string[];
        indexes: ({
            name: string;
            columns: string[];
            unique: boolean;
        } | {
            name: string;
            columns: string[];
            unique?: undefined;
        })[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/fixtures/serviceExecution" {
    export const serviceExecutionTableDef: {
        moduleId: string;
        repositoryName: string;
        tableName: string;
        purpose: string;
        description: string;
        backupHot: boolean;
        storageProfile: string;
        writeMode: string;
        columns: ({
            name: string;
            postgresType: string;
            description: string;
            nullable?: undefined;
        } | {
            name: string;
            postgresType: string;
            nullable: boolean;
            description: string;
        })[];
        primaryKey: string[];
        indexes: {
            name: string;
            columns: string[];
        }[];
        version: number;
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-usecase/usecaseOwnerItem" {
    import type { CbScan, CbOwner, CbEntity } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    import { type CbEntityLifecycle } from "_102021_/l2/agentChangeBackend/helpers/cbLifecycle";
    export function deriveMaps(scan: CbScan): {
        roots: Set<string>;
        mdmIds: Set<string>;
        derivedIds: Set<string>;
        childToRoot: Map<string, string>;
        byId: Map<string, CbEntity>;
        eventsByOwner: Map<string, import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbEventTarget[]>;
    };
    export interface CbMdmWrite {
        entityId: string;
        mdmType: string;
        subtype: string;
        idField: string;
        baseFields: string[];
        namespaceFields: string[];
    }
    /** Transcribe l4 v7 onto `mdmWrites`: role, subtype, idField, base vs namespace partition. */
    export function mdmWriteFromL4(entity: CbEntity, owner: Pick<CbOwner, 'inputs'>): CbMdmWrite;
    /** Reject defs that drift from the current entity/port contract before materialization can turn the
     * mismatch into broken TypeScript. */
    export function validateUsecasePlan(result: any, scan: CbScan, ownerId: string): string[];
    export function buildOwnerItem(o: CbOwner, maps: ReturnType<typeof deriveMaps>, lifecycles?: readonly CbEntityLifecycle[]): {
        authorityRefs?: string[];
        scopeFilter?: {
            mode: import("_102021_/l2/agentChangeBackend/helpers/cbAccess").CbAccessScopeMode | "mixed" | "none";
            alreadyApplied: boolean;
            helperName: string;
            description: string;
            projectionRef: string;
            instruction: string;
        };
        timeStates?: {
            entityId: string;
            state: string;
            ruleRef: string;
        }[];
        lifecycle?: import("/_102021_/l2/agentChangeBackend/helpers/cbLifecycle.js").CbLifecyclePrompt;
        eventWrites: {
            entityId: string;
            owner: string;
            purpose: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").EventPurpose;
            persisted: boolean;
            port: string;
        }[];
        entityFields: {
            [k: string]: {
                enum?: any;
                fieldId: any;
                type: any;
                required: any;
            }[];
        };
        derivedRefs?: {
            derivation?: {
                from: string;
                filter: string;
                aggregate: Array<{
                    fieldId: string;
                    op: string;
                    sourceField?: string;
                }>;
            };
            entityId: string;
            description: string;
            notes: string;
        }[];
        mdm?: import("/_102021_/l2/agentChangeBackend/helpers/cbDefsSource.js").CbOwnerMdm;
        mdmWrites?: CbMdmWrite[];
        usecaseId: string;
        ownerKind: "operation" | "workflow";
        opKind: string;
        entity: string;
        parentAggregate: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbAccessPattern;
        outputShape: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbOutputShape;
        inputs: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbOperationInput[];
        contextResolution: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbContextResolution[];
        acceptanceAssertions: string[];
        ports: string[];
        mdmRefs: string[];
    };
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-usecase/agentCbUsecase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/judgeShared" {
    import { type CbScan, type CbOwner } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    import { type CbJudgeFinding } from "_102021_/l2/agentChangeBackend/helpers/cbRepair";
    /** Step args of every judge step of a run: which pass it is, its scope and (for a worker) its slice. */
    export interface CbJudgeArgs {
        judgeRun: number;
        owners: string[];
        queue: string[] | null;
        batchIndex: number;
        /** Which RUN of the task these findings belong to (see judgeFindingsFileInfo). */
        runId: string;
    }
    export function judgeArgsOf(step: mls.msg.AIAgentStep): CbJudgeArgs;
    /** Read the saved usecase defs data for the given operation owners (null when missing). */
    export function readUsecaseDefsByOwner(scan: CbScan, operations: CbOwner[]): Promise<Map<string, Record<string, unknown> | null>>;
    /** The operation owners in scope for this judge run (all on run 1; only the repaired subset after). */
    export function scopedOperations(scan: CbScan, step: mls.msg.AIAgentStep): {
        judgeRun: number;
        operations: CbOwner[];
    };
    /**
     * The slice of the module THIS step judges, and what is left for the next one.
     *
     * 119 pairs of (L4 contract + generated usecase defs) pretty-printed is megabytes: the intents POST
     * answered 413 and the step hung forever. The batch is planned from the real byte size of each pair,
     * and both hooks plan it the same way from the same step args — nothing extra has to be threaded
     * through, and the after-hook always knows exactly which owners the model just saw.
     */
    export function planJudgeSlice(step: mls.msg.AIAgentStep, operations: CbOwner[], defsByOwner: Map<string, Record<string, unknown> | null>): {
        pairsByOwner: Map<string, unknown>;
        batch: CbOwner[];
        pending: string[];
        batchIndex: number;
        totalQueued: number;
    };
    /** Deterministic pre-findings: an operation owner whose usecase .defs.ts is missing entirely, plus
     *  (T12) one whose defs omit the principal aggregate's local port — a DERIVATION gap that would
     *  otherwise only surface as broken TypeScript after 2-3 expensive materialization repairs. */
    export function missingDefsFindings(defsByOwner: Map<string, Record<string, unknown> | null>, scan: CbScan, operations: CbOwner[]): CbJudgeFinding[];
    /** The reduced L4 contract the judge compares against (authoritative side). */
    export function ownerContract(o: CbOwner): {
        ownerId: string;
        opKind: string;
        entity: string;
        actors: string[];
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbAccessPattern;
        inputs: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbOperationInput[];
        contextResolution: import("/_102021_/l2/agentChangeBackend/helpers/cbShared.js").CbContextResolution[];
        acceptanceAssertions: string[];
    };
    /**
     * Where a worker leaves what it found, so the collector can union the batches. The disk is truth: the
     * runtime discards a fan-out child's return value.
     *
     * The RUN is part of the name. The findings of a previous execution stay in `l4/trace` (they are the
     * audit of that run), and a new judge run 1 would otherwise read them as its own and route usecases to
     * repair over findings nobody made this time.
     */
    export function judgeFindingsFileInfo(runId: string, judgeRun: number, batchIndex: number): Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    /** The shortName prefix every batch file of one (run, judge pass) shares. */
    export function judgeFindingsPrefix(runId: string, judgeRun: number): string;
    export interface CbJudgeBatchFindings {
        runId: string;
        judgeRun: number;
        batchIndex: number;
        owners: string[];
        findings: CbJudgeFinding[];
        savedAt: string;
    }
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { judgeArgsOf } from "_102021_/l2/agentChangeBackend/steps/judge/judgeShared";
    export function createAgent(): IAgentAsync;
    export { judgeArgsOf };
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/judgeBatchContext" {
    export function judgeBatchContextLines(validPorts: readonly string[], mdmIds: readonly string[], derivedIds?: readonly string[]): string[];
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudgeBatch" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudgeCollect" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/materialize/agentCbMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import { type PipelineItem } from "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore";
    export function createAgent(): IAgentAsync;
    export type CbStaleVerdict = {
        stale: boolean;
        decision: 'generate' | 'skip';
        wipedThisRun: boolean;
    };
    export function entryIsStale(project: number, defRef: string, item: PipelineItem, wipedThisRunKeys?: ReadonlySet<string>): CbStaleVerdict;
}
declare module "_102021_/l2/agentChangeBackend/steps/phase/agentCbPhase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/register/agentCbRegister" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbLockOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbScanCreateOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbValidateL4Readiness" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/validate-all/agentCbValidateAll" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Core" {
    export const D1_FLOW_ID: "agentDefsL1";
    export const D1_FLOW_VERSION: "2026-09-21-d1-flow-v1";
    export const D1_PIPELINE_SCHEMA: "2026-09-21-d1-pipeline-v1";
    export const D1_AGENT_NAME: "agentDefsL1";
    export const D1_FLOW_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export type D1StepId = typeof D1_FLOW_STEP_IDS[number];
    /** Steps that have a hook in this delivery. The flow lists the rest as not implemented. */
    export const D1_IMPLEMENTED_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export const D1_STEP_TITLES: Record<D1StepId, string>;
    /** Dependencies are done-anchors. A draft path must never appear here. */
    export const D1_STEP_DEPENDS_ON: Record<D1StepId, readonly string[]>;
    export const D1_REPAIR_PER_UNIT = 1;
    export const D1_REPAIR_GLOBAL_MAX = 8;
    export const D1_FINALIZE_REPAIR = false;
    export const D1_MAX_PARALLEL = 5;
    export const D1_INTERACTION_CLEANER: "input_output";
    export const D1_CHILDREN_MAY_ADD_STEPS = false;
    export const D1_CHILDREN_MAY_CREATE_TASK = false;
    export const D1_NEVER_DISPATCH: readonly ["agentCbMaterialize", "agentChangeBackend", "agentChangeFrontend"];
    const COMMANDS: readonly ["run", "resume", "help"];
    export type D1Command = typeof COMMANDS[number];
    export const MSG_PATH = "Path must not contain '..'.";
    export const MSG_CANDIDATE_DOTDOT = "Candidate path must not contain '..'.";
    export const MSG_CANDIDATE = "Candidate runs are refused. Nothing was changed.";
    export const MSG_REBUILD = "Rebuild all is refused. Nothing was deleted.";
    export const MSG_ONE_COMMAND = "Pass one command: /run, /resume or /help.";
    export const MSG_USAGE = "Pass @@agentDefsL1 <lowerCamel> /run, /resume or /help.";
    export const MSG_MODULE = "Module name must be lowerCamel (example: stockControl).";
    export const MSG_PROJECT = "Project identity is missing.";
    export const MSG_PROJECT_MISMATCH = "Project identity does not match this task.";
    export interface D1FileInfo {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export type D1PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    export type D1StepStatus = 'running' | 'approved' | 'failed';
    export interface D1StepState {
        status: D1StepStatus;
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
    }
    export interface D1PipelineState {
        schemaVersion: typeof D1_PIPELINE_SCHEMA;
        flowId: typeof D1_FLOW_ID;
        flowVersion: typeof D1_FLOW_VERSION;
        project: number;
        moduleName: string;
        status: D1PipelineStatus;
        awaitingStep?: D1StepId;
        command: 'run' | 'resume';
        steps: Partial<Record<D1StepId, D1StepState>>;
        updatedAt: string;
    }
    export interface D1ParsedInvocation {
        module: string;
        command: D1Command | '';
        refused: string;
    }
    export function isD1StepId(value: string): value is D1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    export function repairAllowed(unitAttempts: number, globalAttempts: number): boolean;
    /** A successor is unlocked only by its done-anchors, never by a draft path. */
    export function successorUnlocked(dependsOn: readonly string[], approvedAnchors: ReadonlySet<string>): boolean;
    export function doneAnchorId(stepId: D1StepId): string;
    export function dynamicPlanId(stepId: D1StepId, kind: 'fanout' | 'worker' | 'repair' | 'barrier', token: string): string;
    /** A parallel child has no planning. Its prompt carries the planId. */
    export function planIdFromPrompt(prompt: string): string;
    /**
     * Maps a child planId back to its step. Done-anchors stay unmatched so they are
     * not dispatched as the step they close.
     */
    export function ownerStepId(planId: string): D1StepId | '';
    export function isDoneAnchor(planId: string): boolean;
    export function assertShortName(shortName: string): void;
    /** Project is part of the path so two modules with the same name do not share a file. */
    export function displayPath(file: D1FileInfo): string;
    /** `l1/<module>/pipeline/agentDefsL1/input.json` — the input20 receipt. */
    export function inputFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/drafts/<step>.json`. A draft does not approve the step. */
    export function draftFile(project: number, moduleName: string, step: D1StepId): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/report.json` — the finalize80 receipt. */
    export function reportFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/pipeline.json` in one project. */
    export function pipelineFile(project: number, moduleName: string): D1FileInfo;
    /** Planner checkpoint. This agent never writes or removes it. */
    export function plannerPipelineFile(project: number, moduleName: string): D1FileInfo;
    export function ownedFolder(moduleName: string): string;
    export function requireProject(value: unknown): number | {
        refusal: string;
    };
    export function parseD1Invocation(value: string): D1ParsedInvocation;
    export function helpText(moduleName: string, project: number): string;
    export function notImplementedTrace(stepId: D1StepId): string;
    export function stoppedTrace(stepId: D1StepId): string;
    export function resumeMissing(moduleName: string, project: number): string;
    export function checkpointConflict(moduleName: string, project: number): string;
    export function checkpointNotIntact(moduleName: string, project: number): string;
    export function unknownPromptField(field: string): string;
    export function unknownPlanId(planId: string): string;
    export interface D1StepPrompt {
        planId: D1StepId;
        moduleName: string;
        project: number;
        command: 'run' | 'resume';
    }
    export type D1ParsedStepPrompt = {
        kind: 'step';
        prompt: D1StepPrompt;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseD1StepPrompt(prompt: string): D1ParsedStepPrompt;
    export function createEntryPipeline(project: number, moduleName: string, now: Date): D1PipelineState;
    export function isIntactCheckpoint(state: D1PipelineState, project: number, moduleName: string): boolean;
    /**
     * Records the first missing step. Does not move the marker forward, does not
     * rewrite an approved step, and does not treat a later callback as progress.
     */
    export function withAwaiting(pipeline: D1PipelineState, stepId: D1StepId, now: string): {
        pipeline: D1PipelineState;
        changed: boolean;
    };
    export function createD1AgentStep(stepId: D1StepId, moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep;
    export function buildD1PlannedSteps(moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep[];
    export function taskProject(context: mls.msg.ExecutionContext): number | null;
    export function taskModule(context: mls.msg.ExecutionContext): string;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Schema" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /** Keys locked to schemas/pipeline-v1.schema.json by the flow contract test. */
    export const PIPELINE_KEYS: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "awaitingStep", "command", "steps", "updatedAt"];
    export const PIPELINE_REQUIRED: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "command", "steps", "updatedAt"];
    export const STEP_STATE_KEYS: readonly ["status", "updatedAt", "artifactPaths", "error"];
    export const PIPELINE_STATUS: readonly ["inProgress", "awaitingStep", "complete", "failed"];
    export const STEP_STATUS: readonly ["running", "approved", "failed"];
    /** Structural gate for the pipeline document. Extra keys are refused, not dropped. */
    export function pipelineIssues(value: unknown): string[];
    export function parsePipelineDocument(raw: string): D1PipelineState | null;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Stor" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export interface D1HostView {
        /** Null when this host has no diskPath (Studio). Absence is a state, not an error. */
        diskPath: string | null;
        /** Short names from host listFolder. Null when the host has no listFolder. */
        listed: readonly string[] | null;
    }
    /**
     * Host disk path. Called as a method on `mls.stor` so a private field on the
     * host object stays bound. A missing method is Studio, not a failure.
     */
    export function hostDiskPath(file: D1FileInfo): string | null;
    export function hostView(file: D1FileInfo): D1HostView;
    export function readText(file: D1FileInfo): Promise<string | null>;
    export function writeText(file: D1FileInfo, content: string): Promise<void>;
    export function readJson<T>(file: D1FileInfo): Promise<T | null>;
    /** Writes JSON and returns the exact bytes stored. */
    export function writeJson(file: D1FileInfo, value: unknown): Promise<string>;
    /**
     * Removes one file this agent owns. The file identity is the same object a
     * write would use. The planner pipeline and every other folder are refused.
     */
    export function removeOwned(file: D1FileInfo): Promise<void>;
    /**
     * Removes one own product def. A directory is not a file, a `.ts` output is
     * not a def, and this is not `/rebuild all`.
     */
    export function removeDefFile(file: D1FileInfo): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type D1PipelineState, type D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type D1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type D1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface D1StepHooks {
        beforePromptStep?: D1StepBeforePrompt;
        afterPromptStep?: D1StepAfterPrompt;
    }
    /** Filled by the step module as a side effect. A missing entry is not implemented. */
    export const D1_STEP_HOOKS: Partial<Record<D1StepId, D1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string): D1StepHooks | undefined;
    /**
     * Persists awaitingStep when the marker actually moves. An approved entry10
     * is left untouched. A repeated call does not write.
     */
    export function markAwaitingStep(pipeline: D1PipelineState, stepId: D1StepId, now?: string): Promise<boolean>;
    export function d1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string, memory: Record<string, string>): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/gate" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type EntryDecision = {
        kind: 'record';
        state: D1PipelineState;
    } | {
        kind: 'keep';
    } | {
        kind: 'refusal';
        refusal: string;
    };
    /**
     * Pure entry decision. `keep` writes nothing. A draft on disk is not an input
     * and cannot turn a later step into an approved one.
     */
    export function decideEntry(command: 'run' | 'resume', project: number, moduleName: string, raw: string | null, now: Date): EntryDecision;
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst" {
    export interface D1ContractField {
        name: string;
        type: string;
        optional: boolean;
    }
    export interface D1ContractSymbol {
        name: string;
        fields: D1ContractField[];
        /** `array` when the exported type is an array. The element fields stay the contracted item. */
        shape: 'object' | 'array';
        /** Element symbol when an array alias points at another type. Empty when the fields are inline. */
        element: string;
    }
    /** A route string bound to symbols in this file. The symbol name is not an identity. */
    export interface D1RouteBinding {
        route: string;
        input: string;
        output: string;
    }
    export interface D1ContractAst {
        bindings: D1RouteBinding[];
        symbols: D1ContractSymbol[];
        /** Routes whose binding is a type assertion instead of an input/output symbol. */
        assertions: string[];
        /**
         * Exported declarations this reader could see but not close.
         * Callers surface each entry as `CONTRACT_UNPARSED`. Empty on a file this reader finished.
         */
        unparsed: string[];
    }
    /**
     * Reads exported `routes` bindings, exported `*Route` consts, and type shapes.
     * A `*Route` const whose value is the route string binds `StemInput`/`StemOutput`.
     * The first interface, and a name that matches the usecase, are not an identity.
     * Deno loads this file with the agent. It must not import `typescript`.
     */
    export function readContractAst(source: string, fileName: string): D1ContractAst;
    /** The unique symbol of this name, or null when it is missing or duplicated. */
    export function symbolFields(ast: D1ContractAst, name: string): D1ContractField[] | null;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/contracts" {
    import type { D1ContractAst } from "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst";
    export const D1_INPUT_VERSION: "2026-09-21-d1-input-v1";
    export const D1_SOURCE_SCHEMAS: {
        readonly module: "2026-09-10-ns5-module-v2";
        readonly journey: "2026-09-10-ns5-journey-v1";
        readonly ontology: "2026-09-17-ns5-ontology-v3.1";
        readonly rules: "2026-09-16-ns5-rules-v2";
        readonly workflows: "2026-09-17-ns5-workflows-v3";
        readonly access: "2026-09-12-ns5-access-v3";
        readonly integration: "2026-09-12-ns5-integration-v2";
        readonly menu: "2026-09-20-p2-menu-v2.2";
        readonly needs: "2026-09-21-p2-needs-v1";
        readonly backend: "2026-09-21-p1-backend-v1.1";
        readonly effort: "2026-09-21-p2-effort-v1.1";
        readonly planner: "2026-09-20-p1-pipeline-v1";
    };
    export const D1_PLANNER_FLOW: "agentPlannerL1";
    export const D1_EFFORT_BACKEND_REF: "pool/l2/web/backend.json";
    export const D1_ACTIVE_STATUSES: readonly ["toCreate", "toUpdate", "done"];
    export type D1ActiveStatus = typeof D1_ACTIVE_STATUSES[number];
    export type D1PlanStatus = D1ActiveStatus | 'toRemove';
    export type D1FileAction = 'create' | 'update' | 'preserve' | 'recompose' | 'remove' | 'conflict';
    export type D1ProblemSeverity = 'error' | 'review';
    export interface D1InputProblem {
        severity: D1ProblemSeverity;
        code: string;
        path: string;
        message: string;
        ownerRef?: string;
    }
    export interface D1SourceDigest {
        path: string;
        sha256: string;
        bytes: number;
        schemaVersion: string;
        state: 'present' | 'missing' | 'invalid';
    }
    export interface D1PresentDef {
        path: string;
        sha256: string;
    }
    export interface D1InputArtifacts {
        sources: D1SourceDigest[];
        module: unknown;
        journeyIndex: unknown;
        journeys: Record<string, unknown>;
        ontologyIndex: unknown;
        entities: Record<string, unknown>;
        rules: unknown;
        workflows: unknown;
        access: unknown;
        integration: unknown;
        menu: unknown;
        needs: unknown;
        backend: unknown;
        effort: unknown;
        planner: unknown;
        /** Page id → contract AST. Null means the file was looked up and is absent. */
        contracts: Record<string, D1ContractAst | null>;
        presentDefs: D1PresentDef[];
        /**
         * Done write rows from the progress file of the step that wrote the def.
         * Not copied into the snapshot. Absent means this caller did not load them.
         */
        writerReceipts?: ReadonlyArray<{
            defPath: string;
            desiredHash: string;
        }>;
    }
    export interface D1PlannerRun {
        flowId: string;
        thread: string;
        round: number;
        schemaVersion: string;
    }
    export interface D1SelectedRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
        status: D1ActiveStatus;
    }
    export interface D1SelectedUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        status: D1ActiveStatus;
        existing: string;
        identity: string;
        routes: string[];
    }
    export interface D1SelectedPort {
        portId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1SelectedTable {
        tableId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        action: D1FileAction;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
        /** Present only when this receipt inventoried the bytes at defPath. */
        contentHash?: string;
    }
    export interface D1RemovedItem {
        kind: string;
        id: string;
        defPath: string | null;
        inventoried: boolean;
        contentHash?: string;
    }
    export interface D1InputSnapshot {
        schemaVersion: typeof D1_INPUT_VERSION;
        project: number;
        moduleName: string;
        device: 'web';
        plannerRun: D1PlannerRun | null;
        sources: D1SourceDigest[];
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            routes: D1SelectedRoute[];
            usecases: D1SelectedUsecase[];
            ports: D1SelectedPort[];
            tables: D1SelectedTable[];
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
        removed: D1RemovedItem[];
        problems: D1InputProblem[];
        consumersReleased: boolean;
        snapshotHash: string;
    }
    export function inputPaths(moduleName: string): {
        module: string;
        journeyIndex: string;
        ontologyIndex: string;
        rules: string;
        workflows: string;
        access: string;
        integration: string;
        menu: string;
        needs: string;
        backend: string;
        effort: string;
        planner: string;
    };
    export function journeyPath(moduleName: string, journeyId: string): string;
    export function entityPath(moduleName: string, entityId: string): string;
    export function contractPath(moduleName: string, pageId: string): string;
    export function isSafeToken(value: string): boolean;
    export function lowerFirst(value: string): string;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Artifact" {
    export const D1_DEFINITION_SCHEMA: "2026-09-21-d1-definition-v1";
    /**
     * Measured on RequestContext.data.pgQueue. RequestContext itself has no publishEvent or emitEvent.
     * Postgres publish inserts into the MDM outbox. It is not a module bus.
     * An event keeps this symbol only when the artifact already names it.
     */
    export const D1_MEASURED_PUBLISH: {
        readonly symbol: "IQueueRuntime.publish";
        readonly path: "mls-102034/l1/server/layer_1_external/data/runtime.ts";
        readonly owner: "RequestContext.data.pgQueue";
        readonly payload: "{ topic: string; payload: unknown }";
        readonly delivery: "Postgres insert into mdm_outbox. Memory keeps an array. No module consumer is registered.";
        readonly transaction: "Postgres publish uses the transaction executor. Memory runInTransaction does not roll back.";
    };
    /** Names that are not methods of RequestContext. Writing them would invent an API. */
    export function fictionalMechanism(value: string): boolean;
    export const D1_CATALOG_SCHEMA: "2026-09-21-d1-catalog-v1";
    /** Closed set. Auxiliary names are not dispatched by agentChangeBackend. */
    export const D1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export type D1ArtifactType = typeof D1_ARTIFACT_TYPES[number];
    /** Types readL1Inventory already filters on. */
    export const D1_INVENTORY_TYPES: readonly ["usecase", "repositoryPort", "table", "httpController"];
    /** Design forecast parts. Not a count of files this agent writes. */
    export const D1_CORE_TYPES: readonly ["domainEntity", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController"];
    export const D1_AUXILIARY_TYPES: readonly ["valueObject", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export const D1_FORECAST_CORE: {
        readonly count: 26;
        readonly parts: {
            readonly domainEntity: 5;
            readonly repositoryPort: 1;
            readonly table: 1;
            readonly repositoryAdapter: 1;
            readonly usecase: 13;
            readonly httpController: 5;
        };
        readonly note: "Design forecast: 5 models, 1 port, 1 table, 1 adapter, 13 usecases and 5 controllers. It is not a count of files this agent generated.";
    };
    export const D1_STORAGE_TARGETS: readonly ["moduleDatabase", "mdm", "external", "derived"];
    export type D1StorageTarget = typeof D1_STORAGE_TARGETS[number];
    export interface D1Field {
        name: string;
        type: string;
        derived?: boolean;
        ref?: string;
    }
    export interface D1LifecycleState {
        state: string;
        reachedBy: 'actor' | 'command' | 'time';
    }
    export interface D1Transition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
    }
    export interface D1DomainEntityData {
        entityId: string;
        storageTarget: D1StorageTarget;
        fields: D1Field[];
        lifecycle: {
            states: D1LifecycleState[];
            transitions: D1Transition[];
        };
        invariants: string[];
        imports: string[];
    }
    export interface D1ValueObjectData {
        valueObjectId: string;
        fields: D1Field[];
        referencedBy: string[];
    }
    export interface D1PortMethod {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1RepositoryPortData {
        entityId: string;
        interfaceName: string;
        methods: D1PortMethod[];
    }
    export interface D1TableData {
        tableId: string;
        entityId: string;
        physicalName: string;
        primaryKey: string[];
        uniqueKeys: string[][];
        indexes: Array<{
            name: string;
            columns: string[];
            unique: boolean;
        }>;
    }
    export interface D1RepositoryAdapterData {
        entityId: string;
        portId: string;
        tableId: string;
        columns: Array<{
            field: string;
            column: string;
        }>;
    }
    export interface D1ProjectionField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface D1UsecaseData {
        usecaseId: string;
        entityId: string;
        operation: string;
        ports: string[];
        rulesApplied: string[];
        functions: Array<{
            functionName: string;
            input: D1ProjectionField[];
            output: D1ProjectionField[];
            contractRefs: Array<{
                route: string;
                symbol: string;
            }>;
        }>;
        routeProjections: Array<{
            route: string;
            contractPath: string;
            projection: 'declared' | 'unresolved';
            outputFields: string[];
        }>;
        portCalls: string[];
        transactional: boolean;
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        sequence: Array<Record<string, unknown>>;
        uses: Array<{
            path: string;
            role: 'filter' | 'selector' | 'concurrency' | 'write';
            source: 'input' | 'payload';
        }>;
        rules: Array<{
            ruleId: string;
            path: string;
            symbol: string;
        }>;
        transaction: {
            boundary: 'local' | 'none';
        };
        lifecycle?: {
            transitionId: string;
            payload: string[];
            sourcePath: string;
            symbol: string;
        };
        mdm?: {
            namespace: string;
            role: string;
            atomic: boolean;
            calls: Array<Record<string, unknown>>;
        };
    }
    export interface D1HttpControllerData {
        pageId: string;
        handlers: Array<{
            route: string;
            kind: 'query' | 'command';
            usecaseId: string;
            grantIds: string[];
        }>;
    }
    export interface D1Grant {
        grantId: string;
        actorRef: string;
        anchorEntity?: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields?: string[];
    }
    export interface D1AccessScopeData {
        scopeId: string;
        grants: D1Grant[];
    }
    export interface D1AuthorityMapData {
        mapId: string;
        entries: Array<{
            grantId: string;
            actorRef: string;
        }>;
    }
    export interface D1RegistrationData {
        registrationId: string;
        adapters: Array<{
            portId: string;
            adapterArtifactId: string;
        }>;
    }
    export interface D1SeedRefData {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDependencyData {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedDatasetData {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    /** A plan for the later materializer. `phase` is `plan`. This artifact has no rows. */
    export interface D1SeedsData {
        seedId: string;
        phase?: 'plan';
        scenarios: Array<{
            scenarioId: string;
            tableId: string;
            source?: string;
            constraints: string[];
            refs?: D1SeedRefData[];
            states?: string[];
            requires?: string[];
        }>;
        dependencies?: D1SeedDependencyData[];
        datasets?: D1SeedDatasetData[];
    }
    export interface D1IntegrationData {
        integrationId: string;
        events: Array<{
            eventId: string;
            on: string;
            entityId: string;
            mechanism: string;
        }>;
    }
    export interface D1Definition<T = Record<string, unknown>> {
        schemaVersion: typeof D1_DEFINITION_SCHEMA;
        artifactType: D1ArtifactType;
        artifactId: string;
        moduleName: string;
        data: T;
    }
    export function isArtifactType(value: string): value is D1ArtifactType;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    /** Copies the shared $defs onto one artifact payload so a tool wrapper can hoist them. */
    export function typeDataSchema(definitionSchema: Record<string, unknown>, typeName: string): Record<string, unknown>;
    export function definitionIssues(value: unknown): string[];
    export function recordFieldIssues(data: unknown): string[];
    export function derivedFieldIssues(entity: unknown, usecases: readonly unknown[]): string[];
    export function storageTargetIssues(data: unknown): string[];
    export function lifecycleIssues(data: unknown): string[];
    export function domainImportIssues(moduleName: string, imports: readonly string[], source?: string): string[];
    export function domainEntityIssues(data: unknown): string[];
    export function valueObjectIssues(data: unknown): string[];
    export function repositoryPortIssues(data: unknown): string[];
    export function tableIssues(data: unknown): string[];
    /**
     * readL1Inventory uses artifactId as the table entity and data.tableId as the logical id.
     * data.entityId must equal artifactId so the two do not diverge.
     */
    export function tableIdentityIssues(data: unknown, artifactId: string): string[];
    export function adapterBindingIssues(data: unknown): string[];
    export function adapterLinkIssues(adapter: unknown, port: unknown, table: unknown): string[];
    export function projectionIssues(data: unknown): string[];
    export function routeProjectionIssues(data: unknown): string[];
    export function usecaseIssues(data: unknown): string[];
    export function httpControllerIssues(data: unknown): string[];
    export function accessAnchorIssues(data: unknown): string[];
    export function accessScopeIssues(data: unknown): string[];
    export function authorityMapIssues(data: unknown): string[];
    export function authorityGrantIssues(map: unknown, scope: unknown): string[];
    export function registrationIssues(data: unknown): string[];
    export function seedScenarioIssues(data: unknown): string[];
    /** Processes, inbound and plugins stay operations. A gap is a declared item the pool did not select. */
    export function integrationCoverageIssues(data: unknown): string[];
    /** Empty mechanism is reported and the event is left in place. */
    export function integrationMechanismIssues(data: unknown): string[];
    /** Domain imports are checked with the definition's module, not an empty string. */
    export function definitionImportIssues(value: unknown, source?: string): string[];
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Refs" {
    import { D1_CATALOG_SCHEMA, D1_FORECAST_CORE, type D1ArtifactType, type D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    export const D1_OUTPUT_AVAILABILITY: readonly ["future", "present"];
    export type D1OutputAvailability = typeof D1_OUTPUT_AVAILABILITY[number];
    export interface D1PipelineItem {
        id: string;
        type: D1ArtifactType;
        defPath: string;
        outputPath: string;
        outputAvailability: D1OutputAvailability;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        routes?: string[];
    }
    export interface D1Justification {
        id: string;
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Absence {
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Catalog {
        schemaVersion: typeof D1_CATALOG_SCHEMA;
        project: number;
        moduleName: string;
        items: D1PipelineItem[];
        presentPaths: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
    }
    export interface D1PlanRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
    }
    export interface D1MeasuredPlan {
        project: number;
        moduleName: string;
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            routes: D1PlanRoute[];
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                routes: string[];
            }>;
            ports: Array<{
                portId: string;
                entity: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
            }>;
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
    }
    export interface D1RefFinding {
        path: string;
        kind: 'presentDef' | 'plannedDef' | 'futureOutput' | 'missingInput' | 'uncontractedDeclaration';
        producerId?: string;
    }
    export interface D1Coverage {
        measured: Record<string, number>;
        measuredCore: number;
        forecastCore: typeof D1_FORECAST_CORE.count;
        forecastNote: typeof D1_FORECAST_CORE.note;
        forecastMatchesMeasured: boolean;
        auxiliaries: D1Justification[];
        absences: D1Absence[];
        futureOutputs: string[];
        missingInputs: string[];
        gaps: string[];
    }
    export function pipelineId(project: number, moduleName: string, type: string, owner: string): string;
    export function qualifyDefPath(project: number, logicalPath: string): string;
    export function futureOutputPath(defPath: string): string;
    export function skillPaths(type: string): string[];
    export function catalogFromPlan(plan: D1MeasuredPlan, input: {
        presentPaths?: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
        skillsFor?: (type: string) => string[];
    }): D1Catalog;
    export function pipelineItemIssues(value: unknown, project?: number, moduleName?: string): string[];
    export function skillRefIssues(items: readonly {
        skills?: unknown;
    }[], knownSkills: readonly string[]): string[];
    export function duplicateRouteIssues(items: readonly {
        id: string;
        routes?: string[];
    }[]): string[];
    export function catalogIssues(value: unknown, knownSkills?: readonly string[]): string[];
    export function graphIssues(items: readonly D1PipelineItem[]): string[];
    export function cycleIssues(items: readonly {
        id: string;
        dependsOn: string[];
    }[]): string[];
    export function resolveCatalogRefs(catalog: D1Catalog): D1RefFinding[];
    export function coverageReport(catalog: D1Catalog, plan: D1MeasuredPlan, storageByEntity: Readonly<Record<string, D1StorageTarget>>): D1Coverage;
    export function effectCoverageIssues(usecases: readonly {
        effects?: Array<{
            eventId: string;
        }>;
    }[], events: readonly string[]): string[];
    export function integrationLinkIssues(events: readonly {
        eventId: string;
        on: string;
        consumer?: string;
    }[], usecaseIds: readonly string[]): string[];
    /**
     * Schema property path → the function that reads it.
     * A new field without an entry here has no reader and must not be added.
     */
    export const D1_FIELD_READERS: {
        readonly 'definition.schemaVersion': "definitionIssues";
        readonly 'definition.artifactType': "definitionIssues";
        readonly 'definition.artifactId': "definitionIssues";
        readonly 'definition.moduleName': "definitionIssues";
        readonly 'definition.data': "definitionIssues";
        readonly 'domainEntity.entityId': "domainEntityIssues";
        readonly 'domainEntity.storageTarget': "storageTargetIssues";
        readonly 'domainEntity.fields': "domainEntityIssues";
        readonly 'domainEntity.fields.name': "domainEntityIssues";
        readonly 'domainEntity.fields.type': "domainEntityIssues";
        readonly 'domainEntity.fields.derived': "derivedFieldIssues";
        readonly 'domainEntity.fields.ref': "recordFieldIssues";
        readonly 'domainEntity.lifecycle': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.state': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.reachedBy': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.transitionId': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.from': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.to': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.by': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.ruleRefs': "lifecycleIssues";
        readonly 'domainEntity.invariants': "domainEntityIssues";
        readonly 'domainEntity.imports': "domainImportIssues";
        readonly 'valueObject.valueObjectId': "valueObjectIssues";
        readonly 'valueObject.fields': "valueObjectIssues";
        readonly 'valueObject.fields.name': "valueObjectIssues";
        readonly 'valueObject.fields.type': "valueObjectIssues";
        readonly 'valueObject.fields.derived': "derivedFieldIssues";
        readonly 'valueObject.fields.ref': "recordFieldIssues";
        readonly 'valueObject.referencedBy': "valueObjectIssues";
        readonly 'repositoryPort.entityId': "repositoryPortIssues";
        readonly 'repositoryPort.interfaceName': "repositoryPortIssues";
        readonly 'repositoryPort.methods': "repositoryPortIssues";
        readonly 'repositoryPort.methods.name': "repositoryPortIssues";
        readonly 'repositoryPort.methods.params': "repositoryPortIssues";
        readonly 'repositoryPort.methods.returns': "repositoryPortIssues";
        readonly 'table.tableId': "tableIssues";
        readonly 'table.entityId': "tableIdentityIssues";
        readonly 'table.physicalName': "tableIssues";
        readonly 'table.primaryKey': "tableIssues";
        readonly 'table.uniqueKeys': "tableIssues";
        readonly 'table.indexes': "tableIssues";
        readonly 'table.indexes.name': "tableIssues";
        readonly 'table.indexes.columns': "tableIssues";
        readonly 'table.indexes.unique': "tableIssues";
        readonly 'repositoryAdapter.entityId': "adapterBindingIssues";
        readonly 'repositoryAdapter.portId': "adapterLinkIssues";
        readonly 'repositoryAdapter.tableId': "adapterLinkIssues";
        readonly 'repositoryAdapter.columns': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.field': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.column': "adapterBindingIssues";
        readonly 'usecase.usecaseId': "usecaseIssues";
        readonly 'usecase.entityId': "usecaseIssues";
        readonly 'usecase.operation': "usecaseIssues";
        readonly 'usecase.ports': "usecaseIssues";
        readonly 'usecase.rulesApplied': "usecaseIssues";
        readonly 'usecase.functions': "usecaseIssues";
        readonly 'usecase.functions.functionName': "usecaseIssues";
        readonly 'usecase.functions.input': "projectionIssues";
        readonly 'usecase.functions.input.name': "projectionIssues";
        readonly 'usecase.functions.input.type': "projectionIssues";
        readonly 'usecase.functions.input.fieldRef': "projectionIssues";
        readonly 'usecase.functions.output': "projectionIssues";
        readonly 'usecase.functions.output.name': "projectionIssues";
        readonly 'usecase.functions.output.type': "projectionIssues";
        readonly 'usecase.functions.output.fieldRef': "projectionIssues";
        readonly 'usecase.functions.contractRefs': "routeProjectionIssues";
        readonly 'usecase.functions.contractRefs.route': "routeProjectionIssues";
        readonly 'usecase.functions.contractRefs.symbol': "routeProjectionIssues";
        readonly 'usecase.routeProjections': "routeProjectionIssues";
        readonly 'usecase.routeProjections.route': "routeProjectionIssues";
        readonly 'usecase.routeProjections.contractPath': "routeProjectionIssues";
        readonly 'usecase.routeProjections.projection': "routeProjectionIssues";
        readonly 'usecase.routeProjections.outputFields': "routeProjectionIssues";
        readonly 'usecase.portCalls': "usecaseIssues";
        readonly 'usecase.transactional': "usecaseIssues";
        readonly 'usecase.effects': "usecaseIssues";
        readonly 'usecase.effects.eventId': "effectCoverageIssues";
        readonly 'usecase.effects.path': "readUsecaseFidelity";
        readonly 'usecase.effects.symbol': "readUsecaseFidelity";
        readonly 'usecase.sequence': "readUsecaseFidelity";
        readonly 'usecase.sequence.kind': "readUsecaseFidelity";
        readonly 'usecase.sequence.call': "readUsecaseFidelity";
        readonly 'usecase.sequence.port': "readUsecaseFidelity";
        readonly 'usecase.sequence.ruleId': "readUsecaseFidelity";
        readonly 'usecase.sequence.namespace': "readUsecaseFidelity";
        readonly 'usecase.sequence.entity': "readUsecaseFidelity";
        readonly 'usecase.sequence.capability': "readUsecaseFidelity";
        readonly 'usecase.sequence.transitionId': "readUsecaseFidelity";
        readonly 'usecase.sequence.payload': "readUsecaseFidelity";
        readonly 'usecase.sequence.eventId': "readUsecaseFidelity";
        readonly 'usecase.sequence.boundary': "readUsecaseFidelity";
        readonly 'usecase.sequence.source': "readUsecaseFidelity";
        readonly 'usecase.uses': "readUsecaseFidelity";
        readonly 'usecase.uses.path': "readUsecaseFidelity";
        readonly 'usecase.uses.role': "readUsecaseFidelity";
        readonly 'usecase.uses.source': "readUsecaseFidelity";
        readonly 'usecase.rules': "readUsecaseFidelity";
        readonly 'usecase.rules.ruleId': "readUsecaseFidelity";
        readonly 'usecase.rules.path': "readUsecaseFidelity";
        readonly 'usecase.rules.symbol': "readUsecaseFidelity";
        readonly 'usecase.transaction': "readUsecaseFidelity";
        readonly 'usecase.transaction.boundary': "readUsecaseFidelity";
        readonly 'usecase.lifecycle': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.transitionId': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.payload': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.sourcePath': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.symbol': "readUsecaseFidelity";
        readonly 'usecase.mdm': "readUsecaseFidelity";
        readonly 'usecase.mdm.namespace': "readUsecaseFidelity";
        readonly 'usecase.mdm.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.atomic': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.method': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.target': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.shape': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.capabilities': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.alternative': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.name': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.capability': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.value': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.result': "readUsecaseFidelity";
        readonly 'httpController.pageId': "httpControllerIssues";
        readonly 'httpController.handlers': "httpControllerIssues";
        readonly 'httpController.handlers.route': "httpControllerIssues";
        readonly 'httpController.handlers.kind': "httpControllerIssues";
        readonly 'httpController.handlers.usecaseId': "httpControllerIssues";
        readonly 'httpController.handlers.grantIds': "httpControllerIssues";
        readonly 'accessScope.scopeId': "accessScopeIssues";
        readonly 'accessScope.grants': "accessScopeIssues";
        readonly 'accessScope.grants.grantId': "accessScopeIssues";
        readonly 'accessScope.grants.actorRef': "accessScopeIssues";
        readonly 'accessScope.grants.anchorEntity': "accessAnchorIssues";
        readonly 'accessScope.grants.entityRefs': "accessAnchorIssues";
        readonly 'accessScope.grants.disclosure': "accessScopeIssues";
        readonly 'accessScope.grants.allowedFields': "accessScopeIssues";
        readonly 'authorityMap.mapId': "authorityMapIssues";
        readonly 'authorityMap.entries': "authorityMapIssues";
        readonly 'authorityMap.entries.grantId': "authorityGrantIssues";
        readonly 'authorityMap.entries.actorRef': "authorityMapIssues";
        readonly 'repositoryRegistration.registrationId': "registrationIssues";
        readonly 'repositoryRegistration.adapters': "registrationIssues";
        readonly 'repositoryRegistration.adapters.portId': "registrationIssues";
        readonly 'repositoryRegistration.adapters.adapterArtifactId': "registrationIssues";
        readonly 'persistenceSeeds.seedId': "seedScenarioIssues";
        readonly 'persistenceSeeds.phase': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.scenarioId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.source': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.constraints': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.field': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.relationshipId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.states': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.requires': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.kind': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.seeded': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.datasetId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.owners': "seedScenarioIssues";
        readonly 'integrationOutbound.integrationId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.eventId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.on': "integrationLinkIssues";
        readonly 'integrationOutbound.events.entityId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.mechanism': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.consumer': "integrationLinkIssues";
        readonly 'integrationOutbound.events.mechanismRef': "integrationMechanismIssues";
        readonly 'integrationOutbound.processes': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.processId': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.inboundId': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.pluginId': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.itemId': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.kind': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.code': "integrationCoverageIssues";
        readonly 'pipelineItem.id': "pipelineItemIssues";
        readonly 'pipelineItem.type': "pipelineItemIssues";
        readonly 'pipelineItem.defPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputAvailability': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsFiles': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsOn': "catalogIssues";
        readonly 'pipelineItem.skills': "skillRefIssues";
        readonly 'pipelineItem.routes': "duplicateRouteIssues";
        readonly 'catalog.schemaVersion': "coverageReport";
        readonly 'catalog.project': "coverageReport";
        readonly 'catalog.moduleName': "coverageReport";
        readonly 'catalog.items': "coverageReport";
        readonly 'catalog.presentPaths': "resolveCatalogRefs";
        readonly 'catalog.justifications': "coverageReport";
        readonly 'catalog.justifications.id': "coverageReport";
        readonly 'catalog.justifications.artifactType': "coverageReport";
        readonly 'catalog.justifications.reason': "coverageReport";
        readonly 'catalog.absences': "coverageReport";
        readonly 'catalog.absences.artifactType': "coverageReport";
        readonly 'catalog.absences.reason': "coverageReport";
    };
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Write" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export interface D1Rendered {
        source: string;
        file: D1FileInfo;
    }
    /**
     * The file identity of a def. Qualified `_project_/l1/...` and logical `l1/...`
     * both go through fileInfoFromDisplay, which is the same parser input20 uses.
     */
    export function artifactFile(project: number, defPath: string): D1FileInfo | null;
    /** JSON slice between a marker and ` as const`. This does not evaluate the source. */
    export function parseRendered(source: string): {
        definition: unknown;
        pipeline: unknown;
    } | null;
    export function renderIssues(definition: unknown, pipeline: unknown, project: number): string[];
    /**
     * Renders one defs file. Issues are returned with the value intact: nothing is stripped.
     * Persistence is separate and refuses the same issues.
     */
    export function renderDefinition(definition: D1Definition, pipeline: D1PipelineItem[]): {
        source: string;
    } | {
        issues: string[];
    };
    export function collisionIssues(defPaths: readonly string[]): string[];
    /**
     * Gate then write. A collision or a definition issue writes nothing.
     * The file passed to writeText is artifactFile, the same identity a later remove must use.
     */
    export function persistDefinitions(project: number, parts: readonly {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }[]): Promise<{
        written: D1FileInfo[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Receipt" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export const D1_PROGRESS_SCHEMA: "2026-09-22-d1-progress-v1";
    export interface D1WriterReceipt {
        defPath: string;
        desiredHash: string;
    }
    export interface D1UnitPart {
        defPath: string;
        source: string;
        action?: 'write' | 'remove';
        /** Inventoried hash. Empty when this file has no receipt. */
        receiptHash?: string;
        outputTs?: readonly string[];
    }
    export interface D1FileProgress {
        defPath: string;
        action: 'write' | 'remove';
        previousHash: string;
        desiredHash: string;
        status: 'pending' | 'done' | 'conflict';
        outputTs: string[];
    }
    /**
     * Recovery record for one unit. `transaction` is false because stor has no
     * multi-file transaction and no compare-and-swap. mtime is not a version.
     */
    export interface D1UnitProgress {
        schemaVersion: typeof D1_PROGRESS_SCHEMA;
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        runId: string;
        snapshotHash: string;
        draftHash: string;
        transaction: false;
        finalized: boolean;
        invalidated: boolean;
        reported: string[];
        files: D1FileProgress[];
        issues: string[];
    }
    export interface D1CommitUnitInput {
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        draftText: string;
        parts: readonly D1UnitPart[];
        runId?: string;
        snapshotHash?: string;
        /** Test seam. Throws after this many product mutations. */
        failAfterMutations?: number;
        /** Test seam. Runs immediately before the hash is read again. */
        beforeMutate?: (index: number) => Promise<void>;
    }
    export interface D1CommitUnitResult {
        written: string[];
        removed: string[];
        reported: string[];
        issues: string[];
        finalized: boolean;
        invalidated: boolean;
    }
    export interface D1FingerprintEntry {
        key: string;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        hidden: boolean;
        sha256: string;
        mtime: string;
        status: string;
    }
    export function progressFile(project: number, moduleName: string, step: string, unitId: string): D1FileInfo;
    export function logicalDefPath(defPath: string): string;
    /**
     * True only when every product file of this unit still matches the progress
     * hashes. A checkpoint status of completed is not read and is not proof.
     */
    export function unitIsIntact(project: number, moduleName: string, step: string, unitId: string, snapshotHash: string): Promise<boolean>;
    export function commitD1Unit(input: D1CommitUnitInput): Promise<D1CommitUnitResult>;
    /** Every file in this project, including hidden names. mtime is recorded, not trusted. */
    export function fingerprintProject(project: number): Promise<D1FingerprintEntry[]>;
    /**
     * Paths whose bytes, mtime or status changed outside `l1/<module>` product
     * defs and `l1/<module>/pipeline/agentDefsL1`. The planner pipeline is outside.
     */
    export function outsideOwnedWrites(before: readonly D1FingerprintEntry[], after: readonly D1FingerprintEntry[], moduleName: string): string[];
    /** Done write rows. A trace that is not this progress schema is not opened. */
    export function readWriterReceipts(project: number, moduleName: string): Promise<D1WriterReceipt[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/gate" {
    import { type D1InputArtifacts, type D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export function buildD1InputSnapshot(identity: {
        project: number;
        moduleName: string;
    }, artifacts: D1InputArtifacts, previous: D1InputSnapshot | null): D1InputSnapshot;
    export function contractPageIds(artifacts: Pick<D1InputArtifacts, 'menu' | 'needs' | 'effort' | 'backend'>): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/input20/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /** Reads the object of `export const name = { ... }` without evaluating the file. */
    export function parseD1Source(text: string, kind: 'json' | 'defs'): unknown | null;
    export function readD1Input(project: number, moduleName: string): Promise<D1InputSnapshot | null>;
    /** Reads the snapshot inputs and returns the inventory. Writes nothing. */
    export function assembleD1Input(project: number, moduleName: string): Promise<D1InputSnapshot>;
    export function persistD1Input(project: number, moduleName: string, snapshot: D1InputSnapshot): Promise<{
        reused: boolean;
    }>;
    export function fileInfoFromDisplay(project: number, display: string): D1FileInfo | null;
    export function sha256Text(value: string): Promise<string>;
    export function ownedInputDisplay(project: number, moduleName: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/agentD1Input" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_DOMAIN_VERSION: "2026-09-21-d1-domain-v1";
    export const D1_DOMAIN_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export type D1DomainAction = typeof D1_DOMAIN_ACTIONS[number];
    export type D1RulePlacement = 'invariant' | 'application' | 'platform';
    export interface D1DomainFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1DomainTableRef {
        tableId: string;
        entity: string;
    }
    /** The slice of the input20 inventory this step reads. Matching is by exact id. */
    export interface D1DomainSelection {
        entities: string[];
        files: D1DomainFile[];
        tables: D1DomainTableRef[];
    }
    export interface D1DomainProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1Normalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1PlacedRule {
        ruleId: string;
        owner: 'module' | 'platform';
        /** Module artifact, or the catalog path the entity source names. Spelling is the citation. */
        source: string;
        placement: D1RulePlacement;
    }
    export interface D1Enumeration {
        path: string;
        values: string[];
    }
    export interface D1DomainEntityPlan {
        entityId: string;
        action: string;
        defPath: string;
        storageTarget: string;
        emitsLocalPersistence: false;
        derivedInitial: string | null;
        uniqueKeys: string[][];
        enumerations: D1Enumeration[];
        rules: D1PlacedRule[];
        definition: D1Definition | null;
    }
    export interface D1DomainValuePlan {
        valueObjectId: string;
        defPath: string;
        referencedBy: string[];
        definition: D1Definition | null;
    }
    export interface D1DomainEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1DomainBuild {
        schemaVersion: typeof D1_DOMAIN_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        entities: D1DomainEntityPlan[];
        valueObjects: D1DomainValuePlan[];
        problems: D1DomainProblem[];
        normalizations: D1Normalization[];
        preserved: string[];
        removed: string[];
        emit: D1DomainEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/gate" {
    import { type D1DomainBuild, type D1DomainSelection } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export interface D1DomainRequest {
        project: number;
        moduleName: string;
        selection: D1DomainSelection;
        /** Ontology bodies keyed by entityId. A filename is not an identity. */
        entities: Record<string, unknown>;
        ontologyIndex: unknown;
        /** Module rules artifact. Keys are matched exactly. */
        rules: unknown;
        /** Catalog document keyed by the entity `source` string. Absent means unread. */
        catalogs: Record<string, unknown>;
    }
    /**
     * One deterministic pass from the L4 record tree to domain defs.
     * No model, no eval, and no NS4 field list is rewritten into this tree.
     */
    export function buildD1Domain(request: D1DomainRequest): D1DomainBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export function assembleD1Domain(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1DomainBuild;
    }>;
    export function commitD1Domain(project: number, build: D1DomainBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A catalog may live in another project. `..` and a short name with a dot are refused. */
    export function catalogInfo(source: string): D1FileInfo | null;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/contracts" {
    import type { D1Definition, D1PortMethod } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export const D1_PERSISTENCE_VERSION: "2026-09-21-d1-persistence-v1";
    /** Prefix for a logical field stored in the runtime `details` JSONB column. One writer, reversible. */
    export const D1_JSON_COLUMN_PREFIX: "json:";
    /** Runtime JSONB column name. Not derived per table and not snake-cased. */
    export const D1_DETAILS_COLUMN: "details";
    export const D1_PERSISTENCE_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export const ENUMERATION_REASON: "Table and adapter schemas have no enum values. They stay on the domain draft.";
    export interface D1PersistenceFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1PersistenceProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1PersistenceNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ColumnBinding {
        field: string;
        column: string;
        nullable: boolean;
        placement: 'column' | 'json';
    }
    /** Enum values read from the domain draft and not copied onto a table or adapter. */
    export interface D1UnconsumedEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: 'domain30.enumerations';
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UniqueKeyUse {
        entityId: string;
        tableId: string | null;
        uniqueKeys: string[][];
        consumed: boolean;
        /** Where a consumed key was written, or why it was not. */
        placedOn: string;
    }
    export interface D1PersistencePortPlan {
        portId: string;
        entityId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceTablePlan {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        physicalName: string;
        /** Runtime JSONB column, or null when every field is a real column. */
        detailsColumn: string | null;
        definition: D1Definition | null;
    }
    export interface D1PersistenceAdapterPlan {
        portId: string;
        entityId: string;
        tableId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        bindings: D1ColumnBinding[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1PersistenceBuild {
        schemaVersion: typeof D1_PERSISTENCE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1UnconsumedEnumeration[];
        uniqueKeys: D1UniqueKeyUse[];
        ports: D1PersistencePortPlan[];
        tables: D1PersistenceTablePlan[];
        adapters: D1PersistenceAdapterPlan[];
        problems: D1PersistenceProblem[];
        normalizations: D1PersistenceNormalization[];
        preserved: string[];
        removed: string[];
        emit: D1PersistenceEmit[];
    }
    export interface D1PersistenceRequest {
        project: number;
        moduleName: string;
        selection: {
            ports: Array<{
                portId: string;
                entity: string;
                status: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
                status: string;
            }>;
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                status: string;
            }>;
            files: D1PersistenceFile[];
        };
        domain: D1DomainBuild;
        entities: Record<string, unknown>;
        /** Preserved port bytes keyed by defPath. The value is the definition object. */
        preservedPorts: Record<string, unknown>;
        /** Extra physical names that must equal `storage.table`. Keyed by entity id. */
        physicalCitations: Record<string, string[]>;
        /** Catalog paths this step opened and did not write. */
        catalogsRead: string[];
    }
    /** Logical field encoded by one column string. `json:` marks the details envelope. */
    export function fieldFromColumn(column: string): string;
    export function columnForField(field: string, placement: 'column' | 'json'): string;
    /** Names required by the port and missing from the adapter. */
    export function uncoveredMethods(required: readonly string[], implemented: readonly string[]): string[];
    /** A binding round-trips when each column string decodes to its own field and no column is shared. */
    export function bindingRoundTripIssues(bindings: readonly D1ColumnBinding[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1PersistenceBuild, type D1PersistenceRequest } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    /**
     * One deterministic pass from the domain draft and the L4 record to ports, tables and adapters.
     * No model. Physical names are `storage.table` verbatim. Nothing is snake-cased or pluralized.
     */
    export function buildD1Persistence(request: D1PersistenceRequest): D1PersistenceBuild;
    /** A port file must not depend on an adapter. The check is the application side of the hexagon. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/io" {
    import type { D1PersistenceBuild } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    export function assembleD1Persistence(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1PersistenceBuild;
    }>;
    export function commitD1Persistence(project: number, build: D1PersistenceBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_USECASE_VERSION: "2026-09-21-d1-usecases-v1";
    /** Same trail as persistence40. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Usecase projection has no values slot. Enum values stay on the domain draft.";
    export const D1_WORKER_KINDS: readonly ["port", "rule", "mdm", "transition", "effect", "transaction", "context"];
    /**
     * Facade methods a plan may name. `read` and `attach` are not methods:
     * a point read, a collection read and a platform-field update are different calls.
     * The tool offers only the methods the operation's binding names. This list stays
     * the facade, so a manipulated reply can still be recognized and refused.
     */
    export const D1_MDM_CALLS: readonly ["get", "findByDocument", "findByContact", "listByType", "relatedOfMany", "create", "attachRole", "update", "inactivate", "reactivate", "link", "invite"];
    export type D1MdmCall = (typeof D1_MDM_CALLS)[number];
    export const D1_WRITE_CALLS: readonly ["create", "update", "transition", "delete"];
    export interface D1UsecaseProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1UsecaseNormalization {
        code: string;
        path: string;
        detail: string;
    }
    /** Domain enum values cited by path and not copied onto a usecase. */
    export interface D1UsecaseEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UsecaseField {
        name: string;
        type: string;
        derived: boolean;
    }
    export interface D1UsecaseTransition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        /** Field paths the ontology names. Empty when that transition declares none. */
        payload?: string[];
        description?: string;
    }
    export interface D1UsecaseEntity {
        entityId: string;
        storageTarget: string;
        defPath: string;
        /** Empty when the ontology names none. The step does not invent one. */
        namespace: string;
        fields: D1UsecaseField[];
        transitions: D1UsecaseTransition[];
        rules: Array<{
            ruleId: string;
            owner: 'module' | 'platform';
            source?: string;
        }>;
        enumerations: Array<{
            path: string;
            values: string[];
        }>;
        /** Capability ids the ontology declares. Absent when this step was not given the body. */
        capabilities?: string[];
        /** Non-derived platform field paths. The MDM binding maps each one to a facade patch key. */
        platformFields?: string[];
    }
    export interface D1PortSignature {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1UsecasePort {
        portId: string;
        entityId: string;
        defPath: string;
        methods: string[];
        signatures?: D1PortSignature[];
    }
    export interface D1UsecaseRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
    }
    export interface D1UsecaseSelection {
        usecaseId: string;
        entity: string;
        operation: string;
        routes: string[];
        defPath: string;
    }
    export interface D1OutboundEvent {
        eventId: string;
        on: string;
        kind?: string;
        to?: string;
        description?: string;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1WorkerPort {
        kind: 'port';
        call: string;
        port: string;
    }
    export interface D1WorkerRule {
        kind: 'rule';
        ruleId: string;
    }
    export interface D1WorkerMdm {
        kind: 'mdm';
        namespace: string;
        /** Facade method the model named. Not trusted until the gate matches it to a capability. */
        call: string;
        entity: string;
        /** Capability this step claims to execute. */
        capability: string;
    }
    export interface D1WorkerTransition {
        kind: 'transition';
        transitionId: string;
        payload: string[];
    }
    export interface D1WorkerEffect {
        kind: 'effect';
        eventId: string;
    }
    export interface D1WorkerTransaction {
        kind: 'transaction';
        boundary: string;
    }
    export interface D1WorkerContext {
        kind: 'context';
        source: string;
    }
    export type D1WorkerStep = D1WorkerPort | D1WorkerRule | D1WorkerMdm | D1WorkerTransition | D1WorkerEffect | D1WorkerTransaction | D1WorkerContext;
    /** One model reply, already parsed. Operational means the reply never arrived. */
    export interface D1UsecasePlanInput {
        usecaseId: string;
        steps: D1WorkerStep[];
        operational?: boolean;
        trace?: string;
    }
    /** A source the snapshot approved, or a file that was missing or had changed. */
    export interface D1SourceFinding {
        code: 'SOURCE_ABSENT' | 'SOURCE_CHANGED' | 'RULE_TEXT_ABSENT' | 'CONTRACT_UNPARSED';
        path: string;
        message: string;
    }
    export interface D1SourceHash {
        path: string;
        sha256: string;
    }
    export interface D1SourceText {
        path: string;
        text: string;
    }
    /** One rule the operation is subject to. The text is the source, not a summary. */
    export interface D1RuleText {
        ruleId: string;
        owner: 'module' | 'platform';
        source: string;
        text: string;
    }
    export interface D1ContractPath {
        path: string;
        type: string;
        optional: boolean;
    }
    export interface D1AccessGrant {
        grantId: string;
        actorRef: string;
        scope: string;
        anchorEntity: string;
        scopeDetail: string;
        disclosure: string;
        disclosureDetail: string;
        allowedFields: string[];
    }
    export interface D1RouteContext {
        route: string;
        page: string;
        contractPath: string;
        inputSymbol: string;
        outputSymbol: string;
        inputFields: D1ContractPath[];
        outputFields: D1ContractPath[];
        /** Set when this route's contract does not bind the route. Not a second type. */
        unbound: string;
        access: D1AccessGrant[];
    }
    export interface D1CapabilityText {
        name: string;
        text: string;
    }
    export interface D1JourneyContext {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: Array<{
            stepId: string;
            kind: string;
            transitionRef: string;
            description: string;
        }>;
    }
    /**
     * Business context for one usecase. Contract symbols stay a reading of the L2
     * source. This is not a DTO the gate trusts instead of that source.
     */
    export interface D1UsecaseContext {
        usecaseId: string;
        lifecycle: boolean;
        transition: {
            transitionId: string;
            from: string[];
            to: string;
            by: string[];
            ruleRefs: string[];
            payload: string[];
            description: string;
        } | null;
        capabilities: D1CapabilityText[];
        effectiveFields: string[];
        routes: D1RouteContext[];
        rules: D1RuleText[];
        portId: string;
        portMethods: D1PortSignature[];
        effects: D1OutboundEvent[];
        journeys: D1JourneyContext[];
        findings: D1SourceFinding[];
        sources: D1SourceHash[];
    }
    /** The human prompt that was handed to the worker, plus the hashes it was built from. */
    export interface D1PromptEvidence {
        usecaseId: string;
        bytes: number;
        sha256: string;
        snapshotHash: string;
        sourceHashes: D1SourceHash[];
        text: string;
    }
    export interface D1UsecaseRequest {
        project: number;
        moduleName: string;
        usecases: D1UsecaseSelection[];
        routes: D1UsecaseRoute[];
        ports: D1UsecasePort[];
        entities: D1UsecaseEntity[];
        /** Ids only. The gate uses this catalog to validate a returned id. */
        moduleRules: string[];
        outbound: D1OutboundEvent[];
        contracts: D1ContractSource[];
        contexts?: D1UsecaseContext[];
        sourceFindings?: D1SourceFinding[];
        sourceHashes?: D1SourceHash[];
        /** Raw dependency texts. The fidelity reader uses these, not the draft. */
        files?: D1SourceText[];
        plans: D1UsecasePlanInput[];
        llmCalls: number;
    }
    /** One value the facade method takes. A patch key the facade does not accept is not represented. */
    export interface D1MdmArgument {
        name: string;
        role: 'selector' | 'parameter' | 'patch';
        /** Set when a shared call's patch is owned by one capability. */
        capability?: string;
        /** Ontology or contract path the value is read from. */
        path?: string;
        /** Constant the facade receives when the value is not a field (`role` tag, or `ctx`). */
        value?: string;
    }
    /** One facade invocation. Several capabilities may share it when one patch and one version cover them. */
    export interface D1MdmPlannedCall {
        method: D1MdmCall;
        target: 'entity' | 'collection' | 'identity';
        shape: 'point' | 'collection' | 'write';
        capabilities: string[];
        /** True when the capability is a choice (inactivate or reactivate), not a sequence. */
        alternative: boolean;
        arguments: D1MdmArgument[];
        result: string[];
    }
    /** A declared capability the facade does not implement. Not a successful call. */
    export interface D1MdmGap {
        capability: string;
        /** MDM_UNBOUND: no facade method. MDM_PATCH_UNBOUND: a field the facade cannot patch. */
        code: 'MDM_UNBOUND' | 'MDM_PATCH_UNBOUND';
        evidence: string;
    }
    export interface D1UsecaseMdm {
        namespace: string;
        /** Canonical tag `<namespace>.<entityId>`. */
        role: string;
        /**
         * True only when every selected capability is one facade invocation.
         * A sequence of calls is not atomic: the facade does not wrap them.
         */
        atomic: boolean;
        calls: D1MdmPlannedCall[];
        gaps: D1MdmGap[];
    }
    export interface D1UsecaseItem {
        usecaseId: string;
        entityId: string;
        operation: string;
        defPath: string;
        routes: string[];
        trustedContext: 'ctx';
        mdm: D1UsecaseMdm | null;
        transactionBoundary: 'local' | null;
        steps: D1WorkerStep[];
        definition: D1Definition | null;
    }
    export interface D1UsecaseEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1UsecaseBuild {
        schemaVersion: typeof D1_USECASE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: number;
        ok: boolean;
        enumerations: D1UsecaseEnumeration[];
        usecases: D1UsecaseItem[];
        problems: D1UsecaseProblem[];
        normalizations: D1UsecaseNormalization[];
        emit: D1UsecaseEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/context" {
    import { type D1InputSnapshot, type D1SourceDigest } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ContractSource, D1OutboundEvent, D1SourceFinding, D1SourceHash, D1SourceText, D1UsecaseContext, D1UsecaseEntity, D1UsecasePort, D1UsecaseRequest, D1UsecaseRoute, D1UsecaseSelection } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface JourneyStepView {
        stepId: string;
        kind: string;
        entity: string;
        effect: string;
        transitionRef: string;
        description: string;
    }
    export interface JourneyView {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: JourneyStepView[];
    }
    export interface VerifiedBundle {
        findings: D1SourceFinding[];
        hashes: D1SourceHash[];
        moduleRuleText: Record<string, string> | null;
        moduleRulesPath: string;
        outbound: D1OutboundEvent[];
        integrationPath: string;
        contracts: D1ContractSource[];
        access: unknown | null;
        accessPath: string;
        needs: unknown | null;
        needsPath: string;
        journeys: JourneyView[];
        catalogs: Array<{
            path: string;
            rules: Record<string, string>;
        }>;
        bodies: Record<string, unknown | null>;
        entityPaths: Record<string, string>;
        files: D1SourceText[];
    }
    interface TransitionBody {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        payload: string[];
        description: string;
    }
    /** Reads the snapshot's sources again. A file is kept only when its hash still matches. */
    export function loadVerifiedSources(project: number, moduleName: string, snapshot: D1InputSnapshot, entityIds: readonly string[]): Promise<VerifiedBundle>;
    /**
     * The cut for one usecase: its routes, the rules those routes are subject to,
     * and the lifecycle or MDM capability that operation actually is.
     */
    export function buildUsecaseContexts(input: {
        moduleName: string;
        usecases: readonly D1UsecaseSelection[];
        routes: readonly D1UsecaseRoute[];
        entities: readonly D1UsecaseEntity[];
        ports: readonly D1UsecasePort[];
        bundle: VerifiedBundle;
    }): D1UsecaseContext[];
    export function formatUsecaseContext(context: D1UsecaseContext): string;
    /** Names the gate may accept on a transition payload. Contract inputs stay the authority. */
    export function authorizedPayloadNames(request: D1UsecaseRequest, usecaseId: string, inputNames: readonly string[]): Set<string>;
    export function blockingFinding(findings: readonly D1SourceFinding[]): D1SourceFinding | null;
    /** A file this context was built from no longer matches the snapshot. */
    export function blockingDrift(project: number, context: D1UsecaseContext, digests: readonly D1SourceDigest[]): Promise<D1SourceFinding | null>;
    export function ontologyTransitions(body: unknown): TransitionBody[];
    export function namespaceOf(body: unknown): string;
    export function capabilityNames(body: unknown): string[];
    export function platformFieldPaths(body: unknown): string[];
    export function capabilityApplies(name: string, operation: string): boolean;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/dispatch" {
    import type { D1PromptEvidence } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export const FANOUT_TITLE = "Generating {{completed}}/{{total}} items, failed {{failed}}";
    export interface D1WorkerArg {
        planId: string;
        moduleName: string;
        project: number;
        usecaseId: string;
        attempt: number;
        unitAttempts: number;
        globalAttempts: number;
        feedback: string;
    }
    export interface D1AttemptTrace {
        usecaseId: string;
        status: 'parsed' | 'repairable' | 'operational';
        trace: string;
        unitAttempts: number;
        reply: unknown;
        /** The prompt the hook assembled. Present after prepareWorker. */
        request?: D1PromptEvidence;
    }
    export interface D1RepairOrder {
        usecaseId: string;
        unitAttempts: number;
        globalAttempts: number;
        planId: string;
        feedback: string;
    }
    export interface D1BarrierDecision {
        repairs: D1RepairOrder[];
        identified: Array<{
            usecaseId: string;
            trace: string;
            code: string;
        }>;
        pause: boolean;
    }
    /** Compact, stable JSON. One arg is one usecase. */
    export function workerArg(arg: D1WorkerArg): string;
    export function parseWorkerArg(value: string): D1WorkerArg | null;
    export function firstWorkerArg(project: number, moduleName: string, usecaseId: string): string;
    export function fanoutStep(project: number, moduleName: string, args: readonly string[]): mls.msg.AIAgentStep;
    export function fanoutExecution(args: readonly string[]): mls.msg.ExecutionMode;
    /**
     * The host marks a parallel parent completed and does not call its afterPrompt.
     * This step depends on the fan-out, so the host unlocks it and runs beforePrompt.
     * A later round depends on the repair plan ids from the round it follows.
     */
    export function barrierStep(project: number, moduleName: string, dependsOn: readonly string[], round: string): mls.msg.AIAgentStep;
    /**
     * One repair per usecase, and no more than the global ceiling.
     * An operational failure is identified and does not take a repair.
     * A missing trace is still identified.
     */
    export function decideRepairs(input: {
        expected: readonly string[];
        attempts: readonly D1AttemptTrace[];
        globalAttempts: number;
        feedbackFor: (usecaseId: string) => string;
    }): D1BarrierDecision;
    export function repairStep(project: number, moduleName: string, order: D1RepairOrder): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding" {
    import { type D1MdmCall, type D1MdmGap, type D1UsecaseMdm } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    /**
     * Capabilities the ontology can name and the facade does not implement.
     * Inactivate and reactivate do not write status history. Audit is another module.
     */
    export function mdmFacadeGaps(): D1MdmGap[];
    export function isMdmFacadeCall(value: string): value is D1MdmCall;
    /** A patch key the caller module may not write. Platform keys and the caller namespace are allowed. */
    export function isForeignMdmPatchKey(namespace: string, key: string): boolean;
    export interface MdmBindInput {
        entityId: string;
        namespace: string;
        /** Every capability the role declares. Contact dedupe is decided from this, not from the operation filter. */
        capabilities: readonly string[];
        /** Capabilities this operation actually uses. */
        selected: readonly string[];
        platformFields: readonly string[];
    }
    export function bindMdm(input: MdmBindInput): D1UsecaseMdm;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/fidelity" {
    import type { D1UsecaseMdm, D1WorkerStep } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface FidelityFile {
        path: string;
        text: string;
    }
    export interface FidelityProblem {
        code: string;
        path: string;
        message: string;
    }
    export interface D1FieldUse {
        path: string;
        role: 'filter' | 'selector' | 'concurrency' | 'write';
        source: 'input' | 'payload';
    }
    export interface UsecaseBehavior {
        usecaseId: string;
        operation: string;
        sequence: D1WorkerStep[];
        uses: D1FieldUse[];
        mdm: D1UsecaseMdm | null;
        lifecycle: {
            transitionId: string;
            payload: string[];
            sourcePath: string;
            symbol: string;
        } | null;
        rules: Array<{
            ruleId: string;
            path: string;
            symbol: string;
        }>;
        transaction: 'local' | 'none';
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        routes: Array<{
            route: string;
            contractPath: string;
            symbol: string;
            outputFields: string[];
        }>;
    }
    /**
     * Classifies a derived field the same way the gate does.
     * A payload is a write. Identity on a read is a filter; on an update or
     * transition it is a selector. A nested derived field on a read is a filter.
     * `version` on an update or transition is concurrency.
     */
    export function fieldUses(input: {
        operation: string;
        fields: readonly {
            name: string;
            derived: boolean;
        }[];
        inputPaths: readonly string[];
        payloadPaths: readonly string[];
    }): D1FieldUse[];
    /**
     * Reads one serialized usecase def and the dependency texts it names.
     * It does not take the draft. A rule id, a file count or a signature is not enough.
     */
    export function readUsecaseFidelity(source: string, files: readonly FidelityFile[]): {
        behavior: UsecaseBehavior | null;
        problems: FidelityProblem[];
    };
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1UsecaseBuild, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    /**
     * One deterministic pass from the selection, the domain draft, the ports and
     * the contract AST. The model may order steps. It does not choose ids.
     */
    export function buildD1Usecases(request: D1UsecaseRequest): D1UsecaseBuild;
    /** A usecase file must not depend on an adapter. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1AttemptTrace } from "_102021_/l2/agentDefsL1/steps/usecases50/dispatch";
    import { D1_USECASE_VERSION, type D1PromptEvidence, type D1UsecaseBuild, type D1UsecasePlanInput, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface D1UsecaseWork {
        schemaVersion: typeof D1_USECASE_VERSION;
        repairs: number;
        request: D1UsecaseRequest;
    }
    export function loadD1UsecaseWork(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        work: D1UsecaseWork;
    }>;
    export function readD1UsecaseWork(project: number, moduleName: string): Promise<D1UsecaseWork | null>;
    export function writeD1UsecaseWork(project: number, work: D1UsecaseWork): Promise<void>;
    export function workFile(project: number, moduleName: string): D1FileInfo;
    export function attemptFile(project: number, moduleName: string, usecaseId: string): D1FileInfo;
    export function writeAttempt(project: number, moduleName: string, attempt: D1AttemptTrace): Promise<void>;
    /** The assembled prompt, written before the model replies. Not an attempt: it has no status. */
    export function writePromptEvidence(project: number, moduleName: string, evidence: D1PromptEvidence): Promise<void>;
    /** A source finding already closed this worker. A later empty reply must not replace it. */
    export function sourceBlockTrace(project: number, moduleName: string, usecaseId: string): Promise<string | null>;
    export function readPromptEvidence(project: number, moduleName: string, usecaseId: string): Promise<D1PromptEvidence | null>;
    export function readAttempts(project: number, moduleName: string, usecaseIds: readonly string[]): Promise<D1AttemptTrace[]>;
    export function commitD1Usecases(project: number, build: D1UsecaseBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    export function plansFromAttempts(attempts: readonly D1AttemptTrace[]): D1UsecasePlanInput[];
    export function buildFromWork(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], llmCalls: number): D1UsecaseBuild;
    /**
     * Defs of units that parsed stay. Each identified unit is one error on its
     * usecase id and has no definition. `ok` stays false.
     */
    export function holdUnresolvedBuild(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], identified: readonly {
        usecaseId: string;
        code: string;
        trace: string;
    }[], llmCalls: number): D1UsecaseBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/worker" {
    import { type D1UsecaseContext, type D1UsecaseRequest, type D1UsecaseSelection, type D1WorkerStep } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export const USECASE_TOOL_NAME = "planUsecaseSteps";
    export const STEP_KEYS: {
        readonly port: readonly ["kind", "call", "port"];
        readonly rule: readonly ["kind", "ruleId"];
        readonly mdm: readonly ["kind", "namespace", "call", "entity", "capability"];
        readonly transition: readonly ["kind", "transitionId", "payload"];
        readonly effect: readonly ["kind", "eventId"];
        readonly transaction: readonly ["kind", "boundary"];
        readonly context: readonly ["kind", "source"];
    };
    /** One facade method with the capability that binding says it executes. */
    export interface MdmStepPair {
        call: string;
        capability: string;
    }
    /**
     * Catalogs known for the one usecase being called.
     * An omitted catalog was not provided and stays a free string.
     * An empty catalog was provided and means that branch is unavailable.
     */
    export interface UsecaseClosedValues {
        portCalls?: readonly string[];
        portIds?: readonly string[];
        ruleIds?: readonly string[];
        namespaces?: readonly string[];
        entityIds?: readonly string[];
        /** Facade methods this operation may name. Empty omits MDM. Omitted keeps the facade catalog. */
        mdmCalls?: readonly string[];
        capabilities?: readonly string[];
        /** One branch per pair, so a call cannot be paired with another capability. Empty omits MDM. */
        mdmPairs?: readonly MdmStepPair[];
        transitionIds?: readonly string[];
        /** Paths a transition payload may name. Empty means the payload array is empty. Omitted keeps a free string. */
        payloadPaths?: readonly string[];
        eventIds?: readonly string[];
        /** Authority values this operation may name. The gate admits `ctx` only. */
        sources?: readonly string[];
    }
    export interface OperationCatalogInput {
        operation: string;
        entityId: string;
        storageTarget: string;
        namespace: string;
        portId: string;
        /** Methods the port declares. Only `operation` is offered, and only when this port has it. */
        portMethods: readonly string[];
        ruleIds: readonly string[];
        eventIds: readonly string[];
        transitionId: string;
        payloadPaths: readonly string[];
        mdmPairs: readonly MdmStepPair[];
    }
    /** The catalogs for one operation. Port, MDM and transition come from the same facts the schema uses. */
    export function catalogForOperation(input: OperationCatalogInput): UsecaseClosedValues;
    /** Selection for the usecase the worker is about to call. Schema and prompt both take this object. */
    export function closedFromRequest(request: D1UsecaseRequest, usecase: D1UsecaseSelection, packet?: D1UsecaseContext): UsecaseClosedValues;
    /**
     * Kinds and calls this operation can use, from `selectBranches`.
     * An unscoped call still lists every kind and the facade catalog.
     * The markdown prompt does not copy this list.
     */
    export function workerStepShape(closed?: UsecaseClosedValues): string;
    export interface D1WorkerReply {
        steps: D1WorkerStep[] | null;
        problems: Array<{
            code: string;
            message: string;
        }>;
    }
    /** The model returns steps only. An extra field rejects the reply. */
    export function parseWorkerReply(payload: unknown): D1WorkerReply;
    export function usecaseTool(closed?: UsecaseClosedValues): mls.msg.LLMTool;
    /** Human prompt. The packet is fixed. The model does not write TypeScript. */
    export function usecaseHumanPrompt(input: {
        usecase: D1UsecaseSelection;
        entityId: string;
        storageTarget: string;
        namespace: string;
        portId: string;
        methods: string[];
        rules: string[];
        effects: string[];
        routes: string[];
        context?: D1UsecaseContext;
        /** Same object the tool schema was built from. */
        closed: UsecaseClosedValues;
        feedback?: string;
    }): string;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_CONTROLLER_VERSION: "2026-09-22-d1-controllers-v1";
    /** Same trail as domain30 and usecases50. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Controller projection has no values slot. Enum values stay on the domain draft.";
    export const HANDLER_STEPS: readonly ["transport", "session", "authorize", "call", "project", "bff"];
    export interface D1ControllerProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1ControllerNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ControllerEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1ControllerPage {
        pageId: string;
        actors: string[];
        defPath: string;
    }
    export interface D1ControllerRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
        status: string;
    }
    export interface D1ControllerUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        functionName: string;
        defPath: string;
    }
    export interface D1ControllerGrant {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        scopeMode: string;
    }
    export interface D1ControllerRelationship {
        relationshipId: string;
        from: string;
        to: string;
        /** Copied from the relationship. Empty when the relationship declares none. */
        field: string;
        required: boolean;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1ExistingHandler {
        route: string;
        kind: 'query' | 'command';
        usecaseId: string;
        grantIds: string[];
    }
    /** A controller file already on disk. Parsed, never evaluated. */
    export interface D1ExistingController {
        pageId: string;
        routes: string[];
        handlers: D1ExistingHandler[];
        unreadable: boolean;
    }
    export interface D1EnumerationRef {
        entityId: string;
        path: string;
        values: string[];
    }
    export interface D1ControllerRequest {
        project: number;
        moduleName: string;
        pages: D1ControllerPage[];
        routes: D1ControllerRoute[];
        usecases: D1ControllerUsecase[];
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        contracts: D1ContractSource[];
        existing: D1ExistingController[];
        enumerations: D1EnumerationRef[];
        accessRead: boolean;
        actorsRead: boolean;
        /** Routes selected for removal. Absent means none. */
        removedRoutes?: readonly D1RemovedRoute[];
    }
    export interface D1ScopeRelationship {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Scope plan support70 will emit. The anchor is the one the access artifact declared. */
    export interface D1ScopeGrantPlan {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        relationships: D1ScopeRelationship[];
        pending: string;
        emittedBy: 'support70';
    }
    export interface D1HandlerProjection {
        shape: 'array' | 'object' | 'unresolved';
        fields: string[];
        envelope: 'passthrough';
    }
    export interface D1HandlerBinding {
        route: string;
        pageId: string;
        kind: 'query' | 'command';
        usecaseId: string;
        functionName: string;
        contractPath: string;
        inputSymbol: string;
        outputSymbol: string;
        status: string;
        preserved: boolean;
        grantIds: string[];
        projection: D1HandlerProjection;
        session: 'verified';
        steps: typeof HANDLER_STEPS;
        scopePlan: D1ScopeGrantPlan[];
    }
    export interface D1ControllerItem {
        pageId: string;
        defPath: string;
        handlers: D1HandlerBinding[];
        staleRoutes: string[];
        definition: D1Definition | null;
    }
    export interface D1ControllerEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    /** A selected route to drop. Other routes of the same controller stay. */
    export interface D1RemovedRoute {
        route: string;
        pageId: string;
        defPath: string;
        contentHash: string;
    }
    /** Own controller def removed only when the page has no live route left. */
    export interface D1ControllerRemoval {
        defPath: string;
        contentHash: string;
        outputTs: string[];
    }
    export interface D1ControllerBuild {
        schemaVersion: typeof D1_CONTROLLER_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        measuredRoutes: number;
        measuredPages: number;
        enumerations: D1ControllerEnumeration[];
        controllers: D1ControllerItem[];
        problems: D1ControllerProblem[];
        normalizations: D1ControllerNormalization[];
        emit: D1ControllerEmit[];
        /** Controller defs with no live route. The `.ts` path is reported, not deleted. */
        removals: D1ControllerRemoval[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/gate" {
    import { type D1ControllerBuild, type D1ControllerGrant, type D1ControllerRequest } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    /**
     * One controller per page. Ids, route strings and contract symbols are copied.
     * An operation with no grant is an error. There is no public fallback.
     */
    export function buildD1Controllers(request: D1ControllerRequest): D1ControllerBuild;
    /** A grant whose actor is not on this page is a union. The caller does not add it. */
    export function grantUnionIssues(pageActors: readonly string[], grantIds: readonly string[], grants: readonly D1ControllerGrant[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/io" {
    import { type D1ControllerBuild } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export function assembleD1Controllers(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1ControllerBuild;
    }>;
    export function commitD1Controllers(project: number, build: D1ControllerBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/contracts" {
    import type { D1_MEASURED_PUBLISH, D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1ControllerGrant, D1ControllerRelationship, D1ScopeGrantPlan } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export const D1_SUPPORT_VERSION: "2026-09-22-d1-support-v1";
    /** Same trail as the earlier steps. Uncited values stay on the domain draft. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Scope and registry have no values slot. Enum values stay on the domain draft.";
    export const ENUMERATION_CONSUMED_REASON: "Seed scenarios cite every value of this enum. The values are not copied into rows.";
    export interface D1SupportProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1SupportNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1SupportEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: boolean;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON | typeof ENUMERATION_CONSUMED_REASON;
    }
    export interface D1SupportFile {
        artifactType: string;
        defPath: string;
        action: string;
        /** Hash inventoried on the input receipt. Empty when this run has no receipt. */
        contentHash: string;
        /** Hash of the bytes on disk now. Empty when the file is absent. */
        currentHash: string;
    }
    /** An adapter persistence40 already planned. A removed adapter is not live. */
    export interface D1SupportAdapter {
        portId: string;
        entityId: string;
        tableId: string;
        artifactId: string;
        action: string;
        defPath: string;
    }
    export interface D1SupportJoinStep {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Join helper recorded as a def. This step does not write a TypeScript file for it. */
    export interface D1SupportHelper {
        helperId: string;
        session: 'verified';
        steps: D1SupportJoinStep[];
        consumers: string[];
    }
    export interface D1SupportEdge {
        id: string;
        type: string;
        dependsOn: string[];
    }
    export interface D1ScopeResolution {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        /** The mode the access artifact declared. Never replaced by a permissive fallback. */
        scopeMode: string;
        session: 'verified';
        path: D1SupportJoinStep[];
        pending: string;
        helperId: string;
    }
    export interface D1RegistryAdapter {
        portId: string;
        adapterArtifactId: string;
        factory: string;
        defPath: string;
        dependsOn: string[];
    }
    export interface D1PublicationItem {
        artifactType: string;
        defPath: string;
        outputPath: string;
        registers: string;
    }
    export interface D1PublicationLater {
        artifactType: string;
        defPath: string;
        reason: string;
    }
    /** Local table the seed plan may describe. An MDM table is refused. */
    export interface D1SeedTable {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        uniqueKeys: string[][];
    }
    export interface D1SeedTransition {
        transitionId: string;
        to: string;
        ruleRefs: string[];
    }
    /** Model facts the seed plan may cite. It does not invent rows from them. */
    export interface D1SeedModel {
        entityId: string;
        storageTarget: string;
        kind: 'role' | 'entity';
        namespace: string;
        fields: Array<{
            name: string;
            type: string;
        }>;
        states: string[];
        initialState: string;
        uniqueKeys: string[][];
        transitions: D1SeedTransition[];
        /** Empty when the model does not declare the note field. */
        noteField: string;
    }
    export interface D1SeedEffect {
        entityId: string;
        effect: string;
        transitionRef: string;
    }
    export interface D1SeedJourney {
        journeyId: string;
        entities: string[];
        effects: D1SeedEffect[];
    }
    /** A role or actor tag. It is not the MDM entity id. */
    export interface D1SeedRoleTag {
        tag: string;
        entityId: string;
    }
    export interface D1SeedRef {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDataset {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    export interface D1SeedDependency {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedMaintenance {
        action: 'reseed' | 'reset' | 'removeOwner';
        ownerId: string;
    }
    /** Plan versus rows. This step never sets materialized or a row count above zero. */
    export interface D1SeedReport {
        phase: 'plan' | 'absent';
        materialized: false;
        rowCount: 0;
        datasets: D1SeedDataset[];
        dependencies: D1SeedDependency[];
    }
    /** One outbound event from the integration artifact. `mechanism` is empty when the artifact names none. */
    export interface D1EffectEvent {
        eventId: string;
        on: string;
        mechanism: string;
        /** True only when the transition object declares `payload`. */
        payloadDeclared: boolean;
    }
    /** A process, inbound item or plugin. Operations are not routes. */
    export interface D1EffectOperation {
        id: string;
        kind: 'process' | 'inbound' | 'plugin';
        operations: string[];
        mechanism: string;
        consumer: string;
        /** A scheduled trigger is preserved as a review. This step does not write a scheduler. */
        scheduled: boolean;
    }
    /** The measured publish API, and whether any artifact already named it. Nothing is executed. */
    export interface D1EffectReport {
        phase: 'plan' | 'absent';
        executed: false;
        capability: {
            symbol: typeof D1_MEASURED_PUBLISH.symbol;
            path: typeof D1_MEASURED_PUBLISH.path;
            owner: typeof D1_MEASURED_PUBLISH.owner;
            payload: typeof D1_MEASURED_PUBLISH.payload;
            delivery: typeof D1_MEASURED_PUBLISH.delivery;
            transaction: typeof D1_MEASURED_PUBLISH.transaction;
            requestContextPublish: false;
            bound: boolean;
        };
    }
    export interface D1SupportRequest {
        project: number;
        moduleName: string;
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        /** Scope plans controllers60 already resolved. The anchor is not corrected here. */
        scopePlans: D1ScopeGrantPlan[];
        /** Grant ids cited by handlers. A missing id is a diagnosis, not a new grant. */
        citedGrantIds: string[];
        adapters: D1SupportAdapter[];
        files: D1SupportFile[];
        /** Helpers already on the draft. A helper stays while one live consumer remains. */
        existingHelpers: D1SupportHelper[];
        /** Edges already emitted by application defs. An adapter or registry edge is inverted. */
        applicationEdges: D1SupportEdge[];
        /** Form field names a contract offered as identity. They are not the session. */
        formFields: string[];
        enumerations: Array<{
            entityId: string;
            path: string;
            values: string[];
        }>;
        /** Local tables persistence40 planned. A role table is not a seed target. */
        tables: D1SeedTable[];
        models: D1SeedModel[];
        journeys: D1SeedJourney[];
        /** Journey ids the index names and this step could not read. */
        missingJourneys: string[];
        roleTags: D1SeedRoleTag[];
        /** Extra refs a caller proposed. A ref without a column relationship is refused. */
        seedRefs: D1SeedRef[];
        /** Datasets already shared. Dropping one owner does not drop the dataset. */
        existingDatasets: D1SeedDataset[];
        maintenance: D1SeedMaintenance | null;
        /** Outbound rows of the integration artifact. */
        outbound: D1EffectEvent[];
        /** Event ids input20 selected. A selected id missing here is an omission. */
        selectedEventIds: string[];
        /** Usecase ids the plan selected. An event consumer must be one of these. */
        usecaseIds: string[];
        /** Processes, inbound and plugins. A workflow does not become an endpoint. */
        operations: D1EffectOperation[];
    }
    export interface D1SupportEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1SupportBuild {
        schemaVersion: typeof D1_SUPPORT_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1SupportEnumeration[];
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        registry: D1RegistryAdapter[];
        publication: {
            stillToRegister: D1PublicationItem[];
            later: D1PublicationLater[];
        };
        /** Separates the seed plan from rows. Rows are not written here. */
        seedPlan: D1SeedReport;
        /** Effect plan. `executed` stays false. An empty mechanism stays unbound. */
        effectPlan: D1EffectReport;
        problems: D1SupportProblem[];
        normalizations: D1SupportNormalization[];
        emit: D1SupportEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/support70/gate" {
    import { type D1RegistryAdapter, type D1ScopeResolution, type D1EffectReport, type D1SeedReport, type D1SupportAdapter, type D1SupportBuild, type D1SupportEmit, type D1SupportHelper, type D1SupportNormalization, type D1SupportProblem, type D1SupportRequest } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /**
     * Registry, scope and the seed plan. No model call. Grants and anchors are copied.
     * A missing grant or an anchor with no explicit path is a diagnosis.
     * It is not rewritten as organization or public.
     * Seeds describe scenarios. They do not write rows.
     * Effects name the consumer and keep an empty mechanism when none was declared.
     * Nothing is published.
     */
    export function buildD1Support(request: D1SupportRequest): D1SupportBuild;
    /** Access scope and the authority map. The map adds no grant. */
    export function emitScope(request: D1SupportRequest, problems: D1SupportProblem[]): {
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        emit: D1SupportEmit[];
    };
    /** Live adapters only. The registry depends on them. They do not depend on it. */
    export function emitRegistry(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        adapters: D1RegistryAdapter[];
        live: D1SupportAdapter[];
        emit: D1SupportEmit[];
    };
    /**
     * One seed plan for the local tables. Journeys and models supply scenarios.
     * MDM roles are dependencies, not rows. A ref needs a column relationship.
     */
    export function emitSeeds(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        emit: D1SupportEmit[];
        plan: D1SeedReport;
        cited: Set<string>;
    };
    /**
     * One outbound def. Events keep the transition as consumer.
     * An empty mechanism stays empty. publishEvent and emitEvent are refused.
     * Processes, inbound and plugins stay operations. A scheduled trigger writes no scheduler.
     */
    export function emitEffects(request: D1SupportRequest, problems: D1SupportProblem[]): {
        emit: D1SupportEmit[];
        report: D1EffectReport;
    };
}
declare module "_102021_/l2/agentDefsL1/steps/support70/io" {
    import { type D1SupportBuild, type D1SupportFile } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    export function assembleD1Support(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1SupportBuild;
        files: D1SupportFile[];
    }>;
    export function commitD1Support(project: number, build: D1SupportBuild, files: readonly D1SupportFile[]): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A support def is removed only when this build did not keep it for a live consumer. */
    export function supportFilesToRemove(build: D1SupportBuild, files: readonly D1SupportFile[]): D1SupportFile[];
}
declare module "_102021_/l2/agentDefsL1/steps/support70/agentD1Support" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/contracts" {
    import type { D1PipelineState, D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export const D1_REPORT_VERSION: "2026-09-22-d1-report-v1";
    /** Recognition by the inventory reader is not a runnable backend. */
    export const INVENTORY_NOTE: "Inventory recognition is not certification of an executable backend.";
    /** Product types and the step that writes them. Matching is by artifact type, not by file name. */
    export const PHASE_OF_TYPE: Record<string, D1StepId>;
    export const CHAIN_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70"];
    export interface D1FinalizeChild {
        planId: string;
        status: string;
        artifactPath: string;
        present: boolean;
    }
    export interface D1FinalizeObserved {
        defPath: string;
        text: string | null;
        currentHash: string;
        /** Hash the write receipt expects now. Empty when this file has no such receipt. */
        receiptHash: string;
        action: string;
        ownerRefs: string[];
        unitDone: boolean;
    }
    export interface D1FinalizeContract {
        path: string;
        text: string | null;
        hash: string;
    }
    export interface D1FinalizeRequest {
        project: number;
        moduleName: string;
        pipeline: D1PipelineState;
        snapshot: D1InputSnapshot | null;
        sourceHashes: Record<string, string>;
        /** Texts opened for fidelity: snapshot sources and declared read dependencies. Not the usecase draft. */
        dependencyTexts: Record<string, string>;
        contracts: Record<string, D1FinalizeContract>;
        drafts: {
            domain30: unknown;
            persistence40: unknown;
            usecases50: unknown;
            controllers60: unknown;
            support70: unknown;
        };
        observed: D1FinalizeObserved[];
        /** Future output path → the `.ts` file is on disk. Absence is expected. */
        futurePresent: Record<string, boolean>;
        children: D1FinalizeChild[];
    }
    export interface D1FinalizePhase {
        stepId: D1StepId;
        executed: boolean;
        status: 'approved' | 'failed' | 'absent';
        error: string;
    }
    export interface D1FinalizeFinding {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
        ownerRef: string;
    }
    export interface D1FinalizeFile {
        defPath: string;
        action: 'generated' | 'preserved' | 'removed' | 'notGenerated';
        ownerRefs: string[];
        sourceHash: string;
        phase: string;
    }
    export interface D1FinalizeEnum {
        entityId: string;
        path: string;
        values: string[];
        consumed: boolean;
    }
    export interface D1FinalizePending {
        defPath: string;
        outputPath: string;
        present: boolean;
    }
    export interface D1FinalizeInventory {
        usecaseIds: string[];
        routes: string[];
        portIds: string[];
        tableIds: string[];
    }
    export interface D1FinalizeReport {
        schemaVersion: typeof D1_REPORT_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        repairOpened: false;
        executableBackend: false;
        inventoryNote: typeof INVENTORY_NOTE;
        defsStatus: 'complete' | 'incomplete' | 'notRun';
        materialization: 'pending' | 'none';
        outcome: 'complete' | 'held';
        blocking: string;
        phases: D1FinalizePhase[];
        findings: D1FinalizeFinding[];
        /** Steps that declared enum values stay on the domain draft. */
        declaredNotConsumedBy: string[];
        enumerations: {
            consumed: D1FinalizeEnum[];
            notConsumed: D1FinalizeEnum[];
        };
        files: D1FinalizeFile[];
        sources: Array<{
            path: string;
            sha256: string;
            state: string;
        }>;
        materializationPending: D1FinalizePending[];
        coverage: {
            checked: boolean;
            gaps: string[];
        };
        inventory: D1FinalizeInventory;
        snapshotHash: string;
    }
    export function parseFinalizeReport(text: string): D1FinalizeReport | null;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/gate" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the request. Does not call a model, does not open a repair, and does
     * not treat a missing future `.ts` as a missing def.
     */
    export function buildD1Finalize(request: D1FinalizeRequest): D1FinalizeReport;
    export function earlierHold(pipeline: D1FinalizeRequest['pipeline']): boolean;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/io" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the checkpoint, the snapshot, the drafts and the defs on disk.
     * It does not run an earlier phase and it does not call a model.
     */
    export function assembleD1Finalize(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        request: D1FinalizeRequest;
    }>;
    export function writeD1Report(project: number, moduleName: string, report: D1FinalizeReport): Promise<boolean>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/agentDefsL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry";
    import "_102021_/l2/agentDefsL1/steps/input20/agentD1Input";
    import "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain";
    import "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence";
    import "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases";
    import "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers";
    import "_102021_/l2/agentDefsL1/steps/support70/agentD1Support";
    import "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaCatalog" {
    import type { D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Absence, type D1Catalog, type D1Justification, type D1MeasuredPlan } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    /**
     * Consulta declares storage.target moduleDatabase. The other four are kind role
     * and cite the MDM catalog. They have no local table.
     */
    export const AGENDA_ENTITY_STORAGE: Record<string, D1StorageTarget>;
    export const AGENDA_JUSTIFICATIONS: D1Justification[];
    export const AGENDA_ABSENCES: D1Absence[];
    export function agendaCatalog(plan: D1MeasuredPlan): D1Catalog;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaExamples" {
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Catalog, type D1MeasuredPlan, type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export interface D1Example {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export function agendaExamples(catalog: D1Catalog, plan: D1MeasuredPlan): D1Example[];
    /** The listConsulta example also points at L2 contracts. Those paths are not outputs of this catalog. */
    export function listConsultaWithContracts(example: D1Example): D1Example;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1TestHost" {
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export interface StoredFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        status: string;
        versionRef: string;
        content: string;
        updatedAt: string;
        getValueInfo: () => Promise<{
            content: string;
        }>;
        getContent: () => Promise<string>;
    }
    export interface TestHost {
        files: Record<string, StoredFile>;
        writes: string[];
        setProject: (project: number) => void;
    }
    export function fileKey(info: {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }): string;
    export function installStudio(project: number): TestHost;
    export function seed(host: TestHost, info: D1FileInfo, content: string, updatedAt?: string): StoredFile;
    /** Host stor whose diskPath closes over a private field. Detaching the method throws. */
    export class HostStor {
        #private;
        readonly files: Record<string, StoredFile>;
        readonly writes: string[];
        getKeyToFile(info: D1FileInfo): string;
        addOrUpdateFile(params: D1FileInfo & {
            status?: string;
        }): Promise<StoredFile>;
        readonly localStor: {
            setContent: (file: StoredFile, value: {
                content?: string | null;
            }) => Promise<boolean>;
            listFolder: (project: number, level: number, folder: string) => D1FileInfo[];
            deleteFile: (file: StoredFile) => void;
        };
        diskPath(info: D1FileInfo): string;
    }
    export function installClassHost(project: number, host: HostStor): void;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/fixtures/cases" {
    import type { D1UsecasePlanInput, D1UsecaseRequest, D1UsecaseSelection } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export function frozenRouteCount(): number;
    export function coreUsecaseRequest(): D1UsecaseRequest;
    /** Fixture steps. registrarAtendimento does not invent an attendanceNote payload. */
    export function fixturePlan(request: D1UsecaseRequest, usecase: D1UsecaseSelection): D1UsecasePlanInput;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/fixtures/cases" {
    import type { D1ContractSource, D1ControllerRequest, D1ControllerRoute } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export function frozenControllerCounts(): {
        routes: number;
        pages: number;
    };
    export function coreControllerRequest(): D1ControllerRequest;
    /** One contract file per page. listConsulta is two shapes. A wide unused interface is not a binding. */
    export function contractSources(moduleName: string, routes: readonly D1ControllerRoute[]): D1ContractSource[];
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/fixtures/cases" {
    /** Synthetic ontologies. They are not a product module. Ids are exact and local to each case. */
    export const cycleEntities: {
        Alpha: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
        Beta: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    back: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    export const missingRefEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    export const ambiguousRefEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    /** A string whose name ends in Id is not a reference. A record points at Target by `to`. */
    export const suffixEntities: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    targetId: {
                        type: string;
                    };
                    link: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
        Target: {
            entityId: string;
            kind: string;
            source: string;
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** Nested object stays on the owner. One business value stays an enum. */
    export const nestedEnumEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    details: {
                        type: string;
                        fields: {
                            note: {
                                type: string;
                            };
                            subtype: {
                                type: string;
                                values: {
                                    value: string;
                                }[];
                            };
                        };
                    };
                };
            };
        };
    };
    /** Same dotted path from a literal key and from a real nest. */
    export const fieldCollisionEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    'details.note': {
                        type: string;
                    };
                    details: {
                        type: string;
                        fields: {
                            note: {
                                type: string;
                            };
                        };
                    };
                };
            };
        };
    };
    export const timeEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            lifecycleStates: {
                state: string;
                reachedBy: string;
            }[];
            transitions: {
                transitionId: string;
                from: string[];
                to: string;
                by: string[];
                ruleRefs: string[];
            }[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** Time state kept, and not written by a transition. */
    export const timeKeptEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            rules: string[];
            lifecycleStates: {
                state: string;
                reachedBy: string;
            }[];
            transitions: any[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** An NS4 field list is not rewritten into the v3 map. */
    export const ns4Entity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            fields: {
                fieldId: string;
                type: string;
            }[];
            record: {
                fields: any[];
            };
        };
    };
    export const sharedCatalog: {
        rules: {
            'rule-foreign-namespace-refused': string;
        };
    };
    export const platformRole: {
        PersonRole: {
            entityId: string;
            kind: string;
            source: string;
            rules: string[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    export const moduleRulesWithCamelTwin: {
        rules: {
            ruleForeignNamespaceRefused: string;
            openOnly: string;
        };
    };
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/fixtures/cases" {
    /**
     * Physical names measured on the buildFlowFsm change-order defs:
     * the table says `change_order` and the adapter citation says `change_orders`.
     * The pair is the fixture. It is not a finding against another generator.
     */
    export const MEASURED_TABLE_NAME = "change_order";
    export const MEASURED_TABLE_REF = "change_orders";
    export const changeOrderEntity: {
        ChangeOrder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
                table: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                        indexed: boolean;
                    };
                    title: {
                        type: string;
                        required: boolean;
                    };
                };
            };
        };
    };
    /** Nested nullable `details.note`, plus a derived `version` that is not indexed. */
    export const noteEntity: {
        Note: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
                table: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                        indexed: boolean;
                    };
                    version: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                    };
                    details: {
                        type: string;
                        required: boolean;
                        fields: {
                            note: {
                                type: string;
                            };
                        };
                    };
                };
            };
        };
    };
    export const roleEntity: {
        PersonRole: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                    };
                };
            };
        };
    };
}
declare module "_102021_/l2/agentDefsL1/steps/support70/fixtures/cases" {
    import type { D1SupportAdapter, D1SupportRequest } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /**
     * Measured from the frozen agendaClinica controller fixture: 7 grants, 1 live adapter.
     * The scope plans are the ones controllers60 already resolved. The anchor is not corrected.
     */
    export function coreSupportRequest(): D1SupportRequest;
    /**
     * Measured from the frozen agendaClinica journeys and Consulta model.
     * Four roles stay MDM. Only Consulta is a local table. No row values are present in the sources.
     */
    export function agendaSeedRequest(): D1SupportRequest;
    export function consultaAdapter(moduleName: string): D1SupportAdapter;
    export function adapterPipelineId(project: number, moduleName: string, portId: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ClassicDefs" {
    /**
     * The untyped defs shape of the classic L4 emission, and its reader — PURE, with no storage import.
     * It lives apart from ns4Fs.ts on purpose: ns4Fs pulls in libModel, whose top-level event listener
     * crashes the l2 test stub, and the write/read round trip of these files must stay testable.
     */
    export interface Ns4ClassicDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function ns4ClassicDefsSource(fileInfo: Ns4ClassicDefsFile, exportName: string, value: unknown): string;
    /** Reads a defs file back to its data, exactly as the storage reader does. */
    export function parseNs4ClassicDefsSource<T>(source: string): T | null;
    export function extractNs4ClassicJsonObject(source: string): string;
    /** The single brace/string scanner shared by readers and byte-preserving rewriters. */
    export function scanNs4ClassicJsonObject(source: string): {
        start: number;
        end: number;
    } | null;
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Shape of the level-1 ontology as the solution agents read it. Until ns5_43 these types described files
     * emitted into l4/organization/ontology; that emitter and those files are gone. `level1Catalog.ts`
     * (mls-102035) now derives this shape from l4/ontology/mdm.defs.ts, so these are a READING form and no
     * longer a source.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformEvent {
        eventId: string;
        on: string;
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                services?: readonly string[];
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
        /** Platform events a module may receive with `inbound.from: 'organization'`. No handler in alpha. */
        events?: readonly MdmPlatformEvent[];
    }
}
declare module "_102035_/l2/agentNewSolution/helpers/organizationTypes" {
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    /**
     * A papel of a module over a level-1 subtype. ns5_43 T4 names the three parts the way the v3 ontology
     * names them (`Ns5OntologyRoleV3`): `subtype` is the MDM subtype, `roleTag` is what `attachRole` writes
     * into `identification.tags`. Registries written before ns5_43 carry `mdmSubtype`/`role` instead; they
     * are read through `ns4RegistryRoleSubtype` / `ns4RegistryRoleTag` and rewritten on the next finalize80.
     */
    export interface Ns4SolutionRegistryRole {
        subtype: string;
        roleTag: string;
        namespace: string;
        /** Legacy spelling of `subtype`, written before ns5_43. Never written again. */
        mdmSubtype?: string;
        /** Legacy spelling of `roleTag`, written before ns5_43. Never written again. */
        role?: string;
    }
    export function ns4RegistryRoleSubtype(role: Ns4SolutionRegistryRole): string;
    export function ns4RegistryRoleTag(role: Ns4SolutionRegistryRole): string;
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    /** Entities this module owns. Siblings read this list instead of opening ontology files. */
    export interface Ns4SolutionRegistryEntity {
        entityId: string;
        /** v2 `kind`, or the v3 `role` / `entity`. */
        kind: string;
        mdmSubtype?: string;
        /** v3 table only: `core | event | supporting`, which v2 carried in `kind` (ns5_43 T4). */
        class?: string;
    }
    /** Outbound events this module publishes. `on` is `Entity.transitionId` or `Entity.create`. */
    export interface Ns4SolutionRegistryEvent {
        eventId: string;
        on: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        entities?: Ns4SolutionRegistryEntity[];
        events?: Ns4SolutionRegistryEvent[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102034_/l1/mdm/defs/ontologyTypes" {
    /**
     * The grammar of the platform ontology — the types `l4/ontology/mdm.defs.ts` is written against, and that
     * `l2/mdm/resolveMdmEntity.ts` and the module ontology of `mls-102035/l2/solution/types.ts` read.
     *
     * A record is `{ id, version, details }`, mirroring `mdm_documents`: `id` and `version` are columns and
     * `details` is the JSONB document, laid out as a map of branches — `identification` (the fields that are
     * also columns of the index table), `base` (common to every subtype), `<subtype>` (exactly one per
     * record), `general` (the organization) and `<moduleId>` (the module namespace). The base is declared
     * ONCE, instead of being repeated in each of the 13 subtypes.
     *
     * Defaults are omitted, not written: `required: false`, `nullable: false`, `title` equal to the id, and
     * the layer — which the branch already gives, since `identification` is a column and every other branch
     * lives in the document.
     *
     * `InferMdmRecord` derives the runtime type of a record from the ontology data, so `tsc` keeps code and
     * ontology on one shape instead of a hand-written interface that drifts.
     */
    /** The scalar forms a field may take. */
    export type MdmScalarKind = 'string' | 'text' | 'integer' | 'number' | 'money' | 'boolean' | 'date' | 'timestamp' | 'uuid';
    export type MdmValueTypeName = 'Address' | 'GeoPoint' | 'PrivacyConsent' | 'ContactSummary';
    export type MdmSubtypeName = 'Person' | 'Company' | 'ContactChannel' | 'Animal' | 'Product' | 'Service' | 'Location' | 'BankAccount' | 'Document' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment';
    /**
     * A field of the closed form. Absent flag = the default; `type` plus its own constraints carry everything,
     * so a constraint is never prose. `of` names a reusable type, `to` a record this one points at — both
     * checked by the compiler because they are unions of the declared names, not `string`.
     */
    export interface MdmDefField {
        type: MdmScalarKind | 'enum' | 'object' | 'record';
        required?: true;
        nullable?: true;
        collection?: true;
        /** A reusable type of `types`. */
        of?: MdmValueTypeName;
        /** Subtypes this field may point at. */
        to?: readonly MdmSubtypeName[];
        /** Closed domain. Plain strings when the label is the code itself. */
        values?: readonly string[];
        /** Inline object. */
        fields?: MdmDefFields;
        maxLength?: number;
        pattern?: string;
        min?: number;
        max?: number;
        default?: string | number | boolean;
        /** On `details` only: the branches the document is split into. */
        groups?: readonly string[];
        unique?: true;
        /** Backed by a real index today (a column of `identification` without it is a column with no index). */
        indexed?: true;
        /** The engine writes it; no form and no tool schema ever asks for it. */
        derived?: true;
        /** Only when it differs from the id. */
        title?: string;
        description?: string;
    }
    export type MdmDefFields = Readonly<Record<string, MdmDefField>>;
    /** Catalog entry. `from`/`to` are subtype names, so a typo is a compile error and not a dead link. */
    export interface MdmDefRelationship {
        type: string;
        title: string;
        description: string;
        from: readonly MdmSubtypeName[];
        to: readonly MdmSubtypeName[];
        bidirectional: boolean;
        /** Values `mdm_relationship.role` accepts for this type. Empty when the type has no meaningful role. */
        roles: readonly string[];
        /** Keys the engine writes on each side's `relationshipRefs`, derived from `mapRelationshipKeys`. */
        compactKeys: {
            from: readonly string[];
            to: readonly string[];
        };
    }
    /**
     * One branch of `details`. `open: true` means the key set is not closed here: `general` is declared by the
     * organization in the project registry, and each module declares its own namespace in its own ontology.
     */
    export interface MdmDefGroup {
        type: 'object';
        owner: 'platform' | 'organization' | 'module';
        description: string;
        fields?: MdmDefFields;
        open?: true;
    }
    /**
     * A subtype carries only its DELTA: its own fields, and the capabilities and rules that are not universal.
     * The ids are plain strings here and are checked against the catalogs of the ontology object itself, in
     * `mdmOntology.test.ts` — the file is one JSON literal, so there is no `keyof typeof` to lean on inside it.
     */
    export interface MdmSubtypeDef {
        title?: string;
        description: string;
        fields: MdmDefFields;
        /** Only what does NOT apply to every subtype. */
        capabilities?: readonly string[];
        /** Only what does NOT apply to every subtype. */
        rules?: readonly string[];
    }
    export interface MdmOntology {
        schemaVersion: string;
        /** The three columns of `mdm_documents`, as fields, plus what a screen shows to recognise the record. */
        record: {
            fields: MdmDefFields;
            displayField: string;
        };
        types: Readonly<Record<MdmValueTypeName, MdmDefFields>>;
        /** The branches of `details`: `identification`, `base`, `general` and `<moduleId>`. The subtype branch
         * is not here — it comes from `subtypes.<S>.fields`, one per record. */
        groups: Readonly<Record<string, MdmDefGroup>>;
        subtypes: Readonly<Record<MdmSubtypeName, MdmSubtypeDef>>;
        relationships: readonly MdmDefRelationship[];
        /** id → one sentence: what it does · how · who uses it · platform: ready|partial|missing. */
        capabilities: Readonly<Record<string, string>>;
        /** id → one sentence: what is always true · who enforces it · platform. */
        rules: Readonly<Record<string, string>>;
        statuses: readonly string[];
        docTypes: readonly string[];
        storage: {
            indexTable: string;
            prospectIndexTable: string;
            documentTable: string;
            documentColumn: string;
            /** Document-visible columns that carry a real index today. */
            indexedColumns: readonly string[];
            reservedKeys: readonly string[];
        };
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    /**
     * The three families of data, by NATURE, not by origin (`hdm`/`vdm` classify origin and are another
     * axis): `mdm` is the master record of the organization, shared between modules; `tdm` is the movement,
     * the event, the operation of one module; `ddm` is what is recalculated from the other two and has no
     * writer at all.
     */
    export type DataFamilyName = 'mdm' | 'tdm' | 'ddm';
    /** What the platform really offers today for a capability. Measured, never promised. */
    export type DataFamilyReadiness = 'ready' | 'partial' | 'missing';
    /**
     * One capability of a family catalog. `sentence` is the same three-part line the `mdm` catalog writes as
     * prose (what it does · how · who uses it), `platform` the measured status, and `evidence` where it was
     * measured — `file.ts:line` or a section of `l1/mdm/mdmImplementation.md`. `evidence` is for whoever
     * reviews this file; the projection that reaches a prompt drops it.
     */
    export interface DataFamilyCapability {
        sentence: string;
        /** `table`: the module table engine itself. `platform`: lent by an MDM service. */
        source: 'table' | 'platform';
        platform: DataFamilyReadiness;
        evidence: string;
    }
    /**
     * The catalog a table of one family starts from, in the same spirit as `mdm.defs.ts`: the record it
     * carries, the lines the generator should keep in mind while writing it, what it may do, and the gap
     * between this file and the engine. `record.fields` uses the same field grammar as the platform record,
     * so `tsc` checks the shapes here too.
     */
    export interface DataFamilyOntology {
        schemaVersion: string;
        family: DataFamilyName;
        title: string;
        description: string;
        record: {
            fields: MdmDefFields;
        };
        /** One line each, read whole into the fan-out prompt: what this family's table looks like. */
        recommendations: readonly string[];
        capabilities: Readonly<Record<string, DataFamilyCapability>>;
        /** id → one sentence about where and how the rows live. */
        storage: Readonly<Record<string, string>>;
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    type ScalarOf<K extends MdmScalarKind> = K extends 'string' | 'text' | 'date' | 'timestamp' | 'uuid' ? string : K extends 'integer' | 'number' | 'money' ? number : K extends 'boolean' ? boolean : never;
    type DefValue<F extends MdmDefField, O extends MdmOntology> = F extends {
        type: 'enum';
    } ? (F extends {
        values: readonly (infer V)[];
    } ? V : string) : F extends {
        type: 'record';
    } ? string : F extends {
        type: 'object';
    } ? F extends {
        fields: MdmDefFields;
    } ? InferGroup<F['fields'], O> : F extends {
        of: infer V extends MdmValueTypeName;
    } ? InferGroup<O['types'][V], O> : object : F extends {
        type: infer K extends MdmScalarKind;
    } ? ScalarOf<K> : never;
    type DefWrapped<F extends MdmDefField, O extends MdmOntology> = F extends {
        collection: true;
    } ? DefValue<F, O>[] : DefValue<F, O>;
    type DefNulled<F extends MdmDefField, O extends MdmOntology> = F extends {
        nullable: true;
    } ? DefWrapped<F, O> | null : DefWrapped<F, O>;
    type DefRequiredKeys<T extends MdmDefFields> = {
        [K in keyof T]: T[K] extends {
            required: true;
        } ? K : never;
    }[keyof T];
    type DefOptionalKeys<T extends MdmDefFields> = Exclude<keyof T, DefRequiredKeys<T>>;
    /** One group of `details` as a runtime object. */
    export type InferGroup<T extends MdmDefFields, O extends MdmOntology> = {
        [K in DefRequiredKeys<T>]: DefNulled<T[K], O>;
    } & {
        [K in DefOptionalKeys<T>]?: DefNulled<T[K], O>;
    };
    /**
     * The record of one subtype: `{ id, version, details }`, `details` grouped. The subtype group is keyed by
     * the subtype name with a lowercase first letter (`Person` → `person`, `AssetVehicle` → `assetVehicle`),
     * and any other key is a module namespace — an object only that module writes.
     */
    type GroupFields<O extends MdmOntology, K extends string> = O['groups'][K] extends {
        fields: infer F extends MdmDefFields;
    } ? F : MdmDefFields;
    export type InferMdmRecord<O extends MdmOntology, S extends MdmSubtypeName> = {
        id: string;
        version: number;
        details: {
            identification: InferGroup<GroupFields<O, 'identification'>, O>;
        } & {
            base: InferGroup<GroupFields<O, 'base'>, O>;
        } & {
            [K in Uncapitalize<S>]: InferGroup<O['subtypes'][S]['fields'], O>;
        } & {
            general?: object;
        } & {
            [moduleId: string]: object;
        };
    };
}
declare module "_102035_/l2/solution/types" {
    import type { MdmDefField, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v2";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-11-ns5-ontology-v2";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_RULES_SCHEMA_VERSION_V2: "2026-09-16-ns5-rules-v2";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-12-ns5-workflows-v2";
    /**
     * ns5_48: v3 adds the `alert` stage (a recurring duty of a person). The shape is a superset of v2,
     * so there is ONE artifact interface and the version is a union — the same move ontology30 made with
     * `NS5_ONTOLOGY_SCHEMA_VERSION_V3`. `workflows50` emits v3; the thirteen recorded runs stay v2 and
     * are replayed through `buildNs5WorkflowsArtifact`.
     */
    export const NS5_WORKFLOWS_SCHEMA_VERSION_V3: "2026-09-17-ns5-workflows-v3";
    export type Ns5WorkflowsSchemaVersion = typeof NS5_WORKFLOWS_SCHEMA_VERSION | typeof NS5_WORKFLOWS_SCHEMA_VERSION_V3;
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-12-ns5-access-v3";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-12-ns5-integration-v2";
    export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION: "2026-09-12-ns5-integration-request-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    /**
     * ns5_49: `workflows50` runs BEFORE `ontology30`. A process stage cites the entity and the transition
     * it makes happen; the ontology then declares them with the stage as owner.
     * ns5_62: `judge35` runs AFTER `ontology30` and BEFORE `rules40`/`access60`. Completeness of the
     * journeys is judged only once the ontology (and the processes) exist. The numeric suffixes are
     * identity, not order — they are frozen so recorded runs keep their step ids.
     */
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "workflows50", "ontology30", "judge35", "rules40", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 copies survivors onto access.defs.ts; finalize80 I3 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, Ns5OntologyDetail>;
    }
    export interface Ns5JourneyStep {
        /** Identity of the step; I6 names a handoff by this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /**
         * Required on `kind: act`. `create` opens the record (or attaches, when mdm);
         * `transition` applies `transitionRef`; `update` writes fields without a state change.
         * Readers: I2, master backend, master frontend.
         */
        effect?: 'create' | 'update' | 'transition';
        /**
         * Required iff `effect === 'transition'`. Ontology `transitionId` of `entity` (lowerCamel).
         * Readers: I2, master backend, master frontend.
         */
        transitionRef?: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from the pipeline (then access.defs.ts). */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyDetail {
        /** Typed JSON column and screen formatting. */
        type: Ns5OntologyField['type'];
        /** Planner / UI; rules may cite details.<name>. */
        description: string;
    }
    export interface Ns5OntologyEnumValue {
        /** Stable English lowerCamel code; status.enum.value covers lifecycleStates[].state. */
        value: string;
        /** Screen select/badge label in userLanguage. */
        title: string;
    }
    export interface Ns5OntologyFieldConstraints {
        /** Inclusive lower bound; number, integer or money. */
        min?: number;
        /** Inclusive upper bound; number, integer or money. */
        max?: number;
        /** string or text only. */
        maxLength?: number;
        /** money or number only. */
        precision?: number;
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Simple uniqueness; DDL unique index. Never the identity field. */
        unique?: boolean;
        /** Closed domain; value is the code, title is the screen label. */
        enum?: Ns5OntologyEnumValue[];
        /** Intrinsic to the type (day 1..31, percent 0..100). Never a business policy. */
        constraints?: Ns5OntologyFieldConstraints;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** kind mdm only: level-1 fields this role uses (selection, tightened domain); stores nothing in the module. Readers: f2_04b screen, access60 (ns5_35), masters. */
        fieldsBase?: Ns5OntologyField[];
        /** Composite uniqueness; fieldIds of this entity, never idField. finalize80 I9. */
        uniqueKeys?: string[][];
        /** Calculated values; typed JSON column; rules may cite details.<name>. */
        details?: Record<string, Ns5OntologyDetail>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
        /**
         * How this entity is written. Omitted = `journey` (an `act` writes it as `entity` or `affects`).
         * `crud` = reference catalog nobody creates in a journey (no lifecycle); master
         * frontend emits a data grid, master backend emits CRUD usecases.
         * `inbound` = created/updated by an integration inbound item; integration70 requires
         * a matching `inbound.writes` row. ontology30 normalize drops `crud`/`inbound` when
         * an act already writes the entity. ontology30 / access60 / finalize80 I10 I8.
         * Replaces `maintenance?: 'crud'` (ns5_31).
         */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** Ontology screen edge label; master frontend. One sentence, userLanguage. */
        description: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V3: "2026-09-15-ns5-ontology-v3";
    /**
     * v3.1 (ns5_47): what nobody writes is a `derived` field of the row (`description` says the condition), not a
     * lifecycle state; `time` is therefore gone from `reachedBy` and from `by`. The v3 artifacts already
     * recorded stay readable — the form only lost a way of saying something, so every reader accepts both
     * versions through `isNs5OntologyV3Version` and only the generator emits v3.1.
     */
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V31: "2026-09-17-ns5-ontology-v3.1";
    export type Ns5OntologySchemaVersionV3 = typeof NS5_ONTOLOGY_SCHEMA_VERSION_V3 | typeof NS5_ONTOLOGY_SCHEMA_VERSION_V31;
    /** Every reader of the v3 form asks this, never an equality against one constant. */
    export function isNs5OntologyV3Version(value: unknown): value is Ns5OntologySchemaVersionV3;
    /** Closed-domain value of a v3 field: the bare code, or the code plus its label. */
    export type Ns5OntologyValueV3 = string | {
        value: string;
        title?: string;
        description?: string;
    };
    /** One field of a v3 record. The platform grammar, widened where a module needs it (see above). */
    export interface Ns5OntologyFieldV3 extends Omit<MdmDefField, 'to' | 'values' | 'fields' | 'groups'> {
        /** MDM subtypes AND entity ids of this module. */
        to?: readonly string[];
        values?: readonly Ns5OntologyValueV3[];
        fields?: Ns5OntologyFieldsV3;
        /**
         * Only on a branch of `details`: who writes it. `platform` = the MDM record,
         * `organization` = the promoted layer, `module` = `details.<moduleName>`.
         */
        owner?: 'platform' | 'organization' | 'module';
        /** Only on a branch: the key set is not closed here (declared elsewhere). */
        open?: true;
    }
    export type Ns5OntologyFieldsV3 = Readonly<Record<string, Ns5OntologyFieldV3>>;
    /** One named link of an entity. `relationshipId` is the row of the module index that carries it. */
    export interface Ns5OntologyRelationshipV3 {
        /** Must exist in `index.defs.ts`; that index is the source, this is the reading copy. */
        relationshipId: string;
        /** Entity id of this module, or an MDM subtype. */
        to: string;
        /**
         * `mode: 'fk'` — the column that holds it; `mode: 'throughTable'` — the table walked;
         * absent mode — the MDM relationship type of `mdm.relationships[].type`.
         */
        via: string;
        mode?: 'fk' | 'throughTable';
        /** Which end of the catalog link this entity sits on, when it is not the `from`. */
        direction?: 'from' | 'to';
        /** Role of `mdm_relationship.role`, single or many. */
        role?: string;
        roles?: readonly string[];
        cardinality: '1:1' | '1:N' | 'N:1' | 'N:N';
        /** `true`, or the condition in the user language ("quando menor de 18 anos"). */
        required?: boolean | string;
        /** Walked, never stored. */
        derived?: true;
        /** Only on `throughTable`: the walk, as written. */
        path?: string;
        /** Planner / screen. */
        title: string;
        description?: string;
        /** Narrows the far end, field → accepted values. */
        target?: Readonly<Record<string, readonly string[]>>;
    }
    /** What a `role` and a table share. Exported so `nsArtifactFieldRatchet.test.ts` can reach its keys. */
    export interface Ns5OntologyEntityV3Base<Cap extends string = string, Rule extends string = string> {
        /** Gate: the v3 form. */
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        title: string;
        description: string;
        /** Path a screen shows to recognise the record: `details.identification.name`, `scheduledAt`. */
        displayField: string;
        /** `{ id, version, details }` on a role; plus the indexed columns on an entity. */
        record: {
            fields: Ns5OntologyFieldsV3;
        };
        /** Composite uniqueness, by field id. */
        uniqueKeys?: readonly (readonly string[])[];
        /** ns5_47: only what somebody moves. A condition over data is a `derived` field of the row. */
        lifecycleStates?: readonly {
            state: string;
            reachedBy: 'actor' | 'command';
        }[];
        transitions?: readonly {
            transitionId: string;
            from: readonly string[];
            to: string;
            /** Actor ids of the module; empty when a process owns the move. */
            by: readonly string[];
            description: string;
            /** Record paths the transition command consumes; an explicit empty list means identity only. */
            payload?: readonly string[];
            ruleRefs?: readonly string[];
        }[];
        relationships: Readonly<Record<string, Ns5OntologyRelationshipV3>>;
        /**
         * id → one sentence. A platform id of `mdm.capabilities`, or `<moduleName>.<id>`.
         * Optional per key because an entity picks from the catalog; that `Cap` is an upper bound and not a
         * requirement. Assigning a `const` here therefore does NOT reject an invented id (no excess-property
         * check off a fresh literal) — a reader that wants that proof asserts `Exclude<keyof …, Cap>` is
         * `never`, as `resolveMdmEntity.test.ts` does.
         */
        capabilities: {
            readonly [K in Cap]?: string;
        };
        /** Ids of `mdm.rules` ∪ `ruleId` of the module `rules.defs.ts`. */
        rules: readonly Rule[];
        /** How the entity is written, when it is not a journey. */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    /** A papel of this module over an MDM record. Stores nothing but `details.<moduleName>`. */
    export interface Ns5OntologyRoleV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'role';
        /** The MDM subtype the papel sits on; must be a key of `mdm.subtypes`. */
        subtype: MdmSubtypeName;
        /** `<moduleName>.<entityId>`; what `attachRole` writes into `identification.tags`. */
        roleTag: string;
        /** The platform ontology this papel copies from. */
        source: string;
    }
    /** A table of the module. */
    export interface Ns5OntologyTableV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'entity';
        class: 'core' | 'event' | 'supporting';
        /**
         * `kind` is the family's storage (ns5_46): `relational` is one Postgres table of the module,
         * `timeSeries` a series chunked by time. Optional because the hand-written v3 form predates it and a
         * table without it is read as `relational`.
         */
        storage: {
            target: 'moduleDatabase';
            table: string;
            kind?: 'relational' | 'timeSeries';
        };
    }
    export type Ns5OntologyEntityV3<Cap extends string = string, Rule extends string = string> = Ns5OntologyRoleV3<Cap, Rule> | Ns5OntologyTableV3<Cap, Rule>;
    /** One row of the v3 index: the canonical list of entities. */
    export interface Ns5OntologyIndexEntityV3 {
        entityId: string;
        kind: 'role' | 'entity';
        /** On `role` only. */
        subtype?: MdmSubtypeName;
        /** On `entity` only. */
        class?: 'core' | 'event' | 'supporting';
    }
    /** One row of the v3 index: the canonical list of links. The entities repeat these for reading. */
    export interface Ns5OntologyIndexRelationshipV3 {
        relationshipId: string;
        from: string;
        to: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        mode: 'fk' | 'mdmRelationship' | 'throughTable';
        /** `mode: 'fk'`: the column, as `Entity.field`. */
        field?: string;
        /** `mode: 'mdmRelationship'`: a `type` of `mdm.relationships`. */
        catalogType?: string;
        /** `mode: 'throughTable'`: the entity walked. */
        through?: string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        description: string;
    }
    export interface Ns5OntologyIndexV3 {
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        businessDomain: string;
        /** Path of the platform ontology this module is written on top of. */
        platformOntology: string;
        /** The branch of `details` only this module writes. */
        moduleNamespace: {
            key: string;
            description: string;
        };
        entities: readonly Ns5OntologyIndexEntityV3[];
        relationships: readonly Ns5OntologyIndexRelationshipV3[];
    }
    /** What a reader gets from an ontology entity file, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5OntologyAnyEntity = Ns5OntologyEntityArtifact | Ns5OntologyEntityV3;
    /** The discriminator every reader of a written entity uses; accepts v3 and v3.1 alike (ns5_47). */
    export function isNs5OntologyEntityV3(entity: Ns5OntologyAnyEntity): entity is Ns5OntologyEntityV3;
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    /**
     * The same catalog as a MAP, aligned with `mls-102034/l4/ontology/mdm.defs.ts`, whose `rules` and
     * `capabilities` are both `Record<id, sentence>` — one id, one sentence, no place to put a second.
     * `rules40` emits this form; the v1 array above stays valid and is still what the recorded runs hold.
     * Read either form through `solution/rulesView.ts`, never by branching on the field.
     *
     * The TOOL still asks for `[{ ruleId, description }]`: a strict tool schema must declare
     * `additionalProperties: false` on every object, so an open key set is not expressible
     * (`steps/ontology30/contractsV3.ts:175` says the same of `record.fields` and `capabilities`).
     * Array to map is the normalize's job.
     */
    export interface Ns5RulesArtifactV2 {
        /** Discriminates the two forms. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION_V2;
        /** Folder. */
        moduleName: string;
        /** `ruleId` to the one business sentence; I4 checks cited ruleRefs exist. */
        rules: Readonly<Record<string, string>>;
    }
    /** What a reader gets from `rules.defs.ts`, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5RulesAny = Ns5RulesArtifact | Ns5RulesArtifactV2;
    export interface Ns5WorkflowTrigger {
        /** Gate: scheduled needs schedule, event needs event, manual needs actorRef. */
        kind: 'scheduled' | 'event' | 'manual';
        /** Required iff kind === 'scheduled'. Prose ("every month, day 1"). Backend job. */
        schedule?: string;
        /** Required iff kind === 'event'. '<Entity>.<transitionId>' of this module (inbound '<mod>.<eventId>' is ns5_31). */
        event?: string;
        /** Required iff kind === 'manual'. */
        actorRef?: string;
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. Unique in the process. */
        taskId: string;
        /**
         * Gate: no neutral value; every stage is one of these. `alert` (v3, ns5_48) is a recurring duty
         * of a person: the schedule is on `trigger`, the instruction is the `description`, and it carries
         * neither journeyRef nor entityRef.
         */
        kind: 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
        /** Required on human and on alert. */
        actorRef?: string;
        /** Required on human, forbidden on alert. The journey the person runs, never a screen step. */
        journeyRef?: string;
        /** Required on mechanical|llm. Entity the stage acts on. */
        entityRef?: string;
        /** Required on mechanical|llm. Same form as act.effect (ns5_28). */
        effect?: 'create' | 'update' | 'transition';
        /** Required iff effect === 'transition'. Ontology transitionId; by is system or the actor. */
        transitionRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. Wait: the pause (time or event) in prose. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** How the process starts. Tela da Fase 2, harness, backend job. */
        trigger: Ns5WorkflowTrigger;
        /** finalize80 I6: every journey handoff appears as a human journeyRef. */
        tasks: Ns5WorkflowTask[];
    }
    export interface Ns5JourneyDecision {
        /** Must exist in the journey index. Tela da Fase 2 shows why a journey stayed out. */
        journeyId: string;
        /** One decision per journey in the same LLM call. */
        inProcess: boolean;
        /** Required iff inProcess. */
        processId?: string;
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty processes is valid. v2 recorded on disk stays readable. */
        schemaVersion: Ns5WorkflowsSchemaVersion;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
        /** One row per journey; the screen lists who is in a process. */
        journeyDecisions: Ns5JourneyDecision[];
        /** workflows50 normalize: dropped duplicate stages. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. Unique. */
        grantId: string;
        /** Must be an actorId from access.actors. */
        actorRef: string;
        /** Access matrix screen. */
        title: string;
        /** Access matrix screen. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Copied from the pipeline (survivors of the journeys20 drop). The LLM does not rewrite this list. */
        actors: Ns5ModuleActor[];
        /** The grant is the capability. Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. Unique across inbound and outbound. */
        id: string;
        /** Gate vs registry / plugin catalogue / platform events. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** Inbound source: sibling module, `organization` (platform catalog), or external system. */
        from?: string;
        /** Outbound destination: sibling module, `any`, or external system. */
        to?: string;
        /** Event id this row receives (inbound) or publishes (outbound). Defaults to `id`. */
        event?: string;
        /**
         * Inbound: entities of this module the arrival creates/updates.
         * Counts as a writer (ontology30 WITHOUT_WRITER, access60, I10) and as `trigger.event`.
         */
        writes?: string[];
        /** Inbound: what the arrival does to `writes`. Required on inbound. */
        effect?: 'create' | 'update' | 'transition';
        /** Inbound, required iff `effect === 'transition'`. */
        transitionRef?: string;
        /**
         * Outbound: when this module publishes. `Entity.transitionId` or `Entity.create`.
         * Payload is the entity record at that moment (not declared in l4). I12 checks it exists.
         */
        on?: string;
        /** Planner / UI. Cites `inbound.id` when the rule maps a sibling payload. */
        description: string;
        /** Outbound (and inbound leftover): entity ids this row touches. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** `journeyId.stepId` or `processId.taskId` that uses the plugin. I12. */
        usedBy: string[];
    }
    /** Queued request that a sibling (or a predicted module) publish an event. */
    export interface Ns5IntegrationRequestArtifact {
        schemaVersion: typeof NS5_INTEGRATION_REQUEST_SCHEMA_VERSION;
        requestedBy: string;
        eventId: string;
        on?: string;
        entityRefs: string[];
        description: string;
        status: 'requested';
        /** Organization inbox: the predicted module that should publish. */
        to?: string;
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    /** Form change recorded on `pipeline.json` `steps.<step>`. Shape is step-specific. */
    export interface Ns5PipelineNormalization {
        kind: string;
        detail: string;
        entityId?: string;
        grantId?: string;
        journeyId?: string;
        stepId?: string;
        inboundId?: string;
    }
    export interface Ns5PipelineLiftedField {
        entityId: string;
        detail: string;
    }
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /**
         * module10: actors the normalize removed because they are external systems, not people
         * (`dropSystemActor<Actor>`). An external system the request names is a plugin or an inbound of
         * integration70, never an actor. The clarification/maintenance screen of Fase 2 reads this to
         * show what the step decided without asking.
         */
        systemDecisions?: Ns5SystemDecision[];
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /**
         * Form changes this step applied (pt→pt-BR, dropCrud, liftedFields, …).
         * Same records as the step draft `normalizations[]`. Fase 2 reads this.
         */
        normalizations?: Ns5PipelineNormalization[];
        /**
         * ontology30: extra fields discarded when a panel entity was lifted
         * (`normalizations[].kind === 'liftedFields'`).
         */
        liftedFields?: Ns5PipelineLiftedField[];
        /**
         * ontology30 v3: rule ids the entities cited, platform and module together. `rules40` receives the
         * module ones as data and has to produce them (ns5_42 T7 records it; ns5_43 T2 wires the reading).
         */
        citedRules?: string[];
        /** ontology30 v3: capability ids the entities cited, catalog and module together. */
        citedCapabilities?: string[];
        /** module10: actors born by the step. Later steps read them via `readNs5Actors`. */
        actors?: Ns5ModuleActor[];
        /** journeys20: actorIds dropped as inferred-external without an exclusive step. */
        droppedActors?: string[];
        /** workflows50: true when processes is [] because there is no handoff, no cross-actor decide and no time/event phrase in the prompt. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
        /** judge35: true when the deterministic candidate list was empty and the step approved without an LLM call. */
        noJudgeSignal?: boolean;
        /** judge35: `transitionUnjustified` verdicts recorded for the human; the transition is not deleted. */
        warnings?: string[];
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module (l1/l2/l4/l5 trees plus l5 json / registry). */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** Display paths unlinked under l1/l2/l4/l5/<module>/. */
        deleted: string[];
        /** Display paths rewritten (l5 jsons and the organization registry). */
        edited: string[];
        at: string;
    }
    /** Mailbox of the module pool: one folder per owner (`l4/<module>/pool/<box>/`). */
    export type PoolBox = 'l1' | 'l2' | 'l4';
    /** Implement = do it; estimate = simulate the change and answer the cost. */
    export type PoolMode = 'implement' | 'estimate';
    /** What the owner did with the message it processed. */
    export type PoolOutcome = 'delivered' | 'processed' | 'disputed';
    /**
     * One processed pool message, appended to `pipeline.json`. Readers: the pool screen (p4_04) and
     * L4 itself (round counting). Helpers in `/_102035_/l2/solution/pool.js`.
     */
    export interface PoolTraceLine {
        /** ISO timestamp of the trace. */
        at: string;
        /** Display path of the message file, e.g. `l4/<module>/pool/l2/<stamp>_<thread>_<round>.json`. */
        file: string;
        from: PoolBox;
        to: PoolBox;
        thread: string;
        round: number;
        mode: PoolMode;
        outcome: PoolOutcome;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        /** Pool trace, appended by `tracePool`. Absent in pipelines written before the pool existed. */
        pool?: PoolTraceLine[];
        /**
         * What `agentPlannerL4` entry10 added to `l5/config.json` (reader: that step).
         * Tokens like `workspaceDependencies:+102021`. Absent when nothing was missing.
         */
        l5Adjusted?: string[];
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
}
declare module "_102035_/l2/solution/fs" {
    import type { Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    import type { Ns5OntologyAnyEntity, Ns5PipelineState, Ns5StepId } from "_102035_/l2/solution/types";
    export type Ns5FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function normalizeModuleName(value: unknown, fallback?: string): string;
    /**
     * Point `moduleFolder` at a root relative to `l4/` (example: `stockControl/tobe/plan`).
     * `null` or `''` restores the canonical folder. Lives on the current `mls` (the task process).
     */
    export function setModuleRoot(moduleName: string, relativeRoot: string | null): void;
    /** `l4/<mod>` or the `/candidate` override when `setModuleRoot` was called. */
    export function moduleFolder(moduleName: string): string;
    export function moduleFile(moduleName: string): Ns5FileInfo;
    /** Read-only callers such as the Studio module browser must not depend on mls.actualProject. */
    export function moduleFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function journeyFile(moduleName: string, journeyId: string): Ns5FileInfo;
    export function journeyIndexFile(moduleName: string): Ns5FileInfo;
    export function ontologyEntityFile(moduleName: string, entityId: string): Ns5FileInfo;
    export function ontologyIndexFile(moduleName: string): Ns5FileInfo;
    export function rulesFile(moduleName: string): Ns5FileInfo;
    export function workflowsFile(moduleName: string): Ns5FileInfo;
    export function accessFile(moduleName: string): Ns5FileInfo;
    export function integrationFile(moduleName: string): Ns5FileInfo;
    /** `l4/<target>/tobe/integration/<requestedBy>--<eventId>.defs.ts` — no extra dot in shortName. */
    export function integrationRequestFile(targetModule: string, requestedBy: string, eventId: string): Ns5FileInfo;
    export function collectTobeIntegrationFilesCiting(moduleName: string): mls.stor.IFileInfo[];
    export function pipelineFile(moduleName: string): Ns5FileInfo;
    export function pipelineFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function pipelineJsonFile(moduleName: string, shortName: string): Ns5FileInfo;
    export function pipelineJsonFileForProject(project: number, moduleName: string, shortName: string): Ns5FileInfo;
    export function finalizeReportFile(moduleName: string): Ns5FileInfo;
    export function finalizeReportFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function listPipelineJsonShortNames(moduleName: string): string[];
    export function draftFile(moduleName: string, step: Ns5StepId | string): Ns5FileInfo;
    export function agentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function registryFile(): Ns5FileInfo;
    export function displayPath(fileInfo: Ns5FileInfo): string;
    export function assertShortName(shortName: string): void;
    export function fileExists(fileInfo: Ns5FileInfo): boolean;
    export function listModuleFolders(): Set<string>;
    export function isExactModuleFolder(folder: string, moduleName: string): boolean;
    export const MODULE_TREE_LEVELS: readonly [1, 2, 4, 5];
    export function isProtectedModuleFile(file: {
        level?: number;
        folder?: string;
        shortName?: string;
    }): boolean;
    export function listModuleL4Keys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** Index ∪ host disk of exact `l<level>/<mod>/**`. Never prefix; never protected paths. */
    export function collectExactModuleFiles(moduleName: string, levels?: readonly number[]): mls.stor.IFileInfo[];
    export type Ns5DefsKind = 'journeys' | 'ontology';
    type ListedStorFile = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    /** Host disk listing (`mls.stor.localStor.listFolder`); undefined outside the host. */
    export function hostListFolder(): ((project: number, level: number, folder: string) => ListedStorFile[]) | undefined;
    /** An `mls.stor.files` entry for a file seen on host disk but absent from the index. */
    export function diskFileInfo(info: ListedStorFile): mls.stor.IFileInfo;
    /** shortNames of `.defs.ts` in `l4/<mod>/<kind>/`, including status=deleted and host disk. */
    export function listModuleDefsShortNames(moduleName: string, kind: Ns5DefsKind): string[];
    export function ns5DefsOrphans(diskShortNames: string[], indexIds: string[]): string[];
    export function reconcileModuleDefs(moduleName: string, kind: Ns5DefsKind, indexIds: string[]): Promise<string[]>;
    export function readJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    export function writeJson(fileInfo: Ns5FileInfo, value: unknown): Promise<string>;
    export function writeDefs(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): Promise<string>;
    export function renderDefsSource(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): string;
    export function readPipeline(moduleName: string): Promise<Ns5PipelineState | null>;
    export function readPipelineForProject(project: number, moduleName: string): Promise<Ns5PipelineState | null>;
    export function writePipeline(state: Ns5PipelineState): Promise<string>;
    export function readAgentText(folder: string, shortName: string, extension?: string): Promise<string>;
    export function readAgentJson<T>(folder: string, shortName: string, extension?: string): Promise<T>;
    export function readDefsJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    /** Preserve the exact L4 source when sealing a release or copying it to the candidate. */
    export function readSourceText(fileInfo: Ns5FileInfo): Promise<string>;
    export function writeSourceText(fileInfo: Ns5FileInfo, source: string): Promise<void>;
    /**
     * An ontology entity file in whichever form it is written (ns5_39 T4). Both forms are one JSON literal,
     * so the reading is the same; only the type of what comes back changes, and `schemaVersion` is the
     * discriminator — v3 (`agendaClinica`) carries `record`, v2 (the other eleven modules) carries `fields`.
     */
    export function readOntologyEntityAny(fileInfo: Ns5FileInfo): Promise<Ns5OntologyAnyEntity | null>;
    export function readSolutionRegistry(): Promise<Ns4SolutionRegistryArtifact | null>;
}
declare module "_102035_/l2/solution/pool" {
    import type { Ns5FileInfo } from "_102035_/l2/solution/fs";
    import type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine } from "_102035_/l2/solution/types";
    export type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine };
    export const POOL_BOXES: readonly ["l1", "l2", "l4"];
    export const POOL_MODES: readonly ["implement", "estimate"];
    export const POOL_OUTCOMES: readonly ["delivered", "processed", "disputed"];
    /** Three rounds per side. At 3/3 without agreement the message is NOT deleted: it becomes a human pending. */
    export const POOL_MAX_ROUND = 3;
    /** The whole message. Nothing is optional; lists may be empty. */
    export interface PoolMessage {
        from: PoolBox;
        to: PoolBox;
        /** `<module>-<yyyymmddhhmmss>` of the message that opened the thread. */
        thread: string;
        /** 1..POOL_MAX_ROUND. */
        round: number;
        mode: PoolMode;
        /** One line. */
        subject: string;
        /** Paths relative to the module folder. */
        artifacts: string[];
        body: string;
    }
    /** `yyyymmddhhmmss` in UTC — the order of the mailbox is the order of the name. */
    export function poolStamp(now: Date): string;
    /** Thread id of a message that opens a conversation about `moduleName`. */
    export function nextThread(moduleName: string, now: Date): string;
    /** Rejects with a named cause; never repairs quietly. */
    export function normalizePoolMessage(value: unknown): PoolMessage;
    /** `l4/<module>/pool/<box>/<shortName>.json`, in the project of the run. */
    export function poolFile(moduleName: string, box: PoolBox, shortName: string): Ns5FileInfo;
    /**
     * Writes the message into the box of `msg.to`. `now` is explicit because the file name carries it
     * and the caller — not the clock — decides which moment the message belongs to.
     */
    export function writePoolMessage(moduleName: string, msg: unknown, now: Date): Promise<Ns5FileInfo>;
    /**
     * `<stamp>_<thread>_<round>`, o nome que o `writePoolMessage` gera. Um `.json` na caixa que não siga
     * isso não é mensagem do pool — a p2_09 põe um `menu.json` ali — e é **ignorado**, não é erro: a caixa
     * é de quem a lê, e nada impede o dono de guardar outro arquivo dentro dela.
     *
     * O padrão fica **frouxo de propósito**: o formato do `thread` e a faixa do `round` são recusados com
     * causa nomeada na leitura (`normalizePoolMessage`), e repeti-los aqui seria a mesma regra em dois
     * lugares. Mais importante: errar para o lado estrito esconderia uma mensagem real da caixa, e caixa
     * que parece vazia faz a guarda de pendência não disparar — é a direção cara do erro.
     */
    export function isPoolMessageShortName(shortName: string): boolean;
    /** Oldest first, by name. Index ∪ host disk, so a message written by another process is seen. */
    export function listPoolBoxForProject(project: number, moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function listPoolBox(moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function readPoolMessage(file: Ns5FileInfo): Promise<PoolMessage>;
    /** Any non-empty box — this is what blocks a new `tobe/`. */
    export function poolHasPending(moduleName: string): boolean;
    /**
     * Same normalize and return (`traceId`) as `tracePool`, but writes the line on the
     * `pipeline.json` that `fileInfo` points at — each owner traces on its own file.
     */
    export function tracePoolAt(fileInfo: Ns5FileInfo, line: unknown): Promise<string>;
    /**
     * Appends the line to `pipeline.json` and returns its id — the display path of the message,
     * which is unique per message and is what `deletePoolMessage` demands.
     * Shortcut: traces on the l4 pipeline of `moduleName`.
     */
    export function tracePool(moduleName: string, line: unknown): Promise<string>;
    /** Reads the trace at the given `pipeline.json` (empty when the file has none). */
    export function readPoolTraceAt(fileInfo: Ns5FileInfo): Promise<PoolTraceLine[]>;
    /** Reads the trace of the module (empty when the pipeline has none). */
    export function readPoolTrace(moduleName: string): Promise<PoolTraceLine[]>;
    /**
     * Same check and delete as `deletePoolMessage`, but the trace is read from the `pipeline.json`
     * that `fileInfo` points at — each owner traces (and therefore deletes) on its own file.
     */
    export function deletePoolMessageAt(fileInfo: Ns5FileInfo, file: Ns5FileInfo, traceId: string): Promise<string>;
    /**
     * Last operation of whoever processes a message: only the owner deletes, and only after the
     * trace line is written — `traceId` is the id `tracePool` returned. Shortcut: checks the l4
     * pipeline of `moduleName`.
     */
    export function deletePoolMessage(moduleName: string, file: Ns5FileInfo, traceId: string): Promise<string>;
}
declare module "_102021_/l2/agentPlannerL1/helpers/l1Inventory" {
    import type { OwnerStatus } from "_102021_/l2/agentChangeBackend/helpers/cbShared";
    export interface L1InventoryField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface L1InventoryFunction {
        name: string;
        input: L1InventoryField[];
        output: L1InventoryField[];
    }
    export interface L1InventoryUsecase {
        usecaseId: string;
        file: string;
        functions: L1InventoryFunction[];
        ports: string[];
        rulesApplied: string[];
        statusBackend: OwnerStatus | '';
    }
    export interface L1InventoryPort {
        portId: string;
        entity: string;
    }
    export interface L1InventoryTable {
        tableId: string;
        entity: string;
    }
    export interface L1Inventory {
        routes: string[];
        usecases: L1InventoryUsecase[];
        ports: L1InventoryPort[];
        tables: L1InventoryTable[];
        present: boolean;
    }
    /**
     * Snapshot of the existing l1 of `module` in `project`. Pure over `mls.stor`.
     * No l1 (and no backend block) ⇒ `present: false` and empty lists.
     * Status comes from `l5/<mod>/todoBackend.defs.ts owners[]`, never from `status: draft` in the defs.
     */
    export function readL1Inventory(project: number, moduleName: string): Promise<L1Inventory>;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Core" {
    import { type Ns5FileInfo } from "_102035_/l2/solution/fs";
    import { type PoolMessage, type PoolTraceLine } from "_102035_/l2/solution/pool";
    import type { Ns5PipelineStatus, Ns5PipelineStepState } from "_102035_/l2/solution/types";
    import { type L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    export const P1_FLOW_ID: "agentPlannerL1";
    export const P1_FLOW_VERSION: "2026-09-20-p1-flow-v1";
    export const P1_AGENT_NAME: "agentPlannerL1";
    export const P1_PIPELINE_SCHEMA_VERSION: "2026-09-20-p1-pipeline-v1";
    export const P1_NEEDS_SCHEMA: "2026-09-21-p2-needs-v1";
    export const P1_DEVICE: "web";
    export type P1Device = typeof P1_DEVICE;
    /** Steps the current flow.json actually runs. */
    export const P1_FLOW_STEP_IDS: readonly ["entry10", "plan20"];
    export const P1_STEP_IDS: readonly ["entry10", "plan20"];
    export type P1FlowStepId = typeof P1_FLOW_STEP_IDS[number];
    export type P1StepId = typeof P1_STEP_IDS[number];
    /** Last step of `docs/flow.json` — plan20 closes the pipeline. */
    export const P1_FLOW_LAST_STEP_ID: P1FlowStepId;
    export const P1_STEP_TITLES: Record<P1StepId, string>;
    export const P1_STEP_DEPENDS_ON: Record<P1StepId, readonly string[]>;
    /** Same default as `PL_DEFAULT_CANDIDATE_REL` in `plCore.ts`. */
    export const P1_DEFAULT_CANDIDATE_REL: "tobe/plan";
    export interface P1ParsedInvocation {
        module: string;
        /** Resolved `l4/` folder when `/candidate` is present; otherwise `''`. */
        candidate: string;
        /** True when the `/candidate` token was present, even if the path was refused. */
        hasCandidate: boolean;
    }
    export type P1EntrySource = {
        kind: 'hand';
        moduleName: string;
        candidate?: string;
    } | {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate?: string;
    };
    export interface P1Needs {
        schemaVersion: string;
        moduleName: string;
        device?: string;
        pages?: unknown[];
    }
    export interface P1PipelineState {
        schemaVersion: typeof P1_PIPELINE_SCHEMA_VERSION;
        flowId: typeof P1_FLOW_ID;
        moduleName: string;
        status: Ns5PipelineStatus;
        awaitingStep?: P1StepId;
        steps: Partial<Record<P1StepId, Ns5PipelineStepState>>;
        thread: string;
        round: number;
        messageFile: string;
        sourceMessages: string[];
        needsFile: string;
        inventory: L1Inventory;
        pool?: PoolTraceLine[];
        updatedAt: string;
    }
    export interface P1LoadedEntry {
        moduleName: string;
        file: Ns5FileInfo;
        message: PoolMessage;
        sourceMessages: string[];
        needsFile: Ns5FileInfo;
        needs: P1Needs;
    }
    export type P1LoadResult = P1LoadedEntry | {
        refusal: string;
    };
    export type P1ExecuteResult = {
        pipeline: P1PipelineState;
        file: Ns5FileInfo;
        message: PoolMessage;
    } | {
        refusal: string;
    };
    export function isP1StepId(value: string): value is P1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    /** Copied from `plCore.ts:111`. `..` in the relative path returns `''`. */
    export function resolveCandidateFolder(moduleName: string, relativePath?: string): string;
    /**
     * Point `moduleFolder` at `candidate`, or restore the canonical root when it is
     * empty. `..` is a refusal, not a silent "no candidate". Always call this before
     * reading l4 / pool / pipeline so a previous task cannot leak its root.
     */
    export function applyP1CandidateRoot(moduleName: string, candidate: string): string;
    /**
     * Maps child planIds back to the owning step. Done-anchors stay unmatched so they
     * are not dispatched. A step prompt `{ moduleName, thread, file }` (pool dispatch)
     * is entry10.
     */
    export function ownerStepId(planId: string, prompt?: string): P1StepId | '';
    export function isPoolEntryPrompt(prompt?: string): boolean;
    export function parseP1Invocation(value: string): P1ParsedInvocation;
    export function p1InvocationRefusal(invocation: P1ParsedInvocation): string;
    export type P1StepPrompt = {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate: string;
    } | {
        kind: 'entry';
        moduleName: string;
        candidate: string;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseP1StepPrompt(prompt: string): P1StepPrompt;
    /** `l1/<module>/pipeline/pipeline.json` in the project of the run. */
    export function p1PipelineFile(moduleName: string): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/needs.json` — written by L2, read here. */
    export function p1NeedsFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/l4diff.json` — written by L4 (p4_09). Absent is valid. */
    export function p1L4DiffFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l2/web/backend.json` — written by plan20. Not a pool message. */
    export function p1BackendFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    export function createP1Pipeline(moduleName: string, message: PoolMessage, messageFile: string, now: Date, sourceMessages: string[], needsFile: string, inventory: L1Inventory): P1PipelineState;
    export function createP1AgentStep(stepId: P1StepId, moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep;
    export function buildP1PlannedSteps(moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep[];
    export function isP1PoolMessageFile(shortName: string): boolean;
    export function p1DifferentRequestsRefusal(count: number): string;
    export function loadP1Entry(source: P1EntrySource): Promise<P1LoadResult>;
    export function writeP1Entry(loaded: P1LoadedEntry, now: Date): Promise<P1PipelineState>;
    export function executeP1Entry(source: P1EntrySource, now: Date): Promise<P1ExecuteResult>;
    export function readP1Pipeline(moduleName: string): Promise<P1PipelineState | null>;
    /** `l1/<module>/pipeline/<stepId>-draft.json` in the project of the run. */
    export function p1DraftFile(moduleName: string, stepId: P1StepId): Ns5FileInfo;
    /** Files of this agent (prompt.md, skills) live in 102021, not in the run module. */
    export function p1AgentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function readP1AgentText(folder: string, shortName: string, extension: string): Promise<string>;
    /** `complete` = every step of `flow.json` is approved. A failed pipeline stays failed. */
    export function markP1Complete(pipeline: P1PipelineState, now?: string): P1PipelineState;
    export function markP1Step(pipeline: P1PipelineState, stepId: P1StepId, next: Ns5PipelineStepState): P1PipelineState;
    export function createP1RetryStep(stepId: P1StepId, moduleName: string, kind: 'repair' | 'transport', attempt: number, extra?: Record<string, unknown>): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type P1PipelineState, type P1StepId } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    export type P1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type P1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface P1StepHooks {
        beforePromptStep?: P1StepBeforePrompt;
        afterPromptStep?: P1StepAfterPrompt;
    }
    /** Filled by later specs. A missing entry means the step is not implemented yet. */
    export const P1_STEP_HOOKS: Partial<Record<P1StepId, P1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string, prompt?: string): P1StepHooks | undefined;
    export function markAwaitingStep(pipeline: P1PipelineState, stepId: P1StepId): Promise<P1PipelineState>;
    export function p1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/contracts" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { P1_NEEDS_SCHEMA, type P1Device } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import type { PoolMessage } from "_102035_/l2/solution/pool";
    export const P1_BACKEND_SCHEMA_VERSION: "2026-09-21-p1-backend-v1.1";
    export const P1_BACKEND_ARTIFACT: "pool/l2/web/backend.json";
    export const P1_L4DIFF_SCHEMA: "2026-09-21-p4-l4diff-v1";
    export const P1_KINDS: readonly ["qry", "cmd"];
    export type P1Kind = typeof P1_KINDS[number];
    export const P1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export type P1Operation = typeof P1_OPERATIONS[number];
    export const P1_PLAN_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export type P1PlanStatus = typeof P1_PLAN_STATUSES[number];
    export const P1_NEEDS_FAMILIES: readonly ["mdm", "ddm", "tdm"];
    export type P1NeedsFamily = typeof P1_NEEDS_FAMILIES[number];
    export const P1_WRITE_OPERATIONS: readonly ["create", "update", "transition", "delete"];
    export type P1WriteOperation = typeof P1_WRITE_OPERATIONS[number];
    export const P1_REMOVED_KINDS: readonly ["usecase", "port", "table"];
    export type P1RemovedKind = typeof P1_REMOVED_KINDS[number];
    export const P1_NO_TABLE: readonly ["ok", "mdm", "none"];
    export type P1NoTable = typeof P1_NO_TABLE[number];
    export const P1_CHANGE_KINDS: readonly ["field", "rule", "grant", "transition", "process", "integration", "entity"];
    export type P1ChangeKind = typeof P1_CHANGE_KINDS[number];
    export const P1_CHANGE_OPS: readonly ["added", "changed", "removed"];
    export type P1ChangeOp = typeof P1_CHANGE_OPS[number];
    export interface P1NeedsRead {
        entity: string;
        family: P1NeedsFamily;
        scope: string;
        derived: string[];
        from: string[];
    }
    export interface P1NeedsWrite {
        entity: string;
        operation: P1WriteOperation;
        transitionRef: string;
        from: string[];
    }
    export interface P1NeedsPage {
        pageId: string;
        actors: string[];
        reads: P1NeedsRead[];
        writes: P1NeedsWrite[];
    }
    export interface P1NeedsFile {
        schemaVersion: typeof P1_NEEDS_SCHEMA;
        moduleName: string;
        device: P1Device;
        pages: P1NeedsPage[];
    }
    export interface P1EntityView {
        entityId: string;
        family: P1NeedsFamily;
        storageKind: string;
        storageTarget: string;
        transitions: string[];
        rules: string[];
    }
    export interface P1Endpoint {
        route: string;
        page: string;
        kind: P1Kind;
        usecaseRef: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Usecase {
        usecaseId: string;
        entity: string;
        operation: P1Operation;
        ports: string[];
        status: P1PlanStatus;
        existing: string;
        reason: string;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Port {
        portId: string;
        entity: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Table {
        tableId: string;
        entity: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Removed {
        kind: P1RemovedKind;
        id: string;
        status: 'toRemove';
        reason: string;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Change {
        changeId: string;
        kind: P1ChangeKind;
        op: P1ChangeOp;
        entity: string;
        tableRefs: string[];
        noTable: P1NoTable;
        usecaseRefs: string[];
        reason: string;
        source: string;
    }
    export interface P1UnmappedChange {
        changeId: string;
        kind: string;
        source: string;
    }
    export interface P1L4DiffItem {
        changeId: string;
        kind: P1ChangeKind;
        op: P1ChangeOp;
        entity: string;
        source: string;
        before: Record<string, unknown>;
        after: Record<string, unknown>;
    }
    export interface P1L4DiffFile {
        schemaVersion: typeof P1_L4DIFF_SCHEMA;
        moduleName: string;
        base: string;
        candidate: string;
        items: P1L4DiffItem[];
        unmapped: P1UnmappedChange[];
    }
    export interface P1BackendFile {
        schemaVersion: typeof P1_BACKEND_SCHEMA_VERSION;
        moduleName: string;
        device: P1Device;
        sourceNeeds: string;
        inventoryPresent: boolean;
        endpoints: P1Endpoint[];
        usecases: P1Usecase[];
        ports: P1Port[];
        tables: P1Table[];
        removed: P1Removed[];
        changes: P1Change[];
        meta: {
            pages: Record<string, string[]>;
            generatedAt: string;
            llmCalled: boolean;
            unmappedChanges: P1UnmappedChange[];
        };
    }
    export interface P1UnresolvedItem {
        kind: 'alias' | 'merge';
        candidateUsecaseId: string;
        entity: string;
        operation: string;
        reason: string;
    }
    export interface P1BackendAlias {
        candidateUsecaseId: string;
        existingUsecaseId: string;
        reason: string;
    }
    export interface P1BackendMerge {
        usecaseId: string;
        entity: string;
        operation: 'custom';
        ports: string[];
        replaces: string[];
        reason: string;
    }
    export interface P1BackendResolution {
        aliases: P1BackendAlias[];
        merges: P1BackendMerge[];
    }
    export interface P1PlanBackendInput {
        needs: P1NeedsFile;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        now: Date;
        resolution?: P1BackendResolution | null;
        l4diff?: P1L4DiffFile | null;
    }
    export interface P1PlanBackendResult {
        file: P1BackendFile;
        unresolved: P1UnresolvedItem[];
    }
    export function isP1Kind(value: string): value is P1Kind;
    export function isP1Operation(value: string): value is P1Operation;
    export function isP1PlanStatus(value: string): value is P1PlanStatus;
    export function isP1NeedsFamily(value: string): value is P1NeedsFamily;
    export function isP1WriteOperation(value: string): value is P1WriteOperation;
    export function isP1NoTable(value: string): value is P1NoTable;
    export function isP1ChangeKind(value: string): value is P1ChangeKind;
    export function isP1ChangeOp(value: string): value is P1ChangeOp;
    export function p1BackendSubject(moduleName: string, device?: P1Device): string;
    export function p1BackendBody(file: P1BackendFile): string;
    export function buildP1BackendMessage(input: {
        file: P1BackendFile;
        received: Pick<PoolMessage, 'thread' | 'round' | 'mode'>;
    }): PoolMessage;
    export function p1UsecaseId(operation: P1Operation, entity: string, transitionRef?: string): string;
    export function p1Route(moduleName: string, page: string, kind: P1Kind, usecaseId: string): string;
    export function p1PortId(entity: string): string;
    export function p1TableId(entity: string): string;
    export function parseP1Needs(value: unknown): P1NeedsFile;
    export function parseP1Entity(value: unknown, indexRow?: unknown): P1EntityView | null;
    export function parseP1OntologyIndex(value: unknown): string[];
    export function parseP1L4Diff(value: unknown): P1L4DiffFile | null;
    export function parseP1Resolution(value: unknown): P1BackendResolution;
    export function planP1Backend(input: P1PlanBackendInput): P1PlanBackendResult;
    export function normalizeP1Backend(value: unknown, fallback: P1PlanBackendInput): P1BackendFile;
    export function buildP1BackendTool(schema: Record<string, unknown>): mls.msg.LLMTool;
    export function buildP1ResolutionSchema(): Record<string, unknown>;
    export function unwrapP1ArtifactPayload(value: unknown): unknown;
    export function stampP1Backend(file: P1BackendFile, ctx: {
        ontology: Map<string, P1EntityView>;
        inventory: L1Inventory;
        needs: P1NeedsFile;
        l4diff: P1L4DiffFile | null;
    }): P1BackendFile;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/gate" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1BackendFile, type P1EntityView, type P1L4DiffFile, type P1NeedsFile } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    export interface P1BackendGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface P1BackendGateResult {
        ok: boolean;
        issues: P1BackendGateIssue[];
    }
    export function validateP1Backend(file: P1BackendFile, needs: P1NeedsFile, ontology: readonly P1EntityView[]): P1BackendGateResult;
    export function repairP1Backend(file: P1BackendFile, needs: P1NeedsFile, ontology: readonly P1EntityView[], inventory?: L1Inventory, l4diff?: P1L4DiffFile | null): P1BackendFile;
    export function formatP1BackendGate(issues: readonly P1BackendGateIssue[]): string;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type PoolMessage } from "_102035_/l2/solution/pool";
    import { type P1PipelineState } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1BackendFile, type P1BackendResolution, type P1EntityView, type P1L4DiffFile, type P1NeedsFile, type P1PlanBackendResult } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    export interface P1PlanSources {
        needs: P1NeedsFile;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        pipeline: P1PipelineState;
        l4diff: P1L4DiffFile | null;
    }
    export interface P1DeliverPlanResult {
        backend: P1BackendFile;
        backendPath: string;
        message: PoolMessage;
        messagePath: string;
        llmCalled: boolean;
    }
    export function composeP1SystemPrompt(skillText: string, stepPrompt: string): string;
    export function buildP1PlanHumanPrompt(input: {
        sources: P1PlanSources;
        planned: P1PlanBackendResult;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function loadP1Ontology(moduleName: string): Promise<P1EntityView[]>;
    export function loadP1PlanSources(moduleName: string): Promise<P1PlanSources>;
    export function executeP1Plan(moduleName: string, now: Date, resolution?: P1BackendResolution | null): Promise<P1DeliverPlanResult>;
    export function beforeP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/agentPlannerL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry";
    import "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/atendenteCatalogue.defs" {
    export const atendenteCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "atendenteCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "atendenteCatalogue";
            readonly controllerName: "AtendenteCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "atendenteCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "atendenteCatalogueQryListAtendenteHandler";
                readonly command: "qryListAtendente";
                readonly bffId: "qryListAtendente";
                readonly route: "controleChamados.atendenteCatalogue.qryListAtendente";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdCreateAtendenteHandler";
                readonly command: "cmdCreateAtendente";
                readonly bffId: "cmdCreateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdCreateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "createAtendente";
                readonly usecaseRefs: readonly ["createAtendente"];
                readonly inputTypeName: "CreateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "platformUserId";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "createAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "createAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdUpdateAtendenteHandler";
                readonly command: "cmdUpdateAtendente";
                readonly bffId: "cmdUpdateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdUpdateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "updateAtendente";
                readonly usecaseRefs: readonly ["updateAtendente"];
                readonly inputTypeName: "UpdateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }, {
                    readonly inputId: "platformUserId";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "updateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "updateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdInactivateAtendenteHandler";
                readonly command: "cmdInactivateAtendente";
                readonly bffId: "cmdInactivateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdInactivateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "inactivateAtendente";
                readonly usecaseRefs: readonly ["inactivateAtendente"];
                readonly inputTypeName: "InactivateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "inactivateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "inactivateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdReactivateAtendenteHandler";
                readonly command: "cmdReactivateAtendente";
                readonly bffId: "cmdReactivateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdReactivateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "reactivateAtendente";
                readonly usecaseRefs: readonly ["reactivateAtendente"];
                readonly inputTypeName: "ReactivateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "reactivateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "reactivateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueQryGetAtendenteHandler";
                readonly command: "qryGetAtendente";
                readonly bffId: "qryGetAtendente";
                readonly route: "controleChamados.atendenteCatalogue.qryGetAtendente";
                readonly kind: "query";
                readonly usecaseRef: "getAtendente";
                readonly usecaseRefs: readonly ["getAtendente"];
                readonly inputTypeName: "GetAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "getAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "getAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.atendenteCatalogue.qryListAtendente";
                readonly handlerName: "atendenteCatalogueQryListAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdCreateAtendente";
                readonly handlerName: "atendenteCatalogueCmdCreateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdUpdateAtendente";
                readonly handlerName: "atendenteCatalogueCmdUpdateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdInactivateAtendente";
                readonly handlerName: "atendenteCatalogueCmdInactivateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdReactivateAtendente";
                readonly handlerName: "atendenteCatalogueCmdReactivateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.qryGetAtendente";
                readonly handlerName: "atendenteCatalogueQryGetAtendenteHandler";
            }];
        };
    };
    export default atendenteCatalogueController;
    export const pipeline: readonly [{
        readonly id: "atendenteCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/atendenteCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/atendenteCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--qryListAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdCreateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdUpdateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdInactivateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdReactivateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--qryGetAtendente.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/chamadoCatalogue.defs" {
    export const chamadoCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "chamadoCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "chamadoCatalogue";
            readonly controllerName: "ChamadoCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "chamadoCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "chamadoCatalogueQryListChamadoHandler";
                readonly command: "qryListChamado";
                readonly bffId: "qryListChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryListChamado";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdCreateChamadoHandler";
                readonly command: "cmdCreateChamado";
                readonly bffId: "cmdCreateChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdCreateChamado";
                readonly kind: "command";
                readonly usecaseRef: "createChamado";
                readonly usecaseRefs: readonly ["createChamado"];
                readonly inputTypeName: "CreateChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "titulo";
                    readonly fieldRef: "Chamado.titulo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "descricao";
                    readonly fieldRef: "Chamado.descricao";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do acompanhamento do chamado.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdUpdateChamadoHandler";
                readonly command: "cmdUpdateChamado";
                readonly bffId: "cmdUpdateChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdUpdateChamado";
                readonly kind: "command";
                readonly usecaseRef: "updateChamado";
                readonly usecaseRefs: readonly ["updateChamado"];
                readonly inputTypeName: "UpdateChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }, {
                    readonly inputId: "titulo";
                    readonly fieldRef: "Chamado.titulo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "descricao";
                    readonly fieldRef: "Chamado.descricao";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do acompanhamento do chamado.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdDeleteChamadoHandler";
                readonly command: "cmdDeleteChamado";
                readonly bffId: "cmdDeleteChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdDeleteChamado";
                readonly kind: "command";
                readonly usecaseRef: "deleteChamado";
                readonly usecaseRefs: readonly ["deleteChamado"];
                readonly inputTypeName: "DeleteChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueQryGetChamadoHandler";
                readonly command: "qryGetChamado";
                readonly bffId: "qryGetChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryGetChamado";
                readonly kind: "query";
                readonly usecaseRef: "getChamado";
                readonly usecaseRefs: readonly ["getChamado"];
                readonly inputTypeName: "GetChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueQryLocateChamadoHandler";
                readonly command: "qryLocateChamado";
                readonly bffId: "qryLocateChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryLocateChamado";
                readonly kind: "query";
                readonly usecaseRef: "locateChamado";
                readonly usecaseRefs: readonly ["locateChamado"];
                readonly inputTypeName: "LocateChamadoInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdCloseChamadoHandler";
                readonly command: "cmdCloseChamado";
                readonly bffId: "cmdCloseChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdCloseChamado";
                readonly kind: "command";
                readonly usecaseRef: "closeChamado";
                readonly usecaseRefs: readonly ["closeChamado"];
                readonly inputTypeName: "CloseChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Decisão tomada.";
                    readonly enumValues: readonly ["closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.chamadoCatalogue.qryListChamado";
                readonly handlerName: "chamadoCatalogueQryListChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdCreateChamado";
                readonly handlerName: "chamadoCatalogueCmdCreateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdUpdateChamado";
                readonly handlerName: "chamadoCatalogueCmdUpdateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdDeleteChamado";
                readonly handlerName: "chamadoCatalogueCmdDeleteChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.qryGetChamado";
                readonly handlerName: "chamadoCatalogueQryGetChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.qryLocateChamado";
                readonly handlerName: "chamadoCatalogueQryLocateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdCloseChamado";
                readonly handlerName: "chamadoCatalogueCmdCloseChamadoHandler";
            }];
        };
    };
    export default chamadoCatalogueController;
    export const pipeline: readonly [{
        readonly id: "chamadoCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryListChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdCreateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdUpdateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdDeleteChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryGetChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryLocateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdCloseChamado.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/chamadoHub.defs" {
    export const chamadoHubController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "chamadoHub";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "chamadoHub";
            readonly controllerName: "ChamadoHubController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "chamadoHub";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "chamadoHubQryListChamadoHandler";
                readonly command: "qryListChamado";
                readonly bffId: "qryListChamado";
                readonly route: "controleChamados.chamadoHub.qryListChamado";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoHubQryListComentarioHandler";
                readonly command: "qryListComentario";
                readonly bffId: "qryListComentario";
                readonly route: "controleChamados.chamadoHub.qryListComentario";
                readonly kind: "query";
                readonly usecaseRef: "listComentario";
                readonly usecaseRefs: readonly ["listComentario"];
                readonly inputTypeName: "ListComentarioInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.chamadoHub.qryListChamado";
                readonly handlerName: "chamadoHubQryListChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoHub.qryListComentario";
                readonly handlerName: "chamadoHubQryListComentarioHandler";
            }];
        };
    };
    export default chamadoHubController;
    export const pipeline: readonly [{
        readonly id: "chamadoHub__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoHub.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoHub.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoHub--qryListChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.d.ts", "_102039_/l4/controleChamados/contracts/chamadoHub--qryListComentario.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/comentarioCatalogue.defs" {
    export const comentarioCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "comentarioCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "comentarioCatalogue";
            readonly controllerName: "ComentarioCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "comentarioCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "comentarioCatalogueQryListComentarioHandler";
                readonly command: "qryListComentario";
                readonly bffId: "qryListComentario";
                readonly route: "controleChamados.comentarioCatalogue.qryListComentario";
                readonly kind: "query";
                readonly usecaseRef: "listComentario";
                readonly usecaseRefs: readonly ["listComentario"];
                readonly inputTypeName: "ListComentarioInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdCreateComentarioHandler";
                readonly command: "cmdCreateComentario";
                readonly bffId: "cmdCreateComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdCreateComentario";
                readonly kind: "command";
                readonly usecaseRef: "createComentario";
                readonly usecaseRefs: readonly ["createComentario"];
                readonly inputTypeName: "CreateComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                }, {
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdUpdateComentarioHandler";
                readonly command: "cmdUpdateComentario";
                readonly bffId: "cmdUpdateComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdUpdateComentario";
                readonly kind: "command";
                readonly usecaseRef: "updateComentario";
                readonly usecaseRefs: readonly ["updateComentario"];
                readonly inputTypeName: "UpdateComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }, {
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                }, {
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdDeleteComentarioHandler";
                readonly command: "cmdDeleteComentario";
                readonly bffId: "cmdDeleteComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdDeleteComentario";
                readonly kind: "command";
                readonly usecaseRef: "deleteComentario";
                readonly usecaseRefs: readonly ["deleteComentario"];
                readonly inputTypeName: "DeleteComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryGetComentarioHandler";
                readonly command: "qryGetComentario";
                readonly bffId: "qryGetComentario";
                readonly route: "controleChamados.comentarioCatalogue.qryGetComentario";
                readonly kind: "query";
                readonly usecaseRef: "getComentario";
                readonly usecaseRefs: readonly ["getComentario"];
                readonly inputTypeName: "GetComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryChamadoPickerHandler";
                readonly command: "qryChamadoPicker";
                readonly bffId: "qryChamadoPicker";
                readonly route: "controleChamados.comentarioCatalogue.qryChamadoPicker";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryAtendentePickerHandler";
                readonly command: "qryAtendentePicker";
                readonly bffId: "qryAtendentePicker";
                readonly route: "controleChamados.comentarioCatalogue.qryAtendentePicker";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.comentarioCatalogue.qryListComentario";
                readonly handlerName: "comentarioCatalogueQryListComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdCreateComentario";
                readonly handlerName: "comentarioCatalogueCmdCreateComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdUpdateComentario";
                readonly handlerName: "comentarioCatalogueCmdUpdateComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdDeleteComentario";
                readonly handlerName: "comentarioCatalogueCmdDeleteComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryGetComentario";
                readonly handlerName: "comentarioCatalogueQryGetComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryChamadoPicker";
                readonly handlerName: "comentarioCatalogueQryChamadoPickerHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryAtendentePicker";
                readonly handlerName: "comentarioCatalogueQryAtendentePickerHandler";
            }];
        };
    };
    export default comentarioCatalogueController;
    export const pipeline: readonly [{
        readonly id: "comentarioCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/comentarioCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/comentarioCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryListComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdCreateComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdUpdateComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdDeleteComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryGetComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryChamadoPicker.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryAtendentePicker.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/registrarComentarioChamado.defs" {
    export const registrarComentarioChamadoController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "registrarComentarioChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "registrarComentarioChamado";
            readonly controllerName: "RegistrarComentarioChamadoController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "registrarComentarioChamado";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "registrarComentarioChamadoQryLocateChamadoHandler";
                readonly command: "qryLocateChamado";
                readonly bffId: "qryLocateChamado";
                readonly route: "controleChamados.registrarComentarioChamado.qryLocateChamado";
                readonly kind: "query";
                readonly usecaseRef: "locateChamado";
                readonly usecaseRefs: readonly ["locateChamado"];
                readonly inputTypeName: "LocateChamadoInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "registrarComentarioChamadoCmdRegisterComentarioHandler";
                readonly command: "cmdRegisterComentario";
                readonly bffId: "cmdRegisterComentario";
                readonly route: "controleChamados.registrarComentarioChamado.cmdRegisterComentario";
                readonly kind: "command";
                readonly usecaseRef: "registerComentario";
                readonly usecaseRefs: readonly ["registerComentario"];
                readonly inputTypeName: "RegisterComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente";
                }, {
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "registrarComentarioChamadoQryAtendentePickerHandler";
                readonly command: "qryAtendentePicker";
                readonly bffId: "qryAtendentePicker";
                readonly route: "controleChamados.registrarComentarioChamado.qryAtendentePicker";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.registrarComentarioChamado.qryLocateChamado";
                readonly handlerName: "registrarComentarioChamadoQryLocateChamadoHandler";
            }, {
                readonly key: "controleChamados.registrarComentarioChamado.cmdRegisterComentario";
                readonly handlerName: "registrarComentarioChamadoCmdRegisterComentarioHandler";
            }, {
                readonly key: "controleChamados.registrarComentarioChamado.qryAtendentePicker";
                readonly handlerName: "registrarComentarioChamadoQryAtendentePickerHandler";
            }];
        };
    };
    export default registrarComentarioChamadoController;
    export const pipeline: readonly [{
        readonly id: "registrarComentarioChamado__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/registrarComentarioChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/registrarComentarioChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--qryLocateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--cmdRegisterComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--qryAtendentePicker.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/chamado.defs" {
    export const chamadoTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Chamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Chamado";
            readonly tableName: "controlechamados_chamado";
            readonly columns: readonly [{
                readonly name: "chamado_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key / foreign key identifier";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "Chamado status";
            }];
            readonly primaryKey: readonly ["chamado_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_chamado_status_idx";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default chamadoTableDefinition;
    export const pipeline: readonly [{
        readonly id: "chamado__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.defs" {
    export const chamadoRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ChamadoRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly className: "ChamadoRepositoryAdapter";
            readonly portRef: "IChamadoRepository";
            readonly tableRef: "chamados";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('chamados').", "Map columns chamadoId -> chamado_id and status -> status; map details.titulo and details.descricao with verbatim camelCase JSONB keys.", "getById/list hydrate domain aggregates from chamado_id, status, and details; save writes only real columns plus details JSONB, preserving fieldId keys.", "list must apply filter.sortBy/sortOrder; status must be sorted in memory by the declared domain enum order, not SQL text.", "The requested search behavior cannot be implemented against a real title/name column because Chamado declares no title/name column and titulo is a details field; do not invent a table column or snake_case a details key.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default chamadoRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "chamadoRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/comentario.defs" {
    export const comentarioTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Comentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Comentario";
            readonly tableName: "controlechamados_comentario";
            readonly columns: readonly [{
                readonly name: "comentario_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key / foreign key identifier";
            }, {
                readonly name: "chamado_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Chamado foreign key";
            }, {
                readonly name: "atendente_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Atendente foreign key";
            }];
            readonly primaryKey: readonly ["comentario_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_comentario_chamado_id_idx";
                readonly columns: readonly ["chamado_id"];
                readonly unique: false;
            }, {
                readonly indexName: "controlechamados_comentario_atendente_id_idx";
                readonly columns: readonly ["atendente_id"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default comentarioTableDefinition;
    export const pipeline: readonly [{
        readonly id: "comentario__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.defs" {
    export const comentarioRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ComentarioRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly className: "ComentarioRepositoryAdapter";
            readonly portRef: "IComentarioRepository";
            readonly tableRef: "comentarios";
            readonly mdmReads: readonly ["Resolve atendenteId through ctx.mdm.collection.listByType/getMany/hydrateMany/relatedOfMany as appropriate for the canonical Atendente type; never call ctx.mdm.entity.get inside a loop. Persist only atendente_id locally and do not create a local MDM table."];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('comentarios').", "Map columns comentarioId -> comentario_id, chamadoId -> chamado_id, and atendenteId -> atendente_id; map details.conteudo with the verbatim camelCase JSONB key.", "Bulk-resolve distinct atendenteId values before mapping rows; use the collection APIs and attach the resolved Atendente representation expected by the domain without inventing entityId/entityType or relationship columns.", "save writes only comentario_id, chamado_id, atendente_id, and details; details must contain conteudo and no snake_case JSONB keys.", "Apply filter.sortBy/sortOrder with orderBy for non-enum fields; enum fields, if declared by the domain, must be sorted in memory by declared enum order. Search must use a real title/name column only if one is declared; otherwise do not invent one.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default comentarioRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "comentarioRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/seeds.defs" {
    export const seedsDefs: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "seeds";
        readonly artifactId: "seeds";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbSeeds";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly version: 1;
            readonly language: "en";
            readonly plan: {
                readonly summary: "Three coherent comments linked to the three previously seeded open support tickets and assigned attendants.";
                readonly localTables: readonly [{
                    readonly tableId: "Chamado";
                    readonly rows: readonly [{
                        readonly key: "chamado-1";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Unable to access customer portal";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The customer receives an authentication error after entering valid credentials and cannot reach the portal dashboard.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "chamado-2";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Invoice download fails";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The invoice page loads, but selecting the PDF download action returns an empty response.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "chamado-3";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Request to update contact email";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The customer asked support to replace the primary contact email address on the account.";
                        }];
                        readonly children: readonly [];
                    }];
                }, {
                    readonly tableId: "Comentario";
                    readonly rows: readonly [{
                        readonly key: "comentario-1";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-1";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-1";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "We are investigating the reported access issue and will provide an update shortly.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comentario-2";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-2";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-2";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "The support team requested additional diagnostic information from the requester.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comentario-3";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-3";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-3";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "The ticket remains in progress while the proposed configuration change is being validated.";
                        }];
                        readonly children: readonly [];
                    }];
                }];
                readonly mdmEntities: readonly [{
                    readonly entityId: "Atendente";
                    readonly rows: readonly [{
                        readonly key: "atendente-1";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 1";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-1";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u1";
                            };
                        }];
                        readonly relationships: readonly [];
                    }, {
                        readonly key: "atendente-2";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 2";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-2";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u2";
                            };
                        }];
                        readonly relationships: readonly [];
                    }, {
                        readonly key: "atendente-3";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 3";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-3";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u3";
                            };
                        }];
                        readonly relationships: readonly [];
                    }];
                }];
            };
        };
    };
    export default seedsDefs;
    export const pipeline: readonly [{
        readonly id: "seeds__persistenceSeeds";
        readonly type: "persistenceSeeds";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceSeeds.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/ports/chamadoRepository.defs" {
    export const chamadoRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ChamadoRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly interfaceName: "IChamadoRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ChamadoId"];
                readonly returns: "Chamado | null";
                readonly description: "Retrieves a Chamado aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ChamadoListFilter"];
                readonly returns: "Chamado[]";
                readonly description: "Lists Chamado aggregates matching equality filters and optional search/sort controls.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Chamado"];
                readonly returns: "void";
                readonly description: "Persists a Chamado aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: ChamadoId"];
                readonly returns: "void";
                readonly description: "Deletes a Chamado aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default chamadoRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "chamadoRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/ports/comentarioRepository.defs" {
    export const comentarioRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ComentarioRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly interfaceName: "IComentarioRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ComentarioId"];
                readonly returns: "Comentario | null";
                readonly description: "Retrieves a Comentario aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ComentarioListFilter"];
                readonly returns: "Comentario[]";
                readonly description: "Lists Comentario aggregates matching equality filters and optional search/sort controls.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Comentario"];
                readonly returns: "void";
                readonly description: "Persists a Comentario aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: ComentarioId"];
                readonly returns: "void";
                readonly description: "Deletes a Comentario aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default comentarioRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "comentarioRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/closeChamado.defs" {
    export const closeChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
            readonly functions: readonly [{
                readonly functionName: "closeChamado";
                readonly inputTypeName: "CloseChamadoInput";
                readonly outputTypeName: "CloseChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado identifier from the route parameter.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Decision taken; the contract restricts this value to the enum value closed (enumValues: [\"closed\"]).";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
                readonly transactional: true;
                readonly steps: readonly ["Load Chamado by chamadoId through the Chamado port inside the transaction.", "Validate the requested status is closed, as required by the L4 enum constraint [\"closed\"].", "Apply the domain canTransition helper using the declared chamadoLifecycle matrix; do not add a stricter local transition allow-list.", "Apply rule fechamentoExigeChamadoAberto: reject with an English AppError whose details include ruleId fechamentoExigeChamadoAberto when the loaded Chamado status is not open.", "Set the Chamado status to closed and save the aggregate through the Chamado port.", "Return chamadoId, titulo, descricao, and the resulting status from the saved Chamado."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "closeChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createAtendente.defs" {
    export const createAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createAtendente";
                readonly inputTypeName: "CreateAtendenteInput";
                readonly outputTypeName: "CreateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Validate the required platformUserId input.", "Create the Atendente master-data entity through ctx.mdm.entity.create using mdmType controleChamados.Atendente and the platformUserId field.", "Return the created atendenteId and platformUserId."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default createAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "createAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createChamado.defs" {
    export const createChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createChamado";
                readonly inputTypeName: "CreateChamadoInput";
                readonly outputTypeName: "CreateChamadoOutput";
                readonly input: readonly [{
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.titulo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.descricao";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Validate required titulo and descricao fields.", "Resolve the initial status from the system default as open.", "Generate chamadoId using ctx.idGenerator.", "Create the Chamado aggregate through the Chamado port.", "Return chamadoId, titulo, descricao, and status."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "createChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createComentario.defs" {
    export const createComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "createComentario";
                readonly inputTypeName: "CreateComentarioInput";
                readonly outputTypeName: "CreateComentarioOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Selected open ticket to which the comment belongs.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Authenticated attendant responsible for recording the comment.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Follow-up text written by the attendant for the ticket.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve the selected Chamado through the Chamado port.", "Validate that the Chamado exists; this is required by the referenced rule and the relationship field constraint.", "Validate that Chamado.status is open; otherwise reject with rule id comentariosPermitidosSomenteEmChamadosAbertos and an English user-facing message.", "Create a Comentario with a generated comentarioId and the supplied chamadoId, atendenteId, and conteudo through the Comentario port.", "Return comentarioId, chamadoId, atendenteId, and conteudo from the created comment."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default createComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "createComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/deleteChamado.defs" {
    export const deleteChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteChamado";
                readonly inputTypeName: "DeleteChamadoInput";
                readonly outputTypeName: "DeleteChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Chamado aggregate by chamadoId through the Chamado port.", "Capture the canonical output fields from the loaded aggregate.", "Delete the Chamado aggregate through the Chamado port within the transaction.", "Return chamadoId, titulo, descricao, and status from the deleted aggregate."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/deleteComentario.defs" {
    export const deleteComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteComentario";
                readonly inputTypeName: "DeleteComentarioInput";
                readonly outputTypeName: "DeleteComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Execute within the transaction wrapper provided by ctx.data.", "Resolve the Comentario repository port and load the comment by comentarioId.", "Delete the persisted comment through the Comentario port.", "Return the deleted comment projection with comentarioId, chamadoId, atendenteId, and conteudo."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getAtendente.defs" {
    export const getAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getAtendente";
                readonly inputTypeName: "GetAtendenteInput";
                readonly outputTypeName: "GetAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Read the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "Return atendenteId and platformUserId from the retrieved Atendente record.", "If no record is found, return the platform's standard not-found result."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly situationOutput: "active";
            };
        };
    };
    export default getAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "getAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getChamado.defs" {
    export const getChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getChamado";
                readonly inputTypeName: "GetChamadoInput";
                readonly outputTypeName: "GetChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Chamado aggregate through the Chamado port using chamadoId.", "Return chamadoId, titulo, descricao, and status from the loaded Chamado."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "getChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getComentario.defs" {
    export const getComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getComentario";
                readonly inputTypeName: "GetComentarioInput";
                readonly outputTypeName: "GetComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Comentario aggregate through the Comentario port using comentarioId.", "Return comentarioId, chamadoId, atendenteId, and conteudo with the declared output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "getComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/inactivateAtendente.defs" {
    export const inactivateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "inactivateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "inactivateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "inactivateAtendente";
                readonly inputTypeName: "InactivateAtendenteInput";
                readonly outputTypeName: "InactivateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "If the Atendente record does not exist, return the documented master-data not-found error.", "In the same transaction wrapper, inactivate the Atendente master-data record through ctx.mdm.entity.inactivate({ mdmId: atendenteId, mdmType: \"controleChamados.Atendente\" }).", "Return atendenteId and platformUserId from the loaded record."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly lifecycle: "inactivate";
            };
        };
    };
    export default inactivateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "inactivateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listAtendente.defs" {
    export const listAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listAtendente";
                readonly inputTypeName: "ListAtendenteInput";
                readonly outputTypeName: "ListAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "includeInactive";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Include records inactivated in the MDM index; defaults to active records only.";
                    readonly ofEntity: "";
                    readonly fieldRef: "";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["List Atendente records through ctx.mdm.collection.listByType using type controleChamados.Atendente.", "By default request active records only; when includeInactive is true, include inactivated records from the MDM index.", "Return only atendenteId and platformUserId for each record."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly activeFilterInput: "includeInactive";
                readonly situationOutput: "active";
            };
        };
    };
    export default listAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "listAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listChamado.defs" {
    export const listChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listChamado";
                readonly inputTypeName: "ListChamadoInput";
                readonly outputTypeName: "ListChamadoOutput";
                readonly input: readonly [{
                    readonly name: "sortBy";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Campo de ordenação da listagem.";
                    readonly ofEntity: "";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "sortOrder";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Direção da ordenação.";
                    readonly ofEntity: "";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load all Chamado records through the Chamado repository port.", "Apply the optional status sort field and ascending or descending order when provided.", "Return the selected Chamado fields according to the canonical list output shape."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "listChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listComentario.defs" {
    export const listComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listComentario";
                readonly inputTypeName: "ListComentarioInput";
                readonly outputTypeName: "ListComentarioOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load all Comentario records through the Comentario port.", "Return the selected comentarioId, chamadoId, atendenteId, and conteudo fields as the list projection."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "listComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/locateChamado.defs" {
    export const locateChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "locateChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "locateChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "locateChamado";
                readonly inputTypeName: "LocateChamadoInput";
                readonly outputTypeName: "LocateChamadoOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Use the Chamado port to list the open Chamado aggregate.", "Return the selected open Chamado projection with chamadoId, titulo, descricao, and status.", "Do not invent additional filtering or lifecycle transitions; the lifecycle defines open as the initial state and closed as terminal, but this query does not mutate state."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default locateChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "locateChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/reactivateAtendente.defs" {
    export const reactivateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "reactivateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "reactivateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "reactivateAtendente";
                readonly inputTypeName: "ReactivateAtendenteInput";
                readonly outputTypeName: "ReactivateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "If the record does not exist, fail with a machine-readable not-found error and an English user-facing message.", "Reactivate the Atendente master-data record through the MDM lifecycle operation, using ctx.mdm.entity.update within the single transaction wrapper provided by ctx.data; do not create a local repository or port for this MDM entity.", "Return the reactivated record's atendenteId and platformUserId in the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly lifecycle: "reactivate";
            };
        };
    };
    export default reactivateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "reactivateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/registerComentario.defs" {
    export const registerComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "registerComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "registerComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "registerComentario";
                readonly inputTypeName: "RegisterComentarioInput";
                readonly outputTypeName: "RegisterComentarioOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Atendente selecionado para registrar o comentário.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado identificado pela rota.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve o Atendente por atendenteId usando ctx.mdm.entity.get({ mdmId: atendenteId }); não cria port para MDM.", "Carrega o Chamado por chamadoId através do port Chamado.", "Aplica a regra comentariosPermitidosSomenteEmChamadosAbertos: se o Chamado não tiver status open, rejeita com erro em inglês contendo o identificador da regra.", "Cria o Comentario com comentarioId gerado pelo mecanismo de domínio/port e os campos chamadoId, atendenteId e conteudo; persiste pelo port Comentario dentro da transação.", "Retorna comentarioId, chamadoId, atendenteId e conteudo do comentário persistido."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default registerComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "registerComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateAtendente.defs" {
    export const updateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateAtendente";
                readonly inputTypeName: "UpdateAtendenteInput";
                readonly outputTypeName: "UpdateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get.", "Update platformUserId through ctx.mdm.entity.update using the Atendente master-data identifier and module details when applicable.", "Return atendenteId and platformUserId matching the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default updateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "updateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateChamado.defs" {
    export const updateChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
            readonly functions: readonly [{
                readonly functionName: "updateChamado";
                readonly inputTypeName: "UpdateChamadoInput";
                readonly outputTypeName: "UpdateChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.titulo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.descricao";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
                readonly transactional: true;
                readonly steps: readonly ["Use the Chamado port to load the existing Chamado by chamadoId inside the ctx.data transaction wrapper.", "Resolve status from the server-side systemDefault/current status rather than accepting it as public input.", "If the requested transition closes the Chamado, require the current status to be open and include rule id fechamentoExigeChamadoAberto in the validation error details when blocked.", "Call the domain canTransition helper using the declared chamadoLifecycle matrix; do not add a stricter local transition allow-list.", "If the existing Chamado is closed, reject any transition to open with rule id chamadoFechadoNaoPodeSerReaberto in the validation error details.", "Apply titulo and descricao, preserve the resolved status, save the Chamado through its port, and return the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "updateChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateComentario.defs" {
    export const updateComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "updateComentario";
                readonly inputTypeName: "UpdateComentarioInput";
                readonly outputTypeName: "ComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Within the transaction wrapper provided by ctx.data, load the Comentario aggregate through the Comentario port using comentarioId.", "Load the Chamado through the Chamado port using chamadoId and verify that its status is open; otherwise reject with an English AppError containing rule id comentariosPermitidosSomenteEmChamadosAbertos.", "Resolve the Atendente master-data reference by id through ctx.mdm.entity.get({ mdmId: atendenteId }); do not create a port for Atendente.", "Apply the requested selected-entity values and user-provided conteudo to the Comentario aggregate, preserving its identity and required relationships.", "Save the updated Comentario through its port in the same transaction and return exactly comentarioId, chamadoId, atendenteId, and conteudo."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default updateComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "updateComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_3_domain/entities/chamado.defs" {
    export const chamadoDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Chamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly title: "Chamado";
            readonly fields: readonly [{
                readonly fieldId: "chamadoId";
                readonly title: "Identificador do chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueChamadoId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada chamado possui um identificador estável exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "titulo";
                readonly title: "Título";
                readonly type: "string";
                readonly required: true;
                readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "descricao";
                readonly title: "Descrição";
                readonly type: "text";
                readonly required: true;
                readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "status";
                readonly title: "Status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do acompanhamento do chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "statusEnum";
                    readonly kind: "enum";
                    readonly value: "[\"open\",\"closed\"]";
                    readonly description: "Status permitidos para o ciclo de atendimento do chamado.";
                    readonly source: "journey";
                }];
                readonly enum: readonly ["open", "closed"];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly ["open", "closed"];
            readonly lifecycle: {
                readonly workflowId: "chamadoLifecycle";
                readonly entityRef: "Chamado";
                readonly states: readonly ["closed", "open"];
                readonly initialState: "open";
                readonly terminalStates: readonly ["closed"];
                readonly allowed: {
                    readonly closed: readonly [];
                    readonly open: readonly ["closed"];
                };
            };
            readonly invariants: readonly ["O chamadoId deve ser único entre todos os chamados."];
        };
    };
    export default chamadoDomainEntity;
    export const pipeline: readonly [{
        readonly id: "chamado__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_3_domain/entities/comentario.defs" {
    export const comentarioDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Comentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly title: "Comentário";
            readonly fields: readonly [{
                readonly fieldId: "comentarioId";
                readonly title: "Identificador do comentário";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueComentarioId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada comentário possui um identificador estável e exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "chamadoId";
                readonly title: "Chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "atendenteId";
                readonly title: "Atendente que registrou";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "conteudo";
                readonly title: "Comentário";
                readonly type: "text";
                readonly required: true;
                readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "conteudoMinLength";
                    readonly kind: "minLength";
                    readonly value: "1";
                    readonly description: "O comentário deve conter texto.";
                    readonly source: "journey";
                }];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly [];
            readonly invariants: readonly ["comentarioId deve ser único e estável para cada comentário persistido.", "conteudo deve conter pelo menos 1 caractere.", "O comentário só pode ser registrado para um chamado com status aberto."];
        };
    };
    export default comentarioDomainEntity;
    export const pipeline: readonly [{
        readonly id: "comentario__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases" {
    /**
     * English catalogue slice for the E1-E6 clarification widgets.
     * Merged into NS4_PHRASES so the root planner translates widget chrome once per run.
     */
    export const NS4_WIDGET_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
    };
    export const NS4_WIDGET_KEYS: {
        readonly intake: readonly ["adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly journeys: readonly ["subtitle", "actor", "goal", "steps", "rules", "outcome", "filters", "impact", "noPolicyDecision", "journeys", "journeysFound", "selectJourney", "allActors", "actorMap", "actors", "overview", "actual", "rulesHelp", "adjustment", "placeholder", "requestChanges", "approve", "round", "step", "of", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly accessMatrix: readonly ["subtitle", "step", "of", "round", "profiles", "internal", "external", "actors", "landing", "matrix", "profileAccess", "authority", "noAccess", "full", "limited", "details", "reason", "scope", "disclosure", "allowed", "denied", "ruleRefs", "journeySteps", "informationNeeds", "close", "adjustment", "placeholder", "requestChanges", "approve", "adjustmentRequired", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly ontology: readonly ["subtitle", "step", "of", "round", "mode", "changes", "entities", "fields", "relationships", "lifecycle", "ruleRefs", "overview", "descriptions", "source", "storage", "required", "optional", "constraints", "persistenceMap", "persistenceHint", "targetMdm", "targetModuleDatabase", "targetDerived", "targetExternal", "targetEmbedded", "scope", "mdmType", "idField", "reason", "fieldRulesHint", "crossStore", "sourceRelationships", "destinationRelationships", "noRelationships", "implementation", "editInPlace", "direct", "directHint", "entityTitle", "entityDescription", "fieldTitle", "fieldDescription", "structural", "structuralHint", "placeholder", "request", "approve", "requiredAdjustment", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly rules: readonly ["step", "review", "rules", "search", "noRule", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint", "edit"];
        readonly composition: readonly ["step", "review", "empty", "horizontalModule", "plugin", "include", "defer", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint"];
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Text" {
    /**
     * Deterministic user-facing phrases of agentNewSolution. English is the only text in code.
     * The root planner translates the catalogue once per run into `presentation.phrases`; readers
     * fall back to this object when a key is missing. Placeholders `{name}` stay verbatim in every
     * language. Internal messages (throw, statusTask, trace) are English literals, not keys.
     */
    import { NS4_WIDGET_KEYS } from "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases";
    export const NS4_PHRASE_MAX_LENGTH: 200;
    export const NS4_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
        readonly 'catalogue.list.title': "List {entity}";
        readonly 'catalogue.list.story': "Find the record.";
        readonly 'catalogue.create.title': "Create {entity}";
        readonly 'catalogue.create.story': "Fill in the new record.";
        readonly 'catalogue.update.title': "Update {entity}";
        readonly 'catalogue.update.story': "Correct the chosen record.";
        readonly 'catalogue.section.recordList.intent': "Find {entity}.";
        readonly 'catalogue.section.recordForm.create.intent': "Create {entity}.";
        readonly 'catalogue.section.recordForm.edit.intent': "Create or correct {entity}.";
        readonly 'catalogue.purpose': "{entity} record catalogue.";
        readonly 'catalogue.delete.title': "Delete {entity}";
        readonly 'catalogue.delete.story': "Remove the chosen record.";
        readonly 'catalogue.inactivate.title': "Deactivate {entity}";
        readonly 'catalogue.inactivate.story': "Deactivate the record (history and references are preserved).";
        readonly 'catalogue.reactivate.title': "Reactivate {entity}";
        readonly 'catalogue.reactivate.story': "Reactivate a deactivated record.";
        readonly 'catalogue.get.title': "Get {entity}";
        readonly 'catalogue.get.story': "Read the record by id.";
        readonly 'catalogue.audience.question': "No journey operates {entity}: who maintains this catalogue?";
        readonly 'catalogue.audience.changeHint': "Add an E3 authority over {entity} to restrict this catalogue to a named profile.";
        readonly 'catalogue.list.search': "Search by {field}.";
        readonly 'catalogue.list.sortBy': "Field to sort the listing by.";
        readonly 'catalogue.list.sortOrder': "Sort direction.";
        readonly 'catalogue.list.page': "Listing page (1-based).";
        readonly 'catalogue.list.pageSize': "Page size (default 20, cap 200).";
        readonly 'journey.decide.description': "The decision taken.";
        readonly 'hub.purpose': "{entity} command centre.";
        readonly 'hub.section.collection.intent': "Portfolio and search.";
        readonly 'hub.section.record.intent': "The selected record and what revolves around it.";
        readonly 'projection.unjoined.question': "Use case {useCaseId} reads projection {projectionId} with no derived relationship to {entity}: E4 cannot join them. Omit from the output?";
        readonly 'projection.unjoined.changeHint': "Declare an E4 relationship with realization.kind derived between {projectionId} and {entity}.";
        readonly 'hub.composition.question': "The proposed composition for the {entity} dashboard did not respect the catalogue; use the default order?";
        readonly 'hub.composition.changeHint': "Review the order and highlights of the {entity} dashboard in the next round.";
        readonly 'workflow.unreachable.question': "How should the unreachable {entity}.{state} lifecycle state be handled?";
        readonly 'workflow.unreachable.changeHint': "Add an explicit E2 journey/operation that reaches {entity}.{state} before restoring it to the compiled workflow; the E4 ontology remains unchanged.";
        readonly 'workflow.predicate.question': "The {predicateId} criterion has no effect in this version — none of its states is reachable.";
        readonly 'workflow.predicate.changeHint': "Add an E2 journey that reaches one of {states}; the E5 rule and E4 ontology remain unchanged.";
        readonly 'workflow.omit.question': "{entity} has no operated state flow in this version.";
        readonly 'workflow.omit.changeHint': "Add an E2 journey that operates a {entity} transition; the E4 ontology remains unchanged.";
        readonly 'actor.drop.question': "Actor {actor} was inferred and has no exclusive step. Drop it?";
        readonly 'actor.drop.changeHint': "An inferred external actor whose steps another actor already performs is a persona, not an access role.";
        readonly 'actor.keep.question': "Actor {actor} was inferred and has exclusive steps. Keep it?";
        readonly 'actor.keep.changeHint': "The model invented this actor; exclusive steps are the reason it remains.";
        readonly 'actor.system.question': "Actor {actor} is a system integration point, not a persona. Keep it?";
        readonly 'actor.system.changeHint': "A kind:system actor is an inbound integration, not a demographic persona.";
        readonly 'demotion.chosen': "Standard {entity} record catalogue";
        readonly 'demotion.alternative': "Keep {journey} as its own journey";
        readonly 'demotion.question': "{journey} has no decision and no handoff: should it become the standard {entity} record catalogue?";
        readonly 'dormant.question': "The {title} action stays visible, but transition {transitions} is not reachable in this version.";
        readonly 'dormant.unwritten.question': "State {entity}.{state} is reached only by a transition whose use case does not write {entity}.";
        readonly 'state.unreachable.question': "State {entity}.{state} ({reachedBy}) has no reachable transition. Connect the command that writes it.";
        readonly 'state.filtered.question': "Operation {operation} filters by unreachable state {entity}.{state}.";
        readonly 'writes.beyond.question': "Use case {useCase} records {entities}, which the journey did not name as affected. Keep those writes?";
        readonly 'writes.beyond.changeHint': "Drop the extra writes on {useCase} or add {entities} to the act step affects list.";
        readonly 'route.ambiguous.question': "Which record should the {title} screen open directly?";
        readonly 'route.ambiguous.changeHint': "The {title} screen opens without a direct record link in this version; define a single target context to enable it.";
    };
    export type Ns4PhraseKey = keyof typeof NS4_PHRASES;
    export function isNs4PhraseKey(value: string): value is Ns4PhraseKey;
    export interface Ns4PhraseHolder {
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4PhrasesNormalization {
        phrases: Partial<Record<Ns4PhraseKey, string>>;
        warnings: string[];
    }
    export function ns4Text(presentation: Ns4PhraseHolder | undefined, key: Ns4PhraseKey, params?: Record<string, string>): string;
    type Ns4WidgetName = keyof typeof NS4_WIDGET_KEYS;
    export type Ns4WidgetLabelMap<W extends Ns4WidgetName> = {
        [K in (typeof NS4_WIDGET_KEYS)[W][number]]: string;
    };
    export function ns4WidgetLabels<W extends Ns4WidgetName>(presentation: Ns4PhraseHolder | undefined, widget: W): Ns4WidgetLabelMap<W>;
    export function normalizeNs4Phrases(value: unknown): Ns4PhrasesNormalization;
    export function ns4PlannerPhrasesAppendix(): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Core" {
    import { type Ns4PhraseKey } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export const NS4_FLOW_ID: "agentNewSolution";
    export const NS4_FLOW_VERSION: "2026-09-08-ns4-flow-v41";
    export const NS4_E4_MAX_PARALLEL: 20;
    export const NS4_E7_MAX_PARALLEL: 20;
    export const NS4_E8_MAX_PARALLEL: 20;
    export const NS4_MODULE_SCHEMA_VERSION: "2026-08-06-ns4-module-v4";
    export const NS4_PIPELINE_SCHEMA_VERSION: "2026-08-06-ns4-pipeline-v5";
    export type Ns4PermanentFlowVersion = typeof NS4_FLOW_VERSION | '2026-08-14-ns4-flow-v40' | '2026-08-14-ns4-flow-v39' | '2026-08-14-ns4-flow-v38' | '2026-08-14-ns4-flow-v37' | '2026-08-14-ns4-flow-v36' | '2026-08-14-ns4-flow-v35' | '2026-08-14-ns4-flow-v34' | '2026-08-13-ns4-flow-v33' | '2026-08-13-ns4-flow-v32' | '2026-08-13-ns4-flow-v31' | '2026-08-12-ns4-flow-v30' | '2026-08-11-ns4-flow-v24' | '2026-08-11-ns4-flow-v22' | '2026-08-10-ns4-flow-v21' | '2026-08-10-ns4-flow-v20' | '2026-08-09-ns4-flow-v19' | '2026-08-09-ns4-flow-v18' | '2026-08-08-ns4-flow-v17';
    export const NS4_PLAN_IDS: readonly ["e1-clarification", "e1-compile", "e2-journeys", "e3-access-matrix", "e4-ontology", "e4b-access-realization", "e5-rules", "e6-behaviors", "e7-realization", "e8-workspaces", "e9-navigation-compiler", "e10-validation"];
    export type Ns4PlanId = typeof NS4_PLAN_IDS[number];
    export const NS4_HUMAN_CHECKPOINT_ICON: "\uD83D\uDC64";
    export const NS4_AUTOMATED_JUDGE_ICON: "\uD83D\uDD0E";
    export type Ns4ApprovedBy = 'human' | 'auto';
    export type Ns4E1Status = 'running' | 'approved' | 'failed';
    export type Ns4E2Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E3Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4BStatus = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E5Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E6Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E7Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E8Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E9Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E10Status = 'running' | 'approved' | 'failed';
    export type Ns4CompletedStepId = 'e1' | 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation';
    export type Ns4NextStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation' | 'complete';
    export interface Ns4ClarificationQuestion {
        type: 'open';
        question: string;
        answer: string;
    }
    export interface Ns4Clarification {
        planId: 'e1-clarification';
        userLanguage: string;
        title: string;
        legends: string[];
        questions: Record<string, Ns4ClarificationQuestion>;
    }
    export interface Ns4Presentation {
        userLanguage: string;
        stepTitles: Record<Ns4PlanId, string>;
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4RootPlan {
        validPrompt: boolean;
        invalidReason?: string;
        userPrompt: string;
        presentation: Ns4Presentation;
        clarification: Ns4Clarification;
        phraseWarnings?: string[];
    }
    export const NS4_TERMINAL_CANCEL_UNSUPPORTED = "Terminal cancellation still depends on explicit collab-messages support; this review was kept open without changing the pipeline.";
    export const NS4_DESCRIBE_REQUIRED_CHANGE = "Describe the required change before submitting.";
    export interface Ns4ModuleArtifact {
        schemaVersion: typeof NS4_MODULE_SCHEMA_VERSION;
        presentation: Ns4Presentation;
        module: {
            moduleName: string;
            title: string;
            purpose: string;
            languages: string[];
        };
        designContext: {
            initialPrompt: string;
            clarification: {
                mainActors: string;
                mainGoal: string;
                boundaries: string;
            };
        };
        reviewPolicy: {
            mode: 'guided' | 'smart' | 'automatic';
        };
        solutionStrategy: {
            mode: 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
            rationale: string;
            databaseChangePolicy: 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                origin: 'named' | 'inferred';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        specStatus: {
            flowId: typeof NS4_FLOW_ID;
            /** v17 remains readable by tsc, but isNs4Pipeline deliberately rejects it for runtime resume. */
            flowVersion: Ns4PermanentFlowVersion;
            state: 'inProgress' | 'complete';
            artifactCompleteness: 'partial' | 'full';
            completedSteps: Array<{
                stepId: Ns4CompletedStepId;
                status: 'approved';
                approvedBy: Ns4ApprovedBy;
                approvedAt: string;
                /** Present when smart skipped the human checkpoint. */
                autoReason?: string;
            }>;
            nextStep: Ns4NextStep;
            updatedAt: string;
        };
    }
    export interface Ns4PipelineState {
        schemaVersion: typeof NS4_PIPELINE_SCHEMA_VERSION;
        flowId: typeof NS4_FLOW_ID;
        flowVersion: typeof NS4_FLOW_VERSION;
        moduleName: string;
        sourcePrompt: string;
        presentation: Ns4Presentation;
        status: 'inProgress' | 'complete' | 'failed';
        /** Audit of the last explicit regeneration: which step it restarted from, and when. */
        rebuiltFrom?: Ns4RebuildFrom;
        rebuiltAt?: string;
        /** Counts from `/rebuild all` (l1/l2/l4/l5 wipe). Survives on the regenerated pipeline for runNN_*.json. */
        rebuildAll?: Ns4RebuildAllReport;
        steps: {
            e1: {
                status: Ns4E1Status;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                skippedDefaults?: {
                    productLanguages: string[];
                    defaultLanguage: string;
                    moduleName: string;
                    i18nWarnings?: string[];
                };
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e2?: {
                status: Ns4E2Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e3?: {
                status: Ns4E3Status;
                reviewRound: number;
                draftPath?: string;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4?: {
                status: Ns4E4Status;
                reviewRound: number;
                solutionMode: 'new';
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4b?: {
                status: Ns4E4BStatus;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                repairStep?: 'e4-ontology' | 'e4b-access-realization';
                updatedAt: string;
            };
            e5?: {
                status: Ns4E5Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e6?: {
                status: Ns4E6Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e7?: {
                status: Ns4E7Status;
                planPath?: string;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e8?: {
                status: Ns4E8Status;
                reviewRound: number;
                skeletonPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e9?: {
                status: Ns4E9Status;
                artifactPaths?: string[];
                repairStep?: 'e8-workspaces' | 'e9-navigation-compiler';
                error?: string;
                failedAt?: string;
                approvedAt?: string;
                updatedAt: string;
            };
            e10?: {
                status: Ns4E10Status;
                reportPath?: string;
                artifactPaths?: string[];
                repairStep?: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>;
                error?: string;
                failedAt?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                updatedAt: string;
            };
        };
        nextStep: Ns4NextStep;
        createdAt: string;
        updatedAt: string;
        /**
         * E9 audit: an E7 use case that did not become an operation. Only `degraded` is persisted at the
         * top level — a clean emit strips both fields so a prior-run `degraded` cannot come back.
         */
        useCases?: 'degraded';
        useCasesDropped?: {
            notEmitted: string[];
            approved: number;
            emitted: number;
            reasons?: Record<string, string>;
        };
        /** Recorded when `/fast` dispatches the next agent, so a re-entry of E10 does not send twice. */
        fastHandoff?: {
            to: string;
            message: string;
            at: string;
        };
    }
    export type Ns4ExistingAction = 'new' | 'resume-e1' | 'resume-e2' | 'resume-e3' | 'resume-e4' | 'resume-e4b' | 'resume-e5' | 'resume-e6' | 'resume-e7' | 'resume-e8' | 'resume-e9' | 'resume-e10' | 'resume-next' | 'collision';
    /** Steps a partial rebuild can start from. e1 is not one of them: restarting at e1 IS a total rebuild. */
    export type Ns4RebuildFrom = 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /** `/rebuild all` is its own mode: wipe l1/l2/l4 of the module, then regenerate from the stored prompt. */
    export type Ns4RebuildArg = Ns4RebuildFrom | 'all';
    export interface Ns4RebuildAllReport {
        at: string;
        deleted: {
            l1: number;
            l2: number;
            l4: number;
            l5: number;
        };
        sanitized: {
            projectJsonRemoved: number;
            configJsonRemoved: number;
        };
    }
    export interface Ns4Invocation {
        fast: boolean;
        /** Explicit regeneration intent. Never inferred from prose — prose only produces a graceful stop. */
        rebuild: boolean;
        /** Set by `/rebuild all` or `/rebuild <eN>`; empty means the existing total rebuild (l4/l5 only). */
        rebuildFrom: Ns4RebuildArg | '';
        /** Suppress the next-agent handoff. Independent of `/fast`; `/nochainlane` does not match. */
        nochain: boolean;
        prompt: string;
    }
    export function parseNs4Invocation(value: string): Ns4Invocation;
    /**
     * A prompt that ASKS for a rebuild in prose and names an existing module.
     *
     * The incident this exists for: `rebuild all criar um site chamado petShop , em …`. The module name sits
     * mid-sentence, so `resolveNs4ExistingModuleToken` (which requires the WHOLE prompt to be one token) read
     * it as a new module, E1 ran, and the existence backstop killed the task — the user asked to rebuild and
     * got a terminal error.
     *
     * BOTH signals are required. Scanning tokens for an existing module name on its own would hijack an
     * ordinary creation prompt that happens to mention one ("a schedule module for petShop"); demanding
     * an explicit rebuild word keeps every prompt without one canonicalized exactly as before. The outcome is
     * only ever a message teaching the flag — nothing is written or deleted on this path.
     *
     * The rebuild word may be a flag (`/rebuild`): the slash sits where a start-or-space used to be
     * required, so the canonical form never reached this helper. Natural-language synonyms are not a
     * command; the status task names `/rebuild`.
     */
    export function detectNs4RebuildIntentModule(value: string, existingModules: ReadonlySet<string>): string;
    export function formatNs4MissingRebuildModuleMessage(existingModules: ReadonlySet<string>): string;
    export function createNs4E2Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E1Step(reviewRound?: number, adjustment?: string, previousReview?: unknown, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E2GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, coverageRepairAttempt: number, gateFeedback: string, stepTitle?: string, coverageIssueIds?: string[], policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E2CoverageRepairStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, coverageFeedback: string, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E2CoverageJudgeStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, judgeAttempt: number, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E3Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /**
     * One bounded structural repair for E3, mirroring the E2 gate repair: the model
     * sees the numbered gate findings plus the persisted invalid draft and returns a
     * complete corrected matrix through the same gate.
     */
    export function createNs4E3GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4RepairStep(moduleName: string, reviewRound: number, repairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4FinalizeStep(moduleName: string, reviewRound: number, dependsOn: string[], entityRepairRound?: number, planRepairAttempt?: number, derivationRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4RelationshipBindingStep(moduleName: string, reviewRound: number, bindingRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number): mls.msg.AIAgentStep;
    export function createNs4E4DerivationBindingStep(moduleName: string, reviewRound: number, derivationRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number, planRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4BStep(moduleName?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E5Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E6Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E7Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export type Ns4StepOwner = 'e1' | 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /**
     * The dispatch table, next to the factories that mint the plan ids it matches. The router and the
     * factories drifted apart once — a factory emitting `e8-workspaces-round-1` against a router that
     * only knew `e8-workspaces` — and the step died before reaching any agent, with no trace to read.
     * One table, one truth, and a test that walks every factory through it.
     */
    export function resolveNs4StepOwner(planId: string): Ns4StepOwner | '';
    /**
     * The E8 plan ids live in ONE place, next to the factories that mint them. The router matched a
     * hand-written pattern once and stopped seeing the real step: a plan id the factory emits and the
     * router does not recognize is a step that dies without ever reaching its agent.
     */
    export function ns4E8StepPlanId(reviewRound: number): string;
    export function ns4E8HubRepairPlanId(reviewRound: number, attempt: number): string;
    export function isNs4E8PlanId(planId: string): boolean;
    export function createNs4E8Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /** The one bounded repair E8 still schedules: the hub composition over its closed catalogue. */
    export function createNs4E8HubCompositionRepairStep(moduleName: string, reviewRound: number, compositionAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E9Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E10Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export const NS4_DEFAULT_TITLES: Record<Ns4PlanId, string>;
    export function formatNs4VisibleStepTitle(planId: Ns4PlanId, title: string): string;
    export function plainNs4StepTitle(title: string): string;
    /** Dynamic E4 children do not retain planning.planId; hook args are their stable dispatcher key. */
    export function resolveNs4DynamicWorker(value: unknown): 'e4' | 'e7' | 'e8' | '';
    export interface Ns4DynamicWorkerRequest {
        worker: 'e4' | 'e7' | 'e8' | '';
        args: string;
    }
    /**
     * collab-messages supplies the selector as hook args before a parallel prompt, but may omit those
     * args in the after-prompt callback while retaining the selector in step.prompt. Both callbacks must
     * resolve through the same ordered fallback or a valid entity payload reaches the root planner.
     */
    export function resolveNs4DynamicWorkerRequest(args: unknown, stepPrompt: unknown): Ns4DynamicWorkerRequest;
    export function normalizeNs4RootPlan(payload: unknown, sourcePrompt: string): Ns4RootPlan;
    export function buildNs4PlannedSteps(plan: Ns4RootPlan): mls.msg.AIAgentStep[];
    export function isNs4ModuleToken(value: string): boolean;
    export function normalizeNs4ModuleName(value: unknown, fallback?: string): string;
    export function resolveNs4ExistingModuleToken(value: string, existingModules: ReadonlySet<string>): string;
    export function normalizeNs4Clarification(value: unknown): Ns4Clarification;
    export function buildNs4ModuleArtifact(sourcePrompt: string, clarificationInput: unknown, approvedBy: Ns4ApprovedBy, now?: string, presentation?: Ns4Presentation): Ns4ModuleArtifact;
    export function normalizeNs4Languages(value: unknown, fallback?: string): string[];
    export function createNs4Pipeline(moduleNameInput: string, sourcePrompt: string, now?: string, presentation?: Ns4Presentation): Ns4PipelineState;
    export function markNs4E1Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, autoReason?: string, skippedDefaults?: {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        i18nWarnings?: string[];
    }): Ns4PipelineState;
    export function markNs4FastHandoff(state: Ns4PipelineState, to: string, message: string, now?: string): Ns4PipelineState;
    export function markNs4E2Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E1Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E2Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    /** A changed approved E2 contract invalidates only downstream contracts derived from journeys. */
    export function markNs4E2ImpactStale(state: Ns4PipelineState, hasJourneyImpact: boolean, now?: string): Ns4PipelineState;
    export function markNs4ModuleE2Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, invalidateDownstream?: boolean, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E3Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E3WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E3Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E3Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE3Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E4WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E4Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE4Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Stale(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BRunning(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E4BFailed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BApproved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE4BApproved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E5Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E5WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E5Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E5Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE5Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E6Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E6WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E6Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E6Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE6Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E7Running(state: Ns4PipelineState, planPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E7Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E7Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE7Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E8Running(state: Ns4PipelineState, reviewRound?: number, skeletonPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E8Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E8Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE8Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function markNs4E9Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E9Failed(state: Ns4PipelineState, failure: unknown, origin?: 'skeleton' | 'compiler', now?: string): Ns4PipelineState;
    export function markNs4E9Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE9Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E10Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    /**
     * E10 failed on a defect of the pipeline, not of the product: nothing upstream is stale, because
     * nothing upstream is wrong. The module waits on a fixed pipeline and re-validates from E10.
     */
    export function markNs4E10PipelineDefect(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Failed(state: Ns4PipelineState, failure: unknown, repairStep: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10RuntimeFailed(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, now?: string, reportPath?: string, artifactPaths?: string[]): Ns4PipelineState;
    export function markNs4ModuleE10Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function resolveNs4ExistingAction(moduleExists: boolean, pipeline: unknown, moduleArtifactExists: boolean): Ns4ExistingAction;
    /**
     * Everything a TOTAL rebuild archives: the module's whole l4 and l5 trees.
     *
     * The whole folder, not a list of known artifacts — that is the point. A previous run leaves drafts,
     * pipeline traces (`pipeline/msgtask*.json`) and per-entity defs whose names came from ITS ontology; a
     * selective delete keeps whatever the new run happens not to overwrite, and the module ends up a mix of
     * two generations. l2 is NOT touched: it belongs to agentChangeFrontend, which has its own rebuild.
     *
     * PURE over a `mls.stor.files`-shaped map so the selection is testable without the platform.
     */
    export function listNs4RebuildDeletionKeys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** eN and every step after it. */
    export function ns4RebuildRange(from: Ns4RebuildFrom): Ns4RebuildFrom[];
    /**
     * Resets eN..e10 for a partial rebuild.
     *
     * The reset is EXPLICIT and stamped (`rebuiltFrom`/`rebuiltAt`), which is what keeps rule 11 intact: an
     * approved state is never regressed by a late callback, only by an intent the user typed. The step entries
     * are dropped rather than set to a status, because e2..e10 are optional and "absent" is exactly what
     * "not done yet" means in this pipeline.
     */
    export function resetNs4PipelineForRebuild(pipeline: Ns4PipelineState, from: Ns4RebuildFrom, rebuiltAt?: string): Ns4PipelineState;
    /**
     * Drops the rebuilt range from the permanent artifact's completedSteps.
     *
     * Without this the reset is undone silently: the invocation reconciles the pipeline from
     * `specStatus.completedSteps` whenever the artifact says approved and the file still exists, so the very
     * next invocation would re-mark e10 approved and answer "pipeline encerrado" to a second /rebuild e10.
     */
    export function clearNs4ModuleCompletedStepsFrom(artifact: Ns4ModuleArtifact, from: Ns4RebuildFrom): Ns4ModuleArtifact;
    export function isNs4Pipeline(value: unknown): value is Ns4PipelineState;
    export function humanizeNs4ModuleName(moduleName: string): string;
    /** Display names of the language in the user's language, its own language and English. */
    export function ns4LanguageMentioned(language: string, userLanguage: string, foldedText: string): boolean;
    /** Lower case without diacritics, so a folded language name matches with or without marks. */
    export function foldNs4Text(value: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Resolve" {
    export type Ns4ResolutionClass = 'A' | 'B' | 'C';
    export interface Ns4SystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    interface Ns4ResolutionFindingBase {
        decisionId?: string;
        findingRef: string;
        stage: string;
        question: string;
        alternatives: string[];
        changeHint: string;
    }
    export interface Ns4TypeAFinding extends Ns4ResolutionFindingBase {
        classification: 'A';
    }
    export interface Ns4TypeBFinding extends Ns4ResolutionFindingBase {
        classification: 'B';
        /** The behavior already implicit in the generated artifact. */
        defaultChoice: string;
    }
    export interface Ns4TypeCFinding<TArtifact> extends Ns4ResolutionFindingBase {
        classification: 'C';
        deterministicChoice: string;
        apply: (artifact: TArtifact) => TArtifact;
    }
    export type Ns4ResolutionFinding<TArtifact> = Ns4TypeAFinding | Ns4TypeBFinding | Ns4TypeCFinding<TArtifact>;
    export interface Ns4ResolutionResult<TArtifact> {
        artifact: TArtifact;
        systemDecisions: Ns4SystemDecision[];
        unresolved: Array<Ns4TypeAFinding>;
    }
    /**
     * The single NS4 semantic-resolution boundary. Type A remains unresolved,
     * Type B records the generator's existing choice, and Type C applies its
     * caller-supplied mechanical patch before recording the decision.
     */
    export function resolveNs4Findings<TArtifact>(artifact: TArtifact, findings: Array<Ns4ResolutionFinding<TArtifact>>): Ns4ResolutionResult<TArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4/contracts" {
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4Level1Subtype } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export const NS4_ONTOLOGY_SCHEMA_VERSION: "2026-09-08-ns4-ontology-v7";
    export const NS4_ONTOLOGY_SCHEMA_VERSION_V6: "2026-08-11-ns4-ontology-v6";
    export type { Ns4Level1Subtype };
    /** Human-text JSON paths the importer may rewrite. Union of entity + index shapes that share this schemaVersion. */
    export const TEXT_PATHS_2026_09_08_ns4_ontology_v7: string[];
    export const TEXT_PATHS_2026_08_11_ns4_ontology_v6: string[];
    export const TEXT_PATHS_2026_08_09_ns4_ontology_v4: string[];
    export const TEXT_PATHS_2026_08_08_ns4_ontology_v3: string[];
    export type Ns4EntityKind = 'core' | 'event' | 'supporting' | 'mdm' | 'projection' | 'valueObject';
    /**
     * Is this entity a PARTY — a natural person or an organization?
     *
     * The question decides where the record lives, and it cannot be answered by a name heuristic (the run of
     * buildFlowFsm sent Client and Project to MDM but left FieldWorker — a person — as a module table, seeded,
     * duplicating the organization's own people). Declaring it makes the rule mechanical: a party is master
     * data of the organization, so `storage.target` must be `mdm`, and the gate says so instead of hoping the
     * prompt was read.
     */
    export type Ns4EntityParty = 'person' | 'organization' | 'none';
    export type Ns4EntityOwnership = 'moduleOwned' | 'external' | 'derived';
    export type Ns4DerivationOp = 'count' | 'sum' | 'min' | 'max' | 'first' | 'groupKey';
    /** One output field of a derived projection, computed from the source named by `derivation.from`. */
    export interface Ns4DerivationAggregate {
        fieldId: string;
        op: Ns4DerivationOp;
        /** Source-entity field when the op needs one (`sum`/`min`/`max`/`first`/`groupKey`). Absent for `count`. */
        sourceField?: string;
        /**
         * Sign of a `sum` from an enum on the source. OPTIONAL so L4 written before this field keeps
         * compiling — nothing is ever migrated. Only valid with `op: 'sum'`; `field` is an enum of
         * `derivation.from`, and rows whose value is in `negativeValues` enter the sum negative.
         */
        signBy?: {
            field: string;
            negativeValues: string[];
        };
    }
    /**
     * How a derived projection is computed. OPTIONAL on the type so L4 written before this field keeps
     * compiling — nothing is ever migrated. The E4 gate requires it on every `kind: projection` +
     * `ownership: derived` this generator now produces.
     */
    export interface Ns4EntityDerivation {
        /** entityId of the persisted source; must exist in the same ontology. */
        from: string;
        /** Predicate on declared fields of the source (`status = valid`). Empty when unfiltered. */
        filter: string;
        /** One entry per output field of the projection. */
        aggregate: Ns4DerivationAggregate[];
    }
    export type Ns4ConstraintSource = 'database' | 'journey' | 'user' | 'inferred' | 'legacyCode';
    export type Ns4StorageTarget = 'mdm' | 'moduleDatabase' | 'derived' | 'external' | 'embedded';
    export type Ns4StorageScope = 'organization' | 'module' | 'platform' | 'none';
    export type Ns4RelationshipPersistenceMode = 'mdmRelationship' | 'moduleReference' | 'crossStoreReference' | 'derivedJoin' | 'externalReference' | 'embedded';
    export type Ns4RelationshipRealizationKind = 'fieldReference' | 'fieldCollection' | 'mdmRelationship' | 'derived' | 'externalReference' | 'embedded';
    export interface Ns4RelationshipEndpointBinding {
        entityId: string;
        fieldIds: string[];
    }
    /** Concrete implementation of one semantic edge using fields that already exist in E4 entities. */
    export interface Ns4RelationshipRealization {
        kind: Ns4RelationshipRealizationKind;
        ownerEntity: string;
        from: Ns4RelationshipEndpointBinding;
        to: Ns4RelationshipEndpointBinding;
        description: string;
    }
    export interface Ns4FieldConstraint {
        constraintId: string;
        kind: 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'enum' | 'format' | 'unique' | 'custom';
        value: string;
        description: string;
        source: Ns4ConstraintSource;
    }
    /** Display text for one closed-domain code. Array-of-objects so the tool schema can stay additionalProperties:false. */
    export interface Ns4EnumLabel {
        code: string;
        label: string;
    }
    export interface Ns4OntologyField {
        fieldId: string;
        title: string;
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        required: boolean;
        description: string;
        constraints: Ns4FieldConstraint[];
        /**
         * The literal values of an enumerated field, derived from its enum constraint (or from the entity
         * lifecycle for a status field). It is what turns a decision into a closed selector on the page
         * instead of a free text box; the constraint stays as the human-readable rule.
         */
        enum?: string[];
        /**
         * User-language labels for `enum` codes. OPTIONAL on the type so L4 written before this field keeps
         * compiling — nothing is ever migrated. New E4 runs backfill any gap with a humanized code and a
         * non-blocking systemDecision; the model should still author the user's language.
         */
        enumLabels?: Ns4EnumLabel[];
    }
    export interface Ns4LifecyclePredicate {
        predicateId: string;
        description: string;
        stateIds: string[];
        source: Ns4ConstraintSource;
    }
    /** How a lifecycle state is reached. A gate reads this without an LLM. */
    export type Ns4LifecycleReachedBy = 'actor' | 'command' | 'time';
    /**
     * One lifecycle state of an entity. A bare string in authored JSON is `reachedBy: 'actor'`.
     * `time` is computed on read and is never a workflow transition; it requires `ruleRef`.
     */
    export interface Ns4LifecycleState {
        state: string;
        reachedBy: Ns4LifecycleReachedBy;
        ruleRef?: string;
    }
    export interface Ns4OntologyEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns4EntityKind;
        ownership: Ns4EntityOwnership;
        /**
         * A core entity with one fixed instance (a petition, an institutional page). OPTIONAL so L4
         * written before this field keeps compiling. E8 skips the record catalogue when it is present.
         */
        cardinality?: 'singleton';
        /**
         * Whether records of this entity may be corrected or removed after they exist. OPTIONAL so L4
         * written before this field keeps compiling — nothing is ever migrated; absent = editable.
         * `appendOnly` is a fact, a posting, a meter reading, a signature: E8 emits no update/delete.
         */
        mutability?: 'editable' | 'appendOnly';
        /**
         * Required by the gate for everything this generator now produces; OPTIONAL in the type so the L4
         * artifacts written before it (schema v6, no `party`) keep compiling — nothing is ever migrated.
         */
        party?: Ns4EntityParty;
        /**
         * Required by the gate when `kind === 'projection'` and `ownership === 'derived'`; OPTIONAL in the
         * type so L4 written before this field keeps compiling — nothing is ever migrated.
         */
        derivation?: Ns4EntityDerivation;
        /**
         * Required by the gate when `kind === 'mdm'`; OPTIONAL in the type so L4 written before this field
         * (schema v6) keeps compiling — nothing is ever migrated.
         */
        mdmSubtype?: Ns4Level1Subtype;
        /**
         * Module role tag `<moduleName>.<EntityId>`. Derived by the generator; not authored by the model.
         * OPTIONAL so L4 written before this field keeps compiling.
         */
        role?: string;
        /**
         * The field a person reads to recognise the record. A fieldId of this entity, or of the level-1
         * subtype when `kind === 'mdm'`. OPTIONAL in the type so v6 L4 keeps compiling; the gate requires it.
         */
        displayField?: string;
        sourceRefs: {
            journeyIds: string[];
            featureIds: string[];
            authorityRefs: string[];
        };
        fields: Ns4OntologyField[];
        lifecycleStates: Ns4LifecycleState[];
        /** The lifecycle values as a literal union; mirrors lifecycleStates and is never a second truth. */
        statusEnum?: string[];
        /** User-language labels for `lifecycleStates`. OPTIONAL on the type; new E4 runs backfill a gap. */
        lifecycleLabels?: Ns4EnumLabel[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates: Ns4LifecyclePredicate[];
        useRules: string[];
        storage: {
            target: Ns4StorageTarget;
            scope: Ns4StorageScope;
            idField?: string;
            mdmType?: string;
            notes: string;
        };
    }
    export interface Ns4OntologyRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        description: string;
        persistence: {
            mode: Ns4RelationshipPersistenceMode;
        };
        /** Absent only in the compact overview; mandatory before review and permanent emission. */
        realization?: Ns4RelationshipRealization;
    }
    export type Ns4ResolvedOntologyRelationship = Ns4OntologyRelationship & {
        realization: Ns4RelationshipRealization;
    };
    export type Ns4OntologyEntityPlan = Omit<Ns4OntologyEntity, 'fields' | 'useRules'>;
    export interface Ns4E4PlanDraft {
        planId: 'e4-ontology-plan';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntityPlan[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
    }
    export interface Ns4E4EntityDraft {
        planId: 'e4-ontology-entity';
        moduleName: string;
        reviewRound: number;
        entityId: string;
        fields: Ns4OntologyField[];
        useRules: string[];
        /** Field ids the model proposes for the organization `general` layer. Not stored on the entity. */
        promoteToGeneral?: string[];
    }
    export interface Ns4E4RelationshipBinding {
        relationshipId: string;
        realization: Ns4RelationshipRealization;
    }
    export interface Ns4E4RelationshipBindingsDraft {
        planId: 'e4-relationship-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4RelationshipBinding[];
    }
    export interface Ns4E4DerivationBinding {
        entityId: string;
        derivation: Ns4EntityDerivation;
    }
    export interface Ns4E4DerivationBindingsDraft {
        planId: 'e4-derivation-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4DerivationBinding[];
        changeSummary?: string[];
    }
    export interface Ns4E4DerivationBindingIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E4DerivationFieldIdChange {
        entityId: string;
        before: string[];
        after: string[];
    }
    /** Binding-gate finding that the entity fan-out must repair — travels as a typed payload, not a loose string. */
    export interface Ns4E4EntityFeedback {
        entityId: string;
        feedback: string;
    }
    export interface Ns4E4Review {
        planId: 'e4-ontology-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntity[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
        /** Type C label backfills and Type B registrars such as NS4_E4_CORE_READ_ONLY. */
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4E4ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E4Review;
    }
    export interface Ns4OntologyEntityArtifactV5 extends Ns4OntologyEntity {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyEntityArtifactV6 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3 L4 artifacts. */
    export interface Ns4OntologyEntityArtifactV4 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: '2026-08-09-ns4-ontology-v4';
    }
    export interface Ns4OntologyEntityArtifactV3 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion' | 'useRules'> {
        schemaVersion: '2026-08-08-ns4-ontology-v3';
        invariants: Array<{
            invariantId: string;
            description: string;
            source: Ns4ConstraintSource;
        }>;
    }
    export type Ns4OntologyEntityArtifact = Ns4OntologyEntityArtifactV5 | Ns4OntologyEntityArtifactV6 | Ns4OntologyEntityArtifactV4 | Ns4OntologyEntityArtifactV3;
    interface Ns4OntologyIndexArtifactBase {
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        title: string;
        businessDomain: string;
        entities: Array<{
            entityId: string;
            title: string;
            kind: Ns4EntityKind;
            storage: Pick<Ns4OntologyEntity['storage'], 'target' | 'scope' | 'idField' | 'mdmType'>;
            definitionRef: string;
        }>;
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromOntologyHash: string;
        };
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4OntologyIndexArtifactV5 extends Ns4OntologyIndexArtifactBase {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        relationships: Ns4ResolvedOntologyRelationship[];
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyIndexArtifactV6 extends Omit<Ns4OntologyIndexArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3/v4 L4 artifacts. */
    export interface Ns4OntologyIndexArtifactLegacy extends Ns4OntologyIndexArtifactBase {
        schemaVersion: '2026-08-09-ns4-ontology-v4' | '2026-08-08-ns4-ontology-v3';
        relationships: Ns4OntologyRelationship[];
    }
    export type Ns4OntologyIndexArtifact = Ns4OntologyIndexArtifactV5 | Ns4OntologyIndexArtifactV6 | Ns4OntologyIndexArtifactLegacy;
    export function normalizeNs4E4Review(value: unknown, fallbackModule?: string): Ns4E4Review;
    /** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
    export function humanizeNs4EnumCode(code: string): string;
    export function normalizeNs4E4PlanDraft(value: unknown, fallbackModule?: string): Ns4E4PlanDraft;
    export function normalizeNs4E4EntityDraft(value: unknown, moduleName: string, reviewRound: number, entityId: string): Ns4E4EntityDraft;
    /**
     * Removes the derived literal union from fields before they are echoed back to an entity worker.
     * The union is a projection E4 adds for the consumers; the worker's strict tool schema forbids the
     * key, so showing it in a prompt would invite an invalid repair answer.
     */
    export function stripNs4DerivedFieldUnions<T extends {
        fields?: unknown;
    }>(value: T): T;
    export function stripNs4DerivedFieldUnions(value: Ns4OntologyField[]): Ns4OntologyField[];
    export function assembleNs4E4Review(plan: Ns4E4PlanDraft, details: Ns4E4EntityDraft[]): Ns4E4Review;
    export function normalizeNs4E4RelationshipBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4RelationshipBindingsDraft;
    export function applyNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft): Ns4E4Review;
    export function normalizeNs4E4DerivationBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4DerivationBindingsDraft;
    export function applyNs4E4DerivationBindings(plan: Ns4E4PlanDraft, payload: unknown): {
        plan: Ns4E4PlanDraft;
        issues: Ns4E4DerivationBindingIssue[];
        fieldIdChanges: Ns4E4DerivationFieldIdChange[];
    };
    export function buildNs4OntologyArtifacts(review: Ns4E4Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<{
        entities: Ns4OntologyEntityArtifactV5[];
        index: Ns4OntologyIndexArtifactV5;
    }>;
    export function normalizeDerivation(value: unknown): Ns4EntityDerivation | undefined;
    /** Bare string = `actor`. After normalize, every entity carries objects. */
    export function normalizeLifecycleStates(value: unknown): Ns4LifecycleState[];
    export function lifecycleStateIds(states: ReadonlyArray<string | Ns4LifecycleState>): string[];
    export function hasLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
    export function lifecycleReachedBy(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): Ns4LifecycleReachedBy;
    export function lifecycleRuleRef(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): string;
    export function isTimeLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4EntityFields" {
    /**
     * Fields an NS artifact may name on an entity: declared `fields[]` plus the logical identity
     * `storage.idField` when that id is absent from the list (mdm after n04 is namespace-only).
     * Structural: never inferred from a field name.
     */
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_IDENTITY_FIELD_DESCRIPTION = "Logical record identity. Required uuid named by storage.idField.";
    export type Ns4EntityFieldsSource = {
        entityId?: string;
        kind?: string;
        fields?: ReadonlyArray<{
            fieldId: string;
            type?: Ns4OntologyField['type'];
            required?: boolean;
            description?: string;
            title?: string;
            constraints?: Ns4OntologyField['constraints'];
            enum?: string[];
            enumLabels?: Ns4OntologyField['enumLabels'];
        }>;
        storage?: {
            idField?: string;
        } | null;
    };
    export function ns4EntityIdField(entity: Ns4EntityFieldsSource | undefined | null): string;
    export function ns4ResolvableFields(entity: Ns4EntityFieldsSource | undefined | null): Ns4OntologyField[];
    export function ns4ResolvableFieldIds(entity: Ns4EntityFieldsSource | undefined | null): Set<string>;
    export function ns4ResolvableFieldOf(entity: Ns4EntityFieldsSource | undefined | null, fieldId: string): Ns4OntologyField | undefined;
    /** Compact entity payload for the E4 relationship-binding prompt: exact available fields. */
    export function ns4BindingPromptEntity(entity: Ns4EntityFieldsSource & {
        entityId: string;
    }): {
        entityId: string;
        kind?: string;
        storage: Ns4EntityFieldsSource['storage'];
        fields: Array<{
            fieldId: string;
            type: Ns4OntologyField['type'];
            required: boolean;
            description: string;
        }>;
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Context" {
    export type Ns4ContextStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export interface Ns4DerivedContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        idFieldRef?: string;
    }
    export interface Ns4DerivedStepContexts {
        journeyId: string;
        stepId: string;
        stepRef: string;
        kind: Ns4ContextStepKind;
        entity: string;
        /** True when the step introduces its own entity instead of operating on an existing record. */
        creates: boolean;
        requires: Ns4DerivedContext[];
        provides: Ns4DerivedContext[];
    }
    export interface Ns4DerivedContextGraph {
        catalog: Ns4DerivedContext[];
        steps: Ns4DerivedStepContexts[];
        byStepRef: Map<string, Ns4DerivedStepContexts>;
        entryByJourneyId: Map<string, Ns4DerivedContext[]>;
    }
    export interface Ns4ContextJourneyStep {
        stepId: string;
        kind: Ns4ContextStepKind;
        entity: string;
        affects?: string[];
        targetProfile?: string;
    }
    export interface Ns4ContextJourney {
        journeyId: string;
        business: {
            actorRef: string;
            entry: {
                mode: string;
                preferredFromJourneyRef?: string;
            };
            steps: Ns4ContextJourneyStep[];
        };
    }
    export interface Ns4ContextEntity {
        entityId: string;
        ownership?: string;
        storage?: {
            target?: string;
            scope?: string;
            idField?: string;
        };
        fields?: Array<{
            fieldId: string;
        }>;
    }
    export interface Ns4ContextRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
    }
    export interface Ns4ContextSources {
        journeys: {
            journeys: Ns4ContextJourney[];
        };
        ontology: {
            entities: Ns4ContextEntity[];
            relationships: Ns4ContextRelationship[];
        };
        access?: {
            profiles: Array<{
                profileId: string;
                actorRefs: string[];
            }>;
        };
    }
    /** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
    export function ns4ContextIdOf(entity: string): string;
    /**
     * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
     * summary (counts of the listing) — not getById of one record. Identity-free by construction.
     */
    export function isNs4CollectionInspect(steps: ReadonlyArray<{
        kind: string;
        entity: string;
    }>, index: number): boolean;
    /**
     * Platform-owned records are supplied by the runtime session, never selected by the user, so they
     * are not a coordination requirement of a business step.
     */
    export function isNs4PlatformOwnedEntity(entity: Ns4ContextEntity): boolean;
    export function deriveNs4Contexts(sources: Ns4ContextSources): Ns4DerivedContextGraph;
    /** Business objects the ontology must realize: exactly the entities the journeys operate on. */
    export function collectNs4JourneyEntities(journeys: {
        journeys: Ns4ContextJourney[];
    }): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageSignals" {
    export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL: "moduleWithoutDecide";
    export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL: "journeyWithoutProcess";
    export interface Ns4E2StepKindHistogram {
        locate: number;
        inspect: number;
        act: number;
        decide: number;
        handoff: number;
    }
    export type Ns4E2MechanicalFindingSeverity = 'registrar';
    export interface Ns4E2MechanicalCoverageFinding {
        signalId: typeof NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL;
        severity: Ns4E2MechanicalFindingSeverity;
    }
    export interface Ns4E2MechanicalCoverageReport {
        stepKindHistogram: Ns4E2StepKindHistogram;
        findings: Ns4E2MechanicalCoverageFinding[];
        /** Journeys that carry no process: pure capture or maintenance of one record catalogue. */
        captureOnlyJourneys: Array<{
            journeyId: string;
            entity: string;
        }>;
    }
    interface Ns4E2StepSource {
        journeys: Array<{
            journeyId?: unknown;
            business: {
                steps: Array<{
                    kind: unknown;
                    entity?: unknown;
                    affects?: unknown;
                }>;
            };
        }>;
    }
    export function analyzeNs4E2MechanicalCoverage(source: Ns4E2StepSource): Ns4E2MechanicalCoverageReport;
    /**
     * A journey with no decision, no handoff and one single entity is the record catalogue of that
     * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
     * a visible product choice instead of shipping the same catalogue twice.
     */
    export function ns4E2DemotionDecisionId(journeyId: string): string;
    export function isNs4E2DemotionDecisionId(decisionId: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/contracts" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2StepKindHistogram } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-v5";
    export const NS4_JOURNEY_INDEX_SCHEMA_VERSION: "2026-08-15-ns4-journey-index-v7";
    export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-realized-v5";
    export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION: "2026-08-13-ns4-e2-impact-report-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_journey_v5: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_realized_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_v1: string[];
    export const TEXT_PATHS_2026_08_15_ns4_journey_index_v7: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_index_v6: string[];
    export const TEXT_PATHS_2026_08_12_ns4_journey_index_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_index_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_index_v1: string[];
    export type Ns4JourneyEntryMode = 'coldStart' | 'contextRequired' | 'contextOrLookup' | 'eventDriven';
    export type Ns4JourneyStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export type Ns4FeaturePriority = 'now' | 'next' | 'later';
    /**
     * A step names what it does and to which business record. Everything about context — who provides
     * it, what it carries, how many — is derived by helpers/ns4Context.ts from this entity, the step
     * kind, the journey sequence and the approved ontology.
     */
    export interface Ns4JourneyStep {
        stepId: string;
        kind: Ns4JourneyStepKind;
        entity: string;
        /**
         * Other business objects this act also changes. Same vocabulary as `entity`
         * (PascalCase ids, no fields, no transition). Absent when the step records only `entity`.
         */
        affects?: string[];
        title: string;
        description: string;
        featureRefs: string[];
        /** Only a handoff names the receiving E3 profile; it is the routing fact E9 compiles. */
        targetProfile?: string;
    }
    export interface Ns4JourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
        };
        steps: Ns4JourneyStep[];
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    /** Frozen shape of journeys written by flow versions before the context graph became derived. */
    export interface Ns4LegacyJourneyContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        description: string;
        stateRequirement?: string;
    }
    export interface Ns4LegacyJourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        prerequisites: Array<{
            journeyRef: string;
            reason: string;
            required: boolean;
            providesContext: string[];
        }>;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
            carries: Ns4LegacyJourneyContext[];
        };
        steps: Array<{
            stepId: string;
            kind: Ns4JourneyStepKind;
            intent: string;
            requiresContext: string[];
            providesContext: Ns4LegacyJourneyContext[];
            result: string;
            featureRefs: string[];
        }>;
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    export interface Ns4JourneyProposal {
        journeyId: string;
        business: Ns4JourneyBusiness;
        policyDecisions: Ns4PolicyDecision[];
    }
    /** A product choice made while generating a journey, before any human review. */
    export interface Ns4PolicyDecision {
        decisionId: string;
        question: string;
        chosen: string;
        alternatives: string[];
        /** Only the independent E2 judge may add this explanation. */
        impact?: string;
        relatedJourneyIds?: string[];
    }
    /** Durable audit record of the choice the reviewer approved. */
    export interface Ns4PolicyDecisionSelection {
        decisionId: string;
        generatedChoice: string;
        selectedChoice: string;
        selectedBy: 'human' | 'auto';
        selectedAt: string;
    }
    export interface Ns4E2Feature {
        featureId: string;
        title: string;
        priority: Ns4FeaturePriority;
        journeyStepRefs: string[];
    }
    export interface Ns4E2Review {
        planId: 'e2-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        journeys: Ns4JourneyProposal[];
        features: Ns4E2Feature[];
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4JourneyArtifactV5 extends Ns4JourneyProposal {
        schemaVersion: typeof NS4_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'pending';
            contexts: Record<string, never>;
        };
        realization: {
            status: 'pending';
            compiledFromBusinessHash: string;
            steps: never[];
            transitionRefs: never[];
        };
    }
    /** The derived context, plus the structural provenance E7 records for the compiled journey. */
    export interface Ns4JourneyResolvedContext extends Ns4DerivedContext {
        sourceRefs: string[];
        consumerStepRefs: string[];
    }
    export interface Ns4JourneyStepRealization {
        stepId: string;
        useCaseRefs: string[];
    }
    export interface Ns4JourneyArtifactV5Realized extends Omit<Ns4JourneyProposal, 'policyDecisions'> {
        schemaVersion: typeof NS4_REALIZED_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'compiled';
            contexts: Record<string, Ns4JourneyResolvedContext>;
        };
        realization: {
            status: 'compiled';
            compiledFromBusinessHash: string;
            steps: Ns4JourneyStepRealization[];
            transitionRefs: string[];
            realizationHash: string;
        };
    }
    /**
     * Compile-only compatibility for permanent artifacts written by previous flow versions. They are
     * never resumed or migrated; the union only keeps already-generated L4 modules type-safe.
     */
    export interface Ns4LegacyJourneyArtifact {
        schemaVersion: '2026-08-04-ns4-journey-v1' | '2026-08-09-ns4-journey-v2' | '2026-08-10-ns4-journey-v3' | '2026-08-10-ns4-journey-v4';
        journeyId: string;
        revision: number;
        business: Ns4LegacyJourneyBusiness | (Omit<Ns4LegacyJourneyBusiness, 'useRules'> & {
            businessRules: Array<{
                journeyRuleId: string;
                statement: string;
            }>;
        });
        policyDecisions?: Ns4PolicyDecision[];
        businessHash: string;
        resolution: {
            status: 'pending' | 'compiled';
            contexts: Record<string, unknown>;
        };
        realization: {
            status: 'pending' | 'compiled';
            compiledFromBusinessHash: string;
            steps: Array<{
                stepId: string;
                useCaseRefs: string[];
            }>;
            transitionRefs: string[];
            realizationHash?: string;
        };
    }
    export type Ns4JourneyArtifact = Ns4JourneyArtifactV5 | Ns4JourneyArtifactV5Realized | Ns4LegacyJourneyArtifact;
    /** A journey written by a previous flow version still declares its context graph; it is never compiled. */
    export function isNs4CurrentJourneyBusiness(value: Ns4JourneyArtifact['business']): value is Ns4JourneyBusiness;
    export interface Ns4JourneyIndex {
        schemaVersion: typeof NS4_JOURNEY_INDEX_SCHEMA_VERSION | '2026-08-14-ns4-journey-index-v6' | '2026-08-12-ns4-journey-index-v5' | '2026-08-10-ns4-journey-index-v4' | '2026-08-04-ns4-journey-index-v1' | '2026-08-10-ns4-journey-index-v3' | '2026-08-09-ns4-journey-index-v2';
        moduleName: string;
        approvedAt: string;
        approvedBy: 'human' | 'auto';
        journeys: Array<{
            journeyId: string;
            actorRef: string;
            title: string;
            goal: string;
            entryMode: Ns4JourneyEntryMode;
            businessHash: string;
            artifactPath: string;
            useCaseRefs?: string[];
        }>;
        features: Ns4E2Feature[];
        /**
         * The decisions themselves, next to the selections that answer them. This is their durable home:
         * the journey artifact carries a copy while E2 is still reviewing, and E7 rewrites the artifact as
         * realized-v5, which has no policyDecisions — everything read after E7 reads the index.
         */
        policyDecisions?: Ns4JourneyIndexPolicyDecision[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        systemDecisions?: Ns4SystemDecision[];
        realizationHash?: string;
    }
    /** A policy decision with the journey that owns it; the index is flat, journeys reference by id. */
    export interface Ns4JourneyIndexPolicyDecision extends Ns4PolicyDecision {
        journeyRef: string;
    }
    export interface Ns4E2ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E2Review;
        policyDecisionSelections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>;
    }
    export interface Ns4E2ImpactReport {
        schemaVersion: typeof NS4_E2_IMPACT_REPORT_SCHEMA_VERSION;
        moduleName: string;
        generatedAt: string;
        stepKindHistogram: Ns4E2StepKindHistogram;
        changes: Array<{
            journeyId: string;
            reason: 'hashDivergent' | 'journeyNew' | 'journeyRemoved';
        }>;
        affectedSteps: Array<'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e7-realization'>;
    }
    export function normalizeNs4E2Review(value: unknown, fallbackModule?: string, presentation?: Ns4Presentation): Ns4E2Review;
    export function buildNs4JourneyArtifacts(review: Ns4E2Review): Promise<Ns4JourneyArtifactV5[]>;
    export function buildNs4JourneyIndex(moduleName: string, review: Ns4E2Review, artifacts: Ns4JourneyArtifactV5[], artifactPaths: string[], approvedBy: 'human' | 'auto', approvedAt: string, policyDecisionSelections?: Ns4PolicyDecisionSelection[]): Ns4JourneyIndex;
    export function buildNs4PolicyDecisionSelections(review: Ns4E2Review, selectedChoices: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, selectedBy: 'human' | 'auto', selectedAt: string): Ns4PolicyDecisionSelection[];
    export function buildNs4E2ImpactReport(moduleName: string, previousIndex: Ns4JourneyIndex | null, artifacts: Array<Pick<Ns4JourneyArtifactV5, 'journeyId' | 'businessHash'>>, generatedAt: string, review: Pick<Ns4E2Review, 'journeys'>): Ns4E2ImpactReport;
    export function sha256Ns4(value: unknown): Promise<string>;
    export function stableNs4Stringify(value: unknown): string;
    /**
     * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
     * journeys and ontology entities. The transformation is intentionally lexical: it never translates
     * or substitutes a domain noun.
     */
    export function normalizeNs4BusinessObjectId(value: unknown): string;
    /**
     * A journey with no decision, no handoff and one single entity IS the record catalogue of that
     * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
     * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
     * deterministic: it is recomputed on every round and is never authored by the generator.
     */
    export function withNs4DemotionDecisions(journeys: Ns4JourneyProposal[], presentation?: Ns4Presentation): Ns4JourneyProposal[];
    /** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
    export function collectNs4DemotedJourneyIds(review: Pick<Ns4E2Review, 'journeys'>, selections?: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>): string[];
    /** Business objects that later ontology compilation must realize as entities or projections. */
    export function collectNs4RequiredJourneyBusinessObjects(review: Ns4E2Review): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e3/contracts" {
    export const NS4_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-09-ns4-access-matrix-v2";
    export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-10-ns4-access-matrix-v3";
    export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-13-ns4-access-matrix-v4";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_access_matrix_v2: string[];
    export const TEXT_PATHS_2026_08_10_ns4_access_matrix_v3: string[];
    export const TEXT_PATHS_2026_08_13_ns4_access_matrix_v4: string[];
    export const TEXT_PATHS_2026_08_05_ns4_access_matrix_v1: string[];
    export type Ns4AccessProfileKind = 'internal' | 'external';
    export type Ns4AccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type Ns4DisclosureMode = 'fullRecord' | 'summaryOnly' | 'fieldsOnly' | 'aggregateOnly';
    export interface Ns4AccessProfile {
        profileId: string;
        title: string;
        kind: Ns4AccessProfileKind;
        description: string;
        actorRefs: string[];
        landingIntent: string;
    }
    export interface Ns4AccessAuthority {
        authorityRef: string;
        title: string;
        description: string;
        journeyStepRefs: string[];
        informationNeeds: string[];
    }
    export interface Ns4AccessGrant {
        profileRef: string;
        authorityRef: string;
        reason: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        useRules: string[];
    }
    export interface Ns4E3Review {
        planId: 'e3-access-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        changeSummary: string[];
    }
    export interface Ns4E3ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E3Review;
    }
    export interface Ns4AccessMatrixArtifactV2 {
        schemaVersion: typeof NS4_ACCESS_MATRIX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        accessHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromAccessHash: string;
            operationAuthorityRefs: never[];
        };
    }
    export interface Ns4AccessUseCaseAuthorityRef {
        useCaseId: string;
        authorityRef: string;
        journeyStepRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV3 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'useCasesCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            realizationHash: string;
        };
    }
    export interface Ns4AccessOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        useCaseId?: string;
        authorityRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV4 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'navigationCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: Ns4AccessOperationAuthorityRef[];
            realizationHash: string;
        };
    }
    /** Compile-only compatibility for already generated v1 L4 artifacts. */
    export interface Ns4AccessMatrixArtifactV1 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'grants'> {
        schemaVersion: '2026-08-05-ns4-access-matrix-v1';
        grants: Array<Omit<Ns4AccessGrant, 'useRules'> & {
            constraints: string[];
        }>;
    }
    export type Ns4AccessMatrixArtifact = Ns4AccessMatrixArtifactV4 | Ns4AccessMatrixArtifactV3 | Ns4AccessMatrixArtifactV2 | Ns4AccessMatrixArtifactV1;
    export function normalizeNs4E3Review(value: unknown, fallbackModule?: string): Ns4E3Review;
    export function buildNs4AccessMatrixArtifact(review: Ns4E3Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4AccessMatrixArtifactV2>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4b/contracts" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessGrant, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4DerivationAggregate, Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_ACCESS_BINDINGS_SCHEMA_VERSION: "2026-09-08-ns4-access-bindings-v1";
    export const NS4_PERSON_LOGIN_FIELD: "platformUserId";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_08_ns4_access_bindings_v1: string[];
    export const NS4_SYNTH_AUTHORITY_PREFIX: "synth:";
    export const NS4_LIMITED_DISCLOSURE_MODES: readonly Ns4DisclosureMode[];
    export type Ns4AnchorDirection = 'forward' | 'incoming';
    export interface Ns4AccessAnchorHop {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export interface Ns4AccessAnchor {
        hops: Ns4AccessAnchorHop[];
        terminus: {
            entityRef: string;
            fieldId: typeof NS4_PERSON_LOGIN_FIELD;
        };
    }
    export interface Ns4AccessBinding {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        anchor: Ns4AccessAnchor | null;
        /** Present when `anchor` is null: organization / custom / public have no person path. */
        anchorReason?: string;
        /**
         * Machine artifact (E4B): entityId of the disclosure projection for a limited external grant.
         * Not a field on the human grant.
         */
        projectionRef?: string;
        /**
         * Machine artifact (E4B): field ids the model excluded from the disclosure view, for a human to read.
         * Not a field on the human grant.
         */
        excludedFields?: string[];
    }
    export interface Ns4SynthesizedAuthority {
        authorityRef: string;
        entityRef: string;
        profileRef: string;
        dataScope: Ns4AccessBinding['dataScope'];
        disclosure: Ns4AccessBinding['disclosure'];
        sourceGrant: {
            profileRef: string;
            authorityRef: string;
        };
        anchor: Ns4AccessAnchor | null;
    }
    export interface Ns4AccessBindingsArtifact {
        schemaVersion: typeof NS4_ACCESS_BINDINGS_SCHEMA_VERSION;
        moduleName: string;
        compiledFromAccessHash: string;
        compiledFromOntologyHash: string;
        bindings: Ns4AccessBinding[];
        synthesizedAuthorities: Ns4SynthesizedAuthority[];
        bindingsHash: string;
    }
    export interface Ns4E4BProjectionProposal {
        fields: string[];
        excludedFields: string[];
        /** aggregateOnly: derivation ops. Absent for a field-subset view (`op: first` per field). */
        aggregate?: Ns4DerivationAggregate[];
    }
    export interface Ns4E4BProposal {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        hops: Ns4AccessAnchorHop[];
        /** The model names a field the ontology does not have; the gate turns this into a finding. */
        missingField?: {
            entityRef: string;
            fieldId: string;
        };
        /** Disclosure view extracted from grant prose. Machine artifact, not a human grant field. */
        projection?: Ns4E4BProjectionProposal;
    }
    export interface Ns4E4BSources {
        moduleName: string;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        journeys: Ns4E2Review;
        accessHash: string;
        ontologyHash: string;
        /** Optional: E5 has not run yet on a first pass; present on resume/rebuild. */
        rules?: Array<{
            id: string;
            description: string;
        }>;
    }
    export interface Ns4E4BFinding {
        code: string;
        path: string;
        message: string;
        repairStep?: 'e4-ontology' | 'e4b-access-realization';
    }
    export interface Ns4E4BCompileResult {
        artifact: Ns4AccessBindingsArtifact;
        /** Disclosure views to persist as `ontology/<Entity><Profile>View.defs.ts`. Not added to the E4 index. */
        projections: Ns4OntologyEntity[];
        findings: Ns4E4BFinding[];
    }
    export function ns4SynthesizedAuthorityRef(entityRef: string, profileRef: string): string;
    export function ns4DisclosureProjectionId(entityRef: string, profileRef: string): string;
    export function ns4NeedsDisclosureProjection(grant: Ns4AccessGrant, profileKind: string | undefined): boolean;
    export function ns4GrantCoversEntity(grant: Ns4AccessGrant, entityRef: string, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): boolean;
    export function ns4EntityIdsCoveredByGrant(grant: Ns4AccessGrant, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    /** Catalogue audience: profiles with an organization-scope grant covering the entity. */
    export function ns4CatalogueProfileIds(entityRef: string, access: Pick<Ns4E3Review, 'grants' | 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    export function ns4JourneyAuthorityRefs(compiledFrom: string[], access: Pick<Ns4E3Review, 'authorities'>): string[];
    export function compileNs4AccessBindings(sources: Ns4E4BSources, proposals?: Ns4E4BProposal[]): Promise<Ns4E4BCompileResult>;
    export function isPersonEntity(entity: Ns4OntologyEntity): boolean;
    export interface Ns4AccessFieldEdge {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export function ns4AccessFieldGraph(ontology: Pick<Ns4E4Review, 'relationships'>): Ns4AccessFieldEdge[];
    export function checkAnchorPath(hops: Ns4AccessAnchorHop[], startEntity: string, graph: Ns4AccessFieldEdge[], personEntities: Set<string>, path: string): {
        anchor?: Ns4AccessAnchor;
        finding?: Ns4E4BFinding;
    };
    export function missingFieldFinding(path: string, entityRef: string, fieldId: string): Ns4E4BFinding;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/contracts" {
    export const NS4_RULES_SCHEMA_VERSION: "2026-08-09-ns4-rules-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_rules_v2: string[];
    /** The permanent business-rule contract. Meaning lives here; consumers keep only the id. */
    export interface Ns4RuleDefinition {
        id: string;
        description: string;
    }
    export interface Ns4E5Review {
        planId: 'e5-rules-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        rules: Ns4RuleDefinition[];
        changeSummary: string[];
    }
    export interface Ns4E5ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E5Review;
    }
    export interface Ns4RulesArtifact {
        schemaVersion: typeof NS4_RULES_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        rules: Ns4RuleDefinition[];
        rulesHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromRulesHash: string;
        };
    }
    export function normalizeNs4E5Review(value: unknown, fallbackModule?: string): Ns4E5Review;
    export function buildNs4RulesArtifact(review: Ns4E5Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4RulesArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/contracts" {
    export const NS4_COMPOSITION_SCHEMA_VERSION: "2026-08-09-ns4-composition-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_composition_v1: string[];
    export type Ns4AdditionalCapabilityKind = 'horizontalModule' | 'plugin';
    export type Ns4AdditionalCapabilityDecision = 'include' | 'defer';
    export interface Ns4AdditionalCapability {
        id: string;
        kind: Ns4AdditionalCapabilityKind;
        title: string;
        purpose: string;
        decision: Ns4AdditionalCapabilityDecision;
        /** True when the capability is already realized by a sibling module (reuse, never a new module). */
        existing?: boolean;
    }
    export interface Ns4E6Review {
        planId: 'e6-composition-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        changeSummary: string[];
    }
    export interface Ns4E6ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E6Review;
    }
    export interface Ns4CompositionArtifact {
        schemaVersion: typeof NS4_COMPOSITION_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        compositionHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromCompositionHash: string;
        };
    }
    export function normalizeNs4E6Review(value: unknown, fallbackModule?: string): Ns4E6Review;
    export function buildNs4CompositionArtifact(review: Ns4E6Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4CompositionArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/contracts" {
    import type { Ns4E2Review, Ns4JourneyArtifact, Ns4JourneyArtifactV5Realized, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact, Ns4AccessMatrixArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USE_CASE_DRAFT_VERSION: "2026-09-09-ns4-usecase-draft-v4";
    export const NS4_USE_CASE_SCHEMA_VERSION: "2026-09-09-ns4-usecase-v4";
    export const NS4_USE_CASE_INDEX_SCHEMA_VERSION: "2026-09-09-ns4-usecase-index-v4";
    export const NS4_WORKFLOW_SCHEMA_VERSION: "2026-08-11-ns4-workflow-v4";
    export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION: "2026-08-12-ns4-workflow-index-v5";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_09_ns4_usecase_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v3: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v2: string[];
    export const TEXT_PATHS_2026_09_09_ns4_usecase_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_index_v2: string[];
    /** Workflow artifacts are ids and transitions; no human prose. */
    export const TEXT_PATHS_2026_08_11_ns4_workflow_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_v1: string[];
    export const TEXT_PATHS_2026_08_12_ns4_workflow_index_v5: string[];
    export const TEXT_PATHS_2026_08_11_ns4_workflow_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_index_v1: string[];
    export type Ns4UseCaseKind = 'query' | 'command';
    export type Ns4UseCaseFieldType = Ns4OntologyField['type'];
    export interface Ns4E7SourceHashes {
        journeys: Array<{
            journeyId: string;
            businessHash: string;
        }>;
        ontologyHash: string;
        rulesHash: string;
    }
    export interface Ns4E7PlanUseCase {
        useCaseId: string;
        title: string;
        kind: Ns4UseCaseKind;
        compiledFrom: string[];
        contexts: {
            requires: string[];
            provides: string[];
        };
    }
    export interface Ns4E7PlanDraft {
        planId: 'e7-realization-plan';
        moduleName: string;
        userLanguage: string;
        useCases: Ns4E7PlanUseCase[];
        sourceHashes: Ns4E7SourceHashes;
        presentation?: Ns4Presentation;
    }
    export interface Ns4UseCaseFieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4UseCaseInput {
        inputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseOutput {
        outputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        contextId?: string;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseEntityAccess {
        entityId: string;
        fieldRefs: string[];
    }
    /** Entities this behavior records. fieldRefs optional: omit when the whole record is written. */
    export interface Ns4UseCaseWrite {
        entityId: string;
        fieldRefs?: string[];
    }
    export interface Ns4UseCaseTransition {
        transitionId: string;
        entityRef: string;
        fromStates: string[];
        toState: string;
        useRules: string[];
    }
    export interface Ns4UseCaseError {
        errorId: string;
        description: string;
        when: string;
        useRules: string[];
    }
    export interface Ns4UseCaseDraft extends Ns4E7PlanUseCase {
        draftVersion: typeof NS4_USE_CASE_DRAFT_VERSION;
        planId: 'e7-usecase';
        moduleName: string;
        description: string;
        contexts: {
            requires: string[];
            provides: string[];
        };
        entityRefs: string[];
        writes: Ns4UseCaseWrite[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
    }
    export interface Ns4UseCaseArtifactV3 extends Omit<Ns4UseCaseDraft, 'planId' | 'draftVersion' | 'transitions'> {
        schemaVersion: typeof NS4_USE_CASE_SCHEMA_VERSION;
        transitionRefs: string[];
        useCaseHash: string;
    }
    export interface Ns4UseCaseIndexArtifactV3 {
        schemaVersion: typeof NS4_USE_CASE_INDEX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4WorkflowTransition extends Ns4UseCaseTransition {
        useCaseId?: string;
        trigger?: 'system';
    }
    /** Lifecycle facts are owned by E4 and copied mechanically into E7 workflows. */
    export interface Ns4WorkflowLifecycleDefinition {
        states: string[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
        /** Per-state `reachedBy`. Absent keys default to `actor`. `time` never enters the workflow. */
        reachedBy?: Record<string, 'actor' | 'command' | 'time'>;
    }
    export function workflowLifecycleOf(entity: {
        lifecycleStates: Array<string | {
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
    }): Ns4WorkflowLifecycleDefinition;
    export interface Ns4WorkflowArtifactV2 {
        schemaVersion: typeof NS4_WORKFLOW_SCHEMA_VERSION;
        moduleName: string;
        workflowId: string;
        entityRef: string;
        initialState: string;
        terminalStates: string[];
        states: string[];
        transitions: Ns4WorkflowTransition[];
        workflowHash: string;
    }
    export interface Ns4WorkflowIndexArtifactV2 {
        schemaVersion: '2026-08-11-ns4-workflow-index-v4';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifactV3 extends Omit<Ns4WorkflowIndexArtifactV2, 'schemaVersion'> {
        schemaVersion: typeof NS4_WORKFLOW_INDEX_SCHEMA_VERSION;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4UseCaseArtifact extends Ns4E7PlanUseCase {
        schemaVersion: '2026-08-10-ns4-usecase-v2';
        moduleName: string;
        description: string;
        inputs: Ns4UseCaseInput[];
        outputs: Ns4UseCaseOutput[];
        reads: Ns4UseCaseEntityAccess[];
        writes: Ns4UseCaseEntityAccess[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
        errors: Ns4UseCaseError[];
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCaseHash: string;
        generatedAt: string;
    }
    export interface Ns4UseCaseIndexArtifact {
        schemaVersion: '2026-08-10-ns4-usecase-index-v2';
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-v1';
        moduleName: string;
        userLanguage: string;
        workflowId: string;
        entityRef: string;
        states: string[];
        transitions: Ns4WorkflowTransition[];
        sourceHashes: Ns4E7SourceHashes;
        workflowHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-index-v1';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    /** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
    export function buildNs4E7Plan(moduleName: string, userLanguage: string, journeys: Ns4E2Review, sourceHashes: Ns4E7SourceHashes, contexts: Ns4DerivedContextGraph, presentation?: Ns4Presentation): Ns4E7PlanDraft;
    export function normalizeNs4UseCaseDraft(value: unknown, plan: Ns4E7PlanDraft, useCaseId: string): Ns4UseCaseDraft;
    export function buildNs4UseCaseArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], generatedAt: string, systemDecisions?: Ns4SystemDecision[]): Promise<{
        artifacts: Ns4UseCaseArtifactV3[];
        index: Ns4UseCaseIndexArtifactV3;
    }>;
    export function buildNs4WorkflowArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], ontologyLifecycles: Map<string, Ns4WorkflowLifecycleDefinition>, generatedAt: string): Promise<{
        artifacts: Ns4WorkflowArtifactV2[];
        index: Ns4WorkflowIndexArtifactV3;
    }>;
    export function buildNs4RealizedJourneyArtifact(source: Ns4JourneyArtifact, useCases: Ns4UseCaseArtifactV3[], derived: Ns4DerivedContextGraph): Promise<Ns4JourneyArtifactV5Realized>;
    export function buildNs4RealizedJourneyIndex(source: Ns4JourneyIndex, journeys: Ns4JourneyArtifactV5Realized[]): Promise<Ns4JourneyIndex>;
    export function buildNs4RealizedAccessArtifact(source: Ns4AccessMatrixArtifact, useCases: Ns4UseCaseArtifactV3[]): Promise<Ns4AccessMatrixArtifactV3>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ForeignKeys" {
    /**
     * Where a foreign key POINTS.
     *
     * An input's `fieldRef` names the entity that OWNS the field (`BillingLaborAllocation.clientBillingSummaryId`),
     * never the entity the id refers to. Reading the target off that prefix is how the E8 picker check
     * ended up comparing an entity with itself and passing in silence, while 48 command inputs across 15
     * workspaces asked the user to pick a record the screen could not show. The target only exists in the
     * relationship graph, so it is resolved here, once, for every consumer.
     */
    export interface Ns4FkRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
        realization?: {
            ownerEntity?: string;
            from?: {
                fieldIds?: string[];
            };
        };
    }
    export interface Ns4FkParent {
        parent: string;
        fieldId: string;
        required: boolean;
    }
    /** Owner entity -> the parents it references, with the field that holds each id. */
    export function buildNs4ParentIndex(relationships: readonly Ns4FkRelationship[]): Map<string, Ns4FkParent[]>;
    /** The entity a given field of a given entity points at, or null when the field is not a key. */
    export function ns4FkParentOf(index: Map<string, Ns4FkParent[]>, entityId: string, fieldId: string): Ns4FkParent | null;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/contracts" {
    import type { Ns4E2Review, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export { TEXT_PATHS_2026_08_14_ns4_e8_model_v1 } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export interface Ns4E8HubScore {
        entityRef: string;
        score: number;
        anchoredJourneyCount: number;
        requiredRelationshipCount: number;
        projectionCount: number;
        locateUseCaseCount: number;
    }
    /** A workspace context is exactly the derived journey context; E8 never invents another shape. */
    export type Ns4WorkspaceContext = Ns4DerivedContext;
    /**
     * The E1 prose a contentPage may quote into organisms. Detection itself is structural
     * (public external grant + singleton read) — this blob is copy, not the door.
     */
    export interface Ns4E8ModuleSignals {
        title: string;
        purpose: string;
        mainGoal?: string;
        expectedOutcomes?: Array<{
            outcomeId?: string;
            title: string;
            description: string;
        }>;
        inScope?: string[];
        outOfScope?: string[];
        boundaries?: string;
    }
    /** The approved contracts every E8 derivation reads. */
    export interface Ns4E8Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        useCases: Ns4UseCaseArtifactV3[];
        workflows: Ns4WorkflowArtifactV2[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        module?: Ns4E8ModuleSignals;
        presentation?: Ns4Presentation;
        accessBindings?: Ns4AccessBindingsArtifact;
        /** Disclosure views loaded by projectionRef; not listed on the E4 ontology index. */
        disclosureProjections?: Ns4OntologyEntity[];
    }
    /** E9/E10 compile against the E4 index plus disclosure views that E8 already pointed at. */
    export function ns4OntologyWithDisclosure(ontology: Ns4E4Review, projections?: readonly Ns4OntologyEntity[]): Ns4E4Review;
    export interface Ns4E8Edge {
        from: string;
        to: string;
        carries: string[];
        preferredFromJourneyRef?: string;
    }
    export function deriveE8HubScore(sources: Ns4E8Sources, derived?: import("/_102035_/l2/agentNewSolution/helpers/ns4Context.js").Ns4DerivedContextGraph): Ns4E8HubScore[];
    export function isPlatformOwnedEntity(entity: Ns4E4Review['entities'][number]): boolean;
    /**
     * Compile-only compatibility for workspaces written by the previous E8 model (runs 38-44). They are
     * never read or migrated — the union exists so already-generated L4 folders keep type-checking.
     */
    export interface Ns4WorkspaceArtifact {
        schemaVersion: string;
        moduleName: string;
        workspaceId: string;
        kind: string;
        title: string;
        description: string;
        anchorEntity?: string;
        profileRefs: string[];
        pageContext: Array<Record<string, unknown>>;
        scenarios: Array<Record<string, unknown>>;
        viewCall: {
            uses: Array<Record<string, unknown>>;
        };
        commands: string[];
        invalidations: Array<{
            useCaseId: string;
            sliceIds: string[];
        }>;
        skeletonHash: string;
        workspaceHash: string;
    }
    export interface Ns4WorkspaceIndex {
        schemaVersion: string;
        moduleName: string;
        userLanguage: string;
        workspaces: Array<Record<string, unknown>>;
        hubs: Array<Record<string, unknown>>;
        menu: Record<string, unknown>;
        skeletonHash: string;
        systemDecisions: Array<Record<string, unknown>>;
        approvedBy: string;
        approvedAt: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e8/model" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export const NS4_E8_MODEL_VERSION: "2026-08-14-ns4-e8-model-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_e8_model_v1: string[];
    export type Ns4WorkspaceTier = 'recordCatalogue' | 'journey' | 'hub' | 'projection' | 'contentPage';
    /** Organisms of type `content` use these roles; they exist only on a `contentPage`. */
    export type Ns4E8ContentRole = 'hero' | 'richText' | 'imageSet' | 'ctaLink';
    /**
     * The only origins a page can render by, in the vocabulary the frontend actually reads from an
     * operation input: userInput is a form field, selectedEntity is a picker over a query on the page,
     * routeParam comes from the URL, and the rest is resolved at runtime and never rendered.
     */
    export type Ns4E8InputSource = 'userInput' | 'selectedEntity' | 'routeParam' | 'actorSession' | 'systemDefault';
    /**
     * The record-owner handle: a field that points at a `party: person` entity (its own identity, or a
     * foreign key to one) when every E3 grant that operates the record is `dataScope.mode: own` — or
     * when the session actor is that person (an `own`/`assigned`/`related` grant). Never a field name.
     */
    export function isNs4OwnerHandleInput(input: {
        fieldRef: Ns4E8FieldRef;
        inputId?: string;
    }, sources: Ns4E8Sources): boolean;
    export type Ns4E8AccessPatternKind = 'list' | 'getById' | 'create' | 'update' | 'delete' | 'transition' | 'commandInput';
    export interface Ns4E8FieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4E8Input {
        inputId: string;
        fieldRef: Ns4E8FieldRef;
        source: Ns4E8InputSource;
        required: boolean;
        description: string;
        /** The literal union of an enumerated field, carried from the approved ontology. */
        enumValues?: string[];
        /** Present when the input is not the borrowed fieldRef's type (`page`/`pageSize` are numbers). */
        type?: 'number' | 'boolean' | 'string';
    }
    /**
     * One operation of the module. A journey step compiles into the E7 use case it already owns; a
     * record catalogue synthesizes its five operations from the ontology (list, getById, create,
     * update, and delete or the mdm inactivate/reactivate pair), because E7 only compiles journeys
     * and a catalogue is not a journey. getById is emitted even when no page consumes it.
     */
    /**
     * Master-data semantics of one operation. Master data is referenced by other
     * records, so an mdm catalogue deactivates instead of deleting.
     *
     * It is ONE optional block on purpose. The backend generator reads this artifact
     * as JSON and its accessPattern vocabulary is a closed set, so the lifecycle pair
     * keeps `kind: 'update'` — a command that mutates one identified record, which the
     * consumer already understands — and the meaning travels here. A consumer that
     * ignores the block behaves exactly as before.
     */
    export interface Ns4E8MdmSemantics {
        /** The command replaces a hard delete: route it to the MDM record lifecycle. */
        lifecycle?: 'inactivate' | 'reactivate';
        /** Optional request flag on a list: absent means only active records. */
        activeFilterInput?: 'includeInactive';
        /**
         * Response member carrying the situation. Derived from the MDM record lifecycle,
         * so it is NOT an ontology field and deliberately has no field ref: the ontology
         * declares no `active` field and the model must not invent one.
         */
        situationOutput?: 'active';
    }
    export interface Ns4E8Operation {
        operationId: string;
        title: string;
        kind: 'query' | 'command';
        entityRef: string;
        entityRefs: string[];
        accessPattern: {
            kind: Ns4E8AccessPatternKind;
            pagination?: 'optional';
        };
        inputs: Ns4E8Input[];
        outputRefs: string[];
        useRules: string[];
        transitionRefs: string[];
        story: string[];
        /** Present when the operation is an approved E7 use case; absent when the catalogue derived it. */
        useCaseId?: string;
        /** E3 authority refs or synthesized `synth:<entity>:<profile>` ids. Never empty. */
        authorityRefs: string[];
        /** Present only on a catalogue operation of an entity whose storage.target is mdm. */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4E8BffCall {
        bffId: string;
        kind: 'query' | 'command';
        operationId: string;
        outputKind: 'object' | 'list' | 'paginated';
        entityRef: string;
        /**
         * Which LOCAL call feeds each input of this one. Operations are shared and calls are per workspace,
         * so "where the user picks this record from" is a property of the call, never of the operation.
         * Without it the screen knows an id must be chosen and not which query to choose it from.
         */
        inputSources?: Array<{
            inputId: string;
            bffId: string;
        }>;
    }
    export type Ns4E8OrganismRole = 'primarySurface' | 'detailPanel' | 'filterControl' | 'contextualAction' | Ns4E8ContentRole;
    export interface Ns4E8Organism {
        role: Ns4E8OrganismRole;
        /** Present only on a content organism (hero/richText/imageSet/ctaLink). Never on a data-bound surface. */
        type?: 'content';
        dataSource?: string;
        action?: string;
        /** A picker is a query rendered to choose the record another call consumes. summary is counts of that list, not a row. */
        usage?: 'picker' | 'summary';
        /** Query bffId whose optional list inputs (search/sort) this filterControl drives. */
        attachTo?: string;
    }
    export interface Ns4E8Section {
        sectionId: string;
        intent: string;
        organisms: Ns4E8Organism[];
    }
    export interface Ns4E8ModelWorkspace {
        workspaceId: string;
        tier: Ns4WorkspaceTier;
        title: string;
        purpose: string;
        /** Classic workspace kind: operation, workflow, landing or record. */
        kind: 'operation' | 'workflow' | 'landing' | 'record';
        entity: string;
        workflowId?: string;
        actors: string[];
        profileRefs: string[];
        featureRefs: string[];
        hostedStepRefs: string[];
        journeyRef?: string;
        categoryRef: string;
        bffCalls: Ns4E8BffCall[];
        sections: Ns4E8Section[];
        /** Only a hub carries the closed catalogue its composition call may order and name. */
        hubCatalogue?: Ns4E8HubCatalogue;
        /** Workspaces this one links to; the site map turns them into navigation edges. */
        navigation?: Ns4E8NavigationTarget[];
    }
    export interface Ns4E8HubCatalogueItem {
        itemId: string;
        kind: 'projectionTile' | 'relatedList' | 'action' | 'pending';
        label: string;
        entityRef: string;
        /** The workspace the item belongs to; never invented by the composition call. */
        targetRef: string;
        /**
         * For an item the hub READS: the operation behind it. Operations are shared across the module and
         * calls are per workspace, so a tile becomes a local call of the hub over the same operation — an
         * organism only ever consumes a call of its own workspace.
         */
        sourceOperationId?: string;
        sourceBffId?: string;
        /** The shape the source call declares; a list read as an object would project a single record. */
        sourceOutputKind?: 'object' | 'list' | 'paginated';
        score: number;
    }
    /**
     * A journey reached from the hub is NAVIGATION, not an embedded command: it leaves the sections and
     * travels to the site map, carrying the prominence and order the composition chose.
     */
    export interface Ns4E8NavigationTarget {
        targetWorkspaceId: string;
        label: string;
        prominence: 'primary' | 'contextual';
        order: number;
    }
    export interface Ns4E8HubCatalogue {
        anchorEntity: string;
        items: Ns4E8HubCatalogueItem[];
    }
    export interface Ns4E8HubComposition {
        workspaceId: string;
        title: string;
        /** Catalogue item ids, in display order. Never a new id. */
        tileOrder: string[];
        primaryActionIds: string[];
        labels: Array<{
            itemId: string;
            label: string;
        }>;
        menuGroups: Array<{
            groupId: string;
            label: string;
            itemIds: string[];
        }>;
    }
    export interface Ns4E8MenuEntry {
        workspaceId: string;
        label: string;
        featureRef: string;
        tier: Ns4WorkspaceTier;
        profileRefs: string[];
    }
    export interface Ns4E8Model {
        planId: 'e8-workspace-model';
        schemaVersion: typeof NS4_E8_MODEL_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        hubEntity: string;
        workspaces: Ns4E8ModelWorkspace[];
        operations: Ns4E8Operation[];
        /** The menu lists places only: catalogues, hubs, projections and content pages. A journey is never a menu item. */
        menu: Ns4E8MenuEntry[];
        landings: Ns4E8Landing[];
        systemDecisions: Ns4SystemDecision[];
        modelHash?: string;
    }
    /**
     * Why this profile lands on this workspace. Closed machine token — never prose, never
     * `landingIntent` (that stays E3 copy for the human and the CF).
     */
    export type Ns4E8LandingReason = 'exclusive' | 'firstJourney' | 'rank';
    export interface Ns4E8Landing {
        profileRef: string;
        workspaceId: string;
        reason: Ns4E8LandingReason;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e9/classic" {
    import { type Ns4AccessMatrixArtifact, type Ns4AccessMatrixArtifactV4 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4E8Input, Ns4E8MdmSemantics, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export const NS4_CLASSIC_WORKSPACE_VERSION: "2026-08-14-ns4-classic-workspace-v6";
    export const NS4_E9_OUTPUT_REF_UNKNOWN: "NS4_E9_OUTPUT_REF_UNKNOWN";
    /** Human-text JSON paths the importer may rewrite. Classic L4 has no schemaVersion on operations/siteMap. */
    export const TEXT_PATHS_2026_08_14_ns4_classic_workspace_v6: string[];
    export const TEXT_PATHS_CLASSIC_WORKSPACE: string[];
    export const TEXT_PATHS_CLASSIC_OPERATION: string[];
    export const TEXT_PATHS_CLASSIC_SITE_MAP: string[];
    export class Ns4E9OutputRefError extends Error {
        readonly code: "NS4_E9_OUTPUT_REF_UNKNOWN";
        constructor(ref: string);
    }
    export interface Ns4ClassicField {
        name: string;
        from: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: Ns4ClassicField[];
        };
    }
    export interface Ns4ClassicBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: Array<{
            operationId: string;
        }>;
        input: Array<{
            name: string;
            from: string;
            required?: boolean;
            source: string;
            sourceRef?: string;
            type: string;
            enumValues?: string[];
        }>;
        output: {
            kind: 'object' | 'list' | 'paginated';
            fields: Ns4ClassicField[];
        };
        route: string;
    }
    export interface Ns4ClassicWorkspace {
        workspaceId: string;
        title: string;
        actors: string[];
        kind: string;
        entity: string;
        workflowId?: string;
        bffCalls: Ns4ClassicBffCall[];
        sections: Array<{
            sectionId: string;
            intent: string;
            organisms: Array<Record<string, string>>;
        }>;
        operationIds: string[];
        purpose: string;
        presentation: {
            categoryRef: string;
            confidence: number;
            classificationNote: string;
        };
        sliceHash: string;
    }
    export interface Ns4ClassicOperation {
        operationId: string;
        title: string;
        actors: string[];
        entity: string;
        kind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        story: {
            actor: string;
            goal: string;
            steps: string[];
            outcome: string;
        };
        accessPattern: {
            kind: string;
            description: string;
            entity: string;
            keyField: string;
            pagination: string;
            selection: string;
            output: string[];
        };
        outputShape: {
            kind: 'object' | 'list' | 'paginated';
            fields: Array<{
                name: string;
                type: string;
                required: boolean;
                fieldRef?: string;
                item?: {
                    fields: Array<{
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }>;
                };
            }>;
        };
        inputs: Array<{
            inputId: string;
            fieldRef: string;
            required: boolean;
            source: string;
            description: string;
            enumValues?: string[];
            type?: string;
        }>;
        pageId: string;
        commandName: string;
        bffName: string;
        /**
         * Carried verbatim from the model when the operation is a master-data catalogue
         * operation. It is what lets the backend generator route the lifecycle pair to
         * the MDM facade and keep the list active-only. Optional, so a consumer that
         * ignores it is unaffected.
         */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4ClassicSiteMap {
        moduleName: string;
        note: string;
        workspaces: Array<{
            workspaceId: string;
            title: string;
            actors: string[];
            kind: string;
            entity: string;
            operationIds: string[];
            purpose: string;
        }>;
        landings: Array<{
            actorId: string;
            workspaceId: string;
            reason: string;
        }>;
        navigationEdges: Array<{
            from: string;
            to: string;
            operationId: string;
            description: string;
            prominence?: 'primary' | 'contextual';
            order?: number;
        }>;
        workspaceIds: string[];
    }
    /** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
    export function ns4ClassicFrom(operationId: string, member: string): string;
    export type Ns4ClassicUseCaseWrites = Array<{
        useCaseId: string;
        writes?: Array<{
            entityId: string;
        }>;
    }>;
    export function transposeNs4ClassicOperation(model: Ns4E8Model, operation: Ns4E8Operation, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Ns4ClassicOperation;
    export function transposeNs4ClassicWorkspace(model: Ns4E8Model, workspace: Ns4E8ModelWorkspace, operations: Map<string, Ns4E8Operation>, ontology: Ns4E4Review, sliceHash: string): Ns4ClassicWorkspace;
    export function fieldTypeOf(ontology: Ns4E4Review, entityId: string, fieldId: string): Ns4OntologyField['type'];
    type ClassicOutputField = {
        name: string;
        type: string;
        required: boolean;
        fieldRef: string;
    };
    /**
     * The wire shape is what E8 declared in outputRefs. A catalogue command whose refs are only the
     * identity still projects the entity fields it always did, so modules without a joined projection
     * keep today's outputShape. An unknown ref is a blocking E9 finding, never a silent `unknown`.
     */
    export function resolveClassicOutputFields(operation: Ns4E8Operation, ontology: Ns4E4Review): ClassicOutputField[];
    /** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
    export function buildNs4ClassicContractSource(args: {
        moduleName: string;
        workspaceId: string;
        call: Ns4ClassicBffCall;
        fileRef: string;
        sourceRef: string;
    }): string;
    export function buildNs4ClassicSiteMap(model: Ns4E8Model, classic: Ns4ClassicWorkspace[]): Ns4ClassicSiteMap;
    /** Declared collection name on the wire — never the generic `items`. */
    export function collectionFieldName(entityId: string): string;
    export interface Ns4ClassicL4 {
        workspaces: Ns4ClassicWorkspace[];
        operations: Ns4ClassicOperation[];
        contracts: Array<{
            workspaceId: string;
            bffId: string;
            route: string;
            source: string;
        }>;
        siteMap: Ns4ClassicSiteMap;
    }
    export function buildNs4NavigationRealizedAccess(source: Ns4AccessMatrixArtifact, model: Ns4E8Model, classic: Ns4ClassicL4): Promise<Ns4AccessMatrixArtifactV4>;
    /** The whole transposition: what E9 writes to L4 from an approved E8 model. */
    export function compileNs4ClassicL4(model: Ns4E8Model, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Promise<Ns4ClassicL4>;
    export type Ns4ClassicInput = Ns4E8Input;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/contracts" {
    import { type Ns4JourneyIndex, type Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4UseCaseIndexArtifactV3, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4ClassicL4 } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_E10_VALIDATION_REPORT_VERSION: "2026-08-15-ns4-e10-validation-report-v2";
    export const NS4_L5_TODO_FRONTEND_VERSION: "2026-08-13-ns4-todo-frontend-v1";
    export const NS4_L5_TODO_BACKEND_VERSION: "2026-08-13-ns4-todo-backend-v1";
    export const NS4_L5_PROCESS_VERSION: "2026-08-13-ns4-process-v1";
    export const NS4_E10_MENU_LIMIT: 7;
    export type Ns4E10RepairStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler';
    /** E10 validates the approved E8 model against the classic L4 that E9 actually wrote to disk. */
    export interface Ns4E10Sources {
        moduleName: string;
        userLanguage: string;
        presentation?: Ns4Presentation;
        journeys: Ns4E2Review;
        journeyIndex: Ns4JourneyIndex;
        ontology: Ns4E4Review;
        ontologyIndex: Ns4OntologyIndexArtifact;
        rules: Ns4RulesArtifact;
        access: Ns4AccessMatrixArtifact;
        accessBindings?: Ns4AccessBindingsArtifact;
        disclosureProjections?: Ns4OntologyEntity[];
        useCases: Ns4UseCaseArtifactV3[];
        useCaseIndex: Ns4UseCaseIndexArtifactV3;
        workflows: Ns4WorkflowArtifactV2[];
        workflowIndex: Ns4WorkflowIndexArtifactV2 | Ns4WorkflowIndexArtifactV3;
        model: Ns4E8Model;
        /** What E9 emitted, read back from L4: the staleness check compares it to a fresh compilation. */
        saved: Ns4ClassicL4;
    }
    export interface Ns4E10Issue {
        code: string;
        path: string;
        message: string;
        repairStep?: Ns4E10RepairStep;
    }
    export interface Ns4E10CheckSummary {
        checkId: 'A1-resolution' | 'A2-journeys' | 'A3-decisions' | 'A4-disclosure' | 'A5-fsm' | 'A6-staleness' | 'A7-warnings' | 'A8-dormant-commands' | 'A9-authority';
        status: 'passed' | 'failed' | 'reported';
        errorCount: number;
        warningCount: number;
        registrarCount: number;
    }
    export interface Ns4L5NavigationItem {
        id: string;
        label: string;
        href: string;
        description: string;
        actors: string[];
        workspaceId: string;
        scenarioId: string;
        sectionId: string;
        hub?: string;
    }
    export interface Ns4L5HeaderLink {
        id: string;
        label: string;
        href: string;
        actors: string[];
        manageable: true;
        hub?: string;
    }
    export interface Ns4L5ModuleNavigation {
        moduleId: string;
        basePath: string;
        userLanguage: string;
        navigation: Ns4L5NavigationItem[];
        headerLinks: Ns4L5HeaderLink[];
    }
    export interface Ns4E10ValidationReport {
        schemaVersion: typeof NS4_E10_VALIDATION_REPORT_VERSION;
        moduleName: string;
        userLanguage: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns4E10CheckSummary[];
        errors: Ns4E10Issue[];
        warnings: Ns4E10Issue[];
        registrars: Ns4E10Issue[];
        policyDecisions: Ns4PolicyDecisionSelection[];
        systemDecisions: Ns4SystemDecision[];
        repairStep?: Ns4E10RepairStep;
        /**
         * The failure is a defect of the pipeline itself, not of the product: no step can repair it, so
         * nothing is marked stale and the module waits for a fixed pipeline instead of re-running whole.
         */
        pipelineDefect?: true;
        sourceHashes: {
            journeys: Array<{
                journeyId: string;
                businessHash: string;
            }>;
            accessHash: string;
            ontologyHash: string;
            rulesHash: string;
        };
        counts: {
            journeys: number;
            workspaces: number;
            operations: number;
            contracts: number;
            decisions: number;
        };
        menuPreview: Ns4L5ModuleNavigation;
        reportHash: string;
    }
    /**
     * e10 always EMITS 'toCreate', but the todo file is the ledger the downstream agents own: changeBackend
     * and changeFrontend flip each owner to 'inProgress' and 'done' in place, keeping the `satisfies` the
     * generator wrote. Pinning the literal made the artifact stop type-checking as soon as work progressed —
     * 264 TS2322 in one module's todoFrontend. The type describes the file, so it carries the whole lifecycle.
     */
    export type Ns4L5OwnerStatus = 'toCreate' | 'inProgress' | 'done';
    export interface Ns4L5FrontendOwner {
        ownerType: 'workspace' | 'contract';
        ownerId: string;
        workspaceId: string;
        statusFrontend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5BackendOwner {
        ownerType: 'useCase';
        ownerId: string;
        statusBackend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5TodoFrontendArtifact {
        schemaVersion: typeof NS4_L5_TODO_FRONTEND_VERSION;
        layer: 'frontend';
        moduleName: string;
        owners: Ns4L5FrontendOwner[];
    }
    export interface Ns4L5TodoBackendArtifact {
        schemaVersion: typeof NS4_L5_TODO_BACKEND_VERSION;
        layer: 'backend';
        moduleName: string;
        owners: Ns4L5BackendOwner[];
    }
    export interface Ns4L5ProcessArtifact {
        schemaVersion: typeof NS4_L5_PROCESS_VERSION;
        moduleName: string;
        sourceHashes: Ns4E10ValidationReport['sourceHashes'];
        counts: Ns4E10ValidationReport['counts'];
        validation: {
            status: 'passed';
            reportPath: string;
            reportHash: string;
            warningCount: number;
            registrarCount: number;
        };
        next: {
            frontend: 'todoFrontend';
            backend: 'todoBackend';
        };
        processHash: string;
    }
    export interface Ns4E10Delivery {
        config: Record<string, unknown>;
        moduleNavigation: Ns4L5ModuleNavigation;
        todoFrontend: Ns4L5TodoFrontendArtifact;
        todoBackend: Ns4L5TodoBackendArtifact;
        process: Ns4L5ProcessArtifact;
    }
    /**
     * The L5 menu preview. The frontend rebuilds navigation as E8 `model.menu` ∩ materialized pages
     * (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this mirrors that
     * derivation so the report shows the menu the module will actually have.
     */
    export function compileNs4L5ModuleNavigation(sources: Ns4E10Sources): Ns4L5ModuleNavigation;
    export function compileNs4E10Delivery(sources: Ns4E10Sources, report: Ns4E10ValidationReport, existingConfig: unknown, projectId: number): Promise<Ns4E10Delivery>;
    export function mergeNs4L5Config(existing: unknown, projectId: number, moduleNavigation: Ns4L5ModuleNavigation): Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/steps/e1/contracts" {
    import { Ns4ApprovedBy, Ns4ModuleArtifact, Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4ReviewPolicy = 'guided' | 'smart' | 'automatic';
    export type Ns4SolutionStrategy = 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
    export type Ns4DatabaseChangePolicy = 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
    export type Ns4ActorKind = 'internal' | 'external' | 'system';
    export type Ns4ActorOrigin = 'named' | 'inferred';
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_06_ns4_module_v4: string[];
    /** E1 business actor. `origin` is `named` only when the request itself names the profile. */
    export interface Ns4BusinessActor {
        actorId: string;
        title: string;
        kind: Ns4ActorKind;
        origin: Ns4ActorOrigin;
        expectedOutcome: string;
    }
    export interface Ns4E1Review {
        planId: 'e1-review';
        reviewRound: number;
        userLanguage: string;
        reviewPolicy: {
            mode: Ns4ReviewPolicy;
        };
        module: {
            moduleName: string;
            title: string;
            purpose: string;
        };
        strategy: {
            mode: Ns4SolutionStrategy;
            rationale: string;
            databaseChangePolicy: Ns4DatabaseChangePolicy;
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Ns4BusinessActor[];
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        changeSummary: string[];
        /**
         * Product languages the normalizer discarded for lacking user provenance (run02 102047: the LLM
         * invented en/es for a pt-BR-only request). Trace-only: never copied into the l4 artifact.
         */
        i18nWarnings?: string[];
    }
    export interface Ns4E1ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E1Review;
    }
    export interface Ns4E1ReviewIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1ReviewGate {
        ok: boolean;
        issues: Ns4E1ReviewIssue[];
    }
    export function normalizeNs4E1Review(value: unknown, fallback?: {
        userLanguage?: string;
        moduleName?: string;
        productLanguages?: string;
        mainActors?: string;
        mainGoal?: string;
        boundaries?: string;
        sourcePrompt?: string;
        /**
         * Under `/fast` the clarification answer is the planner's own proposal, never a user citation.
         * When true, language provenance comes only from `sourcePrompt` (and `userLanguage`).
         */
        answerIsProposal?: boolean;
    }): Ns4E1Review;
    export function policyFor(mode: Ns4SolutionStrategy): Ns4DatabaseChangePolicy;
    export function validateNs4E1Review(review: Ns4E1Review): Ns4E1ReviewGate;
    export function buildNs4ModuleArtifactFromReview(review: Ns4E1Review, sourcePrompt: string, approvedBy: Ns4ApprovedBy, presentation: Ns4Presentation, now?: string): Ns4ModuleArtifact;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4TextPaths" {
    import { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export const TEXT_PATHS_VERSION: "2026-09-09-n14";
    export const TEXT_PATHS_BY_SCHEMA: Record<string, readonly string[]>;
    export function textPathsForArtifact(relativePath: string, artifact: unknown): readonly string[];
    export function schemaVersionOf(value: unknown): string;
    export interface StringHit {
        path: string;
        value: string;
    }
    export function walkStrings(value: unknown, prefix?: string): StringHit[];
    export function pathMatches(path: string, pattern: string): boolean;
    export function isCoveredPath(path: string, patterns: readonly string[]): boolean;
    export function extractI18n(artifact: unknown, patterns: readonly string[]): Record<string, string>;
    export function injectI18n<T>(artifact: T, i18n: Record<string, string>): T;
    export function uncoveredNonAscii(artifact: unknown, patterns: readonly string[]): StringHit[];
    export { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE };
}
declare module "_102035_/l2/agentNewSolution/types" {
    import type { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4JourneyArtifact, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4CompositionArtifact } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import type { Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    import type { Ns4Level1EntityArtifact, Ns4Level1IndexArtifact, Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export type { Ns4ActorKind, Ns4ActorOrigin, Ns4BusinessActor, } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    export type { Ns4ApprovedBy, Ns4CompletedStepId, Ns4E1Status, Ns4E2Status, Ns4E3Status, Ns4E4Status, Ns4E4BStatus, Ns4E5Status, Ns4E6Status, Ns4E7Status, Ns4E8Status, Ns4E9Status, Ns4E10Status, Ns4ModuleArtifact, Ns4NextStep, Ns4PipelineState, Ns4Presentation, } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type { Ns4E2Feature, Ns4E2Review, Ns4E2ReviewEvent, Ns4FeaturePriority, Ns4JourneyArtifact, Ns4JourneyBusiness, Ns4JourneyEntryMode, Ns4JourneyIndex, Ns4JourneyProposal, Ns4JourneyStep, Ns4JourneyStepKind, Ns4LegacyJourneyArtifact, Ns4LegacyJourneyBusiness, Ns4LegacyJourneyContext, Ns4PolicyDecision, Ns4PolicyDecisionSelection, } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export type { Ns4AccessAuthority, Ns4AccessMatrixArtifactV4, Ns4AccessOperationAuthorityRef, Ns4AccessGrant, Ns4AccessMatrixArtifact, Ns4AccessProfile, Ns4AccessProfileKind, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review, Ns4E3ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export type { Ns4ConstraintSource, Ns4DerivationAggregate, Ns4DerivationOp, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBinding, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4ReviewEvent, Ns4EntityDerivation, Ns4EntityKind, Ns4EntityOwnership, Ns4FieldConstraint, Ns4LifecyclePredicate, Ns4LifecycleReachedBy, Ns4LifecycleState, Ns4OntologyEntity, Ns4OntologyEntityArtifact, Ns4OntologyEntityPlan, Ns4OntologyField, Ns4OntologyIndexArtifact, Ns4OntologyRelationship, Ns4RelationshipEndpointBinding, Ns4RelationshipPersistenceMode, Ns4RelationshipRealization, Ns4RelationshipRealizationKind, Ns4ResolvedOntologyRelationship, Ns4StorageScope, Ns4StorageTarget, } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export type { Ns4AccessAnchor, Ns4AccessAnchorHop, Ns4AccessBinding, Ns4AccessBindingsArtifact, Ns4SynthesizedAuthority, } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    export type { Ns4E5Review, Ns4E5ReviewEvent, Ns4RuleDefinition, Ns4RulesArtifact, } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export type { Ns4AdditionalCapability, Ns4AdditionalCapabilityDecision, Ns4AdditionalCapabilityKind, Ns4CompositionArtifact, Ns4E6Review, Ns4E6ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export type { Ns4E7PlanDraft, Ns4E7PlanUseCase, Ns4E7SourceHashes, Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseDraft, Ns4UseCaseEntityAccess, Ns4UseCaseError, Ns4UseCaseFieldRef, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4UseCaseInput, Ns4UseCaseKind, Ns4UseCaseOutput, Ns4UseCaseTransition, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4WorkflowTransition, } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    export type { Ns4E8Edge, Ns4E8HubScore, Ns4E8ModuleSignals, Ns4E8Sources, Ns4WorkspaceArtifact, Ns4WorkspaceContext, Ns4WorkspaceIndex, } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export type { Ns4E8BffCall, Ns4E8HubCatalogue, Ns4E8HubCatalogueItem, Ns4E8HubComposition, Ns4E8Input, Ns4E8InputSource, Ns4E8MenuEntry, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation, Ns4E8Organism, Ns4E8Section, Ns4WorkspaceTier, } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export type { Ns4ClassicBffCall, Ns4ClassicL4, Ns4ClassicOperation, Ns4ClassicSiteMap, Ns4ClassicWorkspace, } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export type { Ns4E10CheckSummary, Ns4E10Delivery, Ns4E10Issue, Ns4E10RepairStep, Ns4E10ValidationReport, Ns4L5BackendOwner, Ns4L5FrontendOwner, Ns4L5HeaderLink, Ns4L5ModuleNavigation, Ns4L5NavigationItem, Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact, } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export type { Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, Ns4SolutionRegistryActor, Ns4SolutionRegistryArtifact, Ns4SolutionRegistryGeneralField, Ns4SolutionRegistryModule, Ns4SolutionRegistryRole, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, NS4_SOLUTION_REGISTRY_SCHEMA_VERSION, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { TEXT_PATHS_BY_SCHEMA, TEXT_PATHS_VERSION, textPathsForArtifact, } from "_102035_/l2/agentNewSolution/helpers/ns4TextPaths";
    export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES: readonly ["Ns4ModuleArtifact", "Ns4JourneyArtifact", "Ns4JourneyIndex", "Ns4AccessMatrixArtifact", "Ns4AccessBindingsArtifact", "Ns4OntologyEntityArtifact", "Ns4OntologyIndexArtifact", "Ns4RulesArtifact", "Ns4CompositionArtifact", "Ns4UseCaseArtifact", "Ns4UseCaseArtifactV3", "Ns4UseCaseIndexArtifact", "Ns4UseCaseIndexArtifactV3", "Ns4WorkflowArtifact", "Ns4WorkflowArtifactV2", "Ns4WorkflowIndexArtifact", "Ns4WorkflowIndexArtifactV2", "Ns4WorkflowIndexArtifactV3", "Ns4L5TodoFrontendArtifact", "Ns4L5TodoBackendArtifact", "Ns4L5ProcessArtifact", "Ns4Level1EntityArtifact", "Ns4Level1IndexArtifact", "Ns4SolutionRegistryArtifact"];
    export type Ns4PermanentArtifactTypeName = typeof NS4_PERMANENT_ARTIFACT_TYPE_NAMES[number];
    export interface Ns4PermanentArtifactByType {
        Ns4ModuleArtifact: Ns4ModuleArtifact;
        Ns4JourneyArtifact: Ns4JourneyArtifact;
        Ns4JourneyIndex: Ns4JourneyIndex;
        Ns4AccessMatrixArtifact: Ns4AccessMatrixArtifact;
        Ns4AccessBindingsArtifact: Ns4AccessBindingsArtifact;
        Ns4OntologyEntityArtifact: Ns4OntologyEntityArtifact;
        Ns4OntologyIndexArtifact: Ns4OntologyIndexArtifact;
        Ns4RulesArtifact: Ns4RulesArtifact;
        Ns4CompositionArtifact: Ns4CompositionArtifact;
        Ns4UseCaseArtifact: Ns4UseCaseArtifact;
        Ns4UseCaseArtifactV3: Ns4UseCaseArtifactV3;
        Ns4UseCaseIndexArtifact: Ns4UseCaseIndexArtifact;
        Ns4UseCaseIndexArtifactV3: Ns4UseCaseIndexArtifactV3;
        Ns4WorkflowArtifact: Ns4WorkflowArtifact;
        Ns4WorkflowArtifactV2: Ns4WorkflowArtifactV2;
        Ns4WorkflowIndexArtifact: Ns4WorkflowIndexArtifact;
        Ns4WorkflowIndexArtifactV2: Ns4WorkflowIndexArtifactV2;
        Ns4WorkflowIndexArtifactV3: Ns4WorkflowIndexArtifactV3;
        Ns4L5TodoFrontendArtifact: Ns4L5TodoFrontendArtifact;
        Ns4L5TodoBackendArtifact: Ns4L5TodoBackendArtifact;
        Ns4L5ProcessArtifact: Ns4L5ProcessArtifact;
        Ns4Level1EntityArtifact: Ns4Level1EntityArtifact;
        Ns4Level1IndexArtifact: Ns4Level1IndexArtifact;
        Ns4SolutionRegistryArtifact: Ns4SolutionRegistryArtifact;
    }
}
declare module "_102020_/l2/agentNewSolution/types" {
    export * from "_102035_/l2/agentNewSolution/types";
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l5/todoBackend.defs" {
    export const controleChamadosTodoBackend: {
        readonly schemaVersion: "2026-08-13-ns4-todo-backend-v1";
        readonly layer: "backend";
        readonly moduleName: "controleChamados";
        readonly owners: [{
            readonly ownerType: "useCase";
            readonly ownerId: "closeChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "createAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "createChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "createComentario";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "deleteChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "deleteComentario";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "getAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "getChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "getComentario";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "inactivateAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "listAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "listChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "listComentario";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "locateChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "reactivateAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "registerComentario";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "updateAtendente";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "updateChamado";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "updateComentario";
            readonly statusBackend: "done";
        }];
    };
    export type ControleChamadosTodoBackendType = typeof controleChamadosTodoBackend;
    export default controleChamadosTodoBackend;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/fixtures/ontology/Mensalidade.defs" {
    export const mensalidadesAcademiaEntityMensalidade: {
        readonly schemaVersion: "2026-09-17-ns5-ontology-v3.1";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Mensalidade";
        readonly title: "Mensalidade";
        readonly description: "Cobrança mensal gerada para uma matrícula ativa, com valor, vencimento e situação de pagamento.";
        readonly displayField: "id";
        readonly relationships: {
            readonly matricula: {
                readonly relationshipId: "mensalidadeMatricula";
                readonly to: "Matricula";
                readonly via: "Mensalidade.matriculaId";
                readonly cardinality: "N:1";
                readonly title: "Matrícula da mensalidade";
                readonly description: "Cada mensalidade pertence à matrícula para a qual foi gerada.";
                readonly mode: "fk";
                readonly required: "Sempre, ao gerar a mensalidade.";
                readonly role: "cobrança da matrícula";
            };
            readonly pagamentos: {
                readonly relationshipId: "pagamentoMensalidade";
                readonly to: "Pagamento";
                readonly via: "Pagamento.mensalidadeId";
                readonly cardinality: "1:N";
                readonly title: "Pagamentos da mensalidade";
                readonly description: "Pagamentos registrados para quitar total ou parcialmente esta mensalidade.";
                readonly mode: "fk";
                readonly direction: "to";
                readonly required: "Quando houver pagamento registrado para esta mensalidade.";
                readonly role: "quitação";
            };
        };
        readonly capabilities: {
            readonly "read.byId": "Lê uma mensalidade pelo identificador da linha para a recepção ou a gerência conferir a cobrança selecionada.";
            readonly "locate.byColumn": "Lista mensalidades por matrícula, competência ou vencimento, com paginação, para a recepção e a gerência localizarem cobranças.";
            readonly count: "Conta mensalidades conforme os filtros de matrícula, competência ou vencimento para exibir totais nas consultas da gerência.";
            readonly listByForeignKey: "Lista as mensalidades vinculadas a uma matrícula pelo campo matriculaId para a recepção e a gerência consultarem o histórico de cobranças.";
            readonly create: "Cria a mensalidade de uma matrícula ativa para a competência mensal, com valor do plano e vencimento, durante a geração feita pela gerência.";
            readonly uniqueKey: "Impede uma segunda mensalidade para a mesma matrícula e competência pelo índice único, protegendo a geração mensal da gerência.";
            readonly transaction: "Grava em uma única transação as mensalidades geradas para as matrículas ativas do mês pela gerência.";
        };
        readonly rules: readonly ["mensalidadeUnicaPorMatriculaECompetencia", "mensalidadeGeradaParaMatriculaAtiva", "situacaoMensalidadeDerivada"];
        readonly kind: "entity";
        readonly class: "core";
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly table: "mensalidadesAcademia_mensalidade";
            readonly kind: "relational";
        };
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly title: "Id";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                };
                readonly matriculaId: {
                    readonly type: "record";
                    readonly required: true;
                    readonly indexed: true;
                    readonly of: "Address";
                    readonly to: readonly ["Matricula"];
                    readonly title: "Matrícula";
                    readonly description: "Matrícula ativa para a qual esta mensalidade foi gerada.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                };
                readonly competencia: {
                    readonly type: "date";
                    readonly required: true;
                    readonly indexed: true;
                    readonly of: "Address";
                    readonly title: "Competência";
                    readonly description: "Mês de referência da cobrança mensal.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                };
                readonly vencimento: {
                    readonly type: "date";
                    readonly required: true;
                    readonly indexed: true;
                    readonly of: "Address";
                    readonly title: "Vencimento";
                    readonly description: "Data em que a mensalidade deve ser paga, definida a partir do dia de vencimento do plano.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly of: "Address";
                    readonly title: "Dados da mensalidade";
                    readonly description: "Informações próprias da cobrança mensal que não são usadas como filtro ou ordenação.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                    readonly fields: {
                        readonly valorCobranca: {
                            readonly type: "money";
                            readonly required: true;
                            readonly of: "Address";
                            readonly title: "Valor da cobrança";
                            readonly description: "Valor da mensalidade gerada conforme o plano vigente na matrícula.";
                            readonly maxLength: 0;
                            readonly min: 0;
                            readonly max: 0;
                        };
                        readonly totalPago: {
                            readonly type: "money";
                            readonly derived: true;
                            readonly title: "Total pago";
                            readonly description: "Soma dos pagamentos registrados para esta mensalidade.";
                        };
                        readonly saldoDevedor: {
                            readonly type: "money";
                            readonly derived: true;
                            readonly title: "Saldo devedor";
                            readonly description: "Valor da cobrança menos a soma dos pagamentos registrados para esta mensalidade, nunca inferior a zero.";
                        };
                        readonly situacao: {
                            readonly type: "string";
                            readonly derived: true;
                            readonly title: "Situação";
                            readonly description: "Paga quando os pagamentos registrados alcançam o valor da cobrança; vencida quando ainda há saldo devedor e o vencimento é anterior a hoje; em aberto nos demais casos.";
                        };
                    };
                };
            };
        };
        readonly uniqueKeys: readonly [readonly ["matriculaId", "competencia"]];
    };
    export type MensalidadesAcademiaEntityMensalidadeType = typeof mensalidadesAcademiaEntityMensalidade;
    export default mensalidadesAcademiaEntityMensalidade;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/fixtures/ontology/Pagamento.defs" {
    export const mensalidadesAcademiaEntityPagamento: {
        readonly schemaVersion: "2026-09-17-ns5-ontology-v3.1";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Pagamento";
        readonly title: "Pagamento";
        readonly description: "Registro de um pagamento recebido para regularizar uma mensalidade.";
        readonly displayField: "id";
        readonly relationships: {
            readonly mensalidade: {
                readonly relationshipId: "pagamentoMensalidade";
                readonly to: "Mensalidade";
                readonly via: "Pagamento.mensalidadeId";
                readonly cardinality: "N:1";
                readonly title: "Mensalidade paga";
                readonly description: "Cada pagamento registrado pertence à mensalidade que está sendo regularizada.";
                readonly mode: "fk";
                readonly required: "Sempre";
            };
        };
        readonly capabilities: {
            readonly "read.byId": "Lê um pagamento pelo identificador da linha para a recepção conferir o recebimento registrado.";
            readonly "locate.byColumn": "Lista pagamentos por mensalidade ou por data de pagamento, com ordenação e paginação, para a recepção consultar recebimentos.";
            readonly count: "Conta os pagamentos que correspondem aos filtros de mensalidade ou data para a conferência da recepção.";
            readonly listByForeignKey: "Lista os pagamentos vinculados a uma mensalidade pelo campo mensalidadeId para exibir os recebimentos que a regularizam.";
            readonly create: "Registra um pagamento com data, valor e forma de pagamento para a recepção regularizar uma mensalidade.";
            readonly transaction: "Grava o pagamento e atualiza a situação da mensalidade e a regularidade do aluno de forma atômica durante o registro pela recepção.";
        };
        readonly rules: readonly ["paymentAmountPositive", "paymentUpdatesMonthlyFee", "paymentRegularizesStudentWhenApplicable"];
        readonly kind: "entity";
        readonly class: "event";
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly table: "mensalidadesAcademia_pagamento";
            readonly kind: "relational";
        };
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly title: "Id";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                };
                readonly mensalidadeId: {
                    readonly type: "record";
                    readonly required: true;
                    readonly indexed: true;
                    readonly of: "ContactSummary";
                    readonly to: readonly ["Mensalidade"];
                    readonly title: "Mensalidade";
                    readonly description: "Mensalidade que está sendo regularizada por este pagamento.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                };
                readonly dataPagamento: {
                    readonly type: "date";
                    readonly required: true;
                    readonly indexed: true;
                    readonly of: "ContactSummary";
                    readonly title: "Data do pagamento";
                    readonly description: "Data em que a academia recebeu o pagamento da mensalidade.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly of: "ContactSummary";
                    readonly title: "Dados do pagamento";
                    readonly description: "Informações registradas pela recepção sobre o valor e a forma de recebimento.";
                    readonly maxLength: 0;
                    readonly min: 0;
                    readonly max: 0;
                    readonly fields: {
                        readonly valor: {
                            readonly type: "money";
                            readonly required: true;
                            readonly of: "ContactSummary";
                            readonly title: "Valor pago";
                            readonly description: "Valor efetivamente recebido para a mensalidade.";
                            readonly maxLength: 0;
                            readonly min: 0.01;
                            readonly max: 0;
                        };
                        readonly formaPagamento: {
                            readonly type: "enum";
                            readonly required: true;
                            readonly of: "ContactSummary";
                            readonly values: readonly [{
                                readonly value: "cash";
                                readonly title: "Dinheiro";
                                readonly description: "Pagamento recebido em dinheiro.";
                            }, {
                                readonly value: "pix";
                                readonly title: "Pix";
                                readonly description: "Pagamento recebido por Pix.";
                            }, {
                                readonly value: "debitCard";
                                readonly title: "Cartão de débito";
                                readonly description: "Pagamento recebido por cartão de débito.";
                            }, {
                                readonly value: "creditCard";
                                readonly title: "Cartão de crédito";
                                readonly description: "Pagamento recebido por cartão de crédito.";
                            }, {
                                readonly value: "bankTransfer";
                                readonly title: "Transferência bancária";
                                readonly description: "Pagamento recebido por transferência bancária.";
                            }];
                            readonly title: "Forma de pagamento";
                            readonly description: "Meio pelo qual o aluno realizou o pagamento.";
                            readonly maxLength: 0;
                            readonly min: 0;
                            readonly max: 0;
                        };
                    };
                };
            };
        };
    };
    export type MensalidadesAcademiaEntityPagamentoType = typeof mensalidadesAcademiaEntityPagamento;
    export default mensalidadesAcademiaEntityPagamento;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/fixtures/ontology/index.defs" {
    export const mensalidadesAcademiaOntologyIndex: {
        schemaVersion: string;
        moduleName: string;
        entities: {
            entityId: string;
            kind: string;
            class: string;
        }[];
    };
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
