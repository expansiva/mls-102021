declare module "_102021_agentEndpoint.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_buildServer.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_buildServer" {
    export const DISTFOLDER = "wwwroot";
    export function build(info: InfoBuild): Promise<string>;
    export function loadEsbuild(): Promise<void>;
    export interface InfoBuild {
        project: number;
        shortName: string;
        folder: string;
    }
}
declare module "_102021_designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102021_liveServer.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_start" {
    export let servers: Record<string, IServer>;
    export let listItens: IListItem[];
    export function start(project: number, startServers?: 'all' | 'none' | string): Promise<void>;
    export function setHtml(server: IServer): Promise<void>;
    export function onServer(server: IServer): void;
    export function restartServer(server: IServer): void;
    export function offServer(server: IServer): void;
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
    export interface IServer {
        icon: string | undefined;
        name: string;
        server: string;
        iframe: HTMLIFrameElement;
        status: 'on' | 'off' | 'restarting';
    }
}
declare module "_102021_liveServer" {
    import { CollabLitElement } from './_100554_collabLitElement';
    import { IServer } from "_102021_start";
    export class ServicePreviewL1ListServer extends CollabLitElement {
        listItens: IServer[];
        viewServer: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IServer, idx: number): any;
        private init;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
    }
}
declare module "_102021_project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102021_project" {
    export const modules: {
        pathServer: string;
        name: string;
        path: string;
        auth: string;
        icon: string;
    }[];
}
declare module "_102021_start.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "example/_102021_module.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "example/_102021_module" {
    export const moduleConfig: {
        theme: string;
        initialPage: string;
        menu: any[];
    };
}
