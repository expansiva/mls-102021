declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Core" {
    export const D1_FLOW_ID: "agentDefsL1";
    export const D1_FLOW_VERSION: "2026-09-21-d1-flow-v1";
    export const D1_PIPELINE_SCHEMA: "2026-09-21-d1-pipeline-v1";
    export const D1_AGENT_NAME: "agentDefsL1";
    export const D1_FLOW_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export type D1StepId = typeof D1_FLOW_STEP_IDS[number];
    /** Steps that have a hook in this delivery. The flow lists the rest as not implemented. */
    export const D1_IMPLEMENTED_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70", "finalize80"];
    export const D1_STEP_TITLES: Record<D1StepId, string>;
    /** Dependencies are done-anchors. A draft path must never appear here. */
    export const D1_STEP_DEPENDS_ON: Record<D1StepId, readonly string[]>;
    export const D1_REPAIR_PER_UNIT = 1;
    export const D1_REPAIR_GLOBAL_MAX = 8;
    export const D1_FINALIZE_REPAIR = false;
    export const D1_MAX_PARALLEL = 5;
    export const D1_INTERACTION_CLEANER: "input_output";
    export const D1_CHILDREN_MAY_ADD_STEPS = false;
    export const D1_CHILDREN_MAY_CREATE_TASK = false;
    export const D1_NEVER_DISPATCH: readonly ["agentCbMaterialize", "agentChangeBackend", "agentMaterializeL2"];
    const COMMANDS: readonly ["run", "resume", "help"];
    export type D1Command = typeof COMMANDS[number];
    export const MSG_PATH = "Path must not contain '..'.";
    export const MSG_CANDIDATE_DOTDOT = "Candidate path must not contain '..'.";
    export const MSG_CANDIDATE = "Candidate runs are refused. Nothing was changed.";
    export const MSG_REBUILD = "Rebuild all is refused. Nothing was deleted.";
    export const MSG_ONE_COMMAND = "Pass one command: /run, /resume or /help.";
    export const MSG_USAGE = "Pass @@agentDefsL1 <lowerCamel> /run, /resume or /help.";
    export const MSG_MODULE = "Module name must be lowerCamel (example: stockControl).";
    export const MSG_PROJECT = "Project identity is missing.";
    export const MSG_PROJECT_MISMATCH = "Project identity does not match this task.";
    export interface D1FileInfo {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export type D1PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    export type D1StepStatus = 'running' | 'approved' | 'failed';
    export interface D1StepState {
        status: D1StepStatus;
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
    }
    export interface D1PipelineState {
        schemaVersion: typeof D1_PIPELINE_SCHEMA;
        flowId: typeof D1_FLOW_ID;
        flowVersion: typeof D1_FLOW_VERSION;
        project: number;
        moduleName: string;
        status: D1PipelineStatus;
        awaitingStep?: D1StepId;
        command: 'run' | 'resume';
        steps: Partial<Record<D1StepId, D1StepState>>;
        updatedAt: string;
    }
    export interface D1ParsedInvocation {
        module: string;
        command: D1Command | '';
        refused: string;
    }
    export function isD1StepId(value: string): value is D1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    export function repairAllowed(unitAttempts: number, globalAttempts: number): boolean;
    /** A successor is unlocked only by its done-anchors, never by a draft path. */
    export function successorUnlocked(dependsOn: readonly string[], approvedAnchors: ReadonlySet<string>): boolean;
    export function doneAnchorId(stepId: D1StepId): string;
    export function dynamicPlanId(stepId: D1StepId, kind: 'fanout' | 'worker' | 'repair' | 'barrier', token: string): string;
    /** A parallel child has no planning. Its prompt carries the planId. */
    export function planIdFromPrompt(prompt: string): string;
    /**
     * Maps a child planId back to its step. Done-anchors stay unmatched so they are
     * not dispatched as the step they close.
     */
    export function ownerStepId(planId: string): D1StepId | '';
    export function isDoneAnchor(planId: string): boolean;
    export function assertShortName(shortName: string): void;
    /** Project is part of the path so two modules with the same name do not share a file. */
    export function displayPath(file: D1FileInfo): string;
    /** `l1/<module>/pipeline/agentDefsL1/input.json` — the input20 receipt. */
    export function inputFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/drafts/<step>.json`. A draft does not approve the step. */
    export function draftFile(project: number, moduleName: string, step: D1StepId): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/report.json` — the finalize80 receipt. */
    export function reportFile(project: number, moduleName: string): D1FileInfo;
    /** `l1/<module>/pipeline/agentDefsL1/pipeline.json` in one project. */
    export function pipelineFile(project: number, moduleName: string): D1FileInfo;
    /**
     * Planner checkpoint, `l4/<module>/pool/l1/pipeline.json` since 27/09 (planning only writes
     * the pool). This agent never writes or removes it.
     */
    export function plannerPipelineFile(project: number, moduleName: string): D1FileInfo;
    export function ownedFolder(moduleName: string): string;
    export function requireProject(value: unknown): number | {
        refusal: string;
    };
    export function parseD1Invocation(value: string): D1ParsedInvocation;
    export function helpText(moduleName: string, project: number): string;
    export function notImplementedTrace(stepId: D1StepId): string;
    export function stoppedTrace(stepId: D1StepId): string;
    export function resumeMissing(moduleName: string, project: number): string;
    export function checkpointConflict(moduleName: string, project: number): string;
    export function checkpointNotIntact(moduleName: string, project: number): string;
    export function unknownPromptField(field: string): string;
    export function unknownPlanId(planId: string): string;
    export interface D1StepPrompt {
        planId: D1StepId;
        moduleName: string;
        project: number;
        command: 'run' | 'resume';
    }
    export type D1ParsedStepPrompt = {
        kind: 'step';
        prompt: D1StepPrompt;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseD1StepPrompt(prompt: string): D1ParsedStepPrompt;
    export function createEntryPipeline(project: number, moduleName: string, now: Date): D1PipelineState;
    export function isIntactCheckpoint(state: D1PipelineState, project: number, moduleName: string): boolean;
    /**
     * Records the first missing step. Does not move the marker forward, does not
     * rewrite an approved step, and does not treat a later callback as progress.
     */
    export function withAwaiting(pipeline: D1PipelineState, stepId: D1StepId, now: string): {
        pipeline: D1PipelineState;
        changed: boolean;
    };
    export function createD1AgentStep(stepId: D1StepId, moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep;
    export function buildD1PlannedSteps(moduleName: string, project: number, command: 'run' | 'resume'): mls.msg.AIAgentStep[];
    export function taskProject(context: mls.msg.ExecutionContext): number | null;
    export function taskModule(context: mls.msg.ExecutionContext): string;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Schema" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /** Keys locked to schemas/pipeline-v1.schema.json by the flow contract test. */
    export const PIPELINE_KEYS: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "awaitingStep", "command", "steps", "updatedAt"];
    export const PIPELINE_REQUIRED: readonly ["schemaVersion", "flowId", "flowVersion", "project", "moduleName", "status", "command", "steps", "updatedAt"];
    export const STEP_STATE_KEYS: readonly ["status", "updatedAt", "artifactPaths", "error"];
    export const PIPELINE_STATUS: readonly ["inProgress", "awaitingStep", "complete", "failed"];
    export const STEP_STATUS: readonly ["running", "approved", "failed"];
    /** Structural gate for the pipeline document. Extra keys are refused, not dropped. */
    export function pipelineIssues(value: unknown): string[];
    export function parsePipelineDocument(raw: string): D1PipelineState | null;
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     *
     * `clientProjectId` first: it is the workspace's client project, which is what the studio edits.
     * `projectId` is the owner of the SERVED MODULE, so entering through a platform module
     * (monitor/mdm/audit, owned by the master backend) pinned the studio to the master and the client's
     * services never appeared — measured on 102047.collabcodes.com, 23/09/2026.
     * `projectId` stays as the fallback for a server that does not send the new field yet;
     * mls.actualProject is the last resort when the payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Stor" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export function readText(file: D1FileInfo): Promise<string | null>;
    export function writeText(file: D1FileInfo, content: string): Promise<void>;
    export function readJson<T>(file: D1FileInfo): Promise<T | null>;
    /** Writes JSON and returns the exact bytes stored. */
    export function writeJson(file: D1FileInfo, value: unknown): Promise<string>;
    /**
     * Removes one file this agent owns. The file identity is the same object a
     * write would use. The planner pipeline and every other folder are refused.
     */
    export function removeOwned(file: D1FileInfo): Promise<void>;
    /**
     * Removes one own product def. A directory is not a file, a `.ts` output is
     * not a def, and this is not `/rebuild all`.
     */
    export function removeDefFile(file: D1FileInfo): Promise<void>;
    /**
     * Removes the accepted implement from `l4/<module>/pool/l1` once it is traced. Any other
     * folder, level or name is refused.
     */
    export function removePoolMessage(file: D1FileInfo): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type D1PipelineState, type D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type D1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type D1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface D1StepHooks {
        beforePromptStep?: D1StepBeforePrompt;
        afterPromptStep?: D1StepAfterPrompt;
    }
    /** Filled by the step module as a side effect. A missing entry is not implemented. */
    export const D1_STEP_HOOKS: Partial<Record<D1StepId, D1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string): D1StepHooks | undefined;
    /**
     * Persists awaitingStep when the marker actually moves. An approved entry10
     * is left untouched. A repeated call does not write.
     */
    export function markAwaitingStep(pipeline: D1PipelineState, stepId: D1StepId, now?: string): Promise<boolean>;
    export function d1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string, memory: Record<string, string>): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/gate" {
    import { type D1PipelineState } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export type EntryDecision = {
        kind: 'record';
        state: D1PipelineState;
    } | {
        kind: 'keep';
    } | {
        kind: 'refusal';
        refusal: string;
    };
    /**
     * Pure entry decision. `keep` writes nothing. A draft on disk is not an input
     * and cannot turn a later step into an approved one.
     */
    export function decideEntry(command: 'run' | 'resume', project: number, moduleName: string, raw: string | null, now: Date): EntryDecision;
}
declare module "_102035_/l2/solution/helpers/ns4ClassicDefs" {
    /**
     * The untyped defs shape of the classic L4 emission, and its reader — PURE, with no storage import.
     * It lives apart from ns4Fs.ts on purpose: ns4Fs pulls in libModel, whose top-level event listener
     * crashes the l2 test stub, and the write/read round trip of these files must stay testable.
     */
    export interface Ns4ClassicDefsFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    export function ns4ClassicDefsSource(fileInfo: Ns4ClassicDefsFile, exportName: string, value: unknown): string;
    /** Reads a defs file back to its data, exactly as the storage reader does. */
    export function parseNs4ClassicDefsSource<T>(source: string): T | null;
    export function extractNs4ClassicJsonObject(source: string): string;
    /** The single brace/string scanner shared by readers and byte-preserving rewriters. */
    export function scanNs4ClassicJsonObject(source: string): {
        start: number;
        end: number;
    } | null;
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Shape of the level-1 ontology as the solution agents read it. Until ns5_43 these types described files
     * emitted into l4/organization/ontology; that emitter and those files are gone. `level1Catalog.ts`
     * (mls-102035) now derives this shape from l4/ontology/mdm.defs.ts, so these are a READING form and no
     * longer a source.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformEvent {
        eventId: string;
        on: string;
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                services?: readonly string[];
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
        /** Platform events a module may receive with `inbound.from: 'organization'`. No handler in alpha. */
        events?: readonly MdmPlatformEvent[];
    }
}
declare module "_102035_/l2/solution/helpers/organizationTypes" {
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    /**
     * A papel of a module over a level-1 subtype. ns5_43 T4 names the three parts the way the v3 ontology
     * names them (`Ns5OntologyRoleV3`): `subtype` is the MDM subtype, `roleTag` is what `attachRole` writes
     * into `identification.tags`. Registries written before ns5_43 carry `mdmSubtype`/`role` instead; they
     * are read through `ns4RegistryRoleSubtype` / `ns4RegistryRoleTag` and rewritten on the next finalize80.
     */
    export interface Ns4SolutionRegistryRole {
        subtype: string;
        roleTag: string;
        namespace: string;
        /** Legacy spelling of `subtype`, written before ns5_43. Never written again. */
        mdmSubtype?: string;
        /** Legacy spelling of `roleTag`, written before ns5_43. Never written again. */
        role?: string;
    }
    export function ns4RegistryRoleSubtype(role: Ns4SolutionRegistryRole): string;
    export function ns4RegistryRoleTag(role: Ns4SolutionRegistryRole): string;
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    /** Entities this module owns. Siblings read this list instead of opening ontology files. */
    export interface Ns4SolutionRegistryEntity {
        entityId: string;
        /** v2 `kind`, or the v3 `role` / `entity`. */
        kind: string;
        mdmSubtype?: string;
        /** v3 table only: `core | event | supporting`, which v2 carried in `kind` (ns5_43 T4). */
        class?: string;
    }
    /** Outbound events this module publishes. `on` is `Entity.transitionId` or `Entity.create`. */
    export interface Ns4SolutionRegistryEvent {
        eventId: string;
        on: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        entities?: Ns4SolutionRegistryEntity[];
        events?: Ns4SolutionRegistryEvent[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102034_/l1/mdm/defs/ontologyTypes" {
    /**
     * The grammar of the platform ontology — the types `l4/ontology/mdm.defs.ts` is written against, and that
     * `l2/mdm/resolveMdmEntity.ts` and the module ontology of `mls-102035/l2/solution/types.ts` read.
     *
     * A record is `{ id, version, details }`, mirroring `mdm_documents`: `id` and `version` are columns and
     * `details` is the JSONB document, laid out as a map of branches — `identification` (the fields that are
     * also columns of the index table), `base` (common to every subtype), `<subtype>` (exactly one per
     * record), `general` (the organization) and `<moduleId>` (the module namespace). The base is declared
     * ONCE, instead of being repeated in each of the 13 subtypes.
     *
     * Defaults are omitted, not written: `required: false`, `nullable: false`, `title` equal to the id, and
     * the layer — which the branch already gives, since `identification` is a column and every other branch
     * lives in the document.
     *
     * `InferMdmRecord` derives the runtime type of a record from the ontology data, so `tsc` keeps code and
     * ontology on one shape instead of a hand-written interface that drifts.
     */
    /** The scalar forms a field may take. */
    export type MdmScalarKind = 'string' | 'text' | 'integer' | 'number' | 'money' | 'boolean' | 'date' | 'timestamp' | 'uuid';
    export type MdmValueTypeName = 'Address' | 'GeoPoint' | 'PrivacyConsent' | 'ContactSummary';
    export type MdmSubtypeName = 'Person' | 'Company' | 'ContactChannel' | 'Animal' | 'Product' | 'Service' | 'Location' | 'BankAccount' | 'Document' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment';
    /**
     * A field of the closed form. Absent flag = the default; `type` plus its own constraints carry everything,
     * so a constraint is never prose. `of` names a reusable type, `to` a record this one points at — both
     * checked by the compiler because they are unions of the declared names, not `string`.
     */
    export interface MdmDefField {
        type: MdmScalarKind | 'enum' | 'object' | 'record';
        required?: true;
        nullable?: true;
        collection?: true;
        /** A reusable type of `types`. */
        of?: MdmValueTypeName;
        /** Subtypes this field may point at. */
        to?: readonly MdmSubtypeName[];
        /** Closed domain. Plain strings when the label is the code itself. */
        values?: readonly string[];
        /** Inline object. */
        fields?: MdmDefFields;
        maxLength?: number;
        pattern?: string;
        min?: number;
        max?: number;
        default?: string | number | boolean;
        /** On `details` only: the branches the document is split into. */
        groups?: readonly string[];
        unique?: true;
        /** Backed by a real index today (a column of `identification` without it is a column with no index). */
        indexed?: true;
        /** The engine writes it; no form and no tool schema ever asks for it. */
        derived?: true;
        /** A prior read must supply this engine-owned value when a record is written. */
        writePrecondition?: boolean;
        /** Only when it differs from the id. */
        title?: string;
        description?: string;
    }
    export type MdmDefFields = Readonly<Record<string, MdmDefField>>;
    /** Catalog entry. `from`/`to` are subtype names, so a typo is a compile error and not a dead link. */
    export interface MdmDefRelationship {
        type: string;
        title: string;
        description: string;
        from: readonly MdmSubtypeName[];
        to: readonly MdmSubtypeName[];
        bidirectional: boolean;
        /** Values `mdm_relationship.role` accepts for this type. Empty when the type has no meaningful role. */
        roles: readonly string[];
        /** Keys the engine writes on each side's `relationshipRefs`, derived from `mapRelationshipKeys`. */
        compactKeys: {
            from: readonly string[];
            to: readonly string[];
        };
    }
    /**
     * One branch of `details`. `open: true` means the key set is not closed here: `general` is declared by the
     * organization in the project registry, and each module declares its own namespace in its own ontology.
     */
    export interface MdmDefGroup {
        type: 'object';
        owner: 'platform' | 'organization' | 'module';
        description: string;
        fields?: MdmDefFields;
        open?: true;
    }
    /**
     * A subtype carries only its DELTA: its own fields, and the capabilities and rules that are not universal.
     * The ids are plain strings here and are checked against the catalogs of the ontology object itself, in
     * `mdmOntology.test.ts` — the file is one JSON literal, so there is no `keyof typeof` to lean on inside it.
     */
    export interface MdmSubtypeDef {
        title?: string;
        description: string;
        fields: MdmDefFields;
        /** Only what does NOT apply to every subtype. */
        capabilities?: readonly string[];
        /** Only what does NOT apply to every subtype. */
        rules?: readonly string[];
    }
    export interface MdmOntology {
        schemaVersion: string;
        /** The three columns of `mdm_documents`, as fields, plus what a screen shows to recognise the record. */
        record: {
            fields: MdmDefFields;
            displayField: string;
        };
        types: Readonly<Record<MdmValueTypeName, MdmDefFields>>;
        /** The branches of `details`: `identification`, `base`, `general` and `<moduleId>`. The subtype branch
         * is not here — it comes from `subtypes.<S>.fields`, one per record. */
        groups: Readonly<Record<string, MdmDefGroup>>;
        subtypes: Readonly<Record<MdmSubtypeName, MdmSubtypeDef>>;
        relationships: readonly MdmDefRelationship[];
        /** id → one sentence: what it does · how · who uses it · platform: ready|partial|missing. */
        capabilities: Readonly<Record<string, string>>;
        /** id → one sentence: what is always true · who enforces it · platform. */
        rules: Readonly<Record<string, string>>;
        statuses: readonly string[];
        docTypes: readonly string[];
        storage: {
            indexTable: string;
            prospectIndexTable: string;
            documentTable: string;
            documentColumn: string;
            /** Document-visible columns that carry a real index today. */
            indexedColumns: readonly string[];
            reservedKeys: readonly string[];
        };
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    /**
     * The three families of data, by NATURE, not by origin (`hdm`/`vdm` classify origin and are another
     * axis): `mdm` is the master record of the organization, shared between modules; `tdm` is the movement,
     * the event, the operation of one module; `ddm` is what is recalculated from the other two and has no
     * writer at all.
     */
    export type DataFamilyName = 'mdm' | 'tdm' | 'ddm';
    /** What the platform really offers today for a capability. Measured, never promised. */
    export type DataFamilyReadiness = 'ready' | 'partial' | 'missing';
    /**
     * One capability of a family catalog. `sentence` is the same three-part line the `mdm` catalog writes as
     * prose (what it does · how · who uses it), `platform` the measured status, and `evidence` where it was
     * measured — `file.ts:line` or a section of `l1/mdm/mdmImplementation.md`. `evidence` is for whoever
     * reviews this file; the projection that reaches a prompt drops it.
     */
    export interface DataFamilyCapability {
        sentence: string;
        /** `table`: the module table engine itself. `platform`: lent by an MDM service. */
        source: 'table' | 'platform';
        platform: DataFamilyReadiness;
        evidence: string;
    }
    /**
     * The catalog a table of one family starts from, in the same spirit as `mdm.defs.ts`: the record it
     * carries, the lines the generator should keep in mind while writing it, what it may do, and the gap
     * between this file and the engine. `record.fields` uses the same field grammar as the platform record,
     * so `tsc` checks the shapes here too.
     */
    export interface DataFamilyOntology {
        schemaVersion: string;
        family: DataFamilyName;
        title: string;
        description: string;
        record: {
            fields: MdmDefFields;
        };
        /** One line each, read whole into the fan-out prompt: what this family's table looks like. */
        recommendations: readonly string[];
        capabilities: Readonly<Record<string, DataFamilyCapability>>;
        /** id → one sentence about where and how the rows live. */
        storage: Readonly<Record<string, string>>;
        /** id → what the engine does today where it differs from this document. Listed, never hidden. */
        knownDivergences: Readonly<Record<string, string>>;
    }
    type ScalarOf<K extends MdmScalarKind> = K extends 'string' | 'text' | 'date' | 'timestamp' | 'uuid' ? string : K extends 'integer' | 'number' | 'money' ? number : K extends 'boolean' ? boolean : never;
    type DefValue<F extends MdmDefField, O extends MdmOntology> = F extends {
        type: 'enum';
    } ? (F extends {
        values: readonly (infer V)[];
    } ? V : string) : F extends {
        type: 'record';
    } ? string : F extends {
        type: 'object';
    } ? F extends {
        fields: MdmDefFields;
    } ? InferGroup<F['fields'], O> : F extends {
        of: infer V extends MdmValueTypeName;
    } ? InferGroup<O['types'][V], O> : object : F extends {
        type: infer K extends MdmScalarKind;
    } ? ScalarOf<K> : never;
    type DefWrapped<F extends MdmDefField, O extends MdmOntology> = F extends {
        collection: true;
    } ? DefValue<F, O>[] : DefValue<F, O>;
    type DefNulled<F extends MdmDefField, O extends MdmOntology> = F extends {
        nullable: true;
    } ? DefWrapped<F, O> | null : DefWrapped<F, O>;
    type DefRequiredKeys<T extends MdmDefFields> = {
        [K in keyof T]: T[K] extends {
            required: true;
        } ? K : never;
    }[keyof T];
    type DefOptionalKeys<T extends MdmDefFields> = Exclude<keyof T, DefRequiredKeys<T>>;
    /** One group of `details` as a runtime object. */
    export type InferGroup<T extends MdmDefFields, O extends MdmOntology> = {
        [K in DefRequiredKeys<T>]: DefNulled<T[K], O>;
    } & {
        [K in DefOptionalKeys<T>]?: DefNulled<T[K], O>;
    };
    /**
     * The record of one subtype: `{ id, version, details }`, `details` grouped. The subtype group is keyed by
     * the subtype name with a lowercase first letter (`Person` → `person`, `AssetVehicle` → `assetVehicle`),
     * and any other key is a module namespace — an object only that module writes.
     */
    type GroupFields<O extends MdmOntology, K extends string> = O['groups'][K] extends {
        fields: infer F extends MdmDefFields;
    } ? F : MdmDefFields;
    export type InferMdmRecord<O extends MdmOntology, S extends MdmSubtypeName> = {
        id: string;
        version: number;
        details: {
            identification: InferGroup<GroupFields<O, 'identification'>, O>;
        } & {
            base: InferGroup<GroupFields<O, 'base'>, O>;
        } & {
            [K in Uncapitalize<S>]: InferGroup<O['subtypes'][S]['fields'], O>;
        } & {
            general?: object;
        } & {
            [moduleId: string]: object;
        };
    };
}
declare module "_102035_/l2/solution/types" {
    import type { MdmDefField, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    /**
     * p4_20: the read-only view of an artifact type, read only by the `.defs.ts` emitter
     * (`fs.ts` `renderDefsSource`: `as const satisfies Ns5Readonly<T>`). An `as const` literal is
     * read-only all the way down; the Studio compiler (TypeScript 5.0.2) refuses it against a mutable
     * array of `T` (TS1360), 5.9.3 accepts. The value keeps its own `as const` type, so readers of the
     * exported const see no change. The `Ns5*` types themselves stay as they are.
     */
    export type Ns5Readonly<T> = T extends readonly (infer U)[] ? readonly Ns5Readonly<U>[] : T extends object ? {
        readonly [K in keyof T]: Ns5Readonly<T[K]>;
    } : T;
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v2";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-11-ns5-ontology-v2";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_RULES_SCHEMA_VERSION_V2: "2026-09-16-ns5-rules-v2";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-12-ns5-workflows-v2";
    /**
     * ns5_48: v3 adds the `alert` stage (a recurring duty of a person). The shape is a superset of v2,
     * so there is ONE artifact interface and the version is a union — the same move ontology30 made with
     * `NS5_ONTOLOGY_SCHEMA_VERSION_V3`. `workflows50` emits v3; the thirteen recorded runs stay v2 and
     * are replayed through `buildNs5WorkflowsArtifact`.
     */
    export const NS5_WORKFLOWS_SCHEMA_VERSION_V3: "2026-09-17-ns5-workflows-v3";
    export type Ns5WorkflowsSchemaVersion = typeof NS5_WORKFLOWS_SCHEMA_VERSION | typeof NS5_WORKFLOWS_SCHEMA_VERSION_V3;
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-12-ns5-access-v3";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-12-ns5-integration-v2";
    export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION: "2026-09-12-ns5-integration-request-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    /**
     * ns5_49: `workflows50` runs BEFORE `ontology30`. A process stage cites the entity and the transition
     * it makes happen; the ontology then declares them with the stage as owner.
     * ns5_62: `judge35` runs AFTER `ontology30` and BEFORE `rules40`/`access60`. Completeness of the
     * journeys is judged only once the ontology (and the processes) exist. The numeric suffixes are
     * identity, not order — they are frozen so recorded runs keep their step ids.
     */
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "workflows50", "ontology30", "judge35", "rules40", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 copies survivors onto access.defs.ts; finalize80 I3 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    /**
     * access60 actor. `personEntity` is the role record this login is; `''` means this module has
     * none. Optional only so v3 files written before the field still satisfy the type. access60 always
     * writes it. Readers use `personEntity ?? ''`. Absence is not `''` for the gate.
     */
    export interface Ns5AccessActor extends Ns5ModuleActor {
        personEntity?: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, Ns5OntologyDetail>;
    }
    export interface Ns5JourneyStep {
        /** Identity of the step; I6 names a handoff by this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /**
         * Required on `kind: act`. `create` opens the record (or attaches, when mdm);
         * `transition` applies `transitionRef`; `update` writes fields without a state change.
         * Readers: I2, master backend, master frontend.
         */
        effect?: 'create' | 'update' | 'transition';
        /**
         * Required iff `effect === 'transition'`. Ontology `transitionId` of `entity` (lowerCamel).
         * Readers: I2, master backend, master frontend.
         */
        transitionRef?: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from the pipeline (then access.defs.ts). */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyDetail {
        /** Typed JSON column and screen formatting. */
        type: Ns5OntologyField['type'];
        /** Planner / UI; rules may cite details.<name>. */
        description: string;
    }
    export interface Ns5OntologyEnumValue {
        /** Stable English lowerCamel code; status.enum.value covers lifecycleStates[].state. */
        value: string;
        /** Screen select/badge label in userLanguage. */
        title: string;
    }
    export interface Ns5OntologyFieldConstraints {
        /** Inclusive lower bound; number, integer or money. */
        min?: number;
        /** Inclusive upper bound; number, integer or money. */
        max?: number;
        /** string or text only. */
        maxLength?: number;
        /** money or number only. */
        precision?: number;
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Simple uniqueness; DDL unique index. Never the identity field. */
        unique?: boolean;
        /** Closed domain; value is the code, title is the screen label. */
        enum?: Ns5OntologyEnumValue[];
        /** Intrinsic to the type (day 1..31, percent 0..100). Never a business policy. */
        constraints?: Ns5OntologyFieldConstraints;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** kind mdm only: level-1 fields this role uses (selection, tightened domain); stores nothing in the module. Readers: f2_04b screen, access60 (ns5_35), masters. */
        fieldsBase?: Ns5OntologyField[];
        /** Composite uniqueness; fieldIds of this entity, never idField. finalize80 I9. */
        uniqueKeys?: string[][];
        /** Calculated values; typed JSON column; rules may cite details.<name>. */
        details?: Record<string, Ns5OntologyDetail>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
        /**
         * How this entity is written. Omitted = `journey` (an `act` writes it as `entity` or `affects`).
         * `crud` = reference catalog nobody creates in a journey (no lifecycle); master
         * frontend emits a data grid, master backend emits CRUD usecases.
         * `inbound` = created/updated by an integration inbound item; integration70 requires
         * a matching `inbound.writes` row. ontology30 normalize drops `crud`/`inbound` when
         * an act already writes the entity. ontology30 / access60 / finalize80 I10 I8.
         * Replaces `maintenance?: 'crud'` (ns5_31).
         */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** Ontology screen edge label; master frontend. One sentence, userLanguage. */
        description: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V3: "2026-09-15-ns5-ontology-v3";
    /**
     * v3.1 (ns5_47): what nobody writes is a `derived` field of the row (`description` says the condition), not a
     * lifecycle state; `time` is therefore gone from `reachedBy` and from `by`. The v3 artifacts already
     * recorded stay readable — the form only lost a way of saying something, so every reader accepts both
     * versions through `isNs5OntologyV3Version` and only the generator emits v3.1.
     */
    export const NS5_ONTOLOGY_SCHEMA_VERSION_V31: "2026-09-17-ns5-ontology-v3.1";
    export type Ns5OntologySchemaVersionV3 = typeof NS5_ONTOLOGY_SCHEMA_VERSION_V3 | typeof NS5_ONTOLOGY_SCHEMA_VERSION_V31;
    /** Every reader of the v3 form asks this, never an equality against one constant. */
    export function isNs5OntologyV3Version(value: unknown): value is Ns5OntologySchemaVersionV3;
    /** Closed-domain value of a v3 field: the bare code, or the code plus its label. */
    export type Ns5OntologyValueV3 = string | {
        value: string;
        title?: string;
        description?: string;
    };
    /** One field of a v3 record. The platform grammar, widened where a module needs it (see above). */
    export interface Ns5OntologyFieldV3 extends Omit<MdmDefField, 'to' | 'values' | 'fields' | 'groups'> {
        /** MDM subtypes AND entity ids of this module. */
        to?: readonly string[];
        values?: readonly Ns5OntologyValueV3[];
        fields?: Ns5OntologyFieldsV3;
        /**
         * Only on a branch of `details`: who writes it. `platform` = the MDM record,
         * `organization` = the promoted layer, `module` = `details.<moduleName>`.
         */
        owner?: 'platform' | 'organization' | 'module';
        /** Only on a branch: the key set is not closed here (declared elsewhere). */
        open?: true;
    }
    export type Ns5OntologyFieldsV3 = Readonly<Record<string, Ns5OntologyFieldV3>>;
    /** One named link of an entity. `relationshipId` is the row of the module index that carries it. */
    export interface Ns5OntologyRelationshipV3 {
        /** Must exist in `index.defs.ts`; that index is the source, this is the reading copy. */
        relationshipId: string;
        /** Entity id of this module, or an MDM subtype. */
        to: string;
        /**
         * `mode: 'fk'` — the column that holds it; `mode: 'throughTable'` — the table walked;
         * absent mode — the MDM relationship type of `mdm.relationships[].type`.
         */
        via: string;
        mode?: 'fk' | 'throughTable';
        /** Which end of the catalog link this entity sits on, when it is not the `from`. */
        direction?: 'from' | 'to';
        /** Role of `mdm_relationship.role`, single or many. */
        role?: string;
        roles?: readonly string[];
        cardinality: '1:1' | '1:N' | 'N:1' | 'N:N';
        /** `true`, or the condition in the user language ("quando menor de 18 anos"). */
        required?: boolean | string;
        /** Walked, never stored. */
        derived?: true;
        /** Only on `throughTable`: the walk, as written. */
        path?: string;
        /** Planner / screen. */
        title: string;
        description?: string;
        /** Narrows the far end, field → accepted values. */
        target?: Readonly<Record<string, readonly string[]>>;
    }
    /** What a `role` and a table share. Exported so `nsArtifactFieldRatchet.test.ts` can reach its keys. */
    export interface Ns5OntologyEntityV3Base<Cap extends string = string, Rule extends string = string> {
        /** Gate: the v3 form. */
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        title: string;
        description: string;
        /** Path a screen shows to recognise the record: `details.identification.name`, `scheduledAt`. */
        displayField: string;
        /** `{ id, version, details }` on a role; plus the indexed columns on an entity. */
        record: {
            fields: Ns5OntologyFieldsV3;
        };
        /** Composite uniqueness, by field id. */
        uniqueKeys?: readonly (readonly string[])[];
        /** ns5_47: only what somebody moves. A condition over data is a `derived` field of the row. */
        lifecycleStates?: readonly {
            state: string;
            reachedBy: 'actor' | 'command';
        }[];
        transitions?: readonly {
            transitionId: string;
            from: readonly string[];
            to: string;
            /** Actor ids of the module; empty when a process owns the move. */
            by: readonly string[];
            description: string;
            /** Record paths the transition command consumes; an explicit empty list means identity only. */
            payload?: readonly string[];
            ruleRefs?: readonly string[];
        }[];
        relationships: Readonly<Record<string, Ns5OntologyRelationshipV3>>;
        /**
         * id → one sentence. A platform id of `mdm.capabilities`, or `<moduleName>.<id>`.
         * Optional per key because an entity picks from the catalog; that `Cap` is an upper bound and not a
         * requirement. Assigning a `const` here therefore does NOT reject an invented id (no excess-property
         * check off a fresh literal) — a reader that wants that proof asserts `Exclude<keyof …, Cap>` is
         * `never`, as `resolveMdmEntity.test.ts` does.
         */
        capabilities: {
            readonly [K in Cap]?: string;
        };
        /** Ids of `mdm.rules` ∪ `ruleId` of the module `rules.defs.ts`. */
        rules: readonly Rule[];
        /** How the entity is written, when it is not a journey. */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    /** A papel of this module over an MDM record. Stores nothing but `details.<moduleName>`. */
    export interface Ns5OntologyRoleV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'role';
        /** The MDM subtype the papel sits on; must be a key of `mdm.subtypes`. */
        subtype: MdmSubtypeName;
        /** `<moduleName>.<entityId>`; what `attachRole` writes into `identification.tags`. */
        roleTag: string;
        /** The platform ontology this papel copies from. */
        source: string;
    }
    /** A table of the module. */
    export interface Ns5OntologyTableV3<Cap extends string = string, Rule extends string = string> extends Ns5OntologyEntityV3Base<Cap, Rule> {
        kind: 'entity';
        class: 'core' | 'event' | 'supporting';
        /**
         * `kind` is the family's storage (ns5_46): `relational` is one Postgres table of the module,
         * `timeSeries` a series chunked by time. Optional because the hand-written v3 form predates it and a
         * table without it is read as `relational`.
         */
        storage: {
            target: 'moduleDatabase';
            table: string;
            kind?: 'relational' | 'timeSeries';
        };
    }
    export type Ns5OntologyEntityV3<Cap extends string = string, Rule extends string = string> = Ns5OntologyRoleV3<Cap, Rule> | Ns5OntologyTableV3<Cap, Rule>;
    /** One row of the v3 index: the canonical list of entities. */
    export interface Ns5OntologyIndexEntityV3 {
        entityId: string;
        kind: 'role' | 'entity';
        /** On `role` only. */
        subtype?: MdmSubtypeName;
        /** On `entity` only. */
        class?: 'core' | 'event' | 'supporting';
    }
    /** One row of the v3 index: the canonical list of links. The entities repeat these for reading. */
    export interface Ns5OntologyIndexRelationshipV3 {
        relationshipId: string;
        from: string;
        to: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        mode: 'fk' | 'mdmRelationship' | 'throughTable';
        /** `mode: 'fk'`: the column, as `Entity.field`. */
        field?: string;
        /** `mode: 'mdmRelationship'`: a `type` of `mdm.relationships`. */
        catalogType?: string;
        /** `mode: 'throughTable'`: the entity walked. */
        through?: string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        description: string;
    }
    export interface Ns5OntologyIndexV3 {
        schemaVersion: Ns5OntologySchemaVersionV3;
        moduleName: string;
        businessDomain: string;
        /** Path of the platform ontology this module is written on top of. */
        platformOntology: string;
        /** The branch of `details` only this module writes. */
        moduleNamespace: {
            key: string;
            description: string;
        };
        entities: readonly Ns5OntologyIndexEntityV3[];
        relationships: readonly Ns5OntologyIndexRelationshipV3[];
    }
    /** What a reader gets from an ontology entity file, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5OntologyAnyEntity = Ns5OntologyEntityArtifact | Ns5OntologyEntityV3;
    /** The discriminator every reader of a written entity uses; accepts v3 and v3.1 alike (ns5_47). */
    export function isNs5OntologyEntityV3(entity: Ns5OntologyAnyEntity): entity is Ns5OntologyEntityV3;
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    /**
     * The same catalog as a MAP, aligned with `mls-102034/l4/ontology/mdm.defs.ts`, whose `rules` and
     * `capabilities` are both `Record<id, sentence>` — one id, one sentence, no place to put a second.
     * `rules40` emits this form; the v1 array above stays valid and is still what the recorded runs hold.
     * Read either form through `solution/rulesView.ts`, never by branching on the field.
     *
     * The TOOL still asks for `[{ ruleId, description }]`: a strict tool schema must declare
     * `additionalProperties: false` on every object, so an open key set is not expressible
     * (`steps/ontology30/contractsV3.ts:175` says the same of `record.fields` and `capabilities`).
     * Array to map is the normalize's job.
     */
    export interface Ns5RulesArtifactV2 {
        /** Discriminates the two forms. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION_V2;
        /** Folder. */
        moduleName: string;
        /** `ruleId` to the one business sentence; I4 checks cited ruleRefs exist. */
        rules: Readonly<Record<string, string>>;
    }
    /** What a reader gets from `rules.defs.ts`, whichever form it is in. Discriminate on `schemaVersion`. */
    export type Ns5RulesAny = Ns5RulesArtifact | Ns5RulesArtifactV2;
    export interface Ns5WorkflowTrigger {
        /** Gate: scheduled needs schedule, event needs event, manual needs actorRef. */
        kind: 'scheduled' | 'event' | 'manual';
        /** Required iff kind === 'scheduled'. Prose ("every month, day 1"). Backend job. */
        schedule?: string;
        /** Required iff kind === 'event'. '<Entity>.<transitionId>' of this module (inbound '<mod>.<eventId>' is ns5_31). */
        event?: string;
        /** Required iff kind === 'manual'. */
        actorRef?: string;
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. Unique in the process. */
        taskId: string;
        /**
         * Gate: no neutral value; every stage is one of these. `alert` (v3, ns5_48) is a recurring duty
         * of a person: the schedule is on `trigger`, the instruction is the `description`, and it carries
         * neither journeyRef nor entityRef.
         */
        kind: 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
        /** Required on human and on alert. */
        actorRef?: string;
        /** Required on human, forbidden on alert. The journey the person runs, never a screen step. */
        journeyRef?: string;
        /** Required on mechanical|llm. Entity the stage acts on. */
        entityRef?: string;
        /** Required on mechanical|llm. Same form as act.effect (ns5_28). */
        effect?: 'create' | 'update' | 'transition';
        /** Required iff effect === 'transition'. Ontology transitionId; by is system or the actor. */
        transitionRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. Wait: the pause (time or event) in prose. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** How the process starts. Tela da Fase 2, harness, backend job. */
        trigger: Ns5WorkflowTrigger;
        /** finalize80 I6: every journey handoff appears as a human journeyRef. */
        tasks: Ns5WorkflowTask[];
    }
    export interface Ns5JourneyDecision {
        /** Must exist in the journey index. Tela da Fase 2 shows why a journey stayed out. */
        journeyId: string;
        /** One decision per journey in the same LLM call. */
        inProcess: boolean;
        /** Required iff inProcess. */
        processId?: string;
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty processes is valid. v2 recorded on disk stays readable. */
        schemaVersion: Ns5WorkflowsSchemaVersion;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
        /** One row per journey; the screen lists who is in a process. */
        journeyDecisions: Ns5JourneyDecision[];
        /** workflows50 normalize: dropped duplicate stages. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. Unique. */
        grantId: string;
        /** Must be an actorId from access.actors. */
        actorRef: string;
        /** Access matrix screen. */
        title: string;
        /** Access matrix screen. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Pipeline actors plus personEntity. The LLM does not emit this list; access60 merges actorPersons onto it. */
        actors: Ns5AccessActor[];
        /** The grant is the capability. Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. Unique across inbound and outbound. */
        id: string;
        /** Gate vs registry / plugin catalogue / platform events. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** Inbound source: sibling module, `organization` (platform catalog), or external system. */
        from?: string;
        /** Outbound destination: sibling module, `any`, or external system. */
        to?: string;
        /** Event id this row receives (inbound) or publishes (outbound). Defaults to `id`. */
        event?: string;
        /**
         * Inbound: entities of this module the arrival creates/updates.
         * Counts as a writer (ontology30 WITHOUT_WRITER, access60, I10) and as `trigger.event`.
         */
        writes?: string[];
        /** Inbound: what the arrival does to `writes`. Required on inbound. */
        effect?: 'create' | 'update' | 'transition';
        /** Inbound, required iff `effect === 'transition'`. */
        transitionRef?: string;
        /**
         * Outbound: when this module publishes. `Entity.transitionId` or `Entity.create`.
         * Payload is the entity record at that moment (not declared in l4). I12 checks it exists.
         */
        on?: string;
        /** Planner / UI. Cites `inbound.id` when the rule maps a sibling payload. */
        description: string;
        /** Outbound (and inbound leftover): entity ids this row touches. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** `journeyId.stepId` or `processId.taskId` that uses the plugin. I12. */
        usedBy: string[];
    }
    /** Queued request that a sibling (or a predicted module) publish an event. */
    export interface Ns5IntegrationRequestArtifact {
        schemaVersion: typeof NS5_INTEGRATION_REQUEST_SCHEMA_VERSION;
        requestedBy: string;
        eventId: string;
        on?: string;
        entityRefs: string[];
        description: string;
        status: 'requested';
        /** Organization inbox: the predicted module that should publish. */
        to?: string;
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    /** Form change recorded on `pipeline.json` `steps.<step>`. Shape is step-specific. */
    export interface Ns5PipelineNormalization {
        kind: string;
        detail: string;
        entityId?: string;
        grantId?: string;
        journeyId?: string;
        stepId?: string;
        inboundId?: string;
        /** access60 `anchorFromActor`: the anchor the model wrote. */
        from?: string;
        /** access60 `anchorFromActor`: the actor's personEntity. */
        to?: string;
    }
    export interface Ns5PipelineLiftedField {
        entityId: string;
        detail: string;
    }
    /**
     * p4_20: the Studio compile of the `.defs.ts` a step wrote, recorded on `steps.<step>.compile`.
     * `unavailable` is the absence of `mls.l2.typescript` (or of a model/dependency to compile): a state,
     * never a clean compile. Reader: finalize80 (`ns5CompileBlockers`), which runs the oracle only when
     * every writing step recorded `clean`.
     */
    export interface Ns5CompileRecord {
        status: 'clean' | 'errors' | 'unavailable';
        /** How many `.defs.ts` the step asked the compiler about. */
        files: number;
        /** `errors`: one line per diagnostic, prefixed by the display path of the file. */
        errors?: string[];
        /** `unavailable`: why nothing was compiled. */
        reason?: string;
    }
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /**
         * module10: actors the normalize removed because they are external systems, not people
         * (`dropSystemActor<Actor>`). An external system the request names is a plugin or an inbound of
         * integration70, never an actor. The clarification/maintenance screen of Fase 2 reads this to
         * show what the step decided without asking.
         */
        systemDecisions?: Ns5SystemDecision[];
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /**
         * Form changes this step applied (pt→pt-BR, dropCrud, liftedFields, …).
         * Same records as the step draft `normalizations[]`. Fase 2 reads this.
         */
        normalizations?: Ns5PipelineNormalization[];
        /**
         * ontology30: extra fields discarded when a panel entity was lifted
         * (`normalizations[].kind === 'liftedFields'`).
         */
        liftedFields?: Ns5PipelineLiftedField[];
        /**
         * ontology30 v3: rule ids the entities cited, platform and module together. `rules40` receives the
         * module ones as data and has to produce them (ns5_42 T7 records it; ns5_43 T2 wires the reading).
         */
        citedRules?: string[];
        /** ontology30 v3: capability ids the entities cited, catalog and module together. */
        citedCapabilities?: string[];
        /** module10: actors born by the step. Later steps read them via `readNs5Actors`. */
        actors?: Ns5ModuleActor[];
        /** journeys20: actorIds dropped as inferred-external without an exclusive step. */
        droppedActors?: string[];
        /** workflows50: true when processes is [] because there is no handoff, no cross-actor decide and no time/event phrase in the prompt. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
        /** judge35: true when the deterministic candidate list was empty and the step approved without an LLM call. */
        noJudgeSignal?: boolean;
        /** judge35: `transitionUnjustified` verdicts recorded for the human; the transition is not deleted. */
        warnings?: string[];
        /** p4_20: Studio compile of the `.defs.ts` this step wrote. Reader: finalize80. */
        compile?: Ns5CompileRecord;
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module (l1/l2/l4/l5 trees plus l5 json / registry). */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** Display paths unlinked under l1/l2/l4/l5/<module>/. */
        deleted: string[];
        /** Display paths rewritten (l5 jsons and the organization registry). */
        edited: string[];
        at: string;
    }
    /** Mailbox of the module pool: one folder per owner (`l4/<module>/pool/<box>/`). */
    export type PoolBox = 'l1' | 'l2' | 'l4';
    /** Implement = do it; estimate = simulate the change and answer the cost. */
    export type PoolMode = 'implement' | 'estimate';
    /** What the owner did with the message it processed. */
    export type PoolOutcome = 'delivered' | 'processed' | 'disputed';
    /**
     * One processed pool message, appended to `pipeline.json`. Readers: the pool screen (p4_04) and
     * L4 itself (round counting). Helpers in `/_102035_/l2/solution/pool.js`.
     */
    export interface PoolTraceLine {
        /** ISO timestamp of the trace. */
        at: string;
        /** Display path of the message file, e.g. `l4/<module>/pool/l2/<stamp>_<thread>_<round>.json`. */
        file: string;
        from: PoolBox;
        to: PoolBox;
        thread: string;
        round: number;
        mode: PoolMode;
        outcome: PoolOutcome;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        /** Pool trace, appended by `tracePool`. Absent in pipelines written before the pool existed. */
        pool?: PoolTraceLine[];
        /**
         * What `agentPlannerL4` entry10 added to `l5/config.json` (reader: that step).
         * Tokens like `workspaceDependencies:+102021`. Absent when nothing was missing.
         */
        l5Adjusted?: string[];
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102035_/l2/solution/helpers/organizationTypes";
}
declare module "_102035_/l2/solution/fs" {
    import type { Ns4SolutionRegistryArtifact } from "_102035_/l2/solution/helpers/organizationTypes";
    import type { Ns5OntologyAnyEntity, Ns5PipelineState, Ns5StepId } from "_102035_/l2/solution/types";
    export type Ns5FileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export function normalizeModuleName(value: unknown, fallback?: string): string;
    /**
     * Point `moduleFolder` at a root relative to `l4/` (example: `stockControl/tobe/plan`).
     * `null` or `''` restores the canonical folder. Lives on the current `mls` (the task process).
     */
    export function setModuleRoot(moduleName: string, relativeRoot: string | null): void;
    /** `l4/<mod>` or the `/candidate` override when `setModuleRoot` was called. */
    export function moduleFolder(moduleName: string): string;
    export function moduleFile(moduleName: string): Ns5FileInfo;
    /** Read-only callers such as the Studio module browser must not depend on mls.actualProject. */
    export function moduleFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function journeyFile(moduleName: string, journeyId: string): Ns5FileInfo;
    export function journeyIndexFile(moduleName: string): Ns5FileInfo;
    export function ontologyEntityFile(moduleName: string, entityId: string): Ns5FileInfo;
    export function ontologyIndexFile(moduleName: string): Ns5FileInfo;
    export function rulesFile(moduleName: string): Ns5FileInfo;
    export function workflowsFile(moduleName: string): Ns5FileInfo;
    export function accessFile(moduleName: string): Ns5FileInfo;
    export function integrationFile(moduleName: string): Ns5FileInfo;
    /** `l4/<target>/tobe/integration/<requestedBy>--<eventId>.defs.ts` — no extra dot in shortName. */
    export function integrationRequestFile(targetModule: string, requestedBy: string, eventId: string): Ns5FileInfo;
    export function collectTobeIntegrationFilesCiting(moduleName: string): mls.stor.IFileInfo[];
    export function pipelineFile(moduleName: string): Ns5FileInfo;
    export function pipelineFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function pipelineJsonFile(moduleName: string, shortName: string): Ns5FileInfo;
    export function pipelineJsonFileForProject(project: number, moduleName: string, shortName: string): Ns5FileInfo;
    export function finalizeReportFile(moduleName: string): Ns5FileInfo;
    export function finalizeReportFileForProject(project: number, moduleName: string): Ns5FileInfo;
    export function listPipelineJsonShortNames(moduleName: string): string[];
    export function draftFile(moduleName: string, step: Ns5StepId | string): Ns5FileInfo;
    export function agentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function registryFile(): Ns5FileInfo;
    export function displayPath(fileInfo: Ns5FileInfo): string;
    export function assertShortName(shortName: string): void;
    export function fileExists(fileInfo: Ns5FileInfo): boolean;
    export function listModuleFolders(): Set<string>;
    export function isExactModuleFolder(folder: string, moduleName: string): boolean;
    export const MODULE_TREE_LEVELS: readonly [1, 2, 4, 5];
    export function isProtectedModuleFile(file: {
        level?: number;
        folder?: string;
        shortName?: string;
    }): boolean;
    export function listModuleL4Keys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** Index (`mls.stor.files`) of exact `l<level>/<mod>/**`. Never prefix; never protected paths; never host disk. */
    export function collectExactModuleFiles(moduleName: string, levels?: readonly number[]): mls.stor.IFileInfo[];
    export type Ns5DefsKind = 'journeys' | 'ontology';
    type ListedStorFile = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    /**
     * The `mls.stor.files` entry for `info`, or undefined. The index is the only source the l4 lists,
     * deletes and judges by — it is what the Studio (browser) has; host disk never decides (p4_19).
     */
    export function indexedFile(info: ListedStorFile): mls.stor.IFileInfo | undefined;
    /**
     * Host disk listing (`mls.stor.localStor.listFolder`); undefined outside the host.
     * The l4 no longer reads it (p4_19); still exported for the L1/L2 callers outside this spec.
     */
    export function hostListFolder(): ((project: number, level: number, folder: string) => ListedStorFile[]) | undefined;
    /**
     * An `mls.stor.files` entry for a file seen on host disk but absent from the index.
     * The l4 no longer calls it (p4_19); still exported for the L1/L2 callers outside this spec.
     */
    export function diskFileInfo(info: ListedStorFile): mls.stor.IFileInfo;
    /** shortNames of `.defs.ts` in `l4/<mod>/<kind>/` from the index, including status=deleted; never host disk. */
    export function listModuleDefsShortNames(moduleName: string, kind: Ns5DefsKind): string[];
    export function ns5DefsOrphans(diskShortNames: string[], indexIds: string[]): string[];
    export function reconcileModuleDefs(moduleName: string, kind: Ns5DefsKind, indexIds: string[]): Promise<string[]>;
    export function readJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    export function writeJson(fileInfo: Ns5FileInfo, value: unknown): Promise<string>;
    export function writeDefs(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): Promise<string>;
    export function renderDefsSource(fileInfo: Ns5FileInfo, exportName: string, value: unknown, typeName: string): string;
    export function readPipeline(moduleName: string): Promise<Ns5PipelineState | null>;
    export function readPipelineForProject(project: number, moduleName: string): Promise<Ns5PipelineState | null>;
    export function writePipeline(state: Ns5PipelineState): Promise<string>;
    export function readAgentText(folder: string, shortName: string, extension?: string): Promise<string>;
    export function readAgentJson<T>(folder: string, shortName: string, extension?: string): Promise<T>;
    export function readDefsJson<T>(fileInfo: Ns5FileInfo): Promise<T | null>;
    /** Preserve the exact L4 source when sealing a release or copying it to the candidate. */
    export function readSourceText(fileInfo: Ns5FileInfo): Promise<string>;
    export function writeSourceText(fileInfo: Ns5FileInfo, source: string): Promise<void>;
    /**
     * An ontology entity file in whichever form it is written (ns5_39 T4). Both forms are one JSON literal,
     * so the reading is the same; only the type of what comes back changes, and `schemaVersion` is the
     * discriminator — v3 (`agendaClinica`) carries `record`, v2 (the other eleven modules) carries `fields`.
     */
    export function readOntologyEntityAny(fileInfo: Ns5FileInfo): Promise<Ns5OntologyAnyEntity | null>;
    export function readSolutionRegistry(): Promise<Ns4SolutionRegistryArtifact | null>;
}
declare module "_102035_/l2/solution/pool" {
    import type { Ns5FileInfo } from "_102035_/l2/solution/fs";
    import type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine } from "_102035_/l2/solution/types";
    export type { PoolBox, PoolMode, PoolOutcome, PoolTraceLine };
    export const POOL_BOXES: readonly ["l1", "l2", "l4"];
    export const POOL_MODES: readonly ["implement", "estimate"];
    export const POOL_OUTCOMES: readonly ["delivered", "processed", "disputed"];
    /** Three rounds per side. At 3/3 without agreement the message is NOT deleted: it becomes a human pending. */
    export const POOL_MAX_ROUND = 3;
    /** The whole message. Nothing is optional; lists may be empty. */
    export interface PoolMessage {
        from: PoolBox;
        to: PoolBox;
        /** `<module>-<yyyymmddhhmmss>` of the message that opened the thread. */
        thread: string;
        /** 1..POOL_MAX_ROUND. */
        round: number;
        mode: PoolMode;
        /** One line. */
        subject: string;
        /** Paths relative to the module folder. */
        artifacts: string[];
        body: string;
    }
    /** `yyyymmddhhmmss` in UTC — the order of the mailbox is the order of the name. */
    export function poolStamp(now: Date): string;
    /** Thread id of a message that opens a conversation about `moduleName`. */
    export function nextThread(moduleName: string, now: Date): string;
    /** Rejects with a named cause; never repairs quietly. */
    export function normalizePoolMessage(value: unknown): PoolMessage;
    /** `l4/<module>/pool/<box>/<shortName>.json`, in the project of the run. */
    export function poolFile(moduleName: string, box: PoolBox, shortName: string): Ns5FileInfo;
    /**
     * Writes the message into the box of `msg.to`. `now` is explicit because the file name carries it
     * and the caller — not the clock — decides which moment the message belongs to.
     */
    export function writePoolMessage(moduleName: string, msg: unknown, now: Date): Promise<Ns5FileInfo>;
    /**
     * `<stamp>_<thread>_<round>`, o nome que o `writePoolMessage` gera. Um `.json` na caixa que não siga
     * isso não é mensagem do pool — a p2_09 põe um `menu.json` ali — e é **ignorado**, não é erro: a caixa
     * é de quem a lê, e nada impede o dono de guardar outro arquivo dentro dela.
     *
     * O padrão fica **frouxo de propósito**: o formato do `thread` e a faixa do `round` são recusados com
     * causa nomeada na leitura (`normalizePoolMessage`), e repeti-los aqui seria a mesma regra em dois
     * lugares. Mais importante: errar para o lado estrito esconderia uma mensagem real da caixa, e caixa
     * que parece vazia faz a guarda de pendência não disparar — é a direção cara do erro.
     */
    export function isPoolMessageShortName(shortName: string): boolean;
    /** Oldest first, by name. Index only (`mls.stor.files`) — what the Studio sees; host disk never adds a message. */
    export function listPoolBoxForProject(project: number, moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function listPoolBox(moduleName: string, box: PoolBox): Ns5FileInfo[];
    export function readPoolMessage(file: Ns5FileInfo): Promise<PoolMessage>;
    /** Any non-empty box — this is what blocks a new `tobe/`. */
    export function poolHasPending(moduleName: string): boolean;
    /**
     * Same normalize and return (`traceId`) as `tracePool`, but writes the line on the
     * `pipeline.json` that `fileInfo` points at — each owner traces on its own file.
     */
    export function tracePoolAt(fileInfo: Ns5FileInfo, line: unknown): Promise<string>;
    /**
     * Appends the line to `pipeline.json` and returns its id — the display path of the message,
     * which is unique per message and is what `deletePoolMessage` demands.
     * Shortcut: traces on the l4 pipeline of `moduleName`.
     */
    export function tracePool(moduleName: string, line: unknown): Promise<string>;
    /** Reads the trace at the given `pipeline.json` (empty when the file has none). */
    export function readPoolTraceAt(fileInfo: Ns5FileInfo): Promise<PoolTraceLine[]>;
    /** Reads the trace of the module (empty when the pipeline has none). */
    export function readPoolTrace(moduleName: string): Promise<PoolTraceLine[]>;
    /**
     * Same check and delete as `deletePoolMessage`, but the trace is read from the `pipeline.json`
     * that `fileInfo` points at — each owner traces (and therefore deletes) on its own file.
     */
    export function deletePoolMessageAt(fileInfo: Ns5FileInfo, file: Ns5FileInfo, traceId: string): Promise<string>;
    /**
     * Last operation of whoever processes a message: only the owner deletes, and only after the
     * trace line is written — `traceId` is the id `tracePool` returned. Shortcut: checks the l4
     * pipeline of `moduleName`.
     */
    export function deletePoolMessage(moduleName: string, file: Ns5FileInfo, traceId: string): Promise<string>;
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/dispatch" {
    /**
     * Optional pool transport (d1_38, chain rule of 28/09: dispatching a run authorizes it).
     * The command authorizes the run. An `implement` in `l4/<module>/pool/l1` may be the dispatch that
     * carried it, never a proof: entry10 only lists the ones present when it ran, and finalize80,
     * once the defs are complete, traces each of those in its report and then deletes it.
     * Estimate messages belong to agentPlannerL1 and are never listed. A later arrival is another
     * execution's and stays. Pool shape follows `solution/pool.ts`; only its types come from 102035.
     */
    import type { PoolTraceLine } from "_102035_/l2/solution/pool";
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    /** Display paths of the l1 dispatches present now. Read-only; the entry never depends on it. */
    export function listDispatchMessages(project: number, moduleName: string): Promise<string[]>;
    export interface DispatchConsumption {
        /** Trace lines to append to the report, before any delete. */
        lines: PoolTraceLine[];
        /** Store files to delete once the lines are on disk. */
        files: D1FileInfo[];
    }
    /**
     * The dispatches entry10 listed that are still in pool/l1. Lines already traced are not
     * repeated (a crash after the trace only deletes on the next pass). Nothing else is touched.
     */
    export function dispatchConsumption(project: number, moduleName: string, listed: readonly string[], traced: readonly PoolTraceLine[], now: Date): Promise<DispatchConsumption>;
    /**
     * Deletes each file only if `traced` (the report as read back from disk) holds its `processed`
     * line. Otherwise throws before deleting it: trace first, then delete (`deletePoolMessageAt`).
     */
    export function deleteTraced(files: readonly D1FileInfo[], traced: readonly PoolTraceLine[]): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst" {
    export interface D1ContractField {
        name: string;
        type: string;
        optional: boolean;
    }
    export interface D1ContractSymbol {
        name: string;
        fields: D1ContractField[];
        /** `array` when the exported type is an array. The element fields stay the contracted item. */
        shape: 'object' | 'array';
        /** Element symbol when an array alias points at another type. Empty when the fields are inline. */
        element: string;
    }
    export interface D1ContractAst {
        symbols: D1ContractSymbol[];
        /**
         * Exported declarations this reader could see but not close.
         * Callers surface each entry as `CONTRACT_UNPARSED`. Empty on a file this reader finished.
         */
        unparsed: string[];
    }
    /**
     * Reads exported type shapes. Route identity is the promoted v2 parser, not
     * `export const routes` or a `*Route` const. The first interface, and a name
     * that matches the usecase, are not an identity.
     * Deno loads this file with the agent. It must not import `typescript`.
     */
    export function readContractAst(source: string, fileName: string): D1ContractAst;
    /** The unique symbol of this name, or null when it is missing or duplicated. */
    export function symbolFields(ast: D1ContractAst, name: string): D1ContractField[] | null;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/contracts" {
    import type { D1ContractAst } from "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst";
    export const D1_INPUT_VERSION: "2026-10-01-d1-input-v2";
    /** P1 operation vocabulary (`agentPlannerL1` plan20). Not imported from that agent. */
    export const D1_P1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export const D1_SOURCE_SCHEMAS: {
        readonly module: "2026-09-10-ns5-module-v2";
        readonly journey: "2026-09-10-ns5-journey-v1";
        readonly ontology: "2026-09-17-ns5-ontology-v3.1";
        readonly rules: "2026-09-16-ns5-rules-v2";
        readonly workflows: "2026-09-17-ns5-workflows-v3";
        readonly access: "2026-09-12-ns5-access-v3";
        readonly integration: "2026-09-12-ns5-integration-v2";
        readonly menu: "2026-09-20-p2-menu-v2.2";
        readonly needs: "2026-09-21-p2-needs-v1";
        readonly backend: "2026-09-21-p1-backend-v1.2";
        readonly effort: "2026-09-21-p2-effort-v1.2";
        readonly planner: "2026-09-20-p1-pipeline-v1";
    };
    /** `backend.json.testSupport[]` (p1_12). Same enums as agentPlannerL1 plan20; D1 checks, never fills. */
    export const D1_TEST_SUPPORT_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export const D1_TEST_SUPPORT_OWNERS: readonly ["L1", "runtime"];
    export const D1_PLANNER_FLOW: "agentPlannerL1";
    export const D1_EFFORT_BACKEND_REF: "pool/l2/web/backend.json";
    export const D1_ACTIVE_STATUSES: readonly ["toCreate", "toUpdate", "done"];
    export type D1ActiveStatus = typeof D1_ACTIVE_STATUSES[number];
    export type D1PlanStatus = D1ActiveStatus | 'toRemove';
    export type D1FileAction = 'create' | 'update' | 'preserve' | 'recompose' | 'remove' | 'conflict';
    export type D1ProblemSeverity = 'error' | 'review';
    export interface D1InputProblem {
        severity: D1ProblemSeverity;
        code: string;
        path: string;
        message: string;
        ownerRef?: string;
    }
    export interface D1SourceDigest {
        path: string;
        sha256: string;
        bytes: number;
        schemaVersion: string;
        state: 'present' | 'missing' | 'invalid';
    }
    export interface D1PresentDef {
        path: string;
        sha256: string;
    }
    export interface D1InputArtifacts {
        sources: D1SourceDigest[];
        module: unknown;
        journeyIndex: unknown;
        journeys: Record<string, unknown>;
        ontologyIndex: unknown;
        entities: Record<string, unknown>;
        rules: unknown;
        workflows: unknown;
        access: unknown;
        integration: unknown;
        menu: unknown;
        needs: unknown;
        backend: unknown;
        effort: unknown;
        planner: unknown;
        /** Page id → contract AST. Null means the file was looked up and is absent. */
        contracts: Record<string, D1ContractAst | null>;
        /** Page id → contract source. Present when the file was read. */
        contractTexts?: Record<string, string>;
        presentDefs: D1PresentDef[];
        /**
         * Done write rows from the progress file of the step that wrote the def.
         * Not copied into the snapshot. Absent means this caller did not load them.
         */
        writerReceipts?: ReadonlyArray<{
            defPath: string;
            desiredHash: string;
        }>;
    }
    export interface D1PlannerRun {
        flowId: string;
        thread: string;
        round: number;
        schemaVersion: string;
    }
    export interface D1RequestOutput {
        key: string;
        entity: string;
        many: boolean;
        page?: string;
        pageSize?: string;
        hasMore?: string;
    }
    /** `field` filters `target`. `pages` names the list organism instead of a field. */
    export interface D1RequestParam {
        name: string;
        target: string;
        field?: string;
        pages?: string;
    }
    export interface D1SelectedRequest {
        route: string;
        pageId: string;
        kind: 'qry' | 'cmd';
        writes: string;
        outputs: D1RequestOutput[];
        params: D1RequestParam[];
        uses: string[];
    }
    export interface D1SelectedUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        status: D1ActiveStatus;
        existing: string;
        identity: string;
        routes: string[];
    }
    export interface D1SelectedPort {
        portId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1SelectedTable {
        tableId: string;
        entity: string;
        status: D1ActiveStatus;
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        action: D1FileAction;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
        /** Present only when this receipt inventoried the bytes at defPath. */
        contentHash?: string;
    }
    export interface D1RemovedItem {
        kind: string;
        id: string;
        defPath: string | null;
        inventoried: boolean;
        contentHash?: string;
    }
    export interface D1InputSnapshot {
        schemaVersion: typeof D1_INPUT_VERSION;
        project: number;
        moduleName: string;
        device: 'web';
        plannerRun: D1PlannerRun | null;
        sources: D1SourceDigest[];
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            requests: D1SelectedRequest[];
            usecases: D1SelectedUsecase[];
            ports: D1SelectedPort[];
            tables: D1SelectedTable[];
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
        removed: D1RemovedItem[];
        problems: D1InputProblem[];
        consumersReleased: boolean;
        snapshotHash: string;
    }
    export function inputPaths(moduleName: string): {
        module: string;
        journeyIndex: string;
        ontologyIndex: string;
        rules: string;
        workflows: string;
        access: string;
        integration: string;
        menu: string;
        needs: string;
        backend: string;
        effort: string;
        planner: string;
    };
    export function journeyPath(moduleName: string, journeyId: string): string;
    export function entityPath(moduleName: string, entityId: string): string;
    export function contractPath(moduleName: string, pageId: string): string;
    export function isSafeToken(value: string): boolean;
    export function lowerFirst(value: string): string;
}
declare module "_102021_/l2/helpers/l1Defs/definition" {
    /**
     * C0 contract for defs v2. Exclusive owner of this file: d1_30.
     *
     * d1_31 (writer/finalize), m1_01 (planner) and m1_04 (tests) import from here:
     *   /_102021_/l2/helpers/l1Defs/definition.js
     *
     * Does not import d1Artifact: d1_31 will import this module, and a reverse
     * runtime import would cycle. Business `data` keeps the D1 field names.
     */
    export const M1_DEFINITION_SCHEMA: "2026-09-24-d1-definition-v2";
    export const M1_RECEIPT_SCHEMA: "2026-09-24-m1-receipt-v1";
    export const D1_DEFINITION_SCHEMA_V1: "2026-09-21-d1-definition-v1";
    export const M1_STATUSES: readonly ["pending", "generated", "blocked", "failed"];
    export type M1Status = typeof M1_STATUSES[number];
    export const M1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export type M1ArtifactType = typeof M1_ARTIFACT_TYPES[number];
    export const M1_STAGES: readonly ["plan", "generate", "compile", "verify", "promote"];
    export type M1Stage = typeof M1_STAGES[number];
    export const M1_VERIFICATION_KINDS: readonly ["compile", "test", "schema", "hash"];
    export type M1VerificationKind = typeof M1_VERIFICATION_KINDS[number];
    /** Public names d1_31 must import. Do not duplicate these enums in agentDefsL1. */
    export const D1_31_IMPORT: "/_102021_/l2/helpers/l1Defs/definition.js";
    export const D1_31_EXPORTS: readonly ["M1_DEFINITION_SCHEMA", "M1_STATUSES", "M1_ARTIFACT_TYPES", "parseDefinitionSource", "renderDefinition", "definitionIssues", "canonicalProjection", "semanticHash", "referenceIssues", "traverseDefinitions", "statusEvidenceIssues", "generatedAllowsSkip", "receiptIssues", "receiptPathFor", "diagnoseUnit"];
    export interface M1Definition {
        schemaVersion: typeof M1_DEFINITION_SCHEMA;
        artifactType: M1ArtifactType;
        artifactId: string;
        moduleName: string;
        status: M1Status;
        dependencies: string[];
        data: Record<string, unknown>;
    }
    export interface M1Verification {
        id: string;
        kind: M1VerificationKind;
        passed: boolean;
        detail: string;
    }
    export interface M1ReceiptFailure {
        code: string;
        detail: string;
    }
    export interface MaterializationReceipt {
        schemaVersion: typeof M1_RECEIPT_SCHEMA;
        runId: string;
        candidateId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        recipeVersion: string;
        semanticHash: string;
        dependencyHashes: Record<string, string>;
        sourceHashes: Record<string, string>;
        outputHashes: Record<string, string>;
        stage: M1Stage;
        verifications: M1Verification[];
        failures: M1ReceiptFailure[];
        attempts: number;
        reason: string;
    }
    export interface KnownArtifact {
        artifactType: M1ArtifactType;
        artifactId: string;
        defPath: string;
    }
    export interface ReferenceIndex {
        files: readonly string[];
        artifacts: readonly KnownArtifact[];
    }
    export interface IndexedDefinition {
        defPath: string;
        definition: M1Definition;
    }
    export interface UnitDiagnosis {
        unitId: string;
        defPath: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        status: M1Status;
        stage: M1Stage;
        issues: string[];
        inputHash: string;
        outputHash: string;
    }
    export function isM1Status(value: string): value is M1Status;
    export function isM1ArtifactType(value: string): value is M1ArtifactType;
    export function isM1Stage(value: string): value is M1Stage;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function receiptFolder(moduleName: string): string;
    /**
     * Receipt file for one def. The def path is unique on disk; artifactId is not,
     * and a case-only difference is the same file. The base name has no extra dot.
     */
    export function receiptPathFor(defPath: string): string;
    export function outputPathFromDefPath(defPath: string): string;
    export function qualifiedFileIssues(path: string, field: string): string[];
    export function definitionIssues(value: unknown): string[];
    export function parseDefinitionSource(source: string): {
        definition: unknown;
    } | {
        issues: string[];
    };
    export function renderDefinition(definition: M1Definition, defPath: string): {
        source: string;
    } | {
        issues: string[];
    };
    export function readDefinition(value: unknown): M1Definition | {
        issues: string[];
    };
    export function canonicalProjection(definition: M1Definition): Record<string, unknown>;
    export function semanticHash(definition: M1Definition): Promise<string>;
    export function referenceIssues(definition: M1Definition, index: ReferenceIndex): string[];
    export function traverseDefinitions(units: readonly IndexedDefinition[], knownFiles?: readonly string[]): {
        order: string[];
        issues: string[];
    };
    export function receiptIssues(value: unknown): string[];
    export function statusEvidenceIssues(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<string[]>;
    export function generatedAllowsSkip(definition: M1Definition, receipt: MaterializationReceipt | null, currentDependencyHashes?: Readonly<Record<string, string>>): Promise<boolean>;
    export function diagnoseUnit(input: {
        defPath: string;
        definition: M1Definition;
        receipt?: MaterializationReceipt | null;
        index?: ReferenceIndex;
        stage?: M1Stage;
        currentDependencyHashes?: Readonly<Record<string, string>>;
    }): Promise<UnitDiagnosis>;
    /** Top-level `data` keys. d1_31 uses this list; agentDefsL1 does not keep a second copy. */
    export function dataAllowList(type: M1ArtifactType): readonly string[];
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Identity" {
    /**
     * Identity of a def file. A v2 definition hashes the semantic projection, so a
     * status edit is not a new source. Anything else hashes the raw text.
     */
    export function sourceIdentityHash(source: string): Promise<string>;
    /**
     * A receipt matches the disk when the bytes match, the semantic hash matches,
     * or the only difference is the status D1 would have written as pending.
     * An old receipt of the pending file must not look like SOURCE_CHANGED after
     * a legitimate status update.
     */
    export function hashesAgree(disk: string, receiptHash: string): Promise<boolean>;
    export function sha256Text(value: string): Promise<string>;
}
declare module "_102021_/l2/helpers/l1Defs/fixture" {
    /**
     * Certification fixture plan (m1_28). One shape, one producer, two readers:
     * - producer: D1 support70 `emitSeeds`, from `backend.json.testSupport[]` (p1_12, v1.2) and the
     *   local tables persistence40 planned; written as `data.fixture` of the persistenceSeeds def;
     * - readers: M1 `emitPersistence` (renders it as `certificationFixture`, apart from the product
     *   seeds) and the memory harness `testing/fixture.ts` (setup, cases, cleanup).
     * The plan holds no rows, no ids and no grants. Values are derived by the harness from the
     * entity defs and the contracts at execution time. A runtime-owned item keeps its gap here.
     */
    export const M1_FIXTURE_SCHEMA: "2026-09-27-m1-certification-fixture-v1";
    /** Declared destinations. `development` needs the runtime profile of execBFF; it is not run here. */
    export const M1_FIXTURE_TARGETS: readonly ["memory", "development"];
    export type M1FixtureTarget = typeof M1_FIXTURE_TARGETS[number];
    /** Module data the fixture creates, one per local table. */
    export interface M1FixtureDataset {
        supportId: string;
        entityId: string;
        tableId: string;
        /** Local datasets whose ids this one references. Created first, removed last. */
        dependsOn: string[];
        sourceRefs: string[];
    }
    /** Test identity or MDM data the runtime owns. L1 does not create it and does not invent it. */
    export interface M1FixtureRuntimeNeed {
        supportId: string;
        kind: 'identity' | 'mdm';
        entityId: string;
        actorRefs: string[];
        gap: string;
        owner: 'runtime';
    }
    export interface M1FixturePlan {
        schemaVersion: typeof M1_FIXTURE_SCHEMA;
        phase: 'plan';
        targets: M1FixtureTarget[];
        datasets: M1FixtureDataset[];
        runtime: M1FixtureRuntimeNeed[];
        /** testSupport items this plan could not place, with their reason. */
        gaps: string[];
    }
    /**
     * Plan from testSupport and the live local tables. Deterministic; `null` when there is no
     * testSupport (a v1.1 backend plan), so the def stays as before.
     */
    export function planFixture(testSupport: readonly unknown[] | undefined, tables: ReadonlyArray<{
        tableId: string;
        entityId: string;
    }>): M1FixturePlan | null;
    /** Reads `data.fixture` of a persistenceSeeds def. Anything else is refused with its issue. */
    export function readFixturePlan(value: unknown): M1FixturePlan | {
        issues: string[];
    };
    /** Parents before children; `null` on a cycle. */
    export function dependencyOrder(datasets: readonly M1FixtureDataset[]): M1FixtureDataset[] | null;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Artifact" {
    import { type M1ArtifactType, type M1Status } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1FixturePlan } from "_102021_/l2/helpers/l1Defs/fixture";
    export const D1_DEFINITION_SCHEMA: "2026-09-24-d1-definition-v2";
    export type { M1Status, M1Status as D1DefinitionStatus };
    /**
     * Measured on RequestContext.data.pgQueue. RequestContext itself has no publishEvent or emitEvent.
     * Postgres publish inserts into the MDM outbox. It is not a module bus.
     * The constant is evidence of the real API. It is not an approved integrationOutbound binding.
     */
    export const D1_MEASURED_PUBLISH: {
        readonly symbol: "IQueueRuntime.publish";
        readonly path: "mls-102034/l1/server/layer_1_external/data/runtime.ts";
        readonly owner: "RequestContext.data.pgQueue";
        readonly payload: "{ topic: string; payload: unknown }";
        readonly delivery: "Postgres insert into mdm_outbox. Memory keeps an array. No module consumer is registered.";
        readonly transaction: "Postgres publish uses the transaction executor. Memory runInTransaction does not roll back.";
    };
    /** Names that are not methods of RequestContext. Writing them would invent an API. */
    export function fictionalMechanism(value: string): boolean;
    export const D1_CATALOG_SCHEMA: "2026-09-21-d1-catalog-v1";
    /** Closed set. Same list as the v2 contract. Auxiliary names are not dispatched by agentChangeBackend. */
    export const D1_ARTIFACT_TYPES: readonly ["domainEntity", "valueObject", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export type D1ArtifactType = M1ArtifactType;
    /** Types readL1Inventory already filters on. */
    export const D1_INVENTORY_TYPES: readonly ["usecase", "repositoryPort", "table", "httpController"];
    /** Design forecast parts. Not a count of files this agent writes. */
    export const D1_CORE_TYPES: readonly ["domainEntity", "repositoryPort", "table", "repositoryAdapter", "usecase", "httpController", "requestService"];
    export const D1_AUXILIARY_TYPES: readonly ["valueObject", "accessScope", "authorityMap", "repositoryRegistration", "persistenceSeeds", "integrationOutbound"];
    export const D1_FORECAST_CORE: {
        readonly count: 26;
        readonly parts: {
            readonly domainEntity: 5;
            readonly repositoryPort: 1;
            readonly table: 1;
            readonly repositoryAdapter: 1;
            readonly usecase: 13;
            readonly httpController: 5;
        };
        readonly note: "Design forecast: 5 models, 1 port, 1 table, 1 adapter, 13 usecases and 5 controllers. It is not a count of files this agent generated.";
    };
    export const D1_STORAGE_TARGETS: readonly ["moduleDatabase", "mdm", "external", "derived"];
    export type D1StorageTarget = typeof D1_STORAGE_TARGETS[number];
    export interface D1Field {
        name: string;
        type: string;
        derived?: boolean;
        ref?: string;
    }
    export interface D1LifecycleState {
        state: string;
        reachedBy: 'actor' | 'command' | 'time';
    }
    export interface D1Transition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
    }
    export interface D1DomainEntityData {
        entityId: string;
        storageTarget: D1StorageTarget;
        fields: D1Field[];
        lifecycle: {
            states: D1LifecycleState[];
            transitions: D1Transition[];
        };
        invariants: string[];
        imports: string[];
    }
    export interface D1ValueObjectData {
        valueObjectId: string;
        fields: D1Field[];
        referencedBy: string[];
    }
    export interface D1PortMethod {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1RepositoryPortData {
        entityId: string;
        interfaceName: string;
        methods: D1PortMethod[];
    }
    export interface D1TableData {
        tableId: string;
        entityId: string;
        physicalName: string;
        primaryKey: string[];
        uniqueKeys: string[][];
        indexes: Array<{
            name: string;
            columns: string[];
            unique: boolean;
        }>;
    }
    export interface D1RepositoryAdapterData {
        entityId: string;
        portId: string;
        tableId: string;
        columns: Array<{
            field: string;
            column: string;
        }>;
    }
    export interface D1ProjectionField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface D1UsecaseData {
        usecaseId: string;
        entityId: string;
        operation: string;
        ports: string[];
        rulesApplied: string[];
        /** Present on defs written after applicability is planned. Older examples omit it. */
        rulePlan?: Array<{
            ruleId: string;
            origin: string;
            consumer: string;
            enforcement: 'local' | 'delegated' | 'pending';
            gap: string;
        }>;
        functions: Array<{
            functionName: string;
            input: D1ProjectionField[];
            output: D1ProjectionField[];
            contractRefs: Array<{
                route: string;
                symbol: string;
            }>;
        }>;
        routeProjections: Array<{
            route: string;
            contractPath: string;
            projection: 'declared' | 'unresolved';
            outputFields: string[];
        }>;
        portCalls: string[];
        transactional: boolean;
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        sequence: Array<Record<string, unknown>>;
        uses: Array<{
            path: string;
            role: 'filter' | 'selector' | 'concurrency' | 'write';
            source: 'input' | 'payload';
        }>;
        rules: Array<{
            ruleId: string;
            path: string;
            symbol: string;
        }>;
        transaction: {
            boundary: 'local' | 'none';
        };
        lifecycle?: {
            transitionId: string;
            payload: string[];
            sourcePath: string;
            symbol: string;
        };
        mdm?: {
            namespace: string;
            role: string;
            atomic: boolean;
            calls: Array<Record<string, unknown>>;
        };
    }
    export interface D1HttpHandlerV1 {
        route: string;
        kind: 'query' | 'command';
        usecaseId: string;
        grantIds: string[];
    }
    /** Adapter. Types are `<contractInterface>['<route>']['input'|'output']`. */
    export interface D1HttpHandlerAdapter {
        route: string;
        kind: 'query' | 'command';
        grantIds: string[];
        serviceFunction: string;
        contractPath: string;
        contractInterface: string;
    }
    export interface D1HttpControllerData {
        pageId: string;
        handlers: Array<D1HttpHandlerV1 | D1HttpHandlerAdapter>;
    }
    export interface D1AccessJoin {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Path of one entity of the grant. The anchor keeps empty steps. A missing field is this entity's pending only. */
    export interface D1EntityScopePath {
        entityId: string;
        steps: D1AccessJoin[];
        pending: string;
    }
    export interface D1Grant {
        grantId: string;
        actorRef: string;
        anchorEntity?: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields?: string[];
        /** Declared mode. own and organization stay distinct. Never a permissive fallback. */
        scopeMode: string;
        /** Subject comes from the verified session, never from a form field. */
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
    }
    export interface D1AccessScopeData {
        scopeId: string;
        grants: D1Grant[];
    }
    /** A serialized def plus the files it declares. Reconstruction does not read drafts. */
    export interface D1PolicyUnit {
        defPath: string;
        artifactType: string;
        data: unknown;
        dependencies: readonly string[];
    }
    export interface D1ReconstructedPolicy {
        route: string;
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: string;
        allowedFields: string[];
        anchorEntity: string;
        scopeMode: string;
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
        scopePath: string;
    }
    export interface D1AccessPolicyIssue {
        code: 'POLICY_UNBOUND';
        path: string;
        ownerRef: string;
        message: string;
    }
    export interface D1AuthorityMapData {
        mapId: string;
        entries: Array<{
            grantId: string;
            actorRef: string;
        }>;
    }
    export interface D1RegistrationData {
        registrationId: string;
        adapters: Array<{
            portId: string;
            adapterArtifactId: string;
        }>;
    }
    export interface D1SeedRefData {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDependencyData {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedDatasetData {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    /** A plan for the later materializer. `phase` is `plan`. This artifact has no rows. */
    export interface D1SeedsData {
        seedId: string;
        phase?: 'plan';
        scenarios: Array<{
            scenarioId: string;
            tableId: string;
            source?: string;
            constraints: string[];
            refs?: D1SeedRefData[];
            states?: string[];
            requires?: string[];
        }>;
        dependencies?: D1SeedDependencyData[];
        datasets?: D1SeedDatasetData[];
        /** Temporary certification data (m1_28), apart from the product seeds. No rows. */
        fixture?: M1FixturePlan;
    }
    export interface D1IntegrationData {
        integrationId: string;
        events: Array<{
            eventId: string;
            on: string;
            entityId: string;
            mechanism: string;
        }>;
    }
    export interface D1Definition<T = Record<string, unknown>> {
        schemaVersion: typeof D1_DEFINITION_SCHEMA;
        artifactType: D1ArtifactType;
        artifactId: string;
        moduleName: string;
        status: M1Status;
        dependencies: string[];
        data: T;
    }
    /** A new def is pending. The caller passes blocked when a concrete external gap is already known. */
    export function pendingDefinition<T extends Record<string, unknown>>(artifactType: D1ArtifactType, artifactId: string, moduleName: string, data: T, dependencies?: readonly string[], status?: M1Status): D1Definition<T>;
    export function isArtifactType(value: string): value is D1ArtifactType;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    /** Copies the shared $defs onto one artifact payload so a tool wrapper can hoist them. */
    export function typeDataSchema(definitionSchema: Record<string, unknown>, typeName: string): Record<string, unknown>;
    export function definitionIssues(value: unknown): string[];
    export function recordFieldIssues(data: unknown): string[];
    export function derivedFieldIssues(entity: unknown, usecases: readonly unknown[]): string[];
    export function storageTargetIssues(data: unknown): string[];
    export function lifecycleIssues(data: unknown): string[];
    export function domainImportIssues(moduleName: string, imports: readonly string[], source?: string): string[];
    export function domainEntityIssues(data: unknown): string[];
    export function valueObjectIssues(data: unknown): string[];
    export function repositoryPortIssues(data: unknown): string[];
    export function tableIssues(data: unknown): string[];
    /**
     * artifactId is the logical table id. The inventory reads the entity from data.entityId.
     */
    export function tableIdentityIssues(data: unknown, artifactId: string): string[];
    export function adapterBindingIssues(data: unknown): string[];
    export function adapterLinkIssues(adapter: unknown, port: unknown, table: unknown): string[];
    export function projectionIssues(data: unknown): string[];
    export function routeProjectionIssues(data: unknown): string[];
    export function usecaseIssues(data: unknown): string[];
    /** The unique-key line. It is not a business rule, so `ruleId` stays empty. */
    export function isStorageConstraintRow(row: {
        ruleId: string;
        origin: string;
        consumer: string;
        enforcement: string;
        gap: string;
    }): boolean;
    export function requestServiceIssues(data: unknown): string[];
    export function httpControllerIssues(data: unknown): string[];
    export function accessAnchorIssues(data: unknown): string[];
    export function accessScopeIssues(data: unknown): string[];
    /**
     * Rebuilds each handler grant from serialized defs and declared file dependencies.
     * A scope reached through an intermediate def counts. Drafts are not an input.
     */
    export function reconstructAccessPolicy(units: readonly D1PolicyUnit[]): {
        policies: D1ReconstructedPolicy[];
        issues: D1AccessPolicyIssue[];
    };
    export function authorityMapIssues(data: unknown): string[];
    export function authorityGrantIssues(map: unknown, scope: unknown): string[];
    export function registrationIssues(data: unknown): string[];
    export function seedScenarioIssues(data: unknown): string[];
    /** Processes, inbound and plugins stay operations. A gap is a declared item the pool did not select. */
    export function integrationCoverageIssues(data: unknown): string[];
    /** Empty mechanism is reported and the event is left in place. The MDM queue is not a binding. */
    export function integrationMechanismIssues(data: unknown): string[];
    /** Domain imports are checked with the definition's module, not an empty string. */
    export function definitionImportIssues(value: unknown, source?: string): string[];
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Refs" {
    import { D1_CATALOG_SCHEMA, D1_FORECAST_CORE, type D1ArtifactType, type D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    export const D1_OUTPUT_AVAILABILITY: readonly ["future", "present"];
    export type D1OutputAvailability = typeof D1_OUTPUT_AVAILABILITY[number];
    /** What each type may depend on. A usecase must not depend on the registry or the adapter. */
    export const DEPENDS_ALLOWED: Record<D1ArtifactType, readonly D1ArtifactType[]>;
    export interface D1PipelineItem {
        id: string;
        type: D1ArtifactType;
        defPath: string;
        outputPath: string;
        outputAvailability: D1OutputAvailability;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        routes?: string[];
    }
    export interface D1Justification {
        id: string;
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Absence {
        artifactType: D1ArtifactType;
        reason: string;
    }
    export interface D1Catalog {
        schemaVersion: typeof D1_CATALOG_SCHEMA;
        project: number;
        moduleName: string;
        items: D1PipelineItem[];
        presentPaths: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
    }
    export interface D1PlannedFile {
        id: string;
        artifactType: string;
        defPath: string;
        identity: string;
        ownerRefs: string[];
        dependsOn: string[];
    }
    export interface D1MeasuredPlan {
        project: number;
        moduleName: string;
        selection: {
            pages: Array<{
                pageId: string;
                routes: string[];
            }>;
            /**
             * Debt for `examples/agendaClinicaExamples.ts`, which still indexes this.
             * No D1 reader fills it. The snapshot from input20 does not have this field.
             */
            routes: Array<{
                route: string;
                page: string;
                kind: string;
                usecaseRef: string;
            }>;
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                routes: string[];
            }>;
            ports: Array<{
                portId: string;
                entity: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
            }>;
            entities: string[];
            outbound: string[];
        };
        files: D1PlannedFile[];
    }
    export interface D1RefFinding {
        path: string;
        kind: 'presentDef' | 'plannedDef' | 'futureOutput' | 'missingInput' | 'uncontractedDeclaration';
        producerId?: string;
    }
    export interface D1Coverage {
        measured: Record<string, number>;
        measuredCore: number;
        forecastCore: typeof D1_FORECAST_CORE.count;
        forecastNote: typeof D1_FORECAST_CORE.note;
        forecastMatchesMeasured: boolean;
        auxiliaries: D1Justification[];
        absences: D1Absence[];
        futureOutputs: string[];
        missingInputs: string[];
        gaps: string[];
    }
    export function pipelineId(project: number, moduleName: string, type: string, owner: string): string;
    export function qualifyDefPath(project: number, logicalPath: string): string;
    export function futureOutputPath(defPath: string): string;
    export function skillPaths(type: string): string[];
    export function catalogFromPlan(plan: D1MeasuredPlan, input: {
        presentPaths?: string[];
        justifications: D1Justification[];
        absences: D1Absence[];
        skillsFor?: (type: string) => string[];
    }): D1Catalog;
    export function pipelineItemIssues(value: unknown, project?: number, moduleName?: string): string[];
    export function skillRefIssues(items: readonly {
        skills?: unknown;
    }[], knownSkills: readonly string[]): string[];
    export function duplicateRouteIssues(items: readonly {
        id: string;
        routes?: string[];
    }[]): string[];
    export function catalogIssues(value: unknown, knownSkills?: readonly string[]): string[];
    export function graphIssues(items: readonly D1PipelineItem[]): string[];
    export function cycleIssues(items: readonly {
        id: string;
        dependsOn: string[];
    }[]): string[];
    export function resolveCatalogRefs(catalog: D1Catalog): D1RefFinding[];
    export function coverageReport(catalog: D1Catalog, plan: D1MeasuredPlan, storageByEntity: Readonly<Record<string, D1StorageTarget>>): D1Coverage;
    export function effectCoverageIssues(usecases: readonly {
        effects?: Array<{
            eventId: string;
        }>;
    }[], events: readonly string[]): string[];
    export function integrationLinkIssues(events: readonly {
        eventId: string;
        on: string;
        consumer?: string;
    }[], usecaseIds: readonly string[]): string[];
    /**
     * Schema property path → the function that reads it.
     * A new field without an entry here has no reader and must not be added.
     */
    export const D1_FIELD_READERS: {
        readonly 'definition.schemaVersion': "definitionIssues";
        readonly 'definition.artifactType': "definitionIssues";
        readonly 'definition.artifactId': "definitionIssues";
        readonly 'definition.moduleName': "definitionIssues";
        readonly 'definition.status': "definitionIssues";
        readonly 'definition.dependencies': "definitionIssues";
        readonly 'definition.data': "definitionIssues";
        readonly 'domainEntity.entityId': "domainEntityIssues";
        readonly 'domainEntity.storageTarget': "storageTargetIssues";
        readonly 'domainEntity.fields': "domainEntityIssues";
        readonly 'domainEntity.fields.name': "domainEntityIssues";
        readonly 'domainEntity.fields.type': "domainEntityIssues";
        readonly 'domainEntity.fields.derived': "derivedFieldIssues";
        readonly 'domainEntity.fields.ref': "recordFieldIssues";
        readonly 'domainEntity.lifecycle': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.state': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.states.reachedBy': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.transitionId': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.from': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.to': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.by': "lifecycleIssues";
        readonly 'domainEntity.lifecycle.transitions.ruleRefs': "lifecycleIssues";
        readonly 'domainEntity.invariants': "domainEntityIssues";
        readonly 'domainEntity.imports': "domainImportIssues";
        readonly 'valueObject.valueObjectId': "valueObjectIssues";
        readonly 'valueObject.fields': "valueObjectIssues";
        readonly 'valueObject.fields.name': "valueObjectIssues";
        readonly 'valueObject.fields.type': "valueObjectIssues";
        readonly 'valueObject.fields.derived': "derivedFieldIssues";
        readonly 'valueObject.fields.ref': "recordFieldIssues";
        readonly 'valueObject.referencedBy': "valueObjectIssues";
        readonly 'repositoryPort.entityId': "repositoryPortIssues";
        readonly 'repositoryPort.interfaceName': "repositoryPortIssues";
        readonly 'repositoryPort.methods': "repositoryPortIssues";
        readonly 'repositoryPort.methods.name': "repositoryPortIssues";
        readonly 'repositoryPort.methods.params': "repositoryPortIssues";
        readonly 'repositoryPort.methods.returns': "repositoryPortIssues";
        readonly 'table.tableId': "tableIssues";
        readonly 'table.entityId': "tableIdentityIssues";
        readonly 'table.physicalName': "tableIssues";
        readonly 'table.primaryKey': "tableIssues";
        readonly 'table.uniqueKeys': "tableIssues";
        readonly 'table.indexes': "tableIssues";
        readonly 'table.indexes.name': "tableIssues";
        readonly 'table.indexes.columns': "tableIssues";
        readonly 'table.indexes.unique': "tableIssues";
        readonly 'repositoryAdapter.entityId': "adapterBindingIssues";
        readonly 'repositoryAdapter.portId': "adapterLinkIssues";
        readonly 'repositoryAdapter.tableId': "adapterLinkIssues";
        readonly 'repositoryAdapter.columns': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.field': "adapterBindingIssues";
        readonly 'repositoryAdapter.columns.column': "adapterBindingIssues";
        readonly 'usecase.usecaseId': "usecaseIssues";
        readonly 'usecase.entityId': "usecaseIssues";
        readonly 'usecase.operation': "usecaseIssues";
        readonly 'usecase.ports': "usecaseIssues";
        readonly 'usecase.rulesApplied': "usecaseIssues";
        readonly 'usecase.rulePlan': "readUsecaseFidelity";
        readonly 'usecase.rulePlan.ruleId': "readUsecaseFidelity";
        readonly 'usecase.rulePlan.origin': "readUsecaseFidelity";
        readonly 'usecase.rulePlan.consumer': "readUsecaseFidelity";
        readonly 'usecase.rulePlan.enforcement': "readUsecaseFidelity";
        readonly 'usecase.rulePlan.gap': "readUsecaseFidelity";
        readonly 'usecase.functions': "usecaseIssues";
        readonly 'usecase.functions.functionName': "usecaseIssues";
        readonly 'usecase.functions.input': "projectionIssues";
        readonly 'usecase.functions.input.name': "projectionIssues";
        readonly 'usecase.functions.input.type': "projectionIssues";
        readonly 'usecase.functions.input.fieldRef': "projectionIssues";
        readonly 'usecase.functions.output': "projectionIssues";
        readonly 'usecase.functions.output.name': "projectionIssues";
        readonly 'usecase.functions.output.type': "projectionIssues";
        readonly 'usecase.functions.output.fieldRef': "projectionIssues";
        readonly 'usecase.functions.contractRefs': "routeProjectionIssues";
        readonly 'usecase.functions.contractRefs.route': "routeProjectionIssues";
        readonly 'usecase.functions.contractRefs.symbol': "routeProjectionIssues";
        readonly 'usecase.routeProjections': "routeProjectionIssues";
        readonly 'usecase.routeProjections.route': "routeProjectionIssues";
        readonly 'usecase.routeProjections.contractPath': "routeProjectionIssues";
        readonly 'usecase.routeProjections.projection': "routeProjectionIssues";
        readonly 'usecase.routeProjections.outputFields': "routeProjectionIssues";
        readonly 'usecase.portCalls': "usecaseIssues";
        readonly 'usecase.transactional': "usecaseIssues";
        readonly 'usecase.effects': "usecaseIssues";
        readonly 'usecase.effects.eventId': "effectCoverageIssues";
        readonly 'usecase.effects.path': "readUsecaseFidelity";
        readonly 'usecase.effects.symbol': "readUsecaseFidelity";
        readonly 'usecase.sequence': "readUsecaseFidelity";
        readonly 'usecase.sequence.kind': "readUsecaseFidelity";
        readonly 'usecase.sequence.call': "readUsecaseFidelity";
        readonly 'usecase.sequence.port': "readUsecaseFidelity";
        readonly 'usecase.sequence.ruleId': "readUsecaseFidelity";
        readonly 'usecase.sequence.namespace': "readUsecaseFidelity";
        readonly 'usecase.sequence.entity': "readUsecaseFidelity";
        readonly 'usecase.sequence.capability': "readUsecaseFidelity";
        readonly 'usecase.sequence.transitionId': "readUsecaseFidelity";
        readonly 'usecase.sequence.payload': "readUsecaseFidelity";
        readonly 'usecase.sequence.eventId': "readUsecaseFidelity";
        readonly 'usecase.sequence.boundary': "readUsecaseFidelity";
        readonly 'usecase.sequence.source': "readUsecaseFidelity";
        readonly 'usecase.uses': "readUsecaseFidelity";
        readonly 'usecase.uses.path': "readUsecaseFidelity";
        readonly 'usecase.uses.role': "readUsecaseFidelity";
        readonly 'usecase.uses.source': "readUsecaseFidelity";
        readonly 'usecase.rules': "readUsecaseFidelity";
        readonly 'usecase.rules.ruleId': "readUsecaseFidelity";
        readonly 'usecase.rules.path': "readUsecaseFidelity";
        readonly 'usecase.rules.symbol': "readUsecaseFidelity";
        readonly 'usecase.transaction': "readUsecaseFidelity";
        readonly 'usecase.transaction.boundary': "readUsecaseFidelity";
        readonly 'usecase.lifecycle': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.transitionId': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.payload': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.sourcePath': "readUsecaseFidelity";
        readonly 'usecase.lifecycle.symbol': "readUsecaseFidelity";
        readonly 'usecase.mdm': "readUsecaseFidelity";
        readonly 'usecase.mdm.namespace': "readUsecaseFidelity";
        readonly 'usecase.mdm.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.atomic': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.method': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.target': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.shape': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.capabilities': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.alternative': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.name': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.role': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.capability': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.id': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.kind': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.call': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.when.present': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.value': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.kind': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.path': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.calls': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.arguments.origin.evidence': "readUsecaseFidelity";
        readonly 'usecase.mdm.calls.result': "readUsecaseFidelity";
        readonly 'httpController.pageId': "httpControllerIssues";
        readonly 'httpController.handlers': "httpControllerIssues";
        readonly 'httpController.handlers.route': "httpControllerIssues";
        readonly 'httpController.handlers.kind': "httpControllerIssues";
        readonly 'httpController.handlers.usecaseId': "httpControllerIssues";
        readonly 'httpController.handlers.grantIds': "httpControllerIssues";
        readonly 'requestService.pageId': "requestServiceIssues";
        readonly 'requestService.requests': "requestServiceIssues";
        readonly 'requestService.requests.route': "requestServiceIssues";
        readonly 'requestService.requests.kind': "requestServiceIssues";
        readonly 'requestService.requests.uses': "requestServiceIssues";
        readonly 'requestService.requests.transaction': "requestServiceIssues";
        readonly 'requestService.requests.outputs': "requestServiceIssues";
        readonly 'requestService.requests.outputs.key': "requestServiceIssues";
        readonly 'requestService.requests.outputs.entity': "requestServiceIssues";
        readonly 'requestService.requests.outputs.fields': "requestServiceIssues";
        readonly 'requestService.requests.params': "requestServiceIssues";
        readonly 'requestService.requests.params.name': "requestServiceIssues";
        readonly 'requestService.requests.params.target': "requestServiceIssues";
        readonly 'requestService.requests.params.field': "requestServiceIssues";
        readonly 'requestService.requests.params.pages': "requestServiceIssues";
        readonly 'accessScope.scopeId': "accessScopeIssues";
        readonly 'accessScope.grants': "accessScopeIssues";
        readonly 'accessScope.grants.grantId': "accessScopeIssues";
        readonly 'accessScope.grants.actorRef': "accessScopeIssues";
        readonly 'accessScope.grants.anchorEntity': "accessAnchorIssues";
        readonly 'accessScope.grants.entityRefs': "accessAnchorIssues";
        readonly 'accessScope.grants.disclosure': "accessScopeIssues";
        readonly 'accessScope.grants.allowedFields': "accessScopeIssues";
        readonly 'accessScope.grants.scopeMode': "accessScopeIssues";
        readonly 'accessScope.grants.session': "accessScopeIssues";
        readonly 'accessScope.grants.path': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.entityId': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.relationshipId': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.from': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.to': "reconstructAccessPolicy";
        readonly 'accessScope.grants.path.steps.field': "accessScopeIssues";
        readonly 'accessScope.grants.path.pending': "accessScopeIssues";
        readonly 'accessScope.grants.pending': "accessScopeIssues";
        readonly 'authorityMap.mapId': "authorityMapIssues";
        readonly 'authorityMap.entries': "authorityMapIssues";
        readonly 'authorityMap.entries.grantId': "authorityGrantIssues";
        readonly 'authorityMap.entries.actorRef': "authorityMapIssues";
        readonly 'repositoryRegistration.registrationId': "registrationIssues";
        readonly 'repositoryRegistration.adapters': "registrationIssues";
        readonly 'repositoryRegistration.adapters.portId': "registrationIssues";
        readonly 'repositoryRegistration.adapters.adapterArtifactId': "registrationIssues";
        readonly 'persistenceSeeds.seedId': "seedScenarioIssues";
        readonly 'persistenceSeeds.phase': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.scenarioId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.source': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.constraints': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.field': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.relationshipId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.refs.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.states': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.requires': "seedScenarioIssues";
        readonly 'persistenceSeeds.scenarios.entityId': "seedUses";
        readonly 'persistenceSeeds.scenarios.stateField': "seedUses";
        readonly 'persistenceSeeds.dependencies': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.entityId': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.kind': "seedScenarioIssues";
        readonly 'persistenceSeeds.dependencies.seeded': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.datasetId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.tableId': "seedScenarioIssues";
        readonly 'persistenceSeeds.datasets.owners': "seedScenarioIssues";
        readonly 'integrationOutbound.integrationId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.eventId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.on': "integrationLinkIssues";
        readonly 'integrationOutbound.events.entityId': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.mechanism': "integrationMechanismIssues";
        readonly 'integrationOutbound.events.consumer': "integrationLinkIssues";
        readonly 'integrationOutbound.events.mechanismRef': "integrationMechanismIssues";
        readonly 'integrationOutbound.processes': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.processId': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.processes.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.inboundId': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.inbound.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.pluginId': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.operations': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.mechanism': "integrationCoverageIssues";
        readonly 'integrationOutbound.plugins.consumer': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.itemId': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.kind': "integrationCoverageIssues";
        readonly 'integrationOutbound.gaps.code': "integrationCoverageIssues";
        readonly 'pipelineItem.id': "pipelineItemIssues";
        readonly 'pipelineItem.type': "pipelineItemIssues";
        readonly 'pipelineItem.defPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputPath': "resolveCatalogRefs";
        readonly 'pipelineItem.outputAvailability': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsFiles': "resolveCatalogRefs";
        readonly 'pipelineItem.dependsOn': "catalogIssues";
        readonly 'pipelineItem.skills': "skillRefIssues";
        readonly 'pipelineItem.routes': "duplicateRouteIssues";
        readonly 'catalog.schemaVersion': "coverageReport";
        readonly 'catalog.project': "coverageReport";
        readonly 'catalog.moduleName': "coverageReport";
        readonly 'catalog.items': "coverageReport";
        readonly 'catalog.presentPaths': "resolveCatalogRefs";
        readonly 'catalog.justifications': "coverageReport";
        readonly 'catalog.justifications.id': "coverageReport";
        readonly 'catalog.justifications.artifactType': "coverageReport";
        readonly 'catalog.justifications.reason': "coverageReport";
        readonly 'catalog.absences': "coverageReport";
        readonly 'catalog.absences.artifactType': "coverageReport";
        readonly 'catalog.absences.reason': "coverageReport";
    };
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Write" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    export interface D1Rendered {
        source: string;
        file: D1FileInfo;
    }
    /**
     * The file identity of a def. Qualified `_project_/l1/...` and logical `l1/...`
     * both go through fileInfoFromDisplay, which is the same parser input20 uses.
     */
    export function artifactFile(project: number, defPath: string): D1FileInfo | null;
    /**
     * Reads the v2 definition. A pipeline or agent export is refused: null, not a
     * silent drop of the second value.
     */
    export function parseRendered(source: string): {
        definition: unknown;
    } | null;
    /**
     * Definition object even when a legacy pipeline export follows it.
     * The pipeline export stays illegal. Callers that need v2 use parseRendered.
     */
    export function readDefinitionExport(source: string): {
        definition: unknown;
        pipelineExport: boolean;
    } | null;
    /** Paths a file declares. v2 uses definition.dependencies. A legacy export's dependsFiles is only a fallback. */
    export function declaredDependencyPaths(source: string): string[];
    /**
     * Files the def actually consumes. Qualified `_NNNNN_/lN/...`, sorted, unique.
     * A logical `lN/...` path is qualified with this project. `mls-NNNNN/...` keeps
     * the project named in the path. A fragment after `#` is not a file.
     */
    export function consumedDependencies(project: number, paths: readonly string[]): string[];
    export function qualifyConsumed(project: number, path: string): string;
    /** Copies consumed files onto the definition. Skills and output paths stay out of the file. */
    export function stampDefinition(definition: D1Definition, defPath: string, paths: readonly string[]): D1Definition;
    /**
     * Renders one v2 defs file. No pipeline export. Issues keep the value intact.
     */
    export function renderDefinition(definition: D1Definition, defPath: string): {
        source: string;
    } | {
        issues: string[];
    };
    export function collisionIssues(defPaths: readonly string[]): string[];
    /**
     * Gate then write. A collision or a definition issue writes nothing.
     * The file passed to writeText is artifactFile, the same identity a later remove must use.
     */
    export function persistDefinitions(project: number, parts: readonly {
        definition: D1Definition;
        defPath: string;
    }[]): Promise<{
        written: D1FileInfo[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1Receipt" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export const D1_PROGRESS_SCHEMA: "2026-09-22-d1-progress-v1";
    export interface D1WriterReceipt {
        defPath: string;
        desiredHash: string;
    }
    export interface D1UnitPart {
        defPath: string;
        source: string;
        action?: 'write' | 'remove';
        /** Inventoried hash. Empty when this file has no receipt. */
        receiptHash?: string;
        outputTs?: readonly string[];
        /** Present when the def status is blocked. Written beside the def, not inside it. */
        blockReason?: string;
    }
    export interface D1FileProgress {
        defPath: string;
        action: 'write' | 'remove';
        previousHash: string;
        desiredHash: string;
        status: 'pending' | 'done' | 'conflict';
        outputTs: string[];
    }
    /**
     * Recovery record for one unit. `transaction` is false because stor has no
     * multi-file transaction and no compare-and-swap. mtime is not a version.
     */
    export interface D1UnitProgress {
        schemaVersion: typeof D1_PROGRESS_SCHEMA;
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        runId: string;
        snapshotHash: string;
        draftHash: string;
        transaction: false;
        finalized: boolean;
        invalidated: boolean;
        reported: string[];
        files: D1FileProgress[];
        issues: string[];
    }
    export interface D1CommitUnitInput {
        project: number;
        moduleName: string;
        step: string;
        unitId: string;
        draftText: string;
        parts: readonly D1UnitPart[];
        runId?: string;
        snapshotHash?: string;
        /** Test seam. Throws after this many product mutations. */
        failAfterMutations?: number;
        /** Test seam. Runs immediately before the hash is read again. */
        beforeMutate?: (index: number) => Promise<void>;
    }
    export interface D1CommitUnitResult {
        written: string[];
        removed: string[];
        reported: string[];
        issues: string[];
        finalized: boolean;
        invalidated: boolean;
    }
    export interface D1FingerprintEntry {
        key: string;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        hidden: boolean;
        sha256: string;
        mtime: string;
        status: string;
    }
    export function progressFile(project: number, moduleName: string, step: string, unitId: string): D1FileInfo;
    export function logicalDefPath(defPath: string): string;
    /**
     * True only when every product file of this unit still matches the progress
     * hashes. A checkpoint status of completed is not read and is not proof.
     */
    export function unitIsIntact(project: number, moduleName: string, step: string, unitId: string, snapshotHash: string): Promise<boolean>;
    export function commitD1Unit(input: D1CommitUnitInput): Promise<D1CommitUnitResult>;
    /** Every file in this project, including hidden names. mtime is recorded, not trusted. */
    export function fingerprintProject(project: number): Promise<D1FingerprintEntry[]>;
    /**
     * Paths whose bytes, mtime or status changed outside `l1/<module>` product
     * defs and `l1/<module>/pipeline/agentDefsL1`. The planner pipeline is outside.
     */
    export function outsideOwnedWrites(before: readonly D1FingerprintEntry[], after: readonly D1FingerprintEntry[], moduleName: string): string[];
    export function readWriterReceipts(project: number, moduleName: string): Promise<D1WriterReceipt[]>;
}
declare module "_102020_/l2/helpers/contractV2/types" {
    export interface D2ContractV2Location {
        project: number;
        module: string;
        pageId: string;
    }
    export interface D2ContractV2Projection {
        name: string;
        entityId: string;
        requestIds: string[];
        body: string;
    }
    export interface D2ContractV2MetaOutput {
        entity: string;
        many: boolean;
    }
    export interface D2ContractV2MetaList {
        key: string;
        page: string;
        pageSize: string;
        hasMore: string;
    }
    export interface D2ContractV2MetaParamFilter {
        filters: string;
        field: string;
    }
    export interface D2ContractV2MetaParamPage {
        pages: string;
    }
    export type D2ContractV2MetaParam = D2ContractV2MetaParamFilter | D2ContractV2MetaParamPage;
    export interface D2ContractV2Meta {
        output: Record<string, D2ContractV2MetaOutput>;
        lists: Record<string, D2ContractV2MetaList>;
        params: Record<string, D2ContractV2MetaParam>;
    }
    export interface D2ContractV2Route {
        route: string;
        kind: 'qry' | 'cmd';
        writes?: string;
        input: string;
        output: string;
        meta: D2ContractV2Meta;
        rules: string[];
        access: {
            actors: string[];
            grants: string[];
            scope: string;
        };
    }
    export interface D2ContractV2Definition {
        module: string;
        pageId: string;
        projections: D2ContractV2Projection[];
        routes: D2ContractV2Route[];
    }
}
declare module "_102020_/l2/helpers/contractV2/render" {
    import type { D2ContractV2Definition, D2ContractV2Location } from "_102020_/l2/helpers/contractV2/types";
    export function renderD2ContractV2(location: D2ContractV2Location, definition: D2ContractV2Definition): string;
    export function parseD2ContractV2(source: string): D2ContractV2Definition;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/gate" {
    import { type D1ActiveStatus, type D1InputArtifacts, type D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export function buildD1InputSnapshot(identity: {
        project: number;
        moduleName: string;
    }, artifacts: D1InputArtifacts, previous: D1InputSnapshot | null): D1InputSnapshot;
    export function contractPageIds(artifacts: Pick<D1InputArtifacts, 'menu' | 'needs' | 'effort' | 'backend'>): string[];
    /** `toCreate` over `toUpdate` over `done`. controllers60 applies it per handler. */
    export function worstOfList(statuses: readonly D1ActiveStatus[]): D1ActiveStatus;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /** Reads the object of `export const name = { ... }` without evaluating the file. */
    export function parseD1Source(text: string, kind: 'json' | 'defs'): unknown | null;
    export function readD1Input(project: number, moduleName: string): Promise<D1InputSnapshot | null>;
    /** Reads the snapshot inputs and returns the inventory. Writes nothing. */
    export function assembleD1Input(project: number, moduleName: string): Promise<D1InputSnapshot>;
    export function persistD1Input(project: number, moduleName: string, snapshot: D1InputSnapshot): Promise<{
        reused: boolean;
    }>;
    export function fileInfoFromDisplay(project: number, display: string): D1FileInfo | null;
    export function sha256Text(value: string): Promise<string>;
    export function ownedInputDisplay(project: number, moduleName: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/input20/agentD1Input" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1InputPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_DOMAIN_VERSION: "2026-09-21-d1-domain-v1";
    export const D1_DOMAIN_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export type D1DomainAction = typeof D1_DOMAIN_ACTIONS[number];
    export type D1RulePlacement = 'invariant' | 'application' | 'platform';
    export interface D1DomainFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1DomainTableRef {
        tableId: string;
        entity: string;
    }
    /** The slice of the input20 inventory this step reads. Matching is by exact id. */
    export interface D1DomainSelection {
        entities: string[];
        files: D1DomainFile[];
        tables: D1DomainTableRef[];
    }
    export interface D1DomainProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1Normalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1PlacedRule {
        ruleId: string;
        owner: 'module' | 'platform';
        /** Module artifact, or the catalog path the entity source names. Spelling is the citation. */
        source: string;
        placement: D1RulePlacement;
    }
    export interface D1Enumeration {
        path: string;
        values: string[];
    }
    export interface D1DomainEntityPlan {
        entityId: string;
        action: string;
        defPath: string;
        storageTarget: string;
        emitsLocalPersistence: false;
        derivedInitial: string | null;
        uniqueKeys: string[][];
        enumerations: D1Enumeration[];
        rules: D1PlacedRule[];
        definition: D1Definition | null;
    }
    export interface D1DomainValuePlan {
        valueObjectId: string;
        defPath: string;
        referencedBy: string[];
        definition: D1Definition | null;
    }
    export interface D1DomainEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1DomainBuild {
        schemaVersion: typeof D1_DOMAIN_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        entities: D1DomainEntityPlan[];
        valueObjects: D1DomainValuePlan[];
        problems: D1DomainProblem[];
        normalizations: D1Normalization[];
        preserved: string[];
        removed: string[];
        emit: D1DomainEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/gate" {
    import { type D1DomainBuild, type D1DomainSelection } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export interface D1DomainRequest {
        project: number;
        moduleName: string;
        selection: D1DomainSelection;
        /** Ontology bodies keyed by entityId. A filename is not an identity. */
        entities: Record<string, unknown>;
        ontologyIndex: unknown;
        /** Module rules artifact. Keys are matched exactly. */
        rules: unknown;
        /** Catalog document keyed by the entity `source` string. Absent means unread. */
        catalogs: Record<string, unknown>;
    }
    /**
     * One deterministic pass from the L4 record tree to domain defs.
     * No model, no eval, and no NS4 field list is rewritten into this tree.
     */
    export function buildD1Domain(request: D1DomainRequest): D1DomainBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import { type D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export function assembleD1Domain(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1DomainBuild;
    }>;
    export function commitD1Domain(project: number, build: D1DomainBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A catalog may live in another project. `..` and a short name with a dot are refused. */
    export function catalogInfo(source: string): D1FileInfo | null;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1DomainPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/contracts" {
    import type { D1Definition, D1PortMethod } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1DomainBuild } from "_102021_/l2/agentDefsL1/steps/domain30/contracts";
    export const D1_PERSISTENCE_VERSION: "2026-09-21-d1-persistence-v1";
    /** Prefix for a logical field stored in the runtime `details` JSONB column. One writer, reversible. */
    export const D1_JSON_COLUMN_PREFIX: "json:";
    /** Runtime JSONB column name. Not derived per table and not snake-cased. */
    export const D1_DETAILS_COLUMN: "details";
    export const D1_PERSISTENCE_ACTIONS: readonly ["create", "update", "recompose", "preserve", "remove", "conflict"];
    export const ENUMERATION_REASON: "Table and adapter schemas have no enum values. They stay on the domain draft.";
    export interface D1PersistenceFile {
        artifactType: string;
        identity: string;
        defPath: string;
        action: string;
    }
    export interface D1PersistenceProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1PersistenceNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ColumnBinding {
        field: string;
        column: string;
        nullable: boolean;
        placement: 'column' | 'json';
    }
    /** Enum values read from the domain draft and not copied onto a table or adapter. */
    export interface D1UnconsumedEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: 'domain30.enumerations';
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UniqueKeyUse {
        entityId: string;
        tableId: string | null;
        uniqueKeys: string[][];
        consumed: boolean;
        /** Where a consumed key was written, or why it was not. */
        placedOn: string;
    }
    export interface D1PersistencePortPlan {
        portId: string;
        entityId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceTablePlan {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        physicalName: string;
        /** Runtime JSONB column, or null when every field is a real column. */
        detailsColumn: string | null;
        definition: D1Definition | null;
    }
    export interface D1PersistenceAdapterPlan {
        portId: string;
        entityId: string;
        tableId: string;
        action: string;
        defPath: string;
        methods: D1PortMethod[];
        bindings: D1ColumnBinding[];
        definition: D1Definition | null;
    }
    export interface D1PersistenceEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1PersistenceBuild {
        schemaVersion: typeof D1_PERSISTENCE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1UnconsumedEnumeration[];
        uniqueKeys: D1UniqueKeyUse[];
        ports: D1PersistencePortPlan[];
        tables: D1PersistenceTablePlan[];
        adapters: D1PersistenceAdapterPlan[];
        problems: D1PersistenceProblem[];
        normalizations: D1PersistenceNormalization[];
        preserved: string[];
        removed: string[];
        emit: D1PersistenceEmit[];
    }
    export interface D1PersistenceRequest {
        project: number;
        moduleName: string;
        selection: {
            ports: Array<{
                portId: string;
                entity: string;
                status: string;
            }>;
            tables: Array<{
                tableId: string;
                entity: string;
                status: string;
            }>;
            usecases: Array<{
                usecaseId: string;
                entity: string;
                operation: string;
                status: string;
            }>;
            files: D1PersistenceFile[];
        };
        domain: D1DomainBuild;
        entities: Record<string, unknown>;
        /** Preserved port bytes keyed by defPath. The value is the definition object. */
        preservedPorts: Record<string, unknown>;
        /** Extra physical names that must equal `storage.table`. Keyed by entity id. */
        physicalCitations: Record<string, string[]>;
        /** Catalog paths this step opened and did not write. */
        catalogsRead: string[];
    }
    /** Logical field encoded by one column string. `json:` marks the details envelope. */
    export function fieldFromColumn(column: string): string;
    export function columnForField(field: string, placement: 'column' | 'json'): string;
    /** Names required by the port and missing from the adapter. */
    export function uncoveredMethods(required: readonly string[], implemented: readonly string[]): string[];
    /** A binding round-trips when each column string decodes to its own field and no column is shared. */
    export function bindingRoundTripIssues(bindings: readonly D1ColumnBinding[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1PersistenceBuild, type D1PersistenceRequest } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    /**
     * One deterministic pass from the domain draft and the L4 record to ports, tables and adapters.
     * No model. Physical names are `storage.table` verbatim. Nothing is snake-cased or pluralized.
     */
    export function buildD1Persistence(request: D1PersistenceRequest): D1PersistenceBuild;
    /** A port file must not depend on an adapter. The check is the application side of the hexagon. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/io" {
    import type { D1PersistenceBuild } from "_102021_/l2/agentDefsL1/steps/persistence40/contracts";
    export function assembleD1Persistence(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1PersistenceBuild;
    }>;
    export function commitD1Persistence(project: number, build: D1PersistenceBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1PersistencePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102034_/l4/ontology/mdm.defs" {
    export const mdm: {
        readonly schemaVersion: "2026-09-15-mdm-ontology-v2";
        readonly record: {
            readonly fields: {
                readonly id: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly derived: true;
                    readonly indexed: true;
                    readonly description: "mdmId; stable through promotion and merge.";
                };
                readonly version: {
                    readonly type: "integer";
                    readonly required: true;
                    readonly derived: true;
                    readonly writePrecondition: true;
                    readonly description: "Bumped by the engine on every write; optimistic concurrency.";
                };
                readonly details: {
                    readonly type: "object";
                    readonly required: true;
                    readonly groups: readonly ["identification", "base", "<subtype>", "general", "<moduleId>"];
                    readonly description: "The JSONB document, as a map of groups (see groups).";
                };
            };
            readonly displayField: "identification.name";
        };
        readonly groups: {
            readonly identification: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "Also columns of the index table; that is what makes them filterable and sortable. A field earns a column only when something has to filter or sort by it.";
                readonly fields: {
                    readonly subtype: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Person", "Company", "ContactChannel", "Animal", "Product", "Service", "Location", "BankAccount", "Document", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
                        readonly description: "Which subtype this record is; it decides which subtype branch the document carries.";
                    };
                    readonly name: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 200;
                        readonly description: "How a human recognises the record. The only text filter there is.";
                    };
                    readonly status: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                        readonly values: readonly ["Active", "Inactive", "Merged", "Blocked"];
                    };
                    readonly docType: {
                        readonly type: "enum";
                        readonly indexed: true;
                        readonly values: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
                    };
                    readonly docId: {
                        readonly type: "string";
                        readonly indexed: true;
                        readonly description: "The document number itself. Unique with docType by design; the unique index does not exist yet, see knownDivergences.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly required: true;
                        readonly indexed: true;
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly default: "US";
                        readonly description: "ISO 3166-1 alpha-2. Says which country the document and the legal rules belong to.";
                    };
                    readonly tags: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Module roles, as <moduleId>.<Entity>. Written by attachRole; this is how a module says the record is one of its own. A column with no index.";
                    };
                    readonly mergedInto: {
                        readonly type: "string";
                        readonly derived: true;
                        readonly description: "On the loser of a merge, the mdmId of the winner. A column with no index.";
                    };
                    readonly createdAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                    readonly updatedAt: {
                        readonly type: "string";
                        readonly required: true;
                        readonly derived: true;
                        readonly indexed: true;
                    };
                };
            };
            readonly base: {
                readonly type: "object";
                readonly owner: "platform";
                readonly description: "What every record has, whatever its subtype, and which nothing filters by.";
                readonly fields: {
                    readonly moduleTypes: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly derived: true;
                        readonly description: "The module roles again, kept for the engine and duplicating tags. Not a field for a reader; read tags.";
                    };
                    readonly aliases: {
                        readonly type: "string";
                        readonly collection: true;
                        readonly required: true;
                        readonly description: "Other names the same subject answers to: trade name, maiden name, nickname.";
                    };
                    readonly addresses: {
                        readonly type: "object";
                        readonly of: "Address";
                        readonly collection: true;
                        readonly required: true;
                    };
                    readonly contacts: {
                        readonly type: "object";
                        readonly of: "ContactSummary";
                        readonly collection: true;
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "Summary of the ContactChannel records linked by HasContact. A contact is a record, never a string on this one.";
                    };
                    readonly relationshipRefs: {
                        readonly type: "object";
                        readonly required: true;
                        readonly derived: true;
                        readonly description: "The compact keys the engine recomputes on every link and unlink. The key set is relationships[].compactKeys — it is not repeated here, and it is never written by hand.";
                    };
                    readonly notes: {
                        readonly type: "string";
                        readonly maxLength: 1000;
                    };
                };
            };
            readonly general: {
                readonly type: "object";
                readonly owner: "organization";
                readonly open: true;
                readonly description: "Fields promoted by the organization when more than one module needed them; the schema lives in the project registry, so a module reads this branch and does not declare it.";
            };
            readonly "<moduleId>": {
                readonly type: "object";
                readonly owner: "module";
                readonly open: true;
                readonly description: "One key per module id — Record<moduleId, object>. Only that module writes it (MDM_FOREIGN_NAMESPACE otherwise); other modules see the key by name. Never identity, document, contact or login. Example: \"agendaClinica\": { \"prontuario\": \"PR-000123\" } — its schema is the module's own ontology (Paciente.defs.ts).";
            };
        };
        readonly types: {
            readonly Address: {
                readonly type: {
                    readonly type: "enum";
                    readonly required: true;
                    readonly values: readonly ["Residential", "Commercial", "Billing", "Delivery", "Other"];
                };
                readonly label: {
                    readonly type: "string";
                };
                readonly line1: {
                    readonly type: "string";
                    readonly required: true;
                };
                readonly line2: {
                    readonly type: "string";
                };
                readonly line3: {
                    readonly type: "string";
                };
                readonly city: {
                    readonly type: "string";
                };
                readonly stateOrProvince: {
                    readonly type: "string";
                    readonly description: "State, province, prefecture or canton. In the US, the 2-letter code.";
                };
                readonly postalCode: {
                    readonly type: "string";
                    readonly description: "ZIP, postcode, CEP, PIN. The format varies by country and the platform does not enforce one.";
                };
                readonly countryCode: {
                    readonly type: "string";
                    readonly required: true;
                    readonly maxLength: 2;
                    readonly pattern: "^[A-Z]{2}$";
                    readonly default: "US";
                    readonly description: "ISO 3166-1 alpha-2. Drives how the address is formatted on screen.";
                };
                readonly formatted: {
                    readonly type: "string";
                    readonly derived: true;
                    readonly description: "The whole address on one line, as it would appear on an envelope. Built asynchronously.";
                };
                readonly geolocation: {
                    readonly type: "object";
                    readonly of: "GeoPoint";
                };
                readonly isPrimary: {
                    readonly type: "boolean";
                    readonly required: true;
                };
            };
            readonly GeoPoint: {
                readonly lat: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -90;
                    readonly max: 90;
                };
                readonly lng: {
                    readonly type: "number";
                    readonly required: true;
                    readonly min: -180;
                    readonly max: 180;
                };
            };
            readonly PrivacyConsent: {
                readonly consentedAt: {
                    readonly type: "timestamp";
                    readonly required: true;
                };
                readonly consentVersion: {
                    readonly type: "string";
                    readonly required: true;
                };
                readonly channel: {
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Where the consent was given: web form, paper, phone.";
                };
                readonly revokedAt: {
                    readonly type: "timestamp";
                };
                readonly notes: {
                    readonly type: "string";
                };
            };
            readonly ContactSummary: {
                readonly mdmId: {
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "The ContactChannel record itself.";
                };
                readonly title: {
                    readonly type: "string";
                    readonly required: true;
                };
            };
        };
        readonly subtypes: {
            readonly Person: {
                readonly description: "Natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly gender: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "NonBinary", "NotDisclosed"];
                    };
                    readonly nationality: {
                        readonly type: "string";
                        readonly maxLength: 2;
                        readonly pattern: "^[A-Z]{2}$";
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string";
                        readonly maxLength: 120;
                    };
                    readonly photoUrl: {
                        readonly type: "string";
                    };
                    readonly privacyConsent: {
                        readonly type: "object";
                        readonly of: "PrivacyConsent";
                        readonly description: "Required for residents of Brazil (LGPD) and the EU (GDPR).";
                    };
                };
                readonly capabilities: readonly ["locate.byLogin", "invite.login", "export.personalData", "anonymize"];
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Corporations, LLCs, nonprofits, government entities — and the internal structures of any of them.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["LegalEntity", "Branch", "Franchise", "BusinessUnit", "Group", "Team", "Department", "InternalOrg"];
                        readonly description: "Tells a legal entity apart from an internal structure.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Official registered name.";
                    };
                    readonly tradeName: {
                        readonly type: "string";
                        readonly description: "DBA name. Also goes into aliases, so the text filter finds it.";
                    };
                    readonly legalType: {
                        readonly type: "enum";
                        readonly values: readonly ["Corporation", "LLC", "SoleProp", "Partnership", "Nonprofit", "Government", "Other"];
                    };
                    readonly parentCompanyId: {
                        readonly type: "record";
                        readonly to: readonly ["Company"];
                        readonly description: "Parent in an organizational tree. The link itself is BelongsToGroup, PartOfUnit or SubsidiaryOf.";
                    };
                    readonly externalCode: {
                        readonly type: "string";
                        readonly description: "ERP, HR or legacy code used by the consuming modules.";
                    };
                    readonly foundingDate: {
                        readonly type: "date";
                    };
                    readonly taxRegime: {
                        readonly type: "string";
                        readonly description: "Country-specific tax class: S-Corp and C-Corp in the US, Simples Nacional in Brazil.";
                    };
                    readonly industryCode: {
                        readonly type: "string";
                        readonly description: "NAICS in the US, CNAE in Brazil, or the local equivalent.";
                    };
                    readonly website: {
                        readonly type: "string";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly ContactChannel: {
                readonly description: "A phone, e-mail or social handle as a record of its own, so it can be traced, verified and shared.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Phone", "Email", "WhatsApp", "Instagram", "LinkedIn", "X", "Other"];
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The contact itself, stored unmasked.";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
            readonly Animal: {
                readonly description: "Pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string";
                    };
                    readonly breed: {
                        readonly type: "string";
                    };
                    readonly birthDate: {
                        readonly type: "date";
                    };
                    readonly sex: {
                        readonly type: "enum";
                        readonly values: readonly ["Male", "Female", "Unknown"];
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly microchip: {
                        readonly type: "string";
                    };
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Breed registry, USDA tag, or official animal id.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly Product: {
                readonly description: "An inventory or catalog item that can be bought, stocked, sold or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string";
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "enum";
                        readonly values: readonly ["Physical", "Digital", "Bundle", "Consumable", "Other"];
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string";
                        readonly description: "unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly description: "True when stock is tracked by location.";
                    };
                };
            };
            readonly Service: {
                readonly description: "A reusable service or offering that can be sold, scheduled, taught or assigned to a place. Courses are services too.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string";
                    };
                    readonly serviceKind: {
                        readonly type: "enum";
                        readonly values: readonly ["Service", "Course", "Cohort", "Subscription", "AppointmentType"];
                        readonly description: "Cohort is a concrete instance of a course.";
                    };
                    readonly serviceType: {
                        readonly type: "enum";
                        readonly values: readonly ["Course", "Consulting", "Maintenance", "Appointment", "Subscription", "Other"];
                    };
                    readonly parentServiceId: {
                        readonly type: "record";
                        readonly to: readonly ["Service"];
                        readonly description: "The base service, when this one is a cohort or a derived offering.";
                    };
                    readonly durationMinutes: {
                        readonly type: "number";
                    };
                    readonly deliveryMode: {
                        readonly type: "enum";
                        readonly values: readonly ["Onsite", "Remote", "Hybrid", "Other"];
                    };
                };
            };
            readonly Location: {
                readonly description: "A physical place used for stock or for delivering a service: room, warehouse, campus, store, branch, shelf.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Room", "Warehouse", "Building", "Campus", "Store", "Office", "Shelf", "Other"];
                    };
                    readonly locationCode: {
                        readonly type: "string";
                    };
                    readonly parentLocationId: {
                        readonly type: "record";
                        readonly to: readonly ["Location"];
                        readonly description: "The larger place this one belongs to.";
                    };
                    readonly capacity: {
                        readonly type: "number";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Routing data only. Balances and transactions belong to the finance module, never here.";
                readonly fields: {
                    readonly bankName: {
                        readonly type: "string";
                    };
                    readonly bankRoutingNumber: {
                        readonly type: "string";
                        readonly description: "ABA routing number in the US; use swift for international.";
                    };
                    readonly accountNumber: {
                        readonly type: "string";
                    };
                    readonly accountType: {
                        readonly type: "enum";
                        readonly values: readonly ["Checking", "Savings", "MoneyMarket", "Payment", "Other"];
                    };
                    readonly swift: {
                        readonly type: "string";
                        readonly description: "BIC/SWIFT, for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string";
                    };
                    readonly pixKey: {
                        readonly type: "string";
                    };
                    readonly pixKeyType: {
                        readonly type: "enum";
                        readonly values: readonly ["CPF", "CNPJ", "Phone", "Email", "RandomKey"];
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly required: true;
                        readonly description: "Verified by micro-deposit, open banking or manual review.";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "An indexed reference to an external file. The file itself never lives in the MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "The module that created this record.";
                    };
                    readonly docCategory: {
                        readonly type: "enum";
                        readonly required: true;
                        readonly values: readonly ["Contract", "Certificate", "IdDocument", "Invoice", "Receipt", "Report", "Photo", "Other"];
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "S3 bucket, or its equivalent, holding the file.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly required: true;
                        readonly description: "Path inside the bucket. Never rewritten after creation.";
                    };
                    readonly fileName: {
                        readonly type: "string";
                        readonly required: true;
                    };
                    readonly mimeType: {
                        readonly type: "string";
                    };
                    readonly fileSizeKb: {
                        readonly type: "number";
                    };
                    readonly issuedAt: {
                        readonly type: "date";
                    };
                    readonly expiresAt: {
                        readonly type: "date";
                    };
                    readonly issuer: {
                        readonly type: "string";
                        readonly description: "Name of the issuing authority, as free text. Not an mdmId.";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly AssetGeneric: {
                readonly description: "The fallback asset, for what does not fit vehicle, property or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string";
                        readonly description: "furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly manufacturer: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string";
                    };
                    readonly vin: {
                        readonly type: "string";
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly year: {
                        readonly type: "integer";
                    };
                    readonly color: {
                        readonly type: "string";
                    };
                    readonly fuelType: {
                        readonly type: "enum";
                        readonly values: readonly ["Gasoline", "Diesel", "Electric", "Hybrid", "Flex", "Other"];
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Real estate: residential, commercial, rural or industrial.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string";
                        readonly description: "Deed number, cadastral reference, or the local equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "object";
                        readonly of: "Address";
                    };
                    readonly propertyType: {
                        readonly type: "enum";
                        readonly values: readonly ["Residential", "Commercial", "Rural", "UrbanLot", "Industrial", "Other"];
                    };
                    readonly areaSqft: {
                        readonly type: "number";
                        readonly description: "Area in square feet; the primary unit in the US.";
                    };
                    readonly areaM2: {
                        readonly type: "number";
                        readonly description: "Area in square meters, outside the US.";
                    };
                    readonly taxParcelId: {
                        readonly type: "string";
                        readonly description: "Tax parcel or assessor id in the US, or the local equivalent.";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string";
                    };
                    readonly brand: {
                        readonly type: "string";
                    };
                    readonly model: {
                        readonly type: "string";
                    };
                    readonly category: {
                        readonly type: "string";
                    };
                    readonly acquisitionDate: {
                        readonly type: "date";
                    };
                };
            };
        };
        readonly relationships: readonly [{
            readonly type: "Owns";
            readonly title: "Owns";
            readonly description: "A person or a company owns an asset · metadata: since, ownershipPct";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["ownedAssets"];
                readonly to: readonly ["owners"];
            };
        }, {
            readonly type: "Employs";
            readonly title: "Employs";
            readonly description: "A company employs a person · metadata: role, department, startDate";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["employee", "contractor", "intern"];
            readonly compactKeys: {
                readonly from: readonly ["employees"];
                readonly to: readonly ["employers"];
            };
        }, {
            readonly type: "OffersProduct";
            readonly title: "Offers product";
            readonly description: "A company puts a product in its catalog · metadata: since, supplierSku";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredProducts"];
                readonly to: readonly ["productSuppliers"];
            };
        }, {
            readonly type: "OffersService";
            readonly title: "Offers service";
            readonly description: "A company or a person offers a service · metadata: since, priceTable";
            readonly from: readonly ["Company", "Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["offeredServices"];
                readonly to: readonly ["serviceProviders"];
            };
        }, {
            readonly type: "StocksAt";
            readonly title: "Stocks at";
            readonly description: "A product or a piece of equipment is stocked at a place · metadata: quantity, unit, minLevel";
            readonly from: readonly ["Product", "AssetEquipment"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["stockLocations"];
                readonly to: readonly ["stockedItems"];
            };
        }, {
            readonly type: "Teaches";
            readonly title: "Teaches";
            readonly description: "A person teaches a service or a course · metadata: role, since";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["primary-instructor", "assistant-instructor", "substitute"];
            readonly compactKeys: {
                readonly from: readonly ["taughtServices"];
                readonly to: readonly ["instructors"];
            };
        }, {
            readonly type: "HappensAt";
            readonly title: "Happens at";
            readonly description: "A service is delivered at a place · metadata: scheduleLabel, weekday";
            readonly from: readonly ["Service"];
            readonly to: readonly ["Location"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["serviceLocations"];
                readonly to: readonly ["scheduledServices"];
            };
        }, {
            readonly type: "FranchiseOf";
            readonly title: "Franchise of";
            readonly description: "A company operates as a franchise of another · metadata: contractId, territory";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["franchisors"];
                readonly to: readonly ["franchisees"];
            };
        }, {
            readonly type: "BelongsToGroup";
            readonly title: "Belongs to group";
            readonly description: "A company belongs to an economic group · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["subsidiary-brand"];
            readonly compactKeys: {
                readonly from: readonly ["groupParents"];
                readonly to: readonly ["groupMembers"];
            };
        }, {
            readonly type: "PartOfUnit";
            readonly title: "Part of unit";
            readonly description: "An internal structure belongs to a larger one · metadata: role";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["department", "team", "branch-unit"];
            readonly compactKeys: {
                readonly from: readonly ["unitParents"];
                readonly to: readonly ["unitChildren"];
            };
        }, {
            readonly type: "ManagedBy";
            readonly title: "Managed by";
            readonly description: "A person runs a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["manager", "coordinator"];
            readonly compactKeys: {
                readonly from: readonly ["managedOrganizations"];
                readonly to: readonly ["managers"];
            };
        }, {
            readonly type: "ReportsTo";
            readonly title: "Reports to";
            readonly description: "A person reports to another person · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: false;
            readonly roles: readonly ["direct-report", "manager"];
            readonly compactKeys: {
                readonly from: readonly ["reportManagers"];
                readonly to: readonly ["reports"];
            };
        }, {
            readonly type: "AssignedTo";
            readonly title: "Assigned to";
            readonly description: "A person is assigned to a company or a service · metadata: role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company", "Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["member", "assistant", "instructor"];
            readonly compactKeys: {
                readonly from: readonly ["assignments"];
                readonly to: readonly ["assignees"];
            };
        }, {
            readonly type: "Attends";
            readonly title: "Attends";
            readonly description: "A person attends a service or a course · metadata: attendanceStatus";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Service"];
            readonly bidirectional: false;
            readonly roles: readonly ["enrolled", "completed"];
            readonly compactKeys: {
                readonly from: readonly ["attendedServices"];
                readonly to: readonly ["attendees"];
            };
        }, {
            readonly type: "SuppliesProduct";
            readonly title: "Supplies product";
            readonly description: "A company supplies a product · metadata: leadTimeDays, catalogCode";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Product"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliedProducts"];
                readonly to: readonly ["productVendors"];
            };
        }, {
            readonly type: "PartnersWith";
            readonly title: "Partners with";
            readonly description: "A person is a partner in a company · metadata: equityPct, role";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["managing-partner", "silent-partner"];
            readonly compactKeys: {
                readonly from: readonly ["partners"];
                readonly to: readonly ["partners"];
            };
        }, {
            readonly type: "Family";
            readonly title: "Family";
            readonly description: "Kinship between two people, read the same way from either side · metadata: degree. An emergency contact is this link with role emergency";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person"];
            readonly bidirectional: true;
            readonly roles: readonly ["spouse", "child", "parent", "sibling", "emergency"];
            readonly compactKeys: {
                readonly from: readonly ["family"];
                readonly to: readonly ["family"];
            };
        }, {
            readonly type: "GuardianOf";
            readonly title: "Guardian of";
            readonly description: "A person answers for another person or for an animal · metadata: since, guardianType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Person", "Animal"];
            readonly bidirectional: false;
            readonly roles: readonly ["parent", "guardian", "owner", "foster"];
            readonly compactKeys: {
                readonly from: readonly ["pets"];
                readonly to: readonly ["guardians"];
            };
        }, {
            readonly type: "CustomerOf";
            readonly title: "Customer of";
            readonly description: "A person or a company buys from a company · metadata: since, segment";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["suppliers"];
                readonly to: readonly ["customers"];
            };
        }, {
            readonly type: "SupplierOf";
            readonly title: "Supplier of";
            readonly description: "A company supplies another company · metadata: category, contractMdmId";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["customers"];
                readonly to: readonly ["suppliers"];
            };
        }, {
            readonly type: "MemberOf";
            readonly title: "Member of";
            readonly description: "A person is a member of a company or an association · metadata: role, membershipType";
            readonly from: readonly ["Person"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["board-member", "honorary"];
            readonly compactKeys: {
                readonly from: readonly ["memberships"];
                readonly to: readonly ["members"];
            };
        }, {
            readonly type: "HoldsAccount";
            readonly title: "Holds account";
            readonly description: "A person or a company holds a bank account · metadata: isPrimary, since";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["BankAccount"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["bankAccounts"];
                readonly to: readonly ["accountHolders"];
            };
        }, {
            readonly type: "SubsidiaryOf";
            readonly title: "Subsidiary of";
            readonly description: "A company is a subsidiary of another · metadata: equityPct, type";
            readonly from: readonly ["Company"];
            readonly to: readonly ["Company"];
            readonly bidirectional: false;
            readonly roles: readonly ["wholly-owned", "affiliate"];
            readonly compactKeys: {
                readonly from: readonly ["parentCompanies"];
                readonly to: readonly ["subsidiaries"];
            };
        }, {
            readonly type: "LocatedAt";
            readonly title: "Located at";
            readonly description: "A person or a company sits at a property · metadata: locationType";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["AssetProperty"];
            readonly bidirectional: false;
            readonly roles: readonly ["headquarters", "branch", "warehouse"];
            readonly compactKeys: {
                readonly from: readonly ["locations"];
                readonly to: readonly ["locatedEntities"];
            };
        }, {
            readonly type: "Signed";
            readonly title: "Signed";
            readonly description: "A person or a company signed a document · metadata: role";
            readonly from: readonly ["Person", "Company"];
            readonly to: readonly ["Document"];
            readonly bidirectional: false;
            readonly roles: readonly ["contractor", "client", "witness", "notary"];
            readonly compactKeys: {
                readonly from: readonly ["documents"];
                readonly to: readonly ["signedBy"];
            };
        }, {
            readonly type: "HasContact";
            readonly title: "Has contact";
            readonly description: "Any record owns a contact channel; this is what fills base.contacts · metadata: isPrimary";
            readonly from: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
            readonly to: readonly ["ContactChannel"];
            readonly bidirectional: false;
            readonly roles: readonly [];
            readonly compactKeys: {
                readonly from: readonly ["contacts"];
                readonly to: readonly ["contactOwners"];
            };
        }];
        readonly capabilities: {
            readonly "read.byId": "Reads one record, or a handful at once, when the id is already known · get, getMany and hydrateMany over the index plus the document store, O(1) each · any screen that already holds the mdmId, and every list that has to fill in the records it points at · platform: ready";
            readonly "locate.byName": "Finds records whose name contains the typed text, anywhere in the string · listByType narrows by subtype and status in the index table and then matches the name in memory; aliases are not consulted and there is no default page size · anyone looking a record up · platform: partial";
            readonly "locate.byDocument": "Finds the single record that holds a national document (CPF, CNPJ, SSN, EIN) · findByDocument loads the index and filters in JS · whoever registers, to deduplicate before creating · platform: partial";
            readonly "locate.byContact": "Finds the record that owns a phone, WhatsApp handle or e-mail · findByContact loads every ContactChannel record · whoever answers an inbound call or message · platform: partial";
            readonly "locate.byLogin": "Finds the person behind a login e-mail · mdm_tag row with namespace login, partial unique index on (namespace, tag, module) · the session resolver · platform: ready";
            readonly "locate.byTag": "Finds every record carrying a given label — which is how a secondary key works here · mdm.tag.findByTag, over the index idx_mdm_tag_lookup on (entityType, tag, module); the `namespace` column keeps one key space apart from another, and the login e-mail of locate.byLogin is nothing but the namespace 'login' · a module that has to find a record by a code of its own, such as a chart or a badge number · platform: ready";
            readonly "locate.semantic": "Finds a record through a misspelling, a phonetic match or half a name · would need a trigram or tsvector index, or embeddings; searchVector is TEXT compared literally · reception, when the spelling is uncertain · platform: missing";
            readonly "locate.byDocumentField": "Filters or sorts by something that lives only in the document, such as birth month, city or any module field · would need that field promoted to an index column, or a GIN index on details; for a key the module itself controls, locate.byTag already answers without any of that · marketing and reporting · platform: missing";
            readonly "register.createOrAttach": "Creates the record when it does not exist and, either way, marks it with the module role · locate.byDocument, create when absent, then attachRole writes details[moduleId], the tag, the audit row and the recomputed compact refs · whoever registers · platform: ready";
            readonly "register.asProspect": "Records an interested party who has no document yet, and promotes it later · prospect.create with promotionSource and ttlExpiresAt, then promoteToEntity keeping the same mdmId · reception and the public site · platform: ready";
            readonly "edit.platformFields": "Changes the name, document, addresses, consent and the other fields the platform owns · entity.update; touching an identification field also rewrites the index row · whoever maintains the record · platform: partial";
            readonly "edit.moduleNamespace": "Changes only details[moduleId], which is what this module knows about the record · attachRole or update carrying the module key; any other module key is refused · the module itself · platform: ready";
            readonly inactivate: "Takes the record out of use without deleting it · status Active to Inactive, and reactivate undoes it · whoever maintains the record · platform: partial";
            readonly merge: "Joins two records that are the same subject, the loser pointing at the winner · mergeEntity sets status Merged and mergedInto, but the facade neither exports nor routes it · an administrator · platform: missing";
            readonly delete: "Removes the record physically, and is refused while an active relationship exists · entity.delete, error MDM_DELETE_BLOCKED_BY_RELATIONSHIPS · an administrator · platform: ready";
            readonly link: "Creates a versioned relationship, with a role, between two permanent records · link(from, to, type, role); the engine recomputes the compact keys on both sides · whoever maintains the record · platform: ready";
            readonly unlink: "Closes a relationship while keeping its history · unlink sets status Inactive; the row is never deleted · whoever maintains the record · platform: ready";
            readonly "link.contact": "Adds a phone, WhatsApp handle or e-mail that belongs to this record · create a ContactChannel record and link it with HasContact; the engine fills relationshipRefs.contacts · whoever maintains the record · platform: ready";
            readonly listLinks: "Shows the related records, with their validity and role · relationship.list and relatedOfMany · the record screen · platform: ready";
            readonly "attach.document": "Stores a photo, a scan or a signed document against the record, by category · upload to S3 or local disk, a row in mdm_attachment, presigned GET · whoever maintains the record · platform: partial";
            readonly comment: "Leaves a note on the record, with one level of reply and a 15-minute edit window · mdm_comment anchored by entityType, entityId and module · whoever maintains the record · platform: ready";
            readonly tag: "Marks the record with free labels inside the module namespace · mdm_tag, unique on (entityType, entityId, tag, module) · whoever maintains the record · platform: ready";
            readonly "sequence.next": "Issues the next number of a counter, such as a record or order number · mdm_number_sequence with SELECT … FOR UPDATE, key {module}.{entityType}.{scope} · the module, on create · platform: ready";
            readonly "config.kv": "Keeps a small piece of JSON configuration that more than one module reads · mdm.kv.get and mdm.kv.put over mdm_kv, a shared table keyed by one `key` column — no per-record scope, no history and no module column · a module that needs a setting the others also read · platform: ready";
            readonly "statusHistory.read": "Shows when the record changed status and who changed it · mdm_status_history · the record screen · platform: partial";
            readonly audit: "Says who changed what, and when · mdm_audit_log, insert only · an administrator · platform: partial";
            readonly "invite.login": "Gives the person a login so they can see their own data · identity.invite writes the mdm_tag login row and calls collab-auth · whoever maintains the record · platform: ready";
            readonly "export.personalData": "Hands the subject their own data on request (LGPD art. 18, GDPR art. 15) · would need the document, the links and the attachments in a single export · an administrator · platform: missing";
            readonly anonymize: "Erases the personal data while keeping the record for statistics · would pseudonymize the identification keeping the mdmId · an administrator · platform: missing";
        };
        readonly rules: {
            readonly "rule-person-ssn-unique-for-us": "Two permanent people in the US must not share the same SSN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-person-privacy-consent-required-br-eu": "A person living in Brazil or the EU without a valid privacy consent is forced to Inactive · engine · platform: ready";
            readonly "rule-company-ein-unique-for-us": "Two permanent companies in the US must not share the same EIN · engine · platform: partial, because the unique index does not exist";
            readonly "rule-company-legal-name-required": "A company record is refused without a legalName · engine · platform: ready";
            readonly "rule-contact-value-unique-per-type": "Two contact channels must not share the same contactType and value · engine · platform: partial";
            readonly "rule-bank-account-routing-required-for-us": "A US bank account is refused without a bankRoutingNumber · engine · platform: ready";
            readonly "rule-bank-account-holder-via-relationship": "Who holds a bank account is the HoldsAccount link, never a field of the account · engine · platform: ready";
            readonly "rule-document-parties-via-relationships": "Who signed a document is the Signed link, never a field of the document · engine · platform: ready";
            readonly "rule-document-path-immutable": "Once stored, the storage key of a document is never rewritten · engine · platform: ready";
            readonly "rule-foreign-namespace-refused": "A caller carrying a moduleId may write the platform keys, general and its own key; any other module key is refused with MDM_FOREIGN_NAMESPACE · engine · platform: ready";
            readonly "rule-delete-blocked-by-relationships": "A physical delete is refused while an active relationship exists · engine · platform: ready";
            readonly "rule-document-shape-validated": "Addresses, consent, general and the module namespace are validated on write against the schema derived from this ontology · engine · platform: missing, nothing validates the document today";
            readonly "rule-identity-never-in-namespace": "Identity, document, contact and login are platform layers; a module never redeclares them inside details[moduleId] · engine · platform: partial";
        };
        readonly statuses: readonly ["Active", "Inactive", "Merged", "Blocked"];
        readonly docTypes: readonly ["SSN", "EIN", "Passport", "DriversLicense", "NationalId", "CPF", "CNPJ", "VAT", "Other"];
        readonly storage: {
            readonly indexTable: "mdm_documents_entities_index";
            readonly prospectIndexTable: "mdm_documents_prospects_index";
            readonly documentTable: "mdm_documents";
            readonly documentColumn: "details";
            readonly indexedColumns: readonly ["subtype", "name", "status", "docType", "docId", "countryCode", "createdAt", "updatedAt"];
            readonly reservedKeys: readonly ["identification", "base", "general", "<subtype>", "<moduleId>"];
        };
        readonly knownDivergences: {
            readonly "grouped-document": "The branches of this file are the target. The engine writes and reads a FLAT document today, so identification, base and the subtype branch are all one level.";
            readonly "contacts-written-from-input": "base.contacts is declared derived from HasContact and the engine still writes it raw from the input, duplicating relationshipRefs.contacts.";
            readonly "module-types-duplicates-tags": "base.moduleTypes and identification.tags carry the same module roles. tags is the one with a column; moduleTypes is kept for the engine and should disappear.";
            readonly "doc-unique-missing": "UNIQUE(docType, docId) is promised in defs/ontology.ts and absent from persistence.ts, so the two uniqueness rules are only partly enforced.";
            readonly "privacy-consent-value": "PrivacyConsent (data) and PrivacyConsentValue (interface) declare different fields; the same is true of Address and ContactSummary.";
            readonly "compact-relationship-refs-count": "CompactRelationshipRefs has 22 keys in the data and 48 in the interface; the interface is the real one.";
            readonly "search-vector-type": "searchVector is documented as tsvector and created as TEXT, compared literally, which is why locate.semantic is missing.";
            readonly "relationship-documents-table": "Table mdm_relationship_documents is cited and does not exist.";
            readonly "service-defs-case": "The JSON service definitions use PascalCase where the columns are camelCase.";
            readonly "platform-detail-keys-copy": "The list of platform keys exists twice, in mdmFacade.ts and integration.ts, with different contents.";
            readonly "emergency-contact-type": "There is no EmergencyContactOf type; a Family link with role emergency carries that meaning.";
            readonly "subtype-enum-narrowed": "identification.subtype is declared here with the 13 values; the engine narrows it per subtype, so a Person record only ever carries \"Person\".";
            readonly "index-only-columns": "The index table also has searchVector and dynamoPk, which are engine internals and no field of the document; one of the 9 indexes is on dynamoPk, which is why indexedColumns lists 8.";
        };
    };
    export default mdm;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export const D1_USECASE_VERSION: "2026-10-01-d1-usecases-v2";
    /** Same trail as persistence40. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Usecase projection has no values slot. Enum values stay on the domain draft.";
    export const D1_WORKER_KINDS: readonly ["port", "rule", "mdm", "transition", "effect", "transaction", "context"];
    /**
     * Facade methods a plan may name. `read` and `attach` are not methods:
     * a point read, a collection read and a platform-field update are different calls.
     * The tool offers only the methods the operation's binding names. This list stays
     * the facade, so a manipulated reply can still be recognized and refused.
     */
    export const D1_MDM_CALLS: readonly ["get", "findByDocument", "findByContact", "listByType", "relatedOfMany", "create", "attachRole", "update", "inactivate", "reactivate", "link", "invite"];
    export type D1MdmCall = (typeof D1_MDM_CALLS)[number];
    export const D1_WRITE_CALLS: readonly ["create", "update", "transition", "delete"];
    export interface D1UsecaseProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1UsecaseNormalization {
        code: string;
        path: string;
        detail: string;
    }
    /** Domain enum values cited by path and not copied onto a usecase. */
    export interface D1UsecaseEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1UsecaseField {
        name: string;
        type: string;
        derived: boolean;
        /** Copied from the ontology. Never inferred from the field name. */
        writePrecondition?: boolean;
        /** True when the ontology field or an ancestor is not required. */
        optional?: boolean;
    }
    export interface D1UsecaseTransition {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        /** Field paths the ontology names. Empty when that transition declares none. */
        payload?: string[];
        description?: string;
    }
    export interface D1UsecaseEntity {
        entityId: string;
        storageTarget: string;
        defPath: string;
        /** Empty when the ontology names none. The step does not invent one. */
        namespace: string;
        fields: D1UsecaseField[];
        transitions: D1UsecaseTransition[];
        rules: Array<{
            ruleId: string;
            owner: 'module' | 'platform';
            source?: string;
        }>;
        /** Ontology unique keys. Empty when the entity draft did not carry them. */
        uniqueKeys?: string[][];
        enumerations: Array<{
            path: string;
            values: string[];
        }>;
        /** Capability ids the ontology declares. Absent when this step was not given the body. */
        capabilities?: string[];
        /** Non-derived platform field paths. The MDM binding maps each one to a facade patch key. */
        platformFields?: string[];
    }
    export interface D1PortSignature {
        name: string;
        params: string[];
        returns: string;
    }
    export interface D1UsecasePort {
        portId: string;
        entityId: string;
        defPath: string;
        methods: string[];
        signatures?: D1PortSignature[];
    }
    export interface D1UsecaseSelection {
        usecaseId: string;
        entity: string;
        operation: string;
        routes: string[];
        defPath: string;
    }
    export interface D1OutboundEvent {
        eventId: string;
        on: string;
        kind?: string;
        to?: string;
        description?: string;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1WorkerPort {
        kind: 'port';
        call: string;
        port: string;
    }
    export interface D1WorkerRule {
        kind: 'rule';
        ruleId: string;
    }
    export interface D1WorkerMdm {
        kind: 'mdm';
        namespace: string;
        /** Facade method the model named. Not trusted until the gate matches it to a capability. */
        call: string;
        entity: string;
        /** Capability this step claims to execute. */
        capability: string;
    }
    export interface D1WorkerTransition {
        kind: 'transition';
        transitionId: string;
        payload: string[];
    }
    export interface D1WorkerEffect {
        kind: 'effect';
        eventId: string;
    }
    export interface D1WorkerTransaction {
        kind: 'transaction';
        boundary: string;
    }
    export interface D1WorkerContext {
        kind: 'context';
        source: string;
    }
    export type D1WorkerStep = D1WorkerPort | D1WorkerRule | D1WorkerMdm | D1WorkerTransition | D1WorkerEffect | D1WorkerTransaction | D1WorkerContext;
    /** One model reply, already parsed. Operational means the reply never arrived. */
    export interface D1UsecasePlanInput {
        usecaseId: string;
        steps: D1WorkerStep[];
        operational?: boolean;
        trace?: string;
    }
    /** A source the snapshot approved, or a file that was missing or had changed. */
    export interface D1SourceFinding {
        code: 'SOURCE_ABSENT' | 'SOURCE_CHANGED' | 'RULE_TEXT_ABSENT' | 'CONTRACT_UNPARSED';
        path: string;
        message: string;
    }
    export interface D1SourceHash {
        path: string;
        sha256: string;
    }
    export interface D1SourceText {
        path: string;
        text: string;
    }
    /**
     * One applicability row. `enforcement` is the status of this obligation.
     * `local` runs in the usecase. `delegated` would name a structured method; the catalog has none.
     * `pending` is a gap and is not a step. An empty `ruleId` is the storage unique-key row, not a rule.
     */
    export interface D1RulePlanRow {
        ruleId: string;
        origin: string;
        consumer: string;
        enforcement: 'local' | 'delegated' | 'pending';
        gap: string;
    }
    /** One rule the operation is subject to. The text is the source, not a summary. */
    export interface D1RuleText {
        ruleId: string;
        owner: 'module' | 'platform';
        source: string;
        text: string;
    }
    export interface D1ContractPath {
        path: string;
        type: string;
        optional: boolean;
    }
    export interface D1AccessGrant {
        grantId: string;
        actorRef: string;
        scope: string;
        anchorEntity: string;
        scopeDetail: string;
        disclosure: string;
        disclosureDetail: string;
        allowedFields: string[];
    }
    export interface D1RouteContext {
        route: string;
        page: string;
        contractPath: string;
        inputSymbol: string;
        outputSymbol: string;
        inputFields: D1ContractPath[];
        outputFields: D1ContractPath[];
        /** Set when this route's contract does not bind the route. Not a second type. */
        unbound: string;
        access: D1AccessGrant[];
    }
    export interface D1CapabilityText {
        name: string;
        text: string;
    }
    export interface D1JourneyContext {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: Array<{
            stepId: string;
            kind: string;
            transitionRef: string;
            description: string;
        }>;
    }
    /**
     * Business context for one usecase. Contract symbols stay a reading of the L2
     * source. This is not a DTO the gate trusts instead of that source.
     */
    export interface D1UsecaseContext {
        usecaseId: string;
        lifecycle: boolean;
        transition: {
            transitionId: string;
            from: string[];
            to: string;
            by: string[];
            ruleRefs: string[];
            payload: string[];
            description: string;
        } | null;
        capabilities: D1CapabilityText[];
        effectiveFields: string[];
        routes: D1RouteContext[];
        /** Rules this operation enforces. Pending obligations are not in this list. */
        rules: D1RuleText[];
        rulePlan: D1RulePlanRow[];
        /** Texts for pending rows. Not offered to the worker as steps. */
        pendingRules: D1RuleText[];
        portId: string;
        portMethods: D1PortSignature[];
        effects: D1OutboundEvent[];
        journeys: D1JourneyContext[];
        findings: D1SourceFinding[];
        sources: D1SourceHash[];
    }
    /** The human prompt that was handed to the worker, plus the hashes it was built from. */
    export interface D1PromptEvidence {
        usecaseId: string;
        bytes: number;
        sha256: string;
        snapshotHash: string;
        sourceHashes: D1SourceHash[];
        text: string;
    }
    export interface D1UsecaseRequest {
        project: number;
        moduleName: string;
        usecases: D1UsecaseSelection[];
        ports: D1UsecasePort[];
        entities: D1UsecaseEntity[];
        /** Ids only. The gate uses this catalog to validate a returned id. */
        moduleRules: string[];
        outbound: D1OutboundEvent[];
        contracts: D1ContractSource[];
        contexts?: D1UsecaseContext[];
        sourceFindings?: D1SourceFinding[];
        sourceHashes?: D1SourceHash[];
        /** Raw dependency texts. The fidelity reader uses these, not the draft. */
        files?: D1SourceText[];
        plans: D1UsecasePlanInput[];
        llmCalls: number;
    }
    /**
     * Where an argument's value comes from.
     * `prior.calls` are earlier call ids; the first that produced `path` wins.
     * A later call, or an id with no producer, is not a source.
     */
    export interface D1MdmOrigin {
        kind: 'contract' | 'context' | 'literal' | 'prior';
        path?: string;
        calls?: string[];
        /** `writePrecondition` when the ontology mark and the contract field agree. Not a name. */
        evidence?: string;
    }
    /** One value the facade method takes. A patch key the facade does not accept is not represented. */
    export interface D1MdmArgument {
        name: string;
        role: 'selector' | 'parameter' | 'patch';
        /** Set when a shared call's patch is owned by one capability. */
        capability?: string;
        /** Ontology or contract path the value is read from. Mirrors `origin.path` for a contract source. */
        path?: string;
        /** Constant the facade receives when the value is not a field (`role` tag, or `ctx`). */
        value?: string;
        origin: D1MdmOrigin;
    }
    /**
     * The call runs only when every clause holds.
     * A prior clause whose call did not run sees an absent value.
     */
    export interface D1MdmClause {
        kind: 'contract' | 'prior';
        path: string;
        call?: string;
        present: boolean;
    }
    /** One facade invocation. Several capabilities may share it when one patch and one version cover them. */
    export interface D1MdmPlannedCall {
        /** Stable id inside this plan. Later calls cite it; it does not cite them. */
        id: string;
        method: D1MdmCall;
        target: 'entity' | 'collection' | 'identity';
        shape: 'point' | 'collection' | 'write';
        capabilities: string[];
        /** True when the capability is a choice (inactivate or reactivate), not a sequence. */
        alternative: boolean;
        /** Empty means the call always runs. */
        when: D1MdmClause[];
        arguments: D1MdmArgument[];
        result: string[];
    }
    /** A declared capability the facade does not implement, or an argument with no source. */
    export interface D1MdmGap {
        capability: string;
        /**
         * MDM_UNBOUND: no facade method.
         * MDM_PATCH_UNBOUND: a field the facade cannot patch.
         * MDM_ARGUMENT_UNBOUND: a required argument has no contract, context, literal or earlier result.
         * MDM_CONTRACT_UNREAD: the route contract was not read, so a call that needs one was not emitted.
         */
        code: 'MDM_UNBOUND' | 'MDM_PATCH_UNBOUND' | 'MDM_ARGUMENT_UNBOUND' | 'MDM_CONTRACT_UNREAD';
        evidence: string;
    }
    export interface D1UsecaseMdm {
        namespace: string;
        /** Canonical tag `<namespace>.<entityId>`. */
        role: string;
        /**
         * True only when every selected capability is one facade invocation.
         * A sequence of calls is not atomic: the facade does not wrap them.
         */
        atomic: boolean;
        calls: D1MdmPlannedCall[];
        gaps: D1MdmGap[];
    }
    export interface D1UsecaseItem {
        usecaseId: string;
        entityId: string;
        operation: string;
        defPath: string;
        routes: string[];
        trustedContext: 'ctx';
        mdm: D1UsecaseMdm | null;
        transactionBoundary: 'local' | null;
        steps: D1WorkerStep[];
        definition: D1Definition | null;
    }
    export interface D1UsecaseEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export interface D1UsecaseBuild {
        schemaVersion: typeof D1_USECASE_VERSION;
        project: number;
        moduleName: string;
        llmCalls: number;
        ok: boolean;
        enumerations: D1UsecaseEnumeration[];
        usecases: D1UsecaseItem[];
        problems: D1UsecaseProblem[];
        normalizations: D1UsecaseNormalization[];
        emit: D1UsecaseEmit[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding" {
    import { type D1MdmCall, type D1MdmGap, type D1MdmPlannedCall, type D1UsecaseMdm } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    /** Same filter the worker catalog and the gate use before bindMdm. */
    export function capabilityApplies(name: string, operation: string): boolean;
    /**
     * Capabilities this operation may name, then the calls bindMdm actually emits.
     * Context, worker schema and the gate all take this result. A locate the input
     * cannot feed is not offered.
     */
    export function mdmForOperation(input: MdmBindInput & {
        operation: string;
    }): D1UsecaseMdm;
    /** One schema pair per bound call. Alternative writes stay in the catalog. */
    export function mdmStepPairs(mdm: D1UsecaseMdm): Array<{
        call: string;
        capability: string;
    }>;
    /**
     * Capabilities the ontology can name and the facade does not implement.
     * Inactivate and reactivate do not write status history. Audit is another module.
     */
    export function mdmFacadeGaps(): D1MdmGap[];
    export function isMdmFacadeCall(value: string): value is D1MdmCall;
    /** A patch key the caller module may not write. Platform keys and the caller namespace are allowed. */
    export function isForeignMdmPatchKey(namespace: string, key: string): boolean;
    /**
     * Facade methods named by capabilities alone.
     * Callers that only need the catalog use this. It does not read a contract
     * and it does not invent arguments.
     */
    export function mdmCapabilityCalls(selected: readonly string[]): Array<{
        method: string;
        capabilities: string[];
    }>;
    /** One field of this operation's input, flattened. `writePrecondition` is the ontology mark, not the name. */
    export interface MdmInputField {
        path: string;
        optional: boolean;
        writePrecondition: boolean;
    }
    export interface MdmBindInput {
        entityId: string;
        namespace: string;
        /** Every capability the role declares. A locate capability does not put its arguments on every input. */
        capabilities: readonly string[];
        /** Capabilities this operation actually uses. */
        selected: readonly string[];
        platformFields: readonly string[];
        /**
         * Fields shared by every resolved route input.
         * `null` means the route contract was not read. A call that needs a contract
         * argument is not emitted (`MDM_CONTRACT_UNREAD`).
         * An empty list means the contract was read and declares nothing.
         */
        inputFields?: readonly MdmInputField[] | null;
        /** Why the contract was not read, one reason per route. Ignored when fields were read. */
        contractUnread?: string;
    }
    export function bindMdm(input: MdmBindInput): D1UsecaseMdm;
    /**
     * Proves the serialized plan. Prior links and the create-or-attach branch are checked
     * whether or not a contract was read. A contract argument with no field list is
     * `MDM_CONTRACT_UNREAD`, not a pass.
     */
    export function mdmFlowGaps(calls: readonly D1MdmPlannedCall[], input: MdmBindInput, existing?: readonly D1MdmGap[]): D1MdmGap[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/rulePlan" {
    import { capabilityApplies } from "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding";
    export { capabilityApplies };
    import type { D1RulePlanRow } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface RulePlanRule {
        ruleId: string;
        owner: 'module' | 'platform';
        source: string;
        text: string;
    }
    export interface RulePlanTransition {
        transitionId: string;
        by: readonly string[];
        ruleRefs: readonly string[];
        payload: readonly string[];
    }
    export interface RulePlanGrant {
        grantId: string;
        actorRef: string;
        scope: string;
    }
    export interface RulePlanRoute {
        route: string;
        contractPath: string;
        grants: readonly RulePlanGrant[];
    }
    export interface RulePlanInput {
        moduleName: string;
        entityId: string;
        usecaseId: string;
        operation: string;
        rules: readonly RulePlanRule[];
        transitions: readonly RulePlanTransition[];
        uniqueKeys: readonly (readonly string[])[];
        capabilities: readonly string[];
        routes: readonly RulePlanRoute[];
        /**
         * Facade methods the binding calls. Not evidence: the catalog names no method
         * in a structured field, and a sentence is not a call.
         */
        mdmMethods: readonly string[];
    }
    export interface RulePlanEntity {
        rules: readonly {
            ruleId: string;
            owner: 'module' | 'platform';
            source?: string;
        }[];
        transitions: readonly RulePlanTransition[];
        uniqueKeys?: readonly (readonly string[])[];
        capabilities?: readonly string[];
        namespace: string;
        storageTarget: string;
        platformFields?: readonly string[];
    }
    export interface RulePlanFile {
        path: string;
        text: string;
    }
    /** Rule ids the operation enforces. Pending rows are not in this list. */
    export function enforcedRuleIds(rows: readonly D1RulePlanRow[]): string[];
    export function originFile(origin: string): string;
    export function planRuleApplicability(input: RulePlanInput): D1RulePlanRow[];
    /**
     * Same plan the gate writes and the fidelity reader recomputes.
     * An ontology file wins over the entity draft. Routes stay on the input.
     * A grant does not place a rule.
     */
    export function rulePlanForUsecase(input: {
        moduleName: string;
        entityId: string;
        usecaseId: string;
        operation: string;
        files?: readonly RulePlanFile[];
        entity: RulePlanEntity;
        routes: readonly RulePlanRoute[];
    }): D1RulePlanRow[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/context" {
    import { type D1InputSnapshot, type D1SourceDigest } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ContractField } from "_102021_/l2/agentDefsL1/steps/usecases50/contractsAst";
    import { capabilityApplies, type MdmInputField } from "_102021_/l2/agentDefsL1/steps/usecases50/mdmBinding";
    export { capabilityApplies };
    import type { D1ContractPath, D1ContractSource, D1OutboundEvent, D1SourceFinding, D1SourceHash, D1SourceText, D1UsecaseContext, D1UsecaseEntity, D1UsecaseField, D1UsecasePort, D1UsecaseRequest, D1UsecaseSelection } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface JourneyStepView {
        stepId: string;
        kind: string;
        entity: string;
        effect: string;
        transitionRef: string;
        description: string;
    }
    export interface JourneyView {
        journeyId: string;
        path: string;
        actorRef: string;
        goal: string;
        steps: JourneyStepView[];
    }
    export interface VerifiedBundle {
        findings: D1SourceFinding[];
        hashes: D1SourceHash[];
        moduleRuleText: Record<string, string> | null;
        moduleRulesPath: string;
        outbound: D1OutboundEvent[];
        integrationPath: string;
        contracts: D1ContractSource[];
        access: unknown | null;
        accessPath: string;
        needs: unknown | null;
        needsPath: string;
        journeys: JourneyView[];
        catalogs: Array<{
            path: string;
            rules: Record<string, string>;
        }>;
        bodies: Record<string, unknown | null>;
        entityPaths: Record<string, string>;
        files: D1SourceText[];
    }
    interface TransitionBody {
        transitionId: string;
        from: string[];
        to: string;
        by: string[];
        ruleRefs: string[];
        payload: string[];
        description: string;
    }
    /** Reads the snapshot's sources again. A file is kept only when its hash still matches. */
    export function loadVerifiedSources(project: number, moduleName: string, snapshot: D1InputSnapshot, entityIds: readonly string[]): Promise<VerifiedBundle>;
    /**
     * The cut for one usecase: its routes, the rules those routes are subject to,
     * and the lifecycle or MDM capability that operation actually is.
     */
    export function buildUsecaseContexts(input: {
        moduleName: string;
        usecases: readonly D1UsecaseSelection[];
        entities: readonly D1UsecaseEntity[];
        ports: readonly D1UsecasePort[];
        bundle: VerifiedBundle;
    }): D1UsecaseContext[];
    export function formatUsecaseContext(context: D1UsecaseContext): string;
    /** Names the gate may accept on a transition payload. The domain signature is the authority. */
    export function authorizedPayloadNames(request: D1UsecaseRequest, usecaseId: string, inputNames: readonly string[]): Set<string>;
    export interface DomainField {
        name: string;
        type: string;
        fieldRef?: string;
    }
    /** Application signature. Contract symbols are not an input or an output. */
    export function domainSignature(entity: D1UsecaseEntity, operation: string, payload?: readonly string[]): {
        input: DomainField[];
        output: DomainField[];
    };
    /** Leaves of an ontology record. Optional when the field or an ancestor is not required. */
    export function ontologyLeaves(body: unknown): D1UsecaseField[];
    export function blockingFinding(findings: readonly D1SourceFinding[]): D1SourceFinding | null;
    /** A file this context was built from no longer matches the snapshot. */
    export function blockingDrift(project: number, context: D1UsecaseContext, digests: readonly D1SourceDigest[]): Promise<D1SourceFinding | null>;
    export function ontologyTransitions(body: unknown): TransitionBody[];
    export function namespaceOf(body: unknown): string;
    export function capabilityNames(body: unknown): string[];
    export function platformFieldPaths(body: unknown): string[];
    /** Ontology paths marked writePrecondition. A field named version without the mark is not included. */
    export function writePreconditionPaths(body: unknown): string[];
    /**
     * The ontology file wins. When that file is absent, only fields the caller already marked count.
     * An unmarked name is not a precondition.
     */
    export function preconditionsFor(files: readonly {
        path: string;
        text: string;
    }[] | undefined, moduleName: string, entityId: string, fallback: readonly {
        name: string;
        writePrecondition?: boolean;
    }[]): string[];
    /**
     * Optionality and preconditions the ontology actually declares.
     * The domain draft's field list is the fallback when that file is absent.
     * The gate and the fidelity reader must use the same list, or a call the gate
     * stored will not match the call fidelity recomputes.
     */
    export function declaredFieldsFor(files: readonly {
        path: string;
        text: string;
    }[] | undefined, moduleName: string, entityId: string, fallback: readonly {
        name: string;
        optional?: boolean;
    }[]): readonly {
        name: string;
        optional?: boolean;
    }[];
    /** One route whose contract could not be read, and why. */
    export interface MdmContractRead {
        /** Shared fields. `null` when any route contract was not read: one route never borrows another's fields. */
        fields: readonly MdmInputField[] | null;
        /**
         * One reason per route that did not resolve: contract absent, binding absent, binding ambiguous,
         * input not declared, input symbol absent, or input symbol duplicated.
         */
        unread: readonly string[];
    }
    /**
     * Input fields of this operation, taken from the domain signature.
     * `page` and `pageSize` are application paging, not MDM arguments.
     * An empty list means the ontology declares nothing for this operation.
     */
    export function mdmInputFields(input: readonly {
        name: string;
    }[], preconditions: readonly string[], declared?: readonly {
        name: string;
        optional?: boolean;
    }[]): MdmContractRead;
    export function flattenContractFields(fields: readonly D1ContractField[]): D1ContractPath[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/callLog" {
    /**
     * Receipts of what usecases50 already observes. One file per observation so
     * parallel workers do not share a counter. A missing folder is not zero.
     */
    export const D1_CALL_LOG_VERSION: "2026-09-24-d1-calls-v1";
    export const CALL_ABSENT = "usecases50 call log is absent";
    export const CALL_HISTORY_ABSENT = "generation call history is absent";
    export const CALL_UNREADABLE = "usecases50 call log has an unreadable event";
    export const CALL_NO_INVOCATION = "usecases50 call log has no invocation";
    export type D1CallEventKind = 'prompt_assembled' | 'reply_delivered' | 'reply_absent' | 'not_dispatched' | 'repair_scheduled';
    export interface D1CallEvent {
        schemaVersion: typeof D1_CALL_LOG_VERSION;
        kind: D1CallEventKind;
        usecaseId: string;
        planId: string;
        /** Index on the worker arg. Not a call count. */
        unitAttempts: number;
        invocation: number;
    }
    export interface D1CallInvocation {
        schemaVersion: typeof D1_CALL_LOG_VERSION;
        kind: 'dispatch' | 'resume';
        index: number;
        /** True only when this resume found no generation observations. */
        historyAbsent: boolean;
    }
    export interface D1CallLog {
        invocations: D1CallInvocation[];
        events: D1CallEvent[];
        unreadable: boolean;
    }
    /** Counts proved by the log. Null is unmeasured. Zero is a measured receipt count. */
    export interface D1CallAccount {
        /** Host delivered a reply payload. Not units, attempts, prompts, or cost. */
        repliesDelivered: number | null;
        repliesUnknown: string;
        /** Prompts handed to the host. Not completed calls. */
        promptsAssembled: number | null;
        /** Repair steps the barrier opened. Not calls. */
        repairsScheduled: number | null;
        /** Reply payloads of the latest invocation. A resume without a call is 0. */
        invocationReplies: number | null;
        invocationUnknown: string;
        /** finalize80 does not call a model. Local step, not the generation. */
        finalizeCalledModel: false;
        /** finalize80 does not open a repair. Local step, not the generation. */
        finalizeOpenedRepair: false;
    }
    export function callsFolder(moduleName: string): string;
    export function accountCalls(log: D1CallLog | null): D1CallAccount;
    export function readCallLog(project: number, moduleName: string): Promise<D1CallLog | null>;
    /** A new dispatch. Workers record against this index afterwards. */
    export function openCallDispatch(project: number, moduleName: string): Promise<number>;
    /**
     * This invocation added no call. Observations already on disk stay.
     * No observations means the generation total stays unknown.
     */
    export function openCallResume(project: number, moduleName: string): Promise<void>;
    /** First file for this plan and kind wins. A second delivery does not add a row. */
    export function recordCallEvent(project: number, moduleName: string, event: {
        kind: D1CallEventKind;
        usecaseId: string;
        planId: string;
        unitAttempts: number;
    }): Promise<void>;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/dispatch" {
    import type { D1PromptEvidence } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export const FANOUT_TITLE = "Generating {{completed}}/{{total}} items, failed {{failed}}";
    export interface D1WorkerArg {
        planId: string;
        moduleName: string;
        project: number;
        usecaseId: string;
        attempt: number;
        unitAttempts: number;
        globalAttempts: number;
        feedback: string;
    }
    export interface D1AttemptTrace {
        usecaseId: string;
        status: 'parsed' | 'repairable' | 'operational';
        trace: string;
        unitAttempts: number;
        reply: unknown;
        /** The prompt the hook assembled. Present after prepareWorker. */
        request?: D1PromptEvidence;
    }
    export interface D1RepairOrder {
        usecaseId: string;
        unitAttempts: number;
        globalAttempts: number;
        planId: string;
        feedback: string;
    }
    export interface D1BarrierDecision {
        repairs: D1RepairOrder[];
        identified: Array<{
            usecaseId: string;
            trace: string;
            code: string;
        }>;
        pause: boolean;
    }
    /** Compact, stable JSON. One arg is one usecase. */
    export function workerArg(arg: D1WorkerArg): string;
    export function parseWorkerArg(value: string): D1WorkerArg | null;
    export function firstWorkerArg(project: number, moduleName: string, usecaseId: string): string;
    export function fanoutStep(project: number, moduleName: string, args: readonly string[]): mls.msg.AIAgentStep;
    export function fanoutExecution(args: readonly string[]): mls.msg.ExecutionMode;
    /**
     * The host marks a parallel parent completed and does not call its afterPrompt.
     * This step depends on the fan-out, so the host unlocks it and runs beforePrompt.
     * A later round depends on the repair plan ids from the round it follows.
     */
    export function barrierStep(project: number, moduleName: string, dependsOn: readonly string[], round: string): mls.msg.AIAgentStep;
    /**
     * One repair per usecase, and no more than the global ceiling.
     * An operational failure is identified and does not take a repair.
     * A missing trace is still identified.
     */
    export function decideRepairs(input: {
        expected: readonly string[];
        attempts: readonly D1AttemptTrace[];
        globalAttempts: number;
        feedbackFor: (usecaseId: string) => string;
    }): D1BarrierDecision;
    export function repairStep(project: number, moduleName: string, order: D1RepairOrder): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/fidelity" {
    import type { D1UsecaseMdm, D1WorkerStep } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface FidelityFile {
        path: string;
        text: string;
    }
    export interface FidelityProblem {
        code: string;
        path: string;
        message: string;
    }
    export interface D1FieldUse {
        path: string;
        role: 'filter' | 'selector' | 'concurrency' | 'write';
        source: 'input' | 'payload';
    }
    export interface UsecaseBehavior {
        usecaseId: string;
        operation: string;
        sequence: D1WorkerStep[];
        uses: D1FieldUse[];
        mdm: D1UsecaseMdm | null;
        lifecycle: {
            transitionId: string;
            payload: string[];
            sourcePath: string;
            symbol: string;
        } | null;
        rules: Array<{
            ruleId: string;
            path: string;
            symbol: string;
        }>;
        transaction: 'local' | 'none';
        effects: Array<{
            eventId: string;
            path: string;
            symbol: string;
        }>;
        routes: Array<{
            route: string;
            contractPath: string;
            symbol: string;
            outputFields: string[];
        }>;
    }
    /**
     * Classifies a derived field the same way the gate does.
     * A payload is a write. Identity on a read is a filter; on an update or
     * transition it is a selector. A nested derived field on a read is a filter.
     * `version` on an update or transition is concurrency.
     */
    export function fieldUses(input: {
        operation: string;
        fields: readonly {
            name: string;
            derived: boolean;
        }[];
        inputPaths: readonly string[];
        payloadPaths: readonly string[];
    }): D1FieldUse[];
    /**
     * Reads one serialized usecase def and the dependency texts it names.
     * It does not take the draft. A rule id, a file count or a signature is not enough.
     */
    export function readUsecaseFidelity(source: string, files: readonly FidelityFile[]): {
        behavior: UsecaseBehavior | null;
        problems: FidelityProblem[];
    };
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/gate" {
    import { type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import { type D1UsecaseBuild, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    /**
     * One deterministic pass from the selection, the domain draft, the ports and
     * the contract AST. The model may order steps. It does not choose ids.
     */
    export function buildD1Usecases(request: D1UsecaseRequest): D1UsecaseBuild;
    /** A usecase file must not depend on an adapter. */
    export function applicationAdapterIssues(item: D1PipelineItem): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/io" {
    import { type D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1AttemptTrace } from "_102021_/l2/agentDefsL1/steps/usecases50/dispatch";
    import { D1_USECASE_VERSION, type D1PromptEvidence, type D1UsecaseBuild, type D1UsecasePlanInput, type D1UsecaseRequest } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export interface D1UsecaseWork {
        schemaVersion: typeof D1_USECASE_VERSION;
        repairs: number;
        request: D1UsecaseRequest;
    }
    export function loadD1UsecaseWork(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        work: D1UsecaseWork;
    }>;
    export function readD1UsecaseWork(project: number, moduleName: string): Promise<D1UsecaseWork | null>;
    export function writeD1UsecaseWork(project: number, work: D1UsecaseWork): Promise<void>;
    export function workFile(project: number, moduleName: string): D1FileInfo;
    export function attemptFile(project: number, moduleName: string, usecaseId: string): D1FileInfo;
    export function writeAttempt(project: number, moduleName: string, attempt: D1AttemptTrace): Promise<void>;
    /** The assembled prompt, written before the model replies. Not an attempt: it has no status. */
    export function writePromptEvidence(project: number, moduleName: string, evidence: D1PromptEvidence): Promise<void>;
    /** A source finding already closed this worker. A later empty reply must not replace it. */
    export function sourceBlockTrace(project: number, moduleName: string, usecaseId: string): Promise<string | null>;
    export function readPromptEvidence(project: number, moduleName: string, usecaseId: string): Promise<D1PromptEvidence | null>;
    export function readAttempts(project: number, moduleName: string, usecaseIds: readonly string[]): Promise<D1AttemptTrace[]>;
    export function commitD1Usecases(project: number, build: D1UsecaseBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
    export function plansFromAttempts(attempts: readonly D1AttemptTrace[]): D1UsecasePlanInput[];
    export function buildFromWork(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], llmCalls: number): D1UsecaseBuild;
    /**
     * Defs of units that parsed stay. Each identified unit is one error on its
     * usecase id and has no definition. `ok` stays false.
     */
    export function holdUnresolvedBuild(work: D1UsecaseWork, attempts: readonly D1AttemptTrace[], identified: readonly {
        usecaseId: string;
        code: string;
        trace: string;
    }[], llmCalls: number): D1UsecaseBuild;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/worker" {
    import { type D1UsecaseContext, type D1UsecaseRequest, type D1UsecaseSelection, type D1WorkerStep } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export const USECASE_TOOL_NAME = "planUsecaseSteps";
    export const STEP_KEYS: {
        readonly port: readonly ["kind", "call", "port"];
        readonly rule: readonly ["kind", "ruleId"];
        readonly mdm: readonly ["kind", "namespace", "call", "entity", "capability"];
        readonly transition: readonly ["kind", "transitionId", "payload"];
        readonly effect: readonly ["kind", "eventId"];
        readonly transaction: readonly ["kind", "boundary"];
        readonly context: readonly ["kind", "source"];
    };
    /** One facade method with the capability that binding says it executes. */
    export interface MdmStepPair {
        call: string;
        capability: string;
    }
    /**
     * Catalogs known for the one usecase being called.
     * An omitted catalog was not provided and stays a free string.
     * An empty catalog was provided and means that branch is unavailable.
     */
    export interface UsecaseClosedValues {
        portCalls?: readonly string[];
        portIds?: readonly string[];
        ruleIds?: readonly string[];
        namespaces?: readonly string[];
        entityIds?: readonly string[];
        /** Facade methods this operation may name. Empty omits MDM. Omitted keeps the facade catalog. */
        mdmCalls?: readonly string[];
        capabilities?: readonly string[];
        /** One branch per pair, so a call cannot be paired with another capability. Empty omits MDM. */
        mdmPairs?: readonly MdmStepPair[];
        transitionIds?: readonly string[];
        /** Paths a transition payload may name. Empty means the payload array is empty. Omitted keeps a free string. */
        payloadPaths?: readonly string[];
        eventIds?: readonly string[];
        /** Authority values this operation may name. The gate admits `ctx` only. */
        sources?: readonly string[];
        /**
         * Transaction boundaries this operation may name.
         * Empty omits the branch. The gate admits `local` on a repository operation and refuses every other value.
         */
        boundaries?: readonly string[];
    }
    export interface OperationCatalogInput {
        operation: string;
        entityId: string;
        storageTarget: string;
        namespace: string;
        portId: string;
        /** Methods the port declares. Only `operation` is offered, and only when this port has it. */
        portMethods: readonly string[];
        ruleIds: readonly string[];
        eventIds: readonly string[];
        transitionId: string;
        payloadPaths: readonly string[];
        mdmPairs: readonly MdmStepPair[];
    }
    /** The catalogs for one operation. Port, MDM and transition come from the same facts the schema uses. */
    export function catalogForOperation(input: OperationCatalogInput): UsecaseClosedValues;
    /** Selection for the usecase the worker is about to call. Schema and prompt both take this object. */
    export function closedFromRequest(request: D1UsecaseRequest, usecase: D1UsecaseSelection, packet?: D1UsecaseContext): UsecaseClosedValues;
    /**
     * Kinds and calls this operation can use, from `selectBranches`.
     * An unscoped call still lists every kind and the facade catalog.
     * The markdown prompt does not copy this list.
     */
    export function workerStepShape(closed?: UsecaseClosedValues): string;
    export interface D1WorkerReply {
        steps: D1WorkerStep[] | null;
        problems: Array<{
            code: string;
            message: string;
        }>;
    }
    /** The model returns steps only. An extra field rejects the reply. */
    export function parseWorkerReply(payload: unknown): D1WorkerReply;
    export function usecaseTool(closed?: UsecaseClosedValues): mls.msg.LLMTool;
    /** Human prompt. The packet is fixed. The model does not write TypeScript. */
    export function usecaseHumanPrompt(input: {
        usecase: D1UsecaseSelection;
        entityId: string;
        storageTarget: string;
        namespace: string;
        portId: string;
        methods: string[];
        rules: string[];
        effects: string[];
        routes: string[];
        context?: D1UsecaseContext;
        /** Same object the tool schema was built from. */
        closed: UsecaseClosedValues;
        feedback?: string;
    }): string;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1UsecasesPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/contracts" {
    import type { D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1ActiveStatus } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    export const D1_CONTROLLER_VERSION: "2026-10-01-d1-controllers-adapter";
    /** Same trail as domain30 and usecases50. This step does not copy the values either. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Controller projection has no values slot. Enum values stay on the domain draft.";
    export const HANDLER_STEPS: readonly ["transport", "session", "authorize", "call", "project", "bff"];
    export interface D1ControllerProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1ControllerNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1ControllerEnumeration {
        entityId: string;
        path: string;
        values: string[];
        consumed: false;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON;
    }
    export interface D1ControllerPage {
        pageId: string;
        actors: string[];
        defPath: string;
    }
    export interface D1ControllerRoute {
        route: string;
        page: string;
        kind: string;
        usecaseRef: string;
        status: string;
    }
    export interface D1ControllerUsecase {
        usecaseId: string;
        entity: string;
        operation: string;
        /** Copied from `selection.usecases[].status`. */
        status: D1ActiveStatus;
        functionName: string;
        defPath: string;
    }
    export interface D1ControllerGrant {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        scopeMode: string;
    }
    export interface D1ControllerRelationship {
        relationshipId: string;
        from: string;
        to: string;
        /** Copied from the relationship. Empty when the relationship declares none. */
        field: string;
        required: boolean;
    }
    export interface D1ContractSource {
        pageId: string;
        path: string;
        source: string;
    }
    export interface D1ExistingHandler {
        route: string;
        kind: 'query' | 'command';
        usecaseId: string;
        /** Request route this handler calls. Absent on a v1 usecase handler. */
        serviceFunction?: string;
        grantIds: string[];
    }
    /** A controller file already on disk. Parsed, never evaluated. */
    export interface D1ExistingController {
        pageId: string;
        routes: string[];
        handlers: D1ExistingHandler[];
        unreadable: boolean;
    }
    export interface D1EnumerationRef {
        entityId: string;
        path: string;
        values: string[];
    }
    /** One selected contract request. `uses` names usecase ids already in the pool. */
    export interface D1ServiceRequestSource {
        route: string;
        pageId: string;
        kind: 'qry' | 'cmd';
        uses: string[];
        outputs: Array<{
            key: string;
            entity: string;
        }>;
        params: Array<{
            name: string;
            target: string;
            field?: string;
            pages?: string;
        }>;
    }
    export interface D1ServiceOutput {
        key: string;
        entity: string;
        fields: string[];
    }
    export interface D1ServiceParam {
        name: string;
        target: string;
        field?: string;
        pages?: string;
    }
    export interface D1ServiceRow {
        route: string;
        kind: 'qry' | 'cmd';
        uses: string[];
        transaction: 'single' | 'none';
        outputs: D1ServiceOutput[];
        params: D1ServiceParam[];
    }
    export interface D1RequestServiceItem {
        pageId: string;
        defPath: string;
        requests: D1ServiceRow[];
        definition: D1Definition | null;
    }
    export interface D1ControllerRequest {
        project: number;
        moduleName: string;
        pages: D1ControllerPage[];
        usecases: D1ControllerUsecase[];
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        contracts: D1ContractSource[];
        existing: D1ExistingController[];
        enumerations: D1EnumerationRef[];
        accessRead: boolean;
        actorsRead: boolean;
        /** Routes selected for removal. Absent means none. */
        removedRoutes?: readonly D1RemovedRoute[];
        /** Contract v2 requests. Absent on a v1 plan. */
        serviceRequests?: readonly D1ServiceRequestSource[];
        /** Ontology entities keyed by entity id. Absent when the plan has no v2 request. */
        ontology?: Readonly<Record<string, unknown>>;
    }
    export interface D1ScopeRelationship {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Scope plan support70 will emit. The anchor is the one the access artifact declared. */
    export interface D1ScopeGrantPlan {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        relationships: D1ScopeRelationship[];
        pending: string;
        emittedBy: 'support70';
    }
    export interface D1HandlerProjection {
        shape: 'array' | 'object' | 'unresolved';
        fields: string[];
        envelope: 'passthrough';
    }
    export interface D1HandlerBinding {
        route: string;
        pageId: string;
        kind: 'query' | 'command';
        /** Empty when the handler calls the request service instead of a usecase. */
        usecaseId: string;
        functionName: string;
        /** Request route of this page's service. Empty on a v1 binding. */
        serviceFunction: string;
        contractPath: string;
        /** `<Page>Contracts`. Empty on a v1 binding. Not an Input or Output symbol. */
        contractInterface: string;
        inputSymbol: string;
        outputSymbol: string;
        status: string;
        preserved: boolean;
        grantIds: string[];
        projection: D1HandlerProjection;
        session: 'verified';
        steps: typeof HANDLER_STEPS;
        scopePlan: D1ScopeGrantPlan[];
    }
    export interface D1ControllerItem {
        pageId: string;
        defPath: string;
        handlers: D1HandlerBinding[];
        staleRoutes: string[];
        definition: D1Definition | null;
    }
    export interface D1ControllerEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    /** A selected route to drop. Other routes of the same controller stay. */
    export interface D1RemovedRoute {
        route: string;
        pageId: string;
        defPath: string;
        contentHash: string;
    }
    /** Own controller def removed only when the page has no live route left. */
    export interface D1ControllerRemoval {
        defPath: string;
        contentHash: string;
        outputTs: string[];
    }
    export interface D1ControllerBuild {
        schemaVersion: typeof D1_CONTROLLER_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        measuredRoutes: number;
        measuredPages: number;
        enumerations: D1ControllerEnumeration[];
        controllers: D1ControllerItem[];
        services: D1RequestServiceItem[];
        problems: D1ControllerProblem[];
        normalizations: D1ControllerNormalization[];
        emit: D1ControllerEmit[];
        /** Controller defs with no live route. The `.ts` path is reported, not deleted. */
        removals: D1ControllerRemoval[];
    }
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/requestService" {
    import type { D2ContractV2Definition } from "_102020_/l2/helpers/contractV2/types";
    import type { D1ControllerProblem, D1ControllerRequest, D1ServiceRequestSource, D1ServiceRow } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export interface RequestServiceCheck {
        pageId: string;
        contractRoutes: readonly string[];
        requests: readonly D1ServiceRow[];
        usecaseIds: ReadonlySet<string>;
        fieldsByEntity: ReadonlyMap<string, ReadonlySet<string>>;
        /** Selected rows per route. Defaults to the built rows. */
        selectedCounts?: ReadonlyMap<string, number>;
    }
    /** Leaf paths of a contract interface body. Containers are not paths. */
    export function interfaceFieldPaths(body: string): string[] | null;
    /** Dotted paths of an ontology entity, including object nodes. */
    export function ontologyFieldPaths(entity: unknown): string[];
    /**
     * Each contract route has one request. Every `uses` id is a usecase def.
     * Each projected path is a field of that output's entity. A command is `single`.
     */
    export function requestServiceProblems(input: RequestServiceCheck): D1ControllerProblem[];
    export function serviceRowsFor(pageId: string, definition: D2ContractV2Definition, selected: readonly D1ServiceRequestSource[]): {
        routes: string[];
        rows: D1ServiceRow[];
        problems: D1ControllerProblem[];
    };
    export function fieldsByEntity(ontology: Readonly<Record<string, unknown>>): Map<string, Set<string>>;
    export function usecaseIdsWithDef(request: D1ControllerRequest): Set<string>;
    export function readContractV2(source: string): D2ContractV2Definition | null;
    /** The one `export interface <Page>Contracts` in a v2 file. Empty when it is missing or repeated. */
    export function contractInterfaceName(source: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/gate" {
    import { type D1ControllerBuild, type D1ControllerGrant, type D1ControllerRequest } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    /**
     * One controller per page. Ids, route strings and contract symbols are copied.
     * An operation with no grant is an error. There is no public fallback.
     */
    export function buildD1Controllers(request: D1ControllerRequest): D1ControllerBuild;
    /** A grant whose actor is not on this page is a union. The caller does not add it. */
    export function grantUnionIssues(pageActors: readonly string[], grantIds: readonly string[], grants: readonly D1ControllerGrant[]): string[];
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/io" {
    import { type D1ControllerBuild } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export function assembleD1Controllers(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1ControllerBuild;
    }>;
    export function commitD1Controllers(project: number, build: D1ControllerBuild): Promise<{
        written: string[];
        issues: string[];
    }>;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1ControllersPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/contracts" {
    import type { D1_MEASURED_PUBLISH, D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import type { D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    import type { D1ControllerGrant, D1ControllerRelationship, D1ScopeGrantPlan } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export const D1_SUPPORT_VERSION: "2026-10-01-d1-support-v2";
    /** Same trail as the earlier steps. Uncited values stay on the domain draft. */
    export const ENUMERATION_SOURCE: "domain30.enumerations";
    export const ENUMERATION_REASON: "Scope and registry have no values slot. Enum values stay on the domain draft.";
    export const ENUMERATION_CONSUMED_REASON: "Seed scenarios cite every value of this enum. The values are not copied into rows.";
    /** A covered consumer names this field. The union is not runtime enforcement. */
    export const ENUMERATION_PROVED_REASON: "A covered consumer names this entity and path. A type union is not runtime enforcement. Values stay on the domain draft.";
    export type D1EnumOwner = 'platform' | 'module' | 'unresolved';
    export type D1EnumWriter = 'platform' | 'module' | 'derived' | 'unresolved';
    export type D1EnumRestriction = 'inherited' | 'subset' | 'own' | 'invalid' | 'unresolved';
    export type D1EnumPurpose = 'seedScenario' | 'usecaseDef' | 'domainDef';
    /** One proved use. A homonymous literal on another entity or path is not this use. */
    export interface D1EnumUse {
        purpose: D1EnumPurpose;
        consumer: string;
        entityId: string;
        path: string;
        values: string[];
        /** False when the field is derived, a role binding, or the literal is only on an output. */
        editable: boolean;
    }
    /** Catalog owner, writer and restriction. They are not one badge. */
    export interface D1EnumOrigin {
        owner: D1EnumOwner;
        writer: D1EnumWriter;
        derived: boolean;
        restriction: D1EnumRestriction;
        catalogValues: string[];
        catalogSource: string;
        roleBinding: boolean;
    }
    /** A seed scenario that names one entity and one field. Not a global set of literals. */
    export interface D1SeedCitation {
        entityId: string;
        path: string;
        scenarioId: string;
        values: string[];
    }
    export interface D1SupportProblem {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
    }
    export interface D1SupportNormalization {
        code: string;
        path: string;
        detail: string;
    }
    export interface D1SupportEnumeration {
        entityId: string;
        path: string;
        values: string[];
        /** True when `uses` is non-empty. Not runtime enforcement. */
        consumed: boolean;
        source: typeof ENUMERATION_SOURCE;
        reason: typeof ENUMERATION_REASON | typeof ENUMERATION_CONSUMED_REASON | typeof ENUMERATION_PROVED_REASON;
        origin: D1EnumOrigin;
        uses: D1EnumUse[];
        limits: string;
    }
    export type D1EnumRow = D1SupportEnumeration;
    export interface D1SupportFile {
        artifactType: string;
        defPath: string;
        action: string;
        /** Hash inventoried on the input receipt. Empty when this run has no receipt. */
        contentHash: string;
        /** Hash of the bytes on disk now. Empty when the file is absent. */
        currentHash: string;
    }
    /** An adapter persistence40 already planned. A removed adapter is not live. */
    export interface D1SupportAdapter {
        portId: string;
        entityId: string;
        tableId: string;
        artifactId: string;
        action: string;
        defPath: string;
    }
    export interface D1SupportJoinStep {
        relationshipId: string;
        from: string;
        to: string;
        field: string;
    }
    /** Join helper recorded as a def. This step does not write a TypeScript file for it. */
    export interface D1SupportHelper {
        helperId: string;
        session: 'verified';
        steps: D1SupportJoinStep[];
        consumers: string[];
    }
    export interface D1SupportEdge {
        id: string;
        type: string;
        dependsOn: string[];
    }
    /** One entity of the grant. The anchor's steps stay empty. Another entity is pending when no field reaches the anchor. */
    export interface D1EntityScopePath {
        entityId: string;
        steps: D1SupportJoinStep[];
        pending: string;
    }
    export interface D1ScopeResolution {
        grantId: string;
        actorRef: string;
        entityRefs: string[];
        disclosure: 'fieldsOnly' | 'fullRecord';
        allowedFields: string[];
        anchorEntity: string;
        /** The mode the access artifact declared. Never replaced by a permissive fallback. */
        scopeMode: string;
        session: 'verified';
        path: D1EntityScopePath[];
        pending: string;
        helperId: string;
    }
    export interface D1RegistryAdapter {
        portId: string;
        adapterArtifactId: string;
        factory: string;
        defPath: string;
        dependsOn: string[];
    }
    export interface D1PublicationItem {
        artifactType: string;
        defPath: string;
        outputPath: string;
        registers: string;
    }
    export interface D1PublicationLater {
        artifactType: string;
        defPath: string;
        reason: string;
    }
    /** Local table the seed plan may describe. An MDM table is refused. */
    export interface D1SeedTable {
        tableId: string;
        entityId: string;
        action: string;
        defPath: string;
        uniqueKeys: string[][];
    }
    export interface D1SeedTransition {
        transitionId: string;
        to: string;
        ruleRefs: string[];
    }
    /** Model facts the seed plan may cite. It does not invent rows from them. */
    export interface D1SeedModel {
        entityId: string;
        storageTarget: string;
        kind: 'role' | 'entity';
        namespace: string;
        fields: Array<{
            name: string;
            type: string;
        }>;
        states: string[];
        initialState: string;
        uniqueKeys: string[][];
        transitions: D1SeedTransition[];
        /** Empty when the model does not declare the note field. */
        noteField: string;
    }
    export interface D1SeedEffect {
        entityId: string;
        effect: string;
        transitionRef: string;
    }
    export interface D1SeedJourney {
        journeyId: string;
        entities: string[];
        effects: D1SeedEffect[];
    }
    /** A role or actor tag. It is not the MDM entity id. */
    export interface D1SeedRoleTag {
        tag: string;
        entityId: string;
    }
    export interface D1SeedRef {
        field: string;
        relationshipId: string;
        entityId: string;
    }
    export interface D1SeedDataset {
        datasetId: string;
        tableId: string;
        owners: string[];
    }
    export interface D1SeedDependency {
        entityId: string;
        kind: 'mdm' | 'module';
        seeded: false;
    }
    export interface D1SeedMaintenance {
        action: 'reseed' | 'reset' | 'removeOwner';
        ownerId: string;
    }
    /** Plan versus rows. This step never sets materialized or a row count above zero. */
    export interface D1SeedReport {
        phase: 'plan' | 'absent';
        materialized: false;
        rowCount: 0;
        datasets: D1SeedDataset[];
        dependencies: D1SeedDependency[];
    }
    /** One outbound event from the integration artifact. `mechanism` is empty when the artifact names none. */
    export interface D1EffectEvent {
        eventId: string;
        on: string;
        mechanism: string;
        /** True only when the transition object declares `payload`. */
        payloadDeclared: boolean;
    }
    /** A process, inbound item or plugin. Operations are not routes. */
    export interface D1EffectOperation {
        id: string;
        kind: 'process' | 'inbound' | 'plugin';
        operations: string[];
        mechanism: string;
        consumer: string;
        /** A scheduled trigger is preserved as a review. This step does not write a scheduler. */
        scheduled: boolean;
    }
    /** The measured publish API as evidence. Naming it does not bind or execute an effect. */
    export interface D1EffectReport {
        phase: 'plan' | 'absent';
        executed: false;
        capability: {
            symbol: typeof D1_MEASURED_PUBLISH.symbol;
            path: typeof D1_MEASURED_PUBLISH.path;
            owner: typeof D1_MEASURED_PUBLISH.owner;
            payload: typeof D1_MEASURED_PUBLISH.payload;
            delivery: typeof D1_MEASURED_PUBLISH.delivery;
            transaction: typeof D1_MEASURED_PUBLISH.transaction;
            requestContextPublish: false;
            bound: boolean;
        };
    }
    export interface D1SupportRequest {
        project: number;
        moduleName: string;
        grants: D1ControllerGrant[];
        relationships: D1ControllerRelationship[];
        /** Scope plans controllers60 already resolved. The anchor is not corrected here. */
        scopePlans: D1ScopeGrantPlan[];
        /** Grant ids cited by handlers. A missing id is a diagnosis, not a new grant. */
        citedGrantIds: string[];
        adapters: D1SupportAdapter[];
        files: D1SupportFile[];
        /** Helpers already on the draft. A helper stays while one live consumer remains. */
        existingHelpers: D1SupportHelper[];
        /** Edges already emitted by application defs. An adapter or registry edge is inverted. */
        applicationEdges: D1SupportEdge[];
        /** Form field names a contract offered as identity. They are not the session. */
        formFields: string[];
        enumerations: Array<{
            entityId: string;
            path: string;
            values: string[];
        }>;
        /** Local tables persistence40 planned. A role table is not a seed target. */
        tables: D1SeedTable[];
        models: D1SeedModel[];
        journeys: D1SeedJourney[];
        /** Journey ids the index names and this step could not read. */
        missingJourneys: string[];
        roleTags: D1SeedRoleTag[];
        /** Extra refs a caller proposed. A ref without a column relationship is refused. */
        seedRefs: D1SeedRef[];
        /**
         * Ontology, catalog and serialized defs already opened for this run.
         * Absent on a fixture that only classifies seed citations.
         */
        enumSnapshot?: {
            sources: Record<string, string>;
            definitions: string[];
            tables: Array<{
                tableId: string;
                entityId: string;
            }>;
        };
        /** Datasets already shared. Dropping one owner does not drop the dataset. */
        existingDatasets: D1SeedDataset[];
        /**
         * `backend.json.testSupport[]` (p1_12, backend v1.2), already checked by input20 (d1_39). Empty or
         * absent: the seeds def carries no certification fixture.
         */
        testSupport?: unknown[];
        /** Set when the backend plan changed after input20: its testSupport was not read. */
        testSupportUnread?: string;
        maintenance: D1SeedMaintenance | null;
        /** Outbound rows of the integration artifact. */
        outbound: D1EffectEvent[];
        /** Event ids input20 selected. A selected id missing here is an omission. */
        selectedEventIds: string[];
        /** Usecase ids the plan selected. An event consumer must be one of these. */
        usecaseIds: string[];
        /** Processes, inbound and plugins. A workflow does not become an endpoint. */
        operations: D1EffectOperation[];
    }
    export interface D1SupportEmit {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
        /** Set when status is blocked. The receipt, not the def, carries the reason. */
        blockReason?: string;
    }
    export interface D1SupportBuild {
        schemaVersion: typeof D1_SUPPORT_VERSION;
        project: number;
        moduleName: string;
        llmCalls: 0;
        ok: boolean;
        enumerations: D1SupportEnumeration[];
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        registry: D1RegistryAdapter[];
        publication: {
            stillToRegister: D1PublicationItem[];
            later: D1PublicationLater[];
        };
        /** Separates the seed plan from rows. Rows are not written here. */
        seedPlan: D1SeedReport;
        /** Effect plan. `executed` stays false. An empty mechanism stays unbound. */
        effectPlan: D1EffectReport;
        problems: D1SupportProblem[];
        normalizations: D1SupportNormalization[];
        emit: D1SupportEmit[];
    }
}
declare module "_102034_/l2/mdm/resolveMdmEntity" {
    /**
     * The reader of the ontology: it turns `l4/ontology/mdm.defs.ts` (the platform) and a module ontology in
     * the v3 form (`mls-<client>/l4/<module>/ontology/<Entity>.defs.ts`) into ONE view — the columns, the
     * `details` tree, the links, the capabilities and the rules of a single entity (ns5_39 T3).
     *
     * PURE ON PURPOSE. No `node:*`, no engine (`module.ts`, `mdmFacade.ts`, `persistence.ts`), no I/O: the
     * clarification screen imports this file in the browser and hands it two objects it already read.
     * `resolveMdmEntity.test.ts` asserts that purity against this file's own source, so it cannot rot.
     *
     * What it does NOT do: it does not validate. A divergence is reported ON the node (`conflict`,
     * `tightened`, `unresolved`) for the screen to show — never thrown, never silently repaired. The gate is
     * `ontology30`, and it is still v2 (out of scope here).
     */
    import type { MdmOntology, MdmSubtypeName } from "_102034_/l1/mdm/defs/ontologyTypes";
    import type { Ns5OntologyEntityV3, Ns5OntologyIndexV3, Ns5RulesAny } from "_102035_/l2/solution/types";
    /** How ready the platform is, read from the tail of the catalog sentence. A badge, never a gate. */
    export type OntologyPlatformStatus = 'ready' | 'partial' | 'missing';
    /** Who writes the field. `derived` wins over `platform`: the engine owns it, so no form may offer it. */
    export type OntologyOrigin = 'platform' | 'module' | 'derived';
    export interface OntologyValue {
        value: string;
        title: string;
    }
    export interface OntologyNode {
        /** Field id inside its parent. */
        id: string;
        /** Full path from the record root: `details.identification.name`, `scheduledAt`. */
        path: string;
        title: string;
        type: string;
        required: boolean;
        nullable: boolean;
        collection: boolean;
        derived: boolean;
        indexed: boolean;
        unique: boolean;
        /** Reusable value type of `mdm.types`. */
        of?: string;
        /** Records this field points at. */
        to?: readonly string[];
        values?: readonly OntologyValue[];
        /** Only on a branch of `details`. */
        owner?: 'platform' | 'organization' | 'module';
        /** The branch declares no closed key set (`general`, the module namespace on the platform side). */
        open?: true;
        description?: string;
        /** Only on a module view. */
        origin?: OntologyOrigin;
        /** The module declares a field the platform already owns under that branch, or an identity field
         * inside its own namespace (`rule-identity-never-in-namespace`). The screen warns. */
        conflict?: true;
        /** The module narrowed a closed domain the platform declares wider. Legitimate; shown as a note. */
        tightened?: true;
        children?: OntologyNode[];
    }
    export interface OntologyRelationshipView {
        /** The name the entity gave the link; on the platform view, the catalog type. */
        name: string;
        /** The row of the module index that carries it. Absent on the platform view. */
        relationshipId?: string;
        /** Catalog type (`GuardianOf`), or the column / table walked. */
        via: string;
        title: string;
        description?: string;
        /** The far end. */
        to: readonly string[];
        /** Which end of the link this entity sits on. */
        side: 'from' | 'to' | 'both';
        mode: 'fk' | 'throughTable' | 'mdmRelationship';
        cardinality?: string;
        required?: boolean | string;
        roles?: readonly string[];
        path?: string;
        derived?: true;
        /** Says how the entity and the module index disagree. The index is the source. */
        conflict?: string;
    }
    export interface OntologyCapabilityView {
        id: string;
        /** The catalog sentence for a platform id; the module sentence for a module id. */
        sentence: string;
        /** Only on a platform id: what the platform sentence says about itself. */
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        /** Only on a module view of a platform id: what the module says it uses it for. */
        moduleSentence?: string;
        /** The id is in no catalog. */
        unresolved?: true;
    }
    export interface OntologyRuleView {
        id: string;
        text: string;
        platform?: OntologyPlatformStatus;
        origin: 'platform' | 'module';
        unresolved?: true;
    }
    export interface OntologyTreeView {
        entityId: string;
        title: string;
        description: string;
        kind: 'platform' | 'role' | 'entity';
        /** The MDM subtype, on the platform view and on a role. */
        subtype?: string;
        displayField: string;
        /**
         * The top-level fields of the record OTHER than `details` — `details` is returned expanded below.
         * `{ id, version }` on an MDM record; on a module table also every indexed column.
         */
        columns: OntologyNode[];
        /** The branches of the document, in the order `record.fields.details.groups` declares. */
        details: OntologyNode[];
        relationships: OntologyRelationshipView[];
        capabilities: OntologyCapabilityView[];
        rules: OntologyRuleView[];
    }
    /** The badge, read from the tail of the catalog sentence. Absent when the sentence does not say. */
    export function readPlatformStatus(sentence: string): OntologyPlatformStatus | undefined;
    /**
     * The whole platform record of one subtype: `{ id, version }` plus the five branches of `details`, the
     * relationship types the subtype takes part in, and the capabilities and rules that reach it.
     *
     * `moduleId` names the module namespace branch; without it the branch keeps the placeholder key
     * `<moduleId>` the ontology itself uses.
     */
    export function resolvePlatformEntity(mdm: MdmOntology, subtype: MdmSubtypeName, moduleId?: string): OntologyTreeView;
    /**
     * The entity of a module, read against the platform it sits on.
     *
     * On a `role`, every node of `details` is marked `platform` / `module` / `derived` by comparing it with
     * the branch the platform declares; a module field that shadows a platform field — or any identity field
     * inside the module namespace — is flagged `conflict`. The capabilities and rules keep BOTH sentences:
     * the catalog's (what the platform does) and the module's (what the clinic uses it for). The links are
     * crossed with the module index, which is the source; a disagreement becomes `conflict` on the link.
     */
    export function resolveModuleEntity(entity: Ns5OntologyEntityV3, index: Ns5OntologyIndexV3, mdm: MdmOntology, moduleRules: Ns5RulesAny): OntologyTreeView;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/enumerations" {
    import { type D1EnumRow, type D1SeedCitation } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /** What the report looked at. A union or an owner is not runtime enforcement. */
    export const ENUMERATION_LIMITS: "Covered uses are a seed scenario that names this entity and path, and a domain or usecase def whose type names this path with those literals. A TypeScript union is not runtime enforcement. Ownership is not consumption. No seed, catalog or table is created here.";
    export interface D1EnumSnapshot {
        sources: Record<string, string>;
        definitions: string[];
        tables: Array<{
            tableId: string;
            entityId: string;
        }>;
    }
    export interface D1EnumInput {
        enumerations: ReadonlyArray<{
            entityId: string;
            path: string;
            values: readonly string[];
        }>;
        snapshot?: D1EnumSnapshot;
        seedCitations?: readonly D1SeedCitation[];
    }
    /**
     * Projects origin, restriction and proved uses for each enumeration.
     * Does not read the filesystem and does not invent a seed, a catalog or a table.
     */
    export function projectEnumerations(input: D1EnumInput): D1EnumRow[];
    /** The field a model's lifecycle states belong to, when exactly one enum has that value set. */
    export function lifecyclePath(entityId: string, states: readonly string[], enumerations: ReadonlyArray<{
        entityId: string;
        path: string;
        values: readonly string[];
    }>): string;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/gate" {
    import { type D1RegistryAdapter, type D1ScopeResolution, type D1EffectReport, type D1SeedCitation, type D1SeedReport, type D1SupportAdapter, type D1SupportBuild, type D1SupportEmit, type D1SupportHelper, type D1SupportNormalization, type D1SupportProblem, type D1SupportRequest } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /**
     * Registry, scope and the seed plan. No model call.
     * A grant keeps its declared mode, the verified session, the relationship path and any pending.
     * A missing grant or an anchor with no explicit path is a diagnosis.
     * It is not rewritten as organization or public.
     * Seeds describe scenarios. They do not write rows.
     * Effects name the consumer and keep an empty mechanism when none was declared.
     * Nothing is published.
     */
    export function buildD1Support(request: D1SupportRequest): D1SupportBuild;
    /** Access scope and the authority map. The map adds no grant. */
    export function emitScope(request: D1SupportRequest, problems: D1SupportProblem[]): {
        resolutions: D1ScopeResolution[];
        helpers: D1SupportHelper[];
        removedHelpers: string[];
        emit: D1SupportEmit[];
    };
    /** Live adapters only. The registry depends on them. They do not depend on it. */
    export function emitRegistry(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        adapters: D1RegistryAdapter[];
        live: D1SupportAdapter[];
        emit: D1SupportEmit[];
    };
    /**
     * One seed plan for the local tables. Journeys and models supply scenarios.
     * MDM roles are dependencies, not rows. A ref needs a column relationship.
     */
    export function emitSeeds(request: D1SupportRequest, problems: D1SupportProblem[], normalizations: D1SupportNormalization[]): {
        emit: D1SupportEmit[];
        plan: D1SeedReport;
        citations: D1SeedCitation[];
    };
    /**
     * One outbound def. Events keep the transition as consumer.
     * An empty mechanism stays empty. publishEvent and emitEvent are refused.
     * IQueueRuntime.publish is evidence, not an approved binding.
     * Processes, inbound and plugins stay operations. A scheduled trigger writes no scheduler.
     */
    export function emitEffects(request: D1SupportRequest, problems: D1SupportProblem[]): {
        emit: D1SupportEmit[];
        report: D1EffectReport;
    };
}
declare module "_102021_/l2/agentDefsL1/steps/support70/io" {
    import { type D1SelectedUsecase } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import { type D1EffectOperation, type D1SupportBuild, type D1SupportFile } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    export function assembleD1Support(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        build: D1SupportBuild;
        files: D1SupportFile[];
    }>;
    export function commitD1Support(project: number, build: D1SupportBuild, files: readonly D1SupportFile[]): Promise<{
        written: string[];
        issues: string[];
    }>;
    /** A support def is removed only when this build did not keep it for a live consumer. */
    export function supportFilesToRemove(build: D1SupportBuild, files: readonly D1SupportFile[]): D1SupportFile[];
    /** Inbound operations come from the L4 effect, never from a name built out of the entity. */
    export function inboundOperation(row: Record<string, unknown>, selected: readonly D1SelectedUsecase[]): D1EffectOperation | null;
}
declare module "_102021_/l2/agentDefsL1/steps/support70/agentD1Support" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1SupportPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/contracts" {
    import type { D1PipelineState, D1StepId } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    import type { D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1CallAccount, D1CallLog } from "_102021_/l2/agentDefsL1/steps/usecases50/callLog";
    import type { D1EnumOrigin, D1EnumUse } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    import type { PoolTraceLine } from "_102035_/l2/solution/pool";
    /**
     * v2: `consumed` means a covered consumer was proved for this entity and path.
     * It no longer means "every literal appeared in the seed set".
     * `origin` separates catalog owner, writer and restriction. `uses` names the consumer.
     */
    export const D1_REPORT_VERSION: "2026-09-24-d1-report-v3";
    /** Recognition by the inventory reader is not a runnable backend. */
    export const INVENTORY_NOTE: "Inventory recognition is not certification of an executable backend.";
    /** Product types and the step that writes them. Matching is by artifact type, not by file name. */
    export const PHASE_OF_TYPE: Record<string, D1StepId>;
    export const CHAIN_STEP_IDS: readonly ["entry10", "input20", "domain30", "persistence40", "usecases50", "controllers60", "support70"];
    export interface D1FinalizeChild {
        planId: string;
        status: string;
        artifactPath: string;
        present: boolean;
    }
    export interface D1FinalizeObserved {
        defPath: string;
        text: string | null;
        currentHash: string;
        /** Hash the write receipt expects now. Empty when this file has no such receipt. */
        receiptHash: string;
        action: string;
        ownerRefs: string[];
        unitDone: boolean;
    }
    export interface D1FinalizeContract {
        path: string;
        text: string | null;
        hash: string;
    }
    export interface D1FinalizeRequest {
        project: number;
        moduleName: string;
        pipeline: D1PipelineState;
        snapshot: D1InputSnapshot | null;
        sourceHashes: Record<string, string>;
        /** Texts opened for fidelity: snapshot sources and declared read dependencies. Not the usecase draft. */
        dependencyTexts: Record<string, string>;
        contracts: Record<string, D1FinalizeContract>;
        drafts: {
            domain30: unknown;
            persistence40: unknown;
            usecases50: unknown;
            controllers60: unknown;
            support70: unknown;
        };
        observed: D1FinalizeObserved[];
        /** Future output path → the `.ts` file is on disk. Absence is expected. */
        futurePresent: Record<string, boolean>;
        children: D1FinalizeChild[];
        /** Observations usecases50 recorded. Null when that folder was not written. */
        callLog: D1CallLog | null;
    }
    export interface D1FinalizePhase {
        stepId: D1StepId;
        executed: boolean;
        status: 'approved' | 'failed' | 'absent';
        error: string;
    }
    export interface D1FinalizeFinding {
        severity: 'error' | 'review';
        code: string;
        path: string;
        message: string;
        ownerRef: string;
    }
    export interface D1FinalizeFile {
        defPath: string;
        action: 'generated' | 'preserved' | 'removed' | 'notGenerated';
        ownerRefs: string[];
        sourceHash: string;
        phase: string;
    }
    export interface D1FinalizeEnum {
        entityId: string;
        path: string;
        /** Effective values declared by the module. Not the catalog. */
        values: string[];
        /** True when `uses` is non-empty. Not runtime enforcement. */
        consumed: boolean;
        origin: D1EnumOrigin;
        uses: D1EnumUse[];
        limits: string;
    }
    export interface D1FinalizePending {
        defPath: string;
        outputPath: string;
        present: boolean;
    }
    export interface D1FinalizeInventory {
        usecaseIds: string[];
        routes: string[];
        portIds: string[];
        tableIds: string[];
    }
    export interface D1FinalizeReport {
        schemaVersion: typeof D1_REPORT_VERSION;
        project: number;
        moduleName: string;
        /**
         * Receipts from the call log. Not a billing total and not a unit count.
         * `finalizeCalledModel` / `finalizeOpenedRepair` describe this step only.
         */
        calls: D1CallAccount;
        executableBackend: false;
        inventoryNote: typeof INVENTORY_NOTE;
        defsStatus: 'complete' | 'incomplete' | 'notRun';
        materialization: 'pending' | 'none';
        outcome: 'complete' | 'held';
        blocking: string;
        phases: D1FinalizePhase[];
        findings: D1FinalizeFinding[];
        /** Steps that declared enum values stay on the domain draft. */
        declaredNotConsumedBy: string[];
        enumerations: {
            consumed: D1FinalizeEnum[];
            notConsumed: D1FinalizeEnum[];
        };
        files: D1FinalizeFile[];
        sources: Array<{
            path: string;
            sha256: string;
            state: string;
        }>;
        materializationPending: D1FinalizePending[];
        coverage: {
            checked: boolean;
            gaps: string[];
        };
        inventory: D1FinalizeInventory;
        snapshotHash: string;
        /**
         * Pool trace of the l1 dispatches this agent consumed (optional transport, d1_38). Written
         * before each delete; absent when no dispatch was ever consumed. Not an authorization.
         */
        pool?: PoolTraceLine[];
    }
    export function parseFinalizeReport(text: string): D1FinalizeReport | null;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/gate" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the request. Does not call a model, does not open a repair, and does
     * not treat a missing future `.ts` as a missing def.
     */
    export function buildD1Finalize(request: D1FinalizeRequest): D1FinalizeReport;
    export function earlierHold(pipeline: D1FinalizeRequest['pipeline']): boolean;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/io" {
    import { type D1FinalizeReport, type D1FinalizeRequest } from "_102021_/l2/agentDefsL1/steps/finalize80/contracts";
    /**
     * Reads the checkpoint, the snapshot, the drafts and the defs on disk.
     * It does not run an earlier phase and it does not call a model.
     */
    export function assembleD1Finalize(project: number, moduleName: string): Promise<{
        refusal: string;
    } | {
        request: D1FinalizeRequest;
    }>;
    export function writeD1Report(project: number, moduleName: string, report: D1FinalizeReport): Promise<boolean>;
}
declare module "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterD1FinalizePromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentDefsL1/agentDefsL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentDefsL1/steps/entry10/agentD1Entry";
    import "_102021_/l2/agentDefsL1/steps/input20/agentD1Input";
    import "_102021_/l2/agentDefsL1/steps/domain30/agentD1Domain";
    import "_102021_/l2/agentDefsL1/steps/persistence40/agentD1Persistence";
    import "_102021_/l2/agentDefsL1/steps/usecases50/agentD1Usecases";
    import "_102021_/l2/agentDefsL1/steps/controllers60/agentD1Controllers";
    import "_102021_/l2/agentDefsL1/steps/support70/agentD1Support";
    import "_102021_/l2/agentDefsL1/steps/finalize80/agentD1Finalize";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaCatalog" {
    import type { D1StorageTarget } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Absence, type D1Catalog, type D1Justification, type D1MeasuredPlan } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    /**
     * Consulta declares storage.target moduleDatabase. The other four are kind role
     * and cite the MDM catalog. They have no local table.
     */
    export const AGENDA_ENTITY_STORAGE: Record<string, D1StorageTarget>;
    export const AGENDA_JUSTIFICATIONS: D1Justification[];
    export const AGENDA_ABSENCES: D1Absence[];
    export function agendaCatalog(plan: D1MeasuredPlan): D1Catalog;
}
declare module "_102021_/l2/agentDefsL1/examples/agendaClinicaExamples" {
    import { type D1Definition } from "_102021_/l2/agentDefsL1/helpers/d1Artifact";
    import { type D1Catalog, type D1MeasuredPlan, type D1PipelineItem } from "_102021_/l2/agentDefsL1/helpers/d1Refs";
    export interface D1Example {
        definition: D1Definition;
        pipeline: D1PipelineItem[];
    }
    export function agendaExamples(catalog: D1Catalog, plan: D1MeasuredPlan): D1Example[];
    /** The listConsulta example also points at L2 contracts. Those paths are not outputs of this catalog. */
    export function listConsultaWithContracts(example: D1Example): D1Example;
}
declare module "_102021_/l2/agentDefsL1/fixtures/fixtureDisk" {
    /** Client copies are stored as `.txt` so `scanImportRefs` does not compile them. */
    export function fixtureLogicalName(storedName: string): string;
    export function fixtureLogicalRel(rel: string): string;
    export function resolveFixtureFile(abs: string): string;
    export function restoreFixtureTree(root: string): void;
    export function copyFixtureSources(src: string, dest: string): void;
}
declare module "_102021_/l2/agentDefsL1/helpers/d1TestHost" {
    import type { D1FileInfo } from "_102021_/l2/agentDefsL1/helpers/d1Core";
    export interface StoredFile {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
        status: string;
        versionRef: string;
        content: string;
        updatedAt: string;
        getValueInfo: () => Promise<{
            content: string;
        }>;
        getContent: () => Promise<string>;
    }
    export interface TestHost {
        files: Record<string, StoredFile>;
        writes: string[];
        setProject: (project: number) => void;
    }
    export function fileKey(info: {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }): string;
    export function installStudio(project: number): TestHost;
    export function seed(host: TestHost, info: D1FileInfo, content: string, updatedAt?: string): StoredFile;
    /** Host stor whose diskPath closes over a private field. Detaching the method throws. */
    export class HostStor {
        #private;
        readonly files: Record<string, StoredFile>;
        readonly writes: string[];
        getKeyToFile(info: D1FileInfo): string;
        addOrUpdateFile(params: D1FileInfo & {
            status?: string;
        }): Promise<StoredFile>;
        readonly localStor: {
            setContent: (file: StoredFile, value: {
                content?: string | null;
            }) => Promise<boolean>;
            listFolder: (project: number, level: number, folder: string) => D1FileInfo[];
            deleteFile: (file: StoredFile) => void;
        };
        diskPath(info: D1FileInfo): string;
    }
    export function installClassHost(project: number, host: HostStor): void;
}
declare module "_102021_/l2/agentDefsL1/fixtures/readFixture" {
    import { type TestHost } from "_102021_/l2/agentDefsL1/helpers/d1TestHost";
    import type { D1InputArtifacts } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    /** Logical path (`.defs.ts`, `.json`) to the stored bytes. `SOURCE.md` is omitted. */
    export function loadD1Fixture(id: string): Readonly<Record<string, string>>;
    /**
     * The input20 artifacts of a stored seed, parsed as `assembleD1Input` would. Hashes are a
     * placeholder: a test that needs the real digest seeds the host instead (`seedD1Fixture`).
     */
    export function loadD1Artifacts(id: string, moduleName: string): D1InputArtifacts;
    /** Writes a stored seed into the in-memory Studio host at its logical paths. */
    export function seedD1Fixture(host: TestHost, id: string, project: number): string[];
}
declare module "_102021_/l2/agentDefsL1/fixtures/agendaClinica-f35e28a/root" {
    export const AGENDA_CLINICA_F35E28A: string;
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/fixtures/v1Contracts" {
    import type { D1ContractSource, D1ControllerRoute } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    /** One contract file per page. listConsulta is two shapes. A wide unused interface is not a binding. */
    export function contractSources(moduleName: string, routes: readonly D1ControllerRoute[]): D1ContractSource[];
    /** Type assertion instead of an input/output symbol. Not a projection. */
    export const V1_ASSERTION_CONTRACT = "\n    export interface Wide { id: string; attendanceNote: string; }\n    export const routes = { \"agendaClinica.consultas.qryListConsulta\": value as Wide } as const;\n  ";
    /** A form field named actorId is not the session. */
    export const V1_FORM_CONTRACT = "\n    export interface In { actorId: string; }\n    export interface Out { id: string; }\n    export const routes = { \"agendaClinica.agenda.qryListConsulta\": { input: \"In\", output: \"Out\" } } as const;\n  ";
}
declare module "_102021_/l2/agentDefsL1/steps/controllers60/fixtures/cases" {
    import type { D1InputArtifacts, D1InputSnapshot } from "_102021_/l2/agentDefsL1/steps/input20/contracts";
    import type { D1ControllerRequest } from "_102021_/l2/agentDefsL1/steps/controllers60/contracts";
    export { contractSources } from "_102021_/l2/agentDefsL1/steps/controllers60/fixtures/v1Contracts";
    /** input20 over a stored v2 seed. */
    export function seedSnapshot(id: string, moduleName: string): {
        snapshot: D1InputSnapshot;
        artifacts: D1InputArtifacts;
    };
    /**
     * The controllers60 request io.ts would assemble from that snapshot: page actors from needs,
     * grants from access, relationships from the ontology index, and the v2 contracts as stored.
     */
    export function seedControllerRequest(id: string, moduleName: string): D1ControllerRequest;
    /**
     * Agenda v1 entry still imported by skipped tests. Not a v2 source; never called by a live test.
     */
    export function coreControllerRequest(): D1ControllerRequest;
}
declare module "_102021_/l2/agentDefsL1/steps/domain30/fixtures/cases" {
    /** Synthetic ontologies. They are not a product module. Ids are exact and local to each case. */
    export const cycleEntities: {
        Alpha: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
        Beta: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    back: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    export const missingRefEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    export const ambiguousRefEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    other: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
    };
    /** A string whose name ends in Id is not a reference. A record points at Target by `to`. */
    export const suffixEntities: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    targetId: {
                        type: string;
                    };
                    link: {
                        type: string;
                        to: string[];
                    };
                };
            };
        };
        Target: {
            entityId: string;
            kind: string;
            source: string;
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** Nested object stays on the owner. One business value stays an enum. */
    export const nestedEnumEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    details: {
                        type: string;
                        fields: {
                            note: {
                                type: string;
                            };
                            subtype: {
                                type: string;
                                values: {
                                    value: string;
                                }[];
                            };
                        };
                    };
                };
            };
        };
    };
    /** Same dotted path from a literal key and from a real nest. */
    export const fieldCollisionEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    'details.note': {
                        type: string;
                    };
                    details: {
                        type: string;
                        fields: {
                            note: {
                                type: string;
                            };
                        };
                    };
                };
            };
        };
    };
    export const timeEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            lifecycleStates: {
                state: string;
                reachedBy: string;
            }[];
            transitions: {
                transitionId: string;
                from: string[];
                to: string;
                by: string[];
                ruleRefs: string[];
            }[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** Time state kept, and not written by a transition. */
    export const timeKeptEntity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            rules: string[];
            lifecycleStates: {
                state: string;
                reachedBy: string;
            }[];
            transitions: any[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    /** An NS4 field list is not rewritten into the v3 map. */
    export const ns4Entity: {
        Holder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            fields: {
                fieldId: string;
                type: string;
            }[];
            record: {
                fields: any[];
            };
        };
    };
    export const sharedCatalog: {
        rules: {
            'rule-foreign-namespace-refused': string;
        };
    };
    export const platformRole: {
        PersonRole: {
            entityId: string;
            kind: string;
            source: string;
            rules: string[];
            record: {
                fields: {
                    id: {
                        type: string;
                        derived: boolean;
                    };
                };
            };
        };
    };
    export const moduleRulesWithCamelTwin: {
        rules: {
            ruleForeignNamespaceRefused: string;
            openOnly: string;
        };
    };
}
declare module "_102021_/l2/agentDefsL1/steps/persistence40/fixtures/cases" {
    /**
     * Physical names measured on the buildFlowFsm change-order defs:
     * the table says `change_order` and the adapter citation says `change_orders`.
     * The pair is the fixture. It is not a finding against another generator.
     */
    export const MEASURED_TABLE_NAME = "change_order";
    export const MEASURED_TABLE_REF = "change_orders";
    export const changeOrderEntity: {
        ChangeOrder: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
                table: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                        indexed: boolean;
                    };
                    title: {
                        type: string;
                        required: boolean;
                    };
                };
            };
        };
    };
    /** Nested nullable `details.note`, plus a derived `version` that is not indexed. */
    export const noteEntity: {
        Note: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
                table: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                        indexed: boolean;
                    };
                    version: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                    };
                    details: {
                        type: string;
                        required: boolean;
                        fields: {
                            note: {
                                type: string;
                            };
                        };
                    };
                };
            };
        };
    };
    export const roleEntity: {
        PersonRole: {
            entityId: string;
            kind: string;
            storage: {
                target: string;
            };
            record: {
                fields: {
                    id: {
                        type: string;
                        required: boolean;
                        derived: boolean;
                    };
                };
            };
        };
    };
}
declare module "_102021_/l2/agentDefsL1/steps/support70/fixtures/cases" {
    import type { D1SupportAdapter, D1SupportRequest } from "_102021_/l2/agentDefsL1/steps/support70/contracts";
    /**
     * Measured from the frozen agendaClinica controller fixture: 7 grants, 1 live adapter.
     * The scope plans are the ones controllers60 already resolved. The anchor is not corrected.
     */
    export function coreSupportRequest(): D1SupportRequest;
    /**
     * Measured from the frozen agendaClinica journeys and Consulta model.
     * Four roles stay MDM. Only Consulta is a local table. No row values are present in the sources.
     */
    export function agendaSeedRequest(): D1SupportRequest;
    export function consultaAdapter(moduleName: string): D1SupportAdapter;
    export function adapterPipelineId(project: number, moduleName: string, portId: string): string;
}
declare module "_102021_/l2/agentDefsL1/steps/usecases50/fixtures/cases" {
    import type { D1UsecasePlanInput, D1UsecaseRequest, D1UsecaseSelection } from "_102021_/l2/agentDefsL1/steps/usecases50/contracts";
    export function frozenRouteCount(): number;
    export function coreUsecaseRequest(): D1UsecaseRequest;
    /** Fixture steps. registrarAtendimento does not invent an attendanceNote payload. */
    export function fixturePlan(request: D1UsecaseRequest, usecase: D1UsecaseSelection): D1UsecasePlanInput;
}
declare module "_102021_/l2/agentMaterializeL1/core/registry" {
    /**
     * Closed handler registry. This file is the only integrator: m1_03, m1_06 and m1_07
     * deliver a MaterializeHandler; wiring it stays here. A type with no named entry is
     * blocked by the planner. Nothing in this module writes a file.
     */
    import { type M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_HANDLER_STAGES: readonly ["structure", "implement"];
    export type M1HandlerStage = typeof M1_HANDLER_STAGES[number];
    /** Platform capabilities a handler may ask the context resolver to load. MDM catalog is not one of them. */
    export const M1_CONTEXT_CAPABILITIES: readonly ["requestContext", "dataRuntime", "tableDefinition", "repositoryRegistry", "mdmFacade"];
    export type M1ContextCapability = typeof M1_CONTEXT_CAPABILITIES[number];
    export interface MaterializeHandler {
        readonly id: string;
        readonly artifactType: M1ArtifactType;
        readonly stage: M1HandlerStage;
        /** False means the recipe is local. Simulate never calls a model for this handler. */
        readonly needsLlm: boolean;
        readonly capabilities: readonly M1ContextCapability[];
    }
    /** Implement recipes. A type missing here has no fallback onto the structure scaffolder. */
    export const M1_IMPLEMENT_HANDLERS: Partial<Record<M1ArtifactType, MaterializeHandler>>;
    export const M1_STRUCTURE_HANDLERS: Readonly<Record<M1ArtifactType, MaterializeHandler>>;
    export function handlerFor(type: string, stage?: M1HandlerStage): MaterializeHandler | null;
    export function registeredHandlerIds(stage?: M1HandlerStage): string[];
}
declare module "_102021_/l2/agentMaterializeL1/context/context" {
    /**
     * Context by artifact type and capability. Paths are real 102034 sources.
     * The MDM catalog (`l4/ontology/mdm.defs.ts`) is a dependency file, not a stand-in
     * for RequestContext or mdmFacade. Domain declarations get no facade.
     * A definition source and a compiled TypeScript signature are different functions:
     * compiledSignature refuses a v2 def.
     */
    import { type M1ArtifactType, type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1ContextCapability } from "_102021_/l2/agentMaterializeL1/core/registry";
    export const PLATFORM_FILES: Record<M1ContextCapability, string>;
    export function usesMdm(data: Record<string, unknown>): boolean;
    /** Platform files for a named type. Unknown types get nothing — not the full bundle. */
    export function platformFilesFor(type: M1ArtifactType, data?: Record<string, unknown>): string[];
    export function platformFilesForDefinition(definition: M1Definition): string[];
    /**
     * Compiled signature of a TypeScript file. A v2 definition source is not a signature,
     * even when it contains `export const`.
     */
    export function compiledSignature(source: string): string | null;
    export interface ContextEntry {
        ref: string;
        role: 'platform' | 'def' | 'compiled';
        state: 'read' | 'inaccessible';
        sha256: string | null;
        /** Present only for role `compiled` when the bytes are a real signature. */
        signature: string | null;
    }
    export function renderPrompt(entries: readonly ContextEntry[], unresolved: readonly string[]): string;
}
declare module "_102021_/l2/agentMaterializeL1/core/io" {
    /** Read port for simulate. There is no write, delete, migrate or model method on purpose. */
    export interface MaterializeReadIo {
        read(ref: string): Promise<string | null>;
    }
    export function contentHash(value: string): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/testing/catalog" {
    /**
     * Scenario catalog for one module. The monitor imports the rendered module
     * (export `scenarioCatalog` only). The sibling test file of each unit carries
     * the same scenario as data (`renderScenarioTest`); nothing here runs a case.
     */
    import type { M1ArtifactType } from "_102021_/l2/helpers/l1Defs/definition";
    import type { M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    export const M1_CATALOG_SCHEMA: "2026-09-25-m1-scenario-catalog-v1";
    /** Additive: each case names its runner, and a route case names its caller. */
    export const M1_CATALOG_SCHEMA_V11: "2026-09-26-m1-scenario-catalog-v1.1";
    export const M1_CATALOG_SCHEMAS: readonly ["2026-09-25-m1-scenario-catalog-v1", "2026-09-26-m1-scenario-catalog-v1.1"];
    export type M1CatalogSchema = typeof M1_CATALOG_SCHEMAS[number];
    /** Positive case of an operation that addresses one stored record. */
    export const M1_EXISTING_RECORD = "existing record";
    export const M1_CATALOG_EXPORT: "scenarioCatalog";
    /** Config key x1_02 will read. It is not `frontend.pageTests`. */
    export const M1_CATALOG_CONFIG_KEY: "backend.scenarioCatalog";
    /** Provisional stub from the structure handler. Business expectations do not use this code. */
    export const M1_STUB_ERROR: "USECASE_NOT_IMPLEMENTED";
    export const M1_STUB_STATUS = 501;
    export const M1_GATES: readonly ["compile", "contract", "auth", "business"];
    export type M1Gate = typeof M1_GATES[number];
    export interface M1SyntheticRow {
        entity: string;
        id: string;
        professionalId: string;
        patientId: string;
        scheduledAt: string;
        status: string;
        version: number;
        attendanceNote: string;
    }
    export interface M1ExpectedFailure {
        caseId: string;
        stage: 'structure';
        errorCode: typeof M1_STUB_ERROR;
        status: typeof M1_STUB_STATUS;
    }
    /** Definitive assertion. A repair is not allowed to change it. */
    export interface M1CaseExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        forbiddenFields: string[];
        /** When set, every returned row must carry this actor id. Shape alone does not pass. */
        isolatedActorField: string | null;
    }
    export type M1CaseRunner = 'route' | 'module';
    /** Present only on a route case. Authorities come from the grant, not from the case id. */
    export interface M1CaseCaller {
        source: 'http';
        authorities: string[];
    }
    export interface M1ScenarioCase {
        caseId: string;
        gate: M1Gate;
        mandatory: true;
        source: string;
        expectation: string;
        preconditions: string[];
        synthetic: M1SyntheticRow[];
        actorId: string;
        routine: string;
        mutating: boolean;
        expect: M1CaseExpect;
        expectedFailure: M1ExpectedFailure | null;
        /** Absent on a v1 catalog. */
        runner?: M1CaseRunner;
        /** Absent on a module case and on a v1 catalog. */
        caller?: M1CaseCaller;
    }
    export interface M1Scenario {
        scenarioId: string;
        source: string;
        artifactType: M1ArtifactType;
        artifactId: string;
        handlerId: string;
        productionFile: string;
        testFile: string;
        cases: M1ScenarioCase[];
    }
    export interface M1ScenarioCatalog {
        schemaVersion: M1CatalogSchema;
        moduleName: string;
        store: 'memory';
        scenarios: M1Scenario[];
    }
    export interface M1CatalogParse {
        catalog: M1ScenarioCatalog | null;
        issues: string[];
    }
    export interface M1RepairProposal {
        caseId: string;
        ok?: boolean;
        status?: number;
        errorCode?: string | null;
        ruleId?: string | null;
        dropForbiddenFields?: readonly string[];
        clearActorFilter?: boolean;
        dropExpectedFailure?: boolean;
        replaceExpectedFailure?: {
            errorCode: string;
            status: number;
        };
    }
    export function canonicalJson(value: unknown): string;
    export function extractCatalogJson(source: string): string | null;
    export function parseCatalog(source: string): M1CatalogParse;
    /** Implement removes the provisional mark. This is not a repair. */
    export function catalogForStage(catalog: M1ScenarioCatalog, stage: M1HandlerStage): M1ScenarioCatalog;
    /**
     * Drops a rule or a filter from a copy of the case. Used only to prove the
     * original assertion fails when that rule is absent. Repair refuses the same edit.
     */
    export function withoutRule(item: M1ScenarioCase, ruleId: string): M1ScenarioCase;
    export function repairRefusal(item: M1ScenarioCase, proposal: M1RepairProposal): string[];
    export function applyRepair(catalog: M1ScenarioCatalog, proposal: M1RepairProposal): {
        catalog: M1ScenarioCatalog;
        refused: string[];
    };
    export function renderMonitorCatalog(catalog: M1ScenarioCatalog, fileReference: string): string;
    /** Qualified file or import (`_NNNNN_/…` or `/_NNNNN_/…`) as `/_NNNNN_/….js`. Anything else is refused. */
    export function moduleSpecifier(file: string): string;
    /** Export of the per-unit `.test.ts`: that unit's scenario, as data. */
    export const M1_TEST_EXPORT: "scenarioCases";
    /**
     * The per-unit `.test.ts` is data: the scenario the monitor runs from the module catalog
     * (`backend.scenarioCatalog`). No import, no runner, nothing executes when it loads, so it
     * compiles in the Studio like any other module (conduta 28/09, rule 4).
     */
    export function renderScenarioTest(scenario: M1Scenario): string;
    /** A test this agent rendered before m1_35: a node runner bound to the catalog. It is rewritten, never kept. */
    export function isLegacyNodeTest(text: string, testFile: string): boolean;
    export function testFileFor(productionFile: string): string;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/gate" {
    export const FORBIDDEN_ACTOR = "FORBIDDEN_ACTOR";
    export const VALIDATION_ERROR = "VALIDATION_ERROR";
    export const GRANT_ABSENT = "GRANT_ABSENT";
    export const SESSION_UNVERIFIED = "SESSION_UNVERIFIED";
    export const SCOPE_UNBOUND = "SCOPE_UNBOUND";
    export const REPOSITORY_NOT_IMPLEMENTED = "REPOSITORY_NOT_IMPLEMENTED";
    /** A controller with grants and no readable authority map is not emitted. */
    export const AUTHORITY_UNREAD = "AUTHORITY_UNREAD";
    /** A grant the authority map does not name has no actor: the route is refused. */
    export const AUTHORITY_UNMAPPED = "AUTHORITY_UNMAPPED";
    export interface StructureGrant {
        grantId: string;
        actorRef: string;
        scopeMode: string;
        session: string;
        pending: string;
        disclosure: string;
        /** Record field taken from the grant path. Empty when that path does not resolve. */
        recordField?: string;
    }
    export interface GateInput {
        source: 'http' | 'message' | 'test';
        authorities: readonly string[];
        grantIds: readonly string[];
        grants: readonly StructureGrant[];
        /** Authority map entries. The actor of a grant comes from here, not from the scope. */
        authority: readonly {
            grantId: string;
            actorRef: string;
        }[];
        params: unknown;
        requiredFields: readonly string[];
    }
    export interface GateDecision {
        ok: boolean;
        status: number;
        errorCode: string | null;
        reachedUsecase: boolean;
    }
    export function resolveGrant(grants: readonly StructureGrant[], grantId: string): StructureGrant | {
        code: string;
        detail: string;
    };
    export function missingField(params: unknown, fields: readonly string[]): string;
    /** Same order the emitted controller uses. A stub result means both gates passed. */
    export function decideRoute(input: GateInput): GateDecision;
    export function stubDecision(): GateDecision;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/emit" {
    /**
     * Renders one structure file from a v2 def. Imports are only platform files,
     * an existing l2 contract, or the output of a dependency. A missing source
     * is a named failure, not an import of a file that does not exist.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type StructureGrant } from "_102021_/l2/agentMaterializeL1/handlers/structure/gate";
    /** Raised when the structure handler body changes. An older receipt is a new input. */
    export const STRUCTURE_HANDLER_RECIPE = "2026-10-01-structure-handler-v10";
    export interface EmitFailure {
        code: string;
        detail: string;
    }
    export interface EmitResult {
        source: string;
        runsStub: boolean;
        imports: string[];
    }
    export type StructureRead = (ref: string) => Promise<string | null>;
    /**
     * `optional` names the field paths a stored record may lack; without it every field is required.
     * `enums` maps a field path to the values its source declares; an `enum` field without values stays `string`.
     * The lifecycle states type the entity's single top-level `enum` field.
     */
    export function emitDomain(definition: M1Definition, output: string, optional?: ReadonlySet<string>, enums?: ReadonlyMap<string, readonly string[]>): EmitResult;
    export function emitValueObject(definition: M1Definition, output: string): EmitResult;
    export function emitPort(definition: M1Definition, output: string): EmitResult | EmitFailure;
    export function emitAccess(definition: M1Definition, output: string): EmitResult;
    export function emitAuthority(definition: M1Definition, output: string): EmitResult;
    export function emitUsecase(definition: M1Definition, output: string, read: StructureRead): Promise<EmitResult | EmitFailure>;
    export function emitController(definition: M1Definition, output: string, read: StructureRead, moduleDefinitions?: readonly unknown[]): Promise<EmitResult | EmitFailure>;
    /** Grant and required fields of one v2 route. The adapter names a service function, not a usecase. */
    export function adapterRouteFacts(definition: M1Definition, handler: Record<string, unknown>, read: StructureRead): Promise<{
        grantIds: string[];
        requiredFields: string[];
    } | EmitFailure>;
    /**
     * One function per request, keyed by the route. A command resolves repositories on the
     * transaction runtime: the adapter binds `ctx.data.moduleData` when the factory runs.
     * `outputs[].page`, `pageSize` and `hasMore` are the contract pagination keys when the def has them.
     */
    export function emitRequestService(definition: M1Definition, output: string, read: StructureRead, moduleDefinitions: readonly unknown[], stage: 'structure' | 'implement'): Promise<EmitResult | EmitFailure>;
    /** Value bindings the structure emitters write. Types are not included. */
    export function emittedValueExports(definition: M1Definition): readonly string[];
    export function importSpecifier(defPath: string, kind: 'output' | 'defs'): string;
    export function auditImports(source: string, allowed: readonly string[]): string;
    export function grantsOf(data: Record<string, unknown>): StructureGrant[];
    /** The single path hop of the one non-anchor entity names the record field. A missing or contradictory path does not. */
    export function recordFieldFromGrant(grant: Record<string, unknown>): string;
    export function contractMembers(source: string, name: string): {
        requiredFields: string[];
        allowedFields: string[];
        allowedPaths: string[];
    } | null;
    /** Member paths of `name` whose declared type admits `null`. */
    export function contractNullablePaths(source: string, name: string): string[] | null;
    export function requiredMembers(source: string, name: string): string[] | null;
    /** The l4 entity a domain def types against: its ontology dependency, else the module's ontology file. */
    export function ontologyRef(definition: M1Definition, output: string): string;
    /** Enum values the l4 entity declares per field path, walking nested `fields`; empty when unreadable. */
    export function ontologyEnums(source: string | null): Map<string, string[]>;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/behavior/emitBehavior" {
    /**
     * Replaces a structure stub with behavior derived from the defs.
     * List copies the operation, the port and the entity fields. Create stores only the
     * server assignments and the input members the caller sent (absence is kept).
     * A transition copies lifecycle from/to, the selector and the payload paths.
     * A local storage row is the unique-key check. A payload path is required
     * when one local rule names that path. A leftover local rule is not emitted
     * when the route grant is an unresolved own-scope: that case stays blocked.
     * A pending rule row is not emitted. Events stay in a declared list and are
     * not published. A duplicate slot in this store is not a PostgreSQL atomic
     * constraint. A version the contract does not declare is not invented.
     * An MDM usecase walks `mdm.calls` in order. `expectedVersion` is emitted
     * only when a depended ontology field is `writePrecondition` and the
     * operation input carries that path. Create runs only when its `when` says
     * the prior find missed. No new facade is written.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type EmitFailure, type EmitResult, type StructureRead } from "_102021_/l2/agentMaterializeL1/handlers/structure/emit";
    /** Raised when the implement handler body changes. An older receipt is a new input. */
    export const IMPLEMENT_HANDLER_RECIPE = "2026-10-01-implement-handler-v10";
    export const STORAGE_MARK = "// enforce:storage";
    export const PAYLOAD_MARK = "// enforce:payload";
    export const VERSION_MARK = "// enforce:version";
    export const CREATE_MARK = "// enforce:create";
    export const OWN_MARK = "// enforce:own";
    export interface CaseBlock {
        gap: string;
        owner: string;
        ruleId: string;
        unread: boolean;
    }
    export function isDerivedMdm(definition: M1Definition): boolean;
    export function behaviorNeedsLlm(definition: M1Definition): boolean;
    export function withoutStorageChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutPayloadChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutLifecycleChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutVersionChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutScopeChecks(source: string): {
        source: string;
        removed: number;
    };
    export function withoutCreateChecks(source: string): {
        source: string;
        removed: number;
    };
    export function caseBlock(definition: M1Definition, defPath: string, item: {
        routine: string;
        expect: {
            ruleId: string | null;
        };
    }, read: StructureRead): Promise<CaseBlock | null>;
    /** A lifecycle or payload rule is proved by calling the usecase, not the route. */
    export function ruleRunsOnUsecase(definition: M1Definition, ruleId: string, read: StructureRead): Promise<boolean>;
    export function emitBehavior(id: string, definition: M1Definition, output: string, read: StructureRead, moduleDefinitions?: readonly unknown[]): Promise<EmitResult | EmitFailure>;
    export function contractRoutes(definition: M1Definition): string[];
    /**
     * The lifecycle field is the single top-level enum of an entity that declares transitions.
     * Its initial state is the one declared state no transition reaches; otherwise it is ''.
     */
    export function lifecycleStart(definition: M1Definition): {
        field: string;
        initial: string;
    };
}
declare module "_102021_/l2/agentMaterializeL1/state/maintain" {
    /**
     * Maintenance decisions. The store port in core/state.ts stays frozen.
     * `running` is a receipt stage, never a fifth definition status.
     *
     * Who writes status:
     * - pending: D1, when it creates or changes semantics. M1, when the output is
     *   missing or stale and the old status is not evidence. A stub stays pending.
     * - generated: M1, only after the output file, the receipt and the passing
     *   verifications are already durable.
     * - blocked: M1, when a concrete source or external decision is missing.
     *   The reason is on the receipt. Only dependents of that unit are held.
     * - failed: M1, when the repair budget ends without a passing result.
     *   Resume does not zero that budget and does not repeat the exhausted cycle
     *   until the semantic input changes.
     *
     * Local rename of one file is atomic on one filesystem. The output, the receipt
     * and the definition status are three files, so a crash between them is visible.
     * Studio stor has no compare-and-swap and no multi-file transaction. This module
     * does not claim a remote CAS.
     */
    import { type M1Definition, type M1Status, type MaterializationReceipt } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_RECIPE_VERSION: "2026-09-25-m1-recipe-v1";
    /** Receipts store the recipe of the handler stage that wrote them. */
    export function recipeForStage(stage: 'structure' | 'implement'): string;
    export const M1_OWNED_SCHEMA: "2026-09-25-m1-owned-v1";
    export const M1_WRITER_SCHEMA: "2026-09-25-m1-writer-v1";
    export const WRITE_BOUNDARIES: readonly ["before-promote", "staging", "output", "receipt", "status"];
    export type WriteBoundary = typeof WRITE_BOUNDARIES[number];
    export interface OwnedEntry {
        defPath: string;
        outputs: string[];
    }
    export interface OwnedManifest {
        schemaVersion: typeof M1_OWNED_SCHEMA;
        moduleName: string;
        units: OwnedEntry[];
        /** Catalog path M1 last wrote. Absent on manifests from before that record existed. */
        catalogRef?: string;
        /** Canonical hash of that catalog. A different file is a hand edit, not a stale ledger. */
        catalogHash?: string;
    }
    export interface WriterRecord {
        schemaVersion: typeof M1_WRITER_SCHEMA;
        moduleName: string;
        holder: string;
    }
    export interface MaintenanceInput {
        definition: M1Definition;
        /** Semantic hash of the def, status excluded. */
        semantic: string;
        receipt: MaterializationReceipt | null;
        dependencyHashes: Readonly<Record<string, string>>;
        outputPath: string;
        outputPresent: boolean;
        outputHash: string | null;
        /** Null skips the recipe comparison. A value that differs from the receipt invalidates. */
        recipeVersion: string | null;
        /** Structure evidence is not an implement skip. Implement reuses only a verify receipt. */
        stage: 'structure' | 'implement';
        hasImplementHandler: boolean;
        unresolved: readonly string[];
        testPath: string;
        testHash: string | null;
        /** Hash of the catalog recorded on the previous M1 run. Null when there is no receipt. */
        recordedCatalogHash?: string | null;
        /** Hash of the catalog derived for this run. Null when the run has no catalog. */
        catalogHash?: string | null;
        verifyOnly: boolean;
    }
    export interface MaintenanceDecision {
        action: 'generate' | 'reuse' | 'verify' | 'blocked' | 'conflict';
        reason: string;
    }
    export function stagingRef(moduleName: string, outputRef: string): string;
    export function ownedManifestRef(moduleName: string): string;
    export function writerRef(moduleName: string): string;
    /** Holder written in a writer or project-lock file. '' when absent or unreadable. */
    export function lockHolder(text: string | null): string;
    /** Refusal text of a held writer or lock: which file, which holder, what to remove when no run is active. */
    export function busyDetail(ref: string, text: string | null): string;
    /** Hash a dependency or source. A v2 def hashes the canonical body, so status alone does not cascade. */
    export function hashEvidence(text: string): Promise<string>;
    /**
     * Replace the single envelope status and leave every other byte alone.
     * Returns null when the source is not a def or the status field is not unique.
     */
    export function replaceStatus(source: string, status: M1Status): string | null;
    export function statusForPromotion(accepted: boolean, scaffold: boolean): M1Status | null;
    /**
     * Generated without an intact output is not a skip. Pending forces work.
     * A hand-edited output is a local conflict: dependents are not invalidated by it.
     * A test-only change asks verify. A recipe change asks generate, unless the
     * output was hand-edited, which still wins.
     */
    export function decideMaintenance(input: MaintenanceInput): Promise<MaintenanceDecision>;
    /**
     * A failed receipt is checked again when the catalog or the test hash moved.
     * The same catalog and the same test stay failed. This does not clear another unit's budget.
     */
    export function failureNeedsReverify(receipt: MaterializationReceipt, testPath: string, testHash: string | null, recordedCatalogHash: string | null, catalogHash: string | null): boolean;
    export function selectRemoval(owned: readonly string[], requested: readonly string[]): {
        remove: string[];
        keep: string[];
    };
    export function parseOwnedManifest(text: string, moduleName: string): OwnedManifest | null;
    export function renderOwnedManifest(manifest: OwnedManifest): string;
    export function parseWriterRecord(text: string): WriterRecord | null;
    /** Reverse closure: units that depend on `changed`, directly or further down. */
    export function reverseClosure(changed: readonly string[], dependents: ReadonlyMap<string, readonly string[]>): string[];
}
declare module "_102021_/l2/agentMaterializeL1/planner/plan" {
    /**
     * Plan by declared file references, not by directory order and not by a fixed layer rank.
     * A type with no named handler is blocked, except implement: a type that already
     * has a structure or persistence output is reused. Reuse and verify read bytes and do not write.
     */
    import { type KnownArtifact, type MaterializationReceipt } from "_102021_/l2/helpers/l1Defs/definition";
    import { type MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import { type M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    export const M1_PLAN_ACTIONS: readonly ["generate", "reuse", "verify", "blocked", "remove", "conflict"];
    export type M1PlanAction = typeof M1_PLAN_ACTIONS[number];
    export const PLAN_REASON: {
        readonly noNamedHandler: "NO_NAMED_HANDLER";
        readonly cycle: "CYCLE";
        readonly missingRef: "MISSING_REF";
        readonly ambiguousRef: "AMBIGUOUS_REF";
        readonly relativeWithoutProject: "RELATIVE_WITHOUT_PROJECT";
        readonly noConsumer: "NO_CONSUMER";
        readonly mechanismUnbound: "MECHANISM_UNBOUND";
        readonly contextUnread: "CONTEXT_UNREAD";
        readonly blockedBy: "BLOCKED_BY";
        readonly definition: "DEFINITION";
        readonly generate: "GENERATE";
        readonly reuse: "REUSE";
        readonly verify: "VERIFY";
        readonly remove: "REMOVE";
    };
    /** A unit is a def under `l1/<module>/`. A def outside that tree is only a dependency source. */
    export function isL1ModuleDef(defPath: string): boolean;
    export interface PlanUnitInput {
        defPath: string;
        definition: unknown;
    }
    export interface PlanInput {
        stage?: M1HandlerStage;
        units: readonly PlanUnitInput[];
        /** Qualified refs the host could read. Unit def paths count as present. */
        readable: readonly string[];
        /** Artifacts that are not units (external entities the refs must still resolve). */
        extraArtifacts?: readonly KnownArtifact[];
        receipts?: ReadonlyMap<string, MaterializationReceipt | null>;
        outputsPresent?: readonly string[];
        verifyOnly?: readonly string[];
        /** Def paths that left the set. A path that is still a unit is not removed. */
        removals?: readonly string[];
        dependencyHashes?: Readonly<Record<string, string>>;
        /** Read port. Reuse and verify compare output bytes through it; there is no write. */
        io?: MaterializeReadIo;
        /** When set, a receipt recipe that differs invalidates the unit. */
        recipeVersion?: string | null;
        testHashes?: Readonly<Record<string, string>>;
    }
    export interface PlannedUnit {
        defPath: string;
        artifactType: string;
        artifactId: string;
        action: M1PlanAction;
        reason: string;
        handlerId: string | null;
        needsLlm: boolean;
        unresolved: string[];
        contextRefs: string[];
        blockedBy: string[];
        /** Action before a dependency block. Restored when that dependency passes in the same run. */
        heldAction?: M1PlanAction;
    }
    export interface MaterializationPlan {
        stage: M1HandlerStage;
        order: string[];
        cycles: string[][];
        units: PlannedUnit[];
    }
    export function planMaterialization(input: PlanInput): Promise<MaterializationPlan>;
}
declare module "_102021_/l2/agentMaterializeL1/run/budget" {
    export const M1_CEILING: {
        readonly maxWorkers: 2;
        readonly timeoutMs: 120000;
        readonly repairsPerArtifact: 1;
        readonly repairsPerRun: 4;
        readonly callsPerRun: 24;
    };
    export const M1_LEDGER_SCHEMA: "2026-09-25-m1-ledger-v1";
    export const M1_PROFILE_MODES: readonly ["production", "homologation", "development", "presentation"];
    export type M1ProfileMode = typeof M1_PROFILE_MODES[number];
    export interface BudgetRequest {
        maxWorkers?: number;
        timeoutMs?: number;
        repairsPerArtifact?: number;
        repairsPerRun?: number;
        callsPerRun?: number;
    }
    export interface EffectiveBudget {
        maxWorkers: number;
        timeoutMs: number;
        repairsPerArtifact: number;
        repairsPerRun: number;
        callsPerRun: number;
    }
    export interface ProfileDecision {
        mode: M1ProfileMode;
        declared: boolean;
        databaseEnv: 'DATABASE_URL' | 'DATABASE_URL_TEST';
        allowsSeeds: boolean;
        allowsReset: boolean;
        allowsStubRun: boolean;
    }
    export interface LedgerUnit {
        repairs: number;
        calls: number;
        signature: string;
        ended: string;
        /** Stage that closed the unit. Absent on a ledger written before implement followed structure. */
        stage?: MaterializeLedger['stage'];
    }
    export interface LedgerEvent {
        id: string;
        ended: string;
        units: Array<{
            defPath: string;
            code: string;
            promoted: boolean;
        }>;
    }
    export interface MaterializeLedger {
        schemaVersion: typeof M1_LEDGER_SCHEMA;
        project: number;
        moduleName: string;
        /** Stage that last wrote this ledger. Resume without a stage continues it. */
        stage: 'simulate' | 'structure' | 'implement' | 'verify';
        calls: number;
        repairs: number;
        callsExhausted: boolean;
        repairsExhausted: boolean;
        budget: EffectiveBudget;
        units: Record<string, LedgerUnit>;
        events: LedgerEvent[];
        /** Hash of the derived catalog inputs. A change clears catalog failure signatures. */
        catalogInputHash?: string;
    }
    export type CallErrorCode = 'TIMEOUT' | 'NETWORK_UNAVAILABLE' | 'TRANSIENT' | 'INVALID_RESPONSE';
    export class MaterializeCallError extends Error {
        readonly code: CallErrorCode;
        constructor(code: CallErrorCode, message: string);
    }
    export function ledgerPath(moduleName: string): string;
    export function emptyLedger(project: number, moduleName: string, budget: EffectiveBudget, stage?: MaterializeLedger['stage']): MaterializeLedger;
    /** Each dimension is min(ceiling, requested, persisted). Non-positive numbers are ignored. */
    export function tightenBudget(requested: BudgetRequest | null, persisted: BudgetRequest | null): EffectiveBudget;
    export function decideProfile(mode: unknown, declared: boolean): ProfileDecision;
    /** Counts one model request. Returns false when the run is already at its ceiling. */
    export function noteModelCall(ledger: MaterializeLedger, budget: EffectiveBudget): boolean;
    export function noteRepair(ledger: MaterializeLedger, budget: EffectiveBudget, defPath: string): boolean;
    export function encodeLedger(ledger: MaterializeLedger): string;
    export function parseLedger(text: string, project: number, moduleName: string): MaterializeLedger | null;
}
declare module "_102021_/l2/agentMaterializeL1/run/command" {
    import type { PlanUnitInput } from "_102021_/l2/agentMaterializeL1/planner/plan";
    import { type BudgetRequest } from "_102021_/l2/agentMaterializeL1/run/budget";
    export const M1_ENTRY_STAGES: readonly ["simulate", "structure", "implement", "verify"];
    export type M1EntryStage = typeof M1_ENTRY_STAGES[number];
    export const M1_AGENT_NAME = "agentMaterializeL1";
    export interface MaterializeCommand {
        help: boolean;
        refusal: string;
        project: number;
        moduleName: string;
        /** Null means the safe default, simulate, unless resume loads a ledger stage. */
        stage: M1EntryStage | null;
        flow: string;
        resume: boolean;
        budget: BudgetRequest | null;
    }
    export function emptyCommand(): MaterializeCommand;
    export function helpText(project: number): string;
    export function parseStudioPrompt(prompt: string, project: number): MaterializeCommand;
    /** The matched defs plus every selected def they depend on. The rest of the module stays out. */
    export function unitsForFlow(units: readonly PlanUnitInput[], flow: string): PlanUnitInput[];
    export function matchesFlow(unit: PlanUnitInput, flow: string): boolean;
    export function moduleTokenOk(value: string): boolean;
}
declare module "_102021_/l2/agentMaterializeL1/core/state" {
    /**
     * State-store port frozen for m1_08. Simulate accepts only MaterializeStateReader.
     * `running` stays on the receipt stage; it is not a fifth definition status.
     * removeOwned deletes listed files the manifest owns and never a directory.
     */
    import type { MaterializationReceipt } from "_102021_/l2/helpers/l1Defs/definition";
    export interface MaterializeStateReader {
        readReceipt(defPath: string): Promise<MaterializationReceipt | null>;
    }
    export interface MaterializeOwnedRemoval {
        removed: string[];
        kept: string[];
    }
    export interface MaterializeStateStore extends MaterializeStateReader {
        writeReceipt(receipt: MaterializationReceipt): Promise<void>;
        readOwned(outputPath: string): Promise<Uint8Array | null>;
        writeOwned(outputPath: string, body: Uint8Array): Promise<void>;
        removeOwned(owned: readonly string[], requested: readonly string[]): Promise<MaterializeOwnedRemoval>;
        /** Semantic hash last promoted for this def, or null when the store has no revision. */
        readRevision(defPath: string): Promise<string | null>;
    }
}
declare module "_102021_/l2/agentMaterializeL1/simulate/simulate" {
    /**
     * C2 simulate: read IO only. Returns generate / reuse / verify / blocked / remove.
     * Does not call a model, write a file, open a database or plan a migration.
     */
    import { type KnownArtifact } from "_102021_/l2/helpers/l1Defs/definition";
    import { type MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import type { MaterializeStateReader } from "_102021_/l2/agentMaterializeL1/core/state";
    import { type M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    import { type PlanUnitInput, type PlannedUnit } from "_102021_/l2/agentMaterializeL1/planner/plan";
    export const M1_SIMULATION_SCHEMA: "2026-09-25-m1-simulation-v1";
    export interface SimulateInput {
        moduleName: string;
        units: readonly PlanUnitInput[];
        stage?: M1HandlerStage;
        io: MaterializeReadIo;
        state?: MaterializeStateReader;
        extraArtifacts?: readonly KnownArtifact[];
        verifyOnly?: readonly string[];
        removals?: readonly string[];
        /** When set, a receipt written for another recipe does not skip. */
        recipeVersion?: string | null;
    }
    export interface SimulatedUnit extends PlannedUnit {
        prompt: string;
    }
    export interface SimulationSnapshot {
        schemaVersion: typeof M1_SIMULATION_SCHEMA;
        moduleName: string;
        stage: M1HandlerStage;
        order: string[];
        cycles: string[][];
        units: SimulatedUnit[];
        /** Simulate never writes. Present so a caller cannot mistake a plan for an emitted file. */
        wrote: false;
    }
    export function simulate(input: SimulateInput): Promise<SimulationSnapshot>;
}
declare module "_102021_/l2/agentMaterializeL1/testing/obligations" {
    /**
     * Authenticated route cases (m1_27). The oracle is read from the L2 contract of the
     * route, the access grants and the authority map; never from the emitted handler. A
     * case with authorities needs a test identity the runtime provisions, so it is declared
     * here with that blocker. It is not a catalog case and the run never reports it executed;
     * the memory harness (testing/fixture.ts, m1_28) runs it against the emitted code.
     * A grant proves behaviour; it is not a rule id (d1_26 r2, m1_10), so `ruleId` stays null.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import type { M1CaseCaller } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    /** Runtime proof: credential -> actor -> personEntity and the test identities are the runtime's. */
    export const M1_OBLIGATION_BLOCKER: "RUNTIME_IDENTITY_PENDING";
    export const M1_OBLIGATION_OWNER: "runtime 102034";
    export type M1ObligationKind = 'contract' | 'minimalInput' | 'noIdentity' | 'own' | 'other' | 'disclosure';
    /**
     * Actor the fixture binds: `member` holds the role, `owner` owns the addressed rows,
     * `other` holds the same role and owns none of them, `none` has the authority and no identity.
     */
    export type M1ObligationIdentity = 'member' | 'owner' | 'other' | 'none';
    export interface M1ObligationExpect {
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: null;
        /** Contract leaves no route grant discloses. */
        forbiddenPaths: string[];
        /** Contract paths every route grant discloses. A returned leaf outside them is a leak. Empty: not checked. */
        allowedPaths: string[];
        /** Every returned row carries the bound actor id in this field. */
        isolatedActorField: string | null;
    }
    export interface M1Obligation {
        caseId: string;
        kind: M1ObligationKind;
        routine: string;
        grantIds: string[];
        actorRef: string;
        identity: M1ObligationIdentity;
        caller: M1CaseCaller;
        /** Contract input members. The body holds the required ones, minus `omitted`. */
        input: {
            required: string[];
            optional: string[];
            omitted: string[];
        };
        mutating: boolean;
        expect: M1ObligationExpect;
        /** Refs the oracle was read from. A change in any of them invalidates the case. */
        sources: string[];
        blocker: typeof M1_OBLIGATION_BLOCKER;
        owner: typeof M1_OBLIGATION_OWNER;
    }
    export interface M1ObligationObservation {
        ok: boolean;
        status: number;
        errorCode: string | null;
        data: unknown;
        /** Identity the runner bound for this case; '' for `none`. */
        actorId: string;
    }
    export interface RouteRef {
        controller: M1Definition;
        defPath: string;
        route: string;
        kind: string;
        usecaseId: string;
        grantIds: string[];
    }
    export type RouteObligations = {
        obligations: M1Obligation[];
    } | {
        gap: string;
    };
    export function routeObligations(ref: RouteRef, defs: ReadonlyMap<string, M1Definition>, texts: Readonly<Record<string, string>>): RouteObligations;
    /**
     * Written apart from the controller emitter on purpose. `fullRecord` discloses every
     * contract path; `fieldsOnly`/`summaryOnly` the `<entityId>.` allowed fields and what is
     * under them; any other mode, or a grant that is not declared, discloses nothing.
     */
    export function disclosure(outputPaths: readonly string[], grants: readonly Record<string, unknown>[], entityId: string): {
        allowed: string[];
        forbidden: string[];
    };
    /** '' when the observation meets the obligation; otherwise the first difference. */
    export function obligationMiss(obligation: M1Obligation, observation: M1ObligationObservation): string;
    /**
     * Hash of every source ref; an unreadable ref is `absent` and invalidates its cases. A def is
     * hashed by its semantic hash, so the run rewriting its status does not move the oracle; any
     * other source (an L2 contract) by its content.
     */
    export function obligationSourceHashes(obligations: readonly M1Obligation[], texts: Readonly<Record<string, string>>): Promise<Record<string, string>>;
    /** Cases whose oracle read a source that changed or went missing. The others keep their proof. */
    export function staleObligations(obligations: readonly M1Obligation[], before: Readonly<Record<string, string>>, after: Readonly<Record<string, string>>): string[];
}
declare module "_102021_/l2/agentMaterializeL1/testing/fixture" {
    /**
     * Memory harness of the certification fixture (m1_28). It runs the obligations of m1_27 against
     * the emitted code: per case, setup -> case -> cleanup in `finally`.
     * - Values come from the entity defs, the grants and the contract members; the plan
     *   (l2/helpers/l1Defs/fixture.ts) says which data is local and which the runtime owns.
     * - Every id is made for this execution and registered; cleanup removes only registered ids,
     *   one by one, children first. No reset, no truncate, no delete by name.
     * - Identity in memory is the fixture actor id set on `sessionContext.actorId`, never a body
     *   member. The credential -> actor -> personEntity bridge is the runtime's; the runtime proof
     *   of every authenticated case stays pending with that owner.
     * - production/homologation are refused before any write (`decideProfile`).
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type M1FixturePlan, type M1FixtureTarget } from "_102021_/l2/helpers/l1Defs/fixture";
    import { type M1Obligation } from "_102021_/l2/agentMaterializeL1/testing/obligations";
    export const M1_FIXTURE_RUN_SCHEMA: "2026-09-27-m1-fixture-run-v1";
    export const M1_RUNTIME_OWNER: "runtime 102034";
    /** planned: plan read; materialized: values built; applied: records created and registered; tested: cases ran and cleanup left nothing. */
    export type M1FixturePhase = 'refused' | 'planned' | 'materialized' | 'applied' | 'tested';
    /** One emitted memory store. `remove` deletes one record by its exact key. */
    export interface M1FixtureStore {
        create(record: Record<string, unknown>): Promise<unknown>;
        remove(id: string): Promise<boolean>;
        list(): Promise<unknown[]>;
    }
    export type M1RouteHandler = (input: {
        request: {
            routine: string;
            params: Record<string, unknown>;
            meta: {
                source: string;
                verifiedAuthorities: string[];
            };
        };
        ctx: unknown;
    }) => Promise<{
        data: unknown;
    }>;
    export interface M1FixtureHost {
        runId: string;
        mode: unknown;
        target: M1FixtureTarget;
        stores: Readonly<Record<string, M1FixtureStore>>;
        routes: ReadonlyMap<string, M1RouteHandler>;
        /** A fresh request context; the harness sets `sessionContext.actorId`. */
        context: () => {
            sessionContext: {
                actorId?: string;
            };
        };
    }
    export interface M1FixtureRecordRef {
        entityId: string;
        id: string;
        by: 'setup' | 'case';
    }
    export interface M1FixtureLedger {
        created: M1FixtureRecordRef[];
        removed: M1FixtureRecordRef[];
        /** Registered and still present after cleanup, or created by a case with no returned key. */
        residue: string[];
    }
    export interface M1FixtureCaseResult {
        caseId: string;
        memory: 'passed' | 'failed' | 'pending';
        /** Miss, failure or gap. Empty when passed. */
        detail: string;
        /** Owner of the gap when pending. */
        owner: string;
        runtime: 'pending';
        runtimeGap: string;
        runtimeOwner: typeof M1_RUNTIME_OWNER;
    }
    export interface M1FixtureReceipt {
        schemaVersion: typeof M1_FIXTURE_RUN_SCHEMA;
        runId: string;
        mode: string;
        target: M1FixtureTarget;
        phase: M1FixturePhase;
        refused: string;
        ledger: M1FixtureLedger;
        cases: M1FixtureCaseResult[];
    }
    interface EntityInfo {
        entityId: string;
        key: string;
        fields: Array<{
            name: string;
            type: string;
            ref: string;
            derived: boolean;
        }>;
        lifecycleField: string;
        initial: string;
        /** Record fields an own grant filters on, with the actor that owns the row through them. */
        ownFields: Array<{
            field: string;
            actorRef: string;
        }>;
    }
    export interface M1FixtureModel {
        plan: M1FixturePlan;
        entities: Map<string, EntityInfo>;
        /** Route -> entity of its usecase. */
        routeEntity: Map<string, string>;
        selectors: Set<string>;
    }
    /** Reads what the harness needs from the defs. Unknown shapes simply give no entity. */
    export function fixtureModel(plan: M1FixturePlan, defs: ReadonlyMap<string, M1Definition>): M1FixtureModel;
    /** Actors of one execution: two of the same category with different rows, and one with no link. */
    export function fixtureActors(runId: string, actorRef: string): {
        owner: string;
        other: string;
        member: string;
        none: string;
    };
    /** Why a case cannot run in memory, or null. Derived from the plan and the defs, never from the case kind. */
    export function memoryGap(model: M1FixtureModel, obligation: M1Obligation): {
        gap: string;
        owner: string;
    } | null;
    /**
     * Why a case cannot run in memory, including the values its body needs; null when the harness
     * can run it. Pure: reads the plan and the defs, writes nothing.
     */
    export function classifyObligation(model: M1FixtureModel, obligation: M1Obligation): {
        gap: string;
        owner: string;
    } | null;
    /** Runtime proof: credential -> actor -> personEntity is not referenced; the item's gap says why. */
    export function runtimeGap(plan: M1FixturePlan, obligation: M1Obligation): string;
    /**
     * Setup -> case -> cleanup for every obligation, one execution each. Refused in production and
     * homologation, and for a target other than memory, before any write.
     */
    export function runFixture(model: M1FixtureModel, obligations: readonly M1Obligation[], host: M1FixtureHost): Promise<M1FixtureReceipt>;
    export interface M1FixtureRecord {
        entityId: string;
        /** Key field; its value in the returned record is the registered id. */
        key: string;
        /** Local parents: field -> index of the parent record in this list, resolved to its returned id. */
        parents: Record<string, number>;
        values: Record<string, unknown>;
    }
    export interface M1FixtureInstance {
        runId: string;
        actors: {
            owner: string;
            other: string;
            member: string;
            none: string;
        };
        records: M1FixtureRecord[];
        /** Index of the record the case addresses. */
        target: number;
        body: Record<string, unknown>;
    }
    /**
     * Creates the records in order and registers each returned id before the next one. A parent
     * field takes the id returned for its parent. A failure leaves the ledger with what was created.
     */
    export function applyFixture(records: readonly M1FixtureRecord[], stores: Readonly<Record<string, M1FixtureStore>>, ledger: M1FixtureLedger): Promise<string[]>;
    /** Children first; each registered id once; a record already gone counts as removed. Safe to call twice. */
    export function cleanupFixture(ledger: M1FixtureLedger, stores: Readonly<Record<string, M1FixtureStore>>): Promise<void>;
}
declare module "_102021_/l2/agentMaterializeL1/testing/derive" {
    /**
     * Technical scenario catalog derived from validated defs. No model and no
     * reading of generated TypeScript to invent an oracle. A local rulePlan row
     * is an obligation, not a test.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import type { PlannedUnit, PlanUnitInput } from "_102021_/l2/agentMaterializeL1/planner/plan";
    import { type M1ScenarioCatalog } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    import { type M1Obligation } from "_102021_/l2/agentMaterializeL1/testing/obligations";
    import { type M1FixtureModel } from "_102021_/l2/agentMaterializeL1/testing/fixture";
    export const M1_CATALOG_RECIPE: "2026-09-27-m1-catalog-derive-v5";
    export interface CatalogGap {
        artifactId: string;
        artifactType: string;
        origin: string;
        reason: string;
    }
    export interface DerivedCatalog {
        catalog: M1ScenarioCatalog;
        gaps: CatalogGap[];
        /** Authenticated route cases, declared with their blocker. Not in the catalog and not executed. */
        obligations: M1Obligation[];
        recipeVersion: typeof M1_CATALOG_RECIPE;
    }
    /**
     * A unit that will not write its `.ts` is a gap, not an executable scenario.
     * A unit whose output was already promoted (`promoted`, from its receipt) keeps its scenarios
     * even when it is blocked now: its output and its test are on disk and read the catalog (m1_32).
     */
    export function catalogWithheld(units: readonly PlannedUnit[], boundHandlers: ReadonlySet<string>, promoted?: ReadonlySet<string>): Map<string, string>;
    export function deriveCatalog(moduleName: string, units: readonly PlanUnitInput[], texts: Readonly<Record<string, string>>, withheld?: ReadonlyMap<string, string>): DerivedCatalog;
    /** The certification fixture the seeds def carries (m1_28); null without one. */
    export function fixtureModelOf(defs: ReadonlyMap<string, M1Definition>): M1FixtureModel | null;
    export function catalogBytes(catalog: M1ScenarioCatalog): string;
}
declare module "_102021_/l2/agentMaterializeL1/testing/verify" {
    /**
     * Classifies one batch against the catalog. Stage comes from the handler
     * registered by m1_01. An unstructured exception or a broken compile is
     * never expected-red.
     */
    import type { MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import type { MaterializeHandler, M1HandlerStage } from "_102021_/l2/agentMaterializeL1/core/registry";
    import { type M1ScenarioCase } from "_102021_/l2/agentMaterializeL1/testing/catalog";
    export const M1_CHECKPOINT_SCHEMA: "2026-09-25-m1-checkpoint-v1";
    export const M1_CHECKPOINT_BUDGET_MS: number;
    export const M1_VERDICTS: readonly ["passed", "expectedRed", "failed", "blocked", "skipped", "inconclusive"];
    export type M1Verdict = typeof M1_VERDICTS[number];
    export const M1_BROKEN: readonly ["none", "compile", "import", "transport"];
    export type M1Broken = typeof M1_BROKEN[number];
    /** What one case did. The caller fills this. This module does not call a database. */
    export interface M1Observation {
        caseId: string;
        durationMs: number;
        broken: M1Broken;
        thrown: boolean;
        skipped: boolean;
        inconclusive: boolean;
        blocked: boolean;
        blockOwner: string;
        ok: boolean;
        status: number;
        errorCode: string | null;
        ruleId: string | null;
        fields: string[];
        rowActorIds: string[];
        reason: string;
    }
    export interface M1Evidence {
        caseId: string;
        verdict: M1Verdict;
        errorCode: string | null;
        status: number | null;
        durationMs: number;
        detail: string;
    }
    export interface M1CheckpointCounts {
        passed: number;
        expectedRed: number;
        failed: number;
        blocked: number;
        skipped: number;
        inconclusive: number;
    }
    export interface M1Checkpoint {
        schemaVersion: typeof M1_CHECKPOINT_SCHEMA;
        runId: string;
        inputHash: string;
        commit: string;
        stage: M1HandlerStage;
        handlerId: string;
        startedAt: string;
        finishedAt: string;
        budgetMs: typeof M1_CHECKPOINT_BUDGET_MS;
        counts: M1CheckpointCounts;
        durationsMs: {
            total: number;
        };
        ready: boolean;
        accepted: boolean;
        evidence: M1Evidence[];
        nextAction: string;
        monitor: {
            delivered: boolean;
            error: string | null;
        };
    }
    /** Verification request. The handler and the read port belong to m1_01. */
    export interface MaterializeVerificationRequest {
        handler: MaterializeHandler;
        io: MaterializeReadIo;
        catalogRef: string;
        /** When set, only this artifact's scenarios are scored. An empty match is not a failed batch. */
        artifactId?: string;
        observations: readonly M1Observation[];
        runId: string;
        commit: string;
        startedAt: string;
        finishedAt: string;
        monitorError: string | null;
    }
    export function checkpointDue(elapsedMs: number, batchClosed: boolean): boolean;
    export function classifyCase(stage: M1HandlerStage, item: M1ScenarioCase, observation: M1Observation | undefined): M1Evidence;
    export function verifyBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    /**
     * The agent's own gate (m1_34). The agent runs in the browser and does not run a case, so a case
     * with no observation and a predicted ok/status decide nothing: the case verdict is the monitor's
     * (m1_35). What blocks is only what the agent sees without running: a broken compile or import, an
     * unstructured exception, and a def gap with an owner (held). The catalog checks stay fail-closed.
     */
    export function gateBatch(request: MaterializeVerificationRequest): Promise<M1Checkpoint>;
    export function noteMonitorFailure(report: M1Checkpoint, error: string): M1Checkpoint;
}
declare module "_102021_/l2/agentMaterializeL1/register/reconcileL5" {
    /** Role comes from the promoted def's artifactType. Paths are not a classification. */
    export type L5PromotedRole = 'httpController' | 'table' | 'repositoryRegistration' | 'output';
    export interface L5FileFact {
        ref: string;
        source: string | null;
        role: L5PromotedRole;
    }
    export function roleFromArtifactType(artifactType: string): L5PromotedRole;
    /**
     * Files the reconciler may see: promoted outputs (def path → output path) plus the
     * same-module imports those controllers name. No directory convention and no glob.
     */
    export function loadRegistrationFiles(project: number, moduleName: string, units: readonly {
        defPath: string;
        artifactType: string;
    }[], read: (ref: string) => Promise<string | null>): Promise<L5FileFact[]>;
    /** Fields both L5 readers use. `agentFolder` is required only when this publication fills a missing signature. */
    export interface L5BackendSignature {
        masterProject: number;
        runtimeProject: number;
        agentFolder?: string;
    }
    export interface ReconcileL5Input {
        project: number;
        moduleName: string;
        /** development and presentation may register a structure stub. Production must not. */
        allowStructureStub: boolean;
        phase: 'structure' | 'verified';
        projectJson: string | null;
        /**
         * Absent or omitted: the composer falls back to project.json. A string is an existing file.
         * This function never creates that second file.
         */
        runtimeProjectJson?: string | null;
        /**
         * Copied only when masters.backend is absent and the value already satisfies both readers.
         * This module does not invent agentChangeBackend.
         */
        backendSignature?: L5BackendSignature | null;
        files: readonly L5FileFact[];
        catalogRef: string | null;
    }
    export interface L5Pending {
        origin: string;
        reason: string;
    }
    export interface L5ReconcileResult {
        action: 'patch' | 'unchanged' | 'pending' | 'invalid';
        /** Null when the caller must keep the previous bytes (absent or unreadable). */
        nextText: string | null;
        /** File the composer reads. A patch applies only to this file. */
        effectiveSource: 'l5/project.json' | 'l5/runtime.project.json';
        backend: Record<string, unknown> | null;
        pendings: L5Pending[];
        detail: string;
    }
    /** Marker on a runtime.project.json snapshot this publication already owns. Not written onto a new file. */
    export const L5_PUBLICATION_OWNER = "agentMaterializeL1";
    export interface L5CommitIo {
        claim(project: number, holder: string): Promise<boolean>;
        release(project: number, holder: string): Promise<void>;
        read(ref: string): Promise<string | null>;
        /** Writes only when the current bytes still equal `expected`. `expected` null means the file is absent. */
        compareAndSwap(ref: string, expected: string | null, next: string): Promise<'ok' | 'conflict'>;
    }
    export function projectJsonRef(project: number): string;
    export function runtimeProjectJsonRef(project: number): string;
    export function projectLockRef(project: number): string;
    /**
     * Lock the project, reread both L5 documents, merge, and compare-and-swap the file the composer
     * reads. A second conflict leaves the bytes another writer stored. Does not regenerate sources.
     */
    export function commitL5Registration(input: Omit<ReconcileL5Input, 'projectJson' | 'runtimeProjectJson'>, io: L5CommitIo, holder: string): Promise<L5ReconcileResult>;
    export function reconcileL5Backend(input: ReconcileL5Input): L5ReconcileResult;
}
declare module "_102021_/l2/agentMaterializeL1/run/fixtureRun" {
    /**
     * Certification fixture in the implement run (m1_30). After the units of the run are done, the
     * authenticated obligations of each controller (testing/obligations.ts) run in memory against
     * the emitted bytes through testing/fixture.ts `runFixture`, once per controller whose inputs
     * changed. Browser-safe: execution is a port; the agent runs in the browser and passes none
     * (m1_33), so the proof is inconclusive with an owner.
     * - An obligation runs only when every unit its route imports has an accepted, intact output
     *   (the caller reads the receipts); otherwise it stays pending with owner L1. A sibling route's
     *   usecase does not hold it back.
     * - The key hashes the harness recipe, the fixture plan, the oracle sources, the emitted bytes the
     *   obligations import, the obligations and their readiness. Same key: the stored proof is reused.
     * - Memory is the only proof here. Runtime (identity, MDM) stays pending with its owner.
     */
    import { type M1Verification } from "_102021_/l2/helpers/l1Defs/definition";
    import type { PlanUnitInput } from "_102021_/l2/agentMaterializeL1/planner/plan";
    import { M1_RUNTIME_OWNER, type M1FixtureCaseResult, type M1FixtureModel, type M1FixtureReceipt } from "_102021_/l2/agentMaterializeL1/testing/fixture";
    import type { M1Obligation } from "_102021_/l2/agentMaterializeL1/testing/obligations";
    import { type M1Checkpoint } from "_102021_/l2/agentMaterializeL1/testing/verify";
    export const M1_FIXTURE_REPORT_SCHEMA: "2026-09-28-m1-fixture-report-v1";
    /** Harness recipe; a new one invalidates every stored proof. */
    export const M1_FIXTURE_RECIPE: "2026-09-28-m1-fixture-run-v1";
    /** Id of the verification row the controller receipt carries. */
    export const M1_FIXTURE_CHECK: "fixture.memory";
    export const M1_FIXTURE_HOST_OWNER: "L1 host";
    export type M1RunFixtureStatus = 'passed' | 'failed' | 'inconclusive' | 'pending';
    export interface M1RunFixture {
        /** Controller def whose routes the obligations call. */
        controller: string;
        key: string;
        status: M1RunFixtureStatus;
        /** Owner of a failure, a pending gap or an inconclusive run. */
        owner: string;
        detail: string;
        /** The proof of an earlier run with the same key. */
        reused: boolean;
        /** Execution that produced `receipt`; '' when nothing ran. */
        executionId: string;
        proof: 'memory';
        runtime: 'pending';
        runtimeOwner: typeof M1_RUNTIME_OWNER;
        hashes: {
            recipe: string;
            fixture: string;
            oracle: Record<string, string>;
            outputs: Record<string, string>;
        };
        counts: {
            cases: number;
            passed: number;
            failed: number;
            pending: number;
            residue: number;
        };
        /** Cases not executed because a unit they import is not materialized; also inside `receipt.cases` when it ran. */
        unready: M1FixtureCaseResult[];
        receipt: M1FixtureReceipt | null;
    }
    export interface M1FixtureReport {
        schemaVersion: typeof M1_FIXTURE_REPORT_SCHEMA;
        moduleName: string;
        entries: Record<string, M1RunFixture>;
    }
    /** Emitted bytes handed to the executor: output ref -> source, and which outputs are controllers and memory ports. */
    export interface M1FixtureExecution {
        module: {
            project: string;
            files: Record<string, string>;
            controllers: string[];
            ports: Array<{
                ref: string;
                entityId: string;
                exportName: string;
            }>;
        };
        model: M1FixtureModel;
        obligations: M1Obligation[];
        runId: string;
        mode: unknown;
    }
    /** Execution port. The agent passes none since m1_33 (it does not execute generated code). */
    export type M1FixtureExecutor = (input: M1FixtureExecution) => Promise<{
        receipt: M1FixtureReceipt | null;
        error: string;
    }>;
    export interface FixturePassInput {
        moduleName: string;
        units: readonly PlanUnitInput[];
        obligations: readonly M1Obligation[];
        oracleSources: Readonly<Record<string, string>>;
        /** '' when the unit's output is accepted and intact; otherwise why not. */
        unready: (defPath: string) => Promise<string>;
        read: (ref: string) => Promise<string | null>;
        previous: M1FixtureReport | null;
        /** null: the host offers no execution; `hostGap` says why. */
        execute: M1FixtureExecutor | null;
        hostGap: string;
        mode: unknown;
        /** Unique per run; ids of the fixture are made from it. */
        runStamp: string;
    }
    export function fixtureReportRef(moduleName: string): string;
    export function parseFixtureReport(text: string | null, moduleName: string): M1FixtureReport | null;
    export function renderFixtureReport(report: M1FixtureReport): string;
    /** One entry per controller with obligations. Writes nothing; the caller persists the report. */
    export function fixturePass(input: FixturePassInput): Promise<M1RunFixture[]>;
    /** The run checkpoint of one entry: executed cases and residue; pending cases keep their gap in the report. */
    export function fixtureCheckpoint(entry: M1RunFixture, runId: string, commit: string, at: string): M1Checkpoint | null;
    /** Verification row for the controller receipt, only when the cases ran. */
    export function fixtureVerification(entry: M1RunFixture): M1Verification | null;
    /** Report lines for a run log; CLI and Studio print the same text. */
    export function fixtureLines(entries: readonly M1RunFixture[]): string[];
}
declare module "_102021_/l2/agentMaterializeL1/run/model" {
    import type { MaterializeHandler } from "_102021_/l2/agentMaterializeL1/core/registry";
    import type { M1EntryStage } from "_102021_/l2/agentMaterializeL1/run/command";
    export interface ModelRequest {
        prompt: string;
        signal: AbortSignal;
        eventId: string;
    }
    export type ModelPort = (request: ModelRequest) => Promise<string>;
    export function shouldCallModel(stage: M1EntryStage, handler: MaterializeHandler | null): boolean;
    export function invokeModel(port: ModelPort, request: ModelRequest, timeoutMs: number): Promise<string>;
}
declare module "_102021_/l2/agentMaterializeL1/run/execute" {
    /**
     * Run of the Studio entry (the agent runs in the browser; collab-msg simulates it).
     * simulate only reads. structure calls structure handlers. implement calls
     * only handlers registered for implement. A missing body is a named block,
     * not a generic file. A failed checkpoint is not promoted and does not start
     * the next stage. A source that changes during the call is not overwritten.
     */
    import { type M1Verification } from "_102021_/l2/helpers/l1Defs/definition";
    import { type MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import { type MaterializeHandler } from "_102021_/l2/agentMaterializeL1/core/registry";
    import type { MaterializeStateStore } from "_102021_/l2/agentMaterializeL1/core/state";
    import { type SimulationSnapshot, type SimulatedUnit } from "_102021_/l2/agentMaterializeL1/simulate/simulate";
    import { type PlanUnitInput } from "_102021_/l2/agentMaterializeL1/planner/plan";
    import { type CatalogGap } from "_102021_/l2/agentMaterializeL1/testing/derive";
    import { type M1Checkpoint, type M1Observation } from "_102021_/l2/agentMaterializeL1/testing/verify";
    import { type BudgetRequest, type EffectiveBudget, type MaterializeLedger, type ProfileDecision } from "_102021_/l2/agentMaterializeL1/run/budget";
    import { type L5CommitIo, type L5ReconcileResult } from "_102021_/l2/agentMaterializeL1/register/reconcileL5";
    import { type M1EntryStage } from "_102021_/l2/agentMaterializeL1/run/command";
    import { type M1RunFixture } from "_102021_/l2/agentMaterializeL1/run/fixtureRun";
    import { type ModelPort } from "_102021_/l2/agentMaterializeL1/run/model";
    import { M1_RECIPE_VERSION, type WriteBoundary } from "_102021_/l2/agentMaterializeL1/state/maintain";
    export const M1_RUN_SCHEMA: "2026-09-25-m1-run-v1";
    export { M1_RECIPE_VERSION };
    export interface HandlerOutcome {
        files: Record<string, string>;
        observations: M1Observation[];
        failure: {
            code: string;
            detail: string;
        } | null;
        seeds: boolean;
        resets: boolean;
        runsStub: boolean;
        /** Extra receipt rows. A compiled table and an unapplied migration are two rows. */
        evidences?: M1Verification[];
    }
    export interface HandlerCall {
        handler: MaterializeHandler;
        unit: SimulatedUnit;
        /** The def the planner already accepted. The runner does not receive a write port. */
        definition: unknown;
        read: (ref: string) => Promise<string | null>;
        catalogRef: string;
        repair: boolean;
        signal: AbortSignal;
        eventId: string;
        profile: ProfileDecision;
        modelText: string | null;
        /** Defs loaded for the module. Absent in callers that emit one file alone. */
        moduleDefinitions?: readonly unknown[];
    }
    export type MaterializeHandlerRunner = (call: HandlerCall) => Promise<HandlerOutcome>;
    export interface MaterializeWriter {
        claim(moduleName: string, holder: string): Promise<boolean>;
        release(moduleName: string, holder: string): Promise<void>;
    }
    export interface MaterializeRunHost {
        io: MaterializeReadIo;
        state: MaterializeStateStore;
        runners: Readonly<Record<string, MaterializeHandlerRunner>>;
        llm?: ModelPort;
        now?: () => string;
        catalogRef?: string;
        commit?: string;
        monitorError?: string | null;
        /** One writer per module. Absent in unit tests that do not share a store. */
        writer?: MaterializeWriter;
        /** Project lock and compare-and-swap for l5/project.json. Module claim does not cover this file. */
        l5?: L5CommitIo;
        onBoundary?: (boundary: WriteBoundary) => Promise<void> | void;
    }
    export interface MaterializeRunRequest {
        project: number;
        moduleName: string;
        stage: M1EntryStage | null;
        flow: string;
        resume: boolean;
        units: readonly PlanUnitInput[];
        profileMode: unknown;
        profileDeclared: boolean;
        budget?: BudgetRequest | null;
        eventId?: string;
        signal?: AbortSignal;
    }
    export interface UnitOutcome {
        defPath: string;
        code: string;
        detail: string;
        promoted: boolean;
        modelCalls: number;
    }
    export interface MaterializeRunResult {
        schemaVersion: typeof M1_RUN_SCHEMA;
        project: number;
        moduleName: string;
        stage: M1EntryStage;
        flow: string;
        profile: ProfileDecision;
        budget: EffectiveBudget;
        snapshot: SimulationSnapshot | null;
        ledger: MaterializeLedger;
        units: UnitOutcome[];
        checkpoints: M1Checkpoint[];
        llmCalls: number;
        wrote: boolean;
        ended: string;
        catalog?: CatalogPrep;
        registration?: L5ReconcileResult;
        /** Certification fixture of the implement stage, one entry per controller with obligations (m1_30). */
        fixtures?: M1RunFixture[];
        /** What the ended code alone does not say: for WRITER_BUSY, the file and the holder. */
        detail?: string;
    }
    export interface CatalogPrep {
        ref: string;
        action: 'simulated' | 'written' | 'unchanged' | 'conflict' | 'invalid';
        inputHash: string;
        recipeVersion: string;
        gaps: CatalogGap[];
        detail: string;
        /**
         * Content hash of every source the authenticated-case oracle read (m1_27/m1_28), `absent`
         * when unreadable. Kept out of the catalog bytes, so it does not move `inputHash`.
         */
        oracleSources: Record<string, string>;
    }
    export function runMaterialize(request: MaterializeRunRequest, host: MaterializeRunHost): Promise<MaterializeRunResult>;
}
declare module "_102021_/l2/agentMaterializeL1/core/refs" {
    /**
     * Ref policy shared by the CLI and the Studio host: which ref is read and which is written.
     * Reads: the target project or a platform project. Writes: the target project only.
     */
    /** Platform projects a run may read. Never written. */
    export const PLATFORM_PROJECTS: ReadonlySet<string>;
    export interface ParsedRef {
        projectId: string;
        level: number;
        /** Path under `lN/`, e.g. `project.json` or `moduleName/layer_3_domain/x.ts`. */
        rest: string;
    }
    /** Qualified `_NNNNN_/lN/...` or local `lN/...` (target project). `..`, `\`, `/` prefix and empty segments are refused. */
    export function parseRef(ref: string, project: number): ParsedRef | null;
    export function isPlatformRef(ref: string): boolean;
    export function readable(ref: string, project: number): boolean;
    export function writable(ref: string, project: number): boolean;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/behavior/runners" {
    import type { HandlerCall, HandlerOutcome, MaterializeHandlerRunner } from "_102021_/l2/agentMaterializeL1/run/execute";
    export const behaviorRunners: Readonly<Record<string, MaterializeHandlerRunner>>;
    export function behaviorHandlerIds(): string[];
    export function runBehavior(call: HandlerCall): Promise<HandlerOutcome>;
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls ctx.mdm.prospect.promoteToEntity({ mdmId: prospectMdmId })
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Person | Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Person | Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    /**
     * Organization-level registration namespace (the third MDM layer: base · general · module).
     * Schema lives in the project's solution registry (l4); the engine only reserves the key
     * and does not filter it on read.
     */
    export type MdmGeneralNamespace = Record<string, unknown>;
    export const MDM_GENERAL_NAMESPACE = "general";
    export const MDM_ORGANIZATION_MODULE_ID = "organization";
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        general?: MdmGeneralNamespace;
        /** Computed on facade reads: other modules' namespace keys (no content). Not persisted. */
        namespaces?: string[];
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;
    export type MdmDetailInput = DistributiveOmit<MdmDetailRecord, 'mdmId'> & {
        mdmId?: string;
    };
    export interface MdmDocumentInput {
        mdmId: string;
        version: number;
        details: MdmDetailInput;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    /** Where this project is read from and saved to. Replaces the `cadastro` blob. */
    export interface ProjectSettingsConfig {
        /** Destination: 'GitHub' | 'GitLab' | 'vm'. Routed by getDefaultDriver in the cfe. */
        driver: string;
        /** >= 3 '/'-separated segments: getMyKeysBranch takes the LAST three as branch/owner/repo. */
        url: string;
        name?: string;
        userAuth?: 'public' | 'private';
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        clientShell?: ProjectClientShellConfig;
        /** Optional same-origin favicon href (`/…`). Cross-origin values are ignored. */
        favicon?: string;
        /** Destination of this project's source. Read by the runtime login from l5/config.json. */
        projectSettings?: ProjectSettingsConfig;
        /** Declared workspace project ids. Read by cbeLogin.readProjectDependencies. */
        workspaceDependencies?: string[];
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        name?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export type { ProjectClientShellConfig, ProjectConfigRecord, ProjectDynamicRegionConfig, ProjectFrontendPageConfig, ProjectModuleConfig, ProjectModuleFrontendConfig, ProjectModuleFrontendEntrypoint, ProjectNavigationEntry, ProjectPersistenceModuleConfig, ProjectRegionRendererConfig, ProjectShellRegionProfiles, ProjectType, ProjectsConfig, } from "_102029_/l2/runtimeConfigTypes";
    export function projectsConfigExists(): boolean;
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function resolveWebDistPath(relativePath?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/config/projectMode" {
    export type ProjectMode = 'production' | 'homologation' | 'development' | 'presentation';
    /** A generated module is born in `presentation`; anything unreadable falls back to it, loudly. */
    export const DEFAULT_PROJECT_MODE: ProjectMode;
    export function isProjectMode(value: unknown): value is ProjectMode;
    /** Test modes run against the TEST database and may be written to by the test runner. */
    export function isTestMode(mode: ProjectMode): boolean;
    /**
     * The mode declared by `l5/project.json` of a project. Absent or invalid ⇒ `presentation` with a warning:
     * defaulting to production would point a freshly generated module at real data, which is the one mistake
     * this whole concept exists to prevent.
     */
    /**
     * Did the project DECLARE its mode, or is it running on the default?
     *
     * The difference decides whether a missing `DATABASE_URL_TEST` is a failure: a project that explicitly
     * says `presentation` and has no test connection string is misconfigured and must say so; a project that
     * declared nothing at all is simply older than the modes, and breaking its boot over a default would be
     * this feature's worst outcome.
     */
    export function hasDeclaredProjectMode(projectId?: string | number): boolean;
    export function readProjectMode(projectId?: string | number): ProjectMode;
    /** Which env var holds the connection string for this mode. */
    export function databaseUrlEnvFor(mode: ProjectMode): 'DATABASE_URL' | 'DATABASE_URL_TEST';
    /**
     * The connection string for a mode — and a LEGIBLE failure when a test mode has none.
     *
     * Falling back to `DATABASE_URL` here would be the worst possible bug of this feature: a presentation
     * module quietly writing curated seeds over production data. So the absence is an error, not a default.
     */
    export function resolveDatabaseUrl(mode: ProjectMode): string;
    /**
     * Create the TEST database when it does not exist yet.
     *
     * "Nothing manual per project": provisioning a generated app flows through the publish, so a test mode
     * that points at a database nobody created should create it instead of demanding an SSH session. Only the
     * DATABASE is created — the schema is the bootstrap's job — and only in a test mode: nobody
     * auto-provisions production. Returns what happened, so the caller can log it; a missing privilege is
     * reported, not swallowed, because then the legible failure IS the answer.
     */
    export function ensureTestDatabase(mode: ProjectMode, connect: (adminUrl: string) => Promise<{
        exists: (database: string) => Promise<boolean>;
        create: (database: string) => Promise<void>;
        end: () => Promise<void>;
    }>): Promise<{
        created: boolean;
        database: string;
        reason: string;
    }>;
    /** The database name of a connection string, plus the same string pointed at `postgres` (admin). */
    export function parseDatabaseUrl(url: string): {
        database: string;
        adminUrl: string;
    } | null;
    export interface WriteAttempt {
        /** Where the request came from — the transport stamps it; `test` is the monitor runner. */
        source?: 'http' | 'message' | 'test';
        /** The routine's command segment (`cmdCreateClient`, `qryListClient`). */
        command?: string;
    }
    /**
     * May this request write? The SERVER half of the two defences.
     *
     * The runner is supposed to keep its destructive suite for test modes, but "supposed to" is what let a
     * production run write junk once. The generated vocabulary makes the check deterministic: `cmd*` mutates,
     * `qry*` reads. A read-only smoke from the runner stays allowed everywhere, which is what makes production
     * still observable.
     */
    export function refuseTestWrite(mode: ProjectMode, attempt: WriteAttempt): string;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    /** Snapshot row used for the schema hash. Columns in; seedRows out — a seed-only edit must not rebuild. */
    export function toSchemaSnapshotTable(definition: ResolvedTableDefinition): SchemaSnapshot['tables'][number];
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
    /**
     * A module that wants to be woken up exports `onTick` from its persistence file, next to
     * `tableDefinitions` and `viewDefinitions`. The platform only lends the clock: what the module does
     * with the minute — which occurrences it owes, where it records them — is the module's business.
     */
    export type ModuleTickHandler = (ctx: RequestContext, now: Date) => Promise<void> | void;
    export interface ModuleTickRegistration {
        moduleId: string;
        onTick: ModuleTickHandler;
    }
    /**
     * Collects `onTick` the same way `loadViewDefinitions` collects `viewDefinitions` — with one
     * difference on purpose: a module whose import throws is warned about and skipped instead of
     * rejecting the whole load. `loadViewDefinitions` above has no such isolation; the tick runs every
     * minute forever, so one broken module must not silence every other module's clock.
     */
    export function loadModuleTickHandlers(): Promise<ModuleTickRegistration[]>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        /** Case-insensitive substring per column (`ILIKE` in Postgres). Empty/absent values are ignored. */
        ilike?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
        /** Rows to skip after filtering/ordering. Absent = 0. `findMany` without limit/offset is unchanged. */
        offset?: number;
    }
    /** Default page size when a list asks to paginate without saying how many. */
    export const DEFAULT_PAGE_SIZE = 20;
    /** Hard cap: a requested pageSize above this is cut, and the envelope declares the effective size. */
    export const MAX_PAGE_SIZE = 200;
    export interface ResolvedListPage {
        page: number;
        pageSize: number;
        limit: number;
        offset: number;
    }
    /**
     * Convert optional page/pageSize into LIMIT/OFFSET. Default 20, cap 200 — the cut is declared
     * (returned pageSize is the effective one), never silent and never a rejection.
     */
    export function resolveListPage(input?: {
        page?: number;
        pageSize?: number;
    }): ResolvedListPage;
    export function applyFindManyWindow<TRecord>(rows: TRecord[], input?: Pick<IFindManyInput<TRecord>, 'limit' | 'offset'>): TRecord[];
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        /** Rows matching the filter, ignoring limit/offset. Same WHERE as findMany. */
        count(input?: IFindManyInput<TRecord>): Promise<number>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function buildFindManySql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function buildCountSql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
    /** In-memory ITableRepository without the persistence registry — fixture for tests, not a generated app. */
    export function createMemoryTableRepository<TRecord extends object>(records: TRecord[]): ITableRepository<TRecord>;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmDocumentInput, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from "_102034_/l1/mdm/module";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentInput;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory" {
    export interface ICacheRuntime {
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
    export class CacheRuntimeMemory implements ICacheRuntime {
        private readonly defaultTtlSeconds?;
        private readonly values;
        constructor(defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmDetailRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmDocumentEntity {
        static get(ctx: RequestContext, mdmId: string): Promise<MdmDocumentRecord>;
        static parseDetails(document: MdmDocumentRecord): MdmDetailRecord;
        static create(ctx: RequestContext, record: MdmDocumentRecord): Promise<void>;
        static replace(ctx: RequestContext, record: MdmDocumentRecord, expectedVersion: number): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRecordStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export class MdmRecordEntity {
        static getEntityIndex(ctx: RequestContext, mdmId: string): Promise<MdmEntityIndexRecord>;
        static getProspectIndex(ctx: RequestContext, mdmId: string): Promise<MdmProspectIndexRecord>;
        static findEntityByDocument(ctx: RequestContext, docType?: string | null, docId?: string | null): Promise<MdmEntityIndexRecord | null>;
        static findEntityByContact(ctx: RequestContext, contactType?: string | null, value?: string | null): Promise<MdmEntityIndexRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    export class MdmRelationshipEntity {
        static findOne(ctx: RequestContext, id: string): Promise<{
            scope: 'entity' | 'prospect';
            relationship: MdmRelationshipRecord;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmSupport" {
    import type { MdmProspectStatus, MdmStatus, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CreateRecordParams, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    type RelationshipScope = 'entity' | 'prospect';
    export function getMdmModuleTypes(detail: MdmDetailRecord | Record<string, unknown>): string[];
    export function refreshRelationshipRefs(ctx: RequestContext, relationshipScope: RelationshipScope, mdmIds: string[], enqueueDocumentWrite: (document: {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }) => Promise<void>): Promise<void>;
    export function normalizeCountryCode(countryCode?: string | null): string;
    export function normalizeDocumentId(docId?: string | null): string | null;
    export function normalizeContactValue(value?: string | null): string | null;
    export function isProtectedPrivacyCountry(countryCode: string): boolean;
    export function normalizeDetailInput(input: CreateRecordParams['detail'], ctx: RequestContext, mdmId: string): MdmDetailRecord;
    export function applyPatchToDetail(currentDetail: MdmDetailRecord, patch: Partial<MdmDetailRecord>, ctx: RequestContext): MdmDetailRecord;
    export function normalizeStatus(detail: MdmDetailRecord): MdmStatus | MdmProspectStatus;
    export function validateDetail(detail: MdmDetailRecord): void;
    export function toDocumentRecord(detail: MdmDetailRecord, version: number): {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    };
    export function buildEntityIndex(detail: MdmDetailRecord): MdmEntityIndexRecord;
    export function buildProspectIndex(detail: MdmDetailRecord): MdmProspectIndexRecord;
    export function normalizeEntityStatus(detail: MdmDetailRecord): MdmStatus;
    export function normalizeProspectStatus(detail: MdmDetailRecord): MdmProspectStatus;
    export function buildSearchVector(detail: MdmDetailRecord): string;
    export function relationshipIsBidirectional(type: RelationshipType): boolean;
    export function migrateProspectRelationships(ctx: RequestContext, prospectMdmId: string): Promise<{
        affectedIds: string[];
        migratedRelationships: MdmRelationshipRecord[];
    }>;
    export function buildRelationshipSearchText(relationship: MdmRelationshipRecord): string;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/mdmEntityDefs" {
    import type { EntityDef, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export const mdmEntityDef: EntityDef<MdmDetailRecord, MdmEntityIndexRecord>;
    export const mdmProspectDef: EntityDef<MdmDetailRecord, MdmProspectIndexRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/entityPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRecordParams, ListRecordsParams, MergeEntityParams, MdmDocumentRecord, MdmRelationshipDocumentRecord, PromoteProspectParams, RecordDetailResponse, UpdateRecordParams } from "_102034_/l1/mdm/module";
    export function enqueueWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], document: MdmDocumentRecord): Promise<void>;
    export function enqueueRelationshipWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], relationship: MdmRelationshipDocumentRecord): Promise<void>;
    export function createEntity(ctx: RequestContext, params: CreateRecordParams): Promise<{
        alreadyExists: boolean;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: boolean;
        mdmId: string;
        version: number;
    }>;
    export function createProspect(ctx: RequestContext, params: CreateRecordParams): Promise<{
        mdmId: string;
        version: number;
    }>;
    export function getEntity(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function getProspect(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function listEntities(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord[]>;
    export function listProspects(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord[]>;
    export function updateEntity(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
    }>;
    export function updateProspect(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus | import("_102034_/l1/mdm/defs/ontology").MdmProspectStatus;
    }>;
    export function promoteProspect(ctx: RequestContext, params: PromoteProspectParams): Promise<{
        promoted: boolean;
        status: string;
        mdmId: string;
        prospectMdmId: string;
        candidateMdmId: string;
    } | {
        promoted: boolean;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
        mdmId: string;
    }>;
    export function mergeEntity(ctx: RequestContext, params: MergeEntityParams): Promise<{
        winnerMdmId: string;
        loserMdmId: string;
        status: string;
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/relationshipPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRelationshipParams, ListRelationshipsParams, SearchParams, UpdateRelationshipParams } from "_102034_/l1/mdm/module";
    export function createRelationship(ctx: RequestContext, params: CreateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            role: string;
            metadata: Record<string, unknown>;
            isBidirectional: boolean;
            validFrom: string;
            validTo: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            createdAt: string;
            updatedAt: string;
        };
    }>;
    export function listRelationships(ctx: RequestContext, params: ListRelationshipsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[]>;
    export function updateRelationship(ctx: RequestContext, params: UpdateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            updatedAt: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            metadata?: Record<string, unknown>;
            role?: string | null;
            validFrom: string;
            validTo?: string | null;
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            isBidirectional: boolean;
            createdAt: string;
        };
    }>;
    export function runSearch(ctx: RequestContext, params: SearchParams): Promise<{
        records: (import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord | import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord)[];
        relationships: import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[];
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export function attachFile(ctx: RequestContext, params: AttachFileParams): Promise<MdmAttachmentRecord>;
    export function detachFile(ctx: RequestContext, params: DetachFileParams): Promise<MdmAttachmentRecord>;
    export function findAttachmentsByEntity(ctx: RequestContext, params: FindAttachmentsByEntityParams): Promise<MdmAttachmentRecord[]>;
}
declare module "_102034_/l1/server/layer_1_external/cache/CacheRuntimeRedis" {
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export class CacheRuntimeRedis implements ICacheRuntime {
        private readonly defaultTtlSeconds;
        private socket;
        private connecting;
        private queue;
        private readonly target;
        constructor(url: string, defaultTtlSeconds?: number);
        get<TValue>(key: string): Promise<TValue | null>;
        set<TValue>(key: string, value: TValue, ttlSeconds?: number): Promise<void>;
        del(key: string): Promise<void>;
        close(): Promise<void>;
        private command;
        private ensureConnected;
        private commandOn;
    }
}
declare module "_102034_/l1/server/layer_1_external/cache/identityCache" {
    import { type ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    export const IDENTITY_CACHE_KEY_PREFIX = "identity:login:";
    export const DEFAULT_IDENTITY_CACHE_TTL_SECONDS = 300;
    export interface IdentityCacheValue {
        mdmId: string;
        name: string;
    }
    export function identityCacheKey(email: string): string;
    export function identityCacheTtlSeconds(): number;
    /**
     * Pick the cache implementation by capability: Redis when REDIS_URL is present,
     * in-memory otherwise. Never by host name.
     */
    export function createIdentityCache(redisUrl?: string | null): ICacheRuntime;
    export function getSharedIdentityCache(): ICacheRuntime;
    export function resetSharedIdentityCacheForTests(): void;
}
declare module "_102034_/l1/mdm/layer_3_usecases/identityUsecases" {
    import { type PlatformSessionPerson, type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import { type IdentityCacheValue } from "_102034_/l1/server/layer_1_external/cache/identityCache";
    export const MDM_LOGIN_NAMESPACE = "login";
    export const MDM_LOGIN_ENTITY_TYPE = "MdmEntity";
    export interface MdmIdentityInviteInput {
        mdmId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }
    export interface MdmIdentityInviteResult {
        token: string;
        expiresAt: string;
        teamIds?: string[];
    }
    export function lookupLogin(ctx: RequestContext, email: string): Promise<IdentityCacheValue | null>;
    export function findByLogin(ctx: RequestContext, email: string): Promise<string | null>;
    export function resolveSessionPerson(ctx: RequestContext, email: string): Promise<PlatformSessionPerson | null>;
    export function setLogin(ctx: RequestContext, mdmId: string, email: string): Promise<{
        mdmId: string;
        email: string;
    }>;
    export function createCollabAuthInviteHttp(input: {
        baseUrl: string;
        apiKey: string;
        orgId: string;
        email: string;
        moduleId: string;
        actorId: string;
    }): Promise<MdmIdentityInviteResult>;
    export function invite(ctx: RequestContext, input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmFacade" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord, CompactRelationshipRefKey, CreateableMdmDetailInput, MdmDetailRecord, MdmDocumentRecord, MdmEntityIndexRecord, MdmModuleNamespaceValue, MdmProspectIndexRecord, RelationshipStatus } from "_102034_/l1/mdm/module";
    import type { MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import { type MdmIdentityInviteInput, type MdmIdentityInviteResult } from "_102034_/l1/mdm/layer_3_usecases/identityUsecases";
    export type MdmEntityCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmEntityCreateInput {
        details: MdmEntityCreateDetails;
    }
    export type MdmProspectCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmProspectCreateInput {
        details: MdmProspectCreateDetails;
    }
    export interface MdmEntityUpdateInput {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface MdmProspectUpdateInput extends MdmEntityUpdateInput {
    }
    export interface MdmEntityGetInput {
        mdmId: string;
    }
    export interface MdmProspectGetInput extends MdmEntityGetInput {
    }
    export interface MdmProspectPromoteToEntityInput {
        mdmId: string;
    }
    export interface MdmEntityInactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    /** Mirror of MdmEntityInactivateInput: the cadastral cycle is symmetric, so its input is too. */
    export interface MdmEntityReactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    export interface MdmEntityDeleteInput {
        mdmId: string;
        allowActiveRelationships?: boolean;
    }
    export interface MdmLinkInput {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom?: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface MdmUnlinkInput {
        relationshipId: string;
    }
    export interface MdmGetManyInput {
        mdmIds: string[];
        chunkSize?: number;
    }
    export interface MdmListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmProspectListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmProspectStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmHydrateManyInput extends MdmGetManyInput {
        sections?: string[];
        includeRelationshipRefs?: boolean;
    }
    export interface MdmRelatedOfManyInput {
        mdmIds: string[];
        type?: RelationshipType;
        status?: RelationshipStatus;
    }
    export interface MdmRelatedRef {
        mdmId: string;
        relationshipId: string;
        type: RelationshipType;
        direction: 'from' | 'to';
        role?: string | null;
        metadata?: Record<string, unknown>;
    }
    export interface MdmEntityReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmEntityIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmEntityWriteResult extends MdmEntityReadResult {
        alreadyExists?: boolean;
    }
    export interface MdmProspectReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmProspectIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmProspectWriteResult extends MdmProspectReadResult {
    }
    export type MdmProspectListByTypeItem = MdmProspectIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmProspectListByTypeResult {
        items: MdmProspectListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmProspectPromoteToEntityResult {
        promoted: boolean;
        status: MdmStatus | MdmProspectStatus;
        mdmId: string;
        prospectMdmId?: string;
        candidateMdmId?: string;
    }
    export interface MdmDeleteResult {
        mdmId: string;
        deleted: true;
    }
    export type MdmListByTypeItem = MdmEntityIndexRecord & {
        details: MdmDetailRecord;
    };
    export interface MdmListByTypeResult {
        items: MdmListByTypeItem[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmHydratedEntity {
        mdmId: string;
        version: number;
        details: Partial<MdmDetailRecord>;
    }
    export interface MdmFacade {
        entity: MdmEntity;
        prospect: MdmProspect;
        collection: MdmCollection;
        attachment: MdmAttachment;
        identity: MdmIdentity;
    }
    export function isUnrestrictedMdmCaller(moduleId?: string | null): boolean;
    export function projectDetailsForModule(details: MdmDetailRecord | Record<string, unknown>, moduleId?: string | null): MdmDetailRecord;
    export class MdmEntity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmEntityCreateInput): Promise<MdmEntityWriteResult>;
        get(input: MdmEntityGetInput): Promise<MdmEntityReadResult>;
        update(input: MdmEntityUpdateInput): Promise<MdmEntityWriteResult>;
        findByDocument(docType: string, docId: string): Promise<MdmEntityReadResult | null>;
        findByContact(contactType: string, value: string): Promise<MdmEntityReadResult | null>;
        /**
         * Create-or-attach: add tag `<moduleId>.<role>` without duplicating, and optionally write the
         * caller module's namespace. Role may be the entity id (`Cliente`) or the canonical tag.
         */
        attachRole(mdmId: string, role: string, namespace?: MdmModuleNamespaceValue): Promise<MdmEntityWriteResult>;
        inactivate(input: MdmEntityInactivateInput): Promise<MdmEntityWriteResult>;
        /**
         * The other half of the cadastral cycle. An MDM entity is NEVER deleted by a generated module: the
         * tier-1 catalogue emits `inactivate`/`reactivate` for `storage.target: 'mdm'` instead of `delete`,
         * so a generated `cmdReactivate*` had no target here at all until this method existed.
         *
         * Deliberately the exact mirror of `inactivate` — same optimistic version, same single-field patch —
         * because any asymmetry between the two halves shows up as a record that can be hidden and not
         * brought back.
         */
        reactivate(input: MdmEntityReactivateInput): Promise<MdmEntityWriteResult>;
        delete(input: MdmEntityDeleteInput): Promise<MdmDeleteResult>;
        link(input: MdmLinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                role: string;
                metadata: Record<string, unknown>;
                isBidirectional: boolean;
                validFrom: string;
                validTo: string;
                status: RelationshipStatus;
                createdAt: string;
                updatedAt: string;
            };
        }>;
        unlink(input: MdmUnlinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                updatedAt: string;
                status: RelationshipStatus;
                metadata?: Record<string, unknown>;
                role?: string | null;
                validFrom: string;
                validTo?: string | null;
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                isBidirectional: boolean;
                createdAt: string;
            };
        }>;
    }
    export class MdmProspect {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmProspectCreateInput): Promise<MdmProspectWriteResult>;
        get(input: MdmProspectGetInput): Promise<MdmProspectReadResult>;
        update(input: MdmProspectUpdateInput): Promise<MdmProspectWriteResult>;
        listByType(input: MdmProspectListByTypeInput): Promise<MdmProspectListByTypeResult>;
        promoteToEntity(input: MdmProspectPromoteToEntityInput): Promise<MdmProspectPromoteToEntityResult>;
    }
    export class MdmCollection {
        private readonly ctx;
        constructor(ctx: RequestContext);
        getMany(input: MdmGetManyInput): Promise<MdmEntityReadResult[]>;
        listByType(input: MdmListByTypeInput): Promise<MdmListByTypeResult>;
        relatedOfMany(input: MdmRelatedOfManyInput): Promise<Record<string, MdmRelatedRef[]>>;
        hydrateMany(input: MdmHydrateManyInput): Promise<MdmHydratedEntity[]>;
    }
    /**
     * Attachments of any record, through the facade.
     *
     * The usecases already existed (`attachFile`/`detachFile`/`findAttachmentsByEntity`, with write-behind and
     * audit) but nothing in a generated module could reach them: `ctx.mdm` exposed only entity/prospect/
     * collection. This is the wiring, nothing more — no new rule, no new storage.
     *
     * An attachment is ORTHOGONAL to the record it belongs to (`entityType` + `entityId` + `category`), which
     * is why a photo never becomes a field of the ontology. AUTHORIZATION v1 is the owner's: whoever may read
     * or edit the record may list and attach — the caller has already been through the route's own gate, and a
     * finer rule needs the party/dataScope work that is not here yet.
     *
     * The BYTES are not this API's business: it registers metadata plus a `storageKey`. Uploading through
     * `/execBff` (JSON) is never right; that is what the presigned-URL entry point is for.
     */
    export class MdmAttachment {
        private readonly ctx;
        constructor(ctx: RequestContext);
        attach(input: AttachFileParams): Promise<MdmAttachmentRecord>;
        detach(input: DetachFileParams): Promise<{
            id: string;
            deleted: true;
        }>;
        /**
         * LIVE attachments of a record (optionally one category).
         *
         * `detach` is a SOFT delete — it stamps `deletedAt` — and the underlying query does not filter it, so a
         * gallery built straight on it would keep showing a photo the user removed. Filtering here keeps the
         * usecase (and the existing `mdm.attachment.*` route, which returns the full history) untouched, and
         * `includeDetached` is there for whoever wants the history on purpose.
         */
        listByEntity(input: FindAttachmentsByEntityParams & {
            includeDetached?: boolean;
        }): Promise<MdmAttachmentRecord[]>;
    }
    export class MdmIdentity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        findByLogin(email: string): Promise<string | null>;
        setLogin(mdmId: string, email: string): Promise<{
            mdmId: string;
            email: string;
        }>;
        invite(input: MdmIdentityInviteInput): Promise<MdmIdentityInviteResult>;
    }
    export function createMdmFacade(ctx: RequestContext): MdmFacade;
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    import type { ICacheRuntime } from "_102034_/l1/server/layer_1_external/cache/CacheRuntimeMemory";
    import type { MdmFacade } from "_102034_/l1/mdm/layer_3_usecases/mdmFacade";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
            userId?: string;
            authToken?: string;
            /**
             * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
             * usefully — the http transport overwrites them from the JWKS-verified token, and every other
             * identity field of this meta is discarded on that transport. This is the only channel through which
             * a request may tell execBff who it is.
             */
            verifiedUserId?: string;
            verifiedEmail?: string;
            /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
            verifiedAuthorities?: string[];
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            actorId?: string;
            actorScope?: string[];
            activeCompanyId?: string;
            activeUnitId?: string;
            workspaceId?: string;
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRegionName = 'header' | 'aside' | 'content';
    export interface FrontendDynamicRegionConfig {
        renderer: FrontendRegionRendererRegistration;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface FrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, FrontendDynamicRegionConfig>;
    }
    export interface FrontendClientShellConfig {
        mode: ShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: FrontendShellRegionProfiles;
            aside?: FrontendShellRegionProfiles;
        };
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestBusinessContext {
        activeCompanyId?: string;
        activeUnitId?: string;
    }
    export interface RequestActorSession {
        actorId?: string;
        scope?: string[];
    }
    export interface RequestCurrentWorkspace {
        workspaceId?: string;
    }
    export interface RequestProjectContext {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface RequestOrganizationContext {
        countryCode: string;
        currency?: string;
        timezone?: string;
    }
    /** Person resolved from the login row of `mdm_tag`. Absent when the e-mail has no login. */
    export interface PlatformSessionPerson {
        mdmId: string;
        email: string;
        name: string;
    }
    export interface CollabAuthInviteClient {
        createInvite(input: {
            orgId: string;
            email: string;
            apiKey: string;
            moduleId: string;
            actorId: string;
        }): Promise<{
            token: string;
            expiresAt: string;
            teamIds?: string[];
        }>;
    }
    export interface RequestSessionContext {
        activeCompanyId?: string;
        activeUnitId?: string;
        actorId?: string;
        actorScope?: string[];
        workspaceId?: string;
        /** Set when `mdm.identity.findByLogin` resolves the verified e-mail. */
        person?: PlatformSessionPerson;
        businessContext: RequestBusinessContext;
        actorSession: RequestActorSession;
        currentWorkspace: RequestCurrentWorkspace;
        project: RequestProjectContext;
    }
    export interface RequestContext {
        data: IDataRuntime;
        mdm: MdmFacade;
        cache: ICacheRuntime;
        /** Test/override seam for collab-auth invites. Production uses COLLAB_AUTH_* env. */
        collabAuthInvite?: CollabAuthInviteClient;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        sessionContext: RequestSessionContext;
        /**
         * Caller module of this BFF (`ordenServicio2`). Absent on platform/test callers.
         * `organization` is the super module: unfiltered MDM reads and writes.
         */
        moduleId?: string;
        /** Installation/org locale — never derived from UI language. */
        organization: RequestOrganizationContext;
        sandbox?: boolean;
        requestMeta?: {
            requestId?: string;
            /**
             * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
             * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
             */
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ControllerRoute {
        key: string;
        handler: BffHandler;
    }
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        languages?: string[];
        designSystems?: string[];
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
        clientShell?: FrontendClientShellConfig;
        /** Same-origin favicon href injected into the served HTML (`<link rel="icon">`). */
        faviconHref?: string;
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentLimits" {
    export const DEFAULT_ATTACHMENT_MAX_BYTES: number;
    export const DEFAULT_ATTACHMENT_ALLOWED_MIME: readonly ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"];
    export interface AttachmentLimits {
        maxBytes: number;
        allowedMime: readonly string[];
    }
    export function defaultAttachmentLimits(): AttachmentLimits;
    export function parseAllowedMime(value: string | undefined): string[];
    export function validateAttachmentPayload(input: {
        mimeType: string;
        sizeBytes: number;
        limits?: AttachmentLimits;
    }): void;
    /** Decode the body of a dedicated upload route. `data:` URLs are stripped; raw base64 is accepted. */
    export function decodeAttachmentBase64(raw: string): Buffer;
}
declare module "_102034_/l1/server/layer_1_external/storage/objectBuckets" {
    /**
     * Object-storage buckets of a published app.
     *
     * One PERMANENT bucket per client project, named with the project id (default `collab-{projectId}`).
     * Business attachments (a pet photo, a signed PDF) live there and nowhere else — a lifecycle rule
     * that expires objects would leave `mdm_attachment` pointing at a dead key.
     *
     * A second, OPTIONAL tmp bucket (default `collab-{projectId}-tmp`) exists for ephemeral artifacts
     * (LLM images that may vanish). MDM attachments never use it. Empty `S3_BUCKET_TMP` disables it.
     *
     * Without AWS credentials, without a resolvable project id, or with `S3_BUCKET` explicitly empty,
     * the runtime falls back to local disk. The reason is always named — never a generic S3 crash.
     */
    export type ObjectBucketKind = 'permanent' | 'tmp';
    export type ObjectStorageProvider = 's3' | 'local';
    export const DEFAULT_PERMANENT_BUCKET_PATTERN = "collab-{projectId}";
    export const DEFAULT_TMP_BUCKET_PATTERN = "collab-{projectId}-tmp";
    export interface ObjectBucketResolution {
        provider: ObjectStorageProvider;
        projectId: string;
        /** Permanent bucket name (S3) or directory leaf (local). Always set. */
        permanent: string;
        /** Tmp bucket name, or null when the operator disabled it. MDM attach never reads this. */
        tmp: string | null;
        /** Why we are on `local`, empty when S3 is ready. */
        localReason: string;
    }
    export interface ObjectBucketEnv {
        s3BucketPattern?: string | null;
        s3BucketTmpPattern?: string | null;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        projectId?: string;
    }
    export function applyProjectId(pattern: string, projectId: string): string;
    export function resolveObjectBuckets(env: ObjectBucketEnv): ObjectBucketResolution;
    export function bucketFor(kind: ObjectBucketKind, resolution: ObjectBucketResolution): string | null;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        /** Minute tick that calls `onTick` of each module. Same gate as write-behind: postgres only. */
        tickEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
        testsEnabled: boolean;
        projectId?: string;
        projectDomain?: string;
        studioEnabled: boolean;
        activeCompanyId?: string;
        activeUnitId?: string;
        currentWorkspaceId?: string;
        actorId?: string;
        actorScope: string[];
        /**
         * Organization country (ISO 3166-1 alpha-2). Installation default `US` (MDM ontology).
         * Not derived from UI language. Platform org config is a pending source.
         */
        organizationCountryCode: string;
        organizationCurrency?: string;
        organizationTimezone?: string;
        /**
         * Permanent object-storage bucket pattern. `{projectId}` is replaced with the client project
         * (default `collab-{projectId}`). Empty string forces local disk.
         */
        s3BucketPattern: string;
        /** Optional tmp bucket pattern (default `collab-{projectId}-tmp`). Empty disables it. MDM never uses it. */
        s3BucketTmpPattern: string;
        attachmentMaxBytes: number;
        attachmentAllowedMime: string[];
        attachmentLocalDir?: string;
        /**
         * Redis connection URL. Present on the VM (`install.sh` installs Redis); absent on lima.
         * Identity cache branches on this capability, never on the host name.
         */
        redisUrl?: string;
        /** TTL of `identity:login:<email>` cache entries. Default 300 s. */
        identityCacheTtlSeconds: number;
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
        /** Partial-index predicate, e.g. `"namespace" = 'login'`. */
        where?: string;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
        seedRows?: Array<Record<string, unknown>>;
    }
    /** Seed rows shipped in a separate file inside the module's tableDefsDir (so generated
     *  table definitions stay untouched). Discovered by shape, like TableDefinition. */
    export interface TableSeedRows {
        seedFor: string;
        rows: Array<Record<string, unknown>>;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        logicalTableName: string;
        dynamoResolvedTableName: string | null;
    }
    /** Column fields the Postgres rebuild materializes. Seed rows are not part of the snapshot. */
    export interface SchemaSnapshotColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
            columns: SchemaSnapshotColumn[];
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    /** A project is namespaced when it owns application (client) tables. Platform tables live in
     *  master-backend / lib projects and stay on their canonical, shared names. */
    export function isClientProjectType(projectType: string | undefined): boolean;
    /** Physical-name prefix for a client project. `mls` keeps the identifier unquoted-safe in Postgres
     *  (a bare `102051_order` would require quoting everywhere), and readable. */
    export function projectTableNamespacePrefix(projectId: string): string;
    /** Lowercased module token used as the physical-name prefix. `listaAssinatura3` → `listaassinatura3_`.
     *  Keep in sync with `moduleTableNamespacePrefix` in mls-102021 (l2 cannot import this file). */
    export function moduleTableNamespacePrefix(moduleId: string): string;
    /** Strip the module prefix CB now emits on `tableName`, so lookup stays `petition_signature`.
     *  Idempotent on older tables that were generated without the prefix. */
    export function logicalTableNameFromEmitted(emittedName: string, moduleId: string): string;
    /** Lookup keys: repositoryName, unprefixed logical name, physical name, and the CB-emitted
     *  (module-prefixed, pre-project) name adapters copy from TableDefinition.tableName. */
    export function matchesTableLookup(definition: Pick<ResolvedTableDefinition, 'repositoryName' | 'logicalTableName' | 'tableName' | 'projectId'>, key: string): boolean;
    /**
     * Namespaces a physical storage name (Postgres table or DynamoDB table) with the owning project when
     * that project owns application tables, so several client projects can share one database/schema on a
     * VM without colliding on generic names (`order`, `daily_shift`, ...). Platform tables (mdm_*, monitor,
     * _schema_migrations) belong to master/lib projects and are left on their canonical names. Idempotent:
     * a name already carrying the prefix is returned unchanged.
     */
    export function applyProjectTableNamespace(physicalName: string, projectId: string, projectType: string | undefined): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/persistence/emitPersistence" {
    /**
     * Persistence recipes. Column placement follows the table def and the entity
     * leaves. A derived or platform storage target does not become a local table.
     * The migration plan is an additive diff of the schema snapshot shape. A
     * destructive step is a block, never a DROP. The plan is not an applied migration.
     */
    import { type M1Definition, type M1Verification } from "_102021_/l2/helpers/l1Defs/definition";
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import { type EmitFailure, type StructureRead } from "_102021_/l2/agentMaterializeL1/handlers/structure/emit";
    const PLAN_FORMAT = "102034-schema-snapshot";
    export interface ColumnBinding {
        field: string;
        column: string;
        nullable: boolean;
        placement: 'column' | 'json';
    }
    export interface PlannedColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface PlannedIndex {
        name: string;
        columns: string[];
        unique: boolean;
    }
    export interface PlannedTable {
        tableName: string;
        primaryKey: string[];
        columns: PlannedColumn[];
        indexes: PlannedIndex[];
    }
    export interface AdditiveStep {
        op: 'createTable' | 'addColumn' | 'createIndex';
        tableName: string;
        name: string;
    }
    export interface BlockedStep {
        op: 'removeTable' | 'removeColumn' | 'removeIndex' | 'alterColumn';
        tableName: string;
        name: string;
        reason: 'DESTRUCTIVE_OUT_OF_SCOPE';
    }
    export interface AdditivePlan {
        format: typeof PLAN_FORMAT;
        applied: false;
        steps: AdditiveStep[];
        blocked: BlockedStep[];
    }
    export interface PhysicalAssert {
        ok: boolean;
        isolated: boolean;
        code: string;
        detail: string;
    }
    export interface PersistenceEmit {
        source: string;
        imports: string[];
        runsStub: boolean;
        seeds: boolean;
        evidences: M1Verification[];
    }
    interface BuiltTable {
        definition: TableDefinition;
        bindings: ColumnBinding[];
        planned: PlannedTable;
    }
    export function additivePlan(desired: readonly PlannedTable[], previous: readonly PlannedTable[] | null): AdditivePlan;
    export function applyPlan(previous: readonly PlannedTable[] | null, plan: AdditivePlan, desired: readonly PlannedTable[]): {
        ok: boolean;
        tables: PlannedTable[];
    };
    export function assertPhysicalSchema(expected: PlannedTable | null, actual: PlannedTable | null): PhysicalAssert;
    export function withoutUniqueChecks(source: string): string;
    export function emitPersistence(id: string, definition: M1Definition, output: string, read: StructureRead): Promise<PersistenceEmit | EmitFailure>;
    export function buildLocalTable(definition: M1Definition, entity: M1Definition): BuiltTable | EmitFailure;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/persistence/runners" {
    import type { HandlerCall, HandlerOutcome, MaterializeHandlerRunner } from "_102021_/l2/agentMaterializeL1/run/execute";
    export const persistenceRunners: Readonly<Record<string, MaterializeHandlerRunner>>;
    export function persistenceHandlerIds(): string[];
    export function runPersistence(call: HandlerCall): Promise<HandlerOutcome>;
}
declare module "_102021_/l2/agentMaterializeL1/handlers/structure/runners" {
    import type { HandlerCall, HandlerOutcome, MaterializeHandlerRunner } from "_102021_/l2/agentMaterializeL1/run/execute";
    export const structureRunners: Readonly<Record<string, MaterializeHandlerRunner>>;
    export function structureHandlerIds(): string[];
    export function runStructure(call: HandlerCall): Promise<HandlerOutcome>;
}
declare module "_102021_/l2/agentMaterializeL1/state/localBindings" {
    import type { MaterializeReadIo } from "_102021_/l2/agentMaterializeL1/core/io";
    import type { MaterializeStateStore } from "_102021_/l2/agentMaterializeL1/core/state";
    export interface LocalFiles {
        read(ref: string): Promise<string | null>;
        write(ref: string, body: string): Promise<void>;
        remove(ref: string): Promise<boolean>;
        /** True when this call created the file. False when it already existed. */
        createExclusive(ref: string, body: string): Promise<boolean>;
    }
    export interface LocalWriter {
        claim(moduleName: string, holder: string): Promise<boolean>;
        release(moduleName: string, holder: string): Promise<void>;
    }
    export interface LocalProjectLock {
        claim(projectId: number, holder: string): Promise<boolean>;
        release(projectId: number, holder: string): Promise<void>;
    }
    export function createLocalBindings(io: MaterializeReadIo, files: LocalFiles): {
        state: MaterializeStateStore;
        writer: LocalWriter;
        projectLock: LocalProjectLock;
    };
}
declare module "_102021_/l2/agentMaterializeL1/studioHost" {
    import type { PlanUnitInput } from "_102021_/l2/agentMaterializeL1/planner/plan";
    import type { MaterializeRunHost } from "_102021_/l2/agentMaterializeL1/run/execute";
    export function loadStudioUnits(project: number, moduleName: string): Promise<PlanUnitInput[]>;
    /** Stor key of l5 files: `level: 5, folder: ''`. */
    export function readStudioProfile(project: number): Promise<{
        mode: unknown;
        declared: boolean;
    }>;
    export function createStudioHost(project: number): MaterializeRunHost;
}
declare module "_102021_/l2/agentMaterializeL1/agentMaterializeL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentMaterializeL1/fixtures/cases" {
    import { type M1ArtifactType, type M1Definition, type M1Status, type MaterializationReceipt, type ReferenceIndex } from "_102021_/l2/helpers/l1Defs/definition";
    export const M1_FIXTURE_PROJECT = 102047;
    export const M1_FIXTURE_MODULE = "agendaClinica";
    export function defPathOf(type: M1ArtifactType, artifactId: string): string;
    export const M1_PLATFORM_RULES = "_102047_/l4/agendaClinica/rules.defs.ts";
    export const M1_CONTRACT_PROFESSIONAL = "_102047_/l2/agendaClinica/web/contracts/consultas_profissional.defs.ts";
    export const M1_CONTRACT_RECEPTION = "_102047_/l2/agendaClinica/web/contracts/consultas_recepcionista.defs.ts";
    const CONSULTA: string;
    const PROFISSIONAL = "_102047_/l1/agendaClinica/layer_3_domain/entities/profissional.defs.ts";
    const PACIENTE = "_102047_/l1/agendaClinica/layer_3_domain/entities/paciente.defs.ts";
    const PORT: string;
    const TABLE: string;
    const ADAPTER: string;
    const LIST: string;
    const PAGE: string;
    const SCOPE: string;
    const AUTHORITY: string;
    const REGISTER: string;
    const SEEDS: string;
    const OUTBOUND: string;
    const SLOT: string;
    export const consultaEntity: M1Definition;
    export const scheduleSlot: M1Definition;
    export const consultaPort: M1Definition;
    export const consultaTable: M1Definition;
    export const consultaAdapter: M1Definition;
    export const listConsultaPending: M1Definition;
    export const consultasService: M1Definition;
    export const consultasController: M1Definition;
    export const accessScope: M1Definition;
    export const authorityMap: M1Definition;
    export const registration: M1Definition;
    export const seeds: M1Definition;
    export const outbound: M1Definition;
    export const definitionsByType: Record<M1ArtifactType, M1Definition>;
    export const indexedUnits: {
        defPath: string;
        definition: M1Definition;
    }[];
    export const fixtureIndex: ReferenceIndex;
    export function withStatus(definition: M1Definition, status: M1Status): M1Definition;
    export function listConsultaReceipt(semanticHash: string): MaterializationReceipt;
    export function blockedReceipt(): MaterializationReceipt;
    export function failedReceipt(): MaterializationReceipt;
    export const LIST_CONSULTA_EXAMPLE = "{\n  \"schemaVersion\": \"2026-09-24-d1-definition-v2\",\n  \"artifactType\": \"usecase\",\n  \"artifactId\": \"listConsulta\",\n  \"moduleName\": \"agendaClinica\",\n  \"status\": \"pending\",\n  \"dependencies\": [\n    \"_102047_/l1/agendaClinica/layer_2_application/ports/consultaRepository.defs.ts\",\n    \"_102047_/l1/agendaClinica/layer_3_domain/entities/consulta.defs.ts\",\n    \"_102047_/l2/agendaClinica/web/contracts/consultas_profissional.defs.ts\",\n    \"_102047_/l2/agendaClinica/web/contracts/consultas_recepcionista.defs.ts\",\n    \"_102047_/l4/agendaClinica/rules.defs.ts\"\n  ],\n  \"data\": {\n    \"usecaseId\": \"listConsulta\",\n    \"entityId\": \"Consulta\",\n    \"operation\": \"list\",\n    \"ports\": [\"ConsultaRepository\"]\n  }\n}";
    export { CONSULTA, LIST, PORT, TABLE, ADAPTER, PAGE, SCOPE, AUTHORITY, REGISTER, SEEDS, OUTBOUND, SLOT, PACIENTE, PROFISSIONAL };
}
declare module "_102021_/l2/agentMaterializeL1/register/cbReconcileBackendConfig" {
    export interface LiveBackendModule {
        moduleId: string;
        backendControllers: string;
        tableDefsDir: string;
    }
    export interface ReconcileBackendConfigResult<M extends Record<string, unknown>, P extends Record<string, unknown>> {
        modules: M[];
        persistenceModules: P[];
        discarded: string[];
    }
    export function formatDiscardedOrphans(discarded: readonly string[]): string;
    export function liveBackendModulesFromL5(l5Modules: unknown): LiveBackendModule[];
    /** Drop l5/project.json backend blocks whose persistence dir is gone, except the module this run owns. */
    export function pruneOrphanL5BackendModules<M extends Record<string, unknown>>(modules: readonly M[] | undefined, currentModuleName: string, tableDefsExists: (moduleName: string) => boolean): {
        modules: M[];
        discarded: string[];
    };
    export function reconcileClientBackendRegistration<M extends Record<string, unknown>, P extends Record<string, unknown>>(existingModules: readonly M[] | undefined, existingPersistence: readonly P[] | undefined, live: readonly LiveBackendModule[]): ReconcileBackendConfigResult<M, P>;
}
declare module "_102021_/l2/agentMaterializeL1/testing/oracleModule" {
    /**
     * Neutral module for the memory tests of m1_27/m1_28: defs, contracts and the p1_12 testSupport.
     * Every id comes from `Names`, so a renamed copy must derive the same. Test support only.
     */
    import { type M1Definition } from "_102021_/l2/helpers/l1Defs/definition";
    import { type DerivedCatalog } from "_102021_/l2/agentMaterializeL1/testing/derive";
    /**
     * `Parent` is a local entity the main one references (related data, created first); `Mdm` is an
     * MDM entity the runtime owns (the fixture never creates it).
     */
    export interface Names {
        project: string;
        mod: string;
        Entity: string;
        entity: string;
        owner: string;
        org: string;
        Anchor: string;
        ownerField: string;
        note: string;
        related: string;
        Parent: string;
        parent: string;
        parentField: string;
        Mdm: string;
        mdmField: string;
    }
    export const BASE: Names;
    export const RENAMED: Names;
    export interface Fixture {
        n: Names;
        refs: {
            entity: string;
            port: string;
            parentEntity: string;
            parentPort: string;
            scope: string;
            authority: string;
            uc: (id: string) => string;
            ctrl: (page: string) => string;
            office: string;
            deck: string;
            ontology: string;
        };
        /** `backend.json.testSupport[]` in the p1_12 shape, as the planner derives it for this module. */
        testSupport: unknown[];
        routes: {
            create: string;
            update: string;
            officeList: string;
            deckList: string;
            sail: string;
        };
        defs: Array<[string, string, M1Definition]>;
        controllers: Array<[string, M1Definition]>;
        texts: Record<string, string>;
    }
    export function fixture(n: Names): Fixture;
    export function derive(fx: Fixture, texts?: Record<string, string>): DerivedCatalog;
    /** Local tables persistence40 would plan for this module. */
    export function tablesOf(fx: Fixture): Array<{
        tableId: string;
        entityId: string;
    }>;
    export function definitionsOf(fx: Fixture): Map<string, M1Definition>;
}
declare module "_102021_/l2/agentPlannerL1/helpers/defsSource" {
    /**
     * Pure readers of the l4/l5 defs dialects, with no platform imports, so they can be tested directly.
     * Two generators write the artifacts this agent reads: ns/ns3 emitted `} as const;`, and ns4 emits
     * `} as const satisfies <Artifact>;` over a typed import.
     */
    export type CbEntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm' | 'external' | 'derived';
    /**
     * MDM WRITE PATH — off until the general rebuild.
     *
     * The l4 already declares the intention this switch honours (`storage.target: mdm | external |
     * moduleDatabase`, `storage.mdmType`, v6 vocabulary), so reading it is not a new-vocabulary migration:
     * it would change the classification of the module Wagner is testing (run 9 of buildFlowFsm, where
     * Client/Project/InventoryItem carry `target: mdm` and FieldWorker/PlatformUser carry `target:
     * external`) the moment the next generation runs. That is exactly what the ⏸️ of the spec forbids.
     *
     * Flipping this to `true` moves four things at once, which is why it is one constant and not four:
     *   1. `classifyEntityKind` stops mapping `mdm + moduleOwned` to `core` and starts honouring
     *      `storage.target` — so an MDM entity gets no local domain entity, port, adapter or table, and an
     *      `external` one gets none of those and no seeds either;
     *   2. the seed planner routes those entities to `mdmEntities` (102034 registry) instead of
     *      `localTables`, and drops `external` entities from the plan entirely;
     *   3. the usecase item carries `mdmWrites` (mdmType + subtype + idField), so create/update/delete of
     *      master data is generated against `ctx.mdm` — the surface skills/applicationUsecase.md already
     *      documents — instead of a local port;
     *   4. validate-all blocks on a local persistence/port/domain artifact for an MDM entity instead of
     *      only warning about it (`collectPersistencePolicyIssues`).
     *
     * The order of the general rebuild is in the spec: ns4 vocabulary first (`party`, `platformUserId`),
     * then this flag, then `/rebuild all`.
     *
     * FLIPPED ON 2026-08-24 by Wagner's decision, with the next run being a `/rebuild all`. The two
     * prerequisites above were already met. Note what the flip does NOT do: it changes how the NEXT
     * generation classifies entities, so a module generated while it was `false` keeps its local tables
     * until it is rebuilt. There is no partial reversal — a module is generated in one shape or the other.
     */
    export const MDM_WRITE_PATH_ENABLED = true;
    /** What `storage` declares about an entity: where it lives, and under which master-data type. */
    export interface CbEntityStorage {
        target: string;
        scope: string;
        mdmType: string;
        idField: string;
    }
    export function readEntityStorage(parsed: Record<string, unknown>): CbEntityStorage;
    /** Schema string the NS E4 emits for ontology v7 (`n04`, 2026-09-08). */
    export const CB_ONTOLOGY_SCHEMA_V7 = "2026-09-08-ns4-ontology-v7";
    /** Named scan error when a v7 entity omits `storage.idField`. Never fall back to a name suffix. */
    export const CB_SCAN_ID_FIELD_REQUIRED = "CB_SCAN_ID_FIELD_REQUIRED";
    /**
     * l4 ontology schema generation. v7 carries `mdmSubtype` / `role` / `displayField` / required
     * `storage.idField`. Anything older is v6 and is read until the module is regenerated (2026-09-08).
     */
    export function ontologyDefsVersion(parsed: Record<string, unknown>): number;
    export type CbLifecycleReachedBy = 'actor' | 'command' | 'time';
    export interface CbLifecycleStateDecl {
        state: string;
        reachedBy: CbLifecycleReachedBy;
        ruleRef?: string;
    }
    /** Bare string = actor. Time states are computed on read and never persisted by default. */
    export function readLifecycleStates(value: unknown): CbLifecycleStateDecl[];
    export interface CbOntologyEntityRead {
        storage: CbEntityStorage;
        mdmSubtype: string;
        role: string;
        displayField: string;
        defsVersion: number;
        scanError?: {
            code: string;
            message: string;
        };
    }
    /**
     * v7 fields on an ontology entity. v6 modules keep compiling: missing `mdmSubtype`/`role`/
     * `displayField` are empty strings, and a missing `idField` is not a scan error until v7.
     */
    export function readOntologyEntity(parsed: Record<string, unknown>): CbOntologyEntityRead;
    export interface CbOntologyRelationshipRead {
        fromEntity: string;
        toEntity: string;
        type: string;
        persistenceMode: string;
        fromFieldIds: string[];
        toFieldIds: string[];
    }
    /** `ontology/index.defs.ts` `relationships[]` — the only FK source on v7. */
    export function readOntologyRelationships(index: Record<string, unknown>): CbOntologyRelationshipRead[];
    /** Foreign-key field ids declared for `entityId` on either end of a relationship. */
    export function fkFieldIdsForEntity(entityId: string, relationships: ReadonlyArray<{
        fromEntity: string;
        toEntity: string;
        fromFieldIds?: readonly string[];
        toFieldIds?: readonly string[];
    }>): Set<string>;
    /**
     * The kind this agent generates from, deciding between the two vocabularies AND the two policies.
     *
     * With the write path OFF the answer is exactly what it has always been (`entityKindOf`), so a run of
     * the current module is byte-identical. With it ON, `storage.target` — the field that actually carries
     * the l4 intention — wins over the pair kind/ownership: `mdm` means master data owned by 102034 (the
     * module writes it THROUGH the facade), and `external` means an identity that lives outside this
     * product (a platform user), which must never become a local table and must never be seeded.
     */
    /**
     * What a caller knows about an entity. `storage` is PARTIAL because only `readEntityStorage` produces the
     * complete block — a caller that has just `{ target }` (a fixture, a scan of an older l4) asks the same
     * question and must not have to invent the other three fields.
     */
    export interface CbEntityClassification {
        kind: string;
        ownership?: string;
        storage?: Partial<CbEntityStorage>;
    }
    /** A declaration that contradicts itself, for the scan to announce instead of resolving in silence. */
    export function contradictoryStorageDeclaration(input: CbEntityClassification): string;
    export function classifyEntityKind(input: CbEntityClassification, mdmWritePath?: boolean): CbEntityKind;
    export function parseDefsSource(content: string): unknown;
    /**
     * Replace only the value of a defs file, keeping everything the generator wrote around it — the
     * header, the `import type`, the `satisfies` and the trailing exports. The todo files belong to the
     * generator that emitted them; this agent only flips a status inside them.
     */
    export function replaceDefsValue(content: string, value: unknown): string | null;
    /**
     * The handler vocabulary is `query | command`, but `operation.kind` speaks the generator's dialect:
     * ns/ns3 said create|update|query|view, ns4 says list|getById|create|update|delete|transition|
     * commandInput. Only reads are queries; everything else writes.
     */
    export function handlerKindOf(opKind: string): 'query' | 'command';
    /**
     * ns4 classifies a read-model as `projection`, which is what `metric` already meant here: not an
     * aggregate root by itself, but still backed by a table and seeds WHEN an operation reads it (that
     * is how a dashboard answers at runtime). Casting it silently would land on `core` and give a
     * projection nobody queries a table of its own.
     *
     * `mdm` means two different things in the two vocabularies, and the difference is the OWNERSHIP:
     * here it has always meant "master data read by id through 102034 — no local table, no port, never
     * written locally", while ns4 writes `mdm` + `ownership: moduleOwned` for master data THIS MODULE
     * owns and publishes, and compiles create/update/delete over it. Read as external, those operations
     * have nowhere to live: run 8 of buildFlowFsm generated 4 stub usecases (`functions: []`) for
     * Client/InventoryItem/Project and the final gate failed with 12 "export not found". Owned master
     * data is a local aggregate — table, port, CRUD, seeds — which is exactly `core`.
     */
    export function entityKindOf(kind: string, ownership?: string): CbEntityKind;
    /** A ns4 workflow: the lifecycle of one entity, with states and transitions and no operations. */
    export function isEntityLifecycle(parsed: Record<string, unknown>): boolean;
    /**
     * The module a `TS2792 Cannot find module '<path>'` names, or '' for any other diagnostic.
     *
     * A generated file that imports a platform contract of another project (`/_102034_/l1/...`) compiles
     * against a Monaco model this agent borrows for the compile. When the borrow silently fails the
     * diagnostic is indistinguishable from a real broken import — and the seed run of 2026-08-16 died on
     * one, after two earlier waves had compiled the very same file. Recognizing the shape is what lets
     * the caller ask "does this file actually exist?" instead of blaming the plan.
     */
    export function phantomModulePathOf(diagnostic: string): string;
    /** `/_102034_/l1/server/.../contracts.js` -> the file coordinates of its source. */
    export function mlsImportPathParts(path: string): {
        project: number;
        level: number;
        folder: string;
        shortName: string;
    } | null;
    /**
     * The cross-project module a resolution diagnostic names, whatever the compiler called it
     * (TS2792 "cannot find module … did you mean to set moduleResolution", TS2307 "cannot find module").
     *
     * Used where the file under compile is written by THIS agent from a fixed template — the seeds. There
     * the import is not a claim the LLM made (it only plans data rows), so a module that does not resolve
     * is an environment fact, and asking `mls.stor.files` whether the target exists measures the wrong
     * thing: it measures whether the session indexed the other project, not whether the plan is wrong.
     */
    export function aliasModuleResolutionPathOf(diagnostic: string): string;
    /**
     * Monaco's "model already exists" — raised by `addModels` for a file whose model IS loaded, under a
     * registry key this agent's guard does not compute. The goal of the call (a usable model) is already
     * met, so the caller treats it as success; reading it as a failure logged the same warning forever
     * and left the import unborrowed.
     */
    export function isModelAlreadyExistsError(message: string): boolean;
    const TODO_STATUS_FIELDS: readonly ["status", "statusBackend"];
    export function todoOwnerType(raw: string): 'operation' | 'workflow' | '';
    /** The field the file actually uses, so the write-back lands where the read came from. */
    export function todoStatusField(raw: Record<string, unknown>): typeof TODO_STATUS_FIELDS[number] | '';
    /** The key both sides of a read-back agree on: the owner kind AFTER the dialect alias, plus its id. */
    export function todoOwnerKey(kind: string, id: string): string;
    export interface CbTodoDivergence {
        /** `operation:listBusinessHours` — todoOwnerKey of the owner that does not match. */
        key: string;
        expected: string;
        /** The status the source carries, or `<missing>` when the owner is not in it at all. */
        found: string;
    }
    /**
     * Compare the statuses a run BELIEVES it wrote against the ones a todoBackend source actually carries.
     * Pure on purpose: this is the comparator behind the finalize read-back, and it has to be testable
     * without a stor, a model or a browser.
     *
     * Returns `null` when the source cannot be parsed at all — for the caller that is not "no divergence",
     * it is "unreadable", which is its own kind of failure.
     */
    export function todoStatusDivergences(content: string, expected: ReadonlyMap<string, string>): CbTodoDivergence[] | null;
    /**
     * Which l5 todoBackend file the finalize read-back should open. `moduleName` empty keeps the
     * historical first-file-in-the-project behaviour (single-module runs). Folder is compared by
     * equality, never substring: a module `todo` must not match `todoAvancado`.
     *
     * `none` = this project has no todoBackend at all (caller reports skip).
     * `module-missing` = other modules have a file, this one does not (the run wrote owners whose
     * file vanished — not the same as skip).
     */
    export type CbTodoReadBackPick = {
        kind: 'file';
        folder: string;
        ref: string;
    } | {
        kind: 'none';
    } | {
        kind: 'module-missing';
        moduleName: string;
        ref: string;
    };
    export function pickTodoBackendReadBack(folders: readonly string[], moduleName?: string): CbTodoReadBackPick;
    /**
     * Which l5 todoBackend file a status write should mutate. Prefer the file whose folder is the
     * owner's module; if that file exists but does not contain the owner, do NOT fall through to
     * another module (shared ids like `createTask` would corrupt the neighbour). Empty moduleName
     * keeps the historical search-by-owner-identity.
     */
    export function selectTodoBackendFileForStatusWrite<T extends {
        folder: string;
        content: string;
    }>(files: readonly T[], owner: {
        kind: string;
        id: string;
        moduleName: string;
    }): T | undefined;
    /**
     * MDM semantics the ns4 catalogue attaches to an operation whose entity declares
     * `storage.target: 'mdm'` (`Ns4E8MdmSemantics` -> `Ns4ClassicOperation.mdm`). Measured on
     * `mls-102047/l4/petShop/operations/`:
     *
     *   inactivateCustomer.defs.ts -> `"mdm": { "lifecycle": "inactivate" }`
     *   listCustomer.defs.ts       -> `"mdm": { "activeFilterInput": "includeInactive",
     *                                           "situationOutput": "active" }`
     *
     * It exists because master data is NEVER deleted: the tier-1 catalogue emits the inactivate/reactivate
     * pair instead of a delete, the list hides inactive records by default, and the situation shown on
     * screen derives from the MDM index status — never from an invented local `active` field.
     *
     * `activeFilterInput` names an input that does NOT exist in the operation's `inputs[]` (the ns4 gate
     * requires every input fieldRef to resolve to a real ontology field, and `includeInactive` is not one),
     * so the CB is what has to materialize it. See `synthesizeMdmInputs` in cbShared.
     */
    export interface CbOwnerMdm {
        /** 'inactivate' | 'reactivate' — the cadastral pair that replaces delete for master data. */
        lifecycle?: string;
        /** Name of the boolean input that opts INTO seeing inactive records. */
        activeFilterInput?: string;
        /** Name of the derived output field carrying the situation (from the index status). */
        situationOutput?: string;
    }
    /**
     * Absent (not empty) when the operation carries no `mdm` block — the l4s that predate the block must
     * produce byte-identical owners, which is what makes this readable without touching the write-path flag.
     */
    export function readOwnerMdm(parsed: Record<string, unknown>): CbOwnerMdm | undefined;
    /** Is this the cadastral pair (as opposed to an ordinary MDM update)? */
    export function isMdmLifecycle(mdm: CbOwnerMdm | undefined): boolean;
    /**
     * Pin the l4 `mdm` block onto the usecase defs the model just returned. The model implements the
     * body; this block is not its to invent or drop. Without the pin, `saveDefs` writes the model
     * output and `collectMdmLifecycleIssues` (which reads `data.mdm` of that defs) stays blind — three
     * petShop runs in a row emitted no-op lifecycles with the agent already correct in the build.
     */
    export function pinUsecaseL4Mdm(result: Record<string, unknown>, ownerMdm: CbOwnerMdm | undefined): void;
    /** Structural mirror of cbShared.CbOperationInput — declared here so this module stays platform-free. */
    export interface CbMdmOperationInput {
        inputId: string;
        fieldRef: string;
        type?: string;
        required: boolean;
        source: string;
        description: string;
    }
    /**
     * The one input the l4 CANNOT declare. `mdm.activeFilterInput` names a boolean flag (`includeInactive`)
     * that opts into seeing inactive records, but the ns4 gate requires every input `fieldRef` to resolve to
     * a real ontology field — and `includeInactive` is not a field of anything. Measured on the evidence:
     * `listCustomer.defs.ts` declares `activeFilterInput: 'includeInactive'` with `inputs: []`.
     *
     * So the CB materializes it here, at the SINGLE place owners are read, instead of only in the usecase
     * prompt: the http controller derives its boundary contract from `owner.inputs` too, and an input the
     * controller never learned about is a flag the caller cannot pass.
     *
     * `required: false` on purpose — the default behaviour is active-only, and a required flag would make
     * every existing caller of the list illegal.
     */
    export function synthesizeMdmInputs(inputs: CbMdmOperationInput[], mdm: CbOwnerMdm | undefined): CbMdmOperationInput[];
}
declare module "_102021_/l2/agentPlannerL1/helpers/l1Inventory" {
    /** agentChangeBackend was deleted (p4_15); this is now the single source for the owner status enum. */
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export interface L1InventoryField {
        name: string;
        type?: string;
        fieldRef?: string;
    }
    export interface L1InventoryFunction {
        name: string;
        input: L1InventoryField[];
        output: L1InventoryField[];
    }
    export interface L1InventoryUsecase {
        usecaseId: string;
        file: string;
        functions: L1InventoryFunction[];
        ports: string[];
        rulesApplied: string[];
        statusBackend: OwnerStatus | '';
    }
    export interface L1InventoryPort {
        portId: string;
        entity: string;
    }
    export interface L1InventoryTable {
        tableId: string;
        entity: string;
    }
    export interface L1Inventory {
        routes: string[];
        usecases: L1InventoryUsecase[];
        ports: L1InventoryPort[];
        tables: L1InventoryTable[];
        present: boolean;
    }
    /**
     * Snapshot of the existing l1 of `module` in `project`. Pure over `mls.stor`.
     * No l1 (and no backend block) ⇒ `present: false` and empty lists.
     * Status comes from `l5/<mod>/todoBackend.defs.ts owners[]`, never from `status: draft` in the defs.
     */
    export function readL1Inventory(project: number, moduleName: string): Promise<L1Inventory>;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Core" {
    import { type Ns5FileInfo } from "_102035_/l2/solution/fs";
    import { type PoolMessage, type PoolTraceLine } from "_102035_/l2/solution/pool";
    import type { Ns5PipelineStatus, Ns5PipelineStepState } from "_102035_/l2/solution/types";
    import { type L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    export const P1_FLOW_ID: "agentPlannerL1";
    export const P1_FLOW_VERSION: "2026-09-20-p1-flow-v1";
    export const P1_AGENT_NAME: "agentPlannerL1";
    export const P1_PIPELINE_SCHEMA_VERSION: "2026-09-20-p1-pipeline-v1";
    export const P1_NEEDS_SCHEMA: "2026-09-21-p2-needs-v1";
    export const P1_DEVICE: "web";
    export type P1Device = typeof P1_DEVICE;
    /** Steps the current flow.json actually runs. */
    export const P1_FLOW_STEP_IDS: readonly ["entry10", "plan20"];
    export const P1_STEP_IDS: readonly ["entry10", "plan20"];
    export type P1FlowStepId = typeof P1_FLOW_STEP_IDS[number];
    export type P1StepId = typeof P1_STEP_IDS[number];
    /** Last step of `docs/flow.json` — plan20 closes the pipeline. */
    export const P1_FLOW_LAST_STEP_ID: P1FlowStepId;
    export const P1_STEP_TITLES: Record<P1StepId, string>;
    export const P1_STEP_DEPENDS_ON: Record<P1StepId, readonly string[]>;
    /** Same default as `PL_DEFAULT_CANDIDATE_REL` in `plCore.ts`. */
    export const P1_DEFAULT_CANDIDATE_REL: "tobe/plan";
    export interface P1ParsedInvocation {
        module: string;
        /** Resolved `l4/` folder when `/candidate` is present; otherwise `''`. */
        candidate: string;
        /** True when the `/candidate` token was present, even if the path was refused. */
        hasCandidate: boolean;
    }
    export type P1EntrySource = {
        kind: 'hand';
        moduleName: string;
        candidate?: string;
    } | {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate?: string;
    };
    export interface P1Needs {
        schemaVersion: string;
        moduleName: string;
        device?: string;
        pages?: unknown[];
    }
    export interface P1PipelineState {
        schemaVersion: typeof P1_PIPELINE_SCHEMA_VERSION;
        flowId: typeof P1_FLOW_ID;
        moduleName: string;
        status: Ns5PipelineStatus;
        awaitingStep?: P1StepId;
        steps: Partial<Record<P1StepId, Ns5PipelineStepState>>;
        thread: string;
        round: number;
        messageFile: string;
        sourceMessages: string[];
        needsFile: string;
        inventory: L1Inventory;
        pool?: PoolTraceLine[];
        /**
         * Display paths of the duplicates consumed with `messageFile`. The pool enum has no
         * `superseded` outcome yet, so their trace line is `processed` and this list names them.
         */
        supersededMessages?: string[];
        updatedAt: string;
    }
    export interface P1LoadedEntry {
        moduleName: string;
        file: Ns5FileInfo;
        message: PoolMessage;
        sourceMessages: string[];
        needsFile: Ns5FileInfo;
        needs: P1Needs;
    }
    export type P1LoadResult = P1LoadedEntry | {
        refusal: string;
    };
    export type P1ExecuteResult = {
        pipeline: P1PipelineState;
        file: Ns5FileInfo;
        message: PoolMessage;
    } | {
        refusal: string;
    };
    export function isP1StepId(value: string): value is P1StepId;
    export function moduleTokenOk(moduleName: string): boolean;
    /** Copied from `plCore.ts:111`. `..` in the relative path returns `''`. */
    export function resolveCandidateFolder(moduleName: string, relativePath?: string): string;
    /**
     * Point `moduleFolder` at `candidate`, or restore the canonical root when it is
     * empty. `..` is a refusal, not a silent "no candidate". Always call this before
     * reading l4 / pool / pipeline so a previous task cannot leak its root.
     */
    export function applyP1CandidateRoot(moduleName: string, candidate: string): string;
    /**
     * Maps child planIds back to the owning step. Done-anchors stay unmatched so they
     * are not dispatched. A step prompt `{ moduleName, thread, file }` (pool dispatch)
     * is entry10.
     */
    export function ownerStepId(planId: string, prompt?: string): P1StepId | '';
    export function isPoolEntryPrompt(prompt?: string): boolean;
    export function parseP1Invocation(value: string): P1ParsedInvocation;
    export function p1InvocationRefusal(invocation: P1ParsedInvocation): string;
    export type P1StepPrompt = {
        kind: 'step';
        moduleName: string;
        thread: string;
        file: string;
        candidate: string;
    } | {
        kind: 'entry';
        moduleName: string;
        candidate: string;
    } | {
        kind: 'refusal';
        refusal: string;
    };
    export function parseP1StepPrompt(prompt: string): P1StepPrompt;
    /**
     * `l4/<module>/pool/l1/pipeline.json` — the planner trace lives in its own box (27/09:
     * planning only writes the pool). Not a pool message: `listPoolBox` ignores the name.
     */
    export function p1PipelineFile(moduleName: string): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/needs.json` — written by L2, read here. */
    export function p1NeedsFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l1/web/l4diff.json` — written by L4 (p4_09). Absent is valid. */
    export function p1L4DiffFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    /** `l4/<module>/pool/l2/web/backend.json` — written by plan20. Not a pool message. */
    export function p1BackendFile(moduleName: string, device?: P1Device): Ns5FileInfo;
    export function createP1Pipeline(moduleName: string, message: PoolMessage, messageFile: string, now: Date, sourceMessages: string[], needsFile: string, inventory: L1Inventory): P1PipelineState;
    export function createP1AgentStep(stepId: P1StepId, moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep;
    export function buildP1PlannedSteps(moduleName: string, entry: {
        thread: string;
        file: string;
        candidate?: string;
    }): mls.msg.AIAgentStep[];
    export function isP1PoolMessageFile(shortName: string): boolean;
    export const P1_ONLY_IMPLEMENT = "pool/l1 has no estimate message; implement belongs to agentDefsL1, not to the planner";
    export function p1DifferentRequestsRefusal(count: number): string;
    export function loadP1Entry(source: P1EntrySource): Promise<P1LoadResult>;
    export function writeP1Entry(loaded: P1LoadedEntry, now: Date): Promise<P1PipelineState>;
    /**
     * Consume the messages this run read at entry (`sourceMessages`), never a fresh listing:
     * a message that arrived during the run stays. Trace first, then delete — a failure before
     * the trace keeps the message. `messageFile` is `processed`; the others are duplicates
     * listed in `supersededMessages`. Returns the display paths deleted.
     */
    export function consumeP1Messages(moduleName: string, now: Date): Promise<string[]>;
    export function executeP1Entry(source: P1EntrySource, now: Date): Promise<P1ExecuteResult>;
    export function readP1Pipeline(moduleName: string): Promise<P1PipelineState | null>;
    /** `l4/<module>/pool/l1/<stepId>-draft.json` — scratch of this box, not a pool message. */
    export function p1DraftFile(moduleName: string, stepId: P1StepId): Ns5FileInfo;
    /** Files of this agent (prompt.md, skills) live in 102021, not in the run module. */
    export function p1AgentFile(folder: string, shortName: string, extension: string): Ns5FileInfo;
    export function readP1AgentText(folder: string, shortName: string, extension: string): Promise<string>;
    /** `complete` = every step of `flow.json` is approved. A failed pipeline stays failed. */
    export function markP1Complete(pipeline: P1PipelineState, now?: string): P1PipelineState;
    export function markP1Step(pipeline: P1PipelineState, stepId: P1StepId, next: Ns5PipelineStepState): P1PipelineState;
    export function createP1RetryStep(stepId: P1StepId, moduleName: string, kind: 'repair' | 'transport', attempt: number, extra?: Record<string, unknown>): mls.msg.AIAgentStep;
}
declare module "_102021_/l2/agentPlannerL1/helpers/p1Dispatch" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type P1PipelineState, type P1StepId } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    export type P1StepBeforePrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export type P1StepAfterPrompt = (agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string) => Promise<mls.msg.AgentIntent[]>;
    export interface P1StepHooks {
        beforePromptStep?: P1StepBeforePrompt;
        afterPromptStep?: P1StepAfterPrompt;
    }
    /** Filled by later specs. A missing entry means the step is not implemented yet. */
    export const P1_STEP_HOOKS: Partial<Record<P1StepId, P1StepHooks>>;
    export function planIdOf(step: mls.msg.AIAgentStep): string;
    export function hooksFor(planId: string, prompt?: string): P1StepHooks | undefined;
    export function markAwaitingStep(pipeline: P1PipelineState, stepId: P1StepId): Promise<P1PipelineState>;
    export function p1StatusMessage(agent: IAgentMeta, context: mls.msg.ExecutionContext, message: string): mls.msg.AgentIntentAddMessageAI;
    export function updateStatus(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg: string): mls.msg.AgentIntentUpdateStatus;
    export function drainWaitingSiblings(context: mls.msg.ExecutionContext, current: mls.msg.AIAgentStep, hookSequential: number, traceMsg: string, opts?: {
        onlyUnimplemented?: boolean;
    }): mls.msg.AgentIntentUpdateStatus[];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    export function beforeP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1EntryPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/contracts" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { P1_NEEDS_SCHEMA, type P1Device } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import type { PoolMessage } from "_102035_/l2/solution/pool";
    export const P1_BACKEND_SCHEMA_VERSION: "2026-09-21-p1-backend-v1.2";
    export const P1_BACKEND_ARTIFACT: "pool/l2/web/backend.json";
    export const P1_L4DIFF_SCHEMA: "2026-09-21-p4-l4diff-v1";
    export const P1_KINDS: readonly ["qry", "cmd"];
    export type P1Kind = typeof P1_KINDS[number];
    export const P1_OPERATIONS: readonly ["list", "get", "create", "update", "transition", "delete", "custom"];
    export type P1Operation = typeof P1_OPERATIONS[number];
    export const P1_PLAN_STATUSES: readonly ["toCreate", "toUpdate", "toRemove", "done"];
    export type P1PlanStatus = typeof P1_PLAN_STATUSES[number];
    export const P1_NEEDS_FAMILIES: readonly ["mdm", "ddm", "tdm"];
    export type P1NeedsFamily = typeof P1_NEEDS_FAMILIES[number];
    export const P1_WRITE_OPERATIONS: readonly ["create", "update", "transition", "delete"];
    export type P1WriteOperation = typeof P1_WRITE_OPERATIONS[number];
    export const P1_REMOVED_KINDS: readonly ["usecase", "port", "table"];
    export type P1RemovedKind = typeof P1_REMOVED_KINDS[number];
    export const P1_NO_TABLE: readonly ["ok", "mdm", "none"];
    export type P1NoTable = typeof P1_NO_TABLE[number];
    export const P1_CHANGE_KINDS: readonly ["field", "rule", "grant", "transition", "process", "integration", "entity"];
    export type P1ChangeKind = typeof P1_CHANGE_KINDS[number];
    export const P1_CHANGE_OPS: readonly ["added", "changed", "removed"];
    export type P1ChangeOp = typeof P1_CHANGE_OPS[number];
    export const P1_TEST_SUPPORT_OWNERS: readonly ["L1", "runtime"];
    export type P1TestSupportOwner = typeof P1_TEST_SUPPORT_OWNERS[number];
    export interface P1NeedsRead {
        entity: string;
        family: P1NeedsFamily;
        scope: string;
        derived: string[];
        from: string[];
    }
    export interface P1NeedsWrite {
        entity: string;
        operation: P1WriteOperation;
        transitionRef: string;
        from: string[];
    }
    export interface P1NeedsPage {
        pageId: string;
        actors: string[];
        reads: P1NeedsRead[];
        writes: P1NeedsWrite[];
    }
    export interface P1NeedsFile {
        schemaVersion: typeof P1_NEEDS_SCHEMA;
        moduleName: string;
        device: P1Device;
        pages: P1NeedsPage[];
    }
    export interface P1EntityView {
        entityId: string;
        family: P1NeedsFamily;
        storageKind: string;
        storageTarget: string;
        transitions: string[];
        rules: string[];
        /** Entities this one points to by its own fk column (`relationships[].via` = `<self>.<field>`). */
        fkTargets?: string[];
        /** `transitions[].from` by transitionId. */
        transitionFrom?: Record<string, string[]>;
    }
    /** access.defs.ts actor; `personEntity` is `''` when the actor declares none. */
    export interface P1ActorView {
        actorId: string;
        personEntity: string;
    }
    /**
     * One unit of test preparation (data, identity, cleanup). Not a grant nor a rule.
     * `executorRef` / `cleanupRef` stay `''` until an owner references a verified capability;
     * then `gap` names what is missing.
     */
    export interface P1TestSupportItem {
        id: string;
        actorRefs: string[];
        entityRefs: string[];
        sourceRefs: string[];
        status: P1PlanStatus;
        owner: P1TestSupportOwner;
        executorRef: string;
        cleanupRef: string;
        gap: string;
    }
    export interface P1Endpoint {
        route: string;
        page: string;
        kind: P1Kind;
        usecaseRef: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Usecase {
        usecaseId: string;
        entity: string;
        operation: P1Operation;
        ports: string[];
        status: P1PlanStatus;
        existing: string;
        reason: string;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Port {
        portId: string;
        entity: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Table {
        tableId: string;
        entity: string;
        status: P1PlanStatus;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Removed {
        kind: P1RemovedKind;
        id: string;
        status: 'toRemove';
        reason: string;
        tableRefs: string[];
        noTable: P1NoTable;
    }
    export interface P1Change {
        changeId: string;
        kind: P1ChangeKind;
        op: P1ChangeOp;
        entity: string;
        tableRefs: string[];
        noTable: P1NoTable;
        usecaseRefs: string[];
        reason: string;
        source: string;
    }
    export interface P1UnmappedChange {
        changeId: string;
        kind: string;
        source: string;
    }
    export interface P1L4DiffItem {
        changeId: string;
        kind: P1ChangeKind;
        op: P1ChangeOp;
        entity: string;
        source: string;
        before: Record<string, unknown>;
        after: Record<string, unknown>;
    }
    export interface P1L4DiffFile {
        schemaVersion: typeof P1_L4DIFF_SCHEMA;
        moduleName: string;
        base: string;
        candidate: string;
        items: P1L4DiffItem[];
        unmapped: P1UnmappedChange[];
    }
    export interface P1BackendFile {
        schemaVersion: typeof P1_BACKEND_SCHEMA_VERSION;
        moduleName: string;
        device: P1Device;
        sourceNeeds: string;
        inventoryPresent: boolean;
        endpoints: P1Endpoint[];
        usecases: P1Usecase[];
        ports: P1Port[];
        tables: P1Table[];
        removed: P1Removed[];
        changes: P1Change[];
        testSupport: P1TestSupportItem[];
        meta: {
            pages: Record<string, string[]>;
            generatedAt: string;
            llmCalled: boolean;
            unmappedChanges: P1UnmappedChange[];
        };
    }
    export interface P1UnresolvedItem {
        kind: 'alias' | 'merge';
        candidateUsecaseId: string;
        entity: string;
        operation: string;
        reason: string;
    }
    export interface P1BackendAlias {
        candidateUsecaseId: string;
        existingUsecaseId: string;
        reason: string;
    }
    export interface P1BackendMerge {
        usecaseId: string;
        entity: string;
        operation: 'custom';
        ports: string[];
        replaces: string[];
        reason: string;
    }
    export interface P1BackendResolution {
        aliases: P1BackendAlias[];
        merges: P1BackendMerge[];
    }
    export interface P1PlanBackendInput {
        needs: P1NeedsFile;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        now: Date;
        resolution?: P1BackendResolution | null;
        l4diff?: P1L4DiffFile | null;
        /** access.defs.ts actors; absent ⇒ every needs actor becomes a named gap. */
        actors?: readonly P1ActorView[];
    }
    export interface P1PlanBackendResult {
        file: P1BackendFile;
        unresolved: P1UnresolvedItem[];
    }
    export function isP1Kind(value: string): value is P1Kind;
    export function isP1Operation(value: string): value is P1Operation;
    export function isP1PlanStatus(value: string): value is P1PlanStatus;
    export function isP1NeedsFamily(value: string): value is P1NeedsFamily;
    export function isP1WriteOperation(value: string): value is P1WriteOperation;
    export function isP1NoTable(value: string): value is P1NoTable;
    export function isP1ChangeKind(value: string): value is P1ChangeKind;
    export function isP1ChangeOp(value: string): value is P1ChangeOp;
    export function p1BackendSubject(moduleName: string, device?: P1Device): string;
    export function p1BackendBody(file: P1BackendFile): string;
    export function buildP1BackendMessage(input: {
        file: P1BackendFile;
        received: Pick<PoolMessage, 'thread' | 'round' | 'mode'>;
    }): PoolMessage;
    export function p1UsecaseId(operation: P1Operation, entity: string, transitionRef?: string): string;
    export function p1Route(moduleName: string, page: string, kind: P1Kind, usecaseId: string): string;
    export function p1PortId(entity: string): string;
    export function p1TableId(entity: string): string;
    export function parseP1Needs(value: unknown): P1NeedsFile;
    export function parseP1Entity(value: unknown, indexRow?: unknown): P1EntityView | null;
    export function parseP1Actors(value: unknown): P1ActorView[];
    export function parseP1OntologyIndex(value: unknown): string[];
    export function parseP1L4Diff(value: unknown): P1L4DiffFile | null;
    export function parseP1Resolution(value: unknown): P1BackendResolution;
    export function planP1Backend(input: P1PlanBackendInput): P1PlanBackendResult;
    export function normalizeP1Backend(value: unknown, fallback: P1PlanBackendInput): P1BackendFile;
    export function buildP1BackendTool(schema: Record<string, unknown>): mls.msg.LLMTool;
    export function buildP1ResolutionSchema(): Record<string, unknown>;
    export function unwrapP1ArtifactPayload(value: unknown): unknown;
    export function stampP1Backend(file: P1BackendFile, ctx: {
        ontology: Map<string, P1EntityView>;
        inventory: L1Inventory;
        needs: P1NeedsFile;
        l4diff: P1L4DiffFile | null;
        actors: readonly P1ActorView[];
    }): P1BackendFile;
    /**
     * Test preparation derived from needs (journey refs, page actors), access actors
     * (personEntity) and the ontology (own fk targets, lifecycle `from` of needed transitions).
     * No runtime capability is referenced here, so every item is `toCreate` with a named gap.
     */
    export function planP1TestSupport(input: {
        needs: P1NeedsFile;
        ontology: Map<string, P1EntityView>;
        actors: readonly P1ActorView[];
        tables: readonly P1Table[];
    }): P1TestSupportItem[];
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/gate" {
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1ActorView, type P1BackendFile, type P1EntityView, type P1L4DiffFile, type P1NeedsFile } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    export interface P1BackendGateIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface P1BackendGateResult {
        ok: boolean;
        issues: P1BackendGateIssue[];
    }
    export function validateP1Backend(file: P1BackendFile, needs: P1NeedsFile, ontology: readonly P1EntityView[]): P1BackendGateResult;
    export function repairP1Backend(file: P1BackendFile, needs: P1NeedsFile, ontology: readonly P1EntityView[], inventory?: L1Inventory, l4diff?: P1L4DiffFile | null, actors?: readonly P1ActorView[]): P1BackendFile;
    export function formatP1BackendGate(issues: readonly P1BackendGateIssue[]): string;
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan" {
    import type { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { type PoolMessage } from "_102035_/l2/solution/pool";
    import { type P1PipelineState } from "_102021_/l2/agentPlannerL1/helpers/p1Core";
    import type { L1Inventory } from "_102021_/l2/agentPlannerL1/helpers/l1Inventory";
    import { type P1ActorView, type P1BackendFile, type P1BackendResolution, type P1EntityView, type P1L4DiffFile, type P1NeedsFile, type P1PlanBackendResult } from "_102021_/l2/agentPlannerL1/steps/plan20/contracts";
    export interface P1PlanSources {
        needs: P1NeedsFile;
        inventory: L1Inventory;
        ontology: P1EntityView[];
        pipeline: P1PipelineState;
        l4diff: P1L4DiffFile | null;
        actors: P1ActorView[];
    }
    export interface P1DeliverPlanResult {
        backend: P1BackendFile;
        backendPath: string;
        message: PoolMessage;
        messagePath: string;
        llmCalled: boolean;
    }
    export function composeP1SystemPrompt(skillText: string, stepPrompt: string): string;
    export function buildP1PlanHumanPrompt(input: {
        sources: P1PlanSources;
        planned: P1PlanBackendResult;
        gateFeedback?: string;
        previousDraft?: unknown;
    }): string;
    export function loadP1Ontology(moduleName: string): Promise<P1EntityView[]>;
    export function loadP1PlanSources(moduleName: string): Promise<P1PlanSources>;
    export function executeP1Plan(moduleName: string, now: Date, resolution?: P1BackendResolution | null): Promise<P1DeliverPlanResult>;
    export function beforeP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
    export function afterP1PlanPromptStep(_agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
}
declare module "_102021_/l2/agentPlannerL1/agentPlannerL1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    import "_102021_/l2/agentPlannerL1/steps/entry10/agentP1Entry";
    import "_102021_/l2/agentPlannerL1/steps/plan20/agentP1Plan";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/atendenteCatalogue.defs" {
    export const atendenteCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "atendenteCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "atendenteCatalogue";
            readonly controllerName: "AtendenteCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "atendenteCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "atendenteCatalogueQryListAtendenteHandler";
                readonly command: "qryListAtendente";
                readonly bffId: "qryListAtendente";
                readonly route: "controleChamados.atendenteCatalogue.qryListAtendente";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdCreateAtendenteHandler";
                readonly command: "cmdCreateAtendente";
                readonly bffId: "cmdCreateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdCreateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "createAtendente";
                readonly usecaseRefs: readonly ["createAtendente"];
                readonly inputTypeName: "CreateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "platformUserId";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "createAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "createAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdUpdateAtendenteHandler";
                readonly command: "cmdUpdateAtendente";
                readonly bffId: "cmdUpdateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdUpdateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "updateAtendente";
                readonly usecaseRefs: readonly ["updateAtendente"];
                readonly inputTypeName: "UpdateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }, {
                    readonly inputId: "platformUserId";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "updateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "updateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdInactivateAtendenteHandler";
                readonly command: "cmdInactivateAtendente";
                readonly bffId: "cmdInactivateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdInactivateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "inactivateAtendente";
                readonly usecaseRefs: readonly ["inactivateAtendente"];
                readonly inputTypeName: "InactivateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "inactivateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "inactivateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueCmdReactivateAtendenteHandler";
                readonly command: "cmdReactivateAtendente";
                readonly bffId: "cmdReactivateAtendente";
                readonly route: "controleChamados.atendenteCatalogue.cmdReactivateAtendente";
                readonly kind: "command";
                readonly usecaseRef: "reactivateAtendente";
                readonly usecaseRefs: readonly ["reactivateAtendente"];
                readonly inputTypeName: "ReactivateAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "reactivateAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "reactivateAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "atendenteCatalogueQryGetAtendenteHandler";
                readonly command: "qryGetAtendente";
                readonly bffId: "qryGetAtendente";
                readonly route: "controleChamados.atendenteCatalogue.qryGetAtendente";
                readonly kind: "query";
                readonly usecaseRef: "getAtendente";
                readonly usecaseRefs: readonly ["getAtendente"];
                readonly inputTypeName: "GetAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "getAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "getAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.atendenteCatalogue.qryListAtendente";
                readonly handlerName: "atendenteCatalogueQryListAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdCreateAtendente";
                readonly handlerName: "atendenteCatalogueCmdCreateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdUpdateAtendente";
                readonly handlerName: "atendenteCatalogueCmdUpdateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdInactivateAtendente";
                readonly handlerName: "atendenteCatalogueCmdInactivateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.cmdReactivateAtendente";
                readonly handlerName: "atendenteCatalogueCmdReactivateAtendenteHandler";
            }, {
                readonly key: "controleChamados.atendenteCatalogue.qryGetAtendente";
                readonly handlerName: "atendenteCatalogueQryGetAtendenteHandler";
            }];
        };
    };
    export default atendenteCatalogueController;
    export const pipeline: readonly [{
        readonly id: "atendenteCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/atendenteCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/atendenteCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--qryListAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdCreateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdUpdateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdInactivateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--cmdReactivateAtendente.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.d.ts", "_102039_/l4/controleChamados/contracts/atendenteCatalogue--qryGetAtendente.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/chamadoCatalogue.defs" {
    export const chamadoCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "chamadoCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "chamadoCatalogue";
            readonly controllerName: "ChamadoCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "chamadoCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "chamadoCatalogueQryListChamadoHandler";
                readonly command: "qryListChamado";
                readonly bffId: "qryListChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryListChamado";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdCreateChamadoHandler";
                readonly command: "cmdCreateChamado";
                readonly bffId: "cmdCreateChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdCreateChamado";
                readonly kind: "command";
                readonly usecaseRef: "createChamado";
                readonly usecaseRefs: readonly ["createChamado"];
                readonly inputTypeName: "CreateChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "titulo";
                    readonly fieldRef: "Chamado.titulo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "descricao";
                    readonly fieldRef: "Chamado.descricao";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do acompanhamento do chamado.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "createChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdUpdateChamadoHandler";
                readonly command: "cmdUpdateChamado";
                readonly bffId: "cmdUpdateChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdUpdateChamado";
                readonly kind: "command";
                readonly usecaseRef: "updateChamado";
                readonly usecaseRefs: readonly ["updateChamado"];
                readonly inputTypeName: "UpdateChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }, {
                    readonly inputId: "titulo";
                    readonly fieldRef: "Chamado.titulo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "descricao";
                    readonly fieldRef: "Chamado.descricao";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do acompanhamento do chamado.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "updateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdDeleteChamadoHandler";
                readonly command: "cmdDeleteChamado";
                readonly bffId: "cmdDeleteChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdDeleteChamado";
                readonly kind: "command";
                readonly usecaseRef: "deleteChamado";
                readonly usecaseRefs: readonly ["deleteChamado"];
                readonly inputTypeName: "DeleteChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "deleteChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueQryGetChamadoHandler";
                readonly command: "qryGetChamado";
                readonly bffId: "qryGetChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryGetChamado";
                readonly kind: "query";
                readonly usecaseRef: "getChamado";
                readonly usecaseRefs: readonly ["getChamado"];
                readonly inputTypeName: "GetChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "getChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueQryLocateChamadoHandler";
                readonly command: "qryLocateChamado";
                readonly bffId: "qryLocateChamado";
                readonly route: "controleChamados.chamadoCatalogue.qryLocateChamado";
                readonly kind: "query";
                readonly usecaseRef: "locateChamado";
                readonly usecaseRefs: readonly ["locateChamado"];
                readonly inputTypeName: "LocateChamadoInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoCatalogueCmdCloseChamadoHandler";
                readonly command: "cmdCloseChamado";
                readonly bffId: "cmdCloseChamado";
                readonly route: "controleChamados.chamadoCatalogue.cmdCloseChamado";
                readonly kind: "command";
                readonly usecaseRef: "closeChamado";
                readonly usecaseRefs: readonly ["closeChamado"];
                readonly inputTypeName: "CloseChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Chamado.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Decisão tomada.";
                    readonly enumValues: readonly ["closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "closeChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.chamadoCatalogue.qryListChamado";
                readonly handlerName: "chamadoCatalogueQryListChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdCreateChamado";
                readonly handlerName: "chamadoCatalogueCmdCreateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdUpdateChamado";
                readonly handlerName: "chamadoCatalogueCmdUpdateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdDeleteChamado";
                readonly handlerName: "chamadoCatalogueCmdDeleteChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.qryGetChamado";
                readonly handlerName: "chamadoCatalogueQryGetChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.qryLocateChamado";
                readonly handlerName: "chamadoCatalogueQryLocateChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoCatalogue.cmdCloseChamado";
                readonly handlerName: "chamadoCatalogueCmdCloseChamadoHandler";
            }];
        };
    };
    export default chamadoCatalogueController;
    export const pipeline: readonly [{
        readonly id: "chamadoCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryListChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdCreateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdUpdateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdDeleteChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryGetChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--qryLocateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoCatalogue--cmdCloseChamado.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/chamadoHub.defs" {
    export const chamadoHubController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "chamadoHub";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "chamadoHub";
            readonly controllerName: "ChamadoHubController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "chamadoHub";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "chamadoHubQryListChamadoHandler";
                readonly command: "qryListChamado";
                readonly bffId: "qryListChamado";
                readonly route: "controleChamados.chamadoHub.qryListChamado";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "chamadoHubQryListComentarioHandler";
                readonly command: "qryListComentario";
                readonly bffId: "qryListComentario";
                readonly route: "controleChamados.chamadoHub.qryListComentario";
                readonly kind: "query";
                readonly usecaseRef: "listComentario";
                readonly usecaseRefs: readonly ["listComentario"];
                readonly inputTypeName: "ListComentarioInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.chamadoHub.qryListChamado";
                readonly handlerName: "chamadoHubQryListChamadoHandler";
            }, {
                readonly key: "controleChamados.chamadoHub.qryListComentario";
                readonly handlerName: "chamadoHubQryListComentarioHandler";
            }];
        };
    };
    export default chamadoHubController;
    export const pipeline: readonly [{
        readonly id: "chamadoHub__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoHub.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/chamadoHub.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/chamadoHub--qryListChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.d.ts", "_102039_/l4/controleChamados/contracts/chamadoHub--qryListComentario.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/comentarioCatalogue.defs" {
    export const comentarioCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "comentarioCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "comentarioCatalogue";
            readonly controllerName: "ComentarioCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "comentarioCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "comentarioCatalogueQryListComentarioHandler";
                readonly command: "qryListComentario";
                readonly bffId: "qryListComentario";
                readonly route: "controleChamados.comentarioCatalogue.qryListComentario";
                readonly kind: "query";
                readonly usecaseRef: "listComentario";
                readonly usecaseRefs: readonly ["listComentario"];
                readonly inputTypeName: "ListComentarioInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "listComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdCreateComentarioHandler";
                readonly command: "cmdCreateComentario";
                readonly bffId: "cmdCreateComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdCreateComentario";
                readonly kind: "command";
                readonly usecaseRef: "createComentario";
                readonly usecaseRefs: readonly ["createComentario"];
                readonly inputTypeName: "CreateComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                }, {
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "createComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdUpdateComentarioHandler";
                readonly command: "cmdUpdateComentario";
                readonly bffId: "cmdUpdateComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdUpdateComentario";
                readonly kind: "command";
                readonly usecaseRef: "updateComentario";
                readonly usecaseRefs: readonly ["updateComentario"];
                readonly inputTypeName: "UpdateComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }, {
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                }, {
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "updateComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueCmdDeleteComentarioHandler";
                readonly command: "cmdDeleteComentario";
                readonly bffId: "cmdDeleteComentario";
                readonly route: "controleChamados.comentarioCatalogue.cmdDeleteComentario";
                readonly kind: "command";
                readonly usecaseRef: "deleteComentario";
                readonly usecaseRefs: readonly ["deleteComentario"];
                readonly inputTypeName: "DeleteComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "deleteComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryGetComentarioHandler";
                readonly command: "qryGetComentario";
                readonly bffId: "qryGetComentario";
                readonly route: "controleChamados.comentarioCatalogue.qryGetComentario";
                readonly kind: "query";
                readonly usecaseRef: "getComentario";
                readonly usecaseRefs: readonly ["getComentario"];
                readonly inputTypeName: "GetComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "comentarioId";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "getComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryChamadoPickerHandler";
                readonly command: "qryChamadoPicker";
                readonly bffId: "qryChamadoPicker";
                readonly route: "controleChamados.comentarioCatalogue.qryChamadoPicker";
                readonly kind: "query";
                readonly usecaseRef: "listChamado";
                readonly usecaseRefs: readonly ["listChamado"];
                readonly inputTypeName: "ListChamadoInput";
                readonly inputContract: readonly [{
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Chamado.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "comentarioCatalogueQryAtendentePickerHandler";
                readonly command: "qryAtendentePicker";
                readonly bffId: "qryAtendentePicker";
                readonly route: "controleChamados.comentarioCatalogue.qryAtendentePicker";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.comentarioCatalogue.qryListComentario";
                readonly handlerName: "comentarioCatalogueQryListComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdCreateComentario";
                readonly handlerName: "comentarioCatalogueCmdCreateComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdUpdateComentario";
                readonly handlerName: "comentarioCatalogueCmdUpdateComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.cmdDeleteComentario";
                readonly handlerName: "comentarioCatalogueCmdDeleteComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryGetComentario";
                readonly handlerName: "comentarioCatalogueQryGetComentarioHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryChamadoPicker";
                readonly handlerName: "comentarioCatalogueQryChamadoPickerHandler";
            }, {
                readonly key: "controleChamados.comentarioCatalogue.qryAtendentePicker";
                readonly handlerName: "comentarioCatalogueQryAtendentePickerHandler";
            }];
        };
    };
    export default comentarioCatalogueController;
    export const pipeline: readonly [{
        readonly id: "comentarioCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/comentarioCatalogue.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/comentarioCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryListComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdCreateComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdUpdateComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--cmdDeleteComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryGetComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryChamadoPicker.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/comentarioCatalogue--qryAtendentePicker.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/http/controllers/registrarComentarioChamado.defs" {
    export const registrarComentarioChamadoController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "registrarComentarioChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "registrarComentarioChamado";
            readonly controllerName: "RegistrarComentarioChamadoController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "registrarComentarioChamado";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "registrarComentarioChamadoQryLocateChamadoHandler";
                readonly command: "qryLocateChamado";
                readonly bffId: "qryLocateChamado";
                readonly route: "controleChamados.registrarComentarioChamado.qryLocateChamado";
                readonly kind: "query";
                readonly usecaseRef: "locateChamado";
                readonly usecaseRefs: readonly ["locateChamado"];
                readonly inputTypeName: "LocateChamadoInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "chamadoId";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "titulo";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["titulo"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "descricao";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["descricao"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateChamado";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "registrarComentarioChamadoCmdRegisterComentarioHandler";
                readonly command: "cmdRegisterComentario";
                readonly bffId: "cmdRegisterComentario";
                readonly route: "controleChamados.registrarComentarioChamado.cmdRegisterComentario";
                readonly kind: "command";
                readonly usecaseRef: "registerComentario";
                readonly usecaseRefs: readonly ["registerComentario"];
                readonly inputTypeName: "RegisterComentarioInput";
                readonly inputContract: readonly [{
                    readonly inputId: "atendenteId";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Atendente";
                }, {
                    readonly inputId: "chamadoId";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "conteudo";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "comentarioId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["comentarioId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "chamadoId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["chamadoId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "atendenteId";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "conteudo";
                        readonly operationId: "registerComentario";
                        readonly path: readonly ["conteudo"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "registrarComentarioChamadoQryAtendentePickerHandler";
                readonly command: "qryAtendentePicker";
                readonly bffId: "qryAtendentePicker";
                readonly route: "controleChamados.registrarComentarioChamado.qryAtendentePicker";
                readonly kind: "query";
                readonly usecaseRef: "listAtendente";
                readonly usecaseRefs: readonly ["listAtendente"];
                readonly inputTypeName: "ListAtendenteInput";
                readonly inputContract: readonly [{
                    readonly inputId: "includeInactive";
                    readonly fieldRef: "";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Include records inactivated in the MDM index (default: only active ones).";
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "atendenteId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["atendenteId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "platformUserId";
                        readonly operationId: "listAtendente";
                        readonly path: readonly ["platformUserId"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.registrarComentarioChamado.qryLocateChamado";
                readonly handlerName: "registrarComentarioChamadoQryLocateChamadoHandler";
            }, {
                readonly key: "controleChamados.registrarComentarioChamado.cmdRegisterComentario";
                readonly handlerName: "registrarComentarioChamadoCmdRegisterComentarioHandler";
            }, {
                readonly key: "controleChamados.registrarComentarioChamado.qryAtendentePicker";
                readonly handlerName: "registrarComentarioChamadoQryAtendentePickerHandler";
            }];
        };
    };
    export default registrarComentarioChamadoController;
    export const pipeline: readonly [{
        readonly id: "registrarComentarioChamado__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/registrarComentarioChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/http/controllers/registrarComentarioChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--qryLocateChamado.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--cmdRegisterComentario.defs.ts", "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.d.ts", "_102039_/l4/controleChamados/contracts/registrarComentarioChamado--qryAtendentePicker.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/chamado.defs" {
    export const chamadoTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Chamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Chamado";
            readonly tableName: "controlechamados_chamado";
            readonly columns: readonly [{
                readonly name: "chamado_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key / foreign key identifier";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "Chamado status";
            }];
            readonly primaryKey: readonly ["chamado_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_chamado_status_idx";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default chamadoTableDefinition;
    export const pipeline: readonly [{
        readonly id: "chamado__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/table.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.defs" {
    export const chamadoRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ChamadoRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly className: "ChamadoRepositoryAdapter";
            readonly portRef: "IChamadoRepository";
            readonly tableRef: "chamados";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('chamados').", "Map columns chamadoId -> chamado_id and status -> status; map details.titulo and details.descricao with verbatim camelCase JSONB keys.", "getById/list hydrate domain aggregates from chamado_id, status, and details; save writes only real columns plus details JSONB, preserving fieldId keys.", "list must apply filter.sortBy/sortOrder; status must be sorted in memory by the declared domain enum order, not SQL text.", "The requested search behavior cannot be implemented against a real title/name column because Chamado declares no title/name column and titulo is a details field; do not invent a table column or snake_case a details key.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default chamadoRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "chamadoRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamadoRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/chamado.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/comentario.defs" {
    export const comentarioTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Comentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Comentario";
            readonly tableName: "controlechamados_comentario";
            readonly columns: readonly [{
                readonly name: "comentario_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key / foreign key identifier";
            }, {
                readonly name: "chamado_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Chamado foreign key";
            }, {
                readonly name: "atendente_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Atendente foreign key";
            }];
            readonly primaryKey: readonly ["comentario_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_comentario_chamado_id_idx";
                readonly columns: readonly ["chamado_id"];
                readonly unique: false;
            }, {
                readonly indexName: "controlechamados_comentario_atendente_id_idx";
                readonly columns: readonly ["atendente_id"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default comentarioTableDefinition;
    export const pipeline: readonly [{
        readonly id: "comentario__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/table.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.defs" {
    export const comentarioRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ComentarioRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly className: "ComentarioRepositoryAdapter";
            readonly portRef: "IComentarioRepository";
            readonly tableRef: "comentarios";
            readonly mdmReads: readonly ["Resolve atendenteId through ctx.mdm.collection.listByType/getMany/hydrateMany/relatedOfMany as appropriate for the canonical Atendente type; never call ctx.mdm.entity.get inside a loop. Persist only atendente_id locally and do not create a local MDM table."];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('comentarios').", "Map columns comentarioId -> comentario_id, chamadoId -> chamado_id, and atendenteId -> atendente_id; map details.conteudo with the verbatim camelCase JSONB key.", "Bulk-resolve distinct atendenteId values before mapping rows; use the collection APIs and attach the resolved Atendente representation expected by the domain without inventing entityId/entityType or relationship columns.", "save writes only comentario_id, chamado_id, atendente_id, and details; details must contain conteudo and no snake_case JSONB keys.", "Apply filter.sortBy/sortOrder with orderBy for non-enum fields; enum fields, if declared by the domain, must be sorted in memory by declared enum order. Search must use a real title/name column only if one is declared; otherwise do not invent one.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default comentarioRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "comentarioRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentarioRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_1_external/adapters/persistence/seeds.defs" {
    export const seedsDefs: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "seeds";
        readonly artifactId: "seeds";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbSeeds";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly version: 1;
            readonly language: "en";
            readonly plan: {
                readonly summary: "Three coherent comments linked to the three previously seeded open support tickets and assigned attendants.";
                readonly localTables: readonly [{
                    readonly tableId: "Chamado";
                    readonly rows: readonly [{
                        readonly key: "chamado-1";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Unable to access customer portal";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The customer receives an authentication error after entering valid credentials and cannot reach the portal dashboard.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "chamado-2";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Invoice download fails";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The invoice page loads, but selecting the PDF download action returns an empty response.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "chamado-3";
                        readonly columns: readonly [{
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "titulo";
                            readonly value: "Request to update contact email";
                        }, {
                            readonly name: "descricao";
                            readonly value: "The customer asked support to replace the primary contact email address on the account.";
                        }];
                        readonly children: readonly [];
                    }];
                }, {
                    readonly tableId: "Comentario";
                    readonly rows: readonly [{
                        readonly key: "comentario-1";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-1";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-1";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "We are investigating the reported access issue and will provide an update shortly.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comentario-2";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-2";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-2";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "The support team requested additional diagnostic information from the requester.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comentario-3";
                        readonly columns: readonly [{
                            readonly name: "chamado_id";
                            readonly value: {
                                readonly ref: "local:Chamado.chamado-3";
                            };
                        }, {
                            readonly name: "atendente_id";
                            readonly value: {
                                readonly ref: "mdm:Atendente.atendente-3";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "conteudo";
                            readonly value: "The ticket remains in progress while the proposed configuration change is being validated.";
                        }];
                        readonly children: readonly [];
                    }];
                }];
                readonly mdmEntities: readonly [{
                    readonly entityId: "Atendente";
                    readonly rows: readonly [{
                        readonly key: "atendente-1";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 1";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-1";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u1";
                            };
                        }];
                        readonly relationships: readonly [];
                    }, {
                        readonly key: "atendente-2";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 2";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-2";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u2";
                            };
                        }];
                        readonly relationships: readonly [];
                    }, {
                        readonly key: "atendente-3";
                        readonly fields: readonly [{
                            readonly name: "name";
                            readonly value: "Atendente 3";
                        }, {
                            readonly name: "atendenteId";
                            readonly value: "atendente-3";
                        }, {
                            readonly name: "platformUserId";
                            readonly value: {
                                readonly ref: "actor:atendente.u3";
                            };
                        }];
                        readonly relationships: readonly [];
                    }];
                }];
            };
        };
    };
    export default seedsDefs;
    export const pipeline: readonly [{
        readonly id: "seeds__persistenceSeeds";
        readonly type: "persistenceSeeds";
        readonly outputPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/persistenceSeeds.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/ports/chamadoRepository.defs" {
    export const chamadoRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ChamadoRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly interfaceName: "IChamadoRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ChamadoId"];
                readonly returns: "Chamado | null";
                readonly description: "Retrieves a Chamado aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ChamadoListFilter"];
                readonly returns: "Chamado[]";
                readonly description: "Lists Chamado aggregates matching equality filters and optional search/sort controls.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Chamado"];
                readonly returns: "void";
                readonly description: "Persists a Chamado aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: ChamadoId"];
                readonly returns: "void";
                readonly description: "Deletes a Chamado aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default chamadoRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "chamadoRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/ports/comentarioRepository.defs" {
    export const comentarioRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ComentarioRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly interfaceName: "IComentarioRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ComentarioId"];
                readonly returns: "Comentario | null";
                readonly description: "Retrieves a Comentario aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ComentarioListFilter"];
                readonly returns: "Comentario[]";
                readonly description: "Lists Comentario aggregates matching equality filters and optional search/sort controls.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Comentario"];
                readonly returns: "void";
                readonly description: "Persists a Comentario aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: ComentarioId"];
                readonly returns: "void";
                readonly description: "Deletes a Comentario aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default comentarioRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "comentarioRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/closeChamado.defs" {
    export const closeChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "closeChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "closeChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
            readonly functions: readonly [{
                readonly functionName: "closeChamado";
                readonly inputTypeName: "CloseChamadoInput";
                readonly outputTypeName: "CloseChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado identifier from the route parameter.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Decision taken; the contract restricts this value to the enum value closed (enumValues: [\"closed\"]).";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
                readonly transactional: true;
                readonly steps: readonly ["Load Chamado by chamadoId through the Chamado port inside the transaction.", "Validate the requested status is closed, as required by the L4 enum constraint [\"closed\"].", "Apply the domain canTransition helper using the declared chamadoLifecycle matrix; do not add a stricter local transition allow-list.", "Apply rule fechamentoExigeChamadoAberto: reject with an English AppError whose details include ruleId fechamentoExigeChamadoAberto when the loaded Chamado status is not open.", "Set the Chamado status to closed and save the aggregate through the Chamado port.", "Return chamadoId, titulo, descricao, and the resulting status from the saved Chamado."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default closeChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "closeChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/closeChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createAtendente.defs" {
    export const createAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createAtendente";
                readonly inputTypeName: "CreateAtendenteInput";
                readonly outputTypeName: "CreateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Validate the required platformUserId input.", "Create the Atendente master-data entity through ctx.mdm.entity.create using mdmType controleChamados.Atendente and the platformUserId field.", "Return the created atendenteId and platformUserId."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default createAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "createAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createChamado.defs" {
    export const createChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createChamado";
                readonly inputTypeName: "CreateChamadoInput";
                readonly outputTypeName: "CreateChamadoOutput";
                readonly input: readonly [{
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.titulo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.descricao";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Validate required titulo and descricao fields.", "Resolve the initial status from the system default as open.", "Generate chamadoId using ctx.idGenerator.", "Create the Chamado aggregate through the Chamado port.", "Return chamadoId, titulo, descricao, and status."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "createChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/createComentario.defs" {
    export const createComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "createComentario";
                readonly inputTypeName: "CreateComentarioInput";
                readonly outputTypeName: "CreateComentarioOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Selected open ticket to which the comment belongs.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Authenticated attendant responsible for recording the comment.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Follow-up text written by the attendant for the ticket.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve the selected Chamado through the Chamado port.", "Validate that the Chamado exists; this is required by the referenced rule and the relationship field constraint.", "Validate that Chamado.status is open; otherwise reject with rule id comentariosPermitidosSomenteEmChamadosAbertos and an English user-facing message.", "Create a Comentario with a generated comentarioId and the supplied chamadoId, atendenteId, and conteudo through the Comentario port.", "Return comentarioId, chamadoId, atendenteId, and conteudo from the created comment."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default createComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "createComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/createComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/deleteChamado.defs" {
    export const deleteChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteChamado";
                readonly inputTypeName: "DeleteChamadoInput";
                readonly outputTypeName: "DeleteChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Chamado aggregate by chamadoId through the Chamado port.", "Capture the canonical output fields from the loaded aggregate.", "Delete the Chamado aggregate through the Chamado port within the transaction.", "Return chamadoId, titulo, descricao, and status from the deleted aggregate."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/deleteComentario.defs" {
    export const deleteComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteComentario";
                readonly inputTypeName: "DeleteComentarioInput";
                readonly outputTypeName: "DeleteComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Execute within the transaction wrapper provided by ctx.data.", "Resolve the Comentario repository port and load the comment by comentarioId.", "Delete the persisted comment through the Comentario port.", "Return the deleted comment projection with comentarioId, chamadoId, atendenteId, and conteudo."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/deleteComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getAtendente.defs" {
    export const getAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getAtendente";
                readonly inputTypeName: "GetAtendenteInput";
                readonly outputTypeName: "GetAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Read the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "Return atendenteId and platformUserId from the retrieved Atendente record.", "If no record is found, return the platform's standard not-found result."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly situationOutput: "active";
            };
        };
    };
    export default getAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "getAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getChamado.defs" {
    export const getChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getChamado";
                readonly inputTypeName: "GetChamadoInput";
                readonly outputTypeName: "GetChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Chamado aggregate through the Chamado port using chamadoId.", "Return chamadoId, titulo, descricao, and status from the loaded Chamado."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "getChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/getComentario.defs" {
    export const getComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getComentario";
                readonly inputTypeName: "GetComentarioInput";
                readonly outputTypeName: "GetComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the Comentario aggregate through the Comentario port using comentarioId.", "Return comentarioId, chamadoId, atendenteId, and conteudo with the declared output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "getComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/getComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/inactivateAtendente.defs" {
    export const inactivateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "inactivateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "inactivateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "inactivateAtendente";
                readonly inputTypeName: "InactivateAtendenteInput";
                readonly outputTypeName: "InactivateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "If the Atendente record does not exist, return the documented master-data not-found error.", "In the same transaction wrapper, inactivate the Atendente master-data record through ctx.mdm.entity.inactivate({ mdmId: atendenteId, mdmType: \"controleChamados.Atendente\" }).", "Return atendenteId and platformUserId from the loaded record."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly lifecycle: "inactivate";
            };
        };
    };
    export default inactivateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "inactivateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/inactivateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listAtendente.defs" {
    export const listAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listAtendente";
                readonly inputTypeName: "ListAtendenteInput";
                readonly outputTypeName: "ListAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "includeInactive";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Include records inactivated in the MDM index; defaults to active records only.";
                    readonly ofEntity: "";
                    readonly fieldRef: "";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["List Atendente records through ctx.mdm.collection.listByType using type controleChamados.Atendente.", "By default request active records only; when includeInactive is true, include inactivated records from the MDM index.", "Return only atendenteId and platformUserId for each record."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly activeFilterInput: "includeInactive";
                readonly situationOutput: "active";
            };
        };
    };
    export default listAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "listAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listChamado.defs" {
    export const listChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listChamado";
                readonly inputTypeName: "ListChamadoInput";
                readonly outputTypeName: "ListChamadoOutput";
                readonly input: readonly [{
                    readonly name: "sortBy";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Campo de ordenação da listagem.";
                    readonly ofEntity: "";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "sortOrder";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Direção da ordenação.";
                    readonly ofEntity: "";
                    readonly fieldRef: "Chamado.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load all Chamado records through the Chamado repository port.", "Apply the optional status sort field and ascending or descending order when provided.", "Return the selected Chamado fields according to the canonical list output shape."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "listChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/listComentario.defs" {
    export const listComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listComentario";
            readonly ports: readonly ["Comentario"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listComentario";
                readonly inputTypeName: "ListComentarioInput";
                readonly outputTypeName: "ListComentarioOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load all Comentario records through the Comentario port.", "Return the selected comentarioId, chamadoId, atendenteId, and conteudo fields as the list projection."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "listComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/listComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/locateChamado.defs" {
    export const locateChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "locateChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "locateChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "locateChamado";
                readonly inputTypeName: "LocateChamadoInput";
                readonly outputTypeName: "LocateChamadoOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Use the Chamado port to list the open Chamado aggregate.", "Return the selected open Chamado projection with chamadoId, titulo, descricao, and status.", "Do not invent additional filtering or lifecycle transitions; the lifecycle defines open as the initial state and closed as terminal, but this query does not mutate state."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default locateChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "locateChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/locateChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/reactivateAtendente.defs" {
    export const reactivateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "reactivateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "reactivateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "reactivateAtendente";
                readonly inputTypeName: "ReactivateAtendenteInput";
                readonly outputTypeName: "ReactivateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get({ mdmId: atendenteId }).", "If the record does not exist, fail with a machine-readable not-found error and an English user-facing message.", "Reactivate the Atendente master-data record through the MDM lifecycle operation, using ctx.mdm.entity.update within the single transaction wrapper provided by ctx.data; do not create a local repository or port for this MDM entity.", "Return the reactivated record's atendenteId and platformUserId in the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
            readonly mdm: {
                readonly lifecycle: "reactivate";
            };
        };
    };
    export default reactivateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "reactivateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/reactivateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/registerComentario.defs" {
    export const registerComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "registerComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "registerComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "registerComentario";
                readonly inputTypeName: "RegisterComentarioInput";
                readonly outputTypeName: "RegisterComentarioOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Atendente selecionado para registrar o comentário.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado identificado pela rota.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve o Atendente por atendenteId usando ctx.mdm.entity.get({ mdmId: atendenteId }); não cria port para MDM.", "Carrega o Chamado por chamadoId através do port Chamado.", "Aplica a regra comentariosPermitidosSomenteEmChamadosAbertos: se o Chamado não tiver status open, rejeita com erro em inglês contendo o identificador da regra.", "Cria o Comentario com comentarioId gerado pelo mecanismo de domínio/port e os campos chamadoId, atendenteId e conteudo; persiste pelo port Comentario dentro da transação.", "Retorna comentarioId, chamadoId, atendenteId e conteudo do comentário persistido."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default registerComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "registerComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/registerComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateAtendente.defs" {
    export const updateAtendenteUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateAtendente";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateAtendente";
            readonly ports: readonly [];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateAtendente";
                readonly inputTypeName: "UpdateAtendenteInput";
                readonly outputTypeName: "UpdateAtendenteOutput";
                readonly input: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do atendente reutilizado entre os módulos da organização.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Referência ao usuário correspondente no diretório da plataforma, sem duplicar dados de login.";
                    readonly ofEntity: "Atendente";
                    readonly fieldRef: "Atendente.platformUserId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }, {
                    readonly name: "platformUserId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Atendente";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Atendente master-data record by atendenteId through ctx.mdm.entity.get.", "Update platformUserId through ctx.mdm.entity.update using the Atendente master-data identifier and module details when applicable.", "Return atendenteId and platformUserId matching the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.atendenteId";
                    }, {
                        readonly name: "platformUserId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Atendente.platformUserId";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default updateAtendenteUsecase;
    export const pipeline: readonly [{
        readonly id: "updateAtendente__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateAtendente.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateChamado.defs" {
    export const updateChamadoUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateChamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateChamado";
            readonly ports: readonly ["Chamado"];
            readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
            readonly functions: readonly [{
                readonly functionName: "updateChamado";
                readonly inputTypeName: "UpdateChamadoInput";
                readonly outputTypeName: "UpdateChamadoOutput";
                readonly input: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.titulo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Chamado";
                    readonly fieldRef: "Chamado.descricao";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "titulo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "descricao";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Chamado";
                }];
                readonly ports: readonly ["Chamado"];
                readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
                readonly transactional: true;
                readonly steps: readonly ["Use the Chamado port to load the existing Chamado by chamadoId inside the ctx.data transaction wrapper.", "Resolve status from the server-side systemDefault/current status rather than accepting it as public input.", "If the requested transition closes the Chamado, require the current status to be open and include rule id fechamentoExigeChamadoAberto in the validation error details when blocked.", "Call the domain canTransition helper using the declared chamadoLifecycle matrix; do not add a stricter local transition allow-list.", "If the existing Chamado is closed, reject any transition to open with rule id chamadoFechadoNaoPodeSerReaberto in the validation error details.", "Apply titulo and descricao, preserve the resolved status, save the Chamado through its port, and return the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.chamadoId";
                    }, {
                        readonly name: "titulo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.titulo";
                    }, {
                        readonly name: "descricao";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.descricao";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Chamado.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateChamadoUsecase;
    export const pipeline: readonly [{
        readonly id: "updateChamado__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateChamado.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["fechamentoExigeChamadoAberto", "chamadoFechadoNaoPodeSerReaberto"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_2_application/usecases/updateComentario.defs" {
    export const updateComentarioUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateComentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateComentario";
            readonly ports: readonly ["Comentario", "Chamado"];
            readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
            readonly functions: readonly [{
                readonly functionName: "updateComentario";
                readonly inputTypeName: "UpdateComentarioInput";
                readonly outputTypeName: "ComentarioOutput";
                readonly input: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.comentarioId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.chamadoId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.atendenteId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                    readonly ofEntity: "Comentario";
                    readonly fieldRef: "Comentario.conteudo";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "comentarioId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "chamadoId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "atendenteId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }, {
                    readonly name: "conteudo";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Comentario";
                }];
                readonly ports: readonly ["Comentario", "Chamado"];
                readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
                readonly transactional: true;
                readonly steps: readonly ["Within the transaction wrapper provided by ctx.data, load the Comentario aggregate through the Comentario port using comentarioId.", "Load the Chamado through the Chamado port using chamadoId and verify that its status is open; otherwise reject with an English AppError containing rule id comentariosPermitidosSomenteEmChamadosAbertos.", "Resolve the Atendente master-data reference by id through ctx.mdm.entity.get({ mdmId: atendenteId }); do not create a port for Atendente.", "Apply the requested selected-entity values and user-provided conteudo to the Comentario aggregate, preserving its identity and required relationships.", "Save the updated Comentario through its port in the same transaction and return exactly comentarioId, chamadoId, atendenteId, and conteudo."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "comentarioId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.comentarioId";
                    }, {
                        readonly name: "chamadoId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.chamadoId";
                    }, {
                        readonly name: "atendenteId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.atendenteId";
                    }, {
                        readonly name: "conteudo";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Comentario.conteudo";
                    }];
                };
            }];
            readonly mdmRefs: readonly ["Atendente"];
        };
    };
    export default updateComentarioUsecase;
    export const pipeline: readonly [{
        readonly id: "updateComentario__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_2_application/usecases/updateComentario.defs.ts";
        readonly dependsFiles: readonly ["_102039_/l1/controleChamados/layer_2_application/ports/comentarioRepository.d.ts", "_102039_/l1/controleChamados/layer_2_application/ports/chamadoRepository.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.d.ts", "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/usecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["comentariosPermitidosSomenteEmChamadosAbertos"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_3_domain/entities/chamado.defs" {
    export const chamadoDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Chamado";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Chamado";
            readonly title: "Chamado";
            readonly fields: readonly [{
                readonly fieldId: "chamadoId";
                readonly title: "Identificador do chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do chamado, transportado entre as etapas de acompanhamento.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueChamadoId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada chamado possui um identificador estável exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "titulo";
                readonly title: "Título";
                readonly type: "string";
                readonly required: true;
                readonly description: "Resumo do assunto ou solicitação de atendimento registrada no chamado.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "descricao";
                readonly title: "Descrição";
                readonly type: "text";
                readonly required: true;
                readonly description: "Detalhamento da solicitação de atendimento registrada no chamado.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "status";
                readonly title: "Status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do acompanhamento do chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "statusEnum";
                    readonly kind: "enum";
                    readonly value: "[\"open\",\"closed\"]";
                    readonly description: "Status permitidos para o ciclo de atendimento do chamado.";
                    readonly source: "journey";
                }];
                readonly enum: readonly ["open", "closed"];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly ["open", "closed"];
            readonly lifecycle: {
                readonly workflowId: "chamadoLifecycle";
                readonly entityRef: "Chamado";
                readonly states: readonly ["closed", "open"];
                readonly initialState: "open";
                readonly terminalStates: readonly ["closed"];
                readonly allowed: {
                    readonly closed: readonly [];
                    readonly open: readonly ["closed"];
                };
            };
            readonly invariants: readonly ["O chamadoId deve ser único entre todos os chamados."];
        };
    };
    export default chamadoDomainEntity;
    export const pipeline: readonly [{
        readonly id: "chamado__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_3_domain/entities/chamado.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/entry10/fixtures/controleChamados-l1/l1/layer_3_domain/entities/comentario.defs" {
    export const comentarioDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Comentario";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Comentario";
            readonly title: "Comentário";
            readonly fields: readonly [{
                readonly fieldId: "comentarioId";
                readonly title: "Identificador do comentário";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do comentário persistido no histórico de acompanhamento.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueComentarioId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada comentário possui um identificador estável e exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "chamadoId";
                readonly title: "Chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Chamado aberto selecionado ao qual o comentário pertence.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "atendenteId";
                readonly title: "Atendente que registrou";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Atendente autenticado identificado como responsável pelo registro do comentário.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "conteudo";
                readonly title: "Comentário";
                readonly type: "text";
                readonly required: true;
                readonly description: "Texto de acompanhamento escrito pelo atendente para o chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "conteudoMinLength";
                    readonly kind: "minLength";
                    readonly value: "1";
                    readonly description: "O comentário deve conter texto.";
                    readonly source: "journey";
                }];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly [];
            readonly invariants: readonly ["comentarioId deve ser único e estável para cada comentário persistido.", "conteudo deve conter pelo menos 1 caractere.", "O comentário só pode ser registrado para um chamado com status aberto."];
        };
    };
    export default comentarioDomainEntity;
    export const pipeline: readonly [{
        readonly id: "comentario__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.ts";
        readonly defPath: "_102039_/l1/controleChamados/layer_3_domain/entities/comentario.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentDefsL1/skills/architecture.md", "_102021_/l2/agentDefsL1/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102021_/l2/agentPlannerL1/steps/plan20/fixtures/ontology/index.defs" {
    export const mensalidadesAcademiaOntologyIndex: {
        schemaVersion: string;
        moduleName: string;
        entities: {
            entityId: string;
            kind: string;
            class: string;
        }[];
    };
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
