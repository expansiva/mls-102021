declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore" {
    export interface PipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath?: string;
        dependsFiles?: string[];
        dependsOn?: string[];
        skills?: string[];
        rulesApplied?: string[];
        agent?: string;
    }
    export interface ParsedDefs {
        dataExportName: string | null;
        artifact: Record<string, unknown> | null;
        data: unknown;
        item: PipelineItem | null;
    }
    export interface PlannedItem {
        item: PipelineItem;
        rank: number;
        stale: boolean;
        reason: string;
    }
    export interface MaterializeEnv {
        readRef(ref: string): Promise<string | null>;
        modifiedMs(ref: string): Promise<number | null>;
    }
    export interface GenResult {
        code: string;
    }
    export function layerRank(type: string): number;
    export function orderItems(items: PipelineItem[]): PipelineItem[];
    export function isStale(defsMs: number | null, tsMs: number | null): boolean;
    export function parseDefs(src: string): ParsedDefs;
    export const GEN_TOOL_NAME = "submitGeneratedTs";
    export const GEN_TOOL: {
        readonly type: "function";
        readonly function: {
            readonly name: "submitGeneratedTs";
            readonly description: "Submit the complete generated TypeScript file content.";
            readonly parameters: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["code"];
                readonly properties: {
                    readonly code: {
                        readonly type: "string";
                        readonly description: "Complete TypeScript file content. Must start with the /// <mls fileReference=\"...\"> header.";
                    };
                };
            };
        };
    };
    export const DEFAULT_MODEL_TYPE = "codehigh";
    export function parseModelType(systemPrompt: string): string | null;
    export function buildSystemPrompt(skillSections: string[], outputPath: string, modelType: string): string;
    export function buildHumanPrompt(data: unknown, contextSections: string[], outputPath: string): string;
    export function applyHeader(outputPath: string, code: string): string;
    export const CONTRACTS_102034: readonly string[];
    export function expandContextRef(ref: string): string[];
}
declare module "_102021_/l1/cbMaterializeCli/llmClient" {
    import { type GenResult } from "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore";
    export interface LlmConfig {
        baseUrl: string;
        token: string;
        orgId?: string;
        userId?: string;
        agentName?: string;
        toolStrict?: boolean;
        timeoutMs?: number;
        temperature?: number;
        maxTokens?: number;
    }
    export function parseGenResult(responseText: string, toolName?: string): GenResult;
    export interface LlmCallInput {
        model: string;
        system: string;
        human: string;
    }
    export interface LlmResult {
        ok: boolean;
        code?: string;
        raw: string;
        usage?: Record<string, unknown>;
        httpStatus: number;
        error?: string;
    }
    export function callCollabLlm(cfg: LlmConfig, input: LlmCallInput): Promise<LlmResult>;
}
declare module "_102021_/l1/cbMaterializeCli/nodejsMaterializeL1" { }
declare module "_102021_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbPlanner" {
    export type PlannerStatus = 'ok' | 'needs_input' | 'failed';
    export interface PlannerOutput<T> {
        status: PlannerStatus;
        result: T;
        questions: string[];
        trace: string[];
    }
    export interface PlannerExtractConfig<T> {
        toolName: string;
        preNormalizeResult?: (value: unknown) => unknown;
        normalizeResult: (value: unknown) => T;
    }
    export function createPlannerToolSchema(toolName: string, description: string, resultSchema: Record<string, unknown>): mls.msg.LLMTool;
    export function extractPlannerOutput<T>(payload: unknown, config: PlannerExtractConfig<T>): PlannerOutput<T>;
    export function validateJsonSchema(value: unknown, schema: unknown, path: string): void;
    export function parseMaybeJson(value: unknown): unknown;
    export function isRecord(value: unknown): value is Record<string, unknown>;
    export function assertRecord(value: unknown, path: string): Record<string, unknown>;
    export function assertArray(value: unknown, path: string): unknown[];
    export function assertString(value: unknown, path: string): string;
    export function optionalString(value: unknown): string | undefined;
    export function optionalStringArray(value: unknown): string[] | undefined;
    export function normalizeStringList(value: unknown, path: string): string[];
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbShared" {
    import { IAgentMeta } from "_102027_/l2/aiAgentBase";
    import { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, type PlannerExtractConfig, type PlannerOutput } from "_102021_/l2/agentChangeBackend/helpers/cbPlanner";
    export { createPlannerToolSchema, extractPlannerOutput, isRecord, parseMaybeJson, assertRecord, assertArray, assertString, optionalString, optionalStringArray, };
    export type { PlannerExtractConfig, PlannerOutput };
    /** Loose planner config: validates the envelope and returns the `result` object as a record. Each
     * agent reads the array property it expects (items/aggregates/tables/...). */
    export function plannerConfig(toolName: string): PlannerExtractConfig<Record<string, unknown>>;
    /** Wrap a single-artifact result schema into a batch `{ items: [...] }` schema for one-call-per-layer
     * generation (v1 processes a whole layer in one LLM call instead of a parallel_dynamic fan-out). */
    export function batchSchema(itemSchema: Record<string, unknown>): Record<string, unknown>;
    export function asArray(value: unknown): Record<string, unknown>[];
    export type ExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export type OwnerStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type EntityKind = 'core' | 'supporting' | 'event' | 'metric' | 'mdm';
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export type EventPurpose = 'telemetry' | 'audit' | 'reaction';
    export interface EventPolicy {
        purpose: EventPurpose;
        retentionDays?: number;
    }
    export const DEFAULT_EVENT_RETENTION_DAYS = 90;
    export type CbFileInfo = Pick<mls.stor.IFileInfo, 'project' | 'level' | 'folder' | 'shortName' | 'extension'>;
    export interface CbAccessPattern {
        kind: string;
        description: string;
        entity?: string;
        keyField?: string;
        filters?: string[];
        sort?: string[];
        pagination?: string;
        selection?: string;
        output?: string[];
    }
    export interface CbOperationInput {
        inputId: string;
        fieldRef: string;
        required: boolean;
        source: string;
        description: string;
    }
    export interface CbContextResolution {
        inputId?: string;
        targetRef: string;
        source: string;
        originRef: string;
        description: string;
    }
    export interface CbOwner {
        kind: 'operation' | 'workflow';
        id: string;
        pageId: string;
        commandName: string;
        bffName: string;
        title: string;
        entity: string;
        opKind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        accessPattern?: CbAccessPattern;
        inputs: CbOperationInput[];
        contextResolution: CbContextResolution[];
        acceptanceAssertions: string[];
        /** Status from l5/{module}/todoBackend.defs.ts. This is the only source of generation state. */
        todoStatus: string;
        /** Deprecated compatibility alias for prompts that still print owners as statusBackend. */
        statusBackend: string;
        /** Legacy inline status read from l4 only to warn about divergence; never used for decisions. */
        inlineStatusBackend: string;
        moduleName: string;
    }
    export interface CbEntity {
        entityId: string;
        title: string;
        kind: EntityKind;
        ownership: string;
        moduleName: string;
        fields?: Record<string, unknown>[];
        eventPolicy?: EventPolicy;
    }
    export interface CbRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
    }
    export interface CbAggregate {
        aggregateId: string;
        rootEntity: string;
        embeddedMembers: string[];
        events: string[];
        mdmRefs: string[];
    }
    export interface CbEventTarget {
        entityId: string;
        ownerEntity: string;
        purpose: EventPurpose;
        retentionDays?: number;
        persisted: boolean;
        fields?: Record<string, unknown>[];
    }
    export interface CbScan {
        project: number;
        moduleNames: string[];
        owners: CbOwner[];
        entities: CbEntity[];
        relationships: CbRelationship[];
        aggregates: CbAggregate[];
        events: CbEventTarget[];
        warnings: string[];
    }
    export function readBackendScan(statuses?: string[]): Promise<CbScan>;
    export function deriveEventTargets(entities: CbEntity[], relationships: CbRelationship[]): CbEventTarget[];
    export function deriveAggregates(entities: CbEntity[], relationships: CbRelationship[], operatedRootIds?: Set<string>): CbAggregate[];
    export interface CbColumnPlan {
        fieldId: string;
        reason: string;
    }
    export interface CbTablePlan {
        tableId: string;
        rootEntity: string;
        ownership: string;
        indexedColumns: CbColumnPlan[];
        detailsFields: string[];
        childCollections: string[];
    }
    /** Heuristic: a field needs a real column when it is the id (PK), a reference/FK (type is an entity
     * id or ends with "Id"), a status/lifecycle field, or an ordering timestamp (createdAt). Everything
     * else goes into details JSONB. Deterministic column plan consumed by the table/adapter generators. */
    export function planTableColumns(fields: Record<string, unknown>[], knownEntityIds: Set<string>): {
        indexed: CbColumnPlan[];
        details: string[];
    };
    export function domainEntityFileInfo(m: string, entityId: string): CbFileInfo;
    export function valueObjectFileInfo(m: string, memberId: string): CbFileInfo;
    export function repositoryPortFileInfo(m: string, entityId: string): CbFileInfo;
    export function usecaseFileInfo(m: string, usecaseId: string): CbFileInfo;
    export function persistenceTableFileInfo(m: string, tableId: string): CbFileInfo;
    export function repositoryAdapterFileInfo(m: string, entityId: string): CbFileInfo;
    export function httpControllerFileInfo(m: string, pageId: string): CbFileInfo;
    export const CB_AGENT_PROJECT = 102021;
    export const CB_AGENT_FOLDER = "agentChangeBackend";
    /** Read a co-located LLM prompt at runtime. Prompts live next to their step agent as
     * `agentChangeBackend/steps/<slug>/prompt.md` (moved into the step folders on 2026-07-11,
     * todo/modernizeChangeBackend.md step 4; inline template strings were extracted in step 2). Each file
     * keeps its `<!-- modelType: ... -->` marker; the caller still replaces the {{toolName}} placeholder.
     * `folderRel` is relative to this agent folder (e.g. 'steps/gen-domain'); fixed to project 102021 (the
     * agent's own files), NOT the client mls.actualProject. */
    export function readCbPrompt(folderRel: string, shortName?: string): Promise<string>;
    export function defsRef(fileInfo: CbFileInfo): string;
    /** The .d.ts ref of an artifact (used in dependsFiles — the callee's signatures). */
    export function dtsRef(fileInfo: CbFileInfo): string;
    /** Standard planning envelope shared by every .defs.ts data block. */
    export function buildArtifact(artifactType: string, artifactId: string, moduleName: string, agentName: string, data: unknown): Record<string, unknown>;
    /** Materialization context for a layer: the hexagonal base architecture skill + the per-type skill
     * (both co-located with this agent) + the platform defs. */
    export function layerSkills(skillFile: string): string[];
    export interface CbPipelineItem {
        id: string;
        type: string;
        outputPath: string;
        defPath: string;
        dependsFiles: string[];
        dependsOn: string[];
        skills: string[];
        rulesPath?: string;
        rulesApplied?: string[];
        agent: string;
    }
    /** Build the pipeline item that makes a .defs.ts self-sufficient for materialization (agentCbMaterialize
     * in-flow, or the cbMaterializeCli Node runner): it carries the outputPath (.ts), the dependsFiles
     * (.d.ts of the inner callee layer) and skills (the LLM context = layer skill + platform defs).
     * See spec.md (auto-suficiência). */
    export function buildPipelineItem(shortName: string, type: string, fileInfo: CbFileInfo, dependsFiles: string[], skills: string[], opts?: {
        rulesPath?: string;
        rulesApplied?: string[];
    }): CbPipelineItem;
    /** Write a .defs.ts with the platform header, the main `export const {name}` + default export, and
     * (optionally) the `export const pipeline`. Force-overwrites. */
    export function saveDefs(fileInfo: CbFileInfo, exportName: string, data: unknown, pipeline?: CbPipelineItem[]): Promise<string>;
    export function saveAgentTrace(context: mls.msg.ExecutionContext, agentName: string, step: mls.msg.AIAgentStep): Promise<void>;
    /** Update only l5/{module}/todoBackend.defs.ts. l4 owner defs are read-only for this agent. */
    export function setTodoBackendStatus(owner: CbOwner, status: OwnerStatus): Promise<boolean>;
    export function createUpdateStatusIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIPayload, step: mls.msg.AIPayload, hookSequential: number, status: mls.msg.AIStepStatus, traceMsg?: string, cleaner?: 'input' | 'input_output'): mls.msg.AgentIntentUpdateStatus;
    export function createAgentStepPayload(planId: string, agentName: string, stepTitle: string, args: unknown, dependsOn: string[], executionMode: ExecutionMode, status?: mls.msg.AIStepStatus, dynamicSource?: unknown): mls.msg.AIAgentStep;
    export function createAddStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep): mls.msg.AgentIntentAddStep;
    export function createPromptReadyIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, hookSequential: number, args: string, systemPrompt: string, humanPrompt: string, toolSchema: mls.msg.LLMTool, toolName: string): mls.msg.AgentIntentPromptReady;
    /** Spawn a parallel_dynamic fan-out: one child per selector arg, bounded by maxParallel. */
    export function createParallelStepIntent(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args: string[], dependsOn?: string[], maxParallel?: number): mls.msg.AgentIntentAddStep;
    export function logPrefix(agent: IAgentMeta | {
        agentName: string;
    }): string;
    export function planIdOf(step: mls.msg.AIPayload | undefined): string;
    /** The CLI command the root stored in the task longMemory (rebuild-all | rebuild-defs | run | help). */
    export function readCliCommand(context: mls.msg.ExecutionContext): string;
    /** Enqueue the next sequential step under the same parent, depending on the current step. v1 uses a
     * simple linear chain (not the parallel_dynamic fan-out in flow.json) — easier to reason about and
     * compile; parallelization is a later optimization. */
    export function enqueueNext(context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, currentStep: mls.msg.AIAgentStep, planId: string, agentName: string, stepTitle: string, args?: unknown): mls.msg.AgentIntentAddStep;
    export function parseDefsSource(content: string): unknown;
    export function readString(value: unknown): string;
    export function readStringArray(value: unknown): string[];
    export function lowerFirst(value: string): string;
    export function capitalize(value: string): string;
    export function toSafeShortName(value: string): string;
}
declare module "_102021_/l2/agentChangeBackend/agentChangeBackend" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface PublicationTargetConfig {
        assetBaseUrl?: string;
        serveStaticFromServer?: boolean;
        minify?: boolean;
        sourcemap?: boolean;
    }
    export interface PublicationConfig {
        defaultTarget: string;
        targets: Record<string, PublicationTargetConfig>;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        publication: PublicationConfig;
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        publication?: PublicationConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102021_/l2/agentChangeBackend/nodejsSaveConfigJson" { }
declare module "_102029_/l2/clientBoundarySources" {
    /**
     * The only L4 sources whose values cross the browser/BFF boundary.
     * Keep backend validation and frontend contract generation aligned by importing this module.
     */
    export const CLIENT_BOUNDARY_SOURCES: readonly ["userInput", "selectedEntity", "routeParam"];
    export type ClientBoundarySource = typeof CLIENT_BOUNDARY_SOURCES[number];
    export type ClientInputPresentation = 'form' | 'selection' | 'route';
    export function isClientBoundarySource(source: unknown): source is ClientBoundarySource;
    export function clientInputPresentation(source: unknown): ClientInputPresentation | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbComponentValidators" {
    /** Module-local l1 imports of a generated .ts: `from '_<project>_/l1/<folder>/<name>'`. Returns
     * the tsSet key (`${folder}::${shortName}`) so the caller can check the target was actually generated.
     * Cross-project imports (e.g. /_102034_/ platform) and non-l1 imports are ignored on purpose. */
    export function collectL1Imports(content: string, project: number): {
        key: string;
        target: string;
    }[];
    export function escapeRegExp(value: string): string;
    export function fieldNameFromRef(value: unknown): string;
    export function requiredBoundaryFields(inputContract: unknown): Set<string>;
    export function collectRequiredChecksByHandler(content: string): Map<string, Set<string>>;
    export function collectExportedHandlers(content: string): Set<string>;
    export function collectRouteHandlers(content: string): Map<string, string>;
    export function normalizeRuleId(rule: string): string;
    export function collectUsecaseRules(data: unknown): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbComponentValidators.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbMaterializeIo" {
    import type { PipelineItem } from "_102021_/l2/agentChangeBackend/helpers/cbMaterializeCore";
    export interface ParsedMlsPath {
        project: number;
        level: number;
        folder: string;
        shortName: string;
        extension: string;
    }
    /** Extract the `pipeline` array from a .defs.ts content string. */
    export function parsePipelineFromContent(content: string): PipelineItem[] | null;
    /** Scan every l1 .defs.ts (with a pipeline) of a module. */
    export function scanL1DefsWithPipeline(project: number, moduleName: string): Promise<Array<{
        folder: string;
        shortName: string;
        pipeline: PipelineItem[];
    }>>;
    /** updatedAt (ms) of a file, MAX_SAFE_INTEGER when new/changed without a timestamp, else null. */
    export function getFileModified(project: number, level: number, folder: string, shortName: string, extension: string): number | null;
    /** Read any file by its full MLS path string. */
    export function getContentByMlsPath(mlsPath: string): Promise<string | null>;
    /** Parse a MLS path like `_102050_/l1/cafeFlow/layer_1_external/adapters/persistence/order.ts`. */
    export function parseMlsPath(mlsPath: string): ParsedMlsPath | null;
    export interface SaveGeneratedTsResult {
        ok: boolean;
        /** TypeScript errors of the per-file compile (spec item 11: feed the compiler error back into the
         * repair prompt). Empty when clean or when the compile environment is unavailable. */
        compileErrors: string[];
    }
    /** Save (create or overwrite) a generated .ts file, force a recompile and report its errors. */
    export function saveGeneratedTs(project: number, level: number, folder: string, shortName: string, content: string): Promise<SaveGeneratedTsResult>;
    /** Pull the arguments of a named tool call out of the model payload (several shapes supported). */
    export function extractToolCallArgs<T>(raw: unknown, toolName: string): T | null;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmGuards" {
    export function collectRawMdmAccessIssues(code: string): string[];
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbMdmGuards.test" { }
declare module "_102021_/l2/agentChangeBackend/helpers/cbRepair" {
    /** Max REPAIR attempts per component after the first failure (first try + 2 repairs = 3 LLM calls). */
    export const COMPONENT_REPAIR_BUDGET = 2;
    /** Max full validate-all -> re-materialize repair rounds. */
    export const GLOBAL_REPAIR_BUDGET = 1;
    /** Max judge passes (initial critique + 1 post-repair verification). */
    export const JUDGE_MAX_RUNS = 2;
    /** Routing taxonomy (improveAddNewSolution2_1.md §2). fora_de_escopo findings are discarded. */
    export type CbFindingType = 'estrutural' | 'decisao' | 'fora_de_escopo';
    export interface CbJudgeFinding {
        ownerId: string;
        type: CbFindingType;
        severity: 'error' | 'warning';
        message: string;
        suggestion?: string;
    }
    export type CbRepairSource = 'component-validate' | 'validate-all' | 'judge';
    export interface CbComponentRepair {
        target: string;
        attempts: number;
        findings: string[];
        lastCode?: string;
        source: CbRepairSource;
        updatedAt: string;
    }
    export interface CbRepairState {
        schemaVersion: string;
        componentRepairs: Record<string, CbComponentRepair>;
        globalAttempts: number;
        judgeRuns: number;
        /** Durable audit of every repair occurrence in the run ("target :: attempt n :: finding"). The
         * fan-out children are DELETED by the runtime after completion, so this history is what survives;
         * cb-validate-all embeds it in the task trace before clearing the state. */
        history: string[];
        updatedAt: string;
    }
    export function readRepairState(): Promise<CbRepairState>;
    export function saveRepairState(state: CbRepairState): Promise<void>;
    /** Wipe the whole repair state (validate-all passed: the run converged). */
    export function clearRepairState(): Promise<void>;
    /** Repair target key for the usecase DEFS phase (shared by agentCbUsecase and agentCbJudge). */
    export function usecaseDefsTarget(ownerId: string): string;
    export function getComponentRepair(target: string): Promise<CbComponentRepair | null>;
    /** Record a failed attempt (increments the budget) and keep the findings + rejected code for the retry prompt. */
    export function recordComponentFailure(target: string, findings: string[], lastCode?: string, source?: CbRepairSource): Promise<CbComponentRepair>;
    /** Set findings WITHOUT burning component budget (used by the validate-all global round, which grants
     * the component a fresh worker budget — the global round has its own budget). */
    export function setComponentFindings(target: string, findings: string[], source: CbRepairSource): Promise<void>;
    export function clearComponentRepair(target: string): Promise<void>;
    /** True while the component may still be retried (attempts consumed <= budget). */
    export function hasRepairBudget(entry: CbComponentRepair | null | undefined): boolean;
    /** Repair section appended to the worker's human prompt on a retry. */
    export function buildRepairPromptSection(entry: CbComponentRepair): string;
    /** Persist the validate-all outcome + repair audit to l4/trace/cb-health-report.json. The task dump
     * keeps interaction null on deterministic steps and the repair state is cleared on success, so this
     * file is the DURABLE record of what was repaired in the run (survives task cleanup). */
    export function saveHealthReport(report: Record<string, unknown>): Promise<void>;
    /** Bump the .defs.ts updatedAt so the materialize dispatcher sees the component as stale again. */
    export function forceDefsStale(defRef: string): boolean;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSchemas" {
    export const domainEntityResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "fields"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly title: {
                readonly type: "string";
            };
            readonly fields: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["fieldId", "type", "required"];
                    readonly properties: {
                        readonly fieldId: {
                            readonly type: "string";
                        };
                        readonly type: {
                            readonly type: "string";
                        };
                        readonly required: {
                            readonly type: "boolean";
                        };
                        readonly description: {
                            readonly type: "string";
                        };
                        readonly enum: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
            readonly valueObjects: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly invariants: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly statusEnum: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const repositoryPortResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "interfaceName", "methods"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly interfaceName: {
                readonly type: "string";
            };
            readonly methods: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const persistenceTableResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["tableId", "tableName", "columns", "primaryKey"];
        readonly properties: {
            readonly tableId: {
                readonly type: "string";
            };
            readonly tableName: {
                readonly type: "string";
            };
            readonly columns: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly primaryKey: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly indexes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly detailsColumn: {
                readonly type: "object";
                readonly additionalProperties: false;
                readonly required: readonly ["enabled"];
                readonly properties: {
                    readonly enabled: {
                        readonly type: "boolean";
                    };
                    readonly columnName: {
                        readonly type: "string";
                    };
                    readonly childCollections: {
                        readonly type: "array";
                        readonly items: {
                            readonly type: "string";
                        };
                    };
                };
            };
            readonly appendOnly: {
                readonly type: "boolean";
            };
            readonly purpose: {
                readonly type: "string";
            };
            readonly retentionDays: {
                readonly type: "number";
            };
        };
    };
    export const repositoryAdapterResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["entityId", "className", "portRef", "tableRef"];
        readonly properties: {
            readonly entityId: {
                readonly type: "string";
            };
            readonly className: {
                readonly type: "string";
            };
            readonly portRef: {
                readonly type: "string";
            };
            readonly tableRef: {
                readonly type: "string";
            };
            readonly mdmReads: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly notes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
    export const usecaseResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["usecaseId", "ports", "functions"];
        readonly properties: {
            readonly usecaseId: {
                readonly type: "string";
            };
            readonly ports: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly rulesApplied: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly functions: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: readonly ["functionName", "inputTypeName", "outputTypeName", "input", "output"];
                    readonly properties: {
                        readonly functionName: {
                            readonly type: "string";
                        };
                        readonly inputTypeName: {
                            readonly type: "string";
                        };
                        readonly outputTypeName: {
                            readonly type: "string";
                        };
                        readonly input: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                };
                            };
                        };
                        readonly output: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "object";
                                readonly additionalProperties: false;
                                readonly required: readonly ["name", "type"];
                                readonly properties: {
                                    readonly name: {
                                        readonly type: "string";
                                    };
                                    readonly type: {
                                        readonly type: "string";
                                    };
                                    readonly required: {
                                        readonly type: "boolean";
                                    };
                                    readonly description: {
                                        readonly type: "string";
                                    };
                                    readonly ofEntity: {
                                        readonly type: "string";
                                    };
                                };
                            };
                        };
                        readonly ports: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly rulesApplied: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                        readonly transactional: {
                            readonly type: "boolean";
                        };
                        readonly steps: {
                            readonly type: "array";
                            readonly items: {
                                readonly type: "string";
                            };
                        };
                    };
                };
            };
        };
    };
    export const httpControllerResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["pageId", "controllerName", "handlers", "routes"];
        readonly properties: {
            readonly pageId: {
                readonly type: "string";
            };
            readonly controllerName: {
                readonly type: "string";
            };
            readonly handlers: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly routes: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const seedPlanResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary", "localTables", "mdmEntities"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly localTables: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
            readonly mdmEntities: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const judgeResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["findings"];
        readonly properties: {
            readonly findings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "object";
                    readonly additionalProperties: false;
                    readonly required: string[];
                    readonly properties: Record<string, unknown>;
                };
            };
        };
    };
    export const finalSummaryResultSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly required: readonly ["summary"];
        readonly properties: {
            readonly summary: {
                readonly type: "string";
            };
            readonly ownersDone: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
            readonly warnings: {
                readonly type: "array";
                readonly items: {
                    readonly type: "string";
                };
            };
        };
    };
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore" {
    export const SEED_T0 = "2026-07-01T08:00:00.000Z";
    export const SEED_T1 = "2026-07-01T09:00:00.000Z";
    export const SEED_WINDOW_START = "2026-07-01T00:00:00.000Z";
    export const SEED_WINDOW_END = "2026-07-08T00:00:00.000Z";
    export const SEED_PLAN_START = "/* <agentCbSeedsPlan>";
    export const SEED_PLAN_END = "</agentCbSeedsPlan> */";
    export interface SeedFieldDefinition {
        fieldId: string;
        type: string;
        required: boolean;
        enumValues: string[];
    }
    export interface SeedEntityDefinition {
        entityId: string;
        title: string;
        kind: string;
        fields: SeedFieldDefinition[];
    }
    export interface SeedTableColumn {
        name: string;
        type: string;
        nullable: boolean;
    }
    export interface SeedTableDefinition {
        tableId: string;
        tableName: string;
        seedFor: string;
        columns: SeedTableColumn[];
        primaryKey: string[];
    }
    export interface SeedReference {
        ref: string;
    }
    export type SeedValue = string | number | boolean | null | SeedReference;
    export interface SeedFieldValue {
        name: string;
        value: SeedValue;
    }
    export interface SeedChildRow {
        key: string;
        fields: SeedFieldValue[];
    }
    export interface SeedChildCollection {
        name: string;
        rows: SeedChildRow[];
    }
    export interface SeedLocalRow {
        key: string;
        columns: SeedFieldValue[];
        details: SeedFieldValue[];
        children: SeedChildCollection[];
    }
    export interface SeedLocalTable {
        tableId: string;
        rows: SeedLocalRow[];
    }
    export interface SeedMdmRelationship {
        targetRef: string;
        type: string;
        metadata: SeedFieldValue[];
        isBidirectional: boolean;
    }
    export interface SeedMdmRow {
        key: string;
        fields: SeedFieldValue[];
        relationships: SeedMdmRelationship[];
    }
    export interface SeedMdmEntity {
        entityId: string;
        rows: SeedMdmRow[];
    }
    export interface SeedPlan {
        summary: string;
        localTables: SeedLocalTable[];
        mdmEntities: SeedMdmEntity[];
    }
    export interface SeedRuleDefinition {
        ruleId: string;
        title: string;
        description: string;
        appliesTo: string[];
    }
    export interface SeedRelationshipDefinition {
        fromEntity: string;
        toEntity: string;
        type: string;
    }
    /** A deterministic batch of seed-plan targets. All references emitted by a target in a wave resolve
     * to a target in an earlier wave, or to another target in that same wave (a dependency cycle). */
    export interface SeedPlanningWave {
        index: number;
        tableIds: string[];
        mdmEntityIds: string[];
    }
    export interface SeedPlanProgress {
        plan: SeedPlan;
        partial: boolean;
        completedWaveIndexes: number[];
    }
    export interface SeedReferenceCatalogItem {
        ref: string;
        label: string;
        context: string;
    }
    export interface SeedPlanPromptOptions {
        catalog?: SeedReferenceCatalogItem[];
        priorSummary?: string;
        wave?: SeedPlanningWave;
        estimatedOutputTokens?: number;
    }
    export const MAX_SEED_WAVE_OUTPUT_TOKENS = 12000;
    /** An L4 actor (platform user role). Some FK fields (e.g. an assignee or the actorSession-resolved
     * worker on an event) reference a platform-user identity, NOT a module-owned entity — there is no
     * table/MDM entity to seed. The generator synthesizes a small, deterministic pool of platform-user
     * identities per actor so those FKs resolve to real MDM Person records instead of a fabricated table. */
    export interface SeedActorDefinition {
        actorId: string;
        title: string;
    }
    export interface SeedTimeWindow {
        start: string;
        end: string;
    }
    export interface SeedBuildInput {
        project: number;
        moduleName: string;
        language: string;
        entities: SeedEntityDefinition[];
        tablePlans: SeedTableDefinition[];
        ruleIds: string[];
        /** Full L4 rule text for the applied ruleIds. Passed to the planner so rule conformance is guided
         * by L4 semantics instead of hardcoded, domain-specific checks. */
        rules?: SeedRuleDefinition[];
        /** L4 relationship graph, so the planner models MDM relationships generically (no invented,
         * per-domain type names baked into this generator). */
        relationships?: SeedRelationshipDefinition[];
        /** L4 actors. The generator exposes a resolvable platform-user identity pool per actor so FKs that
         * reference a platform user (assignees, actorSession-resolved fields) never fabricate a table. */
        actors?: SeedActorDefinition[];
        /** Allowed timestamp window; every timestamp must be ISO 8601 within it. */
        timeWindow?: SeedTimeWindow;
        plan: SeedPlan;
    }
    export interface SeedBuildResult {
        errors: string[];
        content?: string;
        summary: string;
    }
    /**
     * Partitions seed targets by their real dependency graph. MDM starts in the first wave, ordinary
     * persistence tables in the second, and supporting/event tables in the third; a dependency moves
     * only its dependant forward. Strongly connected targets stay together so mutual references remain
     * valid within one LLM call.
     */
    export function deriveSeedPlanningWaves(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>): SeedPlanningWave[];
    /** Keeps a wave under the output budget by assigning whole dependency components to sequential
     * batches. An SCC is never split, so references inside a planning wave remain valid. */
    export function splitSeedPlanningWave(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave, maxTokens?: number): SeedPlanningWave[];
    export function estimateSeedPlanningWaveTokens(input: Pick<SeedBuildInput, 'entities' | 'tablePlans' | 'relationships'>, wave: SeedPlanningWave): number;
    /** Selects exactly the L4/table definitions that a wave may create. Rules and relationships are
     * filtered too, so unrelated definitions never inflate the planner context. */
    export function seedPlanInputForWave(input: Omit<SeedBuildInput, 'plan'>, wave: SeedPlanningWave): Omit<SeedBuildInput, 'plan'>;
    /** Turns a tool-call result into a defensive internal representation. Validation below remains the
     * authority: malformed values become empty and produce objective findings instead of being trusted. */
    export function parseSeedPlan(value: unknown): SeedPlan;
    /** Reads the persisted plan embedded in seeds.ts. A valid plan is reused so materializing the same
     * L4/table input never asks the model for a different fixture mass. */
    export function extractSeedPlanFromSource(source: string): SeedPlan | null;
    /** Reads either a completed or interrupted seed run from the persisted envelope. */
    export function extractSeedPlanProgressFromSource(source: string): SeedPlanProgress | null;
    /** A partial seeds.ts remains valid TypeScript so an interrupted flow can be resumed without
     * re-planning completed waves. It intentionally exports no runtime rows until final compilation. */
    export function buildPartialSeedSource(input: Pick<SeedBuildInput, 'project' | 'moduleName' | 'language'>, progress: Pick<SeedPlanProgress, 'plan' | 'completedWaveIndexes'>): string;
    export function mergeSeedPlans(current: SeedPlan, next: SeedPlan): SeedPlan;
    export function seedReferenceCatalog(plan: SeedPlan): SeedReferenceCatalogItem[];
    /** Deterministic validation of the plan before any seed source is saved. */
    export function validateSeedPlan(input: SeedBuildInput, knownReferences?: Iterable<string>): string[];
    /** Compile a validated plan. IDs, relationship IDs and structural MDM records are always generated
     * locally; only the business scenario itself comes from the LLM plan. */
    export function buildSeedSource(input: SeedBuildInput): SeedBuildResult;
    export function seedPlanPromptContext(input: Omit<SeedBuildInput, 'plan'>, repairFindings?: string[], options?: SeedPlanPromptOptions): string;
}
declare module "_102021_/l2/agentChangeBackend/helpers/cbSeedsCore.test" { }
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalSummary" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/finalize/agentCbFinalizeStatus" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-adapter/agentCbRepositoryAdapter" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-domain/agentCbDomainEntity" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-http/agentCbHttpController" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-port/agentCbRepositoryPort" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-seeds/agentCbSeeds" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-table/agentCbPersistenceTable" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/gen-usecase/agentCbUsecase" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/judge/agentCbJudge" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/materialize/agentCbMaterialize" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/register/agentCbRegister" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbLockOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbScanCreateOwners" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/scan/agentCbValidateL4Readiness" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/agentChangeBackend/steps/validate-all/agentCbValidateAll" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_102021_/l2/preview/servicePreviewForge" {
    import { LitElement } from 'lit';
    export class ServicePreviewForge102021 extends LitElement {
        private running;
        private building;
        private logs;
        private iframe;
        private esbuild;
        private _logHandler;
        disconnectedCallback(): void;
        private handleToggle;
        private handleClearLogs;
        private doStart;
        private doStop;
        private ensureEsbuild;
        private buildBundle;
        private discoverRouters;
        private buildEntry;
        private getVirtualFiles;
        private makeVfsPlugin;
        private mountIframe;
        private addLog;
        render(): any;
        static styles: any;
    }
}
