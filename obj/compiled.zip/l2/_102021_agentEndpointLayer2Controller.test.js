/// <mls shortName="agentEndpointLayer2Controller" project="102021" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
