/// <mls shortName="agentEndpoint" project="102021" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { getNextInProgressStepByAgentName, updateStepStatus, getNextPendentStep, appendLongTermMemory } from "./_100554_aiAgentHelper";
import { startNewAiTask, addNewStep } from "./_100554_aiAgentOrchestration";
const agentName = "agentEndpoint";
const project = 102021;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent Endpoint, for decide instructions",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async installBot(context) {
            throw new Error('Not implement');
        },
        async beforeBot(context, msg, toolsBeforeSendMessage) {
            throw new Error('Not implement');
        },
        async afterBot(context, output) {
            throw new Error('Not implement');
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (context.task)
        throw new Error("this agent cannot execute with anothers agentes");
    let prompt = context.message.content.replace('@@agentEndpoint', '').trim();
    const inputs = await getPrompts(prompt);
    await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    return;
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    await nextStep(context);
    context = await updateStepStatus(context, step.stepId, "completed");
};
async function nextStep(context) {
    if (!context.task)
        throw new Error(`[${agentName}]: nextStep not found task`);
    const step = getNextPendentStep(context.task);
    if (!step || step.type !== 'flexible' || !step.result)
        throw new Error(`[${agentName}]: ` + 'Invalid step in update defs, type: "' + step?.type + '"');
    if (typeof step.result === 'string' || !step.result.info)
        return;
    await appendLongTermMemory(context, { "info": JSON.stringify(step.result.info) });
    const newStep = {
        agentName: 'agentEndpointLayer4Entity',
        prompt: JSON.stringify(step.result.info),
        status: 'pending',
        stepId: step.stepId + 1,
        interaction: null,
        nextSteps: null,
        rags: null,
        type: 'agent'
    };
    await addNewStep(context, step.stepId, [newStep]);
}
async function getPrompts(userPrompt) {
    const dataForReplace = {
        userPrompt,
        context: await getRoutes(),
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
async function getRoutes() {
    const key = mls.stor.getKeyToFiles(mls.actualProject || 0, 1, 'routes', 'layer_2_controllers', '.defs.ts');
    if (!mls.stor.files[key])
        return '[]';
    const txt = await mls.stor.files[key].getContent();
    return txt;
}
