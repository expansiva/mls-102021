/// <mls shortName="agentEndpointLayer3UseCase" project="102021" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
