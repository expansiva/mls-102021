"use strict";
/// <mls shortName="agentEndpointLayer2Routes" project="102021" enhancement="_blank" folder="" />
