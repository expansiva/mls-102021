# input20 — snapshot, hashes, file closure

Deterministic. No LLM. No `prompt.md`. No `.defs.ts` is written.

## Input

The step prompt is the same JSON as entry10, with `planId: input20`. The checkpoint
must already have `entry10` approved. Sources are read by file identity:

- L4 module, journey index and journeys, ontology index and entities, rules, workflows, access, integration
- `pool/l2/web/menu.json`, `pool/l1/web/needs.json`, `pool/l2/web/backend.json`, `pool/l2/web/effort.json`
- the planner checkpoint `l1/<module>/pipeline/pipeline.json` (read only)
- `l2/<module>/web/contracts/<pageId>.defs.ts` when the page id is safe
- defs already at a planned `l1` path, compared with the inventoried hash or with the writer receipt (`traces/<step><step>.json`, `desiredHash`)

Pool messages are not read. Statuses in the pool are not changed.

## Output

`l1/<module>/pipeline/agentDefsL1/input20.json` records source hashes, the selected
ids, the planned files (`ownerRefs`, `dependsOn`, action), problems, the derivation of
each contract route with its gaps (`selection.requests[].unresolved`, review
`OUTPUT_UNRESOLVED`), and `sourceKey`: the hash of the snapshot built from the sources
alone (d1_62). The route is derived from its types and the ontology; `meta` is not read.
The final `input.json` is written by resolve25 with the answers; input20 does not write it.

`input20-done` is minted only when `consumersReleased` is true. A missing L2
contract (`CONTRACT_ABSENT`), an unreadable L2 contract (`CONTRACT_UNPARSED`),
a missing required source, a divergent plan, a stale L4 or a done item
without an inventoried file leaves the inventory on disk, sets `awaitingStep`
to `input20`, and records the blocking codes and counts on `steps.input20.error`.
That step is `failed`, not `approved`. `domain30` stays locked.

## Selection

Backend and effort must agree on id, status and the route fields. Ports come from
backend only. `toRemove` on a live row is an error; removal lives in `removed`.
A removed route does not drop a usecase that another selected route still uses.
`existing` is the identity. A path is a base for update only when the previous
receipt or the writer progress lists that path and hash. A file the agent wrote
keeps its `create` action; the snapshot hash does not change. A prefix of
`l1/<module>` is not ownership. A worker trace is not a receipt.

Review problems (payload, access anchor, unbound outbound, unattributed changes,
screens with no routes) stay on the inventory and do not by themselves release
or block consumer phases. A missing or unreadable contract does block them.
