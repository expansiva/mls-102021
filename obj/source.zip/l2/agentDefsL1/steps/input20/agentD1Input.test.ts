/// <mls fileReference="_102021_/l2/agentDefsL1/steps/input20/agentD1Input.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import type { IAgentMeta } from '/_102027_/l2/aiAgentBase.js';
import { createAgent } from '/_102021_/l2/agentDefsL1/agentDefsL1.js';
import {
  createD1AgentStep,
  createEntryPipeline,
  inputFile,
  pipelineFile,
  plannerPipelineFile,
} from '/_102021_/l2/agentDefsL1/helpers/d1Core.js';
import { fileKey, installStudio, seed } from '/_102021_/l2/agentDefsL1/helpers/d1TestHost.js';
import { writeJson } from '/_102021_/l2/agentDefsL1/helpers/d1Stor.js';
import { blockingReason } from '/_102021_/l2/agentDefsL1/steps/input20/agentD1Input.js';
import { fileInfoFromDisplay } from '/_102021_/l2/agentDefsL1/steps/input20/io.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FIXTURE = path.join(HERE, 'fixtures', 'head');
const CONTRACTS = path.join(HERE, 'fixtures', 'contracts');
const MODULE = 'agendaClinica';
const PROJECT = 102047;
const PAGES = ['agenda', 'cadastro_profissional', 'cadastro_recepcionista', 'consultas', 'pacientes'];

function walk(dir: string, prefix: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const abs = path.join(dir, name);
    const rel = prefix ? `${prefix}/${name}` : name;
    if (statSync(abs).isDirectory()) out.push(...walk(abs, rel));
    else out.push(rel);
  }
  return out;
}

function context(): mls.msg.ExecutionContext {
  const root: mls.msg.AIAgentStep = {
    type: 'agent',
    stepId: 1,
    interaction: null,
    stepTitle: 'defs',
    status: 'waiting_human_input',
    nextSteps: [],
    agentName: 'agentDefsL1',
    prompt: '',
    rags: [],
    planning: { planId: 'root', dependsOn: [], executionMode: 'sequential', executionHost: 'client' },
  };
  return {
    message: { orderAt: 'msg-1', threadId: 'thread-1', content: '', senderId: 'u' },
    task: {
      PK: 'task-1',
      iaCompressed: {
        nextSteps: [root],
        longMemory: { project: String(PROJECT), moduleName: MODULE },
      },
    },
  } as unknown as mls.msg.ExecutionContext;
}

function meta(): IAgentMeta {
  return { agentName: 'agentDefsL1', agentProject: 102021, agentFolder: 'agentDefsL1', agentDescription: 'test', visibility: 'public' };
}

async function readyHost(withContracts: boolean) {
  const host = installStudio(PROJECT);
  for (const rel of walk(FIXTURE, '')) {
    const file = rel.endsWith('.defs.txt') ? `${rel.slice(0, -4)}.ts` : rel;
    const info = fileInfoFromDisplay(PROJECT, file);
    assert.ok(info, rel);
    seed(host, info, readFileSync(path.join(FIXTURE, rel), 'utf8'), 'frozen');
  }
  if (withContracts) {
    const names = readdirSync(CONTRACTS).filter(name => name.endsWith('.defs.txt')).sort();
    for (const [index, pageId] of PAGES.entries()) {
      const body = readFileSync(path.join(CONTRACTS, names[index]), 'utf8');
      seed(host, fileInfoFromDisplay(PROJECT, `l2/${MODULE}/web/contracts/${pageId}.defs.ts`)!, body, 'contract');
    }
  }
  await writeJson(pipelineFile(PROJECT, MODULE), createEntryPipeline(PROJECT, MODULE, new Date('2026-09-21T12:00:00.000Z')));
  host.writes.length = 0;
  return host;
}

function blockingCodes(problems: Array<{ severity?: string; code?: string; ownerRef?: string }>): string {
  const counts = new Map<string, number>();
  const owners = new Map<string, string[]>();
  for (const problem of problems) {
    if (problem.severity !== 'error' || !problem.code) continue;
    counts.set(problem.code, (counts.get(problem.code) || 0) + 1);
    const refs = owners.get(problem.code) || [];
    if (problem.ownerRef && refs.length < 3 && !refs.includes(problem.ownerRef)) refs.push(problem.ownerRef);
    owners.set(problem.code, refs);
  }
  return [...counts.keys()].sort().map(code => {
    const refs = owners.get(code) || [];
    const head = `${code}:${counts.get(code)}`;
    return refs.length > 0 ? `${head} (${refs.join(', ')})` : head;
  }).join(',');
}

/** d1_93 s2: the hold reason names which route stopped, so a reader without input.json knows where to look. */
void test('the hold reason carries up to three ownerRefs per code', () => {
  const problem = (code: string, ownerRef?: string) => ({ severity: 'error', code, path: 'p', message: 'm', ...(ownerRef ? { ownerRef } : {}) });
  const problems = [
    problem('REQUEST_USECASE_UNPLANNED', 'onboarding.my_access_overview.saveMyData'),
    problem('ROUTE_X', 'r1'), problem('ROUTE_X', 'r2'), problem('ROUTE_X', 'r2'), problem('ROUTE_X', 'r3'), problem('ROUTE_X', 'r4'),
    problem('SCHEMA_DIVERGENT'),
    { severity: 'review', code: 'IGNORED', path: 'p', message: 'm', ownerRef: 'x' },
  ] as Parameters<typeof blockingReason>[0]['problems'];
  assert.equal(
    blockingReason({ problems }),
    'REQUEST_USECASE_UNPLANNED:1 (onboarding.my_access_overview.saveMyData),ROUTE_X:5 (r1, r2, r3),SCHEMA_DIVERGENT:1',
  );
});

void test('input20 without contracts records the inventory and does not unlock the next phase', { skip: 'frozen agendaClinica plan predates transitionRef (d1_53)' }, async () => {
  const host = await readyHost(false);
  const planner = host.files[fileKey(plannerPipelineFile(PROJECT, MODULE))]!;
  const agent = createAgent();
  const ctx = context();
  const step = createD1AgentStep('input20', MODULE, PROJECT, 'run');
  step.stepId = 20;
  const parent = ctx.task!.iaCompressed!.nextSteps![0] as mls.msg.AIAgentStep;
  const intents = await agent.beforePromptStep!(meta(), ctx, parent, step, 1);
  const trace = intents.find((intent): intent is mls.msg.AgentIntentUpdateStatus => intent.type === 'update-status');
  assert.match(trace?.traceMsg || '', /Consumer phases are not released/);
  assert.doesNotMatch(trace?.traceMsg || '', /success|approved/i);
  // d1_48: the held step fails, last, so the platform pauses the task instead of closing it done.
  assert.equal(trace?.status, 'failed');
  assert.equal(intents[intents.length - 1], trace);
  assert.equal(intents.some(intent => intent.type === 'add-step'), false);
  const inventory = JSON.parse(host.files[fileKey(inputFile(PROJECT, MODULE))]?.content || '{}') as {
    problems?: Array<{ severity?: string; code?: string; path?: string }>;
  };
  const reason = blockingCodes(inventory.problems || []);
  assert.match(reason, /^CONTRACT_ABSENT:\d+ \([^)]+\),SCHEMA_DIVERGENT:2$/);
  assert.equal((trace?.traceMsg || '').includes(reason), true);
  const pipeline = JSON.parse(host.files[fileKey(pipelineFile(PROJECT, MODULE))]?.content || '{}') as {
    status?: string;
    awaitingStep?: string;
    steps?: { input20?: { status?: string; error?: string; artifactPaths?: string[] }; domain30?: unknown };
  };
  assert.equal(pipeline.status, 'awaitingStep');
  assert.equal(pipeline.awaitingStep, 'input20');
  assert.equal(pipeline.steps?.input20?.status, 'failed');
  assert.notEqual(pipeline.steps?.input20?.status, 'approved');
  assert.equal(pipeline.steps?.input20?.error, reason);
  assert.equal(pipeline.steps?.input20?.error?.includes('/'), false);
  assert.equal(pipeline.steps?.input20?.artifactPaths?.[0]?.endsWith('/input.json'), true);
  assert.equal(pipeline.steps?.domain30, undefined);
  assert.equal(planner.updatedAt, 'frozen');
  const pipelineKey = fileKey(pipelineFile(PROJECT, MODULE));
  assert.equal(host.writes.filter(key => key === pipelineKey).length, 1);
  assert.equal(host.writes.every(key => key === fileKey(inputFile(PROJECT, MODULE)) || key === pipelineKey), true);
  assert.equal(Object.keys(host.files).some(key => key.includes('layer_')), false);

  const bytes = host.files[pipelineKey]?.content;
  const mtime = host.files[pipelineKey]?.updatedAt;
  const again = await agent.beforePromptStep!(meta(), ctx, parent, step, 2);
  assert.equal(again.some(intent => intent.type === 'add-step'), false);
  assert.equal(host.files[pipelineKey]?.content, bytes);
  assert.equal(host.files[pipelineKey]?.updatedAt, mtime);
  assert.equal(host.writes.filter(key => key === pipelineKey).length, 1);
});

/** The frozen head carries backend and effort v1.1; D1 reads only the v1.2 plans the producers write (d1_37, d1_39). */
void test('input20 refuses v1.1 plans even when contracts parse, and writes no defs', { skip: 'agendaClinica fixtures kept by Wagner (01/10); not a v2 source' }, async () => {
  const host = await readyHost(true);
  const contractKey = fileKey(fileInfoFromDisplay(PROJECT, `l2/${MODULE}/web/contracts/pacientes.defs.ts`)!);
  const contractMtime = host.files[contractKey]?.updatedAt;
  const agent = createAgent();
  const ctx = context();
  const step = createD1AgentStep('input20', MODULE, PROJECT, 'run');
  step.stepId = 20;
  const parent = ctx.task!.iaCompressed!.nextSteps![0] as mls.msg.AIAgentStep;
  const intents = await agent.beforePromptStep!(meta(), ctx, parent, step, 1);
  assert.equal(intents.some(intent => intent.type === 'add-step'), false);
  const trace = intents.find((intent): intent is mls.msg.AgentIntentUpdateStatus => intent.type === 'update-status');
  assert.match(trace?.traceMsg || '', /Consumer phases are not released/);
  const inventory = JSON.parse(host.files[fileKey(inputFile(PROJECT, MODULE))]?.content || '{}') as {
    consumersReleased?: boolean;
    problems?: Array<{ severity?: string; code?: string; path?: string; message?: string; ownerRef?: string }>;
  };
  assert.equal(inventory.consumersReleased, false);
  const refusals = (inventory.problems || []).filter(problem => problem.code === 'SCHEMA_DIVERGENT');
  const schemaRefs = refusals.map(problem => problem.ownerRef).filter((ref): ref is string => !!ref).slice(0, 3);
  assert.equal(blockingCodes(inventory.problems || []), schemaRefs.length > 0 ? `SCHEMA_DIVERGENT:2 (${schemaRefs.join(', ')})` : 'SCHEMA_DIVERGENT:2');
  assert.deepEqual(refusals.map(problem => problem.path).sort(), [`l4/${MODULE}/pool/l2/web/backend.json`, `l4/${MODULE}/pool/l2/web/effort.json`]);
  assert.ok(refusals.some(problem => /2026-09-21-p1-backend-v1\.1', expected 2026-09-21-p1-backend-v1\.2\. Regenerate/.test(problem.message || '')));
  assert.ok(refusals.some(problem => /2026-09-21-p2-effort-v1\.1', expected 2026-09-21-p2-effort-v1\.2\. Regenerate/.test(problem.message || '')));
  const pipeline = JSON.parse(host.files[fileKey(pipelineFile(PROJECT, MODULE))]?.content || '{}') as {
    status?: string;
    awaitingStep?: string;
    steps: { input20?: { status: string; error?: string }; domain30?: unknown };
  };
  assert.equal(pipeline.status, 'awaitingStep');
  assert.equal(pipeline.awaitingStep, 'input20');
  assert.equal(pipeline.steps.input20?.status, 'failed');
  assert.equal(pipeline.steps.input20?.error, blockingCodes(inventory.problems || []));
  assert.equal(pipeline.steps.domain30, undefined);
  assert.equal(host.files[contractKey]?.updatedAt, contractMtime);
  assert.equal(Object.keys(host.files).some(key => key.includes('layer_')), false);
  assert.equal(host.writes.some(key => key.includes('_4_') || key.includes('_5_') || key.includes('_2_')), false);
});
