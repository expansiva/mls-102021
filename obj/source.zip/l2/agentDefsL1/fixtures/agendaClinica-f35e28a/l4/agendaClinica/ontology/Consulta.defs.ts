/// <mls fileReference="_102047_/l4/agendaClinica/ontology/Consulta.defs.ts" enhancement="_blank"/>

import type { Ns5OntologyEntityV3 } from '/_102035_/l2/solution/types.js';

export const agendaClinicaEntityConsulta = {
  "schemaVersion": "2026-09-17-ns5-ontology-v3.1",
  "moduleName": "agendaClinica",
  "entityId": "Consulta",
  "title": "Consulta",
  "description": "Agendamento clínico de um paciente com um profissional em data e horário determinados, acompanhado até o atendimento ou a falta.",
  "displayField": "scheduledAt",
  "relationships": {
    "patient": {
      "relationshipId": "appointmentPatient",
      "to": "Paciente",
      "via": "Consulta.patientId",
      "cardinality": "N:1",
      "title": "Paciente da consulta",
      "description": "Cada consulta é agendada para um único paciente.",
      "mode": "fk",
      "required": "sempre",
      "role": "paciente"
    },
    "professional": {
      "relationshipId": "appointmentProfessional",
      "to": "Profissional",
      "via": "Consulta.professionalId",
      "cardinality": "N:1",
      "title": "Profissional da consulta",
      "description": "Cada consulta é realizada por um único profissional.",
      "mode": "fk",
      "required": "sempre",
      "role": "responsável"
    }
  },
  "capabilities": {
    "read.byId": "Lê uma consulta pelo identificador da linha no repositório de consultas, para a recepcionista e o profissional abrirem um agendamento já localizado.",
    "locate.byColumn": "Lista consultas por paciente, profissional, data e situação usando as colunas indexadas, para a recepcionista consultar disponibilidade e para o profissional ver a própria agenda diária.",
    "count": "Conta as consultas que correspondem aos filtros de profissional, data ou situação, para as telas de agenda da recepcionista e do profissional.",
    "listByForeignKey": "Lista as consultas vinculadas a um paciente ou profissional pela chave estrangeira, para a recepcionista consultar históricos de agendamento e o profissional consultar sua agenda.",
    "create": "Cria uma consulta com paciente, profissional, data e horário no repositório de consultas, para a recepcionista realizar o agendamento.",
    "transition": "Atualiza a situação da consulta pela transição permitida, para a recepcionista confirmar ou registrar falta e para o profissional registrar o atendimento.",
    "uniqueKey": "Impede outra consulta do mesmo profissional no mesmo data e horário pelo índice único de profissional e data/hora, para a recepcionista concluir apenas agendamentos disponíveis.",
    "read.mdmRecord": "Lê os registros mestres do paciente e do profissional referenciados pelas chaves da consulta, para a recepcionista e o profissional visualizarem os dados necessários da agenda."
  },
  "rules": [
    "uniqueProfessionalSchedule",
    "consultationTransitionFlow",
    "attendanceNoteRequired",
    "professionalOwnAppointment"
  ],
  "kind": "entity",
  "class": "event",
  "storage": {
    "target": "moduleDatabase",
    "table": "agendaClinica_consulta",
    "kind": "relational"
  },
  "record": {
    "fields": {
      "id": {
        "type": "uuid",
        "required": true,
        "derived": true,
        "indexed": true,
        "title": "Id"
      },
      "version": {
        "type": "integer",
        "required": true,
        "derived": true
      },
      "patientId": {
        "type": "record",
        "required": true,
        "indexed": true,
        "of": "Address",
        "to": [
          "Paciente"
        ],
        "title": "Paciente",
        "description": "Paciente para quem a consulta foi agendada.",
        "maxLength": 0,
        "min": 0,
        "max": 0
      },
      "professionalId": {
        "type": "record",
        "required": true,
        "indexed": true,
        "of": "Address",
        "to": [
          "Profissional"
        ],
        "title": "Profissional",
        "description": "Médico ou terapeuta responsável pela realização da consulta.",
        "maxLength": 0,
        "min": 0,
        "max": 0
      },
      "scheduledAt": {
        "type": "timestamp",
        "required": true,
        "indexed": true,
        "of": "Address",
        "title": "Data e horário",
        "description": "Data e horário marcados para a consulta.",
        "maxLength": 0,
        "min": 0,
        "max": 0
      },
      "status": {
        "type": "enum",
        "required": true,
        "indexed": true,
        "of": "Address",
        "values": [
          {
            "value": "scheduled",
            "title": "Agendada",
            "description": "Consulta marcada e ainda sem confirmação."
          },
          {
            "value": "confirmed",
            "title": "Confirmada",
            "description": "Consulta confirmada por telefone."
          },
          {
            "value": "noShow",
            "title": "Falta",
            "description": "Paciente não compareceu à consulta."
          },
          {
            "value": "attended",
            "title": "Atendida",
            "description": "Consulta realizada e registrada pelo profissional."
          }
        ],
        "title": "Situação",
        "description": "Situação do agendamento, atualizada pela recepcionista ou pelo profissional conforme sua atuação.",
        "maxLength": 0,
        "min": 0,
        "max": 0
      },
      "details": {
        "type": "object",
        "required": true,
        "of": "Address",
        "title": "Detalhes da consulta",
        "description": "Informações clínicas registradas para esta consulta que não são usadas em filtros ou ordenações.",
        "maxLength": 0,
        "min": 0,
        "max": 0,
        "fields": {
          "attendanceNote": {
            "type": "text",
            "of": "Address",
            "title": "Anotação do atendimento",
            "description": "Anotação registrada pelo profissional sobre o atendimento realizado.",
            "maxLength": 0,
            "min": 0,
            "max": 0
          }
        }
      }
    }
  },
  "uniqueKeys": [
    [
      "professionalId",
      "scheduledAt"
    ]
  ],
  "lifecycleStates": [
    {
      "state": "scheduled",
      "reachedBy": "actor"
    },
    {
      "state": "confirmed",
      "reachedBy": "actor"
    },
    {
      "state": "noShow",
      "reachedBy": "actor"
    },
    {
      "state": "attended",
      "reachedBy": "actor"
    }
  ],
  "transitions": [
    {
      "transitionId": "confirmarConsulta",
      "from": [
        "scheduled"
      ],
      "to": "confirmed",
      "by": [
        "recepcionista"
      ],
      "description": "Registra a confirmação da consulta por telefone.",
      "payload": [],
      "ruleRefs": [
        "consultationTransitionFlow"
      ]
    },
    {
      "transitionId": "registrarFalta",
      "from": [
        "scheduled",
        "confirmed"
      ],
      "to": "noShow",
      "by": [
        "recepcionista"
      ],
      "description": "Registra a falta quando o paciente não comparece à consulta.",
      "payload": [],
      "ruleRefs": [
        "consultationTransitionFlow"
      ]
    },
    {
      "transitionId": "registrarAtendimento",
      "from": [
        "scheduled",
        "confirmed"
      ],
      "to": "attended",
      "by": [
        "profissional"
      ],
      "description": "Conclui a própria consulta como atendida e exige a anotação do atendimento.",
      "payload": [
        "details.attendanceNote"
      ],
      "ruleRefs": [
        "consultationTransitionFlow",
        "attendanceNoteRequired",
        "professionalOwnAppointment"
      ]
    }
  ]
} as const satisfies Ns5OntologyEntityV3;

export type AgendaClinicaEntityConsultaType = typeof agendaClinicaEntityConsulta;

export default agendaClinicaEntityConsulta;
