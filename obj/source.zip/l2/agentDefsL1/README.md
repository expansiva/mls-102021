# agentDefsL1

L1 defs agent. CLI, project identity, resume, the input20 inventory, the
domain30 defs, the persistence40 defs and the usecases50 plans. usecases50
is the step that calls a model, and only for operation steps. A step that is
only declared in `docs/flow.json` reports that it is not implemented.

## Invocation

```
@@agentDefsL1 <lowerCamel> /run
@@agentDefsL1 <lowerCamel> /resume
@@agentDefsL1 <lowerCamel> /help
```

`/help` writes nothing. `/run` records a checkpoint when the module has none
in this project. `/resume` continues an intact checkpoint and does not rewrite
it. A second `/run` of an intact checkpoint is the same no-op.

The project id is `mls.actualProject`, captured once on the task
(`longTermMemory.project`). Later hooks use that value. The same module name
in another project is a different module.

## Refusals

English, no model, no writes:

- missing module, or a module token that is not lowerCamel
- missing project identity
- more than one command, an unexpected argument, or an unknown flag (`/fast`, `/rebuild` without `all`, `/candidates`)
- `/candidate`, including `/candidate tobe/plan` — same flag spelling as the L1 planner, refused here. Nothing is pointed at `tobe`
- `/candidate` with `..` — `Candidate path must not contain '..'.`
- any other `..` — `Path must not contain '..'.`
- `/rebuild all` — same flag spelling as agentNewSolution5, refused. Nothing is deleted
- `/resume` without an intact checkpoint
- a checkpoint that does not parse, or that belongs to another flow, project or module
- a step prompt that carries a field this step does not know (`candidate` is not dropped)

## Write surface

| path | this delivery |
|---|---|
| `l1/<module>/pipeline/agentDefsL1/pipeline.json` | written on the first `/run` |
| `l1/<module>/pipeline/pipeline.json` | planner file. Never written or removed |
| `l1/<module>/pipeline/agentDefsL1/input20.json` | written by input20: the derivation with its gaps, its problems and the source key. Same bytes are not rewritten |
| `l1/<module>/pipeline/agentDefsL1/resolve25.json` | written by resolve25: one answer per open part of a contract route. Kept while the source key is the same |
| `l1/<module>/pipeline/agentDefsL1/input.json` | written by resolve25: the final inventory with the answers. Same bytes are not rewritten |
| `l1/<module>/pipeline/agentDefsL1/drafts/domain30.json` | written by domain30. A draft does not approve a step |
| `l1/<module>/pipeline/agentDefsL1/drafts/persistence40.json` | written by persistence40. A draft does not approve a step |
| `l1/<module>/pipeline/agentDefsL1/traces/<step><unit>.json` | progress of one unit: previous hash, draft hash, and each file. Not a transaction |
| `l1/<module>/pipeline/agentDefsL1/report.json` | written by finalize80. Same bytes are not rewritten |

Checkpoint reads and writes use `pipelineFile(project, module)`. Domain defs use
`artifactFile`, the same identity input20 uses. A remove of the planner file is
refused. domain30 and persistence40 write `.defs.ts` only. They do not write `.ts` outputs.
l4, l2, l5 and the pool are not written.

The display path includes the project: `_102047_/l1/<module>/pipeline/agentDefsL1/pipeline.json`.

## Resume metadata

Stored on the checkpoint and on the task: `project`, `moduleName`, `flowId`,
`flowVersion`, `schemaVersion`, `command`, `steps.entry10.status`,
`steps.entry10.artifactPaths`, `updatedAt`.

Intact means the file parses, those identities match the invocation, and
`entry10` is `approved` with its own artifact path. Resume then writes zero
bytes. A duplicate or late hook cannot move `entry10` off `approved` and
cannot move `awaitingStep` forward.

`input20` records the inventory and does not generate `.defs.ts`. A route comes from the
L2 contract v2, not from `backend.endpoints` or `effort.endpoints`. A usecase comes from the
pool (`backend.json` and `effort.json`) and is tied to a request by entity and operation.
It approves
itself and mints `input20-done` only when consumer phases are released. A missing
contract or a missing required source sets `awaitingStep` to `input20` and
records the blocking codes and counts on `steps.input20` (`failed`, not
`approved`). The problem list stays in `input20.json`. The waiting task steps are
stopped so the run ends. A later hook does not rewrite that checkpoint.
`/resume` on that held checkpoint does not recompute the reason, does not
rewrite the file, and does not approve `input20`.

A product write checks the receipt hash immediately before the mutation.
Stor has no multi-file transaction. The progress file is how a stopped unit
continues; a matching file is not rewritten, so its bytes and mtime stay.
A changed hash is not overwritten. A future `.ts` path is reported and not
deleted. mtime is not a version, and an approved checkpoint is not proof that
the bytes are still there. The same snapshot with intact outputs does not call
the model.

`resolve25` reads the contract routes from the sources input20 sealed (a changed digest stops it) and
lists the parts the derivation leaves open, each with closed candidates and `none`. No open part, no model
call. Otherwise one worker per route, on the shared fan-out (`helpers/d1Fanout.ts`); the tool offers one
`enum` per part, the gate accepts only a candidate, one repair, then `none`. Until the input20 selection
reads `resolve25.json` (d1_62 r2 item 2), the answers are recorded and not consumed.

`domain30` writes one domain def per selected entity that is not `preserve`, and
a value object only when a record reference names it. It approves itself and
mints `domain30-done` only when the build has no error. The same bytes are not
rewritten.

`persistence40` writes one port, one table and one adapter per planned
module-database item. `uniqueKeys` come from the domain draft. Enumerations
stay on that draft. It approves itself and mints `persistence40-done` only
when the build has no error. The same bytes are not rewritten. It does not
write seeds or the repository registry.

`usecases50` writes one usecase def per selected usecase. A worker plans the
operation steps. Ids, routes and contract symbols stay mechanical. Enum
values stay on the domain draft. `controllers60` writes one http controller
def per page. The binding and the projection stay on its draft. Enum values
stay on the domain draft. `support70` writes the access scope, the authority
map, the repository registry and the seed plan. Join helpers stay on its
draft. A seed scenario names the entity and the field it cites. `consumed` means a
covered consumer was proved for that field. A platform owner does not erase a
local restriction, and a type union is not runtime enforcement. Enum values
stay on the domain draft. It writes the outbound effect plan and does not publish it. It does not write `seeds.ts`, rows, a scheduler or l5.
`finalize80` reads the checkpoint, the snapshot, the drafts and the defs on
disk. It writes `report.json`. It does not run an earlier phase and it does
not call a model. A future `.ts` that is absent is pending materialization,
not a missing def. An absent L2 contract is a real gap. Inventory recognition
is not an executable backend. A step that did not run is reported as not
executed. The same report is not rewritten. finalize80 does not open a repair
cycle. When the defs are intact it sets `pipeline.status` to `complete`. An
error keeps `awaitingStep` on `finalize80` with `CODE:count` and the step is
not `approved`. A run already held at an earlier step is left there.

## Defs contract

Schema `2026-09-21-d1-definition-v1`. The first data export is `definition`
(`schemaVersion` `2026-09-24-d1-definition-v2`, `artifactType`, `artifactId`,
`moduleName`, `status`, `dependencies`, `data`). There is no `export const pipeline`
and no `agent`. `status` starts `pending`. A concrete external gap is `blocked`
and the reason is on the materialization receipt, not chosen by the model.
`dependencies` are qualified files actually consumed (`_NNNNN_/lN/...`): L2
contracts, rules, ontology, access scope and 102034 sources. Skills and output
paths are materializer conventions and are not written into the def. The
internal checkpoint under `pipeline/agentDefsL1/` stays. A collision of path is
refused before `writeText`. The file identity is `artifactFile`, which uses the
same `fileInfoFromDisplay` as input20. Nothing is stripped to make a document pass.

`readL1Inventory` reads `usecase`, `repositoryPort`, `table` and
`httpController`. For a table it uses `data.tableId` and `artifactId` as the
entity, so `data.entityId` must equal `artifactId`. Function `input`/`output`
are a projection (`name`, `type`, `fieldRef`), not a second DTO.
`handlers.route` is the route string from the plan.

| artifactType | file under `l1/<module>/` | export |
|---|---|---|
| domainEntity | `layer_3_domain/entities/<lowerFirst>.defs.ts` | `definition` |
| valueObject | `layer_3_domain/value-objects/<id>.defs.ts` | `definition` |
| repositoryPort | `layer_2_application/ports/<entity>Repository.defs.ts` | `definition` |
| table | `layer_1_external/adapters/persistence/<tableId>.defs.ts` | `definition` |
| repositoryAdapter | `layer_1_external/adapters/persistence/<entity>RepositoryAdapter.defs.ts` | `definition` |
| usecase | `layer_2_application/usecases/<usecaseId>.defs.ts` | `definition` |
| httpController | `layer_1_external/adapters/http/controllers/<pageId>.defs.ts` | `definition` |
| accessScope | `layer_2_application/scope/accessScope.defs.ts` | `definition` |
| authorityMap | `layer_1_external/auth/authorityMap.defs.ts` | `definition` |
| repositoryRegistration | `layer_1_external/adapters/persistence/registerRepositories.defs.ts` | `definition` |
| persistenceSeeds | `layer_1_external/adapters/persistence/seeds.defs.ts` | `definition` |
| integrationOutbound | `layer_1_external/adapters/integration/outbound.defs.ts` | `definition` |

`export default definition` points at that object. The internal catalog still
records `id`, `type`, `defPath`, `outputPath`, `outputAvailability`,
`dependsFiles`, `dependsOn`, `skills`, and `routes` on a controller, but that
catalog is not an export of the def. `id` is `project/module/type/owner`.
`outputAvailability: future` is the `.ts` the materializer does not write in
this delivery. A `.d.ts` with no item `outputPath` is an uncontracted
declaration. A path that is neither a planned def, a present file nor a
declared output is a missing input.

Every property in the three schemas has a reader in `D1_FIELD_READERS`.
Auxiliary types (`valueObject`, `accessScope`, `authorityMap`,
`repositoryRegistration`, `persistenceSeeds`, `integrationOutbound`) are not
dispatched by agentChangeBackend. A value object with an empty `referencedBy`
is not emitted. The agendaClinica example records that absence instead of a
file.

The design forecast of 26 is 5 models, 1 port, 1 table, 1 adapter, 13 usecases
and 5 controllers. The measured plan fixture has 6 controllers, so the same
core categories sum to 27, plus 5 justified auxiliaries (32 planned defs).
That sum is not a count of files this agent generated. usecases50 writes the
usecase defs. controllers60 writes the controller defs. support70 writes
the access scope, the authority map, the repository registry, the seed
plan and the outbound effect plan. An event with no named mechanism stays unbound.
Naming `IQueueRuntime.publish` is `MECHANISM_INCOMPATIBLE`, not a binding.

## Flow

`docs/flow.json` is the contract. Done-anchors (`<step>-done`) unlock the next
step. Fan-out, worker, repair and barrier ids are reserved (`<step>-fanout`,
`<step>-worker-<itemId>`, `<step>-repair-<n>`, `<step>-barrier`). One repair per unit, eight
attempts globally, and finalize80 does not open another repair cycle. Child
hooks do not create a task and do not add steps. `update-status` cleans with
`input_output`.

This flow never dispatches `agentCbMaterialize`, `agentChangeBackend` or
`agentMaterializeL2`.
