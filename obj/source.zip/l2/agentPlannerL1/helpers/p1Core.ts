/// <mls fileReference="_102021_/l2/agentPlannerL1/helpers/p1Core.ts" enhancement="_blank"/>

import {
  diskFileInfo,
  displayPath,
  moduleFile,
  moduleFolder,
  normalizeModuleName,
  readJson,
  readPipeline,
  setModuleRoot,
  writeJson,
  type Ns5FileInfo,
} from '/_102035_/l2/solution/fs.js';
import {
  deletePoolMessageAt,
  listPoolBox,
  readPoolMessage,
  readPoolTraceAt,
  tracePoolAt,
  type PoolMessage,
  type PoolTraceLine,
} from '/_102035_/l2/solution/pool.js';
import type { Ns5PipelineStatus, Ns5PipelineStepState } from '/_102035_/l2/solution/types.js';
import { readL1Inventory, type L1Inventory } from '/_102021_/l2/agentPlannerL1/helpers/l1Inventory.js';

export const P1_FLOW_ID = 'agentPlannerL1' as const;
export const P1_FLOW_VERSION = '2026-09-20-p1-flow-v1' as const;
export const P1_AGENT_NAME = 'agentPlannerL1' as const;
export const P1_PIPELINE_SCHEMA_VERSION = '2026-09-20-p1-pipeline-v1' as const;
export const P1_NEEDS_SCHEMA = '2026-09-21-p2-needs-v1' as const;
export const P1_DEVICE = 'web' as const;
export type P1Device = typeof P1_DEVICE;

/** Steps the current flow.json actually runs. */
export const P1_FLOW_STEP_IDS = ['entry10', 'plan20'] as const;

export const P1_STEP_IDS = P1_FLOW_STEP_IDS;

export type P1FlowStepId = typeof P1_FLOW_STEP_IDS[number];
export type P1StepId = typeof P1_STEP_IDS[number];

/** Last step of `docs/flow.json` — plan20 closes the pipeline. */
export const P1_FLOW_LAST_STEP_ID: P1FlowStepId = P1_FLOW_STEP_IDS[P1_FLOW_STEP_IDS.length - 1];

export const P1_STEP_TITLES: Record<P1StepId, string> = {
  entry10: 'Entry',
  plan20: 'Plan',
};

export const P1_STEP_DEPENDS_ON: Record<P1StepId, readonly string[]> = {
  entry10: [],
  plan20: ['entry10-done'],
};

/** Pool message file: `<stamp>_<thread>_<round>`. `needs.json` does not match. */
const POOL_MESSAGE_SHORT = /^\d{14}_[A-Za-z0-9]+-\d{14}_[123]$/;

/** Copied from `plCore.ts:68,111` — L1 must not import the L4 planner. */
const CANDIDATE_RE = /(^|\s)\/candidate(?:\s+(?!\/)(\S+))?(?=\s|$)/i;
const CANDIDATE_DOTDOT = 'Candidate path must not contain \'..\'.';

/** Same default as `PL_DEFAULT_CANDIDATE_REL` in `plCore.ts`. */
export const P1_DEFAULT_CANDIDATE_REL = 'tobe/plan' as const;

export interface P1ParsedInvocation {
  module: string;
  /** Resolved `l4/` folder when `/candidate` is present; otherwise `''`. */
  candidate: string;
  /** True when the `/candidate` token was present, even if the path was refused. */
  hasCandidate: boolean;
}

export type P1EntrySource =
  | { kind: 'hand'; moduleName: string; candidate?: string }
  | { kind: 'step'; moduleName: string; thread: string; file: string; candidate?: string };

export interface P1Needs {
  schemaVersion: string;
  moduleName: string;
  device?: string;
  pages?: unknown[];
}

export interface P1PipelineState {
  schemaVersion: typeof P1_PIPELINE_SCHEMA_VERSION;
  flowId: typeof P1_FLOW_ID;
  moduleName: string;
  status: Ns5PipelineStatus;
  awaitingStep?: P1StepId;
  steps: Partial<Record<P1StepId, Ns5PipelineStepState>>;
  thread: string;
  round: number;
  messageFile: string;
  sourceMessages: string[];
  needsFile: string;
  inventory: L1Inventory;
  pool?: PoolTraceLine[];
  /**
   * Display paths of the duplicates consumed with `messageFile`. The pool enum has no
   * `superseded` outcome yet, so their trace line is `processed` and this list names them.
   */
  supersededMessages?: string[];
  updatedAt: string;
}

export interface P1LoadedEntry {
  moduleName: string;
  file: Ns5FileInfo;
  message: PoolMessage;
  sourceMessages: string[];
  needsFile: Ns5FileInfo;
  needs: P1Needs;
}

export type P1LoadResult = P1LoadedEntry | { refusal: string };
export type P1ExecuteResult = { pipeline: P1PipelineState; file: Ns5FileInfo; message: PoolMessage } | { refusal: string };

const AGENT_PREFIXES = [
  /@@\s*_102021_\/l2\/agentPlannerL1/gi,
  /@@\s*_102021_agentPlannerL1/gi,
  /@@\s*agentPlannerL1/gi,
];

export function isP1StepId(value: string): value is P1StepId {
  return (P1_STEP_IDS as readonly string[]).includes(value);
}

export function moduleTokenOk(moduleName: string): boolean {
  return /^[a-z][A-Za-z0-9]*$/.test(moduleName);
}

/** Copied from `plCore.ts:111`. `..` in the relative path returns `''`. */
export function resolveCandidateFolder(moduleName: string, relativePath = ''): string {
  const mod = normalizeModuleName(moduleName);
  const rel = String(relativePath || '').trim().replace(/^\/+|\/+$/g, '') || P1_DEFAULT_CANDIDATE_REL;
  if (rel.includes('..')) return '';
  if (rel === mod || rel.startsWith(`${mod}/`)) return rel;
  return `${mod}/${rel}`;
}

/**
 * Point `moduleFolder` at `candidate`, or restore the canonical root when it is
 * empty. `..` is a refusal, not a silent "no candidate". Always call this before
 * reading l4 / pool / pipeline so a previous task cannot leak its root.
 */
export function applyP1CandidateRoot(moduleName: string, candidate: string): string {
  const name = normalizeModuleName(moduleName, '');
  if (!name) return '';
  const raw = String(candidate || '').trim();
  if (!raw) {
    setModuleRoot(name, null);
    return '';
  }
  if (raw.includes('..')) {
    setModuleRoot(name, null);
    return CANDIDATE_DOTDOT;
  }
  const resolved = resolveCandidateFolder(name, raw);
  if (!resolved) {
    setModuleRoot(name, null);
    return CANDIDATE_DOTDOT;
  }
  setModuleRoot(name, resolved);
  return '';
}

/**
 * Maps child planIds back to the owning step. Done-anchors stay unmatched so they
 * are not dispatched. A step prompt `{ moduleName, thread, file }` (pool dispatch)
 * is entry10.
 */
export function ownerStepId(planId: string, prompt?: string): P1StepId | '' {
  if (isP1StepId(planId)) return planId;
  for (const id of P1_STEP_IDS) {
    if (planId === `${id}-done` || planId.startsWith(`${id}-clarification`)) return '';
    if (planId.startsWith(`${id}-`)) return id;
  }
  if (isPoolEntryPrompt(prompt)) return 'entry10';
  return '';
}

export function isPoolEntryPrompt(prompt?: string): boolean {
  const parsed = parseP1StepPrompt(prompt || '');
  return parsed.kind === 'step';
}

export function parseP1Invocation(value: string): P1ParsedInvocation {
  let raw = String(value || '');
  for (const prefix of AGENT_PREFIXES) raw = raw.replace(prefix, ' ');
  const candidateMatch = CANDIDATE_RE.exec(raw);
  const hasCandidate = !!candidateMatch;
  const candidateRel = candidateMatch?.[2] || '';
  const tokens = raw
    .replace(new RegExp(CANDIDATE_RE.source, 'gi'), ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .filter(Boolean);
  const module = tokens[0] || '';
  const candidate = hasCandidate && module ? resolveCandidateFolder(module, candidateRel) : '';
  return { module, candidate, hasCandidate };
}

export function p1InvocationRefusal(invocation: P1ParsedInvocation): string {
  if (!invocation.module) return 'Pass @@agentPlannerL1 <lowerCamel>.';
  if (!moduleTokenOk(invocation.module)) return 'Module name must be lowerCamel (example: stockControl).';
  if (invocation.hasCandidate && !invocation.candidate) return CANDIDATE_DOTDOT;
  return '';
}

export type P1StepPrompt =
  | { kind: 'step'; moduleName: string; thread: string; file: string; candidate: string }
  | { kind: 'entry'; moduleName: string; candidate: string }
  | { kind: 'refusal'; refusal: string };

export function parseP1StepPrompt(prompt: string): P1StepPrompt {
  let parsed: unknown;
  try {
    parsed = JSON.parse(String(prompt || '{}'));
  } catch {
    return { kind: 'refusal', refusal: 'step prompt must be JSON.' };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { kind: 'refusal', refusal: 'step prompt must be a JSON object.' };
  }
  const raw = parsed as Record<string, unknown>;
  const moduleName = typeof raw.moduleName === 'string' ? raw.moduleName.trim() : '';
  const thread = typeof raw.thread === 'string' ? raw.thread.trim() : '';
  const file = typeof raw.file === 'string' ? raw.file.trim() : '';
  const candidate = typeof raw.candidate === 'string' ? raw.candidate.trim() : '';
  if (candidate.includes('..')) return { kind: 'refusal', refusal: CANDIDATE_DOTDOT };
  if (moduleName && thread && file) return { kind: 'step', moduleName, thread, file, candidate };
  if (moduleName) return { kind: 'entry', moduleName, candidate };
  return { kind: 'refusal', refusal: 'step prompt needs moduleName.' };
}

/**
 * `l4/<module>/pool/l1/pipeline.json` — the planner trace lives in its own box (27/09:
 * planning only writes the pool). Not a pool message: `listPoolBox` ignores the name.
 */
export function p1PipelineFile(moduleName: string): Ns5FileInfo {
  const base = moduleFile(moduleName);
  return {
    project: base.project,
    level: 4,
    folder: `${base.folder}/pool/l1`,
    shortName: 'pipeline',
    extension: '.json',
  };
}

/** `l4/<module>/pool/l1/web/needs.json` — written by L2, read here. */
export function p1NeedsFile(moduleName: string, device: P1Device = P1_DEVICE): Ns5FileInfo {
  const base = moduleFile(moduleName);
  return {
    project: base.project,
    level: 4,
    folder: `${base.folder}/pool/l1/${device}`,
    shortName: 'needs',
    extension: '.json',
  };
}

/** `l4/<module>/pool/l1/web/l4diff.json` — written by L4 (p4_09). Absent is valid. */
export function p1L4DiffFile(moduleName: string, device: P1Device = P1_DEVICE): Ns5FileInfo {
  const base = moduleFile(moduleName);
  return {
    project: base.project,
    level: 4,
    folder: `${base.folder}/pool/l1/${device}`,
    shortName: 'l4diff',
    extension: '.json',
  };
}

/** `l4/<module>/pool/l2/web/backend.json` — written by plan20. Not a pool message. */
export function p1BackendFile(moduleName: string, device: P1Device = P1_DEVICE): Ns5FileInfo {
  const base = moduleFile(moduleName);
  return {
    project: base.project,
    level: 4,
    folder: `${base.folder}/pool/l2/${device}`,
    shortName: 'backend',
    extension: '.json',
  };
}

export function createP1Pipeline(
  moduleName: string,
  message: PoolMessage,
  messageFile: string,
  now: Date,
  sourceMessages: string[],
  needsFile: string,
  inventory: L1Inventory,
): P1PipelineState {
  const updatedAt = now.toISOString();
  return {
    schemaVersion: P1_PIPELINE_SCHEMA_VERSION,
    flowId: P1_FLOW_ID,
    moduleName,
    status: 'inProgress',
    steps: {
      entry10: {
        status: 'approved',
        updatedAt,
        artifactPaths: [`l4/${moduleFolder(moduleName)}/pool/l1/pipeline.json`],
      },
    },
    thread: message.thread,
    round: message.round,
    messageFile,
    sourceMessages,
    needsFile,
    inventory,
    updatedAt,
  };
}

export function createP1AgentStep(
  stepId: P1StepId,
  moduleName: string,
  entry: { thread: string; file: string; candidate?: string },
): mls.msg.AIAgentStep {
  const dependsOn = [...P1_STEP_DEPENDS_ON[stepId]];
  const prompt: Record<string, string> = { planId: stepId, moduleName, thread: entry.thread, file: entry.file };
  if (entry.candidate) prompt.candidate = entry.candidate;
  return {
    type: 'agent',
    stepId: 0,
    interaction: null,
    stepTitle: P1_STEP_TITLES[stepId],
    status: dependsOn.length ? 'waiting_dependency' : 'waiting_human_input',
    nextSteps: [],
    agentName: P1_AGENT_NAME,
    prompt: JSON.stringify(prompt),
    rags: [],
    planning: {
      planId: stepId,
      dependsOn,
      executionMode: 'sequential',
      executionHost: 'client',
    },
  };
}

export function buildP1PlannedSteps(
  moduleName: string,
  entry: { thread: string; file: string; candidate?: string },
): mls.msg.AIAgentStep[] {
  return P1_FLOW_STEP_IDS.map(stepId => createP1AgentStep(stepId, moduleName, entry));
}

export function isP1PoolMessageFile(shortName: string): boolean {
  return POOL_MESSAGE_SHORT.test(shortName);
}

function poolMessageFileName(file: Ns5FileInfo): string {
  return `${file.shortName}${file.extension}`;
}

function requestKey(moduleName: string, message: PoolMessage): string {
  const threadModule = message.thread.replace(/-\d{14}$/, '') || moduleName;
  const artifacts = [...message.artifacts].map(item => item.trim()).filter(Boolean).sort().join('\0');
  return `${threadModule}\0${message.mode}\0${artifacts}`;
}

export const P1_ONLY_IMPLEMENT = 'pool/l1 has no estimate message; implement belongs to agentDefsL1, not to the planner';

export function p1DifferentRequestsRefusal(count: number): string {
  return `pool/l1 has ${count} different requests; resolve with the l2 planner`;
}

function matchPoolFile(file: Ns5FileInfo, wanted: string): boolean {
  const path = displayPath(file);
  return path === wanted || file.shortName === wanted || `${file.shortName}${file.extension}` === wanted;
}

function isNeedsArtifact(path: string): boolean {
  const trimmed = path.trim();
  return trimmed === 'pool/l1/web/needs.json' || /(^|\/)needs\.json$/.test(trimmed);
}

function isL2NeedsMessage(message: PoolMessage): boolean {
  return message.from === 'l2' && message.to === 'l1' && message.artifacts.some(isNeedsArtifact);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

async function loadNeeds(moduleName: string, message: PoolMessage): Promise<{ needsFile: Ns5FileInfo; needs: P1Needs } | { refusal: string }> {
  if (!message.artifacts.some(isNeedsArtifact)) return { refusal: 'needs.json is missing' };
  const needsFile = p1NeedsFile(moduleName);
  const raw = await readJson<unknown>(needsFile);
  if (raw === null) return { refusal: 'needs.json is missing' };
  if (!isRecord(raw)) return { refusal: 'needs.json schema is unknown' };
  if (raw.schemaVersion !== P1_NEEDS_SCHEMA) return { refusal: 'needs.json schema is unknown' };
  return {
    needsFile,
    needs: {
      schemaVersion: String(raw.schemaVersion),
      moduleName: typeof raw.moduleName === 'string' ? raw.moduleName : '',
      device: typeof raw.device === 'string' ? raw.device : undefined,
      pages: Array.isArray(raw.pages) ? raw.pages : [],
    },
  };
}

export async function loadP1Entry(source: P1EntrySource): Promise<P1LoadResult> {
  const moduleName = normalizeModuleName(source.moduleName, '');
  if (!moduleName || !moduleTokenOk(moduleName)) {
    return { refusal: 'Module name must be lowerCamel (example: stockControl).' };
  }

  const rootRefusal = applyP1CandidateRoot(moduleName, source.candidate || '');
  if (rootRefusal) return { refusal: rootRefusal };

  const l4 = await readPipeline(moduleName);
  if (!l4 || l4.status !== 'complete') {
    return { refusal: `Module "${moduleName}" has no complete l4.` };
  }

  const resumed = await resumeP1Consumption(moduleName);
  const box = listPoolBox(moduleName, 'l1')
    .filter(file => isP1PoolMessageFile(file.shortName))
    .filter(file => !resumed.includes(displayPath(file)));
  if (!box.length) return { refusal: `nothing pending for ${moduleName} in pool/l1` };

  const loaded: Array<{ file: Ns5FileInfo; message: PoolMessage }> = [];
  for (const file of box) {
    loaded.push({ file, message: await readPoolMessage(file) });
  }

  // The planner only estimates. `implement` belongs to agentDefsL1 and stays in the box.
  const estimates = loaded.filter(entry => entry.message.mode === 'estimate');
  if (!estimates.length) return { refusal: P1_ONLY_IMPLEMENT };

  const needsRequests = estimates.filter(entry => isL2NeedsMessage(entry.message));
  if (!needsRequests.length) return { refusal: 'needs.json is missing' };

  const groups = new Map<string, typeof needsRequests>();
  for (const entry of needsRequests) {
    const key = requestKey(moduleName, entry.message);
    const group = groups.get(key) || [];
    group.push(entry);
    groups.set(key, group);
  }
  if (groups.size > 1) return { refusal: p1DifferentRequestsRefusal(groups.size) };

  const group = needsRequests;
  const oldest = group[0];
  const sourceMessages = group.map(entry => poolMessageFileName(entry.file));

  if (source.kind === 'step') {
    const specified = group.find(entry => matchPoolFile(entry.file, source.file));
    if (!specified) {
      const other = loaded.find(entry => matchPoolFile(entry.file, source.file));
      if (other && other.message.mode !== 'estimate') return { refusal: P1_ONLY_IMPLEMENT };
      return { refusal: `pool/l1 message not found: ${source.file}` };
    }
    if (specified.message.thread !== source.thread) {
      return { refusal: `message thread does not match '${source.thread}'.` };
    }
  }

  const needs = await loadNeeds(moduleName, oldest.message);
  if ('refusal' in needs) return needs;

  return {
    moduleName,
    file: oldest.file,
    message: oldest.message,
    sourceMessages,
    needsFile: needs.needsFile,
    needs: needs.needs,
  };
}

export async function writeP1Entry(loaded: P1LoadedEntry, now: Date): Promise<P1PipelineState> {
  await clearP1Draft(loaded.moduleName);
  const messageFile = displayPath(loaded.file);
  const inventory = await readL1Inventory(moduleFile(loaded.moduleName).project, loaded.moduleName);
  const pipeline = createP1Pipeline(
    loaded.moduleName,
    loaded.message,
    messageFile,
    now,
    loaded.sourceMessages,
    displayPath(loaded.needsFile),
    inventory,
  );
  await writeJson(p1PipelineFile(loaded.moduleName), pipeline);
  return pipeline;
}

/** The previous run's draft is this box's scratch, not l1: drop it so it cannot leak into the prompt. */
async function clearP1Draft(moduleName: string): Promise<void> {
  const draft = p1DraftFile(moduleName, 'plan20');
  const indexed = (mls.stor.files as Record<string, mls.stor.IFileInfo | undefined>)[mls.stor.getKeyToFile(draft)];
  if (!indexed || indexed.status === 'deleted') return;
  const { deleteFile } = await import('/_102027_/l2/libStor.js');
  await deleteFile(diskFileInfo(draft));
}

/**
 * Consume the messages this run read at entry (`sourceMessages`), never a fresh listing:
 * a message that arrived during the run stays. Trace first, then delete — a failure before
 * the trace keeps the message. `messageFile` is `processed`; the others are duplicates
 * listed in `supersededMessages`. Returns the display paths deleted.
 */
export async function consumeP1Messages(moduleName: string, now: Date): Promise<string[]> {
  const pipelineInfo = p1PipelineFile(moduleName);
  const pipeline = await readJson<P1PipelineState>(pipelineInfo);
  if (!pipeline || pipeline.steps?.plan20?.status !== 'approved') return [];
  const wanted = new Set(pipeline.sourceMessages || []);
  const box = listPoolBox(moduleName, 'l1').filter(file => wanted.has(poolMessageFileName(file)));
  if (!box.length) return [];
  const superseded = box.map(file => displayPath(file)).filter(path => path !== pipeline.messageFile);
  if (superseded.length) {
    const known = new Set(pipeline.supersededMessages || []);
    if (superseded.some(path => !known.has(path))) {
      await writeJson(pipelineInfo, {
        ...pipeline,
        supersededMessages: [...new Set([...(pipeline.supersededMessages || []), ...superseded])],
      });
    }
  }
  const traced = new Set((await readPoolTraceAt(pipelineInfo))
    .filter(line => line.outcome === 'processed')
    .map(line => line.file));
  const deleted: string[] = [];
  for (const file of box) {
    const path = displayPath(file);
    let traceId = path;
    if (!traced.has(path)) {
      const message = await readPoolMessage(file);
      traceId = await tracePoolAt(pipelineInfo, {
        at: now.toISOString(),
        file: path,
        from: message.from,
        to: message.to,
        thread: message.thread,
        round: message.round,
        mode: message.mode,
        outcome: 'processed',
      });
    }
    deleted.push(await deletePoolMessageAt(pipelineInfo, file, traceId));
  }
  return deleted;
}

/**
 * Resume: a previous run approved plan20 but stopped before deleting what it consumed.
 * Finish the deletion instead of planning again (a second l1→l2 message would be a duplicate).
 */
async function resumeP1Consumption(moduleName: string): Promise<string[]> {
  return consumeP1Messages(moduleName, new Date());
}

export async function executeP1Entry(source: P1EntrySource, now: Date): Promise<P1ExecuteResult> {
  const loaded = await loadP1Entry(source);
  if ('refusal' in loaded) return loaded;
  const pipeline = await writeP1Entry(loaded, now);
  return { pipeline, file: loaded.file, message: loaded.message };
}

export async function readP1Pipeline(moduleName: string): Promise<P1PipelineState | null> {
  return readJson<P1PipelineState>(p1PipelineFile(moduleName));
}

/** `l4/<module>/pool/l1/<stepId>-draft.json` — scratch of this box, not a pool message. */
export function p1DraftFile(moduleName: string, stepId: P1StepId): Ns5FileInfo {
  const base = moduleFile(moduleName);
  return {
    project: base.project,
    level: 4,
    folder: `${base.folder}/pool/l1`,
    shortName: `${stepId}-draft`,
    extension: '.json',
  };
}

/** Files of this agent (prompt.md, skills) live in 102021, not in the run module. */
export function p1AgentFile(folder: string, shortName: string, extension: string): Ns5FileInfo {
  return {
    project: 102021,
    level: 2,
    folder: folder ? `agentPlannerL1/${folder}` : 'agentPlannerL1',
    shortName,
    extension,
  };
}

export async function readP1AgentText(folder: string, shortName: string, extension: string): Promise<string> {
  const fileInfo = p1AgentFile(folder, shortName, extension);
  const file = mls.stor.files[mls.stor.getKeyToFile(fileInfo)] as {
    status?: string;
    getValueInfo?: () => Promise<{ content?: unknown }>;
    getContent: () => Promise<unknown>;
  } | undefined;
  if (!file || file.status === 'deleted') {
    throw new Error(`agentPlannerL1 file not found: ${displayPath(fileInfo)}`);
  }
  if (file.getValueInfo) {
    try {
      const local = await file.getValueInfo();
      if (typeof local?.content === 'string') return local.content;
    } catch { /* fall through */ }
  }
  const content = await file.getContent();
  if (typeof content === 'string') return content;
  throw new Error(`agentPlannerL1 invalid text file: ${displayPath(fileInfo)}`);
}

/** `complete` = every step of `flow.json` is approved. A failed pipeline stays failed. */
export function markP1Complete(pipeline: P1PipelineState, now = new Date().toISOString()): P1PipelineState {
  if (pipeline.status === 'failed') return pipeline;
  for (const stepId of P1_FLOW_STEP_IDS) {
    if (pipeline.steps[stepId]?.status !== 'approved') return pipeline;
  }
  return {
    ...pipeline,
    status: 'complete',
    awaitingStep: undefined,
    updatedAt: now,
  };
}

export function markP1Step(
  pipeline: P1PipelineState,
  stepId: P1StepId,
  next: Ns5PipelineStepState,
): P1PipelineState {
  const current = pipeline.steps[stepId];
  if (current?.status === 'approved') {
    return { ...pipeline, updatedAt: next.updatedAt };
  }
  const failed = next.status === 'failed';
  const approved = next.status === 'approved';
  return {
    ...pipeline,
    steps: { ...pipeline.steps, [stepId]: next },
    updatedAt: next.updatedAt,
    ...(failed ? { status: 'failed' as const, awaitingStep: undefined } : {}),
    ...(approved && pipeline.awaitingStep === stepId
      ? { status: 'inProgress' as const, awaitingStep: undefined }
      : {}),
  };
}

export function createP1RetryStep(
  stepId: P1StepId,
  moduleName: string,
  kind: 'repair' | 'transport',
  attempt: number,
  extra: Record<string, unknown> = {},
): mls.msg.AIAgentStep {
  const planId = `${stepId}-${kind}-${attempt}`;
  const suffix = kind === 'repair' ? `R${attempt}` : `T${attempt}`;
  return {
    type: 'agent',
    stepId: 0,
    interaction: null,
    stepTitle: `${P1_STEP_TITLES[stepId]} · ${suffix}`,
    status: 'waiting_human_input',
    nextSteps: [],
    agentName: P1_AGENT_NAME,
    prompt: JSON.stringify({ planId: stepId, moduleName, [`${kind}Attempt`]: attempt, ...extra }),
    rags: [],
    planning: {
      planId,
      dependsOn: [],
      executionMode: 'sequential',
      executionHost: 'client',
    },
  };
}
