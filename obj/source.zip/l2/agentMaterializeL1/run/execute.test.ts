/// <mls fileReference="_102021_/l2/agentMaterializeL1/run/execute.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

import { M1_DEFINITION_SCHEMA, M1_RECEIPT_SCHEMA, outputPathFromDefPath, parseDefinitionSource, receiptPathFor, renderDefinition, semanticHash, type M1Definition } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { contentHash } from '/_102021_/l2/agentMaterializeL1/core/io.js';
import type { MaterializeOwnedRemoval, MaterializeStateStore } from '/_102021_/l2/agentMaterializeL1/core/state.js';
import type { MaterializationReceipt } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { handlerFor } from '/_102021_/l2/agentMaterializeL1/core/registry.js';
import type { PlanUnitInput } from '/_102021_/l2/agentMaterializeL1/planner/plan.js';
import { M1_CATALOG_SCHEMA, M1_STUB_ERROR, M1_STUB_STATUS, parseCatalog, renderMonitorCatalog, renderScenarioTest, testFileFor, type M1ScenarioCatalog } from '/_102021_/l2/agentMaterializeL1/testing/catalog.js';
import { catalogBytes, deriveCatalog, M1_CATALOG_RECIPE } from '/_102021_/l2/agentMaterializeL1/testing/derive.js';
import { fixtureLogicalRel } from '/_102021_/l2/helpers/l1Fixtures/fixtureDisk.js';
import type { M1Observation } from '/_102021_/l2/agentMaterializeL1/testing/verify.js';
import { BASE, derive, fixture } from '/_102021_/l2/agentMaterializeL1/testing/oracleModule.js';
import {
  M1_CEILING,
  MaterializeCallError,
  decideProfile,
  emptyLedger,
  encodeLedger,
  ledgerPath,
  noteModelCall,
  parseLedger,
  tightenBudget,
} from '/_102021_/l2/agentMaterializeL1/run/budget.js';
import { helpText, parseStudioPrompt, unitsForFlow } from '/_102021_/l2/agentMaterializeL1/run/command.js';
import {
  runMaterialize,
  type HandlerOutcome,
  type MaterializeHandlerRunner,
  type MaterializeRunHost,
  type MaterializeRunRequest,
} from '/_102021_/l2/agentMaterializeL1/run/execute.js';
import { invokeModel, shouldCallModel } from '/_102021_/l2/agentMaterializeL1/run/model.js';
import { M1_OWNED_SCHEMA, ownedManifestRef, recipeForStage, renderOwnedManifest, writerRef } from '/_102021_/l2/agentMaterializeL1/state/maintain.js';

const MODULE = 'deskLedger';
const PROJECT = 102047;
const HERE = dirname(fileURLToPath(import.meta.url));

void test('studio parses the command and simulate does not call a model or write', async () => {
  const studio = parseStudioPrompt('@@agentMaterializeL1 deskLedger /simulate flow:Note', 102047);
  assert.equal(studio.refusal, '');
  assert.equal(studio.project, 102047);
  assert.equal(studio.moduleName, 'deskLedger');
  assert.equal(studio.stage, 'simulate');
  assert.equal(studio.flow, 'Note');
  assert.equal(studio.resume, false);

  const note = entity('Note');
  const task = entity('Task');
  const left = world();
  const right = world();
  const llm = () => Promise.reject(new Error('model must not be called'));
  const request = baseRequest([note, task], { flow: 'Note', stage: 'simulate' });
  const [a, b] = await Promise.all([
    runMaterialize(request, host(left, {}, llm)),
    runMaterialize(request, host(right, {}, llm)),
  ]);
  assert.equal(a.ended, 'SIMULATED');
  assert.equal(a.llmCalls, 0);
  assert.equal(a.wrote, false);
  assert.equal(a.snapshot?.wrote, false);
  assert.deepEqual(a.snapshot, b.snapshot);
  assert.deepEqual(a.units.map(unit => unit.code), b.units.map(unit => unit.code));
  assert.equal(a.units.length, 1);
  assert.equal(left.writes.length, 0);
  assert.equal(right.writes.length, 0);
});

void test('a tighter budget wins and a higher request is cut at the ceiling', () => {
  const raised = tightenBudget({ maxWorkers: 8, callsPerRun: 100, timeoutMs: 999_999, repairsPerRun: 9 }, null);
  assert.equal(raised.maxWorkers, M1_CEILING.maxWorkers);
  assert.equal(raised.callsPerRun, M1_CEILING.callsPerRun);
  assert.equal(raised.timeoutMs, M1_CEILING.timeoutMs);
  assert.equal(raised.repairsPerRun, M1_CEILING.repairsPerRun);
  const tighter = tightenBudget({ maxWorkers: 1, callsPerRun: 3 }, { timeoutMs: 50, repairsPerArtifact: 1 });
  assert.equal(tighter.maxWorkers, 1);
  assert.equal(tighter.callsPerRun, 3);
  assert.equal(tighter.timeoutMs, 50);
  const ledger = emptyLedger(PROJECT, MODULE, tighter);
  for (let index = 0; index < 3; index += 1) assert.equal(noteModelCall(ledger, tighter), true);
  assert.equal(noteModelCall(ledger, tighter), false);
  assert.equal(ledger.callsExhausted, true);
});

void test('profile names the test database and never falls back, production does not run a stub', async () => {
  assert.equal(decideProfile(undefined, false).mode, 'presentation');
  assert.equal(decideProfile(undefined, false).databaseEnv, 'DATABASE_URL_TEST');
  assert.equal(decideProfile('development', true).databaseEnv, 'DATABASE_URL_TEST');
  assert.equal(decideProfile('production', true).databaseEnv, 'DATABASE_URL');
  assert.equal(decideProfile('production', true).allowsStubRun, false);
  assert.equal(decideProfile('development', true).allowsSeeds, true);
  const store = world();
  const note = entity('Note');
  const output = outputPathFromDefPath(note.defPath);
  const result = await runMaterialize(baseRequest([note], { profileMode: 'production', profileDeclared: true }), host(store, {
    'structure.domainEntity': async () => passOutcome(output, { runsStub: true }),
  }, undefined, catalog([note], 'pass')));
  assert.equal(result.units[0].code, 'PROFILE_REFUSED');
  assert.equal(result.units[0].promoted, false);
  assert.equal(store.map.has(output), false);
  assert.equal(result.profile.databaseEnv, 'DATABASE_URL');
});

void test('structure calls only its handler and implement does not fall back to a generic file', async () => {
  const store = world();
  const note = entity('Note');
  const output = outputPathFromDefPath(note.defPath);
  let structureCalls = 0;
  let implementCalls = 0;
  const runners: Record<string, MaterializeHandlerRunner> = {
    'structure.domainEntity': async () => {
      structureCalls += 1;
      return passOutcome(output);
    },
    'implement.domainEntity': async () => {
      implementCalls += 1;
      return passOutcome(output);
    },
  };
  const structure = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(store, runners, undefined, catalog([note], 'pass')));
  assert.equal(structure.units[0].code, 'PROMOTED');
  assert.equal(structureCalls, 1);
  assert.equal(implementCalls, 0);
  assert.equal(store.map.get(output), 'export const note = 1;\n');

  const bare = world();
  const missing = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(bare, {}));
  assert.equal(missing.units[0].code, 'HANDLER_UNBOUND');
  assert.match(missing.units[0].detail, /structure\.domainEntity/);
  assert.equal(bare.map.has(output), false);

  const implementStore = world();
  const implement = await runMaterialize(baseRequest([note], { stage: 'implement' }), host(implementStore, runners));
  assert.equal(implement.units[0].code, 'REPEATED_FAILURE');
  assert.equal(implementCalls, 2);
  assert.equal(implement.units[0].promoted, false);
  assert.equal(implementStore.map.has(output), false);
  assert.match(implement.units[0].detail, /catalog/);
});

void test('the run report hashes every source the authenticated oracle read, apart from the catalog hash (m1_28)', async () => {
  const fx = fixture(BASE);
  // The MDM targets the neutral module references, so the planner resolves every ref.
  const mdm = [fx.n.Anchor, fx.n.Mdm].map(entityId => {
    const defPath = `${fx.n.project}/l1/${fx.n.mod}/layer_3_domain/entities/${entityId.charAt(0).toLowerCase()}${entityId.slice(1)}.defs.ts`;
    const definition = {
      schemaVersion: M1_DEFINITION_SCHEMA, artifactType: 'domainEntity', artifactId: entityId, moduleName: fx.n.mod, status: 'pending', dependencies: [],
      data: { entityId, storageTarget: 'mdm', fields: [{ name: 'id', type: 'uuid', derived: true }], lifecycle: { states: [], transitions: [] }, invariants: [], imports: [] },
    } as M1Definition;
    return { defPath, definition };
  });
  const units: PlanUnitInput[] = [...fx.defs.map(([, defPath, definition]) => ({ defPath, definition })), ...fx.controllers.map(([defPath, definition]) => ({ defPath, definition })), ...mdm];
  const base = join(HERE, '../../../..');
  const texts: Record<string, string> = { ...fx.texts };
  for (const unit of mdm) {
    const rendered = renderDefinition(unit.definition, unit.defPath);
    assert.equal('source' in rendered, true, JSON.stringify(rendered));
    if ('source' in rendered) texts[unit.defPath] = rendered.source;
  }
  const io = {
    async read(ref: string) {
      // Platform files come from their own project on disk; module files from the fixture.
      const match = /^_(102034)_\/(.*)$/.exec(ref);
      if (!texts[ref] && match) {
        const full = join(base, `mls-${match[1]}`, match[2]);
        if (existsSync(full)) texts[ref] = readFileSync(full, 'utf8');
      }
      return texts[ref] ?? null;
    },
  };
  const catalogRef = `${fx.n.project}/l1/${fx.n.mod}/materialization/agentMaterializeL1/scenarioCatalog.ts`;
  const request = baseRequest(units, { stage: 'simulate', moduleName: fx.n.mod, project: Number(fx.n.project.replace(/_/g, '')) });
  // Simulate calls no runner; binding one per unit keeps the units out of the withheld set.
  const bound: Record<string, MaterializeHandlerRunner> = Object.fromEntries(units.map(unit => [
    handlerFor((unit.definition as M1Definition).artifactType, 'structure')?.id ?? '',
    () => Promise.reject(new Error('simulate must not run a handler')),
  ]));
  const first = await runMaterialize(request, { ...host(world(texts), bound), io, catalogRef });
  const oracle = first.catalog?.oracleSources ?? {};
  const refs = [...new Set(derive(fx).obligations.flatMap(item => item.sources.map(source => source.split('#')[0] ?? source)))].sort();
  assert.equal(refs.length > 0, true);
  assert.deepEqual(Object.keys(oracle), refs, JSON.stringify(first.units.map(unit => `${unit.code} ${unit.detail}`)));
  assert.deepEqual(Object.entries(oracle).filter(([, hash]) => !hash.startsWith('sha256:')), []);
  // A changed contract moves its hash and not the catalog input hash.
  texts[fx.refs.contractA] = `${texts[fx.refs.contractA]}\n// edited\n`;
  const second = await runMaterialize(request, { ...host(world(texts), bound), io, catalogRef });
  assert.equal(second.catalog?.inputHash, first.catalog?.inputHash);
  assert.notEqual(second.catalog?.oracleSources[fx.refs.contractA], oracle[fx.refs.contractA]);
  assert.equal(second.catalog?.oracleSources[fx.refs.scope], oracle[fx.refs.scope]);
});

void test('implement does not emit a test for a unit with no output (v2 seed, authorityMap without its consumers)', async () => {
  // m1_41 b2: the v2 controleEstoque seed (read only) under this module id. Its controllers are the only
  // dependents of the authorityMap; without them the planner names NO_CONSUMER.
  const loaded = loadSeed();
  const consumers = loaded.units.filter(unit => (unit.definition as { artifactType?: string }).artifactType === 'httpController');
  assert.equal(consumers.length > 0, true);
  const run = async (units: readonly PlanUnitInput[]) => {
    const store = world(loaded.texts);
    const catalogRef = `_${PROJECT}_/l1/${MODULE}/materialization/agentMaterializeL1/scenarioCatalog.ts`;
    const result = await runMaterialize(baseRequest(units, {
      stage: 'implement',
      budget: { timeoutMs: 2000, repairsPerRun: 0, callsPerRun: 0 },
    }), {
      ...host(store, {}, () => Promise.reject(new Error('model must not be called'))),
      catalogRef,
    });
    return { result, store, written: store.map.get(catalogRef) ?? '' };
  };
  const noConsumer = (result: Awaited<ReturnType<typeof run>>['result']) => result.catalog?.gaps.some(gap => gap.artifactId === 'authorityMap' && gap.reason.startsWith('NO_CONSUMER:'));
  const control = await run(loaded.units);
  assert.equal(noConsumer(control.result), false);

  const { result, store, written } = await run(loaded.units.filter(unit => !consumers.includes(unit)));
  assert.equal(noConsumer(result), true);
  assert.equal([...store.map.keys()].some(path => path.endsWith('/authorityMap.test.ts')), false);
  assert.equal(written.includes('authorityMap'), false);
});

void test('timeout, network, transient and invalid response end the unit without a generic file', async () => {
  const note = entity('Note');
  const other = entity('Task');
  const output = outputPathFromDefPath(note.defPath);

  const timed = world();
  const timeout = await runMaterialize(baseRequest([note], { budget: { timeoutMs: 30, repairsPerRun: 1 } }), host(timed, {
    'structure.domainEntity': (call) => new Promise((_resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('hung')), 1000);
      call.signal.addEventListener('abort', () => {
        clearTimeout(timer);
        reject(new MaterializeCallError('TIMEOUT', 'aborted'));
      });
    }),
  }));
  assert.equal(timeout.units[0].code, 'REPEATED_FAILURE');
  assert.equal(timed.map.has(output), false);

  const calls: string[] = [];
  const offline = world();
  const network = await runMaterialize(baseRequest([note, other]), host(offline, {
    'structure.domainEntity': async (call) => {
      calls.push(call.unit.artifactId);
      if (call.unit.artifactId === 'Note') throw new MaterializeCallError('NETWORK_UNAVAILABLE', 'offline');
      return passOutcome(outputPathFromDefPath(other.defPath));
    },
  }, undefined, catalog([other], 'pass')));
  assert.equal(network.units.find(unit => unit.defPath === note.defPath)?.code, 'NETWORK_UNAVAILABLE');
  assert.equal(calls.filter(id => id === 'Note').length, 1);
  assert.equal(calls.includes('Task'), true);
  assert.equal(offline.map.has(output), false);

  let transientCalls = 0;
  const healed = world();
  const transient = await runMaterialize(baseRequest([note]), host(healed, {
    'structure.domainEntity': async (call) => {
      transientCalls += 1;
      if (!call.repair) throw new MaterializeCallError('TRANSIENT', 'again');
      return passOutcome(output);
    },
  }, undefined, catalog([note], 'pass')));
  assert.equal(transient.units[0].code, 'PROMOTED');
  assert.equal(transientCalls, 2);

  const invalid = world();
  const rejected = await runMaterialize(baseRequest([note], { budget: { repairsPerRun: 1 } }), host(invalid, {
    'structure.domainEntity': async () => ({ ...emptyOutcome(), failure: { code: 'INVALID_RESPONSE', detail: 'not a file' } }),
  }));
  assert.equal(rejected.units[0].code, 'REPEATED_FAILURE');
  assert.equal(invalid.map.has(output), false);
});

void test('the same failure twice stops that unit and an independent unit still runs', async () => {
  const note = entity('Note');
  const task = entity('Task');
  const calls: string[] = [];
  const result = await runMaterialize(baseRequest([note, task], { budget: { repairsPerRun: 4 } }), host(world(), {
    'structure.domainEntity': async (call) => {
      calls.push(`${call.unit.artifactId}:${call.repair ? 'repair' : 'call'}`);
      if (call.unit.artifactId === 'Note') throw new MaterializeCallError('TRANSIENT', 'same');
      return passOutcome(outputPathFromDefPath(task.defPath));
    },
  }, undefined, catalog([task], 'pass')));
  const failed = result.units.find(unit => unit.defPath === note.defPath);
  assert.equal(failed?.code, 'REPEATED_FAILURE');
  assert.equal(calls.filter(item => item.startsWith('Note:')).length, 2);
  assert.equal(calls.some(item => item.startsWith('Task:')), true);
  assert.equal(result.ended, 'COMPLETED');
});

void test('a duplicate event does not count twice and resume keeps the ledger', async () => {
  const note = entity('Note');
  const task = entity('Task');
  const store = world();
  let calls = 0;
  const runners: Record<string, MaterializeHandlerRunner> = {
    'structure.domainEntity': async (call) => {
      calls += 1;
      if (call.unit.artifactId === 'Note') throw new MaterializeCallError('NETWORK_UNAVAILABLE', 'offline');
      return passOutcome(outputPathFromDefPath(task.defPath));
    },
  };
  const first = await runMaterialize(baseRequest([note], { eventId: 'event-1' }), host(store, runners));
  assert.equal(first.units[0].code, 'NETWORK_UNAVAILABLE');
  const again = await runMaterialize(baseRequest([note], { eventId: 'event-1' }), host(store, runners));
  assert.equal(again.ended, 'DUPLICATE_EVENT');
  assert.equal(calls, 1);
  assert.equal(again.wrote, false);

  const resumed = await runMaterialize(baseRequest([note, task], { resume: true, stage: null }), host(store, runners, undefined, catalog([task], 'pass')));
  assert.notEqual(resumed.ended, 'NOTHING_TO_RESUME');
  assert.equal(resumed.units.find(unit => unit.defPath === note.defPath)?.code, 'NETWORK_UNAVAILABLE');
  assert.equal(resumed.units.find(unit => unit.defPath === task.defPath)?.code, 'PROMOTED');
  assert.equal(calls, 2);
  assert.equal(resumed.ledger.calls, first.ledger.calls);

  const empty = await runMaterialize(baseRequest([note], { resume: true }), host(world(), runners));
  assert.equal(empty.ended, 'NOTHING_TO_RESUME');
  assert.equal(empty.wrote, false);
});

void test('interruption leaves the finished unit and resume continues the other', async () => {
  const note = entity('Note');
  const slot = value('Slot', note.defPath);
  const store = world();
  const noteSource = renderDefinition(note.definition, note.defPath);
  const slotSource = renderDefinition(slot.definition, slot.defPath);
  if (!('source' in noteSource) || !('source' in slotSource)) throw new Error('def seed failed');
  store.map.set(note.defPath, noteSource.source);
  store.map.set(slot.defPath, slotSource.source);
  const controller = new AbortController();
  const calls: string[] = [];
  const runners: Record<string, MaterializeHandlerRunner> = {
    'structure.domainEntity': async () => {
      calls.push('Note');
      controller.abort();
      return passOutcome(outputPathFromDefPath(note.defPath));
    },
    'structure.valueObject': async () => {
      calls.push('Slot');
      return passOutcome(outputPathFromDefPath(slot.defPath));
    },
  };
  const stopped = await runMaterialize(
    { ...baseRequest([note, slot], { stage: 'structure' }), signal: controller.signal },
    host(store, runners, undefined, catalog([note, slot], 'pass')),
  );
  assert.equal(stopped.ended, 'INTERRUPTED');
  assert.deepEqual(calls, ['Note']);
  const continued = await runMaterialize(baseRequest([note, slot], { resume: true, stage: null }), host(store, runners, undefined, catalog([note, slot], 'pass')));
  assert.equal(continued.units.find(unit => unit.defPath === note.defPath)?.code, 'REUSE');
  assert.equal(continued.units.find(unit => unit.defPath === slot.defPath)?.code, 'PROMOTED', continued.units.map(unit => `${unit.code} ${unit.detail}`).join('\n'));
  assert.deepEqual(calls, ['Note', 'Slot']);
});

void test('a write outside the output and a changed snapshot are not promoted', async () => {
  const note = entity('Note');
  const output = outputPathFromDefPath(note.defPath);
  const outside = world();
  const refused = await runMaterialize(baseRequest([note]), host(outside, {
    'structure.domainEntity': async () => passOutcome(output, { extra: { '/tmp/other.ts': 'no' } }),
  }, undefined, catalog([note], 'pass')));
  assert.equal(refused.units[0].code, 'WRITE_OUTSIDE_TARGET');
  assert.equal(outside.map.has(output), false);
  assert.equal(outside.map.has('/tmp/other.ts'), false);

  const drifted = world({ [note.defPath]: 'export const before = 1;\n', [output]: 'OLD' });
  const kept = await runMaterialize(baseRequest([note]), host(drifted, {
    'structure.domainEntity': async () => {
      drifted.map.set(note.defPath, 'export const after = 2;\n');
      return passOutcome(output);
    },
  }, undefined, catalog([note], 'pass')));
  assert.equal(kept.units[0].code, 'SNAPSHOT_CHANGED');
  assert.equal(drifted.map.get(output), 'OLD');
});

void test('m1_34: a broken compile is not promoted and does not start its dependent', async () => {
  const note = entity('Note');
  const slot = value('Slot', note.defPath);
  const output = outputPathFromDefPath(note.defPath);
  const calls: string[] = [];
  const store = world();
  const failed = await runMaterialize(baseRequest([note, slot], { budget: { repairsPerRun: 1 } }), host(store, {
    'structure.domainEntity': async () => {
      calls.push('Note');
      return { ...passOutcome(output), observations: [{ ...observation('Note.check', true), broken: 'compile' }] };
    },
    'structure.valueObject': async () => {
      calls.push('Slot');
      return passOutcome(outputPathFromDefPath(slot.defPath));
    },
  }, undefined, catalog([note], 'pass')));
  assert.equal(failed.units.find(unit => unit.defPath === note.defPath)?.code, 'REPEATED_FAILURE');
  assert.equal(failed.units.find(unit => unit.defPath === slot.defPath)?.code, 'BLOCKED_BY');
  assert.deepEqual(calls, ['Note', 'Note']);
  assert.equal(store.map.has(output), false);
  assert.equal(failed.checkpoints.some(item => item.accepted), false);
});

void test('m1_34: a case the agent did not observe, or a predicted red, does not block generating', async () => {
  const note = entity('Note');
  const slot = value('Slot', note.defPath);
  const output = outputPathFromDefPath(note.defPath);
  for (const observations of [[], [observation('Note.check', false)]]) {
    const store = world();
    const result = await runMaterialize(baseRequest([note, slot]), host(store, {
      'structure.domainEntity': async () => ({ ...passOutcome(output), observations }),
      'structure.valueObject': async () => passOutcome(outputPathFromDefPath(slot.defPath)),
    }, undefined, catalog([note], 'pass')));
    assert.equal(result.units.find(unit => unit.defPath === note.defPath)?.code, 'PROMOTED');
    assert.equal(result.units.find(unit => unit.defPath === slot.defPath)?.code, 'PROMOTED');
    assert.equal(result.checkpoints.every(item => item.accepted && item.counts.inconclusive === 0), true);
    assert.equal(store.map.get(output)?.includes('export const note'), true);
  }
});

void test('m1_34: a def gap with an owner still holds the unit and its dependent', async () => {
  const note = entity('Note');
  const slot = value('Slot', note.defPath);
  const output = outputPathFromDefPath(note.defPath);
  const result = await runMaterialize(baseRequest([note, slot]), host(world(), {
    'structure.domainEntity': async () => ({ ...passOutcome(output), observations: [{ ...observation('Note.check', true), blocked: true, blockOwner: 'L4' }] }),
    'structure.valueObject': async () => passOutcome(outputPathFromDefPath(slot.defPath)),
  }, undefined, catalog([note], 'pass')));
  assert.equal(result.units.find(unit => unit.defPath === note.defPath)?.code, 'BLOCKED');
  assert.equal(result.units.find(unit => unit.defPath === slot.defPath)?.code, 'BLOCKED_BY');
});

void test('m1_34: verify of an intact output is VERIFIED without running a case', async () => {
  const note = entity('Note');
  const output = outputPathFromDefPath(note.defPath);
  const rendered = renderDefinition(note.definition, note.defPath);
  assert.ok('source' in rendered);
  const store = world({ [note.defPath]: rendered.source });
  const first = await runMaterialize(baseRequest([note]), host(store, {
    'structure.domainEntity': async () => passOutcome(output),
  }, undefined, catalog([note], 'pass')));
  assert.equal(first.units[0].code, 'PROMOTED');
  // A test-only change asks verify; the agent does not run it.
  store.map.set(testFileFor(output), `${store.map.get(testFileFor(output)) ?? ''}\n// changed\n`);
  const again = await runMaterialize(baseRequest([note], { stage: 'verify' }), host(store, {}, undefined, catalog([note], 'pass')));
  assert.equal(again.units[0].code, 'VERIFIED');
  assert.equal(again.checkpoints.length, 0);
});

void test('an expected red structural checkpoint can be stored and does not start implement', async () => {
  const note = entity('Note');
  const output = outputPathFromDefPath(note.defPath);
  let implementCalls = 0;
  const store = world();
  const result = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(store, {
    'structure.domainEntity': async () => passOutcome(output, { red: true }),
    'implement.domainEntity': async () => {
      implementCalls += 1;
      return emptyOutcome();
    },
  }, undefined, catalog([note], 'red')));
  assert.equal(result.stage, 'structure');
  assert.equal(result.units[0].code, 'PROMOTED');
  assert.equal(result.checkpoints[0].accepted, true);
  assert.equal(result.checkpoints[0].ready, false);
  assert.equal(implementCalls, 0);
  assert.equal(store.map.get(output)?.includes('export const note'), true);
});

void test('two workers run independent units and a request for more stays at two', async () => {
  const note = entity('Note');
  const task = entity('Task');
  let active = 0;
  let peak = 0;
  let release: (() => void) | null = null;
  const gate = new Promise<void>(resolve => { release = resolve; });
  const run = (limit: number) => {
    active = 0;
    peak = 0;
    return runMaterialize(baseRequest([note, task], { budget: { maxWorkers: limit } }), host(world(), {
      'structure.domainEntity': async (call) => {
        active += 1;
        peak = Math.max(peak, active);
        if (active === Math.min(limit, 2)) release?.();
        await gate;
        active -= 1;
        return passOutcome(outputPathFromDefPath(call.unit.defPath));
      },
    }, undefined, catalog([note, task], 'pass')));
  };
  const wide = await run(8);
  assert.equal(wide.budget.maxWorkers, 2);
  assert.equal(peak, 2);
  release = null;
  const narrowGate = new Promise<void>(resolve => { release = resolve; });
  active = 0;
  peak = 0;
  let entered = 0;
  const narrow = runMaterialize(baseRequest([note, task], { budget: { maxWorkers: 1 } }), host(world(), {
    'structure.domainEntity': async (call) => {
      entered += 1;
      active += 1;
      peak = Math.max(peak, active);
      if (entered === 1) {
        await narrowGate;
      } else {
        release?.();
      }
      active -= 1;
      return passOutcome(outputPathFromDefPath(call.unit.defPath));
    },
  }, undefined, catalog([note, task], 'pass')));
  await new Promise(resolve => setTimeout(resolve, 20));
  assert.equal(peak, 1);
  release?.();
  await narrow;
  assert.equal(peak, 1);
});

void test('verify does not generate and an unknown flow is a refusal', async () => {
  const note = entity('Note');
  const verified = await runMaterialize(baseRequest([note], { stage: 'verify' }), host(world(), {
    'structure.domainEntity': async () => {
      throw new Error('verify must not call a handler');
    },
  }));
  assert.equal(verified.units[0].code, 'NOT_READY');
  assert.equal(verified.llmCalls, 0);

  const missing = await runMaterialize(baseRequest([note], { flow: 'Missing' }), host(world(), {}));
  assert.equal(missing.ended, 'FLOW_NOT_FOUND');
  assert.equal(missing.wrote, false);
  assert.equal(missing.snapshot, null);

  const task = entity('Task');
  const linked = { ...note, definition: { ...note.definition, dependencies: [task.defPath] } };
  const selected = unitsForFlow([linked, task, entity('Other')], 'Note');
  assert.deepEqual(selected.map(unit => unit.definition.artifactId).sort(), ['Note', 'Task']);
});

void test('the model port is only for an implement handler that needs it', async () => {
  const structure = handlerFor('domainEntity', 'structure');
  assert.equal(shouldCallModel('simulate', structure), false);
  assert.equal(shouldCallModel('structure', structure), false);
  assert.equal(shouldCallModel('verify', structure), false);
  assert.equal(shouldCallModel('implement', structure), false);
  assert.equal(shouldCallModel('implement', structure ? { ...structure, stage: 'implement', needsLlm: true } : null), true);

  await assert.rejects(
    () => invokeModel(() => new Promise(() => undefined), { prompt: 'x', signal: new AbortController().signal, eventId: 'm' }, 20),
    (error: unknown) => error instanceof MaterializeCallError && error.code === 'TIMEOUT',
  );
  await assert.rejects(
    () => invokeModel(() => Promise.reject(new MaterializeCallError('NETWORK_UNAVAILABLE', 'offline')), {
      prompt: 'x', signal: new AbortController().signal, eventId: 'm',
    }, 1000),
    (error: unknown) => error instanceof MaterializeCallError && error.code === 'NETWORK_UNAVAILABLE',
  );
  await assert.rejects(
    () => invokeModel(() => Promise.resolve('   '), { prompt: 'x', signal: new AbortController().signal, eventId: 'm' }, 1000),
    (error: unknown) => error instanceof MaterializeCallError && error.code === 'INVALID_RESPONSE',
  );
});

void test('an old failure recipe works again and the same recipe keeps the budget', async () => {
  const note = entity('Note');
  const other = '_102047_/l1/deskLedger/layer_3_domain/entities/other.defs.ts';
  const rendered = renderDefinition(note.definition as M1Definition, note.defPath);
  assert.ok('source' in rendered);
  const store = world({ [note.defPath]: rendered.source });
  const output = outputPathFromDefPath(note.defPath);
  let calls = 0;
  const runners: Record<string, MaterializeHandlerRunner> = {
    'implement.domainEntity': async () => {
      calls += 1;
      return passOutcome(output);
    },
  };
  const hash = await semanticHash(note.definition as M1Definition);
  const current = recipeForStage('implement');
  const receipt: MaterializationReceipt = {
    schemaVersion: M1_RECEIPT_SCHEMA,
    runId: '102047:deskLedger',
    candidateId: '',
    defPath: note.defPath,
    artifactType: 'domainEntity',
    artifactId: 'Note',
    recipeVersion: current,
    semanticHash: hash,
    dependencyHashes: {},
    sourceHashes: { [note.defPath]: hash },
    outputHashes: {},
    stage: 'plan',
    verifications: [],
    failures: [{ code: 'LLM_UNAVAILABLE', detail: 'no model' }],
    attempts: 1,
    reason: 'LLM_UNAVAILABLE: no model',
  };
  const receiptPath = receiptPathFor(note.defPath);
  assert.ok(receiptPath);
  store.map.set(receiptPath, JSON.stringify(receipt));
  const budget = tightenBudget({ timeoutMs: 2000 }, null);
  const ledger = emptyLedger(PROJECT, MODULE, budget, 'implement');
  ledger.calls = 3;
  ledger.repairs = 2;
  ledger.units[note.defPath] = { repairs: 1, calls: 1, signature: 'LLM_UNAVAILABLE', ended: 'LLM_UNAVAILABLE', stage: 'implement' };
  ledger.units[other] = { repairs: 0, calls: 0, signature: '', ended: 'PROMOTED', stage: 'implement' };
  store.map.set(ledgerPath(MODULE), encodeLedger(ledger));

  const kept = await runMaterialize(baseRequest([note], { stage: 'implement', resume: true }), host(store, runners, undefined, catalog([note], 'pass')));
  assert.equal(kept.units[0].code, 'LLM_UNAVAILABLE');
  assert.match(kept.units[0].detail, /budget was not reset/);
  assert.equal(calls, 0);
  const keptLedger = parseLedger(store.map.get(ledgerPath(MODULE)) ?? '', PROJECT, MODULE);
  assert.ok(keptLedger);
  assert.equal(keptLedger.calls, 3);
  assert.equal(keptLedger.repairs, 2);
  assert.equal(keptLedger.units[other]?.ended, 'PROMOTED');

  receipt.recipeVersion = '2026-09-25-m1-recipe-v1';
  store.map.set(receiptPath, JSON.stringify(receipt));
  const again = await runMaterialize(baseRequest([note], { stage: 'implement', resume: true }), host(store, runners, undefined, catalog([note], 'pass')));
  assert.equal(calls, 1);
  assert.notEqual(again.units[0].code, 'LLM_UNAVAILABLE');
  const nextLedger = parseLedger(store.map.get(ledgerPath(MODULE)) ?? '', PROJECT, MODULE);
  assert.equal(nextLedger?.units[other]?.ended, 'PROMOTED');
  assert.ok((nextLedger?.calls ?? 0) >= 3);
  assert.ok((nextLedger?.repairs ?? 0) >= 2);
});

void test('a catalog that matches the M1 receipt is rewritten; a hand edit is a conflict', async () => {
  const note = entity('Note');
  const derived = deriveCatalog(MODULE, [note], {});
  assert.equal(derived.recipeVersion, M1_CATALOG_RECIPE);
  const owned = JSON.parse(catalogBytes(derived.catalog)) as M1ScenarioCatalog;
  owned.scenarios[0].cases[0].expectation = 'previous M1 output';
  const recorded = await contentHash(catalogBytes(owned));
  const ref = 'catalog.json';
  const store = world({ [ref]: renderMonitorCatalog(owned, ref) });
  const ledger = emptyLedger(PROJECT, MODULE, tightenBudget({ timeoutMs: 2000 }, null), 'structure');
  ledger.catalogInputHash = recorded;
  store.map.set(ledgerPath(MODULE), encodeLedger(ledger));
  const rewritten = await runMaterialize(baseRequest([note], { stage: 'simulate' }), host(store, {}, undefined, store.map.get(ref)));
  assert.equal(rewritten.catalog?.action, 'simulated');
  assert.equal(rewritten.catalog?.recipeVersion, M1_CATALOG_RECIPE);
  assert.equal(store.map.get(ref), renderMonitorCatalog(owned, ref));

  const writing = world({ [ref]: renderMonitorCatalog(owned, ref) });
  writing.map.set(ledgerPath(MODULE), encodeLedger(ledger));
  const wrote = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(writing, {
    'structure.domainEntity': async () => passOutcome(outputPathFromDefPath(note.defPath)),
  }, undefined, writing.map.get(ref)));
  assert.equal(wrote.catalog?.action, 'written');
  const next = parseCatalog(writing.map.get(ref) ?? '');
  assert.ok(next.catalog);
  assert.equal(catalogBytes(next.catalog), catalogBytes(derived.catalog));

  const hand = JSON.parse(catalogBytes(derived.catalog)) as M1ScenarioCatalog;
  hand.scenarios[0].cases[0].expectation = 'hand edit';
  const handText = renderMonitorCatalog(hand, ref);
  const conflicted = world({ [ref]: handText });
  const stale = emptyLedger(PROJECT, MODULE, tightenBudget({ timeoutMs: 2000 }, null), 'structure');
  stale.catalogInputHash = await contentHash(catalogBytes(derived.catalog));
  conflicted.map.set(ledgerPath(MODULE), encodeLedger(stale));
  conflicted.map.set(ownedManifestRef(MODULE), renderOwnedManifest({
    schemaVersion: M1_OWNED_SCHEMA,
    moduleName: MODULE,
    units: [],
    catalogRef: ref,
    catalogHash: await contentHash(catalogBytes(derived.catalog)),
  }));
  const conflict = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(conflicted, {}, undefined, handText));
  assert.equal(conflict.catalog?.action, 'conflict');
  assert.equal(conflicted.map.get(ref), handText);
});

void test('m1_32: a refused writer leaves the module untouched and names the file and its holder', async () => {
  const note = entity('Note');
  const store = world({ [writerRef(MODULE)]: '{"schemaVersion":"x","moduleName":"deskLedger","holder":"102047:deskLedger:other"}\n' });
  let calls = 0;
  const run = await runMaterialize(baseRequest([note], { stage: 'structure' }), {
    ...host(store, { 'structure.domainEntity': async () => { calls += 1; return passOutcome(outputPathFromDefPath(note.defPath)); } }),
    catalogRef: 'catalog.json',
    writer: { async claim() { return false; }, async release() { throw new Error('release after a refused claim'); } },
  });
  assert.equal(run.ended, 'WRITER_BUSY');
  assert.deepEqual(store.writes, [], 'nothing of the module is written before the claim');
  assert.equal(store.map.has('catalog.json'), false, 'the catalog is not written by a refused run');
  assert.equal(calls, 0);
  assert.equal(run.detail, `${writerRef(MODULE)} is held by 102047:deskLedger:other. If no run is active, remove ${writerRef(MODULE)} and run again.`);
});

void test('m1_32: a unit promoted once and blocked now keeps its scenarios; one never emitted is a gap', async () => {
  const note = entity('Note');
  (note.definition as M1Definition).status = 'blocked';
  const output = outputPathFromDefPath(note.defPath);
  const blockedReceipt = async (outputHashes: Record<string, string>): Promise<MaterializationReceipt> => ({
    ...await scaffoldReceipt(note, output, 'export {};\n'),
    outputHashes,
    stage: 'plan',
    failures: [{ code: 'BLOCKED', detail: 'Fix Note.compile: case did not run.' }],
    reason: 'BLOCKED: Fix Note.compile: case did not run.',
  });
  const runWith = async (receipt: MaterializationReceipt) => {
    const store = world({ [receiptPathFor(note.defPath)]: JSON.stringify(receipt), [output]: 'export {};\n' });
    const run = await runMaterialize(baseRequest([note], { stage: 'structure' }), { ...host(store, {}), catalogRef: 'catalog.json' });
    return { run, catalog: parseCatalog(store.map.get('catalog.json') ?? '').catalog };
  };
  const promoted = await runWith(await blockedReceipt({ [output]: await contentHash('export {};\n') }));
  assert.match(promoted.run.snapshot?.units[0].reason ?? '', /^STATUS_BLOCKED/);
  assert.deepEqual(promoted.catalog?.scenarios.map(item => item.scenarioId), ['Note']);
  assert.equal(promoted.run.catalog?.gaps.some(gap => gap.origin === note.defPath), false);

  const never = await runWith(await blockedReceipt({}));
  assert.match(never.run.snapshot?.units[0].reason ?? '', /^STATUS_BLOCKED/);
  assert.deepEqual(never.catalog?.scenarios.map(item => item.scenarioId), []);
  assert.equal(never.run.catalog?.gaps.some(gap => gap.origin === note.defPath), true);
});

void test('removing a controller route regenerates that test and leaves an untouched unit byte-identical', async () => {
  const note = entity('Note');
  const board = controller('board', ['listAlpha', 'listBeta']);
  const narrowed = controller('board', ['listAlpha']);
  const derived = deriveCatalog(MODULE, [note, board], {});
  const ref = `_${PROJECT}_/l1/${MODULE}/materialization/agentMaterializeL1/scenarioCatalog.ts`;
  const catalogText = renderMonitorCatalog(derived.catalog, ref);
  const noteOutput = outputPathFromDefPath(note.defPath);
  const boardOutput = outputPathFromDefPath(board.defPath);
  const noteTest = testFileFor(noteOutput);
  const boardTest = testFileFor(boardOutput);
  const boardScenario = derived.catalog.scenarios.find(item => item.artifactId === 'board');
  assert.ok(boardScenario);
  const oldBoardTest = renderScenarioTest(boardScenario);
  assert.match(oldBoardTest, /listBeta/);
  const kept = 'export const kept = 1;\n';
  const noteBody = 'export const note = 1;\n';
  const noteRendered = definitionSource(note);
  const boardRendered = definitionSource(board);
  const store = world({
    [ref]: catalogText,
    [note.defPath]: noteRendered,
    [board.defPath]: boardRendered,
    [noteOutput]: noteBody,
    [boardOutput]: 'export const routes = [];\n',
    [noteTest]: kept,
    [boardTest]: oldBoardTest,
    '_102034_/l1/server/layer_2_controllers/contracts.ts': 'export interface ControllerRoute { key: string }\n',
  });
  const noteReceiptPath = receiptPathFor(note.defPath);
  assert.ok(noteReceiptPath);
  store.map.set(noteReceiptPath, JSON.stringify(await scaffoldReceipt(note, noteOutput, noteBody)));
  store.map.set(board.defPath, definitionSource(narrowed));
  const nextDerived = deriveCatalog(MODULE, [note, narrowed], {});
  const result = await runMaterialize(baseRequest([note, narrowed]), {
    ...host(store, {
      'structure.httpController': async () => {
        const scenario = nextDerived.catalog.scenarios.find(item => item.artifactId === 'board');
        if (!scenario) return emptyOutcome();
        return {
          files: { [boardOutput]: 'export const routes = [{ key: "listAlpha" }];\n' },
          observations: scenario.cases.map(item => observation(item.caseId, item.expect.ok, item.expect.errorCode, item.expect.status)),
          failure: null,
          seeds: false,
          resets: false,
          runsStub: false,
        };
      },
    }),
    catalogRef: ref,
  });
  const promoted = result.units.find(item => item.defPath === board.defPath);
  assert.equal(promoted?.code, 'PROMOTED', promoted?.detail);
  assert.equal(result.units.find(item => item.defPath === note.defPath)?.code, 'REUSE');
  assert.notEqual(store.map.get(boardOutput), 'export const routes = [];\n');
  const regenerated = store.map.get(boardTest) ?? '';
  assert.notEqual(regenerated, oldBoardTest);
  assert.equal(regenerated.includes('listBeta'), false);
  assert.match(regenerated, /listAlpha/);
  assert.equal(store.map.get(noteTest), kept);
  assert.equal(store.map.get(noteOutput), noteBody);
  assert.equal(store.map.get(note.defPath), noteRendered);
  const nextBoard = nextDerived.catalog.scenarios.find(item => item.artifactId === 'board');
  assert.ok(nextBoard);
  assert.equal(regenerated, renderScenarioTest(nextBoard));
  assert.doesNotMatch(regenerated, /^\s*import\b/m);
});

void test('m1_35: a pre-m1_35 node runner on disk is rewritten as data; a hand test stays', async () => {
  const note = entity('Note');
  const derived = deriveCatalog(MODULE, [note], {});
  const scenario = derived.catalog.scenarios[0];
  assert.ok(scenario);
  const ref = `_${PROJECT}_/l1/${MODULE}/materialization/agentMaterializeL1/scenarioCatalog.ts`;
  const output = outputPathFromDefPath(note.defPath);
  const body = 'export const note = 1;\n';
  const legacy = [
    `/// <mls fileReference="${scenario.testFile}" enhancement="_blank"/>`,
    '',
    "import assert from 'node:assert/strict';",
    "import test from 'node:test';",
    `import { scenarioCatalog } from '/${ref.replace(/\.ts$/, '.js')}';`,
    `const scenario = scenarioCatalog.scenarios.find(item => item.scenarioId === '${scenario.scenarioId}');`,
    "void test('x', () => { assert.ok(scenario); });",
    '',
  ].join('\n');
  const hand = 'export const kept = 1;\n';
  // Receipt stages the bench holds today (generate, verify) plus the structure scaffold (compile).
  for (const stage of ['compile', 'generate', 'verify'] as const)
  for (const catalogOnDisk of [false, true]) {
    for (const [testText, expected] of [[legacy, renderScenarioTest(scenario)], [hand, hand]] as const) {
      const store = world({
        [note.defPath]: definitionSource(note),
        [output]: body,
        [scenario.testFile]: testText,
        ...(catalogOnDisk ? { [ref]: renderMonitorCatalog(derived.catalog, ref) } : {}),
      });
      const receiptPath = receiptPathFor(note.defPath);
      assert.ok(receiptPath);
      const receipt = await scaffoldReceipt(note, output, body);
      // A real receipt records the hash of the test that was on disk: here, the node runner.
      receipt.sourceHashes[scenario.testFile] = await contentHash(testText);
      receipt.stage = stage;
      store.map.set(receiptPath, JSON.stringify(receipt));
      const result = await runMaterialize(baseRequest([note]), { ...host(store, {}), catalogRef: ref });
      assert.equal(result.units[0]?.code, 'REUSE', result.units[0]?.detail);
      assert.equal(result.catalog?.action, catalogOnDisk ? 'unchanged' : 'written');
      assert.equal(store.map.get(scenario.testFile), expected, `catalog on disk: ${catalogOnDisk}`);
      // The next run sees a test hash that moved: it must not regenerate, block or fail the unit.
      const again = await runMaterialize(baseRequest([note]), { ...host(store, {}), catalogRef: ref });
      assert.ok(['REUSE', 'VERIFIED'].includes(again.units[0]?.code ?? ''), again.units[0]?.detail);
      assert.equal(store.map.get(scenario.testFile), expected);
    }
  }
});

void test('a misaligned ledger still rewrites an emitted catalog and records the new hash', async () => {
  const note = entity('Note');
  const derived = deriveCatalog(MODULE, [note], {});
  const previous = JSON.parse(catalogBytes(derived.catalog)) as M1ScenarioCatalog;
  previous.scenarios[0].cases[0].expectation = 'previous M1 output';
  const ref = 'catalog.json';
  const text = renderMonitorCatalog(previous, ref);
  const store = world({ [ref]: text });
  const ledger = emptyLedger(PROJECT, MODULE, tightenBudget({ timeoutMs: 2000 }, null), 'structure');
  ledger.catalogInputHash = await contentHash(catalogBytes(derived.catalog));
  store.map.set(ledgerPath(MODULE), encodeLedger(ledger));
  store.map.set(ownedManifestRef(MODULE), renderOwnedManifest({
    schemaVersion: M1_OWNED_SCHEMA,
    moduleName: MODULE,
    units: [{ defPath: note.defPath, outputs: [] }],
  }));
  const wrote = await runMaterialize(baseRequest([note], { stage: 'structure' }), host(store, {
    'structure.domainEntity': async () => passOutcome(outputPathFromDefPath(note.defPath)),
  }, undefined, text));
  assert.equal(wrote.catalog?.action, 'written');
  const next = parseCatalog(store.map.get(ref) ?? '');
  assert.ok(next.catalog);
  assert.equal(catalogBytes(next.catalog), catalogBytes(derived.catalog));
  const aligned = parseLedger(store.map.get(ledgerPath(MODULE)) ?? '', PROJECT, MODULE);
  assert.equal(aligned?.catalogInputHash, await contentHash(catalogBytes(derived.catalog)));
  const owned = JSON.parse(store.map.get(ownedManifestRef(MODULE)) ?? '{}') as { catalogHash?: string };
  assert.equal(owned.catalogHash, aligned?.catalogInputHash);
});

void test('a failed receipt with a new test is checked again and another unit keeps its budget', async () => {
  const note = entity('Note');
  const failedNote = { ...note, definition: { ...(note.definition as M1Definition), status: 'failed' as const } };
  const other = '_102047_/l1/deskLedger/layer_3_domain/entities/other.defs.ts';
  const rendered = renderDefinition(failedNote.definition, failedNote.defPath);
  assert.ok('source' in rendered);
  const output = outputPathFromDefPath(note.defPath);
  const testPath = testFileFor(output);
  const testBody = 'export const probe = 1;\n';
  const store = world({ [note.defPath]: rendered.source, [testPath]: testBody });
  const hash = await semanticHash(note.definition as M1Definition);
  const receipt: MaterializationReceipt = {
    schemaVersion: M1_RECEIPT_SCHEMA,
    runId: '102047:deskLedger',
    candidateId: '',
    defPath: note.defPath,
    artifactType: 'domainEntity',
    artifactId: 'Note',
    recipeVersion: recipeForStage('implement'),
    semanticHash: hash,
    dependencyHashes: {},
    sourceHashes: { [note.defPath]: hash, [testPath]: 'sha256:old-test' },
    outputHashes: {},
    stage: 'plan',
    verifications: [],
    failures: [{ code: 'CHECKPOINT_FAILED', detail: 'red' }],
    attempts: 1,
    reason: 'CHECKPOINT_FAILED: red',
  };
  const receiptPath = receiptPathFor(note.defPath);
  assert.ok(receiptPath);
  store.map.set(receiptPath, JSON.stringify(receipt));
  const ledger = emptyLedger(PROJECT, MODULE, tightenBudget({ timeoutMs: 2000 }, null), 'implement');
  ledger.calls = 3;
  ledger.repairs = 2;
  ledger.units[note.defPath] = { repairs: 1, calls: 1, signature: 'CHECKPOINT_FAILED', ended: 'CHECKPOINT_FAILED', stage: 'implement' };
  ledger.units[other] = { repairs: 4, calls: 2, signature: '', ended: 'PROMOTED', stage: 'implement' };
  store.map.set(ledgerPath(MODULE), encodeLedger(ledger));

  const moved = await runMaterialize(baseRequest([failedNote], { stage: 'implement', resume: true }), host(store, {
    'implement.domainEntity': async () => passOutcome(output),
  }));
  assert.doesNotMatch(moved.units[0].detail, /budget was not reset/);
  const movedLedger = parseLedger(store.map.get(ledgerPath(MODULE)) ?? '', PROJECT, MODULE);
  assert.equal(movedLedger?.repairs, 2);
  assert.equal(movedLedger?.units[other]?.repairs, 4);
  assert.equal(movedLedger?.units[other]?.ended, 'PROMOTED');
  assert.match(store.map.get(note.defPath) ?? '', /"status": "pending"/);

  receipt.sourceHashes[testPath] = await contentHash(testBody);
  store.map.set(receiptPath, JSON.stringify(receipt));
  store.map.set(note.defPath, rendered.source);
  store.map.set(ledgerPath(MODULE), encodeLedger(ledger));
  const same = await runMaterialize(baseRequest([note], { stage: 'implement', resume: true }), host(store, {
    'implement.domainEntity': async () => passOutcome(output),
  }));
  assert.equal(same.units[0].code, 'CHECKPOINT_FAILED');
  assert.match(same.units[0].detail, /budget was not reset/);
  const sameLedger = parseLedger(store.map.get(ledgerPath(MODULE)) ?? '', PROJECT, MODULE);
  assert.equal(sameLedger?.units[other]?.repairs, 4);
});

void test('help names the studio command and the l2 entry does not import node', () => {
  const help = helpText(102047);
  assert.match(help, /@@agentMaterializeL1 \/help/);
  assert.doesNotMatch(help, /nodejsMaterializeL1|tsx /);
  assert.match(help, /stage simulate/);
  const root = dirname(HERE);
  const files: string[] = [];
  walk(root, files);
  const forbidden = /from\s+['"](?:node:|fs|typescript)['"]|import\(\s*['"](?:node:|fs|typescript)/;
  for (const file of files) {
    if (file.endsWith('.test.ts')) continue;
    const source = readFileSync(file, 'utf8');
    assert.equal(forbidden.test(source), false, file);
  }
  const readme = readFileSync(join(root, 'readme.md'), 'utf8');
  assert.match(readme, /@@agentMaterializeL1 \/help/);
});

function loadDefs(root: string, prefix: string): { units: PlanUnitInput[]; texts: Record<string, string> } {
  const units: PlanUnitInput[] = [];
  const texts: Record<string, string> = {};
  const walk = (dir: string): void => {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.name.endsWith('.defs.ts') || entry.name.endsWith('.defs.txt')) {
        const text = readFileSync(path, 'utf8');
        const parsed = parseDefinitionSource(text);
        if (!('definition' in parsed)) continue;
        const rel = fixtureLogicalRel(path.slice(root.length + 1).split('/').join('/'));
        const defPath = `${prefix}${rel}`;
        texts[defPath] = text;
        units.push({ defPath, definition: parsed.definition });
      }
    }
  };
  walk(root);
  return { units, texts };
}

/** m1_41 b2: the v2 controleEstoque seed and its contract, read only, under MODULE. */
function loadSeed(): { units: PlanUnitInput[]; texts: Record<string, string> } {
  const SEED_MODULE = 'controleEstoque';
  const rename = (text: string) => text.split(SEED_MODULE).join(MODULE);
  const loaded = loadDefs(join(HERE, '../fixtures/v2ControleEstoque'), `_${PROJECT}_/l1/${SEED_MODULE}/`);
  const contract = readFileSync(join(HERE, '../fixtures/controleEstoque-39a5166/l2/controleEstoque/web/contracts/produtos.defs.txt'), 'utf8');
  const texts: Record<string, string> = { [rename(`_${PROJECT}_/l2/${SEED_MODULE}/web/contracts/produtos.defs.ts`)]: rename(contract) };
  for (const [key, value] of Object.entries(loaded.texts)) texts[rename(key)] = rename(value);
  const units = loaded.units.map(unit => ({ defPath: rename(unit.defPath), definition: JSON.parse(rename(JSON.stringify(unit.definition))) as PlanUnitInput['definition'] }));
  return { units, texts };
}

function definitionSource(unit: PlanUnitInput): string {
  const rendered = renderDefinition(unit.definition, unit.defPath);
  if ('source' in rendered) return rendered.source;
  return `export const definition = ${JSON.stringify(unit.definition)} as const;\n`;
}

async function scaffoldReceipt(unit: PlanUnitInput, output: string, body: string): Promise<MaterializationReceipt> {
  const definition = unit.definition as M1Definition;
  const hash = await semanticHash(definition);
  return {
    schemaVersion: M1_RECEIPT_SCHEMA,
    runId: '102047:deskLedger',
    candidateId: '',
    defPath: unit.defPath,
    artifactType: definition.artifactType,
    artifactId: definition.artifactId,
    recipeVersion: recipeForStage('structure'),
    semanticHash: hash,
    dependencyHashes: {},
    sourceHashes: { [unit.defPath]: hash },
    outputHashes: { [output]: await contentHash(body) },
    stage: 'compile',
    verifications: [],
    failures: [],
    attempts: 1,
    reason: 'scaffold',
  };
}

function controller(id: string, routes: readonly string[]): PlanUnitInput {
  const defPath = `_${PROJECT}_/l1/${MODULE}/layer_1_external/adapters/http/controllers/${id}.defs.ts`;
  const definition: M1Definition = {
    schemaVersion: M1_DEFINITION_SCHEMA,
    artifactType: 'httpController',
    artifactId: id,
    moduleName: MODULE,
    status: 'pending',
    dependencies: [],
    data: {
      pageId: id,
      handlers: routes.map(route => ({
        route: `${MODULE}.${id}.${route}`,
        kind: 'query',
        grantIds: [],
        serviceFunction: `${MODULE}.${id}.${route}`,
        contractPath: `l2/${MODULE}/web/contracts/${id}.defs.ts`,
        contractInterface: 'BoardContracts',
      })),
    },
  };
  return { defPath, definition };
}

function entity(id: string): PlanUnitInput {
  const defPath = `_${PROJECT}_/l1/${MODULE}/layer_3_domain/entities/${id.toLowerCase()}.defs.ts`;
  const definition: M1Definition = {
    schemaVersion: M1_DEFINITION_SCHEMA,
    artifactType: 'domainEntity',
    artifactId: id,
    moduleName: MODULE,
    status: 'pending',
    dependencies: [],
    data: {
      entityId: id,
      storageTarget: 'moduleDatabase',
      fields: [{ name: 'id', type: 'uuid', derived: true }],
      lifecycle: { states: [{ state: 'ready', reachedBy: 'actor' }], transitions: [] },
      invariants: [],
      imports: [],
    },
  };
  return { defPath, definition };
}

function value(id: string, dependency: string): PlanUnitInput {
  const defPath = `_${PROJECT}_/l1/${MODULE}/layer_3_domain/values/${id.toLowerCase()}.defs.ts`;
  const definition: M1Definition = {
    schemaVersion: M1_DEFINITION_SCHEMA,
    artifactType: 'valueObject',
    artifactId: id,
    moduleName: MODULE,
    status: 'pending',
    dependencies: [dependency],
    data: { valueObjectId: id, fields: [], referencedBy: ['Note'] },
  };
  return { defPath, definition };
}

function baseRequest(units: readonly PlanUnitInput[], patch: Partial<MaterializeRunRequest> = {}): MaterializeRunRequest {
  return {
    project: PROJECT,
    moduleName: MODULE,
    stage: 'structure',
    flow: '',
    resume: false,
    units,
    profileMode: 'development',
    profileDeclared: true,
    budget: { timeoutMs: 2000 },
    ...patch,
  };
}

function host(
  store: ReturnType<typeof world>,
  runners: Record<string, MaterializeHandlerRunner>,
  llm?: MaterializeRunHost['llm'],
  catalogText?: string,
): MaterializeRunHost {
  if (catalogText) store.map.set('catalog.json', catalogText);
  return {
    io: { async read(ref: string) { return store.map.get(ref) ?? null; } },
    state: store.state,
    runners,
    llm,
    now: () => '2026-09-25T12:00:00.000Z',
    catalogRef: catalogText ? 'catalog.json' : '',
    commit: '1b94018',
    monitorError: null,
  };
}

function world(seed: Record<string, string> = {}) {
  const map = new Map(Object.entries(seed));
  const writes: string[] = [];
  const state: MaterializeStateStore = {
    async readReceipt(defPath: string): Promise<MaterializationReceipt | null> {
      const path = receiptPathFor(defPath);
      const text = path ? map.get(path) : undefined;
      if (!text) return null;
      return JSON.parse(text) as MaterializationReceipt;
    },
    async writeReceipt(receipt: MaterializationReceipt): Promise<void> {
      const path = receiptPathFor(receipt.defPath);
      writes.push(path);
      map.set(path, JSON.stringify(receipt));
    },
    async readOwned(path: string): Promise<Uint8Array | null> {
      const text = map.get(path);
      return text === undefined ? null : new TextEncoder().encode(text);
    },
    async writeOwned(path: string, body: Uint8Array): Promise<void> {
      writes.push(path);
      map.set(path, new TextDecoder().decode(body));
    },
    async removeOwned(owned: readonly string[], requested: readonly string[]): Promise<MaterializeOwnedRemoval> {
      const removed: string[] = [];
      const kept: string[] = [];
      for (const path of requested) {
        if (!owned.includes(path) || path.endsWith('/') || !map.has(path)) {
          kept.push(path);
          continue;
        }
        map.delete(path);
        removed.push(path);
      }
      return { removed, kept };
    },
    async readRevision(): Promise<string | null> {
      return null;
    },
  };
  return { map, writes, state };
}

function catalog(units: readonly PlanUnitInput[], mode: 'pass' | 'red'): string {
  return JSON.stringify({
    schemaVersion: M1_CATALOG_SCHEMA,
    moduleName: MODULE,
    store: 'memory',
    scenarios: units.map(unit => {
      const definition = unit.definition as M1Definition;
      const productionFile = outputPathFromDefPath(unit.defPath);
      const caseId = `${definition.artifactId}.check`;
      const red = mode === 'red';
      return {
        scenarioId: definition.artifactId,
        source: 'm1_02',
        artifactType: definition.artifactType,
        artifactId: definition.artifactId,
        handlerId: `structure.${definition.artifactType}`,
        productionFile,
        testFile: testFileFor(productionFile),
        cases: [{
          caseId,
          gate: red ? 'business' : 'compile',
          mandatory: true,
          source: 'm1_02',
          expectation: 'The handler result matches the case.',
          preconditions: ['memory'],
          synthetic: [],
          actorId: '',
          routine: '',
          mutating: false,
          expect: red
            ? { ok: false, status: M1_STUB_STATUS, errorCode: M1_STUB_ERROR, ruleId: null, forbiddenFields: [], isolatedActorField: null }
            : { ok: true, status: 0, errorCode: null, ruleId: null, forbiddenFields: [], isolatedActorField: null },
          expectedFailure: red ? { caseId, stage: 'structure', errorCode: M1_STUB_ERROR, status: M1_STUB_STATUS } : null,
        }],
      };
    }),
  });
}

function passOutcome(output: string, patch: { runsStub?: boolean; extra?: Record<string, string>; red?: boolean } = {}): HandlerOutcome {
  const definitionId = output.split('/').pop()?.replace(/\.ts$/, '') || 'check';
  const id = definitionId.charAt(0).toUpperCase() + definitionId.slice(1);
  return {
    files: { [output]: `export const ${definitionId} = 1;\n`, ...patch.extra },
    observations: [patch.red ? observation(`${id}.check`, false, M1_STUB_ERROR, M1_STUB_STATUS) : observation(`${id}.check`, true)],
    failure: null,
    seeds: false,
    resets: false,
    runsStub: patch.runsStub === true,
  };
}

function observation(caseId: string, ok: boolean, errorCode: string | null = null, status = 0): M1Observation {
  return {
    caseId,
    durationMs: 1,
    broken: 'none',
    thrown: false,
    skipped: false,
    inconclusive: false,
    blocked: false,
    blockOwner: '',
    ok,
    status,
    errorCode,
    ruleId: null,
    fields: [],
    rowActorIds: [],
    reason: '',
  };
}

function emptyOutcome(): HandlerOutcome {
  return { files: {}, observations: [], failure: null, seeds: false, resets: false, runsStub: false };
}

function walk(dir: string, out: string[]): void {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) walk(path, out);
    else if (entry.name.endsWith('.ts')) out.push(path);
  }
}
