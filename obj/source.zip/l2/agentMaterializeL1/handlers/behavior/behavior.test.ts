/// <mls fileReference="_102021_/l2/agentMaterializeL1/handlers/behavior/behavior.test.ts" enhancement="_blank"/>

import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, relative } from 'node:path';
import test from 'node:test';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { isRecord, parseDefinitionSource, readDefinition, type M1Definition } from '/_102021_/l2/helpers/l1Defs/definition.js';
import { handlerFor } from '/_102021_/l2/agentMaterializeL1/core/registry.js';
import { PLATFORM_FILES } from '/_102021_/l2/agentMaterializeL1/context/context.js';
import { planMaterialization } from '/_102021_/l2/agentMaterializeL1/planner/plan.js';
import { decideProfile } from '/_102021_/l2/agentMaterializeL1/run/budget.js';
import type { HandlerCall } from '/_102021_/l2/agentMaterializeL1/run/execute.js';
import { shouldCallModel } from '/_102021_/l2/agentMaterializeL1/run/model.js';
import type { SimulatedUnit } from '/_102021_/l2/agentMaterializeL1/simulate/simulate.js';
import { verifyBatch } from '/_102021_/l2/agentMaterializeL1/testing/verify.js';
import { behaviorNeedsLlm, caseBlock, emitBehavior, withoutCreateChecks, withoutLifecycleChecks, withoutPayloadChecks, withoutScopeChecks, withoutStorageChecks, withoutVersionChecks } from '/_102021_/l2/agentMaterializeL1/handlers/behavior/emitBehavior.js';
import { emitController, recordFieldFromGrant } from '/_102021_/l2/agentMaterializeL1/handlers/structure/emit.js';
import { createRequestContext } from '/_102034_/l1/server/layer_2_controllers/execBff.js';
import { createMemoryDataRuntime } from '/_102034_/l1/mdm/layer_1_external/data/memory/MdmDataRuntimeMemory.js';
import { runBehavior } from '/_102021_/l2/agentMaterializeL1/handlers/behavior/runners.js';
import { copyFixtureSources, resolveFixtureFile } from '/_102021_/l2/agentDefsL1/fixtures/fixtureDisk.js';
import { AGENDA_CLINICA_F35E28A } from '/_102021_/l2/agentDefsL1/fixtures/agendaClinica-f35e28a/root.js';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '../../../../..');
sweepRepoRootScratch();
const CATALOG_REF = 'catalog.json';
const CATALOG = readFileSync(join(HERE, '../../testing/catalogFixture.json'), 'utf8');
const FIXTURES = loadFixtures(join(HERE, '../structure/fixtures'));

void test('lote 1 usecases derive the storage constraint and leave pending rules out', async () => {
  const usecase = handlerFor('usecase', 'implement');
  assert.equal(usecase?.needsLlm, false);
  assert.equal(shouldCallModel('implement', usecase), false);
  assert.equal(handlerFor('table', 'implement'), null);
  assert.equal(behaviorNeedsLlm(definitionFor('createConsulta')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('listConsulta')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('registrarAtendimento')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('confirmarConsulta')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('registrarFalta')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('listPaciente')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('createPaciente')), false);
  assert.equal(behaviorNeedsLlm(definitionFor('updateProfissional')), false);
  const archived = definitionFor('listPaciente');
  const odd: M1Definition = { ...archived, data: { ...archived.data, operation: 'archive', ports: ['Missing'], mdm: {} } };
  assert.equal(behaviorNeedsLlm(odd), true);

  const create = await runBehavior(callFor('createConsulta'));
  const list = await runBehavior(callFor('listConsulta'));
  const port = await runBehavior(callFor('ConsultaRepository'));
  assert.equal(create.failure, null, create.failure?.detail);
  assert.equal(list.failure, null, list.failure?.detail);
  assert.equal(port.failure, null, port.failure?.detail);
  const createSource = sourceOf(create);
  const listSource = sourceOf(list);
  const portSource = sourceOf(port);
  assert.match(createSource, /export async function createConsulta\(/);
  assert.match(createSource, /enforce:storage/);
  assert.match(createSource, /ruleId: "uniqueProfessionalSchedule"/);
  assert.match(createSource, /ports\.consultaRepository\.create\(record\)/);
  assert.equal(createSource.includes('USECASE_NOT_IMPLEMENTED'), false);
  assert.equal(listSource.includes('professionalOwnAppointment'), false);
  assert.match(listSource, /return found;/);
  assert.match(portSource, /createMemoryTableRepository/);
  assert.match(portSource, /export function resetMemory/);
  assert.equal(portSource.includes("from 'pg'"), false);
  assert.equal(port.runsStub, false);
  assert.equal(create.runsStub, false);

  const outsideCall = callFor('listPaciente');
  outsideCall.definition = odd;
  const outside = await runBehavior(outsideCall);
  assert.equal(outside.failure?.code, 'NEEDS_LLM');
  assert.deepEqual(outside.files, {});
  const fakedCall = callFor('listPaciente', 'export const modelBody = 1;\n');
  fakedCall.definition = odd;
  const faked = await runBehavior(fakedCall);
  assert.equal(faked.failure, null, faked.failure?.detail);
  assert.match(sourceOf(faked), /modelBody/);

  const problems = compile([
    ['consulta.ts', sourceOf(await runBehavior(callFor('Consulta')))],
    ['consultaRepository.ts', portSource],
    ['createConsulta.ts', createSource],
    ['listConsulta.ts', listSource],
  ]);
  assert.equal(problems, '', problems);
});

void test('implement checkpoint keeps the business assertion and blocks the open gaps', async () => {
  const handler = handlerFor('usecase', 'implement');
  assert.ok(handler);
  const create = await runBehavior(callFor('createConsulta'));
  const list = await runBehavior(callFor('listConsulta'));
  const created = await verifyBatch({
    handler,
    io: { async read(ref) { return ref === CATALOG_REF ? CATALOG : null; } },
    catalogRef: CATALOG_REF,
    artifactId: 'createConsulta',
    observations: create.observations,
    runId: 'm1-06',
    commit: 'proof',
    startedAt: '2026-09-25T12:00:00.000Z',
    finishedAt: '2026-09-25T12:00:01.000Z',
    monitorError: null,
  });
  assert.equal(created.accepted, true, created.nextAction);
  assert.equal(created.counts.passed, 3);
  assert.equal(created.counts.expectedRed, 0);
  assert.equal(created.ready, true);

  const listed = await verifyBatch({
    handler,
    io: { async read(ref) { return ref === CATALOG_REF ? CATALOG : null; } },
    catalogRef: CATALOG_REF,
    artifactId: 'listConsulta',
    observations: list.observations,
    runId: 'm1-06',
    commit: 'proof',
    startedAt: '2026-09-25T12:00:00.000Z',
    finishedAt: '2026-09-25T12:00:01.000Z',
    monitorError: null,
  });
  const byId = new Map(listed.evidence.map(item => [item.caseId, item.verdict]));
  assert.equal(byId.get('listConsulta.compile'), 'passed');
  assert.equal(byId.get('listConsulta.lists'), 'blocked');
  assert.equal(byId.get('listConsulta.ownAppointments'), 'blocked');
  assert.equal(byId.get('listConsulta.receptionistProjection'), 'passed');
  assert.equal(listed.accepted, false);
  assert.equal(listed.ready, false);
  assert.match(listed.evidence.find(item => item.caseId === 'listConsulta.lists')?.detail ?? '', /x1_04/);
  assert.match(listed.evidence.find(item => item.caseId === 'listConsulta.ownAppointments')?.detail ?? '', /toPlanner/);
});

void test('behavior sources do not name the clinic fixture', () => {
  const banned = /agendaClinica|Consulta|professional|scheduledAt|uniqueProfessionalSchedule/;
  for (const name of ['emitBehavior.ts', 'runners.ts']) {
    const source = readFileSync(join(HERE, name), 'utf8');
    assert.equal(banned.test(source), false, name);
  }
});

void test('renamed fixture ids still enforce the storage constraint', async () => {
  const rewritten = rewriteFixture();
  const create = definitionAt(rewritten, 'createVisita');
  const port = definitionAt(rewritten, 'VisitaRepository');
  const list = definitionAt(rewritten, 'listVisita');
  assert.ok(create && port && list);
  const read = async (ref: string) => rewritten.get(ref) ?? null;
  const emitted = await emitBehavior('implement.usecase', create.definition, 'l1/visitaBook/createVisita.ts', read);
  const emittedPort = await emitBehavior('implement.repositoryPort', port.definition, 'l1/visitaBook/visitaRepository.ts', read);
  assert.equal('code' in emitted, false, 'code' in emitted ? emitted.detail : '');
  assert.equal('code' in emittedPort, false, 'code' in emittedPort ? emittedPort.detail : '');
  if ('code' in emitted || 'code' in emittedPort) return;
  assert.match(emitted.source, /agentId/);
  assert.match(emitted.source, /ruleId: "r1"/);
  assert.match(emitted.source, /visitaRepository/);
  assert.equal(/agendaClinica|Consulta|professionalId|uniqueProfessionalSchedule/.test(emitted.source), false);
  const blockedList = await caseBlock(list.definition, list.defPath, {
    routine: 'visitaBook.consultas_profissional.qryListVisita',
    expect: { ruleId: null },
  }, read);
  const blockedOwn = await caseBlock(list.definition, list.defPath, {
    routine: 'visitaBook.consultas_profissional.qryListVisita',
    expect: { ruleId: 'professionalOwnAppointment' },
  }, read);
  assert.equal(blockedList?.gap, 'ACCESS_ANCHOR');
  assert.equal(blockedOwn?.gap, 'APPLICABILITY_UNDECLARED');

  const dir = mkdtempSync(join(tmpdir(), 'm1-06-rename-'));
  const usecaseFile = join(dir, 'createVisita.ts');
  const portFile = join(dir, 'visitaRepository.ts');
  mkdirSync(dir, { recursive: true });
  writeFileSync(usecaseFile, emitted.source);
  writeFileSync(portFile, emittedPort.source);
  const loaded = await import(pathToFileURL(usecaseFile).href) as { createVisita: (input: Record<string, string>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, string>> };
  const memory = await import(pathToFileURL(portFile).href) as { resetMemory: (seed?: Record<string, unknown>[]) => void; pendingVisitaRepository: unknown };
  const input = { patientId: 'p1', agentId: 'agent-1', scheduledAt: '2026-09-25T13:00:00.000Z', status: 'scheduled' };
  const ctx = { idGenerator: { newId: () => 'row-1' }, sessionContext: { actorId: 'actor-1' } };
  const ports = { visitaRepository: memory.pendingVisitaRepository };
  memory.resetMemory([]);
  const saved = await loaded.createVisita(input, ctx, ports);
  assert.equal(saved.agentId, 'agent-1');
  memory.resetMemory([saved]);
  await assert.rejects(
    () => loaded.createVisita(input, { idGenerator: { newId: () => 'row-2' }, sessionContext: { actorId: 'actor-1' } }, ports),
    (error: { code?: string; details?: { ruleId?: string } }) => error.code === 'CONFLICT' && error.details?.ruleId === 'r1',
  );
  const disabled = withoutStorageChecks(emitted.source);
  assert.equal(disabled.removed, 1);
  const openFile = join(dir, 'createVisitaOpen.ts');
  writeFileSync(openFile, disabled.source);
  const opened = await import(pathToFileURL(openFile).href) as typeof loaded;
  memory.resetMemory([saved]);
  const second = await opened.createVisita(input, { idGenerator: { newId: () => 'row-3' }, sessionContext: { actorId: 'actor-1' } }, ports);
  assert.equal(second.agentId, 'agent-1');
  rmSync(dir, { recursive: true, force: true });

  const units = [...FIXTURES.values()].map(item => ({ defPath: item.defPath, definition: item.definition }));
  const planned = await planMaterialization({
    stage: 'implement',
    units,
    readable: [...units.flatMap(item => [item.defPath, ...item.definition.dependencies]), ...Object.values(PLATFORM_FILES)],
    extraArtifacts: units.map(item => ({
      artifactType: item.definition.artifactType,
      artifactId: item.definition.artifactId,
      defPath: item.defPath,
    })),
  });
  const created = planned.units.find(unit => unit.artifactId === 'createConsulta');
  const transition = planned.units.find(unit => unit.artifactId === 'registrarAtendimento');
  assert.equal(created?.action, 'generate', created?.reason);
  assert.equal(created?.needsLlm, false, created?.reason);
  assert.equal(transition?.action, 'generate', transition?.reason);
  assert.equal(transition?.needsLlm, false, transition?.reason);
});

void test('a transition enforces lifecycle and a required payload, and leaves the anchor rule out', async () => {
  const attend = await runBehavior(callFor('registrarAtendimento'));
  const confirm = await runBehavior(callFor('confirmarConsulta'));
  const missed = await runBehavior(callFor('registrarFalta'));
  const port = await runBehavior(callFor('ConsultaRepository'));
  assert.equal(attend.failure, null, attend.failure?.detail);
  assert.equal(confirm.failure, null, confirm.failure?.detail);
  assert.equal(missed.failure, null, missed.failure?.detail);
  const attendSource = sourceOf(attend);
  const confirmSource = sourceOf(confirm);
  assert.match(attendSource, /enforce:lifecycle/);
  assert.match(attendSource, /enforce:payload/);
  assert.match(attendSource, /ruleId: "attendanceNoteRequired"/);
  assert.match(attendSource, /ruleId: "consultationTransitionFlow"/);
  assert.equal(attendSource.includes('professionalOwnAppointment'), false);
  assert.match(attendSource, /undelivered/);
  assert.equal(attendSource.includes('publish'), false);
  assert.match(confirmSource, /enforce:lifecycle/);
  assert.equal(confirmSource.includes('enforce:payload'), false);
  const anchor = await caseBlock(definitionFor('registrarAtendimento'), callFor('registrarAtendimento').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.cmdRegistrarAtendimento',
    expect: { ruleId: 'professionalOwnAppointment' },
  }, read);
  const note = await caseBlock(definitionFor('registrarAtendimento'), callFor('registrarAtendimento').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.cmdRegistrarAtendimento',
    expect: { ruleId: 'attendanceNoteRequired' },
  }, read);
  const version = await caseBlock(definitionFor('registrarAtendimento'), callFor('registrarAtendimento').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.cmdRegistrarAtendimento',
    expect: { ruleId: 'expectedVersion' },
  }, read);
  assert.equal(anchor?.gap, 'ACCESS_ANCHOR');
  assert.equal(note, null);
  assert.equal(version?.gap, 'PRECONDITION_UNDECLARED');
  assert.equal(version?.owner, 'x1_05');
  const handler = handlerFor('usecase', 'implement');
  assert.ok(handler);
  const reported = await verifyBatch({
    handler,
    io: { async read(ref) { return ref === CATALOG_REF ? CATALOG : null; } },
    catalogRef: CATALOG_REF,
    artifactId: 'registrarAtendimento',
    observations: attend.observations,
    runId: 'm1-06',
    commit: 'proof',
    startedAt: '2026-09-25T12:00:00.000Z',
    finishedAt: '2026-09-25T12:00:01.000Z',
    monitorError: null,
  });
  const verdicts = new Map(reported.evidence.map(item => [item.caseId, item.verdict]));
  assert.equal(verdicts.get('registrarAtendimento.compile'), 'passed');
  assert.equal(verdicts.get('registrarAtendimento.noteRequired'), 'passed');
  assert.equal(verdicts.get('registrarAtendimento.invalidTransition'), 'passed');
  assert.equal(verdicts.get('registrarAtendimento.staleVersion'), 'blocked');
  assert.equal(reported.counts.failed, 0);

  const dir = mkdtempSync(join(tmpdir(), 'm1-06-transition-'));
  const portFile = join(dir, 'consultaRepository.ts');
  const attendFile = join(dir, 'registrarAtendimento.ts');
  const confirmFile = join(dir, 'confirmarConsulta.ts');
  writeFileSync(portFile, sourceOf(port));
  writeFileSync(attendFile, attendSource);
  writeFileSync(confirmFile, confirmSource);
  const problems = compile([
    ['consulta.ts', sourceOf(await runBehavior(callFor('Consulta')))],
    ['consultaRepository.ts', sourceOf(port)],
    ['registrarAtendimento.ts', attendSource],
    ['confirmarConsulta.ts', confirmSource],
    ['registrarFalta.ts', sourceOf(missed)],
  ]);
  assert.equal(problems, '', problems);
  const memory = await import(pathToFileURL(portFile).href) as {
    resetMemory: (seed?: Record<string, unknown>[]) => void;
    pendingConsultaRepository: unknown;
  };
  const attended = await import(pathToFileURL(attendFile).href) as {
    registrarAtendimento: (input: Record<string, unknown>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
  const confirmed = await import(pathToFileURL(confirmFile).href) as {
    confirmarConsulta: (input: Record<string, unknown>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
  const ports = { consultaRepository: memory.pendingConsultaRepository };
  const ctx = {};
  const row = {
    id: 'consulta-1',
    version: 2,
    patientId: 'patient-1',
    professionalId: 'professional-1',
    scheduledAt: '2026-09-25T13:00:00.000Z',
    status: 'scheduled',
    details: { attendanceNote: '' },
  };
  memory.resetMemory([row]);
  await assert.rejects(
    () => attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: '' } }, ctx, ports),
    (error: { code?: string; details?: { ruleId?: string } }) => error.code === 'VALIDATION_ERROR' && error.details?.ruleId === 'attendanceNoteRequired',
  );
  memory.resetMemory([{ ...row, status: 'noShow', details: { attendanceNote: 'seen' } }]);
  await assert.rejects(
    () => attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: 'seen' } }, ctx, ports),
    (error: { code?: string; details?: { ruleId?: string } }) => error.code === 'VALIDATION_ERROR' && error.details?.ruleId === 'consultationTransitionFlow',
  );
  memory.resetMemory([row]);
  const saved = await attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: 'seen' } }, ctx, ports);
  assert.equal(saved.status, 'attended');
  assert.equal((saved.details as { attendanceNote?: string }).attendanceNote, 'seen');
  const opened = withoutPayloadChecks(attendSource);
  assert.equal(opened.removed, 1);
  const openFile = join(dir, 'registrarAtendimentoOpen.ts');
  writeFileSync(openFile, opened.source);
  const openAttend = await import(pathToFileURL(openFile).href) as typeof attended;
  memory.resetMemory([row]);
  const withoutNote = await openAttend.registrarAtendimento({ id: 'consulta-1', details: {} }, ctx, ports);
  assert.equal(withoutNote.status, 'attended');
  memory.resetMemory([row]);
  const confirmedRow = await confirmed.confirmarConsulta({ id: 'consulta-1' }, ctx, ports);
  assert.equal(confirmedRow.status, 'confirmed');
  memory.resetMemory([{ ...row, status: 'attended' }]);
  await assert.rejects(
    () => confirmed.confirmarConsulta({ id: 'consulta-1' }, ctx, ports),
    (error: { code?: string; details?: { ruleId?: string } }) => error.code === 'VALIDATION_ERROR' && error.details?.ruleId === 'consultationTransitionFlow',
  );
  rmSync(dir, { recursive: true, force: true });
});

void test('a transition enforces from/to and payload without picking one lifecycle rule', async () => {
  const root = join(HERE, '../../../agentDefsL1/fixtures/agendaClinica-3f4f677');
  const renamed = new Map<string, string>();
  const load = (ref: string): string | null => {
    if (ref === CATALOG_REF) return CATALOG;
    if (renamed.has(ref)) return renamed.get(ref) ?? null;
    const match = /^_\d+_\/(.+)$/.exec(ref);
    if (!match) return null;
    try {
      return readFileSync(resolveFixtureFile(join(root, match[1])), 'utf8');
    } catch {
      return null;
    }
  };
  const defPath = '_102047_/l1/agendaClinica/layer_2_application/usecases/registrarAtendimento.defs.ts';
  const entityPath = '_102047_/l1/agendaClinica/layer_3_domain/entities/consulta.defs.ts';
  const portPath = '_102047_/l1/agendaClinica/layer_2_application/ports/consultaRepository.defs.ts';
  const call = (path: string, artifactType: string, artifactId: string, text: string) => {
    const parsed = parseDefinitionSource(text);
    if (!('definition' in parsed)) throw new Error(parsed.issues.join(' '));
    const definition = readDefinition(parsed.definition);
    if ('issues' in definition) throw new Error(definition.issues.join(' '));
    const handler = handlerFor(artifactType, 'implement');
    if (!handler) throw new Error(artifactType);
    const unit: SimulatedUnit = {
      defPath: path,
      artifactType,
      artifactId,
      action: 'generate',
      reason: '',
      handlerId: handler.id,
      needsLlm: false,
      unresolved: [],
      contextRefs: [],
      blockedBy: [],
      prompt: '',
    };
    return runBehavior({
      handler,
      unit,
      definition,
      read: async ref => load(ref),
      catalogRef: CATALOG_REF,
      repair: false,
      signal: new AbortController().signal,
      eventId: path,
      profile: decideProfile('development', true),
      modelText: null,
    });
  };
  const attend = await call(defPath, 'usecase', 'registrarAtendimento', load(defPath) ?? '');
  const port = await call(portPath, 'repositoryPort', 'ConsultaRepository', load(portPath) ?? '');
  const entity = await call(entityPath, 'domainEntity', 'Consulta', load(entityPath) ?? '');
  assert.equal(attend.failure, null, attend.failure?.detail);
  assert.equal(port.failure, null, port.failure?.detail);
  assert.equal(entity.failure, null, entity.failure?.detail);
  const attendSource = sourceOf(attend);
  assert.match(attendSource, /enforce:lifecycle/);
  assert.match(attendSource, /enforce:payload/);
  assert.match(attendSource, /\["scheduled"\]/);
  assert.match(attendSource, /"attended"/);
  assert.match(attendSource, /"details\.attendanceNote"/);
  for (const ruleId of [
    'consultaSomenteAgendadaPodeRegistrarAtendimento',
    'anotacaoObrigatoriaNoAtendimento',
    'profissionalAtendeSomentePropriaConsulta',
  ]) {
    assert.equal(attendSource.includes(ruleId), false, ruleId);
  }
  const usecaseText = load(defPath) ?? '';
  const entityText = load(entityPath) ?? '';
  renamed.set(defPath, usecaseText
    .replaceAll('consultaSomenteAgendadaPodeRegistrarAtendimento', 'ruleAlpha')
    .replaceAll('anotacaoObrigatoriaNoAtendimento', 'ruleBeta')
    .replaceAll('profissionalAtendeSomentePropriaConsulta', 'ruleGamma')
    .replaceAll('details.attendanceNote', 'details.remark'));
  renamed.set(entityPath, entityText
    .replaceAll('consultaSomenteAgendadaPodeRegistrarAtendimento', 'ruleAlpha')
    .replaceAll('anotacaoObrigatoriaNoAtendimento', 'ruleBeta')
    .replaceAll('profissionalAtendeSomentePropriaConsulta', 'ruleGamma')
    .replaceAll('"scheduled"', '"alpha"')
    .replaceAll('"attended"', '"omega"')
    .replaceAll('details.attendanceNote', 'details.remark'));
  const renamedAttend = await call(defPath, 'usecase', 'registrarAtendimento', renamed.get(defPath) ?? '');
  assert.equal(renamedAttend.failure, null, renamedAttend.failure?.detail);
  const renamedSource = sourceOf(renamedAttend);
  assert.match(renamedSource, /\["alpha"\]/);
  assert.match(renamedSource, /"omega"/);
  assert.match(renamedSource, /"details\.remark"/);
  assert.equal(renamedSource.includes('ruleAlpha'), false);
  assert.equal(renamedSource.includes('scheduled'), false);

  const dir = mkdtempSync(join(tmpdir(), 'm1-11-transition-'));
  const portFile = join(dir, 'consultaRepository.ts');
  const attendFile = join(dir, 'registrarAtendimento.ts');
  writeFileSync(portFile, sourceOf(port));
  writeFileSync(attendFile, attendSource);
  const problems = compile([
    ['consulta.ts', sourceOf(entity)],
    ['consultaRepository.ts', sourceOf(port)],
    ['registrarAtendimento.ts', attendSource],
  ]);
  assert.equal(problems, '', problems);
  const memory = await import(pathToFileURL(portFile).href) as {
    resetMemory: (seed?: Record<string, unknown>[]) => void;
    pendingConsultaRepository: unknown;
  };
  const attended = await import(pathToFileURL(attendFile).href) as {
    registrarAtendimento: (input: Record<string, unknown>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
  const ports = { consultaRepository: memory.pendingConsultaRepository };
  const row = {
    id: 'consulta-1',
    version: 1,
    pacienteId: 'patient-1',
    profissionalId: 'professional-1',
    scheduledAt: '2026-09-25T13:00:00.000Z',
    status: 'scheduled',
    details: { attendanceNote: '' },
  };
  memory.resetMemory([row]);
  await assert.rejects(
    () => attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: '' } }, {}, ports),
    (error: { code?: string }) => error.code === 'VALIDATION_ERROR',
  );
  memory.resetMemory([{ ...row, status: 'noShow', details: { attendanceNote: 'seen' } }]);
  await assert.rejects(
    () => attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: 'seen' } }, {}, ports),
    (error: { code?: string }) => error.code === 'VALIDATION_ERROR',
  );
  memory.resetMemory([row]);
  const saved = await attended.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: 'seen' } }, {}, ports);
  assert.equal(saved.status, 'attended');
  const openNote = withoutPayloadChecks(attendSource);
  const openState = withoutLifecycleChecks(attendSource);
  assert.equal(openNote.removed, 1);
  assert.equal(openState.removed, 1);
  writeFileSync(join(dir, 'openNote.ts'), openNote.source);
  writeFileSync(join(dir, 'openState.ts'), openState.source);
  const noteModule = await import(pathToFileURL(join(dir, 'openNote.ts')).href) as typeof attended;
  const stateModule = await import(pathToFileURL(join(dir, 'openState.ts')).href) as typeof attended;
  memory.resetMemory([row]);
  const withoutNote = await noteModule.registrarAtendimento({ id: 'consulta-1', details: {} }, {}, ports);
  assert.equal(withoutNote.status, 'attended');
  memory.resetMemory([{ ...row, status: 'noShow', details: { attendanceNote: 'seen' } }]);
  const withoutState = await stateModule.registrarAtendimento({ id: 'consulta-1', details: { attendanceNote: 'seen' } }, {}, ports);
  assert.equal(withoutState.status, 'attended');
  rmSync(dir, { recursive: true, force: true });
});

void test('mdm create attaches an existing record and update rejects a stale version', async () => {
  const created = await runBehavior(callFor('createPaciente'));
  const updated = await runBehavior(callFor('updateProfissional'));
  const listed = await runBehavior(callFor('listPaciente'));
  assert.equal(created.failure, null, created.failure?.detail);
  assert.equal(updated.failure, null, updated.failure?.detail);
  assert.equal(listed.failure, null, listed.failure?.detail);
  const createSource = sourceOf(created);
  const updateSource = sourceOf(updated);
  assert.match(createSource, /enforce:create/);
  assert.match(createSource, /findByDocument/);
  assert.match(createSource, /attachRole/);
  assert.match(updateSource, /enforce:version/);
  assert.match(updateSource, /readPath\(body, "version"\)/);
  assert.match(sourceOf(listed), /listByType/);
  const openCreate = withoutCreateChecks(createSource);
  const openUpdate = withoutVersionChecks(updateSource);
  assert.equal(openCreate.removed, 1);
  assert.equal(openUpdate.removed, 1);

  const dir = mkdtempSync(join(tmpdir(), 'm1-06-mdm-'));
  const createFile = join(dir, 'createPaciente.ts');
  const updateFile = join(dir, 'updateProfissional.ts');
  const openCreateFile = join(dir, 'createPacienteOpen.ts');
  const openUpdateFile = join(dir, 'updateProfissionalOpen.ts');
  writeFileSync(createFile, createSource);
  writeFileSync(updateFile, updateSource);
  writeFileSync(openCreateFile, openCreate.source);
  writeFileSync(openUpdateFile, openUpdate.source);
  const createModule = await import(pathToFileURL(createFile).href) as {
    createPaciente: (input: Record<string, unknown>, ctx: unknown) => Promise<{ id: string }>;
  };
  const updateModule = await import(pathToFileURL(updateFile).href) as {
    updateProfissional: (input: Record<string, unknown>, ctx: unknown) => Promise<{ id: string; version: number }>;
  };
  const openCreateModule = await import(pathToFileURL(openCreateFile).href) as typeof createModule;
  const openUpdateModule = await import(pathToFileURL(openUpdateFile).href) as typeof updateModule;
  const runtime = createMemoryDataRuntime();
  const ctx = createRequestContext(runtime, { sandbox: true, moduleId: 'agendaClinica' });
  const seen: string[] = [];
  const entity = ctx.mdm.entity as unknown as Record<string, (...args: never[]) => Promise<unknown>>;
  for (const name of ['findByDocument', 'create', 'attachRole']) {
    const original = entity[name];
    entity[name] = (async (...args: never[]) => {
      seen.push(name);
      return original.apply(ctx.mdm.entity, args);
    }) as typeof original;
  }
  const input = {
    details: {
      identification: { name: 'Ada', docType: 'Passport', docId: 'DOC1', countryCode: 'US' },
      base: { aliases: ['Ada'] },
    },
  };
  const first = await createModule.createPaciente(input, ctx);
  assert.equal(seen.includes('findByDocument') && seen.includes('create') && seen.includes('attachRole'), true);
  const before = seen.filter(name => name === 'create').length;
  const second = await createModule.createPaciente(input, ctx);
  assert.equal(second.id, first.id);
  assert.equal(seen.filter(name => name === 'create').length, before);
  const openRuntime = createMemoryDataRuntime();
  const openCtx = createRequestContext(openRuntime, { sandbox: true, moduleId: 'agendaClinica' });
  const openSeen: string[] = [];
  const openEntity = openCtx.mdm.entity as unknown as Record<string, (...args: never[]) => Promise<unknown>>;
  const openCreateFn = openEntity.create;
  openEntity.create = (async (...args: never[]) => {
    openSeen.push('create');
    return openCreateFn.apply(openCtx.mdm.entity, args);
  }) as typeof openCreateFn;
  await openCreateModule.createPaciente(input, openCtx);
  await openCreateModule.createPaciente(input, openCtx);
  assert.equal(openSeen.length, 2);

  const seeded = await ctx.mdm.entity.create({
    details: { subtype: 'Person', name: 'Ada', countryCode: 'US', docType: 'Passport', docId: 'DOCprof' },
  });
  const patch = {
    id: seeded.mdmId,
    version: seeded.version,
    details: { identification: { name: 'Ada Updated', docType: 'Passport', docId: 'DOCprof', countryCode: 'US' }, person: { occupation: 'guide' } },
  };
  const saved = await updateModule.updateProfissional(patch, ctx);
  assert.equal(saved.id, seeded.mdmId);
  await assert.rejects(
    () => updateModule.updateProfissional(patch, ctx),
    (error: { code?: string }) => error.code === 'CONCURRENCY_CONFLICT',
  );
  const stale = await openUpdateModule.updateProfissional({ ...patch, id: saved.id, version: seeded.version }, ctx);
  assert.equal(stale.id, seeded.mdmId);
  rmSync(dir, { recursive: true, force: true });

  const hidden = await emitBehavior('implement.usecase', definitionFor('updateProfissional'), 'l1/agendaClinica/updateProfissional.ts', async ref => {
    const text = await read(ref);
    if (text === null) return null;
    if (ref.includes('/ontology/') || ref.endsWith('/mdm.defs.ts')) return text.replaceAll('"writePrecondition": true', '"writePrecondition": false');
    return text;
  });
  assert.equal('code' in hidden, false);
  if (!('code' in hidden)) {
    assert.match(hidden.source, /PRECONDITION_UNDECLARED/);
    assert.equal(hidden.source.includes('enforce:version'), false);
  }
});

void test('a resolved scope path filters the list and an injected field does not widen it', async () => {
  const read = async (ref: string) => {
    const found = [...FIXTURES.values()].find(item => item.defPath === ref);
    const match = /^_(\d+)_\/(.+)$/.exec(ref);
    const disk = !found && match
      ? readFileSync(match[1] === '102047' ? resolveFixtureFile(join(AGENDA_CLINICA_F35E28A, match[2])) : join(ROOT, `mls-${match[1]}`, match[2]), 'utf8')
      : null;
    if (!found && disk === null) return null;
    if (!ref.endsWith('/accessScope.defs.ts')) return found?.text ?? disk;
    const base = found?.text ?? disk ?? '';
    return base.replace(
      /"grantId": "profissionalAgendaDiaria"[\s\S]*?"pending": "ACCESS_ANCHOR"/,
      block => block
        .replace('"anchorEntity": "Paciente"', '"anchorEntity": "Profissional"')
        .replace('"to": "Paciente"', '"to": "Profissional"')
        .replace('"field": "Consulta.patientId"', '"field": "Consulta.professionalId"')
        .replace('"pending": "ACCESS_ANCHOR"', '"pending": ""'),
    );
  };
  const list = definitionFor('listConsulta');
  const open = await caseBlock(list, callFor('listConsulta').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.qryListConsulta',
    expect: { ruleId: null },
  }, read);
  assert.equal(open, null);
  const coverage = await caseBlock(list, callFor('listConsulta').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.qryListConsulta',
    expect: { ruleId: 'professionalOwnAppointment' },
  }, read);
  assert.equal(coverage?.gap, 'APPLICABILITY_UNDECLARED');
  const missing = await caseBlock(list, callFor('listConsulta').unit.defPath, {
    routine: 'agendaClinica.consultas_profissional.qryListConsulta',
    expect: { ruleId: null },
  }, async ref => {
    const text = await read(ref);
    if (text === null || !ref.endsWith('/accessScope.defs.ts')) return text;
    return text.replace(/"path": \[[\s\S]*?\],/, '"path": [],');
  });
  assert.equal(missing?.gap, 'ACCESS_ANCHOR');
  assert.equal(recordFieldFromGrant({
    scopeMode: 'own',
    anchorEntity: 'Paciente',
    path: [{ entityId: 'Consulta', steps: [{ from: 'Consulta', to: 'Paciente', field: 'Consulta.patientId' }], pending: '' }],
  }), 'patientId');
  assert.equal(recordFieldFromGrant({
    scopeMode: 'own',
    anchorEntity: 'Paciente',
    path: [{ from: 'Consulta', to: 'Paciente', field: 'Consulta.patientId' }],
  }), 'patientId');
  assert.equal(recordFieldFromGrant({ scopeMode: 'own', anchorEntity: 'Profissional', path: [] }), '');
  assert.equal(recordFieldFromGrant({
    scopeMode: 'own',
    anchorEntity: 'Profissional',
    path: [
      { from: 'Consulta', to: 'Profissional', field: 'Consulta.professionalId' },
      { from: 'Consulta', to: 'Paciente', field: 'Consulta.patientId' },
    ],
  }), '');

  const page = [...FIXTURES.values()].find(item => item.definition.artifactId === 'consultas_profissional');
  assert.ok(page);
  const controller = await emitController(page.definition, 'l1/agendaClinica/consultas_profissional.ts', read);
  assert.equal('code' in controller, false, 'code' in controller ? controller.detail : '');
  if ('code' in controller) return;
  assert.match(controller.source, /enforce:scope/);
  const stripped = withoutScopeChecks(controller.source);
  assert.equal(stripped.removed, 1);
  const resolveGrant = () => ({ grantId: 'g', scopeMode: 'own', recordField: 'professionalId', pending: '' });
  const apply = (source: string) => new Function('resolveGrant', `${source.slice(source.indexOf('function scopeParams'), source.indexOf('function authorize'))
    .replaceAll(': unknown', '')
    .replaceAll(': { sessionContext?: { actorId?: string } }', '')
    .replaceAll(': readonly string[]', '')
    .replaceAll(': Record<string, unknown>', '')
    .replaceAll(' as Record<string, unknown>', '')} return scopeParams;`)(resolveGrant) as (
    params: Record<string, string>,
    ctx: { sessionContext: { actorId: string } },
    grantIds: string[],
  ) => Record<string, string>;
  const scoped = apply(controller.source)({ professionalId: 'professional-2' }, { sessionContext: { actorId: 'professional-1' } }, ['g']);
  assert.equal(scoped.professionalId, 'professional-1');
  const widened = apply(stripped.source)({ professionalId: 'professional-2' }, { sessionContext: { actorId: 'professional-1' } }, ['g']);
  assert.equal(widened.professionalId, 'professional-2');

  const emitted = await emitBehavior('implement.usecase', list, 'l1/agendaClinica/listConsulta.ts', read);
  const port = await emitBehavior('implement.repositoryPort', definitionFor('ConsultaRepository'), 'l1/agendaClinica/consultaRepository.ts', read);
  assert.equal('code' in emitted || 'code' in port, false);
  if ('code' in emitted || 'code' in port) return;
  assert.equal(emitted.source.includes('attendanceNote'), false);
  const dir = mkdtempSync(join(tmpdir(), 'm1-10-scope-'));
  writeFileSync(join(dir, 'listConsulta.ts'), emitted.source);
  writeFileSync(join(dir, 'consultaRepository.ts'), port.source);
  const loaded = await import(pathToFileURL(join(dir, 'listConsulta.ts')).href) as {
    listConsulta: (input: Record<string, string>, ctx: unknown, ports: Record<string, unknown>) => Promise<Array<Record<string, string>>>;
  };
  const memory = await import(pathToFileURL(join(dir, 'consultaRepository.ts')).href) as {
    resetMemory: (seed?: Record<string, unknown>[]) => void;
    pendingConsultaRepository: unknown;
  };
  const rows = [
    { id: 'consulta-1', professionalId: 'professional-1', patientId: 'patient-1', scheduledAt: '2026-09-25T13:00:00.000Z', status: 'scheduled', version: 1, details: { attendanceNote: '' } },
    { id: 'consulta-2', professionalId: 'professional-2', patientId: 'patient-2', scheduledAt: '2026-09-25T15:00:00.000Z', status: 'scheduled', version: 1, details: { attendanceNote: '' } },
  ];
  const ports = { consultaRepository: memory.pendingConsultaRepository };
  memory.resetMemory(rows);
  const own = await loaded.listConsulta(scoped, {}, ports);
  assert.deepEqual(own.map(row => row.id), ['consulta-1']);
  memory.resetMemory(rows);
  const foreign = await loaded.listConsulta(widened, {}, ports);
  assert.deepEqual(foreign.map(row => row.id), ['consulta-2']);
  rmSync(dir, { recursive: true, force: true });
});

void test('a local table update is derived and proved on a copy of the client defs', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'm1-17-update-'));
  const client = join(ROOT, `mls-${102047}`);
  const archived = spawnSync('git', ['-C', client, 'archive', '11301dd', '--', 'l1/agendaClinica', 'l2/agendaClinica/web/contracts/consultas.defs.ts', 'l4/agendaClinica/ontology/Consulta.defs.ts', 'l4/agendaClinica/rules.defs.ts'], { maxBuffer: 32 * 1024 * 1024 });
  assert.equal(archived.status, 0, archived.stderr?.toString());
  const extracted = spawnSync('tar', ['-x', '-C', dir], { input: archived.stdout });
  assert.equal(extracted.status, 0, extracted.stderr?.toString());
  const project = dir;
  const refs = [
    '_102047_/l1/agendaClinica/layer_2_application/usecases/updateConsulta.defs.ts',
    '_102047_/l1/agendaClinica/layer_2_application/ports/consultaRepository.defs.ts',
    '_102047_/l1/agendaClinica/layer_3_domain/entities/consulta.defs.ts',
    '_102047_/l2/agendaClinica/web/contracts/consultas.defs.ts',
    '_102047_/l4/agendaClinica/ontology/Consulta.defs.ts',
    '_102047_/l4/agendaClinica/rules.defs.ts',
  ];
  const copy = new Map(refs.map(ref => [ref, readFileSync(join(project, ref.slice('_102047_/'.length)), 'utf8')]));
  const contractRef = refs[3];
  copy.set(contractRef, copy.get(contractRef)!.replace(/export interface UpdateConsultaInput[\s\S]*?(?=\nexport)/,
    'export interface UpdateConsultaInput {\n  "id": string;\n  "details": {\n    "telephoneConfirmation": {\n      "confirmedAt": string;\n    };\n  };\n}\n'));
  const loaded = definitionAt(copy, 'updateConsulta');
  assert.ok(loaded);
  assert.equal(behaviorNeedsLlm(loaded.definition), false);
  const readCopy = async (ref: string) => copy.get(ref) ?? null;
  const emitted = await emitBehavior('implement.usecase', loaded.definition, 'l1/agendaClinica/updateConsulta.ts', readCopy);
  assert.equal('code' in emitted, false, 'code' in emitted ? emitted.detail : '');
  if ('code' in emitted) return;
  assert.equal(emitted.source.includes('enforce:storage'), false);
  assert.equal(emitted.source.includes('enforce:version'), false);
  assert.equal(emitted.source.includes('RULE_UNBOUND'), false);
  const versionGap = await caseBlock(loaded.definition, loaded.defPath, {
    routine: '',
    expect: { ruleId: 'expectedVersion' },
  }, readCopy);
  assert.equal(versionGap?.gap, 'PRECONDITION_UNDECLARED');

  const file = join(dir, 'updateConsulta.ts');
  writeFileSync(file, emitted.source);
  const usecase = await import(pathToFileURL(file).href) as {
    updateConsulta: (input: Record<string, unknown>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
  const memory = await import(pathToFileURL(join(project, 'l1/agendaClinica/layer_2_application/ports/consultaRepository.ts')).href) as {
    resetMemory: (seed?: Record<string, unknown>[]) => void;
    pendingConsultaRepository: unknown;
  };
  const details = { telephoneConfirmation: { confirmedAt: '' }, attendanceNote: '' };
  const first = { id: 'row-1', version: 1, pacienteId: 'p1', profissionalId: 'pro-1', scheduledAt: '2026-09-26T13:00:00.000Z', status: 'scheduled', details };
  const second = { id: 'row-2', version: 1, pacienteId: 'p2', profissionalId: 'pro-1', scheduledAt: '2026-09-26T15:00:00.000Z', status: 'scheduled', details };
  const ports = { consultaRepository: memory.pendingConsultaRepository };
  const ctx = {};
  const inputFor = (row: Record<string, unknown>, patch: Record<string, unknown>) => ({ ...row, ...patch });
  memory.resetMemory([first, second]);
  const saved = await usecase.updateConsulta(inputFor(first, { details: { telephoneConfirmation: { confirmedAt: '2026-09-26T12:00:00.000Z' } } }), ctx, ports);
  assert.equal(saved.id, 'row-1');
  assert.equal(saved.pacienteId, 'p1');
  assert.equal(saved.details.telephoneConfirmation.confirmedAt, '2026-09-26T12:00:00.000Z');
  assert.equal(saved.details.attendanceNote, first.details.attendanceNote);
  assert.equal(first.details.telephoneConfirmation.confirmedAt, '');
  assert.equal(saved.version, 1);
  memory.resetMemory([first]);
  const omitted = await usecase.updateConsulta({ id: first.id }, ctx, ports);
  assert.deepEqual(omitted.details, first.details, 'an absent patch value is not written as undefined');
  memory.resetMemory([first, second]);
  const unchanged = await usecase.updateConsulta(inputFor(first, { details: { telephoneConfirmation: { confirmedAt: '2026-09-26T12:00:00.000Z' } }, scheduledAt: second.scheduledAt }), ctx, ports);
  assert.equal(unchanged.scheduledAt, first.scheduledAt);
  memory.resetMemory([first]);
  await assert.rejects(
    () => usecase.updateConsulta(inputFor(first, { id: 'missing' }), ctx, ports),
    (error: { code?: string }) => error.code === 'NOT_FOUND',
  );
  const opened = withoutStorageChecks(emitted.source);
  assert.equal(opened.removed, 0);
  const openFile = join(dir, 'updateConsultaOpen.ts');
  writeFileSync(openFile, opened.source);
  const openUsecase = await import(pathToFileURL(openFile).href) as typeof usecase;
  memory.resetMemory([first, second]);
  const collided = await openUsecase.updateConsulta(inputFor(first, { details: { telephoneConfirmation: { confirmedAt: '2026-09-26T12:00:00.000Z' } }, scheduledAt: second.scheduledAt }), ctx, ports);
  assert.equal(collided.scheduledAt, first.scheduledAt);

  const marked = new Map(copy);
  const ontology = '_102047_/l4/agendaClinica/ontology/Consulta.defs.ts';
  marked.set(ontology, (marked.get(ontology) ?? '').replace('"version": {', '"version": { "writePrecondition": true,'));
  const withVersion = structuredClone(loaded.definition);
  const fn = withVersion.data.functions;
  if (Array.isArray(fn) && isRecord(fn[0]) && Array.isArray(fn[0].input)) {
    fn[0].input.push({ name: 'version', type: 'number', fieldRef: 'Consulta.version' });
  }
  const readMarked = async (ref: string) => marked.get(ref) ?? null;
  const versioned = await emitBehavior('implement.usecase', withVersion, 'l1/agendaClinica/updateConsulta.ts', readMarked);
  assert.equal('code' in versioned, false, 'code' in versioned ? versioned.detail : '');
  if ('code' in versioned) return;
  assert.match(versioned.source, /enforce:version/);
  const versionFile = join(dir, 'updateConsultaVersion.ts');
  writeFileSync(versionFile, versioned.source);
  const versionUsecase = await import(pathToFileURL(versionFile).href) as typeof usecase;
  memory.resetMemory([{ ...first, version: 2 }, second]);
  const bumped = await versionUsecase.updateConsulta(inputFor(first, { version: 2, pacienteId: 'p8' }), ctx, ports);
  assert.equal(bumped.version, 3);
  memory.resetMemory([{ ...first, version: 2 }, second]);
  await assert.rejects(
    () => versionUsecase.updateConsulta(inputFor(first, { version: 1 }), ctx, ports),
    (error: { code?: string; statusCode?: number }) => error.code === 'CONCURRENCY_CONFLICT',
  );

  const renamed = new Map<string, string>();
  for (const [ref, text] of copy) {
    const nextText = text
      .replaceAll('consultaHorarioProfissionalUnico', 'r1')
      .replaceAll('profissionalId', 'agentId')
      .replaceAll('Consulta', 'Visita')
      .replaceAll('agendaClinica', 'visitaBook');
    const nextRef = ref
      .replaceAll('consultaHorarioProfissionalUnico', 'r1')
      .replaceAll('profissionalId', 'agentId')
      .replaceAll('Consulta', 'Visita')
      .replaceAll('agendaClinica', 'visitaBook');
    renamed.set(nextRef, nextText);
  }
  const renamedUpdate = definitionAt(renamed, 'updateVisita');
  const renamedPort = definitionAt(renamed, 'VisitaRepository');
  assert.ok(renamedUpdate && renamedPort);
  const readRenamed = async (ref: string) => renamed.get(ref) ?? null;
  const renamedUse = await emitBehavior('implement.usecase', renamedUpdate.definition, 'l1/visitaBook/updateVisita.ts', readRenamed);
  const renamedRepo = await emitBehavior('implement.repositoryPort', renamedPort.definition, 'l1/visitaBook/visitaRepository.ts', readRenamed);
  assert.equal('code' in renamedUse, false, 'code' in renamedUse ? renamedUse.detail : '');
  assert.equal('code' in renamedRepo, false, 'code' in renamedRepo ? renamedRepo.detail : '');
  if ('code' in renamedUse || 'code' in renamedRepo) return;
  assert.equal(/agendaClinica|Consulta|profissionalId|consultaHorarioProfissionalUnico/.test(renamedUse.source), false);
  writeFileSync(join(dir, 'updateVisita.ts'), renamedUse.source);
  writeFileSync(join(dir, 'visitaRepository.ts'), renamedRepo.source);
  const visita = await import(pathToFileURL(join(dir, 'updateVisita.ts')).href) as {
    updateVisita: (input: Record<string, unknown>, ctx: unknown, ports: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
  const visitaMemory = await import(pathToFileURL(join(dir, 'visitaRepository.ts')).href) as {
    resetMemory: (seed?: Record<string, unknown>[]) => void;
    pendingVisitaRepository: unknown;
  };
  const visitaPorts = { visitaRepository: visitaMemory.pendingVisitaRepository };
  const visitaRow = { ...first, agentId: 'pro-1' };
  const visitaOther = { ...second, agentId: 'pro-1' };
  delete (visitaRow as { profissionalId?: string }).profissionalId;
  delete (visitaOther as { profissionalId?: string }).profissionalId;
  visitaMemory.resetMemory([visitaRow, visitaOther]);
  const visitaSaved = await visita.updateVisita({ ...visitaRow, details: { telephoneConfirmation: { confirmedAt: '2026-09-26T12:00:00.000Z' } }, scheduledAt: visitaOther.scheduledAt }, ctx, visitaPorts);
  assert.equal(visitaSaved.scheduledAt, visitaRow.scheduledAt);
  assert.equal((visitaSaved.details as { attendanceNote: string }).attendanceNote, visitaRow.details.attendanceNote);
  assert.equal((visitaSaved.details as { telephoneConfirmation: { confirmedAt: string } }).telephoneConfirmation.confirmedAt, '2026-09-26T12:00:00.000Z');
  rmSync(dir, { recursive: true, force: true });
});

function definitionFor(artifactId: string): M1Definition {
  return callFor(artifactId).definition as M1Definition;
}

function rewriteFixture(): Map<string, string> {
  const map = new Map<string, string>();
  const extras = [
    '_102047_/l4/agendaClinica/ontology/Consulta.defs.ts',
    '_102047_/l4/agendaClinica/rules.defs.ts',
    '_102047_/l2/agendaClinica/web/contracts/consultas_recepcionista.defs.ts',
    '_102047_/l2/agendaClinica/web/contracts/consultas_profissional.defs.ts',
    '_102047_/l2/agendaClinica/web/contracts/pacientes.defs.ts',
    '_102047_/l2/agendaClinica/web/contracts/profissionais.defs.ts',
  ];
  const sources = [...FIXTURES.values()].map(item => ({ key: '', text: item.text }));
  for (const ref of extras) {
    const match = /^_(\d+)_\/(.+)$/.exec(ref);
    if (!match) continue;
    const disk = match[1] === '102047' ? resolveFixtureFile(join(AGENDA_CLINICA_F35E28A, match[2])) : join(ROOT, `mls-${match[1]}`, match[2]);
    sources.push({ key: ref, text: readFileSync(disk, 'utf8') });
  }
  for (const source of sources) {
    const rewritten = source.text
      .replaceAll('uniqueProfessionalSchedule', 'r1')
      .replaceAll('professionalId', 'agentId')
      .replaceAll('Consulta', 'Visita')
      .replaceAll('agendaClinica', 'visitaBook');
    const marked = /fileReference="([^"]+)"/.exec(rewritten);
    const key = marked?.[1] || source.key
      .replaceAll('uniqueProfessionalSchedule', 'r1')
      .replaceAll('professionalId', 'agentId')
      .replaceAll('Consulta', 'Visita')
      .replaceAll('agendaClinica', 'visitaBook');
    if (key) map.set(key, rewritten);
  }
  return map;
}

function definitionAt(map: Map<string, string>, artifactId: string): { defPath: string; definition: M1Definition } | null {
  for (const [defPath, text] of map) {
    if (!text.includes('export const definition')) continue;
    const parsed = parseDefinitionSource(text);
    if (!('definition' in parsed)) continue;
    const definition = readDefinition(parsed.definition);
    if ('issues' in definition || definition.artifactId !== artifactId) continue;
    return { defPath, definition };
  }
  return null;
}

function callFor(artifactId: string, modelText: string | null = null): HandlerCall {
  const found = [...FIXTURES.values()].find(item => item.definition.artifactId === artifactId);
  if (!found) throw new Error(artifactId);
  const handler = handlerFor(found.definition.artifactType, 'implement');
  if (!handler) throw new Error(found.definition.artifactType);
  const unit: SimulatedUnit = {
    defPath: found.defPath,
    artifactType: found.definition.artifactType,
    artifactId: found.definition.artifactId,
    action: 'generate',
    reason: '',
    handlerId: handler.id,
    needsLlm: false,
    unresolved: [],
    contextRefs: [],
    blockedBy: [],
    prompt: '',
  };
  return {
    handler,
    unit,
    definition: found.definition,
    read,
    catalogRef: CATALOG_REF,
    repair: false,
    signal: new AbortController().signal,
    eventId: found.defPath,
    profile: decideProfile('development', true),
    modelText,
  };
}

async function read(ref: string): Promise<string | null> {
  if (ref === CATALOG_REF) return CATALOG;
  const fixture = FIXTURES.get(ref);
  if (fixture) return fixture.text;
  const match = /^_(\d+)_\/(.+)$/.exec(ref);
  if (!match) return null;
  try {
    if (match[1] === '102047') return readFileSync(resolveFixtureFile(join(AGENDA_CLINICA_F35E28A, match[2])), 'utf8');
    return readFileSync(join(ROOT, `mls-${match[1]}`, match[2]), 'utf8');
  } catch {
    return null;
  }
}

function sourceOf(outcome: { files: Record<string, string> }): string {
  return Object.values(outcome.files)[0] ?? '';
}

function compile(rows: Array<[string, string]>): string {
  sweepRepoRootScratch();
  const dir = join(ROOT, '.generated', `.m1-06-out-${process.pid}`);
  const config = join(ROOT, `.tsconfig.m1-06-${process.pid}.json`);
  try {
    const files: string[] = [];
    for (const [name, source] of rows) {
      const full = join(dir, name);
      mkdirSync(dirname(full), { recursive: true });
      writeFileSync(full, source);
      files.push(relative(ROOT, full));
    }
    const base = readFileSync(join(ROOT, 'tsconfig.base.json'), 'utf8');
    const clinic = join(dir, 'clinic');
    const consistent = join(dir, 'consistent');
    copyFixtureSources(AGENDA_CLINICA_F35E28A, clinic);
    copyFixtureSources(join(HERE, '../../../agentDefsL1/fixtures/agendaClinica-3f4f677'), consistent);
    const paths: Record<string, string[]> = {
      '/_102047_/l1/agendaClinica/layer_3_domain/entities/*': [`./${relative(ROOT, dir)}/*`],
      '/_102047_/l1/agendaClinica/layer_2_application/ports/*': [`./${relative(ROOT, dir)}/*`],
      '/_102047_/l1/agendaClinica/layer_2_application/usecases/*': [`./${relative(ROOT, dir)}/*`],
      '/_102047_/l2/agendaClinica/web/contracts/agenda.defs.js': [`./${relative(ROOT, join(consistent, 'l2/agendaClinica/web/contracts/agenda.defs.ts'))}`],
    };
    for (const id of new Set([...base.matchAll(/\/_(\d+)_\//g)].map(match => match[1]))) {
      const key = `/_${id}_/*`;
      if (!paths[key]) {
        paths[key] = id === '102047'
          ? [`./${relative(ROOT, clinic)}/*`]
          : [`./mls-${id}/*`];
      }
    }
    writeFileSync(config, `${JSON.stringify({
      extends: './tsconfig.base.json',
      compilerOptions: { noEmit: true, paths },
      files: files.map(file => `./${file}`),
    }, null, 2)}\n`);
    const tsc = join(ROOT, 'node_modules/typescript/bin/tsc');
    const result = spawnSync(process.execPath, [tsc, '-p', config, '--pretty', 'false'], { cwd: ROOT, encoding: 'utf8' });
    return `${result.stdout ?? ''}\n${result.stderr ?? ''}`.split('\n').filter(line => line.includes('.m1-06-out')).join('\n').trim();
  } finally {
    rmSync(dir, { recursive: true, force: true });
    rmSync(config, { force: true });
    sweepRepoRootScratch();
  }
}

function sweepRepoRootScratch(): void {
  for (const name of readdirSync(ROOT)) {
    if (name.startsWith('.m1-')) rmSync(join(ROOT, name), { recursive: true, force: true });
  }
}

function loadFixtures(dir: string): Map<string, { defPath: string; text: string; definition: M1Definition }> {
  const map = new Map<string, { defPath: string; text: string; definition: M1Definition }>();
  const walk = (current: string) => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      const path = join(current, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.name.endsWith('.defs.ts') || entry.name.endsWith('.defs.txt')) {
        const text = readFileSync(path, 'utf8');
        const parsed = parseDefinitionSource(text);
        if (!('definition' in parsed)) throw new Error(parsed.issues.join('; '));
        const definition = readDefinition(parsed.definition);
        if ('issues' in definition) throw new Error(`${path} ${definition.issues.join('; ')}`);
        const marked = /fileReference="([^"]+)"/.exec(text);
        const defPath = marked?.[1] ?? '';
        if (!defPath) throw new Error(`no file reference in ${path}`);
        map.set(defPath, { defPath, text, definition });
      }
    }
  };
  walk(dir);
  return map;
}
