/// <mls shortName="agentEndpointLayer4Entity" project="102021" enhancement="_blank" folder="" />

 import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];