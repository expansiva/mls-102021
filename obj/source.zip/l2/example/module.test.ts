/// <mls shortName="module" project="102021" enhancement="_blank" folder="example" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];