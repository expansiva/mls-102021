# Skill: applicationUsecase → `layer_2_application/usecases/{usecase}.ts`

Generate the usecase: it decides WHAT happens (validations, state transitions, orchestration). It
imports the DOMAIN and the repository PORT type, resolves the concrete adapter via
`resolveRepository`, applies the rules, and NEVER touches `ctx.data` (except the single
`ctx.data.runInTransaction` wrapper for multi-aggregate writes). Export the function + its Input/Output
types (the controller imports these). Use `data.functionName`, `data.ports`, `data.rulesApplied`,
`data.steps` from the defs.

## Golden example (compiles)

```ts
/// <mls fileReference="_{project}_/l1/{module}/layer_2_application/usecases/createOrder.ts" enhancement="_blank"/>
import { AppError, type RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { resolveRepository } from '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';
import type { IOrderRepository } from '/_{project}_/l1/{module}/layer_2_application/ports/orderRepository.js';
import type { Order, OrderItem, OrderType } from '/_{project}_/l1/{module}/layer_3_domain/entities/order.js';
import { orderRequiresItem, recomputeOrderTotal } from '/_{project}_/l1/{module}/layer_3_domain/entities/order.js';

export interface CreateOrderItemInput { menuItemId: string; quantity: number; unitPrice: number; observations?: string; }
export interface CreateOrderInput { dailyShiftId: string; orderType: OrderType; tableId?: string; customerName?: string; items: CreateOrderItemInput[]; }
export interface CreateOrderOutput { order: Order; }

export async function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput> {
  const orders = resolveRepository<IOrderRepository>(ctx, 'Order');
  const now = ctx.clock.nowIso();

  const items: OrderItem[] = (input.items ?? []).map((it) => ({
    id: ctx.idGenerator.newId(), menuItemId: it.menuItemId, kitchenTicketId: null,
    quantity: it.quantity, unitPrice: it.unitPrice, totalPrice: it.unitPrice * it.quantity,
    observations: it.observations ?? null, status: 'new', createdAt: now, updatedAt: now,
  }));

  const order: Order = {
    orderId: ctx.idGenerator.newId(), dailyShiftId: input.dailyShiftId, tableId: input.tableId ?? null,
    kitchenTicketId: null, orderType: input.orderType, status: 'draft', totalAmount: recomputeOrderTotal(items),
    notes: null, customerName: input.customerName ?? null, customerPhone: null, numberOfGuests: null,
    closedAt: null, cancelledAt: null, cancellationReason: null, items, createdAt: now, updatedAt: now,
  };

  if (!orderRequiresItem(order)) {
    throw new AppError('VALIDATION_ERROR', 'orderRequiresItem: o pedido precisa de ao menos um item.', 400, { ruleId: 'orderRequiresItem' });
  }

  const saved = await orders.save(order);
  return { order: saved };
}
```

## Rules

- Generate ONE exported `async function` per entry in `data.functions` (a usecase may export SEVERAL),
  signature `(ctx: RequestContext, input: {inputTypeName}): Promise<{outputTypeName}>`.
- Build the `{inputTypeName}` / `{outputTypeName}` interfaces from the function's EXPLICIT
  `data.functions[].input[]` / `output[]` fields (name + type, `?` when `required:false`) — do NOT
  invent fields. Export both interfaces (the controller imports them).
- Resolve every repository with `resolveRepository<I{Entity}Repository>(ctx, '{Entity}')`. NEVER import
  an adapter. Import record/union types and invariants from the domain entity.
- Apply `rulesApplied`: validate via domain invariants; throw `AppError('VALIDATION_ERROR'|'CONFLICT', …)`.
- Lifecycle: read current state, check the domain transition (e.g. `canTransition*`), then `save`.
- Multi-aggregate writes go inside one `ctx.data.runInTransaction(async (tx) => { ... })` — this is the
  ONLY `ctx.data` allowed here; pass `tx` only to repository calls if the adapter supports it.
- Ids via `ctx.idGenerator.newId()`, timestamps via `ctx.clock.nowIso()`.

## Child-entity operations (embedded members)

An operation may target a CHILD entity that is embedded in a parent aggregate (it lives in the parent's
collection, stored in `details` JSONB — e.g. `OrderItem` inside `Order`). There is **no child
repository**. The defs gives you the parent in `data.ports` / `data.functions[].ports`. Pattern:

1. resolve the PARENT port (`resolveRepository<I{Parent}Repository>(ctx, '{Parent}')`);
2. load the parent aggregate (the input carries the parent id, e.g. `orderId`, plus the child id);
3. find and mutate the child inside the parent's collection;
4. `save(parent)`.

Never call a method like `findByOrderItemId` on the parent port and never import a child port — those do
not exist. If you need the parent id to locate the child, it is part of the function input.

## MDM references (master data, accessed by id)

Entities listed in `data.mdmRefs` are MDM master data (people, companies, vehicles, menus, categories,
tables). They live in the shared 102034 MDM store, NOT in this module: there is **no local port, entity
or table** for them, and you must NEVER `resolveRepository` one. A transaction references them **by id
only** — the id comes in the function input (e.g. `tableId`, `menuCategoryId`).

Read a master-data record by id via the runtime (the one ctx.data call besides `runInTransaction`):

```ts
const doc = await ctx.data.mdmDocument.get({ mdmId: input.tableId });
if (!doc) throw new AppError('NOT_FOUND', `MDM record not found: ${input.tableId}`, 404, { mdmId: input.tableId });
const table = doc.details; // the master-data payload
```

`mdmDocument`: `get({ mdmId })`, `getMany({ mdmIds })`, `put({ record })`, `delete({ mdmId })`. Often
just storing/passing the id is enough — only fetch the record when you actually need its fields. Do not
import any `/_{project}_/.../ports/{mdm}Repository` — it does not exist.

### Writing a module-owned MDM record (cadastral data only)

When `data.kind === 'mdm'` and the operation creates/updates the record, write through `mdmDocument.put`.
The stored `details` is an `MdmDetailRecord` with REQUIRED base fields — you cannot put a bare entity
object. Keep the base fields valid and place ALL of the module's own columns under the module-namespace
key (`details[<module>]`), which `BaseMdmDetailRecord` allows via `[moduleNamespace: string]: unknown`:

```ts
// status MUST be an MdmStatus: 'Active' | 'Inactive' | 'Merged' | 'Blocked' (map your domain lifecycle).
// subtype MUST be an MdmSubtype: 'Product' (menu item/category), 'AssetGeneric' (table/furniture),
// 'Location' (room), 'Person' | 'Company' | ... — pick the closest one.
const now = ctx.clock.nowIso();
// UPDATE: preserve the existing record, override only what changed.
const doc = await ctx.data.mdmDocument.get({ mdmId: input.menuCategoryId });
if (!doc) throw new AppError('NOT_FOUND', `MDM record not found: ${input.menuCategoryId}`, 404, { mdmId: input.menuCategoryId });
await ctx.data.mdmDocument.put({
  record: {
    ...doc,
    details: {
      ...doc.details,
      name: input.name ?? doc.details.name,
      status: input.status === 'inactive' ? 'Inactive' : 'Active',
      updatedAt: now,
      cafeFlow: { ...(doc.details.cafeFlow as object ?? {}), ...moduleFields }, // entity columns in JSONB
    },
  },
  expectedVersion: doc.version,
});
```

For CREATE, build the full base (`mdmId`, `subtype`, `name`, `status`, `countryCode`, `tags: []`,
`aliases: []`, `contacts: []`, `relationshipRefs: {}`, `addresses: []`, `createdAt`, `updatedAt`,
`<module>: {…}`) and `put({ record: { mdmId, version: 1, details } })`.

NEVER store operational/transactional state (occupancy, movement, balances, `'occupied'`/`'available'`)
in an MDM record — that is NOT cadastral data and belongs to a local `core` entity with its own table.
The MDM `status` is always one of the four cadastral `MdmStatus` values.

## Emitting events (append-only history)

`data.eventWrites` lists events this usecase MUST record whenever the matching transition happens, so the
history survives a restart instead of living only in memory. For each entry:

- **persisted** (`purpose` telemetry/audit): its port is already in `data.ports`. Resolve it
  (`resolveRepository<I{Event}Repository>(ctx, '{Event}')`), build the event record (new id via
  `ctx.idGenerator.newId()`, owner id, the new status/values, timestamp via `ctx.clock.nowIso()`) and
  `append(record)` it **inside the same `ctx.data.runInTransaction` as the aggregate write** — so the
  state change and its event commit together. Never `update`/`delete` an event.
- **reaction** (not persisted, `port` is null): there is no table — publish the trigger on the platform
  queue (`ctx.data.pgQueue.publish({ topic, payload })`) instead of a port; do not store local history.

Do NOT declare an event object and leave it unused: if `eventWrites` lists it, it must actually be
appended/enqueued on the transition.

## `steps` are guidance, not a contract

`data.steps` (and `data.functions[].steps`) are hints about intent. The CONTRACT you must satisfy is
`functions[].input` / `output` / `ports`. Do not invent repository methods or fields to satisfy a step
literally — implement the step using the declared input/output and the imported port + domain.
