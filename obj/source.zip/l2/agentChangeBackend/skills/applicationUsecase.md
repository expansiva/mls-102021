# Skill: applicationUsecase → `layer_2_application/usecases/{usecase}.ts`

Generate the usecase: it decides WHAT happens (validations, state transitions, orchestration). It
imports the DOMAIN and the repository PORT type, resolves the concrete adapter via
`resolveRepository`, applies L4 rules inline, and only touches `ctx.data` for the single
`ctx.data.runInTransaction` wrapper. MDM master data is accessed only through `ctx.mdm`.
Export the function + its Input/Output
types (the controller imports these). Use `data.functionName`, `data.ports`, `data.rulesApplied`,
`data.steps` from the defs.

## Golden example (compiles)

```ts
/// <mls fileReference="_{project}_/l1/{module}/layer_2_application/usecases/createOrder.ts" enhancement="_blank"/>
import { AppError, type RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { resolveRepository } from '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';
import type { IOrderRepository } from '/_{project}_/l1/{module}/layer_2_application/ports/orderRepository.js';
import type { Order, OrderItem, OrderType } from '/_{project}_/l1/{module}/layer_3_domain/entities/order.js';
import { orderRequiresItem, recomputeOrderTotal } from '/_{project}_/l1/{module}/layer_3_domain/entities/order.js';

export interface CreateOrderItemInput { menuItemId: string; quantity: number; unitPrice: number; observations?: string; }
export interface CreateOrderInput { dailyShiftId: string; orderType: OrderType; tableId?: string; customerName?: string; items: CreateOrderItemInput[]; }
export interface CreateOrderOutput { order: Order; }

export async function createOrder(ctx: RequestContext, input: CreateOrderInput): Promise<CreateOrderOutput> {
  const orders = resolveRepository<IOrderRepository>(ctx, 'Order');
  const now = ctx.clock.nowIso();

  const items: OrderItem[] = (input.items ?? []).map((it) => ({
    id: ctx.idGenerator.newId(), menuItemId: it.menuItemId, kitchenTicketId: null,
    quantity: it.quantity, unitPrice: it.unitPrice, totalPrice: it.unitPrice * it.quantity,
    observations: it.observations ?? null, status: 'new', createdAt: now, updatedAt: now,
  }));

  const order: Order = {
    orderId: ctx.idGenerator.newId(), dailyShiftId: input.dailyShiftId, tableId: input.tableId ?? null,
    kitchenTicketId: null, orderType: input.orderType, status: 'draft', totalAmount: recomputeOrderTotal(items),
    notes: null, customerName: input.customerName ?? null, customerPhone: null, numberOfGuests: null,
    closedAt: null, cancelledAt: null, cancellationReason: null, items, createdAt: now, updatedAt: now,
  };

  if (!orderRequiresItem(order)) {
    throw new AppError('VALIDATION_ERROR', 'orderRequiresItem: the order must have at least one item.', 400, { ruleId: 'orderRequiresItem' });
  }

  const saved = await orders.save(order);
  return { order: saved };
}
```

## Rules

- Generate ONE exported `async function` per entry in `data.functions` (a usecase may export SEVERAL),
  signature `(ctx: RequestContext, input: {inputTypeName}): Promise<{outputTypeName}>`.
- Build the `{inputTypeName}` interface from the function's EXPLICIT `data.functions[].input[]` fields
  (name + type, `?` when `required:false`) — do NOT invent fields. Export it (the controller imports it).
- Build the `{outputTypeName}` interface from `data.functions[].outputShape` when present — it is the
  CANONICAL wire shape declared by l4 and is AUTHORITATIVE: the interface MUST match it EXACTLY (same
  field names, same required-ness, same array/object nesting) and your implementation MUST return that
  shape. `outputShape` is `{ kind, fields[] }`; each field is `{ name, type, required, fieldRef?, item? }`.
  For a field with `type: 'array'` or `'object'` declare a named nested interface from its `item.fields`
  (e.g. `orders: DashboardOrder[]`, with `interface DashboardOrder { ... }`), one level deep. Fields with
  no `fieldRef` are computed/aggregate values you must produce in the body (e.g. `totalSales`,
  `topSellers`). Do NOT add, drop or rename output fields — the frontend contract copies this same shape,
  so any deviation re-creates the FE×BE drift. If `outputShape` is absent (legacy), fall back to building
  `{outputTypeName}` from the flat `output[]` fields. Export the output interface(s).
- The planned function IO was derived from the L4 v2 contract. Preserve that boundary: `accessPattern`
  decides list/get/lookup/commandInput; only inputs whose source is `userInput`, `selectedEntity` or
  `routeParam` are public required fields. Values whose source is `systemDefault`, `currentWorkspace`,
  `actorSession`, `businessContext` or `activeLifecycleInstance` are resolved server-side — they are NOT
  part of the public Input interface and are NOT required as user-entered params.
  - List controls the l4 declared as optional inputs — `search`, `sortBy` (closed enum of field ids),
    `sortOrder` (`'asc' | 'desc'`), `page`, `pageSize` — are public Input fields (`required: false`)
    and MUST be forwarded to `port.list({ search, sortBy, sortOrder, page, pageSize, …equality filters })`.
    Do not drop them. `sortBy` is never a free string: type it as the union from `inputs[].enumValues`.
    `page`/`pageSize` are numbers (they carry an explicit `type`). For a `paginated` outputShape,
    also call `port.count` with the same filter (no page) and return the CANONICAL envelope:
    `{ <arrayFieldName>: rows, total, page, pageSize }` using `resolveListPage` so `pageSize` is the
    **effective** size (default 20, cap 200, declared — never silent). The array field is the name
    declared on outputShape (e.g. `reservations`), NEVER `items`. A list whose l4 still says
    `pagination: 'none'` keeps returning the collection as today.
  - `businessContext.activeCompanyId` -> `ctx.sessionContext.activeCompanyId`
  - `businessContext.activeUnitId` -> `ctx.sessionContext.activeUnitId`
  - `activeLifecycleInstance` -> load the single OPEN/active instance of the lifecycle aggregate via its
    port (e.g. the one `Shift` with `status === 'open'`) and use its id; if none is open, honor the L4
    rule (empty result or the documented validation error) — never throw a "missing input" error for it.
  These context ids are resolved, not plain form fields. Apply a business-scope filter only on a field
  that exists in the model; never invent one (e.g. a `companyId` the entity does not declare) — record a
  modeling gap and skip the filter instead.
- **Person-scope is given, never derived.** When `data.scopeFilter` is present with `alreadyApplied` and
  `helperName`, import `{ helperName, rowInScope }` from
  `layer_2_application/scope/sessionScope.ts` and apply it: list results keep rows where
  `rowInScope(row, filter)` (a missing/empty `allowed` yields no rows — fail closed); get/update/delete
  throw `AppError('FORBIDDEN', …, 403)` when the loaded row is out of scope. Do NOT re-derive the
  predicate from grant prose or field names. `mode: custom` is the exception: emit
  `// scope: custom (prose) — <description>` and honour the description as a rule, with no person join.
  organization/public (no `scopeFilter`) means no person-scope filter.
- Resolve every repository with `resolveRepository<I{Entity}Repository>(ctx, '{Entity}')`. NEVER import
  an adapter. Import record/union types and invariants from the domain entity.
- Apply `rulesApplied` inline in this usecase file. L4 rules are authoritative prose/ids, not generated
  modules: NEVER import from `layer_3_domain/rules/*`, NEVER invent `{ruleId}Rules`/`comboRule` modules,
  and NEVER add a rule import that is not present in `dependsFiles`. Prefer existing domain invariants
  from imported domain entities; otherwise write a small local helper in this usecase file and include
  the `ruleId` in the thrown `AppError('VALIDATION_ERROR'|'CONFLICT', …)` details.
  HARD REQUIREMENT (deterministic gate): EVERY id in `rulesApplied` must appear VERBATIM somewhere in
  this file, or the output is rejected. A blocking rule is covered by the `AppError` details above; a
  NON-blocking rule (side-effect, filter, computed behavior — e.g. a cancellation that restores
  availability) must carry a `// rule: <ruleId>` comment on the exact line(s) that enforce it.
  A third kind exists and is the one most often mishandled: an **ASSUMPTION / SCOPE rule** — a premise or
  phase limitation rather than something the data can violate (a connected-experience assumption, "not
  supported in this phase", "single-currency for now"). It is satisfied ONLY by a `// rule: <ruleId>`
  comment where the premise is relevant — **NEVER by an `AppError`**.
  THE TEST, applied before writing anything: name the concrete input field or stored state of THIS
  operation that would violate the rule. If you can name it, enforce it (blocking or non-blocking). If you
  cannot — and note you may only have the rule ID, not its prose — do NOT invent a check to satisfy the
  gate: emit the comment. **When in doubt, comment.** A reject predicate (`throw` / `return false`)
  exists ONLY when a declared rule (`useRules` / `rulesApplied`) or a field constraint requires it.
  What you infer from product prose goes in a COMMENT, never as a rejection. An id that reads as a
  premise (`…Assumption`, `…Assumed`, `…OnlyPhase`, `…NotSupported`) is a strong signal, but the
  fallback above governs.
  Why this matters more than it looks: fabricating a validation to satisfy the gate produces a 400 that
  every caller hits, so the route can never return data and can never be tested. Observed in a generated
  query: it rejected all callers with `VALIDATION_ERROR` naming an assumption rule, which also blocked
  every later test on that page.
  Finally, never label an EXISTING guard with an assumption ruleId: a missing authenticated actor, an
  absent session or a permission gap is not an assumption violation. Use the rule that actually governs it
  (or state the plain reason) — a wrong ruleId on a real guard hides why the request was rejected.
- Lifecycle: read current state, check the domain transition (e.g. `canTransition*`), then `save`.
  When `data.lifecycle` is present, that matrix is the cycle — do not add a local allow-list that
  rejects a declared from→to pair, and do not treat a state as terminal if `allowed` still lists
  outgoing edges. The domain `*_STATUS_TRANSITIONS` map is attached from the same matrix.
  When `data.timeStates` is present, compute those states on the read path (get/list/projection)
  from the rule description named by `ruleRef`. Do not write them. Comment
  `// time status computed on read (2026-09-09): <state> via <ruleRef>`. List/panel evaluate the
  rule; never trust a stored field for a time state.
- Multi-aggregate writes go inside one `ctx.data.runInTransaction(async (tx) => { ... })`. When
  `data.writes` lists N entities, that single transaction covers all N local tables **and** every
  `mdmWrites` entry — never one transaction per entity. Do not use
  raw MDM primitives from `ctx.data` or `tx`; use `ctx.mdm` for MDM so document, index and
  `relationshipRefs` stay consistent.
- Ids via `ctx.idGenerator.newId()`, timestamps via `ctx.clock.nowIso()`.
- **User-facing `AppError` messages are English** (or come from i18n). Never hardcode Portuguese (or
  any other locale) in the message string — `code`/`details` stay machine-readable; the message is
  what `/monitor/tests` and the client show. Example: `new AppError('NOT_FOUND', 'No authenticated user was identified for the responsible customer.', 404, { ... })`.

### An operation the port does not support

NEVER cast a repository to reach a method it does not declare — `const x = orders as unknown as
{ delete(id: string): Promise<void> }` compiles and then throws `undefined is not a function` at run
time, which reaches the client as `INTERNAL_ERROR: Unexpected error` (7 of 22 cases of one production
suite). The port IS the contract: if it declares no `delete`, this entity is not deletable, and the
usecase must say so in a way the caller can read:

```ts
throw new AppError('CONFLICT', 'ProjectCoordinationAssignment repository does not support deletion.', 409, { projectCoordinationAssignmentId: input.projectCoordinationAssignmentId });
```

The same holds for any other missing method. A generic error in a predictable path is a defect of
handling, independent of the policy behind it.

## Child-entity operations (embedded members)

An operation may target a CHILD entity that is embedded in a parent aggregate (it lives in the parent's
collection, stored in `details` JSONB — e.g. `OrderItem` inside `Order`). There is **no child
repository**. The defs gives you the parent in `data.ports` / `data.functions[].ports`. Pattern:

1. resolve the PARENT port (`resolveRepository<I{Parent}Repository>(ctx, '{Parent}')`);
2. load the parent aggregate (the input carries the parent id, e.g. `orderId`, plus the child id);
3. find and mutate the child inside the parent's collection;
4. `save(parent)`.

Never call a method like `findByOrderItemId` on the parent port and never import a child port — those do
not exist. If you need the parent id to locate the child, it is part of the function input.

## MDM references (master data, accessed by id)

Entities listed in `data.mdmRefs` are MDM master data (people, companies, vehicles, menus, categories,
tables). They live in the shared 102034 MDM store, NOT in this module: there is **no local port, entity
or table** for them, and you must NEVER `resolveRepository` one. A transaction references them **by id
only** — the id comes in the function input (e.g. `tableId`, `menuCategoryId`).

Read a master-data record by id via the MDM facade:

```ts
const entity = await ctx.mdm.entity.get({ mdmId: input.tableId });
if (!entity) throw new AppError('NOT_FOUND', `MDM record not found: ${input.tableId}`, 404, { mdmId: input.tableId });
const table = entity.details; // the master-data payload
```

`ctx.mdm.entity.get`/`ctx.mdm.collection.getMany` return `MdmEntityReadResult`:
`{ mdmId, version, document, index, details, related() }`.

- `document` is `MdmDocumentRecord = { mdmId, version, details }` — it has **NO**
  `createdAt`/`updatedAt`. Reading `entity.document.createdAt` is a TS2339 compile error; never
  infer temporal metadata on `document`.
- Timestamps live on the INDEX: `entity.index.createdAt` / `entity.index.updatedAt`
  (`MdmEntityIndexRecord`). Module-owned dates may also live under `entity.details.<moduleId>`.

For bulk reads use `ctx.mdm.collection.getMany({ mdmIds })`. For module lists use
`ctx.mdm.collection.listByType({ type: '<module>.<Entity>' })`; this reads the promoted
`details.moduleTypes` index. For relationship hydration use `ctx.mdm.collection.relatedOfMany(...)`
and `ctx.mdm.collection.hydrateMany(...)`. Often just storing/passing the id is enough - only fetch the
record when you actually need its fields. Do not import any `/_{project}_/.../ports/{mdm}Repository` -
it does not exist.

### Type pitfalls that fail the compile (the in-loop compiler now checks cross-project types too)

- **`entity.related(key)` takes a typed `CompactRelationshipRefKey`** — NEVER invent a key or force one
  with a literal cast (`entity.related(key as 'o')` / `entity.relatedIds(rel as 'OffersProduct')` are
  rejected). To get a linked id, read a DECLARED field off the record (e.g.
  `entity.details.<moduleId>.menuCategoryId`), not a guessed relationship key.
- **Append-only EVENT entities have NO `updatedAt`** — they carry only `createdAt` (plus their own
  declared timestamps such as `occurredAt`/`voidedAt`). Setting `updatedAt` on an event object literal is
  a compile error (TS2353). Only mutable **core** aggregates have `updatedAt`.
- **A port method typed `Promise<T | null>` really can return null** — assign it to a `T | null` variable
  and null-check (or throw `NOT_FOUND`) before use. Never assign a nullable result to a non-null variable
  or pass it where a non-null `T` is required (TS2322/TS2345).
- **Never assign through a callback into `let x: T | null = null`.** TypeScript cannot see assignments
  inside a function passed as an argument (`runInTransaction(async () => { x = … })`). After `if (!x)`
  the type is `never` and property access fails to compile (TS2339). Return the value from the callback.

  Wrong:
  ```ts
  let updatedComment: TicketComment | null = null;
  await ctx.data.runInTransaction(async () => {
    updatedComment = { ...comment, commentText: input.commentText };
    await comments.save(updatedComment);
  });
  if (!updatedComment) throw new AppError('CONFLICT', 'Ticket comment was not updated.', 409);
  return { ticketCommentId: updatedComment.ticketCommentId, ticketId: updatedComment.ticketId, commentText: updatedComment.commentText };
  ```

  Right — the callback returns the value:
  ```ts
  const updatedComment = await ctx.data.runInTransaction(async () => {
    const next = { ...comment, commentText: input.commentText };
    await comments.save(next);
    return next;
  });
  return { ticketCommentId: updatedComment.ticketCommentId, ticketId: updatedComment.ticketId, commentText: updatedComment.commentText };
  ```

Plural-first rule: never call `ctx.mdm.entity.get` inside a `for`/`while`/`map`/`forEach` loop. Collect
the ids first, call `ctx.mdm.collection.getMany({ mdmIds })` or `hydrateMany`, then join the results in
memory.

### Writing a module-owned MDM record (cadastral data only)

When `data.kind === 'mdm'` and the operation creates/updates the record, write through the MDM facade.
Never write `mdmDocument.put` directly: the facade is what keeps the document, index and
`relationshipRefs` consistent. The stored `details` is an MDM detail payload with required base fields;
place the module-owned columns under the module namespace key (for example `cafeFlow`) and include the
canonical module type in `moduleTypes`. If a field is module-specific but belongs to the master-data
record, store it under `details.<moduleId>`; if it is a relation to another MDM record, use
`ctx.mdm.entity.link/unlink` instead of storing a raw related id in JSON.

When `data.mdmWrites` names the entity, transcribe it — do not infer subtype or id from a name:
`mdmType` is the role tag `<moduleId>.<Entity>` (goes in `moduleTypes` and `tags`, or
`listByType` will never see the record), `subtype` is the 102034 closed union from the l4,
`idField` is the module-side field that CARRIES the returned `mdmId`, `baseFields` are level-1
identification/base inputs, `namespaceFields` are the module namespace under `ctx.moduleId`.
Store `created.mdmId` in `idField`; never mint a separate local id for a master-data record.
`countryCode` is required on the engine index: use `ctx.organization?.countryCode` when that field
exists; otherwise the level-1 identification default `'US'`. Never derive it from language.

A create of a role on Person/Company is **create-or-attach**, not a second person. The facade
`ctx.mdm.entity.create` already returns `alreadyExists` when a document matches; it does not add
the new role. Always add the role tag and write the namespace:

```ts
const write = data.mdmWrites[0];
const created = await ctx.mdm.entity.create({
  details: {
    subtype: write.subtype,
    name: input.name,
    status: 'Active',
    countryCode: 'US',
    moduleTypes: [write.mdmType],
    tags: [write.mdmType],
    [ctx.moduleId]: Object.fromEntries(write.namespaceFields.map((fieldId: string) => [fieldId, (input as Record<string, unknown>)[fieldId]])),
  },
});
if (created.alreadyExists) {
  const tags = [...new Set([...(created.details.tags ?? []), write.mdmType])];
  const moduleTypes = [...new Set([...(created.details.moduleTypes ?? []), write.mdmType])];
  await ctx.mdm.entity.update({
    mdmId: created.mdmId,
    expectedVersion: created.version,
    details: {
      ...created.details,
      tags,
      moduleTypes,
      [ctx.moduleId]: {
        ...((created.details as Record<string, unknown>)[ctx.moduleId] as object),
        ...Object.fromEntries(write.namespaceFields.map((fieldId: string) => [fieldId, (input as Record<string, unknown>)[fieldId]])),
      },
    },
  });
}
```

`findByDocument` / `findByContact` / `attachRole` are not on `ctx.mdm` yet — use `create` +
`alreadyExists` + `update` as above. Do not invent a second lookup API.

For update, load the entity, preserve fields you do not change, and pass the optimistic version.
For create-or-attach use `ctx.mdm.entity.create` (then `update` when `alreadyExists`). For
cadastral deactivation prefer `ctx.mdm.entity.inactivate`; use physical `ctx.mdm.entity.delete` only when the
operation truly removes a standalone record. For MDM links use
`ctx.mdm.entity.link({ fromId, toId, type })` and `ctx.mdm.entity.unlink({ relationshipId })`.
If no existing `RelationshipType` expresses the domain relation, record a modeling gap instead of
inventing a free-text type in generated code.
For prospect/pre-qualified lead flows use the explicit prospect facade:
`ctx.mdm.prospect.create`, `ctx.mdm.prospect.get`, `ctx.mdm.prospect.listByType`,
`ctx.mdm.prospect.update` and `ctx.mdm.prospect.promoteToEntity`; do not model prospects through
`ctx.mdm.entity`.

### `data.mdm` — the cadastral rules of a master-data operation

When the item carries `data.mdm`, the l4 has declared that this operation acts on master data, and the
block says HOW. Master data is never destroyed: the catalogue emits an inactivate/reactivate pair in
place of a delete, because removing a record would break the history and the references other modules
keep to it.

| `data.mdm` | what the usecase must do |
| --- | --- |
| `lifecycle: 'inactivate'` | call `ctx.mdm.entity.inactivate({ mdmId, expectedVersion })` and nothing else destructive. NEVER `ctx.mdm.entity.delete`, never a local port/table write. |
| `lifecycle: 'reactivate'` | call `ctx.mdm.entity.reactivate({ mdmId, expectedVersion })` — the exact mirror. |
| `activeFilterInput: '<name>'` | the list filters `status: 'Active'` by DEFAULT; when that input is `true`, pass no status and return everything. The input is already in `data.inputs` as an optional boolean. |
| `situationOutput: '<name>'` | that output field is DERIVED from the MDM index status (`index.status === 'Active'`). Never read or invent a local `active`/`situation` field — there is no such column. |

Two rules that do not appear in the block and still hold:

- **A lookup by id never filters by status.** The detail screen has to resolve an inactivated record —
  that is the whole point of preserving it. Only LIST reads are active-only by default.
- **The `mdmId` comes from the module field named by `mdmWrites[].idField`** (when present); a lifecycle
  operation receives it through its own `selectedEntity` input.

The optimistic `expectedVersion` is mandatory on both halves: read the entity, pass the version you
read. Two concurrent screens deactivating the same record must not silently overwrite each other.

Relationship decision guide:

| Situation | MDM relationship |
| --- | --- |
| Ownership/possession | `Owns` |
| Physical/logical location | `LocatedAt` |
| Organization hierarchy | `SubsidiaryOf`, `BelongsToGroup`, `PartOfUnit` |
| Supplier/customer relation | `SupplierOf`, `CustomerOf` |
| Product/service offered | `OffersProduct`, `OffersService` |
| Contact channel/person | `HasContact` |

If none of these expresses the domain, keep the ids and record a modeling gap instead of inventing a
free-text relationship type silently.

Embedded decision guide: use embedded only for small child data that has no global identity, no
independent lifecycle, no cross-aggregate references, no own audit/reporting need and no relationship of
its own. If it needs identity, links, attachments, search or history, model it as MDM-owned or
module-owned instead of embedding it to simplify code.

Forbidden in generated module code: `ctx.data.mdmDocument`, `ctx.data.mdmEntityIndex`,
`ctx.data.mdmRelationship`, `tx.mdmDocument`, `tx.mdmEntityIndex`, `tx.mdmRelationship` and local MDM
repositories.

NEVER store operational/transactional state (occupancy, movement, balances, `'occupied'`/`'available'`)
in an MDM record — that is NOT cadastral data and belongs to a local `core` entity with its own table.
The MDM `status` is always one of the four cadastral `MdmStatus` values.

## Derived projections (`data.derivedRefs`)

Entities listed in `data.derivedRefs` are computed projections: no table, no repository port, never
`resolveRepository`. Compose them in the output. `ofEntity: '<projection>'` on output fields is
legitimate.

When a derivedRef carries `derivation`, that block is the account — implement it:

1. Resolve the source `from` through its port (it is already in `data.ports` when the source is a
   module aggregate) or via `ctx.mdm` if it is master data.
2. Apply `filter` (empty string means unfiltered).
3. Compute each `aggregate` entry (`count` | `sum` | `min` | `max` | `first` | `groupKey`) onto the
   named output field. Use `sourceField` when the op reads a source column (`count` has none).

Do not invent a second formula and do not hardcode zero. When `derivation` is absent (older l4),
keep composing from `description`/`notes` as today — do not fail the run.

## Emitting events (append-only history)

`data.eventWrites` lists events this usecase MUST record whenever the matching transition happens, so the
history survives a restart instead of living only in memory. For each entry:

- **persisted** (`purpose` telemetry/audit): its port is already in `data.ports`. Resolve it
  (`resolveRepository<I{Event}Repository>(ctx, '{Event}')`), build the event record (new id via
  `ctx.idGenerator.newId()`, owner id, the new status/values, timestamp via `ctx.clock.nowIso()`) and
  `append(record)` it **inside the same `ctx.data.runInTransaction` as the aggregate write** — so the
  state change and its event commit together. Never `update`/`delete` an event.
- **reaction** (not persisted, `port` is null): there is no table — publish the trigger on the platform
  queue (`ctx.data.pgQueue.publish({ topic, payload })`) instead of a port; do not store local history.

Do NOT declare an event object and leave it unused: if `eventWrites` lists it, it must actually be
appended/enqueued on the transition.

## `steps` are guidance, not a contract

`data.steps` (and `data.functions[].steps`) are hints about intent. The CONTRACT you must satisfy is
`functions[].input` / `output` / `ports`. Do not invent repository methods or fields to satisfy a step
literally — implement the step using the declared input/output and the imported port + domain.
