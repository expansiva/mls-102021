# CHANGELOG

## 2026-08-28 — string/enum do l4 nunca vira INTEGER

O planner recebia só `fieldId`+`reason` e escolhia INTEGER para um campo chamado `priority` cujo
l4 era `string` + enum `low|medium|high` (o `status` vizinho, mesma forma, saía TEXT). Seeds e a
UI mandam a string do enum; o INSERT quebra. O payload agora leva `type`/`enum`; o writer coerces
família incompatível antes do save; validate-all emite `column type mismatch` se o defeito
atravessar.

## 2026-08-25 — title/name e datas são colunas (busca/ordenação)

`planTableColumns` indexa `title`/`name` (search) e `date`/`datetime`/`*At` (ordering), além de PK,
FK, status/enum e `createdAt`. Sem coluna, o adapter não tem onde fazer `ILIKE`/`ORDER BY`.

## 2026-08-24 — JSONB details keys = fieldId

Skill: keys inside the `details` envelope are the entity fieldId verbatim (camelCase). snake_case
is only for `tableName` and column `name`. The table def does not rename those keys.

## 2026-08-22 — fixtures de l2 não importam l1/server do 102034

Código de agente em `l2` nunca importa (nem como tipo) o `l1/server` do 102034 — o
`tsconfig.frontend.json` compila `l2` DOM-only (`types: []`). A forma do fixture fica local.

## 2026-08-22 — strip redundant `<table>_pkey` indexes before save

Postgres already creates `<tableName>_pkey` from `PRIMARY KEY`. The model has emitted that index
alongside `primaryKey` (petShop `appointment_availability_pkey` → 42P07 at publish). The writer now
drops reserved `_pkey` names and indexes whose columns are exactly the primary key before `saveDefs`.
Secondary indexes keep the `_idx` suffix (`service_execution_*_idx` is the legitimate shape).

## 2026-07-11 — migração ns3

- Step movido do folder plano `agentChangeBackend/` para `steps/gen-table/` (1 folder por unidade de manutenção).
- `fileReference` e `agentFolder` atualizados para o novo caminho; agentes resolvidos por `agentName` (getInstanceByName), imports do núcleo permanecem absolutos.
