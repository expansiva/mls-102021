/// <mls shortName="bteste" project="102021" enhancement="_blank" />


import { IAteste } from '/_102021_ateste';

class bteste{

    private teste: IAteste | undefined;
}