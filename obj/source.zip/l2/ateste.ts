/// <mls shortName="ateste" project="102021" enhancement="_blank" />


export class IAteste extends HTMLElement{
    
}
